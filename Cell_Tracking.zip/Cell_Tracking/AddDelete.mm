//
// AddDelete.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 09/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "AddDelete.h"

@implementation AddDelete

-(int)addLineageMain:(int)connectNoAdd{
    int returnResults = 0;
    
    if (connectNoAdd > 0){
        ifstream fin;
        
        int maxLineageNo = 0;
        int dataLoadingErrorStatus = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (arrayLineageStartEnd [counter1*8] > maxLineageNo) maxLineageNo = arrayLineageStartEnd [counter1*8];
        }
        
        maxLineageNo++;
        
        string lineageNoExtension = to_string(timeOneHold);
        
        if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
        else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
        else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
        
        string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        long sizeForCopyA = 0;
        long sizeForCopyB = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter2 = 0; counter2 < 6; counter2++){
            sizeForCopy = 0;
            
            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter2 == 0) size1 = sizeForCopy;
                else if (counter2 == 1) size2 = sizeForCopy;
                else if (counter2 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter2 == 3) size1 = sizeForCopy;
                else if (counter2 == 4) size2 = sizeForCopy;
                else if (counter2 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        uint8_t *uploadTemp;
        int uploadTempLoading = 0;
        
        unsigned long readPosition = 0;
        int stepCount = 0;
        int finData [19];
        int readBit [4];
        int pointNoCount = 0;
        int pointGravityCenterCount = 0;
        int centerX = 0;
        int centerY = 0;
        int dataTemp = 0;
        int modifyStartFlag = -1;
        
        //-----Master Data upLoad-----
        if (checkFlag == 1){
            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
            uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        readingError = 1;
                    }
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                uploadTempLoading = 1;
                readPosition = 0;
                stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        readPosition = readPosition+5;
                        
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Connect no
                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++;
                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                        
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                        
                        if (finData [7] == connectNoAdd && finData [13] == 0 && finData [16] == 0 && modifyStartFlag == -1){
                            dataTemp = maxLineageNo;
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            uploadTemp [readPosition-1] = (uint8_t)readBit [2];
                            uploadTemp [readPosition-2] = (uint8_t)readBit [1];
                            uploadTemp [readPosition-3] = (uint8_t)readBit [0];
                            uploadTemp [readPosition-4] = 1;
                            uploadTemp [readPosition-5] = 0;
                            uploadTemp [readPosition-6] = 0;
                            uploadTemp [readPosition-7] = 0;
                            uploadTemp [readPosition-8] = 0;
                            uploadTemp [readPosition-9] = 0;
                            
                            pointNoCount++;
                            modifyStartFlag = 1;
                        }
                        else if (finData [7] == connectNoAdd && finData [13] == 0 && finData [16] == 0 && modifyStartFlag == 1){
                            uploadTemp [readPosition-1] = (uint8_t)readBit [2];
                            uploadTemp [readPosition-2] = (uint8_t)readBit [1];
                            uploadTemp [readPosition-3] = (uint8_t)readBit [0];
                            uploadTemp [readPosition-4] = 1;
                            uploadTemp [readPosition-5] = 0;
                            uploadTemp [readPosition-6] = 0;
                            uploadTemp [readPosition-7] = 0;
                            uploadTemp [readPosition-8] = 0;
                            uploadTemp [readPosition-9] = 0;
                            
                            pointNoCount++;
                        }
                        
                        if (finData [7] == 0 && finData [16] == 0) stepCount = 1;
                    }
                    else if (stepCount == 1){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        finData [9] = finData [8]*256+finData [9];
                        
                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                    }
                    else if (stepCount == 2){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                        
                        if (pointGravityCenterCount+1 == connectNoAdd){
                            centerX = finData [1];
                            centerY = finData [3];
                        }
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                        else pointGravityCenterCount++;
                    }
                    
                } while (stepCount != 3);
            }
        }
        
        if (checkFlag == 1 && readingError == 1) dataLoadingErrorStatus = 1;
        
        string extension;
        
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        sizeForCopyA = 0;
        
        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopyA = sizeOfFile.st_size;
        }
        
        uint8_t *uploadTempA;
        int uploadTempALoading = 0;
        
        readingError = 0;
        
        if (sizeForCopyA != 0){
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            uploadTempA = new uint8_t [sizeForCopyA+50];
            fin.read((char*)uploadTempA, sizeForCopyA+50);
            
            if ((finData [0] = uploadTempA [sizeForCopyA-1]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-2]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-3]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-4]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-5]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-6]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-7]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-8]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-9]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-10]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-11]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-12]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-13]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-14]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-15]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-16]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-17]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-18]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTempA, sizeForCopyA+50);
                
                if ((finData [0] = uploadTempA [sizeForCopyA-1]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-2]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-3]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-4]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-5]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-6]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-7]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-8]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-9]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-10]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-11]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-12]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-13]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-14]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-15]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-16]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-17]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-18]) != 0 || (finData [0] = uploadTempA [sizeForCopyA-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                readPosition = 0;
                stepCount = 0;
                uploadTempALoading = 0;
                int entryCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        readPosition = readPosition+13;
                        
                        finData [13] = uploadTempA [readPosition], readPosition++;
                        finData [14] = uploadTempA [readPosition], readPosition++;
                        finData [15] = uploadTempA [readPosition], readPosition++; //--9 Connect no
                        finData [16] = uploadTempA [readPosition], readPosition++;
                        finData [17] = uploadTempA [readPosition], readPosition++;
                        finData [18] = uploadTempA [readPosition], readPosition++; //--10 Lineage no
                        
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            if (entryCount == connectNoAdd-1){
                                uploadTempA [readPosition-19] = 7;
                                
                                dataTemp = maxLineageNo;
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                uploadTempA [readPosition-3] = (uint8_t)readBit [0];
                                uploadTempA [readPosition-2] = (uint8_t)readBit [1];
                                uploadTempA [readPosition-1] = (uint8_t)readBit [2];
                                
                                break;
                            }
                            
                            entryCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
        }
        
        if (readingError == 1) dataLoadingErrorStatus = 1;
        
        string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
        
        sizeForCopyB = 0;
        
        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
            sizeForCopyB = sizeOfFile.st_size;
        }
        
        readingError = 0;
        
        uint8_t *uploadTempB;
        int uploadTempBLoading = 0;
        
        int *relDataTemp = new int [sizeForCopyB+50];
        int relDataTempCount = 0;
        
        //-----Master Data upLoad-----
        if (sizeForCopyB != 0){
            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
            uploadTempB = new uint8_t [sizeForCopyB+50];
            fin.read((char*)uploadTempB, sizeForCopyB+50);
            
            if ((finData [0] = uploadTempB [sizeForCopyB-1]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-2]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-3]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-4]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-5]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-6]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-7]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-8]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-9]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-10]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-11]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-12]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-13]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-14]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-15]) != 0){
                usleep(50000);
                fin.read((char*)uploadTempB, sizeForCopyB+50);
                
                if ((finData [0] = uploadTempB [sizeForCopyB-1]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-2]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-3]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-4]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-5]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-6]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-7]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-8]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-9]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-10]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-11]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-12]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-13]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-14]) != 0 || (finData [0] = uploadTempB [sizeForCopyB-15]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                uploadTempBLoading = 1;
                readPosition = 0;
                stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTempB [readPosition], readPosition++;
                        finData [1] = uploadTempB [readPosition], readPosition++;
                        finData [2] = uploadTempB [readPosition], readPosition++; //--1 Lineage no
                        finData [3] = uploadTempB [readPosition], readPosition++;
                        finData [4] = uploadTempB [readPosition], readPosition++;
                        finData [5] = uploadTempB [readPosition], readPosition++; //--3 Connect no
                        finData [6] = uploadTempB [readPosition], readPosition++;
                        finData [7] = uploadTempB [readPosition], readPosition++; //--4 Image no
                        finData [8] = uploadTempB [readPosition], readPosition++; //--5 +-
                        finData [9] = uploadTempB [readPosition], readPosition++;
                        finData [10] = uploadTempB [readPosition], readPosition++;
                        finData [11] = uploadTempB [readPosition], readPosition++;
                        finData [12] = uploadTempB [readPosition], readPosition++; //--6 Cell no
                        finData [13] = uploadTempB [readPosition], readPosition++; //--7 Target
                        finData [14] = uploadTempB [readPosition], readPosition++; //--8 Res
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                        else{
                            
                            relDataTemp [relDataTempCount] = finData [2], relDataTempCount++;
                            relDataTemp [relDataTempCount] = finData [5], relDataTempCount++;
                            relDataTemp [relDataTempCount] = finData [7], relDataTempCount++;
                            relDataTemp [relDataTempCount] = finData [12], relDataTempCount++;
                            relDataTemp [relDataTempCount] = finData [13], relDataTempCount++;
                            relDataTemp [relDataTempCount] = finData [14], relDataTempCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
        }
        
        if (readingError == 1) dataLoadingErrorStatus = 1;
        
        if (dataLoadingErrorStatus == 0){
            //======Master data save========
            ofstream outfile (connectDataPath.c_str(), ofstream::binary);
            outfile.write ((char*)uploadTemp, sizeForCopy);
            outfile.close();
            
            //======Status data save=======
            ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
            outfile2.write ((char*)uploadTempA, sizeForCopyA);
            outfile2.close();
            
            //for (int counterA = 0; counterA < relDataTempCount2/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<relDataTemp2 [counterA*6+counterB];
            //	cout<<" relDataTemp2 "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < relDataTempCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<relDataTemp [counterA*10+counterB];
            //	cout<<" relDataTemp "<<counterA<<endl;
            //}
            
            //======Rel data save=======
            relDataTemp [relDataTempCount] = maxLineageNo, relDataTempCount++;
            relDataTemp [relDataTempCount] = connectNoAdd, relDataTempCount++;
            relDataTemp [relDataTempCount] = timeOneHold, relDataTempCount++;
            relDataTemp [relDataTempCount] = 0, relDataTempCount++;
            relDataTemp [relDataTempCount] = 0, relDataTempCount++;
            relDataTemp [relDataTempCount] = 0, relDataTempCount++;
            
            //for (int counterA = 0; counterA < relDataTempCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<relDataTemp [counterA*6+counterB];
            //	cout<<" relDataTemp "<<counterA<<endl;
            //}
            
            char *writingArray = new char [relDataTempCount/6*16+16];
            unsigned long indexCount = 0;
            
            for (int counter1 = 0; counter1 < relDataTempCount/6; counter1++){
                dataTemp = relDataTemp [counter1*6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = relDataTemp [counter1*6+1];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = relDataTemp [counter1*6+2];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                if (relDataTemp [counter1*6+3] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = relDataTemp [counter1*6+3]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = relDataTemp [counter1*6+3];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                writingArray [indexCount] = (char)relDataTemp [counter1*6+4], indexCount++;
                writingArray [indexCount] = (char)relDataTemp [counter1*6+5], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
            outfile3.write ((char*) writingArray, indexCount);
            outfile3.close();
            
            delete [] writingArray;
            //-----1. X position, 2. Y position, 3. Time point, 4. Event Type, 5. Next Cell number, Fusion: hold cell number of Fusion partner-----
            //-----6. Cell Number, 7. Cell Lineage Number, 8. For Fusion, Cell lineage Number-----
            
            string connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            int *lingDataTemp = new int [lineageDataCount+50];
            int lingDataTempCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataCount; counter1++) lingDataTemp [lingDataTempCount] = arrayLineageData [counter1], lingDataTempCount++;
            
            //for (int counterA = 0; counterA < lingDataTempCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lingDataTemp [counterA*8+counterB];
            //	cout<<" lingDataTemp "<<counterA<<endl;
            //}
            
            lingDataTemp [lingDataTempCount] = centerX, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = centerY, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = timeOneHold, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = 1, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = 0, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = 0, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = maxLineageNo, lingDataTempCount++;
            lingDataTemp [lingDataTempCount] = 0, lingDataTempCount++;
            
            if (lineageDataStatus == 1) delete [] arrayLineageData;
            arrayLineageData = new int [lingDataTempCount+50];
            lineageDataCount = 0;
            lineageDataLimit = lingDataTempCount+50;
            lineageDataStatus = 1;
            
            for (int counter1 = 0; counter1 < lingDataTempCount; counter1++) arrayLineageData [lineageDataCount] = lingDataTemp [counter1], lineageDataCount++;
            
            writingArray = new char [lineageDataCount/8*25+25];
            
            indexCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                if (arrayLineageData [counter1*8] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8];
                }
                
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                if (arrayLineageData [counter1*8+1] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+1]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+1];
                }
                
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayLineageData [counter1*8+2];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                writingArray [indexCount] = (char)arrayLineageData [counter1*8+3], indexCount++;
                
                if (arrayLineageData [counter1*8+4] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+4]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+4];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                if (arrayLineageData [counter1*8+5] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+5]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = arrayLineageData [counter1*8+5];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                dataTemp = arrayLineageData [counter1*8+6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = arrayLineageData [counter1*8+7];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile4 (connectDataLineagePath.c_str(), ofstream::binary);
            outfile4.write ((char*) writingArray, indexCount);
            outfile4.close();
            
            delete [] writingArray;
            delete [] lingDataTemp;
            
            //==========Lineage Start end, 1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
            if (lineageStartEndCount+24 > lineageStartEndLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate lineageStartEndUpDate];
            }
            
            arrayLineageStartEnd [lineageStartEndCount] = maxLineageNo, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = 0, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = centerX, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = centerY, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = lineageDataCount/8-1, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = timeOneHold, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = lineageDataCount/8-1, lineageStartEndCount++;
            arrayLineageStartEnd [lineageStartEndCount] = timeOneHold, lineageStartEndCount++;
            
            //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
            //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
            //}
            
            if (lineageStartEndCount != 0){
                string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                
                char *mainDataEntry = new char [lineageStartEndCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++){
                    extension = to_string(arrayLineageStartEnd [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile5 (connectStartEndPath.c_str(), ofstream::binary);
                outfile5.write (mainDataEntry, totalEntryCount);
                outfile5.close();
                
                delete [] mainDataEntry;
            }
            
            //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
            string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
            
            int *lingStatusDataTemp = new int [cellLineageInfoCount+50];
            int lingStatusDataTempCount = 0;
            
            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
            //}
            
            int saveHoldPoint = 0;
            
            for (int counter1 = 0; counter1 < cellLineageInfoCount/3; counter1++){
                if (arrayCellLineageInfo [counter1*3] < maxLineageNo){
                    lingStatusDataTemp [lingStatusDataTempCount] = arrayCellLineageInfo [counter1*3], lingStatusDataTempCount++;
                    lingStatusDataTemp [lingStatusDataTempCount] = arrayCellLineageInfo [counter1*3+1], lingStatusDataTempCount++;
                    lingStatusDataTemp [lingStatusDataTempCount] = arrayCellLineageInfo [counter1*3+2], lingStatusDataTempCount++;
                }
                
                if (lingStatusDataTemp [counter1*3] > maxLineageNo){
                    saveHoldPoint = counter1;
                    break;
                }
            }
            
            lingStatusDataTemp [lingStatusDataTempCount] = maxLineageNo, lingStatusDataTempCount++;
            lingStatusDataTemp [lingStatusDataTempCount] = 0, lingStatusDataTempCount++;
            lingStatusDataTemp [lingStatusDataTempCount] = 1, lingStatusDataTempCount++;
            
            for (int counter1 = saveHoldPoint; counter1 < cellLineageInfoCount/3; counter1++){
                if (arrayCellLineageInfo [counter1*3] > maxLineageNo){
                    lingStatusDataTemp [lingStatusDataTempCount] = arrayCellLineageInfo [counter1*3], lingStatusDataTempCount++;
                    lingStatusDataTemp [lingStatusDataTempCount] = arrayCellLineageInfo [counter1*3+1], lingStatusDataTempCount++;
                    lingStatusDataTemp [lingStatusDataTempCount] = arrayCellLineageInfo [counter1*3+2], lingStatusDataTempCount++;
                }
            }
            
            if (cellLineageInfoStatus == 1) delete [] arrayCellLineageInfo;
            arrayCellLineageInfo = new int [lingStatusDataTempCount+50];
            cellLineageInfoCount = 0;
            cellLineageInfoLimit = lingStatusDataTempCount+50;
            cellLineageInfoStatus = 1;
            
            for (int counter1 = 0; counter1 < lingStatusDataTempCount; counter1++) arrayCellLineageInfo [cellLineageInfoCount] = lingStatusDataTemp [counter1], cellLineageInfoCount++;
            
            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
            //}
            
            char *mainDataEntry = new char [lingStatusDataTempCount*6+10];
            int totalEntryCount = 0;
            
            for (int counter1 = 0; counter1 < lingStatusDataTempCount; counter1++){
                extension = to_string(lingStatusDataTemp [counter1]);
                
                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile5 (connectDataInfoPath.c_str(), ofstream::binary);
            outfile5.write (mainDataEntry, totalEntryCount);
            outfile5.close();
            
            delete [] mainDataEntry;
            delete [] lingStatusDataTemp;
            
            //=========Queue List creation==========
            if (queueListCount+12 > queueListLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate queueListUpDate];
            }
            
            arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
            
            string cellLineageString = to_string(maxLineageNo);
            
            if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
            else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
            else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
            else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
            else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
            
            arrayQueueList [queueListCount] = cellLineageString, queueListCount++;
            arrayQueueList [queueListCount] = "C000000000", queueListCount++;
            
            extension = to_string(timeOneHold);
            
            arrayQueueList [queueListCount] = extension+":"+extension, queueListCount++;
            arrayQueueList [queueListCount] = "0", queueListCount++;
            arrayQueueList [queueListCount] = "Wait", queueListCount++;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                mainDataEntry = new char [queueListCount*12+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile6 (queueListPath.c_str(), ofstream::binary);
                outfile6.write (mainDataEntry, totalEntryCount);
                outfile6.close();
                
                delete [] mainDataEntry;
            }
            
            //-----Folder creation-----
            string lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageString;
            mkdir(lineageFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string cellFolderPath = lineageFolderPath+"/C000000000";
            mkdir(cellFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string lineageFolderPath2 = lineageFolderPath+"/"+analysisID+"_"+cellLineageString+"_CellStatus";
            
            ofstream oin;
            oin.open(lineageFolderPath2.c_str(), ios::out);
            oin<<0<<endl;
            oin<<timeOneHold<<endl;
            oin<<-1<<endl;
            oin<<1<<endl;
            oin<<0<<endl;
            oin<<0<<endl;
            oin<<maxLineageNo<<endl;
            oin<<"End"<<endl;
            oin.close();
            
            //=========LINE DATA AMEND==========
            //-----1. Image No, 2, X position, 3 Y position, 4. Value, 5. Connect No, 6. Lineage NO-----
            lineageFolderPath2 = cellFolderPath+"/"+analysisID+"_"+cellLineageString+"_lineDataAmend";
            
            indexCount = 0;
            int lastZeroEntry = 0;
            stepCount = 0;
            readPosition = 0;
            modifyStartFlag = -1;
            
            writingArray = new char [pointNoCount*15+1];
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                    finData [2] = uploadTemp [readPosition], readPosition++;
                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                    finData [5] = uploadTemp [readPosition], readPosition++;
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                    
                    readPosition = readPosition+9;
                    
                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                    
                    if (finData [7] == 0){
                        stepCount = 3;
                        
                        if (lastZeroEntry == 0){
                            for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                        }
                    }
                    else{
                        
                        if (finData [7] == connectNoAdd && modifyStartFlag == -1){
                            dataTemp = timeOneHold;
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)finData [0], indexCount++;
                            writingArray [indexCount] = (char)finData [1], indexCount++;
                            
                            writingArray [indexCount] = (char)finData [2], indexCount++;
                            writingArray [indexCount] = (char)finData [3], indexCount++;
                            
                            writingArray [indexCount] = 1, indexCount++;
                            
                            writingArray [indexCount] = (char)finData [5], indexCount++;
                            writingArray [indexCount] = (char)finData [6], indexCount++;
                            writingArray [indexCount] = (char)finData [7], indexCount++;
                            
                            dataTemp = maxLineageNo;
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            modifyStartFlag = 1;
                        }
                        else if (finData [7] == connectNoAdd && modifyStartFlag == 1){
                            dataTemp = timeOneHold;
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)finData [0], indexCount++;
                            writingArray [indexCount] = (char)finData [1], indexCount++;
                            
                            writingArray [indexCount] = (char)finData [2], indexCount++;
                            writingArray [indexCount] = (char)finData [3], indexCount++;
                            
                            writingArray [indexCount] = 1, indexCount++;
                            
                            writingArray [indexCount] = (char)finData [5], indexCount++;
                            writingArray [indexCount] = (char)finData [6], indexCount++;
                            writingArray [indexCount] = (char)finData [7], indexCount++;
                            
                            dataTemp = maxLineageNo;
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        else if (finData [7] != connectNoAdd && modifyStartFlag == 1){
                            for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                            
                            modifyStartFlag = 2;
                            lastZeroEntry = 1;
                        }
                    }
                }
                
            } while (stepCount != 3);
            
            ofstream outfile7 (lineageFolderPath2.c_str(), ofstream::binary);
            outfile7.write ((char*)writingArray, indexCount);
            outfile7.close();
            
            delete [] writingArray;
            
            //=========Fluorescent line set==========
            if (fluorescentDetectionDisplay == 1){
                connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+lineageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 1){
                    arrayPositionRevise = new int [sizeForCopy+50];
                    positionReviseCount = 0;
                    positionReviseLimit = (int)sizeForCopy+50;
                    
                    readingError = 0;
                    
                    //-----Master Data upLoad-----
                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTempC = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTempC, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0 || (finData [0] = uploadTempC [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTempC, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0 || (finData [0] = uploadTempC [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTempC, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0 || (finData [0] = uploadTempC [sizeForCopy-12]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTempC [readPosition], readPosition++;
                                    finData [1] = uploadTempC [readPosition], readPosition++; //--1
                                    finData [2] = uploadTempC [readPosition], readPosition++;
                                    finData [3] = uploadTempC [readPosition], readPosition++; //--2
                                    finData [4] = uploadTempC [readPosition], readPosition++; //--3
                                    finData [5] = uploadTempC [readPosition], readPosition++;
                                    finData [6] = uploadTempC [readPosition], readPosition++;
                                    finData [7] = uploadTempC [readPosition], readPosition++; //--4
                                    finData [8] = uploadTempC [readPosition], readPosition++; //--+/- Flag
                                    finData [9] = uploadTempC [readPosition], readPosition++;
                                    finData [10] = uploadTempC [readPosition], readPosition++;
                                    finData [11] = uploadTempC [readPosition], readPosition++;
                                    finData [12] = uploadTempC [readPosition], readPosition++; //--5 Cell no
                                    finData [13] = uploadTempC [readPosition], readPosition++; //--6 Status
                                    finData [14] = uploadTempC [readPosition], readPosition++;
                                    finData [15] = uploadTempC [readPosition], readPosition++;
                                    finData [16] = uploadTempC [readPosition], readPosition++; //--7 Lineage no
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                        arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                    }
                                }
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTempC;
                    }
                    else{
                        
                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTempC = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTempC, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTempC, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTempC, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0 ){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTempC [readPosition], readPosition++;
                                    finData [1] = uploadTempC [readPosition], readPosition++; //--2
                                    finData [2] = uploadTempC [readPosition], readPosition++;
                                    finData [3] = uploadTempC [readPosition], readPosition++; //--2
                                    finData [4] = uploadTempC [readPosition], readPosition++; //--1
                                    finData [5] = uploadTempC [readPosition], readPosition++;
                                    finData [6] = uploadTempC [readPosition], readPosition++;
                                    finData [7] = uploadTempC [readPosition], readPosition++; //--3
                                    finData [8] = uploadTempC [readPosition], readPosition++; //--1
                                    finData [9] = uploadTempC [readPosition], readPosition++;
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //-----X Position-----
                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //-----Y Position-----
                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //-----Value-----
                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //-----Connect No-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Cell No-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Status-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Lineage no-----
                                    }
                                }
                            } while (stepCount != 3);
                            
                            delete [] uploadTempC;
                        }
                    }
                    
                    if (checkFlag == 0 || readingError == 1) dataLoadingErrorStatus = 1;
                    
                    if (dataLoadingErrorStatus == 0){
                        
                        //-----Master Data Status UpLoad-----
                        connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        arrayTimeSelected = new int [sizeForCopy+50];
                        timeSelectedCount = 0;
                        timeSelectedLimit = (int)sizeForCopy+50;
                        
                        readingError = 0;
                        
                        if (sizeForCopy != 0){
                            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTempC = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTempC, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0 || (finData [0] = uploadTempC [sizeForCopy-12]) != 0 || (finData [0] = uploadTempC [sizeForCopy-13]) != 0 || (finData [0] = uploadTempC [sizeForCopy-14]) != 0 || (finData [0] = uploadTempC [sizeForCopy-15]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTempC, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTempC [sizeForCopy-1]) != 0 || (finData [0] = uploadTempC [sizeForCopy-2]) != 0 || (finData [0] = uploadTempC [sizeForCopy-3]) != 0 || (finData [0] = uploadTempC [sizeForCopy-4]) != 0 || (finData [0] = uploadTempC [sizeForCopy-5]) != 0 || (finData [0] = uploadTempC [sizeForCopy-6]) != 0 || (finData [0] = uploadTempC [sizeForCopy-7]) != 0 || (finData [0] = uploadTempC [sizeForCopy-8]) != 0 || (finData [0] = uploadTempC [sizeForCopy-9]) != 0 || (finData [0] = uploadTempC [sizeForCopy-10]) != 0 || (finData [0] = uploadTempC [sizeForCopy-11]) != 0 || (finData [0] = uploadTempC [sizeForCopy-12]) != 0 || (finData [0] = uploadTempC [sizeForCopy-13]) != 0 || (finData [0] = uploadTempC [sizeForCopy-14]) != 0 || (finData [0] = uploadTempC [sizeForCopy-15]) != 0){
                                        readingError = 1;
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTempC [readPosition], readPosition++; //--1 Status
                                            finData [1] = uploadTempC [readPosition], readPosition++;
                                            finData [2] = uploadTempC [readPosition], readPosition++;
                                            finData [3] = uploadTempC [readPosition], readPosition++; //--3 Previous connect
                                            finData [4] = uploadTempC [readPosition], readPosition++;
                                            finData [5] = uploadTempC [readPosition], readPosition++;
                                            finData [6] = uploadTempC [readPosition], readPosition++; //--4 Start position
                                            finData [7] = uploadTempC [readPosition], readPosition++;
                                            finData [8] = uploadTempC [readPosition], readPosition++; //--5 Cut no
                                            finData [9] = uploadTempC [readPosition], readPosition++; //--6 Ch2
                                            finData [10] = uploadTempC [readPosition], readPosition++; //--7 Ch3
                                            finData [11] = uploadTempC [readPosition], readPosition++; //--8 Ch4
                                            finData [12] = uploadTempC [readPosition], readPosition++; //--9 Ch5
                                            finData [13] = uploadTempC [readPosition], readPosition++;
                                            finData [14] = uploadTempC [readPosition], readPosition++;
                                            finData [15] = uploadTempC [readPosition], readPosition++; //--10 Connect no
                                            finData [16] = uploadTempC [readPosition], readPosition++;
                                            finData [17] = uploadTempC [readPosition], readPosition++;
                                            finData [18] = uploadTempC [readPosition], readPosition++; //--11 Lineage no
                                            
                                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            finData [8] = finData [7]*256+finData [8];
                                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                            
                                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                                                arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                                                arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                                                arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                                                arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                                                arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                                                arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                                                arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                                                arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                                                arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTempC;
                            }
                        }
                        
                        if (readingError == 1) dataLoadingErrorStatus = 1;
                        
                        string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+exType;
                        string mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+lineageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                        
                        if (revisedWorkingMapStatus == 0){
                            revisedWorkingMap = new int *[imageDimension+1];
                            revisedWorkingMapStatus = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedWorkingMap [counter1] = new int [imageDimension+1];
                        }
                        
                        if (sourceImageStatus == 0){
                            sourceImage = new int *[imageDimension+1];
                            sourceImageStatus = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) sourceImage [counter1] = new int [imageDimension+1];
                        }
                        
                        if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            if (exType == ".tif"){
                                int dataConversion [4];
                                int endianType = 0;
                                int imageWidthEntry = 0;
                                int value0 = 0;
                                int value1 = 0;
                                int value2 = 0;
                                int imageDimensionReadCount = 0;
                                
                                unsigned long headPosition = 0;
                                
                                uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp2, sizeForCopy+50);
                                    fin.close();
                                    
                                    dataConversion [0] = uploadTemp2 [0];
                                    dataConversion [1] = uploadTemp2 [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = uploadTemp2 [7];
                                        dataConversion [1] = uploadTemp2 [6];
                                        dataConversion [2] = uploadTemp2 [5];
                                        dataConversion [3] = uploadTemp2 [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = uploadTemp2 [4];
                                        dataConversion [1] = uploadTemp2 [5];
                                        dataConversion [2] = uploadTemp2 [6];
                                        dataConversion [3] = uploadTemp2 [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    imageDimensionReadCount = 0;
                                    imageWidthEntry = 0;
                                    
                                    if (tifImageColorGray == 0){
                                        for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                            sourceImage [imageDimensionReadCount][imageWidthEntry] = uploadTemp2 [counter3], imageWidthEntry++;
                                            
                                            if (imageWidthEntry == imageDimension){
                                                imageWidthEntry = 0;
                                                imageDimensionReadCount++;
                                            }
                                        }
                                    }
                                    else if (tifImageColorGray == 1){
                                        for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                            value0 = uploadTemp2 [counter3];
                                            value1 = uploadTemp2 [counter3+1];
                                            value2 = uploadTemp2 [counter3+2];
                                            
                                            sourceImage [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                            
                                            if (imageWidthEntry == imageDimension){
                                                imageWidthEntry = 0;
                                                imageDimensionReadCount++;
                                            }
                                        }
                                    }
                                }
                                
                                delete [] uploadTemp2;
                            }
                            else if (exType == ".bmp"){
                                uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)uploadTemp2, sizeForCopy+50);
                                    fin.close();
                                    
                                    int imageDimensionReadCount = 0;
                                    
                                    for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                        for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                            sourceImage [imageDimensionReadCount][counter2] = uploadTemp2 [1078+counter1*imageDimension+counter2];
                                        }
                                        
                                        imageDimensionReadCount++;
                                    }
                                }
                                
                                delete [] uploadTemp2;
                            }
                        }
                        
                        //-----Source upload-----
                        int yDimensionCount;
                        int xDimensionCount;
                        int sizeTotal = imageDimension*imageDimension*4;
                        int pixData = 0;
                        
                        //-----Map-----
                        uint8_t *upload2 = new uint8_t [sizeTotal+50];
                        
                        fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)upload2, sizeTotal+1);
                            fin.close();
                            
                            yDimensionCount = 0;
                            xDimensionCount = 0;
                            
                            for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                                readBit [0] = upload2[counter1];
                                readBit [1] = upload2[counter1+1];
                                readBit [2] = upload2[counter1+2];
                                readBit [3] = upload2[counter1+3];
                                
                                pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                
                                for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                    revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                }
                                
                                if (xDimensionCount == imageDimension){
                                    xDimensionCount = 0;
                                    yDimensionCount++;
                                    
                                    if (yDimensionCount == imageDimension){
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            
                            fin.open(mapPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)upload2, sizeTotal+50);
                                fin.close();
                                
                                yDimensionCount = 0;
                                xDimensionCount = 0;
                                
                                for (int counter1 = 0; counter1 < sizeTotal; counter1 = counter1+4){
                                    readBit [0] = upload2[counter1];
                                    readBit [1] = upload2[counter1+1];
                                    readBit [2] = upload2[counter1+2];
                                    readBit [3] = upload2[counter1+3];
                                    
                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                    
                                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                    }
                                    
                                    if (xDimensionCount == imageDimension){
                                        xDimensionCount = 0;
                                        yDimensionCount++;
                                        
                                        if (yDimensionCount == imageDimension){
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        delete [] upload2;
                        
                        if (fluorescentMapStatus1 == 0){
                            fluorescentMap1 = new int *[imageDimension+1];
                            fluorescentMapStatus1 = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap1 [counter1] = new int [imageDimension+1];
                        }
                        
                        if (fluorescentMapStatus2 == 0){
                            fluorescentMap2 = new int *[imageDimension+1];
                            fluorescentMapStatus2 = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap2 [counter1] = new int [imageDimension+1];
                        }
                        
                        if (fluorescentMapStatus3 == 0){
                            fluorescentMap3 = new int *[imageDimension+1];
                            fluorescentMapStatus3 = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap3 [counter1] = new int [imageDimension+1];
                        }
                        
                        if (fluorescentMapStatus4 == 0){
                            fluorescentMap4 = new int *[imageDimension+1];
                            fluorescentMapStatus4 = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap4 [counter1] = new int [imageDimension+1];
                        }
                        
                        if (fluorescentMapStatus5 == 0){
                            fluorescentMap5 = new int *[imageDimension+1];
                            fluorescentMapStatus5 = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap5 [counter1] = new int [imageDimension+1];
                        }
                        
                        if (fluorescentMapStatus6 == 0){
                            fluorescentMap6 = new int *[imageDimension+1];
                            fluorescentMapStatus6 = 1;
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap6 [counter1] = new int [imageDimension+1];
                        }
                        
                        if (fluorescentEntryCount >= 1){
                            extension = to_string(fluorescentNo1);
                            
                            string fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName1+exType;
                            
                            if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTempA [0];
                                        dataConversion [1] = uploadTempA [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTempA [7];
                                            dataConversion [1] = uploadTempA [6];
                                            dataConversion [2] = uploadTempA [5];
                                            dataConversion [3] = uploadTempA [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTempA [4];
                                            dataConversion [1] = uploadTempA [5];
                                            dataConversion [2] = uploadTempA [6];
                                            dataConversion [3] = uploadTempA [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTempA [counter3];
                                                value1 = uploadTempA [counter3+1];
                                                value2 = uploadTempA [counter3+2];
                                                
                                                fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                                else if (exType == ".bmp"){
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 2){
                            extension = to_string(fluorescentNo2);
                            
                            string fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName2+exType;
                            
                            if (stat(fluorescentProcessPath2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTempA [0];
                                        dataConversion [1] = uploadTempA [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTempA [7];
                                            dataConversion [1] = uploadTempA [6];
                                            dataConversion [2] = uploadTempA [5];
                                            dataConversion [3] = uploadTempA [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTempA [4];
                                            dataConversion [1] = uploadTempA [5];
                                            dataConversion [2] = uploadTempA [6];
                                            dataConversion [3] = uploadTempA [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTempA [counter3];
                                                value1 = uploadTempA [counter3+1];
                                                value2 = uploadTempA [counter3+2];
                                                
                                                fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                                else if (exType == ".bmp"){
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 3){
                            extension = to_string(fluorescentNo3);
                            
                            string fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName3+exType;
                            
                            if (stat(fluorescentProcessPath3.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTempA [0];
                                        dataConversion [1] = uploadTempA [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTempA [7];
                                            dataConversion [1] = uploadTempA [6];
                                            dataConversion [2] = uploadTempA [5];
                                            dataConversion [3] = uploadTempA [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTempA [4];
                                            dataConversion [1] = uploadTempA [5];
                                            dataConversion [2] = uploadTempA [6];
                                            dataConversion [3] = uploadTempA [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTempA [counter3];
                                                value1 = uploadTempA [counter3+1];
                                                value2 = uploadTempA [counter3+2];
                                                
                                                fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                                else if (exType == ".bmp"){
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 4){
                            extension = to_string(fluorescentNo4);
                            
                            string fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName4+exType;
                            
                            if (stat(fluorescentProcessPath4.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTempA [0];
                                        dataConversion [1] = uploadTempA [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTempA [7];
                                            dataConversion [1] = uploadTempA [6];
                                            dataConversion [2] = uploadTempA [5];
                                            dataConversion [3] = uploadTempA [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTempA [4];
                                            dataConversion [1] = uploadTempA [5];
                                            dataConversion [2] = uploadTempA [6];
                                            dataConversion [3] = uploadTempA [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTempA [counter3];
                                                value1 = uploadTempA [counter3+1];
                                                value2 = uploadTempA [counter3+2];
                                                
                                                fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                                else if (exType == ".bmp"){
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 5){
                            extension = to_string(fluorescentNo5);
                            
                            string fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName5+exType;
                            
                            if (stat(fluorescentProcessPath5.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTempA [0];
                                        dataConversion [1] = uploadTempA [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTempA [7];
                                            dataConversion [1] = uploadTempA [6];
                                            dataConversion [2] = uploadTempA [5];
                                            dataConversion [3] = uploadTempA [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTempA [4];
                                            dataConversion [1] = uploadTempA [5];
                                            dataConversion [2] = uploadTempA [6];
                                            dataConversion [3] = uploadTempA [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTempA [counter3];
                                                value1 = uploadTempA [counter3+1];
                                                value2 = uploadTempA [counter3+2];
                                                
                                                fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                                else if (exType == ".bmp"){
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                        }
                        
                        if (fluorescentEntryCount >= 6){
                            extension = to_string(fluorescentNo6);
                            
                            string fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName6+exType;
                            
                            if (stat(fluorescentProcessPath6.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTempA [0];
                                        dataConversion [1] = uploadTempA [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTempA [7];
                                            dataConversion [1] = uploadTempA [6];
                                            dataConversion [2] = uploadTempA [5];
                                            dataConversion [3] = uploadTempA [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTempA [4];
                                            dataConversion [1] = uploadTempA [5];
                                            dataConversion [2] = uploadTempA [6];
                                            dataConversion [3] = uploadTempA [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTempA [counter3];
                                                value1 = uploadTempA [counter3+1];
                                                value2 = uploadTempA [counter3+2];
                                                
                                                fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                                else if (exType == ".bmp"){
                                    uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                        }
                        
                        int returnResults2 = 0;
                        
                        if (autoExpand == 1){
                            expandLine = [[ExpandLine alloc] init];
                            returnResults2 = [expandLine lineExtendTrackType2:connectNoAdd];
                        }
                        
                        if (autoExpand == 0 || (autoExpand == 1 && returnResults2 == 1)){
                            int maxPointDimX = 0;
                            int maxPointDimY = 0;
                            int minPointDimX = 1000000;
                            int minPointDimY = 1000000;
                            
                            for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                                    
                                    if (maxPointDimX < arrayPositionRevise [counter1*7]) maxPointDimX = arrayPositionRevise [counter1*7]; //====PS
                                    if (minPointDimX > arrayPositionRevise [counter1*7]) minPointDimX = arrayPositionRevise [counter1*7];
                                    if (maxPointDimY < arrayPositionRevise [counter1*7+1]) maxPointDimY = arrayPositionRevise [counter1*7+1];
                                    if (minPointDimY > arrayPositionRevise [counter1*7+1]) minPointDimY = arrayPositionRevise [counter1*7+1];
                                }
                                else{
                                    
                                    break;
                                }
                            }
                            
                            if (fluorescentEntryCount >= 2){
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoAdd){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoAdd){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoAdd){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoAdd){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            int pixelValueTemp = 0;
                            int pixelAreaTemp = 0;
                            int pixelValueTemp2 = 0;
                            int pixelAreaTemp2 = 0;
                            int pixelValueTemp3 = 0;
                            int pixelAreaTemp3 = 0;
                            int pixelValueTemp4 = 0;
                            int pixelAreaTemp4 = 0;
                            int pixelValueTemp5 = 0;
                            int pixelAreaTemp5 = 0;
                            int pixelValueTemp6 = 0;
                            int pixelAreaTemp6 = 0;
                            
                            for (int counterY = minPointDimY; counterY <= maxPointDimY; counterY++){
                                for (int counterX = minPointDimX; counterX <= maxPointDimX; counterX++){
                                    if (revisedWorkingMap [counterY][counterX] == connectNoAdd){
                                        if (fluorescentEntryCount >= 1){
                                            if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY][counterX];
                                            pixelAreaTemp++;
                                        }
                                        if (fluorescentEntryCount >= 2){
                                            if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterY][counterX];
                                            pixelAreaTemp2++;
                                        }
                                        if (fluorescentEntryCount >= 3){
                                            if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterY][counterX];
                                            pixelAreaTemp3++;
                                        }
                                        if (fluorescentEntryCount >= 4){
                                            if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) pixelValueTemp4 = pixelValueTemp4+fluorescentMap4 [counterY][counterX];
                                            pixelAreaTemp4++;
                                        }
                                        if (fluorescentEntryCount >= 5){
                                            if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) pixelValueTemp5 = pixelValueTemp5+fluorescentMap5 [counterY][counterX];
                                            pixelAreaTemp5++;
                                        }
                                        if (fluorescentEntryCount >= 6){
                                            if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) pixelValueTemp6 = pixelValueTemp6+fluorescentMap6 [counterY][counterX];
                                            pixelAreaTemp6++;
                                        }
                                    }
                                }
                            }
                            
                            double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                            
                            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate expandFluorescentDataUpDate];
                            }
                            
                            expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                            
                            if (fluorescentEntryCount >= 2){
                                averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
                            }
                        }
                        
                        string fluorescentExpandPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                        
                        if (expandFluorescentOutlineCount != 0){
                            indexCount = 0;
                            writingArray = new char [expandFluorescentOutlineCount*2+200];
                            
                            for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                                dataTemp = expandFluorescentOutline [counter1*4];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = expandFluorescentOutline [counter1*4+1];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = expandFluorescentOutline [counter1*4+2];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                writingArray [indexCount] = (char)expandFluorescentOutline [counter1*4+3], indexCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile8 (fluorescentExpandPath.c_str(), ofstream::binary);
                            outfile8.write ((char*)writingArray, indexCount);
                            outfile8.close();
                            
                            delete [] writingArray;
                        }
                        
                        string fluorescentExpandPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                        
                        if (expandFluorescentDataCount != 0){
                            indexCount = 0;
                            
                            writingArray = new char [expandFluorescentDataCount*2+20];
                            
                            for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                                dataTemp = expandFluorescentData [counter1*4];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                writingArray [indexCount] = (char)expandFluorescentData [counter1*4+1], indexCount++;
                                writingArray [indexCount] = (char)expandFluorescentData [counter1*4+2], indexCount++;
                                
                                dataTemp = expandFluorescentData [counter1*4+3];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                            }
                            
                            for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile8 (fluorescentExpandPath2.c_str(), ofstream::binary);
                            outfile8.write ((char*)writingArray, indexCount);
                            outfile8.close();
                            
                            delete [] writingArray;
                        }
                        
                        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                            delete [] revisedWorkingMap [counter1];
                            delete [] fluorescentMap1 [counter1];
                            delete [] fluorescentMap2 [counter1];
                            delete [] fluorescentMap3 [counter1];
                            delete [] fluorescentMap4 [counter1];
                            delete [] fluorescentMap5 [counter1];
                            delete [] fluorescentMap6 [counter1];
                            delete [] sourceImage [counter1];
                        }
                        
                        delete [] revisedWorkingMap;
                        delete [] fluorescentMap1;
                        delete [] fluorescentMap2;
                        delete [] fluorescentMap3;
                        delete [] fluorescentMap4;
                        delete [] fluorescentMap5;
                        delete [] fluorescentMap6;
                        delete [] sourceImage;
                        
                        revisedWorkingMapStatus = 0;
                        sourceImageStatus = 0;
                        
                        delete [] arrayPositionRevise;
                        delete [] arrayTimeSelected;
                        
                        fluorescentMapStatus1 = 0;
                        fluorescentMapStatus2 = 0;
                        fluorescentMapStatus3 = 0;
                        fluorescentMapStatus4 = 0;
                        fluorescentMapStatus5 = 0;
                        fluorescentMapStatus6 = 0;
                        
                        positionReviseCount = 0;
                        timeSelectedCount = 0;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Data Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            
            if (dataLoadingErrorStatus == 0){
                cellLineageNoHold = cellLineageString;
                cellNoHold = "C000000000";
                
                revisedWorkingMapTime2 = 0;
                
                addDelInsert = 1;
                returnResults = 1;
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        if (uploadTempLoading == 1) delete [] uploadTemp;
        if (uploadTempALoading == 1) delete [] uploadTempA;
        if (uploadTempBLoading == 1) delete [] uploadTempB;
        
        delete [] relDataTemp;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Connect No. Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return returnResults;
}

-(int)delLineageMain:(int)connectNoDel :(int)processType :(int)delCellNo :(int)startPointSet{
    //cout<<connectNoDel<<" "<<processType<<" "<<delCellNo<<" "<<startPointSet<<" entry"<<endl;
    
    //-----Type 3: cut time point including "startPointSet"-----
    int returnResults = 0;
    int lineageSaveFlag = 0;
    int counterMain = 1;
    int warningSkip = 0;
    
    if (processType == 5){
        counterMain = delCellNo;
        lineageSaveFlag = 1;
        processType = 1;
        warningSkip = 1;
    }
    
    string imagePositionString;
    string connectDataPath;
    string connectStatusDataPath;
    string connectRelationPath;
    string connectDataLineagePath;
    string mitosisStatusPath;
    string connectStartEndPath;
    string connectDataInfoPath;
    string queueListPath;
    string doneListPath;
    string lineageFolderPath;
    string cellFolderPath;
    string cellFolderPath2;
    string cellFusionPartnerPath;
    string fusionLineageString;
    string fusionCellNoString;
    string extension;
    string delLineage;
    string lineageNoGet;
    string cellNoGet;
    string imageNoGet;
    string setTypeGet;
    string cellLineageString;
    string cellNumberString;
    string imageCheckTime;
    string entry;
    string entry2;
    string treatmentNameGet;
    string partnerLingNoGet;
    string partnerCellNoGet;
    string lingNoTemp;
    string cellNoTemp;
    string imageNoTemp;
    string dataString;
    
    int lineageCheck = 0;
    int underProcessing = 0;
    int fusionPositionInfoCount = 0;
    int relativeToStart = 0;
    int lineageExtractionFusionTempCount = 0;
    int connectNoGet = 0;
    int imagePositionData = 0;
    int modifyDataTempCount = 0;
    int dataTemp = 0;
    int stepCount = 0;
    int modifyStartFlag = 0;
    int pointNoCount = 0;
    int mitosisTempCount = 0;
    int terminationFlag = 0;
    int mitosisSetFind = 0;
    int lineageFirstPoint = 0;
    int lineageLastPoint = 0;
    int mitosisTempCount4 = 0;
    int lineageEntryExtractionCount = 0;
    int lineageDataTempCount = 0;
    int expandTempCount = 0;
    int expandTempCount2 = 0;
    int expandDataTempCount = 0;
    int expandDataTempCount2 = 0;
    int expandTempCount3 = 0;
    int expandDataTempCount3 = 0;
    int cellNumberStart = 0;
    int lineageNumberStart = 0;
    int firstEntryFind = 0;
    int totalEntryCount = 0;
    int modifyDataStringTempCount = 0;
    int findInListFlag = 0;
    int markerStatus = 0;
    int startTime = 0;
    int endStatus = 0;
    int endTime = 0;
    int cellInfoProcessTempCount = 0;
    int fusionRemainingMark = 0;
    int cellInfoTempCount = 0;
    int lineagePartnerInfoTempCount = 0;
    int lineagePartnerInfoTempCount2 = 0;
    int mitosisTempCount2 = 0;
    int mitosisTempCount3 = 0;
    int prevFirstPoint = 0;
    int prevLastPoint = 0;
    int prevFind = 0;
    int prevCount = 0;
    int lastZeroEntry = 0;
    int finData [19];
    int readBit [4];
    int finData2 [10];
    int checkFlag = 0;
    int readingError = 0;
    int fusionProcessError = 0;
    int mainDeletionError = 0;
    unsigned long readPosition = 0;
    unsigned long indexCount = 0;
    
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    
    struct stat sizeOfFile;
    
    ifstream fin;
    
    for (int counter1 = 0; counter1 < counterMain; counter1++){
        if (lineageSaveFlag == 1) connectNoDel = lineageProcessList [counter1]*-1;
        
        lineageCheck = 0;
        
        for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
            if (arrayLineageData [counter2*8+6] == connectNoDel){
                lineageCheck = 1;
                break;
            }
        }
        
        if (lineageCheck == 1){
            if (connectNoDel > 0 && lineageDataCount > 1){
                delLineage = to_string(connectNoDel);
                
                if (delLineage.length() == 1) delLineage = "L0000"+delLineage;
                else if (delLineage.length() == 2) delLineage = "L000"+delLineage;
                else if (delLineage.length() == 3) delLineage = "L00"+delLineage;
                else if (delLineage.length() == 4) delLineage = "L0"+delLineage;
                else if (delLineage.length() == 5) delLineage = "L"+delLineage;
                
                //-----Check whether lineage contains "PROC"-----
                underProcessing = 0;
                
                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                    if (arrayQueueList [counter2*6+1] == delLineage && arrayQueueList [counter2*6+4] == "Proc"){
                        underProcessing = 1;
                        break;
                    }
                }
                
                //-----Process Start-----
                if (underProcessing == 0){
                    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                    //	cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                    //    cout<<" arrayLineageStartEnd "<<counterA<<endl;
                    //}
                    
                    int *fusionPositionInfo = new int [imageEndHold/2+100];
                    fusionPositionInfoCount = 0;
                    
                    //-----Get fusion lineage info-----
                    //==========Check counterpart fusion cell lineage: 1. Lineage no, 2. Cell no, 3. Fusion type, 4. self cell no, 5 start image no==========
                    
                    for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                        if (processType == 1){
                            if (arrayLineageStartEnd [counter2*8] == connectNoDel){
                                for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                    if (arrayLineageData [counter3*8+3] == 91){
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+7], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+4], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = 92, fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+5], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageStartEnd [counter2*8+5], fusionPositionInfoCount++;
                                    }
                                    if (arrayLineageData [counter3*8+3] == 92){
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+7], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+4], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = 91, fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+5], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageStartEnd [counter2*8+5], fusionPositionInfoCount++;
                                    }
                                }
                            }
                        }
                        
                        if (processType == 2){
                            if (arrayLineageStartEnd [counter2*8] == connectNoDel && arrayLineageStartEnd [counter2*8+1] == delCellNo){
                                for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                    if (arrayLineageData [counter3*8+3] == 91){
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+7], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+4], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = 92, fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+5], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageStartEnd [counter2*8+5], fusionPositionInfoCount++;
                                    }
                                    if (arrayLineageData [counter3*8+3] == 92){
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+7], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+4], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = 91, fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+5], fusionPositionInfoCount++;
                                        fusionPositionInfo [fusionPositionInfoCount] = arrayLineageStartEnd [counter2*8+5], fusionPositionInfoCount++;
                                    }
                                }
                            }
                        }
                        
                        if (processType == 3){
                            if (arrayLineageStartEnd [counter2*8] == connectNoDel && arrayLineageStartEnd [counter2*8+1] == delCellNo){
                                if (startPointSet >= arrayLineageStartEnd [counter2*8+5] && startPointSet <= arrayLineageStartEnd [counter2*8+7]){
                                    relativeToStart = 0;
                                    
                                    for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                        if (arrayLineageStartEnd [counter2*8+5]+relativeToStart >= startPointSet){
                                            if (arrayLineageData [counter3*8+3] == 91){
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+7], fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+4], fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = 92, fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+5], fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageStartEnd [counter2*8+5], fusionPositionInfoCount++;
                                            }
                                            if (arrayLineageData [counter3*8+3] == 92){
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+7], fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+4], fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = 91, fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageData [counter3*8+5], fusionPositionInfoCount++;
                                                fusionPositionInfo [fusionPositionInfoCount] = arrayLineageStartEnd [counter2*8+5], fusionPositionInfoCount++;
                                            }
                                        }
                                        
                                        relativeToStart++;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fusionPositionInfoCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<fusionPositionInfo [counterA*5+counterB];
                    //    cout<<" fusionPositionInfo "<<counterA<<endl;
                    //}
                    
                    //-----Lineage update for fusion-----
                    fusionProcessError = 0;
                    
                    if (fusionPositionInfoCount != 0){ //-----For fusion-----
                        for (int counter2 = 0; counter2 < fusionPositionInfoCount/5; counter2++){
                            if (fusionPositionInfo [counter2*5+2] == 92){
                                for (int counter3 = 0; counter3 < lineageStartEndCount/8; counter3++){
                                    if (arrayLineageStartEnd [counter3*8] == fusionPositionInfo [counter2*5] && arrayLineageStartEnd [counter3*8+1] == fusionPositionInfo [counter2*5+1]){
                                        for (int counter4 = arrayLineageStartEnd [counter3*8+4]; counter4 <= arrayLineageStartEnd [counter3*8+6]; counter4++){
                                            if (arrayLineageData [counter4*8+4] == fusionPositionInfo [counter2*5+3] && arrayLineageData [counter4*8+7] == connectNoDel && arrayLineageData [counter4*8+3] == 92){
                                                arrayLineageData [counter4*8+3] = 2;
                                                arrayLineageData [counter4*8+4] = 0;
                                                arrayLineageData [counter4*8+7] = 0;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (fusionPositionInfo [counter2*5+2] == 91){
                                for (int counter3 = 0; counter3 < lineageStartEndCount/8; counter3++){
                                    fusionProcessError = 0;
                                    
                                    if (arrayLineageStartEnd [counter3*8] == fusionPositionInfo [counter2*5] && arrayLineageStartEnd [counter3*8+1] == fusionPositionInfo [counter2*5+1]){
                                        
                                        int *cellDataExtraction = new int [(arrayLineageStartEnd [counter3*8+6]-arrayLineageStartEnd [counter3*8+4])*8+100], cellDataExtractionCount = 0;
                                        
                                        for (int counter4 = arrayLineageStartEnd [counter3*8+4]; counter4 <= arrayLineageStartEnd [counter3*8+6]; counter4++){
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+1], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+2], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+3], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+4], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+5], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+6], cellDataExtractionCount++;
                                            cellDataExtraction [cellDataExtractionCount] = arrayLineageData [counter4*8+7], cellDataExtractionCount++;
                                        }
                                        
                                        //for (int counterA = 0; counterA < cellDataExtractionCount/8; counterA++){
                                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellDataExtraction [counterA*8+counterB];
                                        //    cout<<" cellDataExtraction "<<counterA<<endl;
                                        //}
                                        
                                        if (cellDataExtraction [cellDataExtractionCount-13] != 31 && cellDataExtraction [cellDataExtractionCount-13] != 41 && cellDataExtraction [cellDataExtractionCount-13] != 51 && cellDataExtraction [cellDataExtractionCount-13] != 1) cellDataExtraction [cellDataExtractionCount-5] = 2;
                                        
                                        cellDataExtraction [cellDataExtractionCount-12] = 0;
                                        cellDataExtraction [cellDataExtractionCount-9] = 0;
                                        
                                        int *lineageExtractionFusionTemp = new int [lineageDataCount+50];
                                        lineageExtractionFusionTempCount = 0;
                                        
                                        for (int counter4 = 0; counter4 < lineageDataCount/8; counter4++){
                                            if (arrayLineageData [counter4*8+6] != fusionPositionInfo [counter2*5] || arrayLineageData [counter4*8+5] != fusionPositionInfo [counter2*5+1]){
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8], lineageExtractionFusionTempCount++; //-----X Position-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+1], lineageExtractionFusionTempCount++; //-----Y Position-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+2], lineageExtractionFusionTempCount++; //-----Time point-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+3], lineageExtractionFusionTempCount++; //-----Event type-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+4], lineageExtractionFusionTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+5], lineageExtractionFusionTempCount++; //-----Cell Number-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+6], lineageExtractionFusionTempCount++; //-----Cell Lineage Number-----
                                                lineageExtractionFusionTemp [lineageExtractionFusionTempCount] = arrayLineageData [counter4*8+7], lineageExtractionFusionTempCount++; //-----For Fusion, Cell lineage Number-----
                                            }
                                        }
                                        
                                        imagePositionData = cellDataExtraction [(cellDataExtractionCount/8-1)*8+2];
                                        
                                        if (lineageDataStatus == 1) delete [] arrayLineageData;
                                        arrayLineageData = new int [lineageDataCount+50];
                                        lineageDataCount = 0;
                                        lineageDataLimit = lineageDataCount+50;
                                        lineageDataStatus = 1;
                                        
                                        //for (int counterA = 0; counterA < cellDataExtractionCount/8; counterA++){
                                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellDataExtraction [counterA*8+counterB];
                                        //	cout<<" cellDataExtraction "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < lineageExtractionFusionTempCount/8; counterA++){
                                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionFusionTemp [counterA*8+counterB];
                                        //	cout<<" lineageExtractionFusionTemp "<<counterA<<endl;
                                        //}
                                        
                                        for (int counter4 = 0; counter4 < lineageExtractionFusionTempCount; counter4++) arrayLineageData [lineageDataCount] = lineageExtractionFusionTemp [counter4], lineageDataCount++;
                                        
                                        for (int counter4 = 0; counter4 < cellDataExtractionCount/8-1; counter4++){
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+1], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+2], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+3], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+4], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+5], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+6], lineageDataCount++;
                                            arrayLineageData [lineageDataCount] = cellDataExtraction [counter4*8+7], lineageDataCount++;
                                        }
                                        
                                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                                        //	cout<<" arrayLineageData "<<counterA<<endl;
                                        //}
                                        
                                        delete [] cellDataExtraction;
                                        delete [] lineageExtractionFusionTemp;
                                        
                                        imagePositionString = to_string(imagePositionData);
                                        
                                        if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                                        else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                                        else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                                        
                                        connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter4 = 0; counter4 < 6; counter4++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter4 == 0) size1 = sizeForCopy;
                                                else if (counter4 == 1) size2 = sizeForCopy;
                                                else if (counter4 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter4 == 3) size1 = sizeForCopy;
                                                else if (counter4 == 4) size2 = sizeForCopy;
                                                else if (counter4 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        connectNoGet = 0;
                                        readingError = 0;
                                        
                                        //-----Master Data upLoad-----
                                        if (checkFlag == 1){
                                            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                    usleep(50000);
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    
                                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                        readingError = 1;
                                                    }
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (readingError == 0){
                                                readPosition = 0;
                                                stepCount = 0;
                                                modifyStartFlag = -1;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        readPosition = readPosition+5;
                                                        
                                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                        
                                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                        
                                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                        
                                                        if (finData [7] == 0 && finData [16] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            if (finData [16] == fusionPositionInfo [counter2*5] && finData [12] == fusionPositionInfo [counter2*5+1] && modifyStartFlag == -1){
                                                                modifyStartFlag = finData [16];
                                                                connectNoGet = finData [7];
                                                                
                                                                uploadTemp [readPosition-1] = 0;
                                                                uploadTemp [readPosition-2] = 0;
                                                                uploadTemp [readPosition-3] = 0;
                                                                uploadTemp [readPosition-4] = 0;
                                                                uploadTemp [readPosition-5] = 0;
                                                                uploadTemp [readPosition-6] = 0;
                                                                uploadTemp [readPosition-7] = 0;
                                                                uploadTemp [readPosition-8] = 0;
                                                                uploadTemp [readPosition-9] = 0;
                                                            }
                                                            else if (finData [12] == fusionPositionInfo [counter2*5] && modifyStartFlag == finData [16]){
                                                                uploadTemp [readPosition-1] = 0;
                                                                uploadTemp [readPosition-2] = 0;
                                                                uploadTemp [readPosition-3] = 0;
                                                                uploadTemp [readPosition-4] = 0;
                                                                uploadTemp [readPosition-5] = 0;
                                                                uploadTemp [readPosition-6] = 0;
                                                                uploadTemp [readPosition-7] = 0;
                                                                uploadTemp [readPosition-8] = 0;
                                                                uploadTemp [readPosition-9] = 0;
                                                            }
                                                            else if (modifyStartFlag != -1 && modifyStartFlag != finData [16]){
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                ofstream outfile2 (connectDataPath.c_str(), ofstream::binary);
                                                outfile2.write ((char*)uploadTemp, sizeForCopy);
                                                outfile2.close();
                                            }
                                            
                                            delete [] uploadTemp;
                                            
                                            //for (int counterA = 0; counterA < modifyDataTempCount4/7; counterA++){
                                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<modifyDataTemp4 [counterA*7+counterB];
                                            //	cout<<" modifyDataTemp4 "<<counterA<<endl;
                                            //}
                                            
                                            //for (int counterA = 0; counterA < modifyDataTempCount2/6; counterA++){
                                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<modifyDataTemp2 [counterA*6+counterB];
                                            //	cout<<" modifyDataTemp2 "<<counterA<<endl;
                                            //}
                                        }
                                        
                                        if (checkFlag == 0 || readingError == 1) fusionProcessError = 1;
                                        
                                        connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        readingError = 0;
                                        
                                        //-----Master Data upLoad-----
                                        if (sizeForCopy != 0){
                                            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                                                    readingError = 1;
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (readingError == 0){
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        readPosition = readPosition+13;
                                                        
                                                        finData [13] = uploadTemp [readPosition], readPosition++;
                                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                                        finData [15] = uploadTemp [readPosition], readPosition++; //--9 Connect no
                                                        finData [16] = uploadTemp [readPosition], readPosition++;
                                                        finData [17] = uploadTemp [readPosition], readPosition++;
                                                        finData [18] = uploadTemp [readPosition], readPosition++; //--10 Lineage no
                                                        
                                                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                                        
                                                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            if (finData [18] == fusionPositionInfo [counter2*5] && finData [15] == connectNoGet){
                                                                uploadTemp [readPosition-19] = 0;
                                                                uploadTemp [readPosition-1] = 0;
                                                                uploadTemp [readPosition-2] = 0;
                                                                uploadTemp [readPosition-3] = 0;
                                                            }
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                ofstream outfile3 (connectStatusDataPath.c_str(), ofstream::binary);
                                                outfile3.write ((char*)uploadTemp, sizeForCopy);
                                                outfile3.close();
                                            }
                                            
                                            delete [] uploadTemp;
                                        }
                                        
                                        if (readingError == 1) fusionProcessError = 1;
                                        
                                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        //-----Master Data upLoad-----
                                        readingError = 0;
                                        
                                        if (sizeForCopy != 0){
                                            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                                    readingError = 1;
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (readingError == 0){
                                                int *modifyDataTemp = new int [sizeForCopy+50];
                                                modifyDataTempCount = 0;
                                                
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                                        finData [3] = uploadTemp [readPosition], readPosition++;
                                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                        
                                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                        finData [7] = finData [6]*256+finData [7];
                                                        
                                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                        else if (finData [2] != fusionPositionInfo [counter2*5] || finData [12] != fusionPositionInfo [counter2*5+1]){
                                                            modifyDataTemp [modifyDataTempCount] = finData [2], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [5], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [7], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [12], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [13], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [14], modifyDataTempCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                char *writingArray = new char [modifyDataTempCount/6*16+16];
                                                
                                                indexCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < modifyDataTempCount/6; counter4++){
                                                    dataTemp = modifyDataTemp [counter4*6];
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                    
                                                    dataTemp = modifyDataTemp [counter4*6+1];
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                    
                                                    dataTemp = modifyDataTemp [counter4*6+2];
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    if (modifyDataTemp [counter4*6+3] < 0){
                                                        writingArray [indexCount] = 1, indexCount++;
                                                        dataTemp = modifyDataTemp [counter4*6+3]*-1;
                                                    }
                                                    else{
                                                        
                                                        writingArray [indexCount] = 0, indexCount++;
                                                        dataTemp = modifyDataTemp [counter4*6+3];
                                                    }
                                                    
                                                    readBit [0] = dataTemp/16777216;
                                                    dataTemp = dataTemp%16777216;
                                                    readBit [1] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [2] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [3] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                                    
                                                    writingArray [indexCount] = (char)modifyDataTemp [counter4*6+4], indexCount++;
                                                    writingArray [indexCount] = (char)modifyDataTemp [counter4*6+5], indexCount++;
                                                }
                                                
                                                for (int counter4 = 0; counter4 < 15; counter4++) writingArray [indexCount] = 0, indexCount++;
                                                
                                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                                outfile3.write ((char*) writingArray, indexCount);
                                                outfile3.close();
                                                
                                                delete [] writingArray;
                                                delete [] modifyDataTemp;
                                            }
                                            
                                            delete [] uploadTemp;
                                        }
                                        
                                        if (readingError == 1) fusionProcessError = 1;
                                        
                                        //-----New end creation-----
                                        imagePositionString = to_string(imagePositionData-1);
                                        
                                        if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                                        else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                                        else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                                        
                                        connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter4 = 0; counter4 < 6; counter4++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter4 == 0) size1 = sizeForCopy;
                                                else if (counter4 == 1) size2 = sizeForCopy;
                                                else if (counter4 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter4 == 3) size1 = sizeForCopy;
                                                else if (counter4 == 4) size2 = sizeForCopy;
                                                else if (counter4 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //-----Master Data upLoad-----
                                        readingError = 0;
                                        
                                        if (checkFlag == 1){
                                            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                    usleep(50000);
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    
                                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                        readingError = 1;
                                                    }
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (readingError == 0){
                                                //-----LINE DATA AMEND-----
                                                //-----1. Image No, 2, X position, 3 Y position, 4. Value, 5. Connect No, 6. Lineage NO-----
                                                fusionLineageString = to_string(fusionPositionInfo [counter2*5]);
                                                
                                                if (fusionLineageString.length() == 1) fusionLineageString = "L0000"+fusionLineageString;
                                                else if (fusionLineageString.length() == 2) fusionLineageString = "L000"+fusionLineageString;
                                                else if (fusionLineageString.length() == 3) fusionLineageString = "L00"+fusionLineageString;
                                                else if (fusionLineageString.length() == 4) fusionLineageString = "L0"+fusionLineageString;
                                                else if (fusionLineageString.length() == 5) fusionLineageString = "L"+fusionLineageString;
                                                
                                                fusionCellNoString = to_string(fusionPositionInfo [counter2*5+1]);
                                                
                                                if (fusionPositionInfo [counter2*5+1] >= 0){
                                                    if (fusionCellNoString.length() == 1) fusionCellNoString = "C00000000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 2) fusionCellNoString = "C0000000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 3) fusionCellNoString = "C000000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 4) fusionCellNoString = "C00000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 5) fusionCellNoString = "C0000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 6) fusionCellNoString = "C000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 7) fusionCellNoString = "C00"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 8) fusionCellNoString = "C0"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 9) fusionCellNoString = "C"+fusionCellNoString;
                                                }
                                                else{
                                                    
                                                    fusionCellNoString = fusionCellNoString.substr(1);
                                                    
                                                    if (fusionCellNoString.length() == 1) fusionCellNoString = "C-00000000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 2) fusionCellNoString = "C-0000000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 3) fusionCellNoString = "C-000000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 4) fusionCellNoString = "C-00000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 5) fusionCellNoString = "C-0000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 6) fusionCellNoString = "C-000"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 7) fusionCellNoString = "C-00"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 8) fusionCellNoString = "C-0"+fusionCellNoString;
                                                    else if (fusionCellNoString.length() == 9) fusionCellNoString = "C-"+fusionCellNoString;
                                                }
                                                
                                                readPosition = 0;
                                                stepCount = 0;
                                                modifyStartFlag = -1;
                                                pointNoCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        readPosition = readPosition+5;
                                                        
                                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                        
                                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                        
                                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                        
                                                        if (finData [7] == 0 && finData [16] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            if (finData [16] == fusionPositionInfo [counter2*5] && finData [12] == fusionPositionInfo [counter2*5+1] && modifyStartFlag == -1){
                                                                modifyStartFlag = finData [16];
                                                                pointNoCount++;
                                                            }
                                                            else if (finData [16] == fusionPositionInfo [counter2*5] && finData [12] == fusionPositionInfo [counter2*5+1] && modifyStartFlag == finData [16]){
                                                                pointNoCount++;
                                                            }
                                                            else if (modifyStartFlag != -1 && modifyStartFlag != finData [16]){
                                                                break;
                                                            }
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                cellFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+fusionLineageString+"/"+fusionCellNoString+"/"+analysisID+"_"+fusionLineageString+"_lineDataAmend";
                                                
                                                indexCount = 0;
                                                stepCount = 0;
                                                readPosition = 0;
                                                modifyStartFlag = -1;
                                                lastZeroEntry = 0;
                                                
                                                char *writingArray = new char [pointNoCount*16+1];
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                                        
                                                        finData2 [0] = finData [5]*65536+finData [6]*256+finData [7];
                                                        
                                                        if (finData [8] == 1) finData2 [1] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                        else finData2 [1] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        finData2 [2] = finData [14]*65536+finData [15]*256+finData [16];
                                                        
                                                        if (finData2 [0] == 0){
                                                            stepCount = 3;
                                                            
                                                            if (lastZeroEntry == 0){
                                                                for (int counter4 = 0; counter4 < 13; counter4++) writingArray [indexCount] = 0, indexCount++;
                                                            }
                                                        }
                                                        else{
                                                            
                                                            if (finData2 [2] == fusionPositionInfo [counter2*5] && finData2 [1] == fusionPositionInfo [counter2*5+1] && modifyStartFlag == -1){
                                                                dataTemp = imagePositionData-1;
                                                                readBit [0] = dataTemp/256;
                                                                dataTemp = dataTemp%256;
                                                                readBit [1] = dataTemp;
                                                                
                                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [0], indexCount++;
                                                                writingArray [indexCount] = (char)finData [1], indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [2], indexCount++;
                                                                writingArray [indexCount] = (char)finData [3], indexCount++;
                                                                
                                                                writingArray [indexCount] = 1, indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [5], indexCount++;
                                                                writingArray [indexCount] = (char)finData [6], indexCount++;
                                                                writingArray [indexCount] = (char)finData [7], indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [14], indexCount++;
                                                                writingArray [indexCount] = (char)finData [15], indexCount++;
                                                                writingArray [indexCount] = (char)finData [16], indexCount++;
                                                                
                                                                modifyStartFlag = 1;
                                                            }
                                                            else if (finData2 [2] == fusionPositionInfo [counter2*5] && finData2 [1] == fusionPositionInfo [counter2*5+1] && modifyStartFlag == 1){
                                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [0], indexCount++;
                                                                writingArray [indexCount] = (char)finData [1], indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [2], indexCount++;
                                                                writingArray [indexCount] = (char)finData [3], indexCount++;
                                                                
                                                                writingArray [indexCount] = 1, indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [5], indexCount++;
                                                                writingArray [indexCount] = (char)finData [6], indexCount++;
                                                                writingArray [indexCount] = (char)finData [7], indexCount++;
                                                                
                                                                writingArray [indexCount] = (char)finData [14], indexCount++;
                                                                writingArray [indexCount] = (char)finData [15], indexCount++;
                                                                writingArray [indexCount] = (char)finData [16], indexCount++;
                                                            }
                                                            else if ((finData2 [2] != fusionPositionInfo [counter2*5] || finData2 [1] != fusionPositionInfo [counter2*5+1]) && modifyStartFlag == 1){
                                                                for (int counter4 = 0; counter4 < 13; counter4++) writingArray [indexCount] = 0, indexCount++;
                                                                
                                                                modifyStartFlag = 2;
                                                                lastZeroEntry = 1;
                                                            }
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                ofstream outfile3 (cellFolderPath.c_str(), ofstream::binary);
                                                outfile3.write ((char*)writingArray, indexCount);
                                                outfile3.close();
                                                
                                                delete [] writingArray;
                                            }
                                            
                                            delete [] uploadTemp;
                                        }
                                        
                                        //-----Mitosis status List-----
                                        mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_MitosisData";
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter4 = 0; counter4 < 6; counter4++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter4 == 0) size1 = sizeForCopy;
                                                else if (counter4 == 1) size2 = sizeForCopy;
                                                else if (counter4 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter4 == 3) size1 = sizeForCopy;
                                                else if (counter4 == 4) size2 = sizeForCopy;
                                                else if (counter4 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        int *arrayMitosisTemp = new int [sizeForCopy+50];
                                        mitosisTempCount = 0;
                                        
                                        if (checkFlag == 1){
                                            fin.open(mitosisStatusPath.c_str(), ios::in);
                                            
                                            if (fin.is_open()){
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    getline(fin, lineageNoGet);
                                                    
                                                    if (lineageNoGet == "") terminationFlag = 0;
                                                    else{
                                                        
                                                        getline(fin, cellNoGet);
                                                        getline(fin, imageNoGet);
                                                        getline(fin, setTypeGet);
                                                        
                                                        arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                                        arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                                        arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                                        arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                                    }
                                                    
                                                } while (terminationFlag == 1);
                                                
                                                fin.close();
                                            }
                                        }
                                        
                                        mitosisSetFind = 0;
                                        lineageFirstPoint = 0;
                                        lineageLastPoint = 0;
                                        
                                        for (int counter4 = 0; counter4 < lineageStartEndCount/8; counter4++){
                                            if (arrayLineageStartEnd [counter4*8] == fusionPositionInfo [counter2*5] && arrayLineageStartEnd [counter4*8+1] == fusionPositionInfo [counter2*5+1]){
                                                for (int counter5 = arrayLineageStartEnd [counter4*8+4]; counter5 <= arrayLineageStartEnd [counter4*8+6]; counter5++){
                                                    if (arrayLineageData [counter5*8+3] == 6) mitosisSetFind = arrayLineageData [counter5*8+2];
                                                    if (lineageLastPoint < arrayLineageData [counter5*8+2]) lineageLastPoint = arrayLineageData [counter5*8+2];
                                                    if (lineageFirstPoint == 0) lineageFirstPoint = arrayLineageData [counter5*8+2];
                                                }
                                            }
                                        }
                                        
                                        int *arrayMitosisTemp4 = new int [(lineageLastPoint-lineageFirstPoint+1)*4+50];
                                        mitosisTempCount4 = 0;
                                        
                                        for (int counter4 = lineageFirstPoint; counter4 <= lineageLastPoint; counter4++){
                                            arrayMitosisTemp4 [mitosisTempCount4] = fusionPositionInfo [counter2*5], mitosisTempCount4++;
                                            arrayMitosisTemp4 [mitosisTempCount4] = fusionPositionInfo [counter2*5+1], mitosisTempCount4++;
                                            arrayMitosisTemp4 [mitosisTempCount4] = counter4, mitosisTempCount4++;
                                            
                                            if (mitosisSetFind == counter4){
                                                arrayMitosisTemp4 [mitosisTempCount4] = 10, mitosisTempCount4++;
                                            }
                                            else arrayMitosisTemp4 [mitosisTempCount4] = 0, mitosisTempCount4++;
                                        }
                                        
                                        ofstream oin;
                                        oin.open(mitosisStatusPath.c_str(), ios::out);
                                        
                                        for (int counter4 = 0; counter4 < mitosisTempCount; counter4++) oin<<arrayMitosisTemp [counter4]<<endl;
                                        
                                        for (int counter4 = 0; counter4 < mitosisTempCount4; counter4++) oin<<arrayMitosisTemp4 [counter4]<<endl;
                                        
                                        oin.close();
                                        
                                        delete [] arrayMitosisTemp4;
                                        delete [] arrayMitosisTemp;
                                    }
                                    
                                    if (fusionProcessError == 1){
                                        break;
                                    }
                                }
                            }
                        }
                        
                        if (fusionProcessError == 0){
                            if (processType == 2 || processType == 3){
                                int *lineageDataTemp = new int [lineageDataCount+50];
                                lineageDataTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                    if (arrayLineageExtraction [counter2*8+5] != delCellNo){
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8], lineageDataTempCount++; //-----X Position-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+1], lineageDataTempCount++; //-----Y Position-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+2], lineageDataTempCount++; //-----Time point-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+3], lineageDataTempCount++;
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+5], lineageDataTempCount++; //-----Cell Number-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                    if (arrayLineageData [counter2*8+6] == connectNoDel && arrayLineageData [counter2*8+5] == delCellNo){
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8], lineageDataTempCount++; //-----X Position-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+1], lineageDataTempCount++; //-----Y Position-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+2], lineageDataTempCount++; //-----Time point-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+3], lineageDataTempCount++;
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+5], lineageDataTempCount++; //-----Cell Number-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                                        lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                                    }
                                }
                                
                                delete [] arrayLineageExtraction;
                                arrayLineageExtraction = new int [lineageDataTempCount+50];
                                lineageExtractionCount = 0;
                                
                                for (int counter2 = 0; counter2 < lineageDataTempCount; counter2++) arrayLineageExtraction [lineageExtractionCount] = lineageDataTemp [counter2], lineageExtractionCount++;
                                
                                delete [] lineageDataTemp;
                                
                                lineageStartEndCount = 0;
                                cellNumberStart = -1;
                                lineageNumberStart = 0;
                                firstEntryFind = 0;
                                
                                for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                    if ((arrayLineageData [counter2*8+6] != lineageNumberStart || arrayLineageData [counter2*8+5] != cellNumberStart) && firstEntryFind == 0){
                                        lineageNumberStart = arrayLineageData [counter2*8+6];
                                        cellNumberStart = arrayLineageData [counter2*8+5];
                                        
                                        arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+1], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+2], lineageStartEndCount++;
                                        
                                        firstEntryFind = 1;
                                    }
                                    else if ((arrayLineageData [counter2*8+6] != lineageNumberStart || arrayLineageData [counter2*8+5] != cellNumberStart) && firstEntryFind == 1){
                                        lineageNumberStart = arrayLineageData [counter2*8+6];
                                        cellNumberStart = arrayLineageData [counter2*8+5];
                                        
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2-1, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter2-1)*8+2], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+1], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+2], lineageStartEndCount++;
                                    }
                                    
                                    if (counter2 == lineageDataCount/8-1){
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+2], lineageStartEndCount++;
                                    }
                                    
                                    if (lineageStartEndCount+24 > lineageStartEndLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate lineageStartEndUpDate];
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                    //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
                    //}
                    
                    //-----Remove connectDel or cellDel from lineage-----
                    
                    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8 +counterB];
                    //	cout<<" arrayLineageData "<<counterA<<endl;
                    //}
                    
                    mainDeletionError = 0;
                    
                    if (fusionProcessError == 0){
                        if (fusionPositionInfoCount != 0 && (processType == 2 || processType == 3)){
                            lineageExtractionCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                                if (arrayLineageStartEnd [counter2*8] == connectNoDel){
                                    for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+1], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+2], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+3], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+4], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+5], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+6], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter3*8+7], lineageExtractionCount++;
                                    }
                                }
                            }
                        }
                        
                        int *lineageEntryExtraction = new int [lineageDataCount+50];
                        lineageEntryExtractionCount = 0;
                        
                        if (processType == 1){
                            int *lineageDataTemp = new int [lineageDataCount+50];
                            lineageDataTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                if (arrayLineageData [counter2*8+6] != connectNoDel){
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8], lineageDataTempCount++; //-----X Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+1], lineageDataTempCount++; //-----Y Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+2], lineageDataTempCount++; //-----Time point-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+3], lineageDataTempCount++;
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+5], lineageDataTempCount++; //-----Cell Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageData [counter2*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                                }
                                else{
                                    
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8], lineageEntryExtractionCount++; //-----X Position-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+1], lineageEntryExtractionCount++; //-----Y Position-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+2], lineageEntryExtractionCount++; //-----Time point-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+3], lineageEntryExtractionCount++;
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+4], lineageEntryExtractionCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+5], lineageEntryExtractionCount++; //-----Cell Number-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+6], lineageEntryExtractionCount++; //-----Cell Lineage Number-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageData [counter2*8+7], lineageEntryExtractionCount++; //-----For Fusion, Cell lineage Number-----
                                }
                            }
                            
                            if (lineageDataStatus == 1) delete [] arrayLineageData;
                            arrayLineageData = new int [lineageDataTempCount+50];
                            lineageDataCount = 0;
                            lineageDataLimit = lineageDataTempCount+50;
                            lineageDataStatus = 1;
                            
                            for (int counter2 = 0; counter2 < lineageDataTempCount; counter2++) arrayLineageData [lineageDataCount] = lineageDataTemp [counter2], lineageDataCount++;
                            
                            delete [] lineageDataTemp;
                        }
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8 +counterB];
                        //    cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8 +counterB];
                        //	cout<<" arrayLineageExtraction "<<counterA<<endl;
                        //}
                        
                        if (processType == 2){
                            int *lineageDataTemp = new int [lineageDataCount+50];
                            lineageDataTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                if (arrayLineageExtraction [counter2*8+5] != delCellNo){
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8], lineageDataTempCount++; //-----X Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+1], lineageDataTempCount++; //-----Y Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+2], lineageDataTempCount++; //-----Time point-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+3], lineageDataTempCount++;
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+5], lineageDataTempCount++; //-----Cell Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                                }
                                else{
                                    
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8], lineageEntryExtractionCount++; //-----X Position-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+1], lineageEntryExtractionCount++; //-----Y Position-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+2], lineageEntryExtractionCount++; //-----Time point-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+3], lineageEntryExtractionCount++;
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+4], lineageEntryExtractionCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+5], lineageEntryExtractionCount++; //-----Cell Number-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+6], lineageEntryExtractionCount++; //-----Cell Lineage Number-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+7], lineageEntryExtractionCount++; //-----For Fusion, Cell lineage Number-----
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageDataTempCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageDataTemp [counterA*8 +counterB];
                            //    cout<<" lineageDataTemp "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
                            //    cout<<" lineageEntryExtraction "<<counterA<<endl;
                            //}
                            
                            delete [] arrayLineageExtraction;
                            arrayLineageExtraction = new int [lineageDataTempCount+50];
                            lineageExtractionCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageDataTempCount; counter2++) arrayLineageExtraction [lineageExtractionCount] = lineageDataTemp [counter2], lineageExtractionCount++;
                            
                            delete [] lineageDataTemp;
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8 +counterB];
                        //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                        //}
                        
                        if (processType == 3){
                            int *lineageDataTemp = new int [lineageDataCount+50];
                            lineageDataTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                if (arrayLineageExtraction [counter2*8+5] != delCellNo){
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8], lineageDataTempCount++; //-----X Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+1], lineageDataTempCount++; //-----Y Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+2], lineageDataTempCount++; //-----Time point-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+3], lineageDataTempCount++;
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+5], lineageDataTempCount++; //-----Cell Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                                }
                                else if (arrayLineageExtraction [counter2*8+5] == delCellNo && arrayLineageExtraction [counter2*8+2] < startPointSet){
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8], lineageDataTempCount++; //-----X Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+1], lineageDataTempCount++; //-----Y Position-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+2], lineageDataTempCount++; //-----Time point-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+3], lineageDataTempCount++;
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+5], lineageDataTempCount++; //-----Cell Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                                    lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter2*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                                }
                                else{
                                    
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8], lineageEntryExtractionCount++; //-----X Position-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+1], lineageEntryExtractionCount++; //-----Y Position-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+2], lineageEntryExtractionCount++; //-----Time point-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+3], lineageEntryExtractionCount++;
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+4], lineageEntryExtractionCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+5], lineageEntryExtractionCount++; //-----Cell Number-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+6], lineageEntryExtractionCount++; //-----Cell Lineage Number-----
                                    lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter2*8+7], lineageEntryExtractionCount++; //-----For Fusion, Cell lineage Number-----
                                }
                            }
                            
                            // for (int counterA = 0; counterA < lineageDataTempCount/8; counterA++){
                            //     for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageDataTemp [counterA*8+counterB];
                            //     cout<<" lineageDataTemp "<<counterA<<endl;
                            // }
                            
                            delete [] arrayLineageExtraction;
                            arrayLineageExtraction = new int [lineageDataTempCount+50];
                            lineageExtractionCount = 0;
                            
                            for (int counter2 = 0; counter2 < lineageDataTempCount; counter2++) arrayLineageExtraction [lineageExtractionCount] = lineageDataTemp [counter2], lineageExtractionCount++;
                            
                            //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                            //    cout<<" arrayLineageExtraction "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageDataTempCount/8; counterA++){
                            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageDataTemp [counterA*8 +counterB];
                            //	cout<<" lineageDataTemp "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
                            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
                            //	cout<<" lineageEntryExtraction "<<counterA<<endl;
                            //}
                            
                            delete [] lineageDataTemp;
                        }
                        
                        if (processType == 1){
                            connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
                            
                            char *writingArray = new char [lineageDataCount/8*25+25];
                            
                            indexCount = 0;
                            lineageWritingCheck = 1;
                            
                            for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                if (arrayLineageData [counter2*8] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8];
                                }
                                
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                if (arrayLineageData [counter2*8+1] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8+1]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8+1];
                                }
                                
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = arrayLineageData [counter2*8+2];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                writingArray [indexCount] = (char)arrayLineageData [counter2*8+3], indexCount++;
                                
                                if (arrayLineageData [counter2*8+4] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8+4]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8+4];
                                }
                                
                                readBit [0] = dataTemp/16777216;
                                dataTemp = dataTemp%16777216;
                                readBit [1] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [2] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [3] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                
                                if (arrayLineageData [counter2*8+5] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8+5]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = arrayLineageData [counter2*8+5];
                                }
                                
                                readBit [0] = dataTemp/16777216;
                                dataTemp = dataTemp%16777216;
                                readBit [1] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [2] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [3] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                
                                dataTemp = arrayLineageData [counter2*8+6];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = arrayLineageData [counter2*8+7];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                            }
                            
                            for (int counter2 = 0; counter2 < 25; counter2++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile (connectDataLineagePath.c_str(), ofstream::binary);
                            outfile.write ((char*) writingArray, indexCount);
                            outfile.close();
                            
                            delete [] writingArray;
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                fin.open(connectDataLineagePath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    lineageWritingCheck = 0;
                                    terminationFlag = 0;
                                }
                                
                            } while (terminationFlag == 1);
                        }
                        
                        //-----Duplicated image number point remove-----
                        if (processType == 1){
                            for (int counter2 = 0; counter2 < lineageEntryExtractionCount/8-1; counter2++){
                                if (lineageEntryExtraction [counter2*8+2] != 0){
                                    for (int counter3 = counter2+1; counter3 < lineageEntryExtractionCount/8; counter3++){
                                        if (lineageEntryExtraction [counter3*8+2] == lineageEntryExtraction [counter2*8+2]) lineageEntryExtraction [counter3*8+2] = 0;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
                        //	cout<<" lineageEntryExtraction "<<counterA<<endl;
                        //}
                        
                        //-----Master Rev and Status process-----
                        for (int counter2 = 0; counter2 < lineageEntryExtractionCount/8; counter2++){
                            mainDeletionError = 0;
                            
                            if (lineageEntryExtraction [counter2*8+2] != 0){
                                imagePositionString = to_string(lineageEntryExtraction [counter2*8+2]);
                                
                                if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                                else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                                else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                                
                                connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                                
                                size1 = 0;
                                size2 = 0;
                                checkFlag = 0;
                                
                                for (int counter4 = 0; counter4 < 6; counter4++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter4 == 0) size1 = sizeForCopy;
                                        else if (counter4 == 1) size2 = sizeForCopy;
                                        else if (counter4 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter4 == 3) size1 = sizeForCopy;
                                        else if (counter4 == 4) size2 = sizeForCopy;
                                        else if (counter4 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                connectNoGet = 0;
                                readingError = 0;
                                
                                if (checkFlag == 1){
                                    fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        modifyStartFlag = -1;
                                        
                                        do{
                                            
                                            readPosition = readPosition+5;
                                            
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                            finData [14] = uploadTemp [readPosition], readPosition++;
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                            
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                            
                                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                            
                                            if (finData [7] == 0 && finData [16] == 0);
                                            else{
                                                
                                                if (processType == 1){
                                                    if (finData [16] == connectNoDel){
                                                        connectNoGet = finData [7];
                                                        
                                                        uploadTemp [readPosition-1] = 0;
                                                        uploadTemp [readPosition-2] = 0;
                                                        uploadTemp [readPosition-3] = 0;
                                                        uploadTemp [readPosition-4] = 0;
                                                        uploadTemp [readPosition-5] = 0;
                                                        uploadTemp [readPosition-6] = 0;
                                                        uploadTemp [readPosition-7] = 0;
                                                        uploadTemp [readPosition-8] = 0;
                                                        uploadTemp [readPosition-9] = 0;
                                                    }
                                                }
                                                else if (processType == 2 || processType == 3){
                                                    if (finData [16] == connectNoDel && finData [12] == delCellNo && modifyStartFlag == -1){
                                                        modifyStartFlag = finData [16];
                                                        connectNoGet = finData [7];
                                                        
                                                        uploadTemp [readPosition-1] = 0;
                                                        uploadTemp [readPosition-2] = 0;
                                                        uploadTemp [readPosition-3] = 0;
                                                        uploadTemp [readPosition-4] = 0;
                                                        uploadTemp [readPosition-5] = 0;
                                                        uploadTemp [readPosition-6] = 0;
                                                        uploadTemp [readPosition-7] = 0;
                                                        uploadTemp [readPosition-8] = 0;
                                                        uploadTemp [readPosition-9] = 0;
                                                    }
                                                    else if (finData [12] == delCellNo && modifyStartFlag == finData [16]){
                                                        uploadTemp [readPosition-1] = 0;
                                                        uploadTemp [readPosition-2] = 0;
                                                        uploadTemp [readPosition-3] = 0;
                                                        uploadTemp [readPosition-4] = 0;
                                                        uploadTemp [readPosition-5] = 0;
                                                        uploadTemp [readPosition-6] = 0;
                                                        uploadTemp [readPosition-7] = 0;
                                                        uploadTemp [readPosition-8] = 0;
                                                        uploadTemp [readPosition-9] = 0;
                                                    }
                                                    else if (modifyStartFlag != -1 && modifyStartFlag != finData [16]){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                        } while (finData [7] != 0);
                                        
                                        ofstream outfile (connectDataPath.c_str(), ofstream::binary);
                                        outfile.write ((char*)uploadTemp, sizeForCopy);
                                        outfile.close();
                                    }
                                    
                                    delete [] uploadTemp;
                                }
                                
                                if (checkFlag == 0 || readingError == 1) mainDeletionError = 1;
                                
                                connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                                
                                sizeForCopy = 0;
                                
                                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                readingError = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                readPosition = readPosition+13;
                                                
                                                finData [13] = uploadTemp [readPosition], readPosition++;
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++; //--9 Connect no
                                                finData [16] = uploadTemp [readPosition], readPosition++;
                                                finData [17] = uploadTemp [readPosition], readPosition++;
                                                finData [18] = uploadTemp [readPosition], readPosition++; //--10 Lineage no
                                                
                                                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                                
                                                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                                else{
                                                    
                                                    if (processType == 1){
                                                        if (finData [18] == connectNoDel){
                                                            uploadTemp [readPosition-19] = 0;
                                                            uploadTemp [readPosition-1] = 0;
                                                            uploadTemp [readPosition-2] = 0;
                                                            uploadTemp [readPosition-3] = 0;
                                                        }
                                                    }
                                                    
                                                    if (processType == 2 || processType == 3){
                                                        if (finData [18] == connectNoDel && finData [15] == connectNoGet){
                                                            uploadTemp [readPosition-19] = 0;
                                                            uploadTemp [readPosition-1] = 0;
                                                            uploadTemp [readPosition-2] = 0;
                                                            uploadTemp [readPosition-3] = 0;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                                        outfile2.write ((char*)uploadTemp, sizeForCopy);
                                        outfile2.close();
                                    }
                                    
                                    delete [] uploadTemp;
                                }
                                
                                if (readingError == 1) mainDeletionError = 1;
                                
                                //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
                                connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                                
                                sizeForCopy = 0;
                                
                                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //-----Master Data upLoad-----
                                readingError = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                    
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        int *modifyDataTemp = new int [sizeForCopy+50];
                                        modifyDataTempCount = 0;
                                        
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                                finData [3] = uploadTemp [readPosition], readPosition++;
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                finData [7] = finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                else{
                                                    
                                                    if (processType == 1){
                                                        if (finData [2] != connectNoDel){
                                                            modifyDataTemp [modifyDataTempCount] = finData [2], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [5], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [7], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [12], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [13], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [14], modifyDataTempCount++;
                                                        }
                                                    }
                                                    else if (processType == 2 || processType == 3){
                                                        if (finData [2] != connectNoDel || finData [12] != delCellNo){
                                                            modifyDataTemp [modifyDataTempCount] = finData [2], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [5], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [7], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [12], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [13], modifyDataTempCount++;
                                                            modifyDataTemp [modifyDataTempCount] = finData [14], modifyDataTempCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        char *writingArray = new char [modifyDataTempCount/6*16+16];
                                        
                                        indexCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < modifyDataTempCount/6; counter3++){
                                            dataTemp = modifyDataTemp [counter3*6];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            dataTemp = modifyDataTemp [counter3*6+1];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            dataTemp = modifyDataTemp [counter3*6+2];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            if (modifyDataTemp [counter3*6+3] < 0){
                                                writingArray [indexCount] = 1, indexCount++;
                                                dataTemp = modifyDataTemp [counter3*6+3]*-1;
                                            }
                                            else{
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                dataTemp = modifyDataTemp [counter3*6+3];
                                            }
                                            
                                            readBit [0] = dataTemp/16777216;
                                            dataTemp = dataTemp%16777216;
                                            readBit [1] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [2] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [3] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                                            
                                            writingArray [indexCount] = (char)modifyDataTemp [counter3*6+4], indexCount++;
                                            writingArray [indexCount] = (char)modifyDataTemp [counter3*6+5], indexCount++;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 15; counter3++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile2 (connectRelationPath.c_str(), ofstream::binary);
                                        outfile2.write ((char*) writingArray, indexCount);
                                        outfile2.close();
                                        
                                        delete [] writingArray;
                                        delete [] modifyDataTemp;
                                    }
                                    
                                    delete [] uploadTemp;
                                }
                                
                                if (readingError == 1) mainDeletionError = 1;
                                
                                //===========Fluorescent deletion============
                                connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                                
                                size1 = 0;
                                size2 = 0;
                                checkFlag = 0;
                                
                                for (int counter4 = 0; counter4 < 6; counter4++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter4 == 0) size1 = sizeForCopy;
                                        else if (counter4 == 1) size2 = sizeForCopy;
                                        else if (counter4 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter4 == 3) size1 = sizeForCopy;
                                        else if (counter4 == 4) size2 = sizeForCopy;
                                        else if (counter4 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                readingError = 0;
                                
                                if (checkFlag == 1){
                                    int *arrayExpandTemp = new int [sizeForCopy+50];
                                    expandTempCount = 0;
                                    
                                    fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                                    readingError = 1;
                                                }
                                            }
                                        }
                                        
                                        fin.close();
                                        
                                        if (readingError == 0){
                                            readPosition = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                                    finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                                    
                                                    finData [1] = finData [0]*256+finData [1];
                                                    finData [3] = finData [2]*256+finData [3];
                                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                    
                                                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayExpandTemp [expandTempCount] = finData [1], expandTempCount++;
                                                        arrayExpandTemp [expandTempCount] = finData [3], expandTempCount++;
                                                        arrayExpandTemp [expandTempCount] = finData [6], expandTempCount++;
                                                        arrayExpandTemp [expandTempCount] = finData [7], expandTempCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    
                                    //for (int counterA = 0; counterA < expandTempCount/4; counterA++){
                                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandTemp [counterA*4+counterB];
                                    //    cout<<" arrayExpandTemp "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
                                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
                                    //    cout<<" expandFluorescentData "<<counterA<<endl;
                                    //}
                                    
                                    int *arrayExpandTemp2 = new int [sizeForCopy+50];
                                    expandTempCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandTempCount/4; counter3++){
                                        if (arrayExpandTemp [counter3*4+2] != connectNoGet){
                                            arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter3*4], expandTempCount2++;
                                            arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter3*4+1], expandTempCount2++;
                                            arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter3*4+2], expandTempCount2++;
                                            arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter3*4+3], expandTempCount2++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < expandTempCount2/4; counterA++){
                                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandTemp2 [counterA*4+counterB];
                                    //    cout<<" arrayExpandTemp2 "<<counterA<<endl;
                                    //}
                                    
                                    delete [] arrayExpandTemp;
                                    
                                    if (expandTempCount2 != 0){
                                        indexCount = 0;
                                        char *writingArray = new char [expandTempCount2*2+200];
                                        
                                        for (int counter3 = 0; counter3 < expandTempCount2/4; counter3++){
                                            dataTemp = arrayExpandTemp2 [counter3*4];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = arrayExpandTemp2 [counter3*4+1];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = arrayExpandTemp2 [counter3*4+2];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            writingArray [indexCount] = (char)arrayExpandTemp2 [counter3*4+3], indexCount++;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                        outfile3.write ((char*)writingArray, indexCount);
                                        outfile3.close();
                                        
                                        delete [] writingArray;
                                    }
                                    else remove(connectRelationPath.c_str());
                                    
                                    delete [] arrayExpandTemp2;
                                    
                                    connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                                    
                                    sizeForCopy = 0;
                                    
                                    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        int *arrayExpandDataTemp = new int [sizeForCopy+50];
                                        expandDataTempCount = 0;
                                        
                                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            readPosition = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                                    
                                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                    
                                                    if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [2], expandDataTempCount++;
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [3], expandDataTempCount++;
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [4], expandDataTempCount++;
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [7], expandDataTempCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                            
                                            delete [] uploadTemp;
                                        }
                                        
                                        int *arrayExpandDataTemp2 = new int [expandDataTempCount+50];
                                        expandDataTempCount2 = 0;
                                        
                                        for (int counter3 = 0; counter3 < expandDataTempCount/4; counter3++){
                                            if (arrayExpandDataTemp [counter3*4] != connectNoGet){
                                                arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter3*4], expandDataTempCount2++;
                                                arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter3*4+1], expandDataTempCount2++;
                                                arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter3*4+2], expandDataTempCount2++;
                                                arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter3*4+3], expandDataTempCount2++;
                                            }
                                        }
                                        
                                        delete [] arrayExpandDataTemp;
                                        
                                        if (expandDataTempCount2 != 0){
                                            indexCount = 0;
                                            char *writingArray = new char [expandDataTempCount2*2+20];
                                            
                                            for (int counter3 = 0; counter3 < expandDataTempCount2/4; counter3++){
                                                dataTemp = arrayExpandDataTemp2 [counter3*4];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayExpandDataTemp2 [counter3*4+1], indexCount++;
                                                writingArray [indexCount] = (char)arrayExpandDataTemp2 [counter3*4+2], indexCount++;
                                                
                                                dataTemp = arrayExpandDataTemp2 [counter3*4+3];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            }
                                            
                                            for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                            
                                            ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                            outfile3.write ((char*)writingArray, indexCount);
                                            outfile3.close();
                                            
                                            delete [] writingArray;
                                        }
                                        else remove(connectRelationPath.c_str());
                                        
                                        delete [] arrayExpandDataTemp2;
                                    }
                                    
                                    if (lineageEntryExtraction [counter2*8+2] == imageNumberTrackForDisplay){
                                        int *arrayExpandTemp3 = new int [expandFluorescentOutlineCount+50];
                                        expandTempCount3 = 0;
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                                            if (expandFluorescentOutline [counter3*4+2] != connectNoGet){
                                                arrayExpandTemp3 [expandTempCount3] = expandFluorescentOutline [counter3*4], expandTempCount3++;
                                                arrayExpandTemp3 [expandTempCount3] = expandFluorescentOutline [counter3*4+1], expandTempCount3++;
                                                arrayExpandTemp3 [expandTempCount3] = expandFluorescentOutline [counter3*4+2], expandTempCount3++;
                                                arrayExpandTemp3 [expandTempCount3] = expandFluorescentOutline [counter3*4+3], expandTempCount3++;
                                            }
                                        }
                                        
                                        expandFluorescentOutlineCount = 0;
                                        for (int counter3 = 0; counter3 < expandTempCount3; counter3++) expandFluorescentOutline [expandFluorescentOutlineCount] = arrayExpandTemp3 [counter3], expandFluorescentOutlineCount++;
                                        
                                        delete [] arrayExpandTemp3;
                                        
                                        int *arrayExpandDataTemp3 = new int [expandFluorescentDataCount+50];
                                        expandDataTempCount3 = 0;
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentDataCount/4; counter3++){
                                            if (expandFluorescentData [counter3*4] != connectNoGet){
                                                arrayExpandDataTemp3 [expandDataTempCount3] = expandFluorescentData [counter3*4], expandDataTempCount3++;
                                                arrayExpandDataTemp3 [expandDataTempCount3] = expandFluorescentData [counter3*4+1], expandDataTempCount3++;
                                                arrayExpandDataTemp3 [expandDataTempCount3] = expandFluorescentData [counter3*4+2], expandDataTempCount3++;
                                                arrayExpandDataTemp3 [expandDataTempCount3] = expandFluorescentData [counter3*4+3], expandDataTempCount3++;
                                            }
                                        }
                                        
                                        expandFluorescentDataCount = 0;
                                        for (int counter3 = 0; counter3 < expandDataTempCount3; counter3++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp3 [counter3], expandFluorescentDataCount++;
                                        
                                        delete [] arrayExpandDataTemp3;
                                    }
                                    
                                    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
                                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
                                    //    cout<<" expandFluorescentData "<<counterA<<endl;
                                    //}
                                }
                            }
                            
                            if (mainDeletionError == 1){
                                break;
                            }
                        }
                        
                        if (mainDeletionError == 0){
                            if (processType == 1){
                                //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
                                connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                                
                                lineageStartEndCount = 0;
                                
                                cellNumberStart = -1;
                                lineageNumberStart = 0;
                                firstEntryFind = 0;
                                
                                for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                    if ((arrayLineageData [counter2*8+6] != lineageNumberStart || arrayLineageData [counter2*8+5] != cellNumberStart) && firstEntryFind == 0){
                                        lineageNumberStart = arrayLineageData [counter2*8+6];
                                        cellNumberStart = arrayLineageData [counter2*8+5];
                                        
                                        arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+1], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+2], lineageStartEndCount++;
                                        
                                        firstEntryFind = 1;
                                    }
                                    else if ((arrayLineageData [counter2*8+6] != lineageNumberStart || arrayLineageData [counter2*8+5] != cellNumberStart) && firstEntryFind == 1){
                                        lineageNumberStart = arrayLineageData [counter2*8+6];
                                        cellNumberStart = arrayLineageData [counter2*8+5];
                                        
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2-1, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter2-1)*8+2], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+1], lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+2], lineageStartEndCount++;
                                    }
                                    
                                    if (counter2 == lineageDataCount/8-1){
                                        arrayLineageStartEnd [lineageStartEndCount] = counter2, lineageStartEndCount++;
                                        arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter2*8+2], lineageStartEndCount++;
                                    }
                                    
                                    if (lineageStartEndCount+24 > lineageStartEndLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate lineageStartEndUpDate];
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                                //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
                                //}
                                
                                if (lineageStartEndCount != 0){
                                    char *mainDataEntry = new char [lineageStartEndCount*7+10];
                                    totalEntryCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageStartEndCount; counter2++){
                                        extension = to_string(arrayLineageStartEnd [counter2]);
                                        
                                        for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile (connectStartEndPath.c_str(), ofstream::binary);
                                    outfile.write (mainDataEntry, totalEntryCount);
                                    outfile.close();
                                    
                                    delete [] mainDataEntry;
                                }
                            }
                            
                            //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                            int *modifyDataTemp = new int [cellLineageInfoCount+50];
                            modifyDataTempCount = 0;
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                            
                            if (processType == 1){
                                for (int counter2 = 0; counter2 < cellLineageInfoCount/3; counter2++){
                                    if (arrayCellLineageInfo [counter2*3] != connectNoDel){
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3], modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+1], modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+2], modifyDataTempCount++;
                                    }
                                }
                            }
                            
                            if (processType == 2){
                                for (int counter2 = 0; counter2 < cellLineageInfoCount/3; counter2++){
                                    if (arrayCellLineageInfo [counter2*3] != connectNoDel){
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3], modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+1], modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+2], modifyDataTempCount++;
                                    }
                                    if (arrayCellLineageInfo [counter2*3] == connectNoDel){
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3], modifyDataTempCount++;
                                        
                                        modifyDataTemp [modifyDataTempCount] = 0, modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+2]-1, modifyDataTempCount++;
                                    }
                                }
                            }
                            
                            if (processType == 3){
                                for (int counter2 = 0; counter2 < cellLineageInfoCount/3; counter2++){
                                    if (arrayCellLineageInfo [counter2*3] != connectNoDel){
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3], modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+1], modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+2], modifyDataTempCount++;
                                    }
                                    if (arrayCellLineageInfo [counter2*3] == connectNoDel){
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3], modifyDataTempCount++;
                                        
                                        modifyDataTemp [modifyDataTempCount] = 0, modifyDataTempCount++;
                                        modifyDataTemp [modifyDataTempCount] = arrayCellLineageInfo [counter2*3+2], modifyDataTempCount++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                            //    if (arrayLineageData [counterA*8 +6] == 267){
                            //        for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8 +counterB];
                            //        cout<<" arrayLineageData2 "<<counterA<<endl;
                            //    }
                            //}
                            
                            //for (int counterA = 0; counterA < fusionPositionInfoCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<fusionPositionInfo [counterA*5+counterB];
                            //	cout<<" fusionPositionInfo "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                            
                            if (fusionPositionInfoCount != 0){ //-----For fusion-----
                                for (int counter2 = 0; counter2 < fusionPositionInfoCount/5; counter2++){
                                    for (int counter3 = 0; counter3 < modifyDataTempCount/3; counter3++){
                                        if (modifyDataTemp [counter3*3] == fusionPositionInfo [counter2*5]){
                                            modifyDataTemp [counter3*3+1] = 0;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (cellLineageInfoStatus == 1) delete [] arrayCellLineageInfo;
                            arrayCellLineageInfo = new int [modifyDataTempCount+50];
                            cellLineageInfoCount = 0;
                            cellLineageInfoLimit = modifyDataTempCount+50;
                            cellLineageInfoStatus = 1;
                            
                            for (int counter2 = 0; counter2 < modifyDataTempCount; counter2++) arrayCellLineageInfo [cellLineageInfoCount] = modifyDataTemp [counter2], cellLineageInfoCount++;
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                            
                            connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
                            
                            char *mainDataEntry = new char [modifyDataTempCount*6+10];
                            totalEntryCount = 0;
                            
                            for (int counter2 = 0; counter2 < modifyDataTempCount; counter2++){
                                extension = to_string(modifyDataTemp [counter2]);
                                
                                for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile (connectDataInfoPath.c_str(), ofstream::binary);
                            outfile.write (mainDataEntry, totalEntryCount);
                            outfile.close();
                            
                            delete [] mainDataEntry;
                            delete [] modifyDataTemp;
                            
                            //=========Queue List creation==========
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //    cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            if (fusionPositionInfoCount != 0){ //-----For fusion-----
                                for (int counter2 = 0; counter2 < fusionPositionInfoCount/5; counter2++){ //-----Fusion case, add into the Queue list-----
                                    fusionLineageString = to_string(fusionPositionInfo [counter2*5]);
                                    
                                    if (fusionLineageString.length() == 1) fusionLineageString = "L0000"+fusionLineageString;
                                    else if (fusionLineageString.length() == 2) fusionLineageString = "L000"+fusionLineageString;
                                    else if (fusionLineageString.length() == 3) fusionLineageString = "L00"+fusionLineageString;
                                    else if (fusionLineageString.length() == 4) fusionLineageString = "L0"+fusionLineageString;
                                    else if (fusionLineageString.length() == 5) fusionLineageString = "L"+fusionLineageString;
                                    
                                    fusionCellNoString = to_string(fusionPositionInfo [counter2*5+1]);
                                    
                                    if (fusionPositionInfo [counter2*5+1] >= 0){
                                        if (fusionCellNoString.length() == 1) fusionCellNoString = "C00000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 2) fusionCellNoString = "C0000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 3) fusionCellNoString = "C000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 4) fusionCellNoString = "C00000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 5) fusionCellNoString = "C0000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 6) fusionCellNoString = "C000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 7) fusionCellNoString = "C00"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 8) fusionCellNoString = "C0"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 9) fusionCellNoString = "C"+fusionCellNoString;
                                    }
                                    else{
                                        
                                        fusionCellNoString = fusionCellNoString.substr(1);
                                        
                                        if (fusionCellNoString.length() == 1) fusionCellNoString = "C-00000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 2) fusionCellNoString = "C-0000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 3) fusionCellNoString = "C-000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 4) fusionCellNoString = "C-00000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 5) fusionCellNoString = "C-0000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 6) fusionCellNoString = "C-000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 7) fusionCellNoString = "C-00"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 8) fusionCellNoString = "C-0"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 9) fusionCellNoString = "C-"+fusionCellNoString;
                                    }
                                    
                                    string *modifyDataStringTemp = new string [queueListCount+50];
                                    modifyDataStringTempCount = 0;
                                    
                                    findInListFlag = 0;
                                    
                                    for (int counter3 = 0; counter3 < queueListCount/6; counter3++){
                                        if (arrayQueueList [counter3*6] != treatmentNameHold || arrayQueueList [counter3*6+1] != fusionLineageString || arrayQueueList [counter3*6+2] != fusionCellNoString){
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter3*6], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter3*6+1], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter3*6+2], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter3*6+3], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter3*6+4], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter3*6+5], modifyDataStringTempCount++;
                                        }
                                        else if (arrayQueueList [counter3*6] == treatmentNameHold && arrayQueueList [counter3*6+1] == fusionLineageString && arrayQueueList [counter3*6+2] == fusionCellNoString){
                                            findInListFlag = 1;
                                        }
                                    }
                                    
                                    queueListCount = 0;
                                    for (int counter3 = 0; counter3 < modifyDataStringTempCount; counter3++) arrayQueueList [queueListCount] = modifyDataStringTemp [counter3], queueListCount++;
                                    
                                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                    //    cout<<" arrayQueueList "<<counterA<<endl;
                                    //}
                                    
                                    if (findInListFlag == 1){
                                        markerStatus = 0;
                                        startTime = 0;
                                        endStatus = 0;
                                        endTime = 0;
                                        
                                        for (int counter3 = 0; counter3 < lineageStartEndCount/8; counter3++){
                                            if (arrayLineageStartEnd [counter3*8] == fusionPositionInfo [counter2*5] && arrayLineageStartEnd [counter3*8+1] == fusionPositionInfo [counter2*5+1]){
                                                for (int counter4 = arrayLineageStartEnd [counter3*8+4]; counter4 <= arrayLineageStartEnd [counter3*8+6]; counter4++){
                                                    if (arrayLineageData [counter4*8+3] == 10) markerStatus = 1;
                                                    if (arrayLineageData [counter4*8+3] == 32 || arrayLineageData [counter4*8+3] == 42 || arrayLineageData [counter4*8+3] == 52 || arrayLineageData [counter4*8+3] == 7 || arrayLineageData [counter4*8+3] == 8 || arrayLineageData [counter4*8+3] == 91) endStatus = 1;
                                                    
                                                    endTime = arrayLineageData [counter4*8+2];
                                                    
                                                    if (startTime == 0) startTime = arrayLineageData [counter4*8+2];
                                                }
                                            }
                                        }
                                        
                                        if (endStatus == 0){
                                            if (processType == 1){
                                                for (int counter3 = 0; counter3 < doneListCount/5; counter3++){
                                                    if (arrayDoneList [counter3*5] == treatmentNameHold && arrayDoneList [counter3*5+1] == fusionLineageString && arrayDoneList [counter3*5+2] == fusionCellNoString){
                                                        imageCheckTime = arrayDoneList [counter3*5+3];
                                                        
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                                            else imageCheckTime = to_string(startTime);
                                            
                                            extension = to_string(endTime);
                                            
                                            arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
                                            arrayQueueList [queueListCount] = fusionLineageString, queueListCount++;
                                            arrayQueueList [queueListCount] = fusionCellNoString, queueListCount++;
                                            arrayQueueList [queueListCount] = extension+":"+imageCheckTime, queueListCount++;
                                            
                                            if (markerStatus == 1) arrayQueueList [queueListCount] = "/m", queueListCount++;
                                            else arrayQueueList [queueListCount] = "0", queueListCount++;
                                            
                                            arrayQueueList [queueListCount] = "Wait", queueListCount++;
                                        }
                                    }
                                    
                                    delete [] modifyDataStringTemp;
                                }
                            }
                            
                            cellLineageString = to_string(connectNoDel);
                            
                            if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
                            else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
                            else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
                            else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
                            else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
                            
                            cellNumberString = to_string(delCellNo);
                            
                            if (delCellNo >= 0){
                                if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                                else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                                else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                                else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                                else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                                else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                                else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                                else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                                else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                            }
                            else{
                                
                                cellNumberString = cellNumberString.substr(1);
                                
                                if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                                else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                                else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                                else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                                else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                                else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                                else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                                else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                                else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                            }
                            
                            string *modifyDataStringTemp = new string [queueListCount+50];
                            modifyDataStringTempCount = 0;
                            
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //    cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            if (processType == 1){
                                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                    if (arrayQueueList [counter2*6] != treatmentNameHold || arrayQueueList [counter2*6+1] != cellLineageString){
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+1], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+2], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+3], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+4], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+5], modifyDataStringTempCount++;
                                    }
                                }
                            }
                            
                            if (processType == 2){
                                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                    if (arrayQueueList [counter2*6] != treatmentNameHold || arrayQueueList [counter2*6+1] != cellLineageString || arrayQueueList [counter2*6+2] != cellNumberString){
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+1], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+2], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+3], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+4], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+5], modifyDataStringTempCount++;
                                    }
                                }
                            }
                            
                            if (processType == 3){
                                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                    if (arrayQueueList [counter2*6] != treatmentNameHold || arrayQueueList [counter2*6+1] != cellLineageString || arrayQueueList [counter2*6+2] != cellNumberString){
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+1], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+2], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+3], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+4], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+5], modifyDataStringTempCount++;
                                    }
                                    else if (arrayQueueList [counter2*6] == treatmentNameHold && arrayQueueList [counter2*6+1] == cellLineageString && arrayQueueList [counter2*6+2] == cellNumberString){
                                        
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+1], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+2], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = to_string(startPointSet-1)+":"+to_string(startPointSet-1), modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+4], modifyDataStringTempCount++;
                                        modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter2*6+5], modifyDataStringTempCount++;
                                    }
                                }
                            }
                            
                            queueListCount = 0;
                            for (int counter2 = 0; counter2 < modifyDataStringTempCount; counter2++) arrayQueueList [queueListCount] = modifyDataStringTemp [counter2], queueListCount++;
                            
                            queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                            
                            if (queueListCount != 0){
                                mainDataEntry = new char [queueListCount*12+10];
                                totalEntryCount = 0;
                                
                                for (int counter2 = 0; counter2 < queueListCount; counter2++){
                                    extension = arrayQueueList [counter2];
                                    
                                    for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile2 (queueListPath.c_str(), ofstream::binary);
                                outfile2.write (mainDataEntry, totalEntryCount);
                                outfile2.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //	cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            delete [] modifyDataStringTemp;
                            
                            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                            //	cout<<" arrayDoneList "<<counterA<<endl;
                            //}
                            
                            //=========Done List UpDate==========
                            //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Check status-----
                            //-----Check Status: OK, LST, CFU, CDD, CTD, CHD, UN-----
                            
                            if (fusionPositionInfoCount != 0){ //-----For fusion-----
                                for (int counter2 = 0; counter2 < fusionPositionInfoCount/5; counter2++){
                                    fusionLineageString = to_string(fusionPositionInfo [counter2*5]);
                                    
                                    if (fusionLineageString.length() == 1) fusionLineageString = "L0000"+fusionLineageString;
                                    else if (fusionLineageString.length() == 2) fusionLineageString = "L000"+fusionLineageString;
                                    else if (fusionLineageString.length() == 3) fusionLineageString = "L00"+fusionLineageString;
                                    else if (fusionLineageString.length() == 4) fusionLineageString = "L0"+fusionLineageString;
                                    else if (fusionLineageString.length() == 5) fusionLineageString = "L"+fusionLineageString;
                                    
                                    fusionCellNoString = to_string(fusionPositionInfo [counter2*5+1]);
                                    
                                    if (fusionPositionInfo [counter2*5+1] >= 0){
                                        if (fusionCellNoString.length() == 1) fusionCellNoString = "C00000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 2) fusionCellNoString = "C0000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 3) fusionCellNoString = "C000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 4) fusionCellNoString = "C00000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 5) fusionCellNoString = "C0000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 6) fusionCellNoString = "C000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 7) fusionCellNoString = "C00"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 8) fusionCellNoString = "C0"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 9) fusionCellNoString = "C"+fusionCellNoString;
                                    }
                                    else{
                                        
                                        fusionCellNoString = fusionCellNoString.substr(1);
                                        
                                        if (fusionCellNoString.length() == 1) fusionCellNoString = "C-00000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 2) fusionCellNoString = "C-0000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 3) fusionCellNoString = "C-000000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 4) fusionCellNoString = "C-00000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 5) fusionCellNoString = "C-0000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 6) fusionCellNoString = "C-000"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 7) fusionCellNoString = "C-00"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 8) fusionCellNoString = "C-0"+fusionCellNoString;
                                        else if (fusionCellNoString.length() == 9) fusionCellNoString = "C-"+fusionCellNoString;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < doneListCount/5; counter3++){
                                        if (arrayDoneList [counter3*5] == treatmentNameHold && arrayDoneList [counter3*5+1] == fusionLineageString && arrayDoneList [counter3*5+2] == fusionCellNoString && fusionPositionInfo [counter2*5+2] == 91){
                                            arrayDoneList [counter3*5] = "D";
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            modifyDataStringTemp = new string [doneListCount+50];
                            modifyDataStringTempCount = 0;
                            
                            if (processType == 1){
                                for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                                    if (arrayDoneList [counter2*5] != treatmentNameHold || arrayDoneList [counter2*5+1] != cellLineageString){
                                        if (arrayDoneList [counter2*5] != "D"){
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+1], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+2], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+3], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+4], modifyDataStringTempCount++;
                                        }
                                    }
                                }
                            }
                            
                            if (processType == 2 || processType == 3){
                                for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                                    if (arrayDoneList [counter2*5] != treatmentNameHold || arrayDoneList [counter2*5+1] != cellLineageString || arrayDoneList [counter2*5+2] != cellNumberString){
                                        if (arrayDoneList [counter2*5] != "D"){
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+1], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+2], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+3], modifyDataStringTempCount++;
                                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter2*5+4], modifyDataStringTempCount++;
                                        }
                                    }
                                }
                            }
                            
                            doneListCount = 0;
                            
                            for (int counter2 = 0; counter2 < modifyDataStringTempCount; counter2++) arrayDoneList [doneListCount] = modifyDataStringTemp [counter2], doneListCount++;
                            
                            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                            //	cout<<" arrayDoneList "<<counterA<<endl;
                            //}
                            
                            doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                            
                            if (doneListCount != 0){
                                mainDataEntry = new char [doneListCount*10+10];
                                totalEntryCount = 0;
                                
                                for (int counter2 = 0; counter2 < doneListCount; counter2++){
                                    extension = arrayDoneList [counter2];
                                    
                                    for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile9 (doneListPath.c_str(), ofstream::binary);
                                outfile9.write (mainDataEntry, totalEntryCount);
                                outfile9.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            delete [] modifyDataStringTemp;
                            
                            //-----Folder deletion-----
                            if (processType == 1){
                                lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageString;
                                
                                DIR *dir;
                                struct dirent *dent;
                                DIR *dir2;
                                struct dirent *dent2;
                                
                                dir = opendir(lineageFolderPath.c_str());
                                fileDeleteCount = 0;
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        cellFolderPath = lineageFolderPath+"/"+entry;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            dir2 = opendir(cellFolderPath.c_str());
                                            
                                            if (dir2 != NULL){
                                                while ((dent2 = readdir(dir2))){
                                                    entry2 = dent2 -> d_name;
                                                    
                                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                                        fileUpdate = [[FileUpdate alloc] init];
                                                        [fileUpdate fileDeleteUpDate];
                                                    }
                                                    
                                                    arrayFileDelete [fileDeleteCount] = cellFolderPath+"/"+entry2, fileDeleteCount++;
                                                }
                                                
                                                closedir(dir2);
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                    remove (arrayFileDelete [counter2].c_str());
                                }
                                
                                fileDeleteCount = 0;
                                
                                dir = opendir(lineageFolderPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate fileDeleteUpDate];
                                        }
                                        
                                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir);
                                    
                                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                        cellFolderPath = lineageFolderPath+"/"+arrayFileDelete [counter2];
                                        remove (cellFolderPath.c_str());
                                        rmdir (cellFolderPath.c_str());
                                    }
                                    
                                    rmdir (lineageFolderPath.c_str());
                                }
                            }
                            
                            if (processType == 2){
                                cellFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageString+"/"+cellNumberString;
                                
                                fileDeleteCount = 0;
                                
                                DIR *dir;
                                struct dirent *dent;
                                
                                dir = opendir(cellFolderPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate fileDeleteUpDate];
                                        }
                                        
                                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir);
                                    
                                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                                        cellFolderPath2 = cellFolderPath+"/"+arrayFileDelete [counter2];
                                        remove (cellFolderPath2.c_str());
                                    }
                                    
                                    rmdir (cellFolderPath.c_str());
                                }
                            }
                            
                            if (fusionPositionInfoCount != 0){ //-----For fusion-----
                                for (int counter2 = 0; counter2 < fusionPositionInfoCount/5; counter2++){ //-----Fusion case, add into the Queue list-----
                                    fusionLineageString = to_string(fusionPositionInfo [counter2*5]);
                                    
                                    if (fusionLineageString.length() == 1) fusionLineageString = "L0000"+fusionLineageString;
                                    else if (fusionLineageString.length() == 2) fusionLineageString = "L000"+fusionLineageString;
                                    else if (fusionLineageString.length() == 3) fusionLineageString = "L00"+fusionLineageString;
                                    else if (fusionLineageString.length() == 4) fusionLineageString = "L0"+fusionLineageString;
                                    else if (fusionLineageString.length() == 5) fusionLineageString = "L"+fusionLineageString;
                                    
                                    lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+fusionLineageString+"/"+analysisID+"_"+fusionLineageString+"_CellStatus";
                                    
                                    sizeForCopy = 0;
                                    
                                    if (stat(lineageFolderPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        char *uploadTemp = new char [sizeForCopy+50];
                                        fin.open(lineageFolderPath.c_str(), ios::in | ios::binary);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        fin.close();
                                        
                                        int *cellInfoProcessTemp = new int [sizeForCopy+50];
                                        cellInfoProcessTempCount = 0;
                                        
                                        readPosition = 0;
                                        
                                        do{
                                            
                                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                            else if (dataString != "End") cellInfoProcessTemp [cellInfoProcessTempCount] = atoi(dataString.c_str()), cellInfoProcessTempCount++,
                                                dataString = "";
                                            
                                            readPosition++;
                                            
                                        } while (dataString != "End");
                                        
                                        delete [] uploadTemp;
                                        
                                        // 1. Lineage no, 2. Cell no, 3. Fusion type, 4. self cell no, 5 start image no=
                                        
                                        fusionRemainingMark = 0;
                                        
                                        for (int counter3 = 0; counter3 < cellInfoProcessTempCount/7; counter3++){
                                            if (cellInfoProcessTemp [counter3*7] == fusionPositionInfo [counter2*5+1]){
                                                if (fusionPositionInfo [counter2*5+2] == 91){
                                                    cellInfoProcessTemp [counter3*7+2] = -1;
                                                    cellInfoProcessTemp [counter3*7+4] = 0;
                                                    
                                                    for (int counter4 = 0; counter4 < lineageStartEndCount/8; counter4++){
                                                        if (arrayLineageStartEnd [counter4*8] == fusionPositionInfo [counter2*5] && arrayLineageStartEnd [counter4*8+1] == fusionPositionInfo [counter2*5+1]){
                                                            for (int counter5 = arrayLineageStartEnd [counter4*8+4]; counter5 <= arrayLineageStartEnd [counter4*8+6]; counter5++){
                                                                if (arrayLineageData [counter5*8+3] == 10) fusionRemainingMark = 1;
                                                            }
                                                        }
                                                    }
                                                    
                                                    if (fusionRemainingMark == 1){
                                                        if (cellInfoProcessTemp [counter3*7+5] == 21) cellInfoProcessTemp [counter3*7+5] = 51;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 22) cellInfoProcessTemp [counter3*7+5] = 52;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 23) cellInfoProcessTemp [counter3*7+5] = 53;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 24) cellInfoProcessTemp [counter3*7+5] = 54;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 25) cellInfoProcessTemp [counter3*7+5] = 55;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 26) cellInfoProcessTemp [counter3*7+5] = 56;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 27) cellInfoProcessTemp [counter3*7+5] = 57;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 28) cellInfoProcessTemp [counter3*7+5] = 58;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 29) cellInfoProcessTemp [counter3*7+5] = 59;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 30) cellInfoProcessTemp [counter3*7+5] = 60;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 31) cellInfoProcessTemp [counter3*7+5] = 61;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 32) cellInfoProcessTemp [counter3*7+5] = 62;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 33) cellInfoProcessTemp [counter3*7+5] = 63;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 34) cellInfoProcessTemp [counter3*7+5] = 64;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 35) cellInfoProcessTemp [counter3*7+5] = 65;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 36) cellInfoProcessTemp [counter3*7+5] = 66;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 37) cellInfoProcessTemp [counter3*7+5] = 67;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 38) cellInfoProcessTemp [counter3*7+5] = 68;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 39) cellInfoProcessTemp [counter3*7+5] = 69;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 40) cellInfoProcessTemp [counter3*7+5] = 70;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 41) cellInfoProcessTemp [counter3*7+5] = 71;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 42) cellInfoProcessTemp [counter3*7+5] = 72;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 43) cellInfoProcessTemp [counter3*7+5] = 73;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 44) cellInfoProcessTemp [counter3*7+5] = 74;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 45) cellInfoProcessTemp [counter3*7+5] = 75;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 46) cellInfoProcessTemp [counter3*7+5] = 76;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 47) cellInfoProcessTemp [counter3*7+5] = 78;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 0) cellInfoProcessTemp [counter3*7+5] = 77;
                                                    }
                                                    else if (fusionRemainingMark == 0){
                                                        if (cellInfoProcessTemp [counter3*7+5] == 51) cellInfoProcessTemp [counter3*7+5] = 21;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 52) cellInfoProcessTemp [counter3*7+5] = 22;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 53) cellInfoProcessTemp [counter3*7+5] = 23;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 54) cellInfoProcessTemp [counter3*7+5] = 24;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 55) cellInfoProcessTemp [counter3*7+5] = 25;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 56) cellInfoProcessTemp [counter3*7+5] = 26;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 57) cellInfoProcessTemp [counter3*7+5] = 27;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 58) cellInfoProcessTemp [counter3*7+5] = 28;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 59) cellInfoProcessTemp [counter3*7+5] = 29;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 60) cellInfoProcessTemp [counter3*7+5] = 30;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 61) cellInfoProcessTemp [counter3*7+5] = 31;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 62) cellInfoProcessTemp [counter3*7+5] = 32;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 63) cellInfoProcessTemp [counter3*7+5] = 33;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 64) cellInfoProcessTemp [counter3*7+5] = 34;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 65) cellInfoProcessTemp [counter3*7+5] = 35;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 66) cellInfoProcessTemp [counter3*7+5] = 36;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 67) cellInfoProcessTemp [counter3*7+5] = 37;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 68) cellInfoProcessTemp [counter3*7+5] = 38;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 69) cellInfoProcessTemp [counter3*7+5] = 39;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 70) cellInfoProcessTemp [counter3*7+5] = 40;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 71) cellInfoProcessTemp [counter3*7+5] = 41;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 72) cellInfoProcessTemp [counter3*7+5] = 42;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 73) cellInfoProcessTemp [counter3*7+5] = 43;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 74) cellInfoProcessTemp [counter3*7+5] = 44;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 75) cellInfoProcessTemp [counter3*7+5] = 45;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 76) cellInfoProcessTemp [counter3*7+5] = 46;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 78) cellInfoProcessTemp [counter3*7+5] = 47;
                                                        else if (cellInfoProcessTemp [counter3*7+5] == 77) cellInfoProcessTemp [counter3*7+5] = 0;
                                                    }
                                                }
                                                
                                                break;
                                            }
                                        }
                                        
                                        mainDataEntry = new char [cellInfoProcessTempCount*7+10];
                                        totalEntryCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < cellInfoProcessTempCount; counter3++){
                                            extension = to_string(cellInfoProcessTemp [counter3]);
                                            
                                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile8 (lineageFolderPath.c_str(), ofstream::binary);
                                        outfile8.write (mainDataEntry, totalEntryCount);
                                        outfile8.close();
                                        
                                        delete [] mainDataEntry;
                                        delete [] cellInfoProcessTemp;
                                    }
                                }
                            }
                            
                            if (processType == 2 || processType == 3){
                                lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageString+"/"+analysisID+"_"+cellLineageString+"_CellStatus";
                                
                                int *cellInfoTemp = new int [cellNumberInfoCount+500];
                                cellInfoTempCount = 0;
                                
                                if (processType == 2){
                                    for (int counter2 = 0; counter2 < cellNumberInfoCount/7; counter2++){
                                        if (arrayCellNumberInfo [counter2*7] != delCellNo){
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7], cellInfoTempCount++;
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7+1], cellInfoTempCount++;
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7+2], cellInfoTempCount++;
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7+3], cellInfoTempCount++;
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7+4], cellInfoTempCount++;
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7+5], cellInfoTempCount++;
                                            cellInfoTemp [cellInfoTempCount] = arrayCellNumberInfo [counter2*7+6], cellInfoTempCount++;
                                        }
                                    }
                                    
                                    cellNumberInfoCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellInfoTempCount; counter2++) arrayCellNumberInfo [cellNumberInfoCount] = cellInfoTemp [counter2], cellNumberInfoCount++;
                                    
                                    mainDataEntry = new char [cellInfoTempCount*7+10];
                                    totalEntryCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellInfoTempCount; counter2++){
                                        extension = to_string(cellInfoTemp [counter2]);
                                        
                                        for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile10 (lineageFolderPath.c_str(), ofstream::binary);
                                    outfile10.write (mainDataEntry, totalEntryCount);
                                    outfile10.close();
                                    
                                    delete [] mainDataEntry;
                                }
                                
                                if (processType == 3){
                                    for (int counter2 = 0; counter2 < cellNumberInfoCount/7; counter2++){
                                        if (arrayCellNumberInfo [counter2*7] == delCellNo){
                                            arrayCellNumberInfo [counter2*7+2] = -1;
                                            arrayCellNumberInfo [counter2*7+4] = 0;
                                            arrayCellNumberInfo [counter2*7+5] = 0;
                                            break;
                                        }
                                    }
                                    
                                    mainDataEntry = new char [cellNumberInfoCount*7+10];
                                    totalEntryCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellNumberInfoCount; counter2++){
                                        extension = to_string(arrayCellNumberInfo [counter2]);
                                        
                                        for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile11 (lineageFolderPath.c_str(), ofstream::binary);
                                    outfile11.write (mainDataEntry, totalEntryCount);
                                    outfile11.close();
                                    
                                    delete [] mainDataEntry;
                                }
                                
                                delete [] cellInfoTemp;
                            }
                            
                            //=======Lineage partner line=======
                            cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_FusionPartner";
                            
                            sizeForCopy = 0;
                            
                            if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                                lineagePartnerInfoTempCount = 0;
                                
                                string *arrayLineagePartnerInfoTemp2 = new string [sizeForCopy+50];
                                lineagePartnerInfoTempCount2 = 0;
                                
                                fin.open(cellFusionPartnerPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        getline(fin, treatmentNameGet);
                                        
                                        if (treatmentNameGet == "") terminationFlag = 0;
                                        else{
                                            
                                            getline(fin, lineageNoGet);
                                            getline(fin, cellNoGet);
                                            getline(fin, imageNoGet);
                                            getline(fin, partnerLingNoGet);
                                            getline(fin, partnerCellNoGet);
                                            
                                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < lineagePartnerInfoTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineagePartnerInfoTemp [counterA*6+counterB];
                                //    cout<<" arrayLineagePartnerInfoTemp "<<counterA<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                    if (arrayLineageData [counter2*8+3] == 10){
                                        for (int counter3 = 0; counter3 < lineagePartnerInfoTempCount/6; counter3++){
                                            lingNoTemp = arrayLineagePartnerInfoTemp [counter3*6+1];
                                            cellNoTemp = arrayLineagePartnerInfoTemp [counter3*6+2];
                                            imageNoTemp = arrayLineagePartnerInfoTemp [counter3*6+3];
                                            
                                            if (arrayLineagePartnerInfoTemp [counter3*6] == treatmentNameHold && atoi(lingNoTemp.c_str()) == arrayLineageData [counter2*8+6] && atoi(cellNoTemp.c_str()) == arrayLineageData [counter2*8+5] && atoi(imageNoTemp.c_str()) == arrayLineageData [counter2*8+2]){
                                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6], lineagePartnerInfoTempCount2++;
                                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+1], lineagePartnerInfoTempCount2++;
                                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+2], lineagePartnerInfoTempCount2++;
                                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+3], lineagePartnerInfoTempCount2++;
                                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+4], lineagePartnerInfoTempCount2++;
                                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+5], lineagePartnerInfoTempCount2++;
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineagePartnerInfoTempCount2/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineagePartnerInfoTemp2 [counterA*6+counterB];
                                //    cout<<" arrayLineagePartnerInfoTemp2 "<<counterA<<endl;
                                //}
                                
                                if (lineagePartnerInfoTempCount2 != 0){
                                    ofstream oin;
                                    oin.open(cellFusionPartnerPath.c_str(), ios::out);
                                    
                                    for (int counter2 = 0; counter2 < lineagePartnerInfoTempCount2; counter2++) oin<<arrayLineagePartnerInfoTemp2 [counter2]<<endl;
                                    
                                    oin.close();
                                }
                                else remove (cellFusionPartnerPath.c_str());
                                
                                delete [] arrayLineagePartnerInfoTemp;
                                delete [] arrayLineagePartnerInfoTemp2;
                            }
                            
                            //=======Mitosis Set array=======
                            mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_MitosisData";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter4 = 0; counter4 < 6; counter4++){
                                sizeForCopy = 0;
                                
                                if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter4 == 0) size1 = sizeForCopy;
                                    else if (counter4 == 1) size2 = sizeForCopy;
                                    else if (counter4 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter4 == 3) size1 = sizeForCopy;
                                    else if (counter4 == 4) size2 = sizeForCopy;
                                    else if (counter4 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            int *arrayMitosisTemp = new int [sizeForCopy+50];
                            mitosisTempCount = 0;
                            int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                            mitosisTempCount2 = 0;
                            int *arrayMitosisTemp3 = new int [sizeForCopy+50];
                            mitosisTempCount3 = 0;
                            
                            if (checkFlag == 1){
                                fin.open(mitosisStatusPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        getline(fin, lineageNoGet);
                                        
                                        if (lineageNoGet == "") terminationFlag = 0;
                                        else{
                                            
                                            getline(fin, cellNoGet);
                                            getline(fin, imageNoGet);
                                            getline(fin, setTypeGet);
                                            
                                            arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                            arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                            arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                            arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                if (processType == 1){
                                    for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                                        if (arrayMitosisTemp [counter2*4] != connectNoDel){
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4], mitosisTempCount2++;
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+1], mitosisTempCount2++;
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+2], mitosisTempCount2++;
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+3], mitosisTempCount2++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                                    //    cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                                    //}
                                    
                                    if (mitosisTempCount2 != 0){
                                        ofstream oin;
                                        oin.open(mitosisStatusPath.c_str(), ios::out);
                                        
                                        for (int counter2 = 0; counter2 < mitosisTempCount2; counter2++) oin<<arrayMitosisTemp2 [counter2]<<endl;
                                        
                                        oin.close();
                                    }
                                    else remove (mitosisStatusPath.c_str());
                                }
                                
                                if (processType == 2){
                                    for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                                        if (arrayMitosisTemp [counter2*4] != connectNoDel || arrayMitosisTemp [counter2*4+1] != delCellNo){
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4], mitosisTempCount2++;
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+1], mitosisTempCount2++;
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+2], mitosisTempCount2++;
                                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+3], mitosisTempCount2++;
                                        }
                                    }
                                    
                                    if (mitosisTempCount2 != 0){
                                        ofstream oin;
                                        oin.open(mitosisStatusPath.c_str(), ios::out);
                                        
                                        for (int counter2 = 0; counter2 < mitosisTempCount2; counter2++) oin<<arrayMitosisTemp2 [counter2]<<endl;
                                        
                                        oin.close();
                                    }
                                    else remove (mitosisStatusPath.c_str());
                                }
                            }
                            
                            if (processType == 3){
                                mitosisSetFind = 0;
                                lineageFirstPoint = 0;
                                lineageLastPoint = 0;
                                
                                for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                                    if (arrayLineageStartEnd [counter2*8] == connectNoDel && arrayLineageStartEnd [counter2*8+1] == delCellNo){
                                        for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                            if (arrayLineageData [counter3*8+2] < startPointSet){
                                                if (arrayLineageData [counter3*8+3] == 6) mitosisSetFind = arrayLineageData [counter3*8+2];
                                                if (lineageLastPoint < arrayLineageData [counter3*8+2]) lineageLastPoint = arrayLineageData [counter3*8+2];
                                                if (lineageFirstPoint == 0) lineageFirstPoint = arrayLineageData [counter3*8+2];
                                            }
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                                    if (arrayMitosisTemp [counter2*4] != connectNoDel || arrayMitosisTemp [counter2*4+1] != delCellNo){
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4], mitosisTempCount2++;
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+1], mitosisTempCount2++;
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+2], mitosisTempCount2++;
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+3], mitosisTempCount2++;
                                    }
                                    else{
                                        
                                        arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter2*4], mitosisTempCount3++;
                                        arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter2*4+1], mitosisTempCount3++;
                                        arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter2*4+2], mitosisTempCount3++;
                                        arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter2*4+3], mitosisTempCount3++;
                                    }
                                }
                                
                                int *arrayMitosisTemp4 = new int [(lineageLastPoint-lineageFirstPoint+1)*4+50];
                                mitosisTempCount4 = 0;
                                
                                for (int counter2 = lineageFirstPoint; counter2 <= lineageLastPoint; counter2++){
                                    arrayMitosisTemp4 [mitosisTempCount4] = connectNoDel, mitosisTempCount4++;
                                    arrayMitosisTemp4 [mitosisTempCount4] = delCellNo, mitosisTempCount4++;
                                    arrayMitosisTemp4 [mitosisTempCount4] = counter2, mitosisTempCount4++;
                                    
                                    if (mitosisSetFind != 0 && mitosisSetFind == counter2) arrayMitosisTemp4 [mitosisTempCount4] = 10, mitosisTempCount4++;
                                    else arrayMitosisTemp4 [mitosisTempCount4] = 0, mitosisTempCount4++;
                                }
                                
                                //for (int counterA = 0; counterA < mitosisTempCount4/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp4 [counterA*4+counterB];
                                //    cout<<" arrayMitosisTemp4 "<<counterA<<endl;
                                //}
                                
                                if (mitosisSetFind == 0){
                                    prevFirstPoint = 0;
                                    prevLastPoint = 0;
                                    
                                    for (int counter2 = 0; counter2 < mitosisTempCount3/4; counter2++){
                                        if (prevFirstPoint == 0) prevFirstPoint = arrayMitosisTemp3 [counter2*4+2];
                                        
                                        prevLastPoint = arrayMitosisTemp3 [counter2*4+2];
                                    }
                                    
                                    if (prevFirstPoint < lineageFirstPoint) prevFirstPoint = lineageFirstPoint;
                                    if (prevLastPoint > lineageLastPoint) prevLastPoint = lineageLastPoint;
                                    if (prevFirstPoint > lineageLastPoint || prevLastPoint < lineageFirstPoint) prevFirstPoint = 0;
                                    
                                    if (prevFirstPoint != 0){
                                        prevFind = 0;
                                        prevCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < mitosisTempCount4/4; counter2++){
                                            if (prevLastPoint > prevFirstPoint){
                                                if (arrayMitosisTemp4 [counter2*4+2] == prevFirstPoint){
                                                    if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                    
                                                    arrayMitosisTemp4 [counter2*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                                    prevFind = 1;
                                                    prevCount++;
                                                }
                                                else if (arrayMitosisTemp4 [counter2*4+2] == prevLastPoint){
                                                    if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                    
                                                    arrayMitosisTemp4 [counter2*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                                    prevFind = 0;
                                                }
                                                else if (prevFind == 1){
                                                    if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                    
                                                    arrayMitosisTemp4 [counter2*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                                    prevCount++;
                                                }
                                            }
                                            
                                            if (arrayMitosisTemp4 [counter2*4] == prevFirstPoint && prevLastPoint == prevFirstPoint){
                                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                
                                                arrayMitosisTemp4 [counter2*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                                //    cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < mitosisTempCount4/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp4 [counterA*4+counterB];
                                //    cout<<" arrayMitosisTemp4 "<<counterA<<endl;
                                //}
                                
                                ofstream oin;
                                oin.open(mitosisStatusPath.c_str(), ios::out);
                                
                                for (int counter2 = 0; counter2 < mitosisTempCount2; counter2++) oin<<arrayMitosisTemp2 [counter2]<<endl;
                                for (int counter2 = 0; counter2 < mitosisTempCount4; counter2++) oin<<arrayMitosisTemp4 [counter2]<<endl;
                                
                                oin.close();
                                
                                delete [] arrayMitosisTemp4;
                            }
                            
                            delete [] arrayMitosisTemp;
                            delete [] arrayMitosisTemp2;
                            delete [] arrayMitosisTemp3;
                            
                            if (processType == 1){
                                cellLineageNoHold = "";
                                cellNoHold = "";
                                addDelInsert = 1;
                            }
                            
                            revisedWorkingMapTime2 = 0;
                            
                            returnResults = 1;
                        }
                        
                        delete [] lineageEntryExtraction;
                    }
                    
                    delete [] fusionPositionInfo;
                    
                    if (fusionProcessError == 1 || mainDeletionError == 1){
                        returnResults = 0;
                        break;
                    }
                }
                else{
                    
                    returnResults = 0;
                    break;
                }
            }
            else{
                
                if (warningSkip == 0 && connectNoDel <= 0 && lineageDataCount <= 1){
                    returnResults = 0;
                    break;
                }
            }
        }
        else{
            
            if (lineageSaveFlag == 0){
                if (warningSkip == 0){
                    returnResults = 0;
                    break;
                }
                
                break;
            }
        }
    }
    
    return returnResults;
}

-(int)insertLineageMain:(int)connectNoAdd{
    int returnResults = 0;
    
    if (connectNoAdd > 0){
        ifstream fin;
        
        int maxLineageNo = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (arrayLineageStartEnd [counter1*8] > maxLineageNo) maxLineageNo = arrayLineageStartEnd [counter1*8];
        }
        
        if (maxLineageNo != 0){
            maxLineageNo++;
            
            string extension;
            string lineageNoExtension = to_string(imageNumberTrackForDisplay);
            
            if (lineageNoExtension.length() == 1) lineageNoExtension = "000"+lineageNoExtension;
            else if (lineageNoExtension.length() == 2) lineageNoExtension = "00"+lineageNoExtension;
            else if (lineageNoExtension.length() == 3) lineageNoExtension = "0"+lineageNoExtension;
            
            string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+lineageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
            string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                int modifyStartFlag = -1;
                int pointNoCount = 0;
                int pointGravityCenterCount = 0;
                int centerX = 0;
                int centerY = 0;
                int dataTemp = 0;
                int readingError = 0;
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int readBit [4];
                        
                        do{
                            
                            if (stepCount == 0){
                                readPosition = readPosition+5;
                                
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [7] == connectNoAdd && finData [13] == 0 && finData [16] == 0 && modifyStartFlag == -1){
                                    dataTemp = maxLineageNo;
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    uploadTemp [readPosition-1] = (uint8_t)readBit [2];
                                    uploadTemp [readPosition-2] = (uint8_t)readBit [1];
                                    uploadTemp [readPosition-3] = (uint8_t)readBit [0];
                                    uploadTemp [readPosition-4] = 1;
                                    uploadTemp [readPosition-5] = 0;
                                    uploadTemp [readPosition-6] = 0;
                                    uploadTemp [readPosition-7] = 0;
                                    uploadTemp [readPosition-8] = 0;
                                    uploadTemp [readPosition-9] = 0;
                                    
                                    pointNoCount++;
                                    modifyStartFlag = 1;
                                }
                                else if (finData [7] == connectNoAdd && finData [13] == 0 && finData [16] == 0 && modifyStartFlag == 1){
                                    uploadTemp [readPosition-1] = (uint8_t)readBit [2];
                                    uploadTemp [readPosition-2] = (uint8_t)readBit [1];
                                    uploadTemp [readPosition-3] = (uint8_t)readBit [0];
                                    uploadTemp [readPosition-4] = 1;
                                    uploadTemp [readPosition-5] = 0;
                                    uploadTemp [readPosition-6] = 0;
                                    uploadTemp [readPosition-7] = 0;
                                    uploadTemp [readPosition-8] = 0;
                                    uploadTemp [readPosition-9] = 0;
                                    
                                    pointNoCount++;
                                }
                                
                                if (finData [7] == 0 && finData [16] == 0) stepCount = 1;
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--5
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (pointGravityCenterCount+1 == connectNoAdd) centerX = finData [1], centerY = finData [3];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else pointGravityCenterCount++;
                            }
                            
                        } while (stepCount != 3);
                        
                    }
                    if (readingError == 0){
                        ofstream outfile (connectDataRevPath.c_str(), ofstream::binary);
                        outfile.write ((char*)uploadTemp, sizeForCopy);
                        outfile.close();
                    }
                }
                else{
                    
                    fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [11];
                        
                        uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp2, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp2 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-11]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp2, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp2 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp2, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp2 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-11]) != 0 ){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            unsigned long readPosition2 = 0;
                            int stepCount = 0;
                            int finData2 [5];
                            int readBit [4];
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [1] = uploadTemp2 [readPosition2], readPosition2++; //--2
                                    finData [2] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [3] = uploadTemp2 [readPosition2], readPosition2++; //--2
                                    finData [4] = uploadTemp2 [readPosition2], readPosition2++; //--1
                                    finData [5] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [6] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [7] = uploadTemp2 [readPosition2], readPosition2++; //--3
                                    finData [8] = uploadTemp2 [readPosition2], readPosition2++; //--1
                                    finData [9] = uploadTemp2 [readPosition2], readPosition2++;
                                    
                                    finData2 [0] = finData [0]*256+finData [1];
                                    finData2 [1] = finData [2]*256+finData [3];
                                    finData2 [2] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData2 [0] == 0 && finData2 [1] == 0 && finData2 [2] == 0){
                                        for (int counter1 = 0; counter1 < 17; counter1++) uploadTemp [readPosition] = 0, readPosition++;
                                        
                                        stepCount = 1;
                                    }
                                    else if (finData2 [2] == connectNoAdd && modifyStartFlag == -1){
                                        uploadTemp [readPosition] = (uint8_t)finData [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [1], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [2], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [3], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [4], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [5], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [6], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [7], readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        
                                        dataTemp = maxLineageNo;
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        uploadTemp [readPosition] = (uint8_t)readBit [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)readBit [1], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)readBit [2], readPosition++;
                                        
                                        modifyStartFlag = 1;
                                        pointNoCount++;
                                    }
                                    else if (finData2 [2] == connectNoAdd && modifyStartFlag == 1){
                                        uploadTemp [readPosition] = (uint8_t)finData [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [1], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [2], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [4], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [5], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [6], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [7], readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)readBit [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)readBit [1], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)readBit [2], readPosition++;
                                        
                                        pointNoCount++;
                                    }
                                    else{
                                        
                                        uploadTemp [readPosition] = (uint8_t)finData [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [1], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [2], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [3], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [4], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [5], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [6], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [7], readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        uploadTemp [readPosition] = 0, readPosition++;
                                        
                                        pointNoCount++;
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [1] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [2] = uploadTemp2 [readPosition2], readPosition2++; //--1
                                    finData [3] = uploadTemp2 [readPosition2], readPosition2++; //--2
                                    finData [4] = uploadTemp2 [readPosition2], readPosition2++; //--3
                                    finData [5] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [6] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [7] = uploadTemp2 [readPosition2], readPosition2++; //--4
                                    finData [8] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [9] = uploadTemp2 [readPosition2], readPosition2++; //--5
                                    finData [10] = uploadTemp2 [readPosition2], readPosition2++; //--6
                                    
                                    finData2 [0] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData2 [1] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData2 [2] = finData [8]*256+finData [9];
                                    
                                    if (finData2 [0] == 0 && finData2 [1] == 0 && finData2 [2] == 0){
                                        for (int counter1 = 0; counter1 < 11; counter1++) uploadTemp [readPosition] = 0, readPosition++;
                                        
                                        stepCount = 2;
                                    }
                                    else{
                                        
                                        uploadTemp [readPosition] = (uint8_t)finData [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [1], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [2], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [3], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [4], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [5], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [6], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [7], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [8], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [9], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [10], readPosition++; //--1
                                    }
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [1] = uploadTemp2 [readPosition2], readPosition2++; //--1
                                    finData [2] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [3] = uploadTemp2 [readPosition2], readPosition2++; //--2
                                    finData [4] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [5] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [6] = uploadTemp2 [readPosition2], readPosition2++; //--3
                                    finData [7] = uploadTemp2 [readPosition2], readPosition2++; //--4
                                    finData [8] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [9] = uploadTemp2 [readPosition2], readPosition2++;
                                    finData [10] = uploadTemp2 [readPosition2], readPosition2++; //--5
                                    
                                    finData2 [0] = finData [0]*256+finData [1];
                                    finData2 [1] = finData [2]*256+finData [3];
                                    finData2 [2] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData2 [3] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (pointGravityCenterCount+1 == connectNoAdd) centerX = finData2 [0], centerY = finData2 [1];
                                    
                                    if (finData2 [0] == 0 && finData2 [1] == 0 && finData2 [2] == 0){
                                        for (int counter1 = 0; counter1 < 12; counter1++) uploadTemp [readPosition] = 1, readPosition++;
                                        
                                        stepCount = 3;
                                    }
                                    else{
                                        
                                        uploadTemp [readPosition] = (uint8_t)finData [0], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [1], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [2], readPosition++;
                                        uploadTemp [readPosition] = (uint8_t)finData [3], readPosition++; //--2
                                        uploadTemp [readPosition] = (uint8_t)finData [4], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [5], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [6], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [7], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [8], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [9], readPosition++; //--1
                                        uploadTemp [readPosition] = (uint8_t)finData [10], readPosition++; //--1
                                        uploadTemp [readPosition] = 0, readPosition++; //--1
                                        
                                        pointGravityCenterCount++;
                                        
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp2;
                        
                        if (readingError == 0){
                            ofstream outfile (connectDataRevPath.c_str(), ofstream::binary);
                            outfile.write ((char*)uploadTemp, sizeForCopy);
                            outfile.close();
                        }
                    }
                }
                
                if (readingError == 0){
                    //-----Status UpLoad-----
                    string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                    
                    int *modifyStatusTemp = new int [pointGravityCenterCount*10+50];
                    int modifyStatusTempCount = 0;
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTempA, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [19];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                                finData [1] = uploadTempA [readPosition], readPosition++;
                                finData [2] = uploadTempA [readPosition], readPosition++;
                                finData [3] = uploadTempA [readPosition], readPosition++; //--3 Previous connect
                                finData [4] = uploadTempA [readPosition], readPosition++;
                                finData [5] = uploadTempA [readPosition], readPosition++;
                                finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                                finData [7] = uploadTempA [readPosition], readPosition++;
                                finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                                finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                                finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                                finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                                finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                                finData [13] = uploadTempA [readPosition], readPosition++;
                                finData [14] = uploadTempA [readPosition], readPosition++;
                                finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no
                                finData [16] = uploadTempA [readPosition], readPosition++;
                                finData [17] = uploadTempA [readPosition], readPosition++;
                                finData [18] = uploadTempA [readPosition], readPosition++; //--11 Lineage no
                                
                                finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [8] = finData [7]*256+finData [8];
                                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                
                                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                else{
                                    
                                    modifyStatusTemp [modifyStatusTempCount] = finData [0], modifyStatusTempCount++; //-----Selected, removed, eliminated status-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [3], modifyStatusTempCount++; //-----When new line is created, enter line number which creates-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [6], modifyStatusTempCount++; //-----PositionRevise Start-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [8], modifyStatusTempCount++; //-----Cut line number-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [9], modifyStatusTempCount++; //-----X Start-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [10], modifyStatusTempCount++; //-----X End-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [11], modifyStatusTempCount++; //-----Y Start-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [12], modifyStatusTempCount++; //-----Y End-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [15], modifyStatusTempCount++; //-----Connect-----
                                    modifyStatusTemp [modifyStatusTempCount] = finData [18], modifyStatusTempCount++; //-----Lineage-----
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTempA;
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < pointGravityCenterCount; counter1++){ //-----Counter number corresponds to connect No-----
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++; //-----Selected, removed, eliminated status-----
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++; //-----When new line is created, enter line number which creates-----
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++; //-----Top position of each connect-----
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++; //-----Cut line number-----
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++;
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++;
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++;
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++;
                            modifyStatusTemp [modifyStatusTempCount] = counter1+1, modifyStatusTempCount++;
                            modifyStatusTemp [modifyStatusTempCount] = 0, modifyStatusTempCount++;
                        }
                        
                        unsigned long readPosition = 0;
                        int positionNoCount = 0;
                        int stepCount = 0;
                        int finData [16];
                        int valueTemp = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                readPosition = readPosition+5;
                                
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                
                                readPosition = readPosition+3;
                                
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    if (finData [7] != valueTemp && finData [7] != 0){
                                        valueTemp = finData [7];
                                        modifyStatusTemp [(valueTemp-1)*10+2] = positionNoCount;
                                        
                                        if (finData [13] == 0) modifyStatusTemp [(valueTemp-1)*10] = 0;
                                    }
                                    
                                    positionNoCount++;
                                }
                            }
                            
                            
                        } while (stepCount != 3);
                    }
                    
                    modifyStatusTemp [(connectNoAdd-1)*10] = 7;
                    modifyStatusTemp [(connectNoAdd-1)*10+9] = maxLineageNo;
                    
                    //for (int counterA = 0; counterA < modifyStatusTempCount/10; counterA++){
                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<modifyStatusTemp [counterA*10+counterB];
                    //	cout<<" modifyStatusTemp "<<counterA<<endl;
                    //}
                    
                    char *writingArray = new char [modifyStatusTempCount/10*19+20];
                    
                    unsigned long indexCount = 0;
                    int readBit [4];
                    
                    for (int counter1 = 0; counter1 < modifyStatusTempCount/10; counter1++){
                        writingArray [indexCount] = (char)modifyStatusTemp [counter1*10], indexCount++;
                        
                        dataTemp = modifyStatusTemp [counter1*10+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = modifyStatusTemp [counter1*10+2];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = modifyStatusTemp [counter1*10+3];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)modifyStatusTemp [counter1*10+4], indexCount++;
                        writingArray [indexCount] = (char)modifyStatusTemp [counter1*10+5], indexCount++;
                        writingArray [indexCount] = (char)modifyStatusTemp [counter1*10+6], indexCount++;
                        writingArray [indexCount] = (char)modifyStatusTemp [counter1*10+7], indexCount++;
                        
                        dataTemp = modifyStatusTemp [counter1*10+8];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = modifyStatusTemp [counter1*10+9];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 19; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                    outfile2.write ((char*) writingArray, indexCount);
                    outfile2.close();
                    
                    delete [] modifyStatusTemp;
                    delete [] writingArray;
                    
                    //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target, 2: Dummy), 6. reserve=========
                    string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    int *modifyRelTemp = new int [sizeForCopy+50];
                    int modifyRelTempCount = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                        
                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTempA, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [19];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTempA [readPosition], readPosition++;
                                finData [1] = uploadTempA [readPosition], readPosition++;
                                finData [2] = uploadTempA [readPosition], readPosition++; //--1 Lineage no
                                finData [3] = uploadTempA [readPosition], readPosition++;
                                finData [4] = uploadTempA [readPosition], readPosition++;
                                finData [5] = uploadTempA [readPosition], readPosition++; //--3 Connect no
                                finData [6] = uploadTempA [readPosition], readPosition++;
                                finData [7] = uploadTempA [readPosition], readPosition++; //--4 Image no
                                finData [8] = uploadTempA [readPosition], readPosition++; //--5 +-
                                finData [9] = uploadTempA [readPosition], readPosition++;
                                finData [10] = uploadTempA [readPosition], readPosition++;
                                finData [11] = uploadTempA [readPosition], readPosition++;
                                finData [12] = uploadTempA [readPosition], readPosition++; //--6 Cell no
                                finData [13] = uploadTempA [readPosition], readPosition++; //--7 Target
                                finData [14] = uploadTempA [readPosition], readPosition++; //--8 Res
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    modifyRelTemp [modifyRelTempCount] = finData [2], modifyRelTempCount++;
                                    modifyRelTemp [modifyRelTempCount] = finData [5], modifyRelTempCount++;
                                    modifyRelTemp [modifyRelTempCount] = finData [7], modifyRelTempCount++;
                                    modifyRelTemp [modifyRelTempCount] = finData [12], modifyRelTempCount++;
                                    modifyRelTemp [modifyRelTempCount] = finData [13], modifyRelTempCount++;
                                    modifyRelTemp [modifyRelTempCount] = finData [14], modifyRelTempCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTempA;
                        
                        modifyRelTemp [modifyRelTempCount] = maxLineageNo, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = connectNoAdd, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = imageNumberTrackForDisplay, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = 0, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = 0, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = 0, modifyRelTempCount++;
                    }
                    else{
                        
                        modifyRelTemp [modifyRelTempCount] = maxLineageNo, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = connectNoAdd, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = imageNumberTrackForDisplay, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = 0, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = 0, modifyRelTempCount++;
                        modifyRelTemp [modifyRelTempCount] = 0, modifyRelTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < modifyRelTempCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<modifyRelTemp [counterA*6+counterB];
                    //	cout<<" modifyRelTemp "<<counterA<<endl;
                    //}
                    
                    writingArray = new char [modifyRelTempCount/6*16+16];
                    
                    indexCount = 0;
                    
                    for (int counter1 = 0; counter1 < modifyRelTempCount/6; counter1++){
                        dataTemp = modifyRelTemp [counter1*6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = modifyRelTemp [counter1*6+1];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = modifyRelTemp [counter1*6+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (modifyRelTemp [counter1*6+3] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = modifyRelTemp [counter1*6+3]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = modifyRelTemp [counter1*6+3];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        writingArray [indexCount] = (char)modifyRelTemp [counter1*6+4], indexCount++;
                        writingArray [indexCount] = (char)modifyRelTemp [counter1*6+5], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 15; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                    outfile3.write ((char*) writingArray, indexCount);
                    outfile3.close();
                    
                    delete [] writingArray;
                    delete [] modifyRelTemp;
                    
                    string mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+lineageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                    string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                    
                    if (stat(mapPath.c_str(), &sizeOfFile) == 0 && stat(revisedMapPath.c_str(), &sizeOfFile) == -1){
                        int imageDimensionSave = 0;
                        
                        for (int counter1 = 0; counter1 < imageSizeListCount/2; counter1++){
                            if (arrayImageSizeList [counter1*2] == treatmentNameHold){
                                imageDimensionSave = atoi(arrayImageSizeList [counter1*2+1].c_str());
                                break;
                            }
                        }
                        
                        int **revisedImageSave = new int *[imageDimensionSave+1];
                        for (int counter1 = 0; counter1 < imageDimensionSave+1; counter1++) revisedImageSave [counter1] = new int [imageDimensionSave+1];
                        
                        fin.open(mapPath.c_str(), ios::in | ios::binary);
                        
                        int totalSize = imageDimensionSave*imageDimensionSave*4;
                        
                        if (fin.is_open()){
                            uint8_t *upload2 = new uint8_t [totalSize+50];
                            
                            fin.read((char*)upload2, totalSize+50);
                            fin.close();
                            
                            int yDimensionCount = 0;
                            int xDimensionCount = 0;
                            int pixData = 0;
                            
                            for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                readBit [0] = upload2[counter1];
                                readBit [1] = upload2[counter1+1];
                                readBit [2] = upload2[counter1+2];
                                readBit [3] = upload2[counter1+3];
                                
                                pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                
                                for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                    revisedImageSave [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                }
                                
                                if (xDimensionCount == imageDimensionSave){
                                    xDimensionCount = 0;
                                    yDimensionCount++;
                                    
                                    if (yDimensionCount == imageDimensionSave){
                                        break;
                                    }
                                }
                            }
                            
                            delete [] upload2;
                        }
                        
                        char *dataHold = new char [totalSize];
                        indexCount = 0;
                        int dataTemp2 = 0;
                        int entryCount = 0;
                        
                        for (int counter1 = 0; counter1 < imageDimensionSave; counter1++){
                            for (int counter2 = 0; counter2 < imageDimensionSave; counter2++){
                                dataTemp = revisedImageSave [counter1][counter2];
                                
                                if (counter2 == 0) dataTemp2 = dataTemp, entryCount++;
                                else if (dataTemp != dataTemp2 || entryCount == 254 || counter2 == imageDimensionSave-1){
                                    readBit [0] = dataTemp2/65536;
                                    dataTemp2 = dataTemp2%65536;
                                    readBit [1] = dataTemp2/256;
                                    dataTemp2 = dataTemp2%256;
                                    readBit [2] = dataTemp2;
                                    
                                    if (counter2 == imageDimensionSave-1){
                                        if (dataTemp != dataTemp2){
                                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                                            dataHold [indexCount] = (char)entryCount, indexCount++;
                                            
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            entryCount = 1;
                                            
                                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                                            dataHold [indexCount] = (char)entryCount, indexCount++;
                                        }
                                        else{
                                            
                                            entryCount++;
                                            
                                            dataHold [indexCount] = (char)readBit [0], indexCount++;
                                            dataHold [indexCount] = (char)readBit [1], indexCount++;
                                            dataHold [indexCount] = (char)readBit [2], indexCount++;
                                            dataHold [indexCount] = (char)entryCount, indexCount++;
                                        }
                                    }
                                    else{
                                        
                                        dataHold [indexCount] = (char)readBit [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                    
                                    if (counter2 == imageDimensionSave-1) entryCount = 0;
                                    else{
                                        
                                        entryCount = 1;
                                        dataTemp2 = dataTemp;
                                    }
                                }
                                else entryCount++;
                            }
                        }
                        
                        ofstream outfile4 (revisedMapPath.c_str(), ofstream::binary);
                        outfile4.write(dataHold, indexCount);
                        outfile4.close();
                        
                        delete [] dataHold;
                        
                        for (int counter1 = 0; counter1 < imageDimensionSave+1; counter1++) delete [] revisedImageSave [counter1];
                        
                        delete [] revisedImageSave;
                    }
                    
                    //-----Save Previous Time, if it is not created-----
                    string imageNoExtension;
                    
                    unsigned long readPosition2 = 0;
                    unsigned long readPosition3 = 0;
                    int finData [19];
                    int finData2 [10];
                    int entryGCCount = 0;
                    int stepCount = 0;
                    int modifyDataTempCount5 = 0;
                    int positionNoCount = 0;
                    int valueTemp = 0;
                    int imageDimensionSave = 0;
                    int totalSize = 0;
                    int yDimensionCount = 0;
                    int xDimensionCount = 0;
                    int pixData = 0;
                    int dataTemp2 = 0;
                    int entryCount = 0;
                    int modifyMasterTempCount = 0;
                    
                    for (int counter1 = timeOneHold; counter1 < imageNumberTrackForDisplay; counter1++){
                        imageNoExtension = to_string(counter1);
                        
                        if (imageNoExtension.length() == 1) imageNoExtension = "000"+imageNoExtension;
                        else if (imageNoExtension.length() == 2) imageNoExtension = "00"+imageNoExtension;
                        else if (imageNoExtension.length() == 3) imageNoExtension = "0"+imageNoExtension;
                        
                        connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+imageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                        connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                        connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                        mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+imageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                        revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+imageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        
                        for (int counter3 = 0; counter3 < 6; counter3++){
                            sizeForCopy = 0;
                            
                            if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter3 == 0) size1 = sizeForCopy;
                                else if (counter3 == 1) size2 = sizeForCopy;
                                else if (counter3 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter3 == 3) size1 = sizeForCopy;
                                else if (counter3 == 4) size2 = sizeForCopy;
                                else if (counter3 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        if (checkFlag == 0){
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter3 = 0; counter3 < 6; counter3++){
                                sizeForCopy = 0;
                                
                                if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter3 == 0) size1 = sizeForCopy;
                                    else if (counter3 == 1) size2 = sizeForCopy;
                                    else if (counter3 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter3 == 3) size1 = sizeForCopy;
                                    else if (counter3 == 4) size2 = sizeForCopy;
                                    else if (counter3 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            sizeForCopy = (long)(sizeForCopy*(double)1.6+50);
                            
                            uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                            
                            readingError = 0;
                            
                            if (checkFlag == 1){
                                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    int *modifyMasterTemp = new int [sizeForCopy+50];
                                    modifyMasterTempCount = 0;
                                    
                                    uint8_t *uploadTemp3 = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp3, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp3 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp3, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp3 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp3, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp3 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp3 [sizeForCopy-12]) != 0){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition2 = 0;
                                        readPosition3 = 0;
                                        entryGCCount = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [1] = uploadTemp3 [readPosition3], readPosition3++; //--2
                                                finData [2] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [3] = uploadTemp3 [readPosition3], readPosition3++; //--2
                                                finData [4] = uploadTemp3 [readPosition3], readPosition3++; //--1
                                                finData [5] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [6] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [7] = uploadTemp3 [readPosition3], readPosition3++; //--3
                                                finData [8] = uploadTemp3 [readPosition3], readPosition3++; //--1
                                                finData [9] = uploadTemp3 [readPosition3], readPosition3++; //--1
                                                
                                                finData2 [0] = finData [0]*256+finData [1];
                                                finData2 [1] = finData [2]*256+finData [3];
                                                finData2 [2] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData2 [0] == 0 && finData2 [1] == 0 && finData2 [2] == 0){
                                                    for (int counter2 = 0; counter2 < 17; counter2++) uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    
                                                    stepCount = 1;
                                                }
                                                else{
                                                    
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [0], readPosition2++;
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [1], readPosition2++; //--2
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [2], readPosition2++;
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [3], readPosition2++; //--2
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [4], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [5], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [6], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [7], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                }
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [1] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [2] = uploadTemp3 [readPosition3], readPosition3++; //--1
                                                finData [3] = uploadTemp3 [readPosition3], readPosition3++; //--2
                                                finData [4] = uploadTemp3 [readPosition3], readPosition3++; //--3
                                                finData [5] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [6] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [7] = uploadTemp3 [readPosition3], readPosition3++; //--4
                                                finData [8] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [9] = uploadTemp3 [readPosition3], readPosition3++; //--5
                                                finData [10] = uploadTemp3 [readPosition3], readPosition3++; //--6
                                                
                                                finData2 [0] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData2 [1] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData2 [2] = finData [8]*256+finData [9];
                                                
                                                if (finData2 [0] == 0 && finData2 [1] == 0 && finData2 [3] == 0){
                                                    for (int counter2 = 0; counter2 < 11; counter2++) uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    
                                                    stepCount = 2;
                                                }
                                                else{
                                                    
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [0], readPosition2++;
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [1], readPosition2++; //--2
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [2], readPosition2++;
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [3], readPosition2++; //--2
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [4], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [5], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [6], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [7], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [8], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [9], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [10], readPosition2++; //--1
                                                }
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [1] = uploadTemp3 [readPosition3], readPosition3++; //--1
                                                finData [2] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [3] = uploadTemp3 [readPosition3], readPosition3++; //--2
                                                finData [4] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [5] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [6] = uploadTemp3 [readPosition3], readPosition3++; //--3
                                                finData [7] = uploadTemp3 [readPosition3], readPosition3++; //--4
                                                finData [8] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [9] = uploadTemp3 [readPosition3], readPosition3++;
                                                finData [10] = uploadTemp3 [readPosition3], readPosition3++; //--5
                                                
                                                finData2 [0] = finData [0]*256+finData [1];
                                                finData2 [1] = finData [2]*256+finData [3];
                                                finData2 [2] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData2 [3] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData2 [0] == 0 && finData2 [1] == 0 && finData2 [2] == 0){
                                                    for (int counter2 = 0; counter2 < 12; counter2++) uploadTemp2 [readPosition2] = 0, readPosition2++;
                                                    
                                                    stepCount = 3;
                                                }
                                                else{
                                                    
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [0], readPosition2++;
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [1], readPosition2++; //--2
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [2], readPosition2++;
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [3], readPosition2++; //--2
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [4], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [5], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [6], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [7], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [8], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [9], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = (uint8_t)finData [10], readPosition2++; //--1
                                                    uploadTemp2 [readPosition2] = 0, readPosition2++; //--1
                                                    
                                                    entryGCCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                    }
                                    
                                    delete [] uploadTemp3;
                                    
                                    ofstream outfile4 (connectDataRevPath.c_str(), ofstream::binary);
                                    outfile4.write ((char*)uploadTemp2, sizeForCopy);
                                    outfile4.close();
                                    
                                    //for (int counterA = 0; counterA < modifyDataTempCount/7; counterA++){
                                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<modifyDataTemp [counterA*7+counterB];
                                    //	cout<<" modifyDataTemp "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < modifyDataTempCount3/6; counterA++){
                                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<modifyDataTemp3 [counterA*6+counterB];
                                    //	cout<<" modifyDataTemp3 "<<counterA<<endl;
                                    //}
                                    
                                    int *modifyDataTemp5 = new int [entryGCCount*10+50];
                                    modifyDataTempCount5 = 0;
                                    
                                    for (int counter2 = 0; counter2 < entryGCCount; counter2++){ //-----Counter number corresponds to connect No-----
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++; //-----Selected, removed, eliminated status-----
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++; //-----When new line is created, enter line number which creates-----
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++; //-----Top position of each connect-----
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++; //-----Cut line number-----
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++;
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++;
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++;
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++;
                                        modifyDataTemp5 [modifyDataTempCount5] = counter2+1, modifyDataTempCount5++;
                                        modifyDataTemp5 [modifyDataTempCount5] = 0, modifyDataTempCount5++;
                                    }
                                    
                                    readPosition2 = 0;
                                    positionNoCount = 0;
                                    stepCount = 0;
                                    valueTemp = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            readPosition2 =readPosition2+5;
                                            
                                            finData [5] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [6] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [7] = uploadTemp2 [readPosition2], readPosition2++; //--4
                                            finData [8] = uploadTemp2 [readPosition2], readPosition2++; //--+/- Flag
                                            finData [9] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [10] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [11] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [12] = uploadTemp2 [readPosition2], readPosition2++; //--5 Cell no
                                            finData [13] = uploadTemp2 [readPosition2], readPosition2++; //--6 Status
                                            finData [14] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [15] = uploadTemp2 [readPosition2], readPosition2++;
                                            finData [16] = uploadTemp2 [readPosition2], readPosition2++; //--7 Lineage no
                                            
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                if (finData [7] != valueTemp && finData [7] != 0){
                                                    valueTemp = finData [7];
                                                    modifyMasterTemp [(valueTemp-1)*10+2] = positionNoCount;
                                                    
                                                    if (finData [13] == 0) modifyMasterTemp [(valueTemp-1)*10] = 0;
                                                }
                                                
                                                positionNoCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    //for (int counterA = 0; counterA < modifyDataTempCount5/10; counterA++){
                                    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<modifyDataTemp5 [counterA*10+counterB];
                                    //	cout<<" modifyDataTemp5 "<<counterA<<endl;
                                    //}
                                    
                                    modifyMasterTemp [(connectNoAdd-1)*10+9] = maxLineageNo;
                                    
                                    writingArray = new char [modifyMasterTempCount/10*19+20];
                                    
                                    indexCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < modifyMasterTempCount/10; counter2++){
                                        writingArray [indexCount] = (char)modifyMasterTemp [counter2*10], indexCount++;
                                        
                                        dataTemp = modifyMasterTemp [counter2*10+1];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = modifyMasterTemp [counter2*10+2];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = modifyMasterTemp [counter2*10+3];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        writingArray [indexCount] = (char)modifyMasterTemp [counter2*10+4], indexCount++;
                                        writingArray [indexCount] = (char)modifyMasterTemp [counter2*10+5], indexCount++;
                                        writingArray [indexCount] = (char)modifyMasterTemp [counter2*10+6], indexCount++;
                                        writingArray [indexCount] = (char)modifyMasterTemp [counter2*10+7], indexCount++;
                                        
                                        dataTemp = modifyMasterTemp [counter2*10+8];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = modifyMasterTemp [counter2*10+9];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter2 = 0; counter2 < 19; counter2++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile5 (connectStatusDataPath.c_str(), ofstream::binary);
                                    outfile5.write ((char*)writingArray, sizeForCopy);
                                    outfile5.close();
                                    
                                    delete [] writingArray;
                                    delete [] modifyDataTemp5;
                                    
                                    writingArray = new char [30];
                                    
                                    indexCount = 0;
                                    
                                    dataTemp = maxLineageNo;
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = 0;
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = counter1;
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = 1;
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    writingArray [indexCount] = 2, indexCount++;
                                    writingArray [indexCount] = 0, indexCount++;
                                    
                                    for (int counter2 = 0; counter2 < 15; counter2++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile6 (connectRelationPath.c_str(), ofstream::binary);
                                    outfile6.write ((char*) writingArray, indexCount);
                                    outfile6.close();
                                    
                                    delete [] writingArray;
                                    delete [] modifyMasterTemp;
                                }
                            }
                            
                            delete [] uploadTemp2;
                            
                            if (stat(mapPath.c_str(), &sizeOfFile) == 0 && stat(revisedMapPath.c_str(), &sizeOfFile) == -1){
                                imageDimensionSave = 0;
                                
                                for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                                    if (arrayImageSizeList [counter2*2] == treatmentNameHold){
                                        imageDimensionSave = atoi(arrayImageSizeList [counter2*2+1].c_str());
                                        break;
                                    }
                                }
                                
                                int **revisedImageSave = new int *[imageDimensionSave+1];
                                for (int counter2 = 0; counter2 < imageDimensionSave+1; counter2++) revisedImageSave [counter2] = new int [imageDimensionSave+1];
                                
                                fin.open(mapPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    totalSize = imageDimensionSave*imageDimensionSave*4;
                                    
                                    uint8_t *upload2 = new uint8_t [totalSize+50];
                                    fin.read((char*)upload2, totalSize+50);
                                    fin.close();
                                    
                                    yDimensionCount = 0;
                                    xDimensionCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < totalSize; counter2 = counter2+4){
                                        readBit [0] = upload2[counter2];
                                        readBit [1] = upload2[counter2+1];
                                        readBit [2] = upload2[counter2+2];
                                        readBit [3] = upload2[counter2+3];
                                        
                                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                        
                                        for (int counter3 = 0; counter3 < readBit [3]; counter3++){
                                            
                                            revisedImageSave [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                        }
                                        
                                        if (xDimensionCount == imageDimensionSave){
                                            xDimensionCount = 0;
                                            yDimensionCount++;
                                            
                                            if (yDimensionCount == imageDimensionSave){
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] upload2;
                                }
                                
                                char *dataHold = new char [totalSize];
                                indexCount = 0;
                                
                                dataTemp2 = 0;
                                entryCount = 0;
                                
                                for (int counter2 = 0; counter2 < imageDimensionSave; counter2++){
                                    for (int counter3 = 0; counter3 < imageDimensionSave; counter3++){
                                        dataTemp = revisedImageSave [counter2][counter3];
                                        
                                        if (counter3 == 0) dataTemp2 = dataTemp, entryCount++;
                                        else if (dataTemp != dataTemp2 || entryCount == 254 || counter3 == imageDimensionSave-1){
                                            readBit [0] = dataTemp2/65536;
                                            dataTemp2 = dataTemp2%65536;
                                            readBit [1] = dataTemp2/256;
                                            dataTemp2 = dataTemp2%256;
                                            readBit [2] = dataTemp2;
                                            
                                            if (counter2 == imageDimensionSave-1){
                                                if (dataTemp != dataTemp2){
                                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                    
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    entryCount = 1;
                                                    
                                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                }
                                                else{
                                                    
                                                    entryCount++;
                                                    
                                                    dataHold [indexCount] = (char)readBit [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                }
                                            }
                                            else{
                                                
                                                dataHold [indexCount] = (char)readBit [0], indexCount++;
                                                dataHold [indexCount] = (char)readBit [1], indexCount++;
                                                dataHold [indexCount] = (char)readBit [2], indexCount++;
                                                dataHold [indexCount] = (char)entryCount, indexCount++;
                                            }
                                            
                                            if (counter3 == imageDimensionSave-1) entryCount = 0;
                                            else{
                                                
                                                entryCount = 1;
                                                dataTemp2 = dataTemp;
                                            }
                                        }
                                        else entryCount++;
                                    }
                                }
                                
                                ofstream outfile4 (revisedMapPath.c_str(), ofstream::binary);
                                outfile4.write(dataHold, indexCount);
                                outfile4.close();
                                
                                delete [] dataHold;
                                
                                for (int counter2 = 0; counter2 < imageDimensionSave+1; counter2++) delete [] revisedImageSave [counter2];
                                
                                delete [] revisedImageSave;
                            }
                        }
                    }
                    
                    //-----1. X position, 2. Y position, 3. Time point, 4. Event Type, 5. Next Cell number, Fusion: hold cell number of Fusion partner-----
                    //-----6. Cell Number, 7. Cell Lineage Number, 8. For Fusion, Cell lineage Number-----
                    
                    string connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
                    
                    int *modifyLingDataTemp = new int [lineageDataCount+imageNumberTrackForDisplay*8+50];
                    int modifyLingDataTempCount = 0;
                    
                    //for (int counterA = 0; counterA < modifyDataTempCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<modifyDataTemp [counterA*8+counterB];
                    //	cout<<" modifyDataTemp "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < lineageDataCount; counter1++) modifyLingDataTemp [modifyLingDataTempCount] = arrayLineageData [counter1], modifyLingDataTempCount++;
                    
                    //for (int counterA = 0; counterA < modifyLingDataTempCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<modifyLingDataTemp [counterA*8+counterB];
                    //	cout<<" modifyLingDataTemp "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = timeOneHold; counter1 <= imageNumberTrackForDisplay; counter1++){
                        if (counter1 == imageNumberTrackForDisplay){
                            modifyLingDataTemp [modifyLingDataTempCount] = centerX, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = centerY, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = imageNumberTrackForDisplay, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 1, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 0, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 0, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = maxLineageNo, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 0, modifyLingDataTempCount++;
                        }
                        else{
                            
                            modifyLingDataTemp [modifyLingDataTempCount] = -1, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = -1, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = counter1, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 13, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 0, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = -1, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = maxLineageNo, modifyLingDataTempCount++;
                            modifyLingDataTemp [modifyLingDataTempCount] = 0, modifyLingDataTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < modifyDataTempCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<modifyDataTemp [counterA*8+counterB];
                    //	cout<<" modifyDataTemp "<<counterA<<endl;
                    //}
                    
                    if (lineageDataStatus == 1) delete [] arrayLineageData;
                    arrayLineageData = new int [modifyLingDataTempCount+50];
                    lineageDataCount = 0;
                    lineageDataLimit = modifyLingDataTempCount+50;
                    lineageDataStatus = 1;
                    
                    for (int counter1 = 0; counter1 < modifyLingDataTempCount; counter1++) arrayLineageData [lineageDataCount] = modifyLingDataTemp [counter1], lineageDataCount++;
                    
                    writingArray = new char [lineageDataCount/8*25+25];
                    
                    indexCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        if (arrayLineageData [counter1*8+1] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+1]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+1];
                        }
                        
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = arrayLineageData [counter1*8+2];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)arrayLineageData [counter1*8+3], indexCount++;
                        
                        if (arrayLineageData [counter1*8+4] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+4]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+4];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        if (arrayLineageData [counter1*8+5] < 0){
                            writingArray [indexCount] = 1, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+5]*-1;
                        }
                        else{
                            
                            writingArray [indexCount] = 0, indexCount++;
                            dataTemp = arrayLineageData [counter1*8+5];
                        }
                        
                        readBit [0] = dataTemp/16777216;
                        dataTemp = dataTemp%16777216;
                        readBit [1] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [2] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [3] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                        
                        dataTemp = arrayLineageData [counter1*8+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = arrayLineageData [counter1*8+7];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                    
                    for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile4 (connectDataLineagePath.c_str(), ofstream::binary);
                    outfile4.write ((char*) writingArray, indexCount);
                    outfile4.close();
                    
                    delete [] writingArray;
                    delete [] modifyLingDataTemp;
                    
                    //-----Lineage Start/End List-----
                    //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                    
                    lineageStartEndCount = 0;
                    int cellNumberStart = -1;
                    int lineageNumberStart = 0;
                    int firstEntryFind = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                            lineageNumberStart = arrayLineageData [counter1*8+6];
                            cellNumberStart = arrayLineageData [counter1*8+5];
                            
                            arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                            
                            firstEntryFind = 1;
                        }
                        else if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                            lineageNumberStart = arrayLineageData [counter1*8+6];
                            cellNumberStart = arrayLineageData [counter1*8+5];
                            
                            arrayLineageStartEnd [lineageStartEndCount] = counter1-1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter1-1)*8+2], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                        }
                        
                        if (counter1 == lineageDataCount/8-1){
                            arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                            arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                        }
                        
                        if (lineageStartEndCount+24 > lineageStartEndLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate lineageStartEndUpDate];
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                    //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
                    //}
                    
                    if (lineageStartEndCount != 0){
                        char *mainDataEntry = new char [lineageStartEndCount*7+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++){
                            extension = to_string(arrayLineageStartEnd [counter1]);
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile5 (connectStartEndPath.c_str(), ofstream::binary);
                        outfile5.write (mainDataEntry, totalEntryCount);
                        outfile5.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                    string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
                    
                    int *modifyLingStatusDataTemp = new int [cellLineageInfoCount+50];
                    int modifyLingStatusDataTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < cellLineageInfoCount; counter1++) modifyLingStatusDataTemp [modifyLingStatusDataTempCount] = arrayCellLineageInfo [counter1], modifyLingStatusDataTempCount++;
                    
                    modifyLingStatusDataTemp [modifyLingStatusDataTempCount] = maxLineageNo, modifyLingStatusDataTempCount++;
                    modifyLingStatusDataTemp [modifyLingStatusDataTempCount] = 0, modifyLingStatusDataTempCount++;
                    modifyLingStatusDataTemp [modifyLingStatusDataTempCount] = 1, modifyLingStatusDataTempCount++;
                    
                    //for (int counterA = 0; counterA < modifyLingStatusDataTempCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<modifyLingStatusDataTemp [counterA*3+counterB];
                    //	cout<<" modifyLingStatusDataTemp "<<counterA<<endl;
                    //}
                    
                    if (cellLineageInfoStatus == 1) delete [] arrayCellLineageInfo;
                    arrayCellLineageInfo = new int [modifyLingStatusDataTempCount+50], cellLineageInfoCount = 0, cellLineageInfoLimit = modifyLingStatusDataTempCount+50, cellLineageInfoStatus = 1;
                    
                    for (int counter1 = 0; counter1 < modifyLingStatusDataTempCount; counter1++) arrayCellLineageInfo [cellLineageInfoCount] = modifyLingStatusDataTemp [counter1], cellLineageInfoCount++;
                    
                    char *mainDataEntry = new char [modifyLingStatusDataTempCount*6+10];
                    int totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < modifyLingStatusDataTempCount; counter1++){
                        extension = to_string(modifyLingStatusDataTemp [counter1]);
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile5 (connectDataInfoPath.c_str(), ofstream::binary);
                    outfile5.write (mainDataEntry, totalEntryCount);
                    outfile5.close();
                    
                    delete [] mainDataEntry;
                    delete [] modifyLingStatusDataTemp;
                    
                    //=========Queue List creation==========
                    //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Status, 6. Processing status-----
                    //-----Status: MANU, EVAL-----
                    //-----Processing Status: WAIT, PROC, PEND-----
                    
                    if (queueListCount+12 > queueListLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate queueListUpDate];
                    }
                    
                    arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
                    
                    string cellLineageString = to_string(maxLineageNo);
                    
                    if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
                    else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
                    else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
                    else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
                    else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
                    
                    arrayQueueList [queueListCount] = cellLineageString, queueListCount++;
                    arrayQueueList [queueListCount] = "C000000000", queueListCount++;
                    
                    extension = to_string(imageNumberTrackForDisplay);
                    
                    arrayQueueList [queueListCount] = extension+":"+extension, queueListCount++;
                    arrayQueueList [queueListCount] = "0", queueListCount++;
                    arrayQueueList [queueListCount] = "Wait", queueListCount++;
                    
                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                    
                    if (queueListCount != 0){
                        mainDataEntry = new char [queueListCount*12+10];
                        totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < queueListCount; counter1++){
                            extension = arrayQueueList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile6 (queueListPath.c_str(), ofstream::binary);
                        outfile6.write (mainDataEntry, totalEntryCount);
                        outfile6.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    //-----Folder creation-----
                    string lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageString;
                    mkdir(lineageFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string cellFolderPath = lineageFolderPath+"/C000000000";
                    mkdir(cellFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string lineageFolderPath2 = lineageFolderPath+"/"+analysisID+"_"+cellLineageString+"_CellStatus";
                    
                    ofstream oin;
                    oin.open(lineageFolderPath2.c_str(), ios::out);
                    oin<<0<<endl;
                    oin<<imageNumberTrackForDisplay<<endl;
                    oin<<-1<<endl;
                    oin<<1<<endl;
                    oin<<0<<endl;
                    oin<<0<<endl;
                    oin<<maxLineageNo<<endl;
                    oin<<"End"<<endl;
                    oin.close();
                    
                    //-----LINE DATA AMEND-----
                    //-----1. Image No, 2, X position, 3 Y position, 4. Value, 5. Connect No, 6. Lineage NO-----
                    
                    lineageFolderPath2 = cellFolderPath+"/"+analysisID+"_"+cellLineageString+"_lineDataAmend";
                    
                    //for (int counterA = 0; counterA < modifyDataTempCount4/7; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<modifyDataTemp4 [counterA*7+counterB];
                    //	cout<<" modifyDataTemp4 "<<counterA<<endl;
                    //}
                    
                    indexCount = 0;
                    unsigned long readPosition = 0;
                    int lastZeroEntry = 0;
                    
                    modifyStartFlag = -1;
                    
                    writingArray = new char [pointNoCount*15+1];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            
                            readPosition = readPosition+9;
                            
                            finData2 [0] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData2 [0] == 0){
                                stepCount = 3;
                                
                                if (lastZeroEntry == 0){
                                    for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                                }
                            }
                            else{
                                
                                if (finData2 [0] == connectNoAdd && modifyStartFlag == -1){
                                    dataTemp = imageNumberTrackForDisplay;
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)finData [0], indexCount++;
                                    writingArray [indexCount] = (char)finData [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)finData [2], indexCount++;
                                    writingArray [indexCount] = (char)finData [3], indexCount++;
                                    
                                    writingArray [indexCount] = 1, indexCount++;
                                    
                                    writingArray [indexCount] = (char)finData [5], indexCount++;
                                    writingArray [indexCount] = (char)finData [6], indexCount++;
                                    writingArray [indexCount] = (char)finData [7], indexCount++;
                                    
                                    dataTemp = maxLineageNo;
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    modifyStartFlag = 1;
                                }
                                else if (finData2 [0] == connectNoAdd && modifyStartFlag == 1){
                                    dataTemp = imageNumberTrackForDisplay;
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)finData [0], indexCount++;
                                    writingArray [indexCount] = (char)finData [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)finData [2], indexCount++;
                                    writingArray [indexCount] = (char)finData [3], indexCount++;
                                    
                                    writingArray [indexCount] = 1, indexCount++;
                                    
                                    writingArray [indexCount] = (char)finData [5], indexCount++;
                                    writingArray [indexCount] = (char)finData [6], indexCount++;
                                    writingArray [indexCount] = (char)finData [7], indexCount++;
                                    
                                    dataTemp = maxLineageNo;
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                else if (finData2 [0] != connectNoAdd && modifyStartFlag == 1){
                                    for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    modifyStartFlag = 2;
                                    lastZeroEntry = 1;
                                }
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    ofstream outfile7 (lineageFolderPath2.c_str(), ofstream::binary);
                    outfile7.write ((char*)writingArray, indexCount);
                    outfile7.close();
                    
                    delete [] writingArray;
                    
                    //==========Fluorescent Expand============
                    if (fluorescentDetectionDisplay == 1){
                        connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+lineageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
                        connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        
                        for (int counter3 = 0; counter3 < 6; counter3++){
                            sizeForCopy = 0;
                            
                            if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter3 == 0) size1 = sizeForCopy;
                                else if (counter3 == 1) size2 = sizeForCopy;
                                else if (counter3 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter3 == 3) size1 = sizeForCopy;
                                else if (counter3 == 4) size2 = sizeForCopy;
                                else if (counter3 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        if (checkFlag == 1){
                            arrayPositionRevise = new int [sizeForCopy+50];
                            positionReviseCount = 0;
                            positionReviseLimit = (int)sizeForCopy+50;
                            
                            int gravityCenterRevTempCount = 0;
                            
                            //-----Master Data upLoad-----
                            fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTempA, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 || (finData [0] = uploadTempA [sizeForCopy-12]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTempA [readPosition], readPosition++;
                                            finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                            finData [2] = uploadTempA [readPosition], readPosition++;
                                            finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                            finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                            finData [5] = uploadTempA [readPosition], readPosition++;
                                            finData [6] = uploadTempA [readPosition], readPosition++;
                                            finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                            finData [8] = uploadTempA [readPosition], readPosition++; //--+/- Flag
                                            finData [9] = uploadTempA [readPosition], readPosition++;
                                            finData [10] = uploadTempA [readPosition], readPosition++;
                                            finData [11] = uploadTempA [readPosition], readPosition++;
                                            finData [12] = uploadTempA [readPosition], readPosition++; //--5 Cell no
                                            finData [13] = uploadTempA [readPosition], readPosition++; //--6 Status
                                            finData [14] = uploadTempA [readPosition], readPosition++;
                                            finData [15] = uploadTempA [readPosition], readPosition++;
                                            finData [16] = uploadTempA [readPosition], readPosition++; //--7 Lineage no
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                            
                                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                            else{
                                                
                                                arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                                arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                                arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                                arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                                arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                                arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                                arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                            }
                                        }
                                        else if (stepCount == 1){
                                            finData [0] = uploadTempA [readPosition], readPosition++;
                                            finData [1] = uploadTempA [readPosition], readPosition++;
                                            finData [2] = uploadTempA [readPosition], readPosition++; //--1
                                            finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                            finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                            finData [5] = uploadTempA [readPosition], readPosition++;
                                            finData [6] = uploadTempA [readPosition], readPosition++;
                                            finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                            finData [8] = uploadTempA [readPosition], readPosition++;
                                            finData [9] = uploadTempA [readPosition], readPosition++; //--5
                                            finData [10] = uploadTempA [readPosition], readPosition++; //--6
                                            
                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            finData [9] = finData [8]*256+finData [9];
                                            
                                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                        }
                                        else if (stepCount == 2){
                                            finData [0] = uploadTempA [readPosition], readPosition++;
                                            finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                            finData [2] = uploadTempA [readPosition], readPosition++;
                                            finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                            finData [4] = uploadTempA [readPosition], readPosition++;
                                            finData [5] = uploadTempA [readPosition], readPosition++;
                                            finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                            finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                            finData [8] = uploadTempA [readPosition], readPosition++;
                                            finData [9] = uploadTempA [readPosition], readPosition++;
                                            finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                            finData [11] = uploadTempA [readPosition], readPosition++; //--6
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                            else gravityCenterRevTempCount = gravityCenterRevTempCount+6;
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTempA;
                            }
                            else{
                                
                                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTempA, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTempA, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTempA [sizeForCopy-1]) != 0 || (finData [0] = uploadTempA [sizeForCopy-2]) != 0 || (finData [0] = uploadTempA [sizeForCopy-3]) != 0 || (finData [0] = uploadTempA [sizeForCopy-4]) != 0 || (finData [0] = uploadTempA [sizeForCopy-5]) != 0 || (finData [0] = uploadTempA [sizeForCopy-6]) != 0 || (finData [0] = uploadTempA [sizeForCopy-7]) != 0 || (finData [0] = uploadTempA [sizeForCopy-8]) != 0 || (finData [0] = uploadTempA [sizeForCopy-9]) != 0 || (finData [0] = uploadTempA [sizeForCopy-10]) != 0 || (finData [0] = uploadTempA [sizeForCopy-11]) != 0 ){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTempA [readPosition], readPosition++;
                                                finData [1] = uploadTempA [readPosition], readPosition++; //--2
                                                finData [2] = uploadTempA [readPosition], readPosition++;
                                                finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                finData [4] = uploadTempA [readPosition], readPosition++; //--1
                                                finData [5] = uploadTempA [readPosition], readPosition++;
                                                finData [6] = uploadTempA [readPosition], readPosition++;
                                                finData [7] = uploadTempA [readPosition], readPosition++; //--3
                                                finData [8] = uploadTempA [readPosition], readPosition++; //--1
                                                finData [9] = uploadTempA [readPosition], readPosition++;
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                else{
                                                    
                                                    arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //-----X Position-----
                                                    arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //-----Y Position-----
                                                    arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //-----Value-----
                                                    arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //-----Connect No-----
                                                    arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Cell No-----
                                                    arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Status-----
                                                    arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Lineage no-----
                                                }
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTempA [readPosition], readPosition++;
                                                finData [1] = uploadTempA [readPosition], readPosition++;
                                                finData [2] = uploadTempA [readPosition], readPosition++; //--1
                                                finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                finData [4] = uploadTempA [readPosition], readPosition++; //--3
                                                finData [5] = uploadTempA [readPosition], readPosition++;
                                                finData [6] = uploadTempA [readPosition], readPosition++;
                                                finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                                finData [8] = uploadTempA [readPosition], readPosition++;
                                                finData [9] = uploadTempA [readPosition], readPosition++; //--5
                                                finData [10] = uploadTempA [readPosition], readPosition++; //--6
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData [9] = finData [8]*256+finData [9];
                                                
                                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                                
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTempA [readPosition], readPosition++;
                                                finData [1] = uploadTempA [readPosition], readPosition++; //--1
                                                finData [2] = uploadTempA [readPosition], readPosition++;
                                                finData [3] = uploadTempA [readPosition], readPosition++; //--2
                                                finData [4] = uploadTempA [readPosition], readPosition++;
                                                finData [5] = uploadTempA [readPosition], readPosition++;
                                                finData [6] = uploadTempA [readPosition], readPosition++; //--3
                                                finData [7] = uploadTempA [readPosition], readPosition++; //--4
                                                finData [8] = uploadTempA [readPosition], readPosition++;
                                                finData [9] = uploadTempA [readPosition], readPosition++;
                                                finData [10] = uploadTempA [readPosition], readPosition++; //--5
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                                else gravityCenterRevTempCount = gravityCenterRevTempCount+6;
                                            }
                                            
                                        } while (stepCount != 3);
                                    }
                                    
                                    delete [] uploadTempA;
                                }
                            }
                            
                            //-----Master Data Status UpLoad-----
                            connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            arrayTimeSelected = new int [sizeForCopy+50];
                            timeSelectedCount = 0;
                            timeSelectedLimit = (int)sizeForCopy+50;
                            
                            if (sizeForCopy != 0){
                                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                                
                                uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTempA, sizeForCopy+50);
                                fin.close();
                                
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                                        finData [1] = uploadTempA [readPosition], readPosition++;
                                        finData [2] = uploadTempA [readPosition], readPosition++;
                                        finData [3] = uploadTempA [readPosition], readPosition++; //--3 Previous connect
                                        finData [4] = uploadTempA [readPosition], readPosition++;
                                        finData [5] = uploadTempA [readPosition], readPosition++;
                                        finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                                        finData [7] = uploadTempA [readPosition], readPosition++;
                                        finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                                        finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                                        finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                                        finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                                        finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                                        finData [13] = uploadTempA [readPosition], readPosition++;
                                        finData [14] = uploadTempA [readPosition], readPosition++;
                                        finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no
                                        finData [16] = uploadTempA [readPosition], readPosition++;
                                        finData [17] = uploadTempA [readPosition], readPosition++;
                                        finData [18] = uploadTempA [readPosition], readPosition++; //--11 Lineage no
                                        
                                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [8] = finData [7]*256+finData [8];
                                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                        
                                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                                            arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                                            arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                                            arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                                            arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                                            arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                                            arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                                            arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                                            arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                                            arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTempA;
                            }
                            else{
                                
                                for (int counter1 = 0; counter1 < gravityCenterRevTempCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Selected, removed, eliminated status-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Top position of each connect-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Cut line number-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X Start-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X End-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y Start-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y End-----
                                    arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //-----Connect-----
                                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Lineage-----
                                }
                                
                                valueTemp = 0;
                                
                                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] != valueTemp){
                                        valueTemp = arrayPositionRevise [counter1*7+3];
                                        arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                                        arrayTimeSelectedHold [(valueTemp-1)*10+2] = counter1;
                                        
                                        if (arrayPositionRevise [counter1*7+5] == 0){
                                            arrayTimeSelected [(valueTemp-1)*10] = 0;
                                            arrayTimeSelectedHold [(valueTemp-1)*10] = 0;
                                        }
                                    }
                                }
                            }
                            
                            string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+exType;
                            mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+lineageNoExtension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
                            revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                            
                            if (revisedWorkingMapStatus == 0){
                                revisedWorkingMap = new int *[imageDimension+1];
                                revisedWorkingMapStatus = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedWorkingMap [counter1] = new int [imageDimension+1];
                            }
                            
                            if (sourceImageStatus == 0){
                                sourceImage = new int *[imageDimension+1];
                                sourceImageStatus = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) sourceImage [counter1] = new int [imageDimension+1];
                            }
                            
                            sizeForCopy = 0;
                            
                            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (exType == ".tif"){
                                    int dataConversion [4];
                                    int endianType = 0;
                                    int imageWidthEntry = 0;
                                    int value0 = 0;
                                    int value1 = 0;
                                    int value2 = 0;
                                    int imageDimensionReadCount = 0;
                                    
                                    unsigned long headPosition = 0;
                                    
                                    uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                                    fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTemp2, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataConversion [0] = uploadTemp2 [0];
                                        dataConversion [1] = uploadTemp2 [1];
                                        
                                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                        else endianType = 0;
                                        
                                        headPosition = 0;
                                        
                                        if (endianType == 1){
                                            dataConversion [0] = uploadTemp2 [7];
                                            dataConversion [1] = uploadTemp2 [6];
                                            dataConversion [2] = uploadTemp2 [5];
                                            dataConversion [3] = uploadTemp2 [4];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        else if (endianType == 0){
                                            dataConversion [0] = uploadTemp2 [4];
                                            dataConversion [1] = uploadTemp2 [5];
                                            dataConversion [2] = uploadTemp2 [6];
                                            dataConversion [3] = uploadTemp2 [7];
                                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                        }
                                        
                                        imageDimensionReadCount = 0;
                                        imageWidthEntry = 0;
                                        
                                        if (tifImageColorGray == 0){
                                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                sourceImage [imageDimensionReadCount][imageWidthEntry] = uploadTemp2 [counter3], imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                        else if (tifImageColorGray == 1){
                                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                value0 = uploadTemp2 [counter3];
                                                value1 = uploadTemp2 [counter3+1];
                                                value2 = uploadTemp2 [counter3+2];
                                                
                                                sourceImage [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                
                                                if (imageWidthEntry == imageDimension){
                                                    imageWidthEntry = 0;
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] uploadTemp2;
                                }
                                else if (exType == ".bmp"){
                                    uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                                    fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.read((char*)uploadTemp2, sizeForCopy+50);
                                        fin.close();
                                        
                                        int imageDimensionReadCount = 0;
                                        
                                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                sourceImage [imageDimensionReadCount][counter2] = uploadTemp2 [1078+counter1*imageDimension+counter2];
                                            }
                                            
                                            imageDimensionReadCount++;
                                        }
                                    }
                                    
                                    delete [] uploadTemp2;
                                }
                            }
                            
                            //-----Source upload-----
                            totalSize = imageDimension*imageDimension*4;
                            
                            //-----Map-----
                            uint8_t *upload2 = new uint8_t [totalSize+50];
                            
                            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.read((char*)upload2, totalSize+1);
                                fin.close();
                                
                                yDimensionCount = 0;
                                xDimensionCount = 0;
                                
                                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                    readBit [0] = upload2[counter1];
                                    readBit [1] = upload2[counter1+1];
                                    readBit [2] = upload2[counter1+2];
                                    readBit [3] = upload2[counter1+3];
                                    
                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                    
                                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                    }
                                    
                                    if (xDimensionCount == imageDimension){
                                        xDimensionCount = 0;
                                        yDimensionCount++;
                                        
                                        if (yDimensionCount == imageDimension){
                                            break;
                                        }
                                    }
                                }
                            }
                            else{
                                
                                fin.open(mapPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.read((char*)upload2, totalSize+50);
                                    fin.close();
                                    
                                    yDimensionCount = 0;
                                    xDimensionCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                                        readBit [0] = upload2[counter1];
                                        readBit [1] = upload2[counter1+1];
                                        readBit [2] = upload2[counter1+2];
                                        readBit [3] = upload2[counter1+3];
                                        
                                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                        
                                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                        }
                                        
                                        if (xDimensionCount == imageDimension){
                                            xDimensionCount = 0;
                                            yDimensionCount++;
                                            
                                            if (yDimensionCount == imageDimension){
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                            
                            delete [] upload2;
                            
                            if (fluorescentMapStatus1 == 0){
                                fluorescentMap1 = new int *[imageDimension+1];
                                fluorescentMapStatus1 = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap1 [counter1] = new int [imageDimension+1];
                            }
                            
                            if (fluorescentMapStatus2 == 0){
                                fluorescentMap2 = new int *[imageDimension+1];
                                fluorescentMapStatus2 = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap2 [counter1] = new int [imageDimension+1];
                            }
                            
                            if (fluorescentMapStatus3 == 0){
                                fluorescentMap3 = new int *[imageDimension+1];
                                fluorescentMapStatus3 = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap3 [counter1] = new int [imageDimension+1];
                            }
                            
                            if (fluorescentMapStatus4 == 0){
                                fluorescentMap4 = new int *[imageDimension+1];
                                fluorescentMapStatus4 = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap4 [counter1] = new int [imageDimension+1];
                            }
                            
                            if (fluorescentMapStatus5 == 0){
                                fluorescentMap5 = new int *[imageDimension+1];
                                fluorescentMapStatus5 = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap5 [counter1] = new int [imageDimension+1];
                            }
                            
                            if (fluorescentMapStatus6 == 0){
                                fluorescentMap6 = new int *[imageDimension+1];
                                fluorescentMapStatus6 = 1;
                                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap6 [counter1] = new int [imageDimension+1];
                            }
                            
                            if (fluorescentEntryCount >= 1){
                                extension = to_string(fluorescentNo1);
                                string fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName1+exType;
                                
                                sizeForCopy = 0;
                                
                                if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (exType == ".tif"){
                                        int dataConversion [4];
                                        int endianType = 0;
                                        int imageWidthEntry = 0;
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        int imageDimensionReadCount = 0;
                                        
                                        unsigned long headPosition = 0;
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTempA [0];
                                            dataConversion [1] = uploadTempA [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempA [7];
                                                dataConversion [1] = uploadTempA [6];
                                                dataConversion [2] = uploadTempA [5];
                                                dataConversion [3] = uploadTempA [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempA [4];
                                                dataConversion [1] = uploadTempA [5];
                                                dataConversion [2] = uploadTempA [6];
                                                dataConversion [3] = uploadTempA [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTempA [counter3];
                                                    value1 = uploadTempA [counter3+1];
                                                    value2 = uploadTempA [counter3+2];
                                                    
                                                    fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else if (exType == ".bmp"){
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            int imageDimensionReadCount = 0;
                                            
                                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                    fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 2){
                                extension = to_string(fluorescentNo2);
                                string fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName2+exType;
                                
                                sizeForCopy = 0;
                                
                                if (stat(fluorescentProcessPath2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (exType == ".tif"){
                                        int dataConversion [4];
                                        int endianType = 0;
                                        int imageWidthEntry = 0;
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        int imageDimensionReadCount = 0;
                                        
                                        unsigned long headPosition = 0;
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTempA [0];
                                            dataConversion [1] = uploadTempA [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempA [7];
                                                dataConversion [1] = uploadTempA [6];
                                                dataConversion [2] = uploadTempA [5];
                                                dataConversion [3] = uploadTempA [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempA [4];
                                                dataConversion [1] = uploadTempA [5];
                                                dataConversion [2] = uploadTempA [6];
                                                dataConversion [3] = uploadTempA [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTempA [counter3];
                                                    value1 = uploadTempA [counter3+1];
                                                    value2 = uploadTempA [counter3+2];
                                                    
                                                    fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else if (exType == ".bmp"){
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            int imageDimensionReadCount = 0;
                                            
                                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                    fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                extension = to_string(fluorescentNo3);
                                string fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName3+exType;
                                
                                sizeForCopy = 0;
                                
                                if (stat(fluorescentProcessPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (exType == ".tif"){
                                        int dataConversion [4];
                                        int endianType = 0;
                                        int imageWidthEntry = 0;
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        int imageDimensionReadCount = 0;
                                        
                                        unsigned long headPosition = 0;
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTempA [0];
                                            dataConversion [1] = uploadTempA [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempA [7];
                                                dataConversion [1] = uploadTempA [6];
                                                dataConversion [2] = uploadTempA [5];
                                                dataConversion [3] = uploadTempA [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempA [4];
                                                dataConversion [1] = uploadTempA [5];
                                                dataConversion [2] = uploadTempA [6];
                                                dataConversion [3] = uploadTempA [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTempA [counter3];
                                                    value1 = uploadTempA [counter3+1];
                                                    value2 = uploadTempA [counter3+2];
                                                    
                                                    fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else if (exType == ".bmp"){
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            int imageDimensionReadCount = 0;
                                            
                                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                    fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                extension = to_string(fluorescentNo4);
                                string fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName4+exType;
                                
                                sizeForCopy = 0;
                                
                                if (stat(fluorescentProcessPath4.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (exType == ".tif"){
                                        int dataConversion [4];
                                        int endianType = 0;
                                        int imageWidthEntry = 0;
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        int imageDimensionReadCount = 0;
                                        
                                        unsigned long headPosition = 0;
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTempA [0];
                                            dataConversion [1] = uploadTempA [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempA [7];
                                                dataConversion [1] = uploadTempA [6];
                                                dataConversion [2] = uploadTempA [5];
                                                dataConversion [3] = uploadTempA [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempA [4];
                                                dataConversion [1] = uploadTempA [5];
                                                dataConversion [2] = uploadTempA [6];
                                                dataConversion [3] = uploadTempA [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTempA [counter3];
                                                    value1 = uploadTempA [counter3+1];
                                                    value2 = uploadTempA [counter3+2];
                                                    
                                                    fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else if (exType == ".bmp"){
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            int imageDimensionReadCount = 0;
                                            
                                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                    fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                extension = to_string(fluorescentNo5);
                                string fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName5+exType;
                                
                                sizeForCopy = 0;
                                
                                if (stat(fluorescentProcessPath5.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (exType == ".tif"){
                                        int dataConversion [4];
                                        int endianType = 0;
                                        int imageWidthEntry = 0;
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        int imageDimensionReadCount = 0;
                                        
                                        unsigned long headPosition = 0;
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTempA [0];
                                            dataConversion [1] = uploadTempA [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempA [7];
                                                dataConversion [1] = uploadTempA [6];
                                                dataConversion [2] = uploadTempA [5];
                                                dataConversion [3] = uploadTempA [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempA [4];
                                                dataConversion [1] = uploadTempA [5];
                                                dataConversion [2] = uploadTempA [6];
                                                dataConversion [3] = uploadTempA [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTempA [counter3];
                                                    value1 = uploadTempA [counter3+1];
                                                    value2 = uploadTempA [counter3+2];
                                                    
                                                    fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else if (exType == ".bmp"){
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            int imageDimensionReadCount = 0;
                                            
                                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                    fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                extension = to_string(fluorescentNo6);
                                string fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+lineageNoExtension+"_"+extension+"_"+fluorescentName6+exType;
                                
                                sizeForCopy = 0;
                                
                                if (stat(fluorescentProcessPath6.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (exType == ".tif"){
                                        int dataConversion [4];
                                        int endianType = 0;
                                        int imageWidthEntry = 0;
                                        int value0 = 0;
                                        int value1 = 0;
                                        int value2 = 0;
                                        int imageDimensionReadCount = 0;
                                        
                                        unsigned long headPosition = 0;
                                        
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTempA [0];
                                            dataConversion [1] = uploadTempA [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTempA [7];
                                                dataConversion [1] = uploadTempA [6];
                                                dataConversion [2] = uploadTempA [5];
                                                dataConversion [3] = uploadTempA [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTempA [4];
                                                dataConversion [1] = uploadTempA [5];
                                                dataConversion [2] = uploadTempA [6];
                                                dataConversion [3] = uploadTempA [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTempA [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTempA [counter3];
                                                    value1 = uploadTempA [counter3+1];
                                                    value2 = uploadTempA [counter3+2];
                                                    
                                                    fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                    else if (exType == ".bmp"){
                                        uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTempA, sizeForCopy+50);
                                            fin.close();
                                            
                                            int imageDimensionReadCount = 0;
                                            
                                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                                    fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTempA [1078+counter1*imageDimension+counter2];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTempA;
                                    }
                                }
                            }
                            
                            int returnResults2 = 0;
                            
                            if (autoExpand == 1){
                                expandLine = [[ExpandLine alloc] init];
                                returnResults2 = [expandLine lineExtendTrackType2:connectNoAdd];
                            }
                            
                            if (autoExpand == 0 || (autoExpand == 1 && returnResults2 == 1)){
                                int maxPointDimX = 0;
                                int maxPointDimY = 0;
                                int minPointDimX = 1000000;
                                int minPointDimY = 1000000;
                                
                                for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                                        
                                        if (maxPointDimX < arrayPositionRevise [counter1*7]) maxPointDimX = arrayPositionRevise [counter1*7]; //====PS
                                        if (minPointDimX > arrayPositionRevise [counter1*7]) minPointDimX = arrayPositionRevise [counter1*7];
                                        if (maxPointDimY < arrayPositionRevise [counter1*7+1]) maxPointDimY = arrayPositionRevise [counter1*7+1];
                                        if (minPointDimY > arrayPositionRevise [counter1*7+1]) minPointDimY = arrayPositionRevise [counter1*7+1];
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                                
                                if (fluorescentEntryCount >= 2){
                                    for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                        if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                                fileUpdate = [[FileUpdate alloc] init];
                                                [fileUpdate expandFluorescentOutlineUpDate];
                                            }
                                            
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (fluorescentEntryCount >= 3){
                                    for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                        if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                                fileUpdate = [[FileUpdate alloc] init];
                                                [fileUpdate expandFluorescentOutlineUpDate];
                                            }
                                            
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (fluorescentEntryCount >= 4){
                                    for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                        if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                                fileUpdate = [[FileUpdate alloc] init];
                                                [fileUpdate expandFluorescentOutlineUpDate];
                                            }
                                            
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (fluorescentEntryCount >= 5){
                                    for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                        if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                                fileUpdate = [[FileUpdate alloc] init];
                                                [fileUpdate expandFluorescentOutlineUpDate];
                                            }
                                            
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (fluorescentEntryCount >= 6){
                                    for (int counter1 = arrayTimeSelected [(connectNoAdd-1)*10+2]; counter1 < positionReviseCount/7; counter1++){
                                        if (arrayPositionRevise [counter1*7+3] == arrayTimeSelected [(connectNoAdd-1)*10+8]){
                                            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                                fileUpdate = [[FileUpdate alloc] init];
                                                [fileUpdate expandFluorescentOutlineUpDate];
                                            }
                                            
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoAdd, expandFluorescentOutlineCount++;
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                int pixelValueTemp = 0;
                                int pixelAreaTemp = 0;
                                int pixelValueTemp2 = 0;
                                int pixelAreaTemp2 = 0;
                                int pixelValueTemp3 = 0;
                                int pixelAreaTemp3 = 0;
                                int pixelValueTemp4 = 0;
                                int pixelAreaTemp4 = 0;
                                int pixelValueTemp5 = 0;
                                int pixelAreaTemp5 = 0;
                                int pixelValueTemp6 = 0;
                                int pixelAreaTemp6 = 0;
                                
                                for (int counterY = minPointDimY; counterY <= maxPointDimY; counterY++){
                                    for (int counterX = minPointDimX; counterX <= maxPointDimX; counterX++){
                                        if (revisedWorkingMap [counterY][counterX] == connectNoAdd){
                                            if (fluorescentEntryCount >= 1){
                                                if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY][counterX];
                                                pixelAreaTemp++;
                                            }
                                            if (fluorescentEntryCount >= 2){
                                                if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterY][counterX];
                                                pixelAreaTemp2++;
                                            }
                                            if (fluorescentEntryCount >= 3){
                                                if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterY][counterX];
                                                pixelAreaTemp3++;
                                            }
                                            if (fluorescentEntryCount >= 4){
                                                if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) pixelValueTemp4 = pixelValueTemp4+fluorescentMap4 [counterY][counterX];
                                                pixelAreaTemp4++;
                                            }
                                            if (fluorescentEntryCount >= 5){
                                                if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) pixelValueTemp5 = pixelValueTemp5+fluorescentMap5 [counterY][counterX];
                                                pixelAreaTemp5++;
                                            }
                                            if (fluorescentEntryCount >= 6){
                                                if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) pixelValueTemp6 = pixelValueTemp6+fluorescentMap6 [counterY][counterX];
                                                pixelAreaTemp6++;
                                            }
                                        }
                                    }
                                }
                                
                                double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                
                                if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate expandFluorescentDataUpDate];
                                }
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                                
                                if (fluorescentEntryCount >= 2){
                                    averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
                                }
                                
                                if (fluorescentEntryCount >= 3){
                                    averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
                                }
                                
                                if (fluorescentEntryCount >= 4){
                                    averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
                                }
                                
                                if (fluorescentEntryCount >= 5){
                                    averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
                                }
                                
                                if (fluorescentEntryCount >= 6){
                                    averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = connectNoAdd, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
                                }
                            }
                            
                            string fluorescentExpandPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                            
                            if (expandFluorescentOutlineCount != 0){
                                indexCount = 0;
                                
                                writingArray = new char [expandFluorescentOutlineCount*2+200];
                                
                                for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                                    dataTemp = expandFluorescentOutline [counter1*4];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = expandFluorescentOutline [counter1*4+1];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = expandFluorescentOutline [counter1*4+2];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)expandFluorescentOutline [counter1*4+3], indexCount++;
                                }
                                
                                for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile8 (fluorescentExpandPath.c_str(), ofstream::binary);
                                outfile8.write ((char*)writingArray, indexCount);
                                outfile8.close();
                                
                                delete [] writingArray;
                            }
                            
                            string fluorescentExpandPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+lineageNoExtension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                            
                            if (expandFluorescentDataCount != 0){
                                indexCount = 0;
                                
                                writingArray = new char [expandFluorescentDataCount*2+20];
                                
                                for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                                    dataTemp = expandFluorescentData [counter1*4];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)expandFluorescentData [counter1*4+1], indexCount++;
                                    writingArray [indexCount] = (char)expandFluorescentData [counter1*4+2], indexCount++;
                                    
                                    dataTemp = expandFluorescentData [counter1*4+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile9 (fluorescentExpandPath2.c_str(), ofstream::binary);
                                outfile9.write ((char*)writingArray, indexCount);
                                outfile9.close();
                                
                                delete [] writingArray;
                            }
                            
                            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                                delete [] revisedWorkingMap [counter1];
                                delete [] fluorescentMap1 [counter1];
                                delete [] fluorescentMap2 [counter1];
                                delete [] fluorescentMap3 [counter1];
                                delete [] fluorescentMap4 [counter1];
                                delete [] fluorescentMap5 [counter1];
                                delete [] fluorescentMap6 [counter1];
                                delete [] sourceImage [counter1];
                            }
                            
                            delete [] revisedWorkingMap;
                            delete [] fluorescentMap1;
                            delete [] fluorescentMap2;
                            delete [] fluorescentMap3;
                            delete [] fluorescentMap4;
                            delete [] fluorescentMap5;
                            delete [] fluorescentMap6;
                            delete [] sourceImage;
                            
                            revisedWorkingMapStatus = 0;
                            sourceImageStatus = 0;
                            
                            delete [] arrayPositionRevise;
                            delete [] arrayTimeSelected;
                            
                            fluorescentMapStatus1 = 0;
                            fluorescentMapStatus2 = 0;
                            fluorescentMapStatus3 = 0;
                            fluorescentMapStatus4 = 0;
                            fluorescentMapStatus5 = 0;
                            fluorescentMapStatus6 = 0;
                            
                            positionReviseCount = 0;
                            timeSelectedCount = 0;
                        }
                    }
                    
                    cellLineageNoHold = cellLineageString;
                    cellNoHold = "C000000000";
                    
                    revisedWorkingMapTime2= 0;
                    addDelInsert = 1;
                    
                    returnResults = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Invalid Number"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                delete [] uploadTemp;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Structure Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Fault"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Connect No. Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return returnResults;
}

@end
