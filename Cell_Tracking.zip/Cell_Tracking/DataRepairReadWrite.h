//
//  DataRepairReadWrite.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#ifndef DATAREPAIRREADWRITE_H
#define DATAREPAIRREADWRITE_H
#import "Controller.h"
#endif

@interface DataRepairReadWrite : NSObject{
    id dataSaveRead;
}

-(int)lineageDataSetList:(long)size :(int)processType;
-(void)lineageDataSave;

-(int)masterDataSetList:(long)size :(int)processType :(int)dataType;
-(void)masterDataSave;

-(void)timeSelectedList:(long)size :(int)processType;
-(void)connectRLList:(long)size :(int)processType;
-(int)fluorescentLineList:(long)size :(int)processType;
-(void)fluorescentAreaList:(long)size :(int)processType;
-(void)fluorescentCutList:(int)processType;

-(void)lineageRelDataSet;

@end
