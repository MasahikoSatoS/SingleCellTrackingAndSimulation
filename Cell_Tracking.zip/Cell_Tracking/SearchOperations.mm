//
//  SearchOperations.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-12-02.
//
//

#import "SearchOperations.h"

NSString *notificationToSearchOperations = @"notificationExecuteSearchOperations";

@implementation SearchOperations

-(id)init{
    self = [super init];
    
    if (self != nil){
        tableRowHoldSearch = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSearchOperations object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    lineageNoSelect = 0;
    searchFlag = 0;
    lingNoSearchHold = 0;
    lingSearchPosition = 1;
    searchType = 0;
    
    for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
        if (arrayTreatmentStatus [counter1*9] == treatmentNameHold){
            treatmentNameSearch = arrayTreatmentStatus [counter1*9];
            break;
        }
        else treatmentNameSearch = arrayTreatmentStatus [counter1*9];
    }
    
    if (trackingOn == 1) [self lineageDataReadSearch];
    
    [treatmentSL setStringValue:@(treatmentNameSearch.c_str())];
    [lineageSL setStringValue:@"All"];
    
    logicStatus1 = 0;
    logicStatus2 = 0;
    logicStatus3 = 0;
    
    searchStatus1 = "nil";
    searchStatus2 = "nil";
    searchStatus3 = "nil";
    searchStatus4 = "nil";
    
    [eventSL1 setStringValue:@"nil"];
    [eventSL2 setStringValue:@"nil"];
    [eventSL3 setStringValue:@"nil"];
    [eventSL4 setStringValue:@"nil"];
    [logicSL1 setStringValue:@"nil"];
    [logicSL2 setStringValue:@"nil"];
    [logicSL3 setStringValue:@"nil"];
    
    [lingInfoSL setStringValue:@"nil"];
    [lingInfoCellNoSL setStringValue:@"nil"];
    [lingInfoStatusSL setStringValue:@"nil"];
    [cellInfoSL setStringValue:@"nil"];
    [cellInfoSTtimeSL setStringValue:@"nil"];
    [cellInfoEDtimeSL setStringValue:@"nil"];
    [cellInfoSTStatusSL setStringValue:@"nil"];
    [cellInfoEDStatusSL setStringValue:@"nil"];
    [cellInfoFUMKSL setStringValue:@"nil"];
    
    [mainLabel setStringValue:@"Display: All"];
    
    [searchListBrowser setTarget:self];
    [searchListBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [searchListBrowser reloadColumn:0];
    [timeViewSearch setDataSource:self];
    [timeViewSearch reloadData];
}

-(IBAction)lineageSelect:(id)sender{
    if (queueHoldingStatus == 0 && trackingOn == 1 && timeOneStatus == 0){
        if (mainSavingInProgress == 0 && cleaningProgress == 0){
            if (treatmentNameSearch != treatmentNameSearchSelect){
                treatmentNameSearch = treatmentNameSearchSelect;
                lineageNoSelect = 0;
                searchFlag = 0;
                lingNoSearchHold = 0;
                lingSearchPosition = 1;
                searchType = 0;
                
                [lineageSL setStringValue:@"All"];
                
                logicStatus1 = 0;
                logicStatus2 = 0;
                logicStatus3 = 0;
                
                searchStatus1 = "nil";
                searchStatus2 = "nil";
                searchStatus3 = "nil";
                searchStatus4 = "nil";
                
                [eventSL1 setStringValue:@"nil"];
                [eventSL2 setStringValue:@"nil"];
                [eventSL3 setStringValue:@"nil"];
                [eventSL4 setStringValue:@"nil"];
                [logicSL1 setStringValue:@"nil"];
                [logicSL2 setStringValue:@"nil"];
                [logicSL3 setStringValue:@"nil"];
                
                [lingInfoSL setStringValue:@"nil"];
                [lingInfoCellNoSL setStringValue:@"nil"];
                [lingInfoStatusSL setStringValue:@"nil"];
                [cellInfoSL setStringValue:@"nil"];
                [cellInfoSTtimeSL setStringValue:@"nil"];
                [cellInfoEDtimeSL setStringValue:@"nil"];
                [cellInfoSTStatusSL setStringValue:@"nil"];
                [cellInfoEDStatusSL setStringValue:@"nil"];
                [cellInfoFUMKSL setStringValue:@"nil"];
                
                [mainLabel setStringValue:@"Display: All"];
                
                int searchResults = 0;
                
                searchResults = [self lineageDataReadSearch];
                
                if (searchResults == 0){
                    [searchListBrowser reloadColumn:0];
                    
                    //for (int counterA = 0; counterA < lineageDataSearchCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageSearchData [counterA*8+counterB];
                    //    cout<<" arrayLineageSearchData "<<counterA<<endl;
                    //}
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else if (treatmentNameSearch == treatmentNameSearchSelect){
                searchFlag = 0;
                searchType = 0;
                
                int searchResults = 0;
                
                searchResults = [self lineageDataReadSearch];
                
                if (searchResults == 0){
                    [searchListBrowser reloadColumn:0];
                    
                    //for (int counterA = 0; counterA < lineageDataSearchCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageSearchData [counterA*8+counterB];
                    //    cout<<" arrayLineageSearchData "<<counterA<<endl;
                    //}
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInitialInfoCount = 0;
    
    if (column == 0){
        string extension2;
        
        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
            if (directoryInitialInfoCount+2 > directoryInitialInfoLimit){
                string *arrayUpDate = new string [directoryInitialInfoCount+10];
                
                for (int counter2 = 0; counter2 < directoryInitialInfoCount; counter2++) arrayUpDate [counter2] = arrayDirectoryInitialInfo [counter2];
                
                delete [] arrayDirectoryInitialInfo;
                arrayDirectoryInitialInfo = new string [directoryInitialInfoLimit+500];
                directoryInitialInfoLimit = directoryInitialInfoLimit+500;
                
                for (int counter2 = 0; counter2 < directoryInitialInfoCount; counter2++) arrayDirectoryInitialInfo [counter2] = arrayUpDate [counter2];
                delete [] arrayUpDate;
            }
            
            if (arrayLineageList [counter1*5] != 0){
                extension2 = to_string(counter1);
                
                if (extension2.length() == 1) extension2 = "L0000"+extension2;
                else if (extension2.length() == 2) extension2 = "L000"+extension2;
                else if (extension2.length() == 3) extension2 = "L00"+extension2;
                else if (extension2.length() == 4) extension2 = "L0"+extension2;
                else if (extension2.length() == 5) extension2 = "L"+extension2;
                
                arrayDirectoryInitialInfo [directoryInitialInfoCount] = extension2, directoryInitialInfoCount++;
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        string lineageNoTemp = [path UTF8String];
        lineageNoTemp = lineageNoTemp.substr(2);
        int lineageNoTempInt = atoi(lineageNoTemp.c_str());
        
        if (searchType == 0){
            if (lineageNoTempInt != 0){
                string extension;
                string endStatus;
                
                for (int counter1 = 0; counter1 < lineageStartEndSearchCount/8; counter1++){
                    if (arrayLineageStartEndSearch [counter1*8] == lineageNoTempInt){
                        if (arrayLineageStartEndSearch [counter1*8+1] != -1){
                            extension = to_string(arrayLineageStartEndSearch [counter1*8+1]);
                            
                            if (arrayLineageStartEndSearch [counter1*8+1] >= 0){
                                if (extension.length() == 1) extension = "C00000000"+extension;
                                else if (extension.length() == 2) extension = "C0000000"+extension;
                                else if (extension.length() == 3) extension = "C000000"+extension;
                                else if (extension.length() == 4) extension = "C00000"+extension;
                                else if (extension.length() == 5) extension = "C0000"+extension;
                                else if (extension.length() == 6) extension = "C000"+extension;
                                else if (extension.length() == 7) extension = "C00"+extension;
                                else if (extension.length() == 8) extension = "C0"+extension;
                                else if (extension.length() == 9) extension = "C"+extension;
                            }
                            else{
                                
                                extension = extension.substr(1);
                                
                                if (extension.length() == 1) extension = "C-00000000"+extension;
                                else if (extension.length() == 2) extension = "C-0000000"+extension;
                                else if (extension.length() == 3) extension = "C-000000"+extension;
                                else if (extension.length() == 4) extension = "C-00000"+extension;
                                else if (extension.length() == 5) extension = "C-0000"+extension;
                                else if (extension.length() == 6) extension = "C-000"+extension;
                                else if (extension.length() == 7) extension = "C-00"+extension;
                                else if (extension.length() == 8) extension = "C-0"+extension;
                                else if (extension.length() == 9) extension = "C-"+extension;
                            }
                            
                            endStatus = "OP";
                            
                            for (int counter2 = arrayLineageStartEndSearch [counter1*8+4]; counter2 <= arrayLineageStartEndSearch [counter1*8+6]; counter2++){
                                if (arrayLineageSearchData [counter2*8+3] == 32) endStatus = "BD";
                                else if (arrayLineageSearchData [counter2*8+3] == 42) endStatus = "TD";
                                else if (arrayLineageSearchData [counter2*8+3] == 52) endStatus = "HD";
                                else if (arrayLineageSearchData [counter2*8+3] == 8) endStatus = "OF";
                                else if (arrayLineageSearchData [counter2*8+3] == 7) endStatus = "CD";
                                else if (arrayLineageSearchData [counter2*8+3] == 91) endStatus = "CF";
                            }
                            
                            arrayDirectoryInitialInfo [directoryInitialInfoCount] = extension+": "+endStatus, directoryInitialInfoCount++;
                        }
                    }
                }
            }
        }
        else if (searchType == 1){
            if (lineageNoTempInt != 0){
                string extension;
                string endStatus;
                
                for (int counter1 = 0; counter1 < searchCellListCount/2; counter1++){
                    if (arraySearchCellList [counter1*2] == lineageNoTempInt){
                        extension = to_string(arraySearchCellList [counter1*2+1]);
                        
                        if (arraySearchCellList [counter1*2+1] >= 0){
                            if (extension.length() == 1) extension = "C00000000"+extension;
                            else if (extension.length() == 2) extension = "C0000000"+extension;
                            else if (extension.length() == 3) extension = "C000000"+extension;
                            else if (extension.length() == 4) extension = "C00000"+extension;
                            else if (extension.length() == 5) extension = "C0000"+extension;
                            else if (extension.length() == 6) extension = "C000"+extension;
                            else if (extension.length() == 7) extension = "C00"+extension;
                            else if (extension.length() == 8) extension = "C0"+extension;
                            else if (extension.length() == 9) extension = "C"+extension;
                        }
                        else{
                            
                            extension = extension.substr(1);
                            
                            if (extension.length() == 1) extension = "C-00000000"+extension;
                            else if (extension.length() == 2) extension = "C-0000000"+extension;
                            else if (extension.length() == 3) extension = "C-000000"+extension;
                            else if (extension.length() == 4) extension = "C-00000"+extension;
                            else if (extension.length() == 5) extension = "C-0000"+extension;
                            else if (extension.length() == 6) extension = "C-000"+extension;
                            else if (extension.length() == 7) extension = "C-00"+extension;
                            else if (extension.length() == 8) extension = "C-0"+extension;
                            else if (extension.length() == 9) extension = "C-"+extension;
                        }
                        
                        arrayDirectoryInitialInfo [directoryInitialInfoCount] = extension, directoryInitialInfoCount++;
                    }
                }
            }
        }
    }
    
    return directoryInitialInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInitialInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    if (column == 1){
        string folderName = arrayDirectoryInitialInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    nodePathString = nodePathString.substr(2);
    int stringFind = (int)nodePathString.find("/");
    
    if (stringFind == -1){
        lingNoSearchHold = atoi(nodePathString.c_str());
        int noOfCellTemp = arrayLineageList [lingNoSearchHold*5+1];
        int statusTemp = arrayLineageList [lingNoSearchHold*5+2];
        
        string lineageStatus = "";
        
        if (statusTemp == 0) lineageStatus = "Open";
        else lineageStatus = "Complete";
        
        [lingInfoSL setIntegerValue:lingNoSearchHold];
        [lingInfoCellNoSL setIntegerValue:noOfCellTemp];
        [lingInfoStatusSL setStringValue:@(lineageStatus.c_str())];
        [cellInfoSL setStringValue:@"nil"];
        [cellInfoSTtimeSL setStringValue:@"nil"];
        [cellInfoEDtimeSL setStringValue:@"nil"];
        [cellInfoSTStatusSL setStringValue:@"nil"];
        [cellInfoEDStatusSL setStringValue:@"nil"];
        [cellInfoFUMKSL setStringValue:@"nil"];
    }
    else if (mainSavingInProgress == 0 && cleaningProgress == 0){
        string lineageNoString = nodePathString.substr(0, (unsigned long)stringFind);
        lingNoSearchHold = atoi(nodePathString.c_str());
        int noOfCellTemp = arrayLineageList [lingNoSearchHold*5+1];
        int statusTemp = arrayLineageList [lingNoSearchHold*5+2];
        
        nodePathString = nodePathString.substr((unsigned long)stringFind);
        
        string lineageStatus = "";
        
        if (statusTemp == 0) lineageStatus = "Open";
        else lineageStatus = "Complete";
        
        [lingInfoSL setIntegerValue:lingNoSearchHold];
        [lingInfoCellNoSL setIntegerValue:noOfCellTemp];
        [lingInfoStatusSL setStringValue:@(lineageStatus.c_str())];
        
        nodePathString = nodePathString.substr(2);
        stringFind = (int)nodePathString.find(":");
        string cellNoString = nodePathString.substr(0, (unsigned long)stringFind);
        int cellNoInt = atoi(cellNoString.c_str());
        
        string endStatus;
        string startStatus;
        string midStatus;
        int fusionMarkStatus = 0;
        int startTime = 0;
        int endTime = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndSearchCount/8; counter1++){
            if (arrayLineageStartEndSearch [counter1*8] == lingNoSearchHold && arrayLineageStartEndSearch [counter1*8+1] == cellNoInt){
                endStatus = "OP";
                startStatus = "";
                midStatus = "";
                
                for (int counter2 = arrayLineageStartEndSearch [counter1*8+4]; counter2 <= arrayLineageStartEndSearch [counter1*8+6]; counter2++){
                    if (arrayLineageSearchData [counter2*8+3] == 32) endStatus = "BD";
                    else if (arrayLineageSearchData [counter2*8+3] == 42) endStatus = "TD";
                    else if (arrayLineageSearchData [counter2*8+3] == 52) endStatus = "HD";
                    else if (arrayLineageSearchData [counter2*8+3] == 8) endStatus = "OF";
                    else if (arrayLineageSearchData [counter2*8+3] == 7) endStatus = "CD";
                    else if (arrayLineageSearchData [counter2*8+3] == 91) endStatus = "CF";
                    else if (arrayLineageSearchData [counter2*8+3] == 92) midStatus = "CF";
                    else if (arrayLineageSearchData [counter2*8+3] == 11) midStatus = "IP";
                    
                    if (startStatus == ""){
                        if (arrayLineageSearchData [counter2*8+3] == 1) startStatus = "IN";
                        else if (arrayLineageSearchData [counter2*8+3] == 31) startStatus = "BD";
                        else if (arrayLineageSearchData [counter2*8+3] == 41) startStatus = "TD";
                        else if (arrayLineageSearchData [counter2*8+3] == 51) startStatus = "HD";
                    }
                    
                    if (arrayLineageSearchData [counter2*8+3] == 10) fusionMarkStatus = 1;
                    if (startTime == 0) startTime = arrayLineageSearchData [counter2*8+2];
                    
                    endTime = arrayLineageSearchData [counter2*8+2];
                }
                
                break;
            }
        }
        
        string fusionMarkerString = "";
        
        if (fusionMarkStatus == 0) fusionMarkerString = "Not found";
        else fusionMarkerString = "Found";
        
        [cellInfoSL setIntegerValue:cellNoInt];
        [cellInfoSTtimeSL setIntegerValue:startTime];
        [cellInfoEDtimeSL setIntegerValue:endTime];
        [cellInfoSTStatusSL setStringValue:@(startStatus.c_str())];
        [cellInfoEDStatusSL setStringValue:@(endStatus.c_str())];
        [cellInfoFUMKSL setStringValue:@(fusionMarkerString.c_str())];
        
        lineageNoString = "L"+lineageNoString;
        
        cellLineageNoHold = lineageNoString;
        cellNoHold = "C"+cellNoString;
        
        string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameSearch+"_Connect/"+ analysisID+"_"+treatmentNameSearch+"_LineageStatus";
        string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameSearch+"_Treat/"+lineageNoString+"/"+analysisID+"_"+lineageNoString+"_CellStatus";
        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameSearch+"_Connect/"+ analysisID+"_"+treatmentNameSearch+"_LineageStartEnd";
        
        ifstream fin;
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (treatmentNameSearch != treatmentNameHold){
            saveInfo = treatmentNameSearch;
            
            dataSaveRead = [[DataSaveRead alloc] init];
            [dataSaveRead lineageDataRead];
            
            if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (cellLineageInfoStatus == 0){
                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                cellLineageInfoStatus = 1;
            }
            else if (sizeForCopy*2 > cellLineageInfoCount){
                delete [] arrayCellLineageInfo;
                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                cellLineageInfoLimit = (int)sizeForCopy*2+50;
            }
            
            cellLineageInfoCount = 0;
            
            if (sizeForCopy != 0){
                fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End") arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++, dataString = "";
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
            }
            
            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
            //}
            
            sizeForCopy = 0;
            
            if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (lineageStartEndStatus == 0){
                arrayLineageStartEnd = new int [sizeForCopy+50];
                lineageStartEndLimit = (int)sizeForCopy+50;
                lineageStartEndStatus = 1;
            }
            else if (sizeForCopy > lineageStartEndCount){
                delete [] arrayLineageStartEnd;
                arrayLineageStartEnd = new int [sizeForCopy+50];
                lineageStartEndLimit = (int)sizeForCopy+50;
            }
            
            lineageStartEndCount = 0;
            
            if (sizeForCopy != 0){
                fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        sizeForCopy = 0;
        
        if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
        arrayCellNumberInfo = new int [sizeForCopy*2+50];
        cellNumberInfoCount = 0;
        cellNumberInfoLimit = (int)sizeForCopy*2+50;
        cellNumberInfoStatus = 1;
        
        if (sizeForCopy != 0){
            fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        listCrickMonitor = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = treatmentStatusCount/9;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    string trackName = arrayTreatmentStatus [rowIndex*9];
    
    NSAttributedString *attrStr;
    
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(trackName.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallSearchCount++;
    tableNewRowHoldSearch = rowIndex;
    
    if (tableCallSearchCount == 2){
        tableRowHoldSearch = rowIndex;
        treatmentNameSearchSelect = arrayTreatmentStatus [tableCurrentRowHoldSearch*9];
    }
    else{
        
        tableRowHoldSearch = rowIndex;
        treatmentNameSearchSelect = arrayTreatmentStatus [rowIndex*9];
    }
    
    return YES;
}

-(IBAction)completeSelect:(id)sender{
    if (queueHoldingStatus == 0 && trackingOn == 1 && timeOneStatus == 0){
        if (lineageNoSelect != -1){
            if (lineageNoSelect == 0){
                lineageNoSelect = 1;
                [lineageSL setStringValue:@"Open"];
                [mainLabel setStringValue:@"Display: Open"];
            }
            else if (lineageNoSelect == 1){
                lineageNoSelect = 2;
                [lineageSL setStringValue:@"Complete"];
                [mainLabel setStringValue:@"Display: Complete"];
            }
            else if (lineageNoSelect == 2){
                lineageNoSelect = 0;
                [lineageSL setStringValue:@"All"];
                [mainLabel setStringValue:@"Display: All"];
            }
            
            searchType = 0;
            
            [lingInfoSL setStringValue:@"nil"];
            [lingInfoCellNoSL setStringValue:@"nil"];
            [lingInfoStatusSL setStringValue:@"nil"];
            [cellInfoSL setStringValue:@"nil"];
            [cellInfoSTtimeSL setStringValue:@"nil"];
            [cellInfoEDtimeSL setStringValue:@"nil"];
            [cellInfoSTStatusSL setStringValue:@"nil"];
            [cellInfoEDStatusSL setStringValue:@"nil"];
            [cellInfoFUMKSL setStringValue:@"nil"];
            
            int searchResults = 0;
            
            searchResults = [self lineageDataReadSearch];
            
            if (searchResults == 0){
                [searchListBrowser reloadColumn:0];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Missing Lineage Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)logicSet1:(id)sender{
    if (logicStatus1 == 0){
        logicStatus1 = 1;
        [logicSL1 setStringValue:@"AND"];
    }
    else if (logicStatus1 == 1){
        logicStatus1 = 2;
        [logicSL1 setStringValue:@"OR"];
    }
    else if (logicStatus1 == 2){
        logicStatus1 = 3;
        [logicSL1 setStringValue:@"NOT"];
    }
    else if (logicStatus1 == 3){
        logicStatus1 = 0;
        [logicSL1 setStringValue:@"nil"];
        
        logicStatus2 = 0;
        [logicSL2 setStringValue:@"nil"];
        
        logicStatus3 = 0;
        [logicSL3 setStringValue:@"nil"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)logicSet2:(id)sender{
    if (logicStatus1 != 0){
        if (logicStatus2 == 0){
            logicStatus2 = 1;
            [logicSL2 setStringValue:@"AND"];
        }
        else if (logicStatus2 == 1){
            logicStatus2 = 2;
            [logicSL2 setStringValue:@"OR"];
        }
        else if (logicStatus2 == 2){
            logicStatus2 = 3;
            [logicSL2 setStringValue:@"NOT"];
        }
        else if (logicStatus2 == 3){
            logicStatus2 = 0;
            [logicSL2 setStringValue:@"nil"];
            
            logicStatus3 = 0;
            [logicSL3 setStringValue:@"nil"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)logicSet3:(id)sender{
    if (logicStatus1 != 0 && logicStatus2 != 0){
        if (logicStatus3 == 0){
            logicStatus3 = 1;
            [logicSL3 setStringValue:@"AND"];
        }
        else if (logicStatus3 == 1){
            logicStatus3 = 2;
            [logicSL3 setStringValue:@"OR"];
        }
        else if (logicStatus3 == 2){
            logicStatus3 = 3;
            [logicSL3 setStringValue:@"NOT"];
        }
        else if (logicStatus3 == 3){
            logicStatus3 = 0;
            [logicSL3 setStringValue:@"nil"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear1:(id)sender{
    if (searchStatus1 != "nil"){
        searchStatus1 = "nil";
        [eventSL1 setStringValue:@"nil"];
        
        lingSearchPosition = 1;
        
        if (searchStatus2 != "nil"){
            searchStatus1 = searchStatus2;
            searchStatus2 = "nil";
            [eventSL1 setStringValue:@(searchStatus1.c_str())];
            [eventSL2 setStringValue:@"nil"];
            
            lingSearchPosition = 2;
        }
        
        if (searchStatus3 != "nil"){
            searchStatus2 = searchStatus3;
            searchStatus3 = "nil";
            [eventSL2 setStringValue:@(searchStatus2.c_str())];
            [eventSL3 setStringValue:@"nil"];
            
            lingSearchPosition = 3;
        }
        
        if (searchStatus4 != "nil"){
            searchStatus3 = searchStatus4;
            searchStatus4 = "nil";
            [eventSL3 setStringValue:@(searchStatus3.c_str())];
            [eventSL4 setStringValue:@"nil"];
            
            lingSearchPosition = 4;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear2:(id)sender{
    if (searchStatus2 != "nil"){
        searchStatus2 = "nil";
        [eventSL2 setStringValue:@"nil"];
        
        lingSearchPosition = 2;
        
        if (searchStatus3 != "nil"){
            searchStatus2 = searchStatus3;
            searchStatus3 = "nil";
            [eventSL2 setStringValue:@(searchStatus2.c_str())];
            [eventSL3 setStringValue:@"nil"];
            
            lingSearchPosition = 3;
        }
        
        if (searchStatus4 != "nil"){
            searchStatus3 = searchStatus4;
            searchStatus4 = "nil";
            [eventSL3 setStringValue:@(searchStatus3.c_str())];
            [eventSL4 setStringValue:@"nil"];
            
            lingSearchPosition = 4;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear3:(id)sender{
    if (searchStatus3 != "nil"){
        searchStatus3 = "nil";
        [eventSL3 setStringValue:@"nil"];
        
        lingSearchPosition = 3;
        
        if (searchStatus4 != "nil"){
            searchStatus3 = searchStatus4;
            searchStatus4 = "nil";
            [eventSL3 setStringValue:@(searchStatus3.c_str())];
            [eventSL4 setStringValue:@"nil"];
            
            lingSearchPosition = 4;
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clear4:(id)sender{
    if (searchStatus4 != "nil"){
        searchStatus4 = "nil";
        [eventSL4 setStringValue:@"nil"];
        
        lingSearchPosition = 4;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)search:(id)sender{
    if (queueHoldingStatus == 0 && trackingOn == 1 && timeOneStatus == 0){
        if (mainSavingInProgress == 0 && cleaningProgress == 0){
            if (lineageNoSelect != -1){
                if (searchStatus1 != "nil" && searchStatus2 != "nil"){
                    if (logicStatus1 == 0){
                        searchStatus2 = "nil";
                        [eventSL2 setStringValue:@"nil"];
                        searchStatus3 = "nil";
                        [eventSL3 setStringValue:@"nil"];
                        searchStatus4 = "nil";
                        [eventSL4 setStringValue:@"nil"];
                    }
                }
                
                if (searchStatus1 != "nil" && searchStatus2 != "nil" && searchStatus3 != "nil"){
                    if (logicStatus2 == 0){
                        searchStatus3 = "nil";
                        [eventSL3 setStringValue:@"nil"];
                        searchStatus4 = "nil";
                        [eventSL4 setStringValue:@"nil"];
                    }
                }
                
                if (searchStatus1 != "nil" && searchStatus2 != "nil" && searchStatus3 != "nil" && searchStatus4 != "nil"){
                    if (logicStatus3 == 0){
                        searchStatus4 = "nil";
                        [eventSL4 setStringValue:@"nil"];
                    }
                }
                
                searchFlag = 1;
                searchType = 0;
                
                [mainLabel setStringValue:@"Display: Search"];
                
                [lingInfoSL setStringValue:@"nil"];
                [lingInfoCellNoSL setStringValue:@"nil"];
                [lingInfoStatusSL setStringValue:@"nil"];
                [cellInfoSL setStringValue:@"nil"];
                [cellInfoSTtimeSL setStringValue:@"nil"];
                [cellInfoEDtimeSL setStringValue:@"nil"];
                [cellInfoSTStatusSL setStringValue:@"nil"];
                [cellInfoEDStatusSL setStringValue:@"nil"];
                [cellInfoFUMKSL setStringValue:@"nil"];
                
                int searchResults = 0;
                
                searchResults = [self lineageDataReadSearch];
                
                //for (int counterA = 1; counterA < lineageListCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                //    cout<<" arrayLineageList "<<counterA<<endl;
                //}
                
                if (searchResults == 0){
                    [searchListBrowser reloadColumn:0];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    searchFlag = 0;
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Missing Lineage Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
        }
        else if (trackingOn == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(int)lineageDataReadSearch{
    int returnValue = 0;
    
    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameSearch+"_Connect/"+ analysisID+"_"+treatmentNameSearch+"_LineageData";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    int errorFind = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    if (checkFlag == 1){
        if (lineageDataSearchStatus == 1) delete [] arrayLineageSearchData;
        arrayLineageSearchData = new int [sizeForCopy+50];
        lineageDataSearchCount = 0;
        lineageDataSearchStatus = 1;
        
        ifstream fin;
        
        int finData [25];
        
        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
        
        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
        fin.read((char*)uploadTemp, sizeForCopy+50);
        
        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
            usleep(50000);
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                errorFind = 1;
            }
        }
        
        fin.close();
        
        if (errorFind == 0){
            unsigned long readPosition = 0;
            int stepCount = 0;
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++;
                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                    finData [15] = uploadTemp [readPosition], readPosition++;
                    finData [16] = uploadTemp [readPosition], readPosition++;
                    finData [17] = uploadTemp [readPosition], readPosition++;
                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                    finData [19] = uploadTemp [readPosition], readPosition++;
                    finData [20] = uploadTemp [readPosition], readPosition++;
                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                    finData [22] = uploadTemp [readPosition], readPosition++;
                    finData [23] = uploadTemp [readPosition], readPosition++;
                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                    
                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                    else finData [2] = finData [1]*256+finData [2];
                    
                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                    else finData [5] = finData [4]*256+finData [5];
                    
                    finData [7] = finData [6]*256+finData [7];
                    
                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                    
                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                    
                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                    
                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                    else{
                        
                        arrayLineageSearchData [lineageDataSearchCount] = finData [2], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [5], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [7], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [8], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [13], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [18], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [21], lineageDataSearchCount++;
                        arrayLineageSearchData [lineageDataSearchCount] = finData [24], lineageDataSearchCount++;
                    }
                }
                
            } while (stepCount != 3);
        }
        
        delete [] uploadTemp;
        
        //for (int counterA = 0; counterA < lineageDataSearchCount/8; counterA++){
        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageSearchData [counterA*8+counterB];
        //    cout<<" lineageDataSearch "<<counterA<<endl;
        //}
        
        if (checkFlag == 1 && errorFind == 0){
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameSearch+"_Connect/"+ analysisID+"_"+treatmentNameSearch+"_LineageStartEnd";
            
            sizeForCopy = 0;
            
            if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (lineageStartEndSearchStatus == 1) delete [] arrayLineageStartEndSearch;
            arrayLineageStartEndSearch = new int [sizeForCopy+50];
            lineageStartEndSearchCount = 0;
            lineageStartEndSearchStatus = 1;
            
            if (sizeForCopy != 0){
                fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp2 = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp2, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    unsigned long readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp2 [readPosition] != 10) dataString = dataString+uploadTemp2 [readPosition];
                        else if (dataString != "End"){
                            arrayLineageStartEndSearch [lineageStartEndSearchCount] = atoi(dataString.c_str()), lineageStartEndSearchCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp2;
                }
            }
            
            //for (int counterA = 0; counterA < lineageStartEndSearchCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEndSearch [counterA*8+counterB];
            //	cout<<" lineageStartEndSearchCount "<<counterA<<endl;
            //}
            
            int lastLineageNo = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndSearchCount/8; counter1++){
                if (arrayLineageStartEndSearch [counter1*8] > lastLineageNo) lastLineageNo = arrayLineageStartEndSearch [counter1*8];
            }
            
            if (lineageListStatus == 1) delete [] arrayLineageList;
            arrayLineageList = new int [lastLineageNo*5+50];
            lineageListStatus = 1;
            lineageListCount = lastLineageNo;
            
            for (int counter1 = 0; counter1 < lastLineageNo*5+50; counter1++) arrayLineageList [counter1] = 0;
            
            if (searchFlag == 0){
                int lineageNoTemp = 0;
                int openCloseStatus = 0;
                int markerStatus = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndSearchCount/8; counter1++){
                    lineageNoTemp = arrayLineageStartEndSearch [counter1*8];
                    
                    arrayLineageList [lineageNoTemp*5] = 1;
                    arrayLineageList [lineageNoTemp*5+2] = -1;
                    
                    openCloseStatus = 0;
                    markerStatus = 0;
                    
                    for (int counter2 = arrayLineageStartEndSearch [counter1*8+4]; counter2 <= arrayLineageStartEndSearch [counter1*8+6]; counter2++){
                        if (arrayLineageSearchData [counter2*8+3] == 32 || arrayLineageSearchData [counter2*8+3] == 42 || arrayLineageSearchData [counter2*8+3] == 52 || arrayLineageSearchData [counter2*8+3] == 7 || arrayLineageSearchData [counter2*8+3] == 8 || arrayLineageSearchData [counter2*8+3] == 91 || arrayLineageSearchData [counter2*8+3] == 13){
                            openCloseStatus = 1;
                        }
                        
                        if (arrayLineageSearchData [counter2*8+3] == 10) markerStatus = 1;
                    }
                    
                    arrayLineageList [lineageNoTemp*5] = 1;
                    
                    if (markerStatus == 1) arrayLineageList [lineageNoTemp*5+4] = 1;
                    
                    if (arrayLineageList [lineageNoTemp*5+2] == -1 && openCloseStatus == 1) arrayLineageList [lineageNoTemp*5+2] = 1;
                    else if (arrayLineageList [lineageNoTemp*5+2] == -1 && openCloseStatus == 0) arrayLineageList [lineageNoTemp*5+2] = 0;
                    else if (arrayLineageList [lineageNoTemp*5+2] != -1 && openCloseStatus == 0) arrayLineageList [lineageNoTemp*5+2] = 0;
                    
                    arrayLineageList [lineageNoTemp*5+1]++;
                }
                
                //for (int counterA = 1; counterA < lineageListCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                //    cout<<" arrayLineageList "<<counterA<<endl;
                //}
                
                if (lineageNoSelect == 1){
                    for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                        if (arrayLineageList [counter1*5+2] == 1) arrayLineageList [counter1*5] = 0;
                    }
                }
                else if (lineageNoSelect == 2){
                    for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                        if (arrayLineageList [counter1*5+2] == 0) arrayLineageList [counter1*5] = 0;
                    }
                }
            }
            else if (searchFlag == 1){
                int *arrayLineageListTemp = new int [lastLineageNo*10+50];
                
                for (int counter1 = 0; counter1 < lastLineageNo*10+50; counter1++) arrayLineageListTemp [counter1] = 0;
                
                int searchType1 = -1;
                
                if (searchStatus1 == "IN") searchType1 = 0;
                else if (searchStatus1 == "BD") searchType1 = 1;
                else if (searchStatus1 == "TD") searchType1 = 2;
                else if (searchStatus1 == "HD") searchType1 = 3;
                else if (searchStatus1 == "OF") searchType1 = 4;
                else if (searchStatus1 == "CD") searchType1 = 5;
                else if (searchStatus1 == "CF") searchType1 = 6;
                else if (searchStatus1 == "IP") searchType1 = 7;
                else if (searchStatus1 == "FM") searchType1 = 8;
                else if (searchStatus1 == "MI") searchType1 = 9;
                
                int searchType2 = -1;
                
                if (searchStatus2 == "IN") searchType2 = 0;
                else if (searchStatus2 == "BD") searchType2 = 1;
                else if (searchStatus2 == "TD") searchType2 = 2;
                else if (searchStatus2 == "HD") searchType2 = 3;
                else if (searchStatus2 == "OF") searchType2 = 4;
                else if (searchStatus2 == "CD") searchType2 = 5;
                else if (searchStatus2 == "CF") searchType2 = 6;
                else if (searchStatus2 == "IP") searchType2 = 7;
                else if (searchStatus2 == "FM") searchType2 = 8;
                else if (searchStatus2 == "MI") searchType2 = 9;
                
                int searchType3 = -1;
                
                if (searchStatus3 == "IN") searchType3 = 0;
                else if (searchStatus3 == "BD") searchType3 = 1;
                else if (searchStatus3 == "TD") searchType3 = 2;
                else if (searchStatus3 == "HD") searchType3 = 3;
                else if (searchStatus3 == "OF") searchType3 = 4;
                else if (searchStatus3 == "CD") searchType3 = 5;
                else if (searchStatus3 == "CF") searchType3 = 6;
                else if (searchStatus3 == "IP") searchType3 = 7;
                else if (searchStatus3 == "FM") searchType3 = 8;
                else if (searchStatus3 == "MI") searchType3 = 9;
                
                int searchType4 = -1;
                
                if (searchStatus4 == "IN") searchType4 = 0;
                else if (searchStatus4 == "BD") searchType4 = 1;
                else if (searchStatus4 == "TD") searchType4 = 2;
                else if (searchStatus4 == "HD") searchType4 = 3;
                else if (searchStatus4 == "OF") searchType4 = 4;
                else if (searchStatus4 == "CD") searchType4 = 5;
                else if (searchStatus4 == "CF") searchType4 = 6;
                else if (searchStatus4 == "IP") searchType4 = 7;
                else if (searchStatus4 == "FM") searchType4 = 8;
                else if (searchStatus4 == "MI") searchType4 = 9;
                
                int lineageNoTemp = 0;
                int openCloseStatus = 0;
                int markerStatus = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndSearchCount/8; counter1++){
                    lineageNoTemp = arrayLineageStartEndSearch [counter1*8];
                    
                    arrayLineageList [lineageNoTemp*5] = 1;
                    arrayLineageList [lineageNoTemp*5+2] = -1;
                    
                    openCloseStatus = 0;
                    markerStatus = 0;
                    
                    for (int counter2 = arrayLineageStartEndSearch [counter1*8+4]; counter2 <= arrayLineageStartEndSearch [counter1*8+6]; counter2++){
                        if (arrayLineageSearchData [counter2*8+3] == 32 || arrayLineageSearchData [counter2*8+3] == 42 || arrayLineageSearchData [counter2*8+3] == 52 || arrayLineageSearchData [counter2*8+3] == 7 || arrayLineageSearchData [counter2*8+3] == 8 || arrayLineageSearchData [counter2*8+3] == 91 || arrayLineageSearchData [counter2*8+3] == 13){
                            openCloseStatus = 1;
                        }
                        
                        if (arrayLineageSearchData [counter2*8+3] == 10) markerStatus = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 1) arrayLineageListTemp [lineageNoTemp*10] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 31) arrayLineageListTemp [lineageNoTemp*10+1] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 41) arrayLineageListTemp [lineageNoTemp*10+2] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 51) arrayLineageListTemp [lineageNoTemp*10+3] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 8) arrayLineageListTemp [lineageNoTemp*10+4] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 7) arrayLineageListTemp [lineageNoTemp*10+5] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 91 || arrayLineageSearchData [counter2*8+3] == 92) arrayLineageListTemp [lineageNoTemp*10+6] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 11) arrayLineageListTemp [lineageNoTemp*10+7] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 10) arrayLineageListTemp [lineageNoTemp*10+8] = 1;
                        if (arrayLineageSearchData [counter2*8+3] == 6) arrayLineageListTemp [lineageNoTemp*10+9] = 1;
                    }
                    
                    arrayLineageList [lineageNoTemp*5] = 1;
                    
                    if (markerStatus == 1) arrayLineageList [lineageNoTemp*5+4] = 1;
                    
                    if (arrayLineageList [lineageNoTemp*5+2] == -1 && openCloseStatus == 1) arrayLineageList [lineageNoTemp*5+2] = 1;
                    else if (arrayLineageList [lineageNoTemp*5+2] == -1 && openCloseStatus == 0) arrayLineageList [lineageNoTemp*5+2] = 0;
                    else if (arrayLineageList [lineageNoTemp*5+2] != -1 && openCloseStatus == 0) arrayLineageList [lineageNoTemp*5+2] = 0;
                    
                    arrayLineageList [lineageNoTemp*5+1]++;
                }
                
                //for (int counterA = 1; counterA < lineageListCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                //    cout<<" arrayLineageList "<<counterA<<endl;
                //}
                
                //for (int counterA = 1; counterA < lineageListCount; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayLineageListTemp [counterA*10+counterB];
                //    cout<<" arrayLineageListTemp "<<counterA<<endl;
                //}
                
                if (searchType1 != -1){
                    for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                        if (arrayLineageList [counter1*5] != 0 && arrayLineageListTemp [counter1*10+searchType1] != 0) arrayLineageList [counter1*5] = 2;
                    }
                }
                
                if (searchType2 != -1){
                    if (logicStatus1 == 1){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] == 2 && arrayLineageListTemp [counter1*10+searchType2] == 0){
                                arrayLineageList [counter1*5] = 1;
                            }
                        }
                    }
                    else if (logicStatus1 == 2){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] != 0 && arrayLineageListTemp [counter1*10+searchType2] != 0) arrayLineageList [counter1*5] = 2;
                        }
                    }
                    else if (logicStatus1 == 3){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] == 2 && arrayLineageListTemp [counter1*10+searchType2] != 0){
                                arrayLineageList [counter1*5] = 1;
                            }
                        }
                    }
                }
                
                if (searchType3 != -1){
                    if (logicStatus2 == 1){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] == 2 && arrayLineageListTemp [counter1*10+searchType3] == 0){
                                arrayLineageList [counter1*5] = 1;
                            }
                        }
                    }
                    else if (logicStatus2 == 2){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] != 0 && arrayLineageListTemp [counter1*10+searchType3] != 0) arrayLineageList [counter1*5] = 2;
                        }
                    }
                    else if (logicStatus2 == 3){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] == 2 && arrayLineageListTemp [counter1*10+searchType3] != 0){
                                arrayLineageList [counter1*5] = 1;
                            }
                        }
                    }
                }
                
                if (searchType4 != -1){
                    if (logicStatus3 == 1){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] == 2 && arrayLineageListTemp [counter1*10+searchType4] == 0){
                                arrayLineageList [counter1*5] = 1;
                            }
                        }
                    }
                    else if (logicStatus3 == 2){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] != 0 && arrayLineageListTemp [counter1*10+searchType4] != 0) arrayLineageList [counter1*5] = 2;
                        }
                    }
                    else if (logicStatus3 == 3){
                        for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                            if (arrayLineageList [counter1*5] == 2 && arrayLineageListTemp [counter1*10+searchType4] != 0){
                                arrayLineageList [counter1*5] = 1;
                            }
                        }
                    }
                }
                
                for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                    if (arrayLineageList [counter1*5] == 2) arrayLineageList [counter1*5] = 1;
                    else if (arrayLineageList [counter1*5] == 1) arrayLineageList [counter1*5] = 0;
                }
                
                //for (int counterA = 1; counterA < lineageListCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                //    cout<<" arrayLineageList "<<counterA<<endl;
                //}
                
                delete [] arrayLineageListTemp;
            }
            else if (searchFlag == 2){
                int *arrayLineageListTemp = new int [lastLineageNo+50];
                
                //for (int counterA = 0; counterA < lineageDataSearchCount/8; counterA++){
                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageSearchData [counterA*8+counterB];
                //	cout<<" lineageData "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < lastLineageNo+50; counter1++) arrayLineageListTemp [counter1] = 0;
                
                int lineageNoTemp = 0;
                int openCloseStatus = 0;
                int markerStatus = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndSearchCount/8; counter1++){
                    lineageNoTemp = arrayLineageStartEndSearch [counter1*8];
                    
                    arrayLineageList [lineageNoTemp*5] = 1;
                    arrayLineageList [lineageNoTemp*5+2] = -1;
                    
                    openCloseStatus = 0;
                    markerStatus = 0;
                    
                    for (int counter2 = arrayLineageStartEndSearch [counter1*8+4]; counter2 <= arrayLineageStartEndSearch [counter1*8+6]; counter2++){
                        if (arrayLineageSearchData [counter2*8+3] == 32 || arrayLineageSearchData [counter2*8+3] == 42 || arrayLineageSearchData [counter2*8+3] == 52 || arrayLineageSearchData [counter2*8+3] == 7 || arrayLineageSearchData [counter2*8+3] == 8 || arrayLineageSearchData [counter2*8+3] == 91 || arrayLineageSearchData [counter2*8+3] == 13){
                            openCloseStatus = 1;
                        }
                        
                        if (arrayLineageSearchData [counter2*8+3] == 10) markerStatus = 1;
                        
                        if (lingNoSearchHold != 0 && arrayLineageSearchData [counter2*8+7] == lingNoSearchHold){
                            if (arrayLineageSearchData [counter2*8+6] != lingNoSearchHold) arrayLineageListTemp [lineageNoTemp] = 1;
                        }
                    }
                    
                    arrayLineageList [lineageNoTemp*5] = 1;
                    
                    if (markerStatus == 1) arrayLineageList [lineageNoTemp*5+4] = 1;
                    
                    if (arrayLineageList [lineageNoTemp*5+2] == -1 && openCloseStatus == 1) arrayLineageList [lineageNoTemp*5+2] = 1;
                    else if (arrayLineageList [lineageNoTemp*5+2] == -1 && openCloseStatus == 0) arrayLineageList [lineageNoTemp*5+2] = 0;
                    else if (arrayLineageList [lineageNoTemp*5+2] != -1 && openCloseStatus == 0) arrayLineageList [lineageNoTemp*5+2] = 0;
                    
                    arrayLineageList [lineageNoTemp*5+1]++;
                }
                
                for (int counter1 = 1; counter1 <= lineageListCount; counter1++){
                    if (arrayLineageListTemp [counter1] != 0) arrayLineageList [counter1*5] = 1;
                    else arrayLineageList [counter1*5] = 0;
                }
                
                arrayLineageList [lingNoSearchHold*5] = 1;
                
                delete [] arrayLineageListTemp;
            }
            else if (searchFlag == 3){
                if (searchCellListStatus == 0){
                    arraySearchCellList = new int [500];
                    searchCellListStatus = 1;
                    searchCellListCount = 0;
                }
                else  searchCellListCount = 0;
                
                int findFlag = 0;
                
                //for (int counterA = 1; counterA < lineageListCount; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
                //    cout<<" arrayLineageList "<<counterA<<endl;
                //}
                
                for (int counter2 = 0; counter2 < lineageDataSearchCount/8; counter2++){
                    if (arrayLineageSearchData [counter2*8+3] == 31 || arrayLineageSearchData [counter2*8+3] == 41 || arrayLineageSearchData [counter2*8+3] == 51){
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < lineageDataSearchCount/8; counter3++){
                            if (arrayLineageSearchData [counter3*8+6] == arrayLineageSearchData [counter2*8+6] && arrayLineageSearchData [counter3*8+2] == arrayLineageSearchData [counter2*8+2]-1 && arrayLineageSearchData [counter3*8+5] == arrayLineageSearchData [counter2*8+4]){
                                
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            if (searchCellListCount < 500){
                                arrayLineageList [arrayLineageSearchData [counter2*8+6]*5] = 1;
                                arrayLineageList [arrayLineageSearchData [counter2*8+6]*5+2] = -1;
                                
                                arraySearchCellList [searchCellListCount] = arrayLineageSearchData [counter2*8+6], searchCellListCount++;
                                arraySearchCellList [searchCellListCount] = arrayLineageSearchData [counter2*8+4], searchCellListCount++;
                            }
                        }
                    }
                }
            }
            
            //for (int counterA = 1; counterA <= lineageListCount; counterA++){
            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayLineageList [counterA*5+counterB];
            //	cout<<" arrayLineageList "<<counterA<<endl;
            //}
            
            [treatmentSL setStringValue:@(treatmentNameSearch.c_str())];
        }
        else{
            
            lineageNoSelect = -1;
            
            if (lineageListStatus == 1) delete [] arrayLineageList;
            arrayLineageList = new int [50];
            lineageListStatus = 1;
            lineageListCount = 0;
            
            for (int counter1 = 0; counter1 < 50; counter1++) arrayLineageList [counter1] = 0;
            
            [treatmentSL setStringValue:@(treatmentNameSearch.c_str())];
            
            returnValue = -1;
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Missing Lineage Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        lineageNoSelect = -1;
        
        if (lineageListStatus == 1) delete [] arrayLineageList;
        arrayLineageList = new int [50];
        lineageListStatus = 1;
        lineageListCount = 0;
        
        for (int counter1 = 0; counter1 < 50; counter1++) arrayLineageList [counter1] = 0;
        
        [treatmentSL setStringValue:@(treatmentNameSearch.c_str())];
        
        returnValue = -1;
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Missing Lineage Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return returnValue;
}

-(IBAction)fusionPartner:(id)sender{
    if (queueHoldingStatus == 0 && trackingOn == 1 && timeOneStatus == 0){
        if (mainSavingInProgress == 0 && cleaningProgress == 0){
            if (lineageNoSelect != -1){
                searchFlag = 2;
                searchType = 0;
                
                [mainLabel setStringValue:@"Display: Fused Lineages"];
                
                [lingInfoSL setStringValue:@"nil"];
                [lingInfoCellNoSL setStringValue:@"nil"];
                [lingInfoStatusSL setStringValue:@"nil"];
                [cellInfoSL setStringValue:@"nil"];
                [cellInfoSTtimeSL setStringValue:@"nil"];
                [cellInfoEDtimeSL setStringValue:@"nil"];
                [cellInfoSTStatusSL setStringValue:@"nil"];
                [cellInfoEDStatusSL setStringValue:@"nil"];
                [cellInfoFUMKSL setStringValue:@"nil"];
                
                int searchResults = 0;
                
                searchResults = [self lineageDataReadSearch];
                
                if (searchResults == 0){
                    [searchListBrowser reloadColumn:0];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    searchFlag = 0;
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Missing Lineage Data"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)setIN:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"IN"];
        searchStatus1 = "IN";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"IN"];
        searchStatus2 = "IN";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"IN"];
        searchStatus3 = "IN";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"IN"];
        searchStatus4 = "IN";
        lingSearchPosition++;
    }
}

-(IBAction)setDD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"BD"];
        searchStatus1 = "BD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"BD"];
        searchStatus2 = "BD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"BD"];
        searchStatus3 = "BD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"BD"];
        searchStatus4 = "BD";
        lingSearchPosition++;
    }
}

-(IBAction)setTD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"TD"];
        searchStatus1 = "TD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"TD"];
        searchStatus2 = "TD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"TD"];
        searchStatus3 = "TD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"TD"];
        searchStatus4 = "TD";
        lingSearchPosition++;
    }
}

-(IBAction)setHD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"HD"];
        searchStatus1 = "HD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"HD"];
        searchStatus2 = "HD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"HD"];
        searchStatus3 = "HD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"HD"];
        searchStatus4 = "HD";
        lingSearchPosition++;
    }
}

-(IBAction)setOF:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"OF"];
        searchStatus1 = "OF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"OF"];
        searchStatus2 = "OF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"OF"];
        searchStatus3 = "OF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"OF"];
        searchStatus4 = "OF";
        lingSearchPosition++;
    }
}

-(IBAction)setCD:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"CD"];
        searchStatus1 = "CD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"CD"];
        searchStatus2 = "CD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"CD"];
        searchStatus3 = "CD";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"CD"];
        searchStatus4 = "CD";
        lingSearchPosition++;
    }
}

-(IBAction)setIP:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"IP"];
        searchStatus1 = "IP";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"IP"];
        searchStatus2 = "IP";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"IP"];
        searchStatus3 = "IP";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"IP"];
        searchStatus4 = "IP";
        lingSearchPosition++;
    }
}

-(IBAction)setMI:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"MI"];
        searchStatus1 = "MI";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"MI"];
        searchStatus2 = "MI";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"MI"];
        searchStatus3 = "MI";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"MI"];
        searchStatus4 = "MI";
        lingSearchPosition++;
    }
}

-(IBAction)setCF:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"CF"];
        searchStatus1 = "CF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"CF"];
        searchStatus2 = "CF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"CF"];
        searchStatus3 = "CF";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"CF"];
        searchStatus4 = "CF";
        lingSearchPosition++;
    }
}

-(IBAction)setFM:(id)sender{
    if (lingSearchPosition == 1){
        [eventSL1 setStringValue:@"FM"];
        searchStatus1 = "FM";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 2){
        [eventSL2 setStringValue:@"FM"];
        searchStatus2 = "FM";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 3){
        [eventSL3 setStringValue:@"FM"];
        searchStatus3 = "FM";
        lingSearchPosition++;
    }
    else if (lingSearchPosition == 4){
        [eventSL4 setStringValue:@"FM"];
        searchStatus4 = "FM";
        lingSearchPosition++;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSearchOperations object:nil];
}

@end
