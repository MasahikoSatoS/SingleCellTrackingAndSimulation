//
//  ActiveProcessMonitor.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-03-09.
//
//

#import "ActiveProcessMonitor.h"

NSString *notificationToActiveProcess = @"notificationExecuteActiveProcess";

@implementation ActiveProcessMonitor

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToActiveProcess object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    activeProcessTimer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(processControl) userInfo:nil repeats:YES];
}

-(void)processControl{
    NSString *activeProcess;
    
    int cellCurvingActive = 0;
    
    if (runStatusCellCurving > 0) cellCurvingActive = 1;
    
    for (NSRunningApplication *currApp in [[NSWorkspace sharedWorkspace] runningApplications]){
        activeProcess = [currApp localizedName];
        
        //NSLog (@"%@", activeProcess);
        
        if ([activeProcess isEqualToString:@"Cell_Carving"]) cellCurvingActive = 2;
    }
    
    if (cellCurvingActive == 1) cellCurvingRunningFlag = 2; //============Put back on
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToActiveProcess object:nil];
    if (activeProcessTimer) [activeProcessTimer invalidate];
}

@end
