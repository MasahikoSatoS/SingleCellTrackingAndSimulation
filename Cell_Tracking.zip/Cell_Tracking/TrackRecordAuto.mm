//
// TrackRecordAuto.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 22/11/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackRecordAuto.h"

@implementation TrackRecordAuto

-(int)trackDataAutoMain{
    int returnResults = 0;
    
    subCompleteFlag = 1;
    
    string cellLineageExtract = lineageNoAuto.substr(1);
    string cellNoExtract = cellNoAuto.substr(1);
    int lineageAmendTemp = atoi(cellLineageExtract.c_str());
    int cellAmendTemp = atoi(cellNoExtract.c_str());
    
    int imageEndAuto = 0;
    
    for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
        if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
            imageEndAuto = atoi(arrayTreatmentStatus [counter1*9+8].c_str());
            break;
        }
    }
    
    //-----"eventTemp" file need to be created by cell curving-----
    string lineageCommPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+analysisID+"_"+treatmentNameAuto+"_LineageData";
    string startEndCommPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+analysisID+"_"+treatmentNameAuto+"_LineageStartEnd";
    string eventTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_EventTemp";
    string mitosisTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_MitosisDataTemp";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    int readingError = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(lineageCommPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    ifstream fin;
    
    int *lineageCommTemp = new int [sizeForCopy+50];
    int lineageCommTempCount = 0;
    
    readingError = 0;
    
    if (checkFlag == 1){
        int finData [25];
        
        fin.open(lineageCommPath.c_str(), ios::in | ios::binary);
        
        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
        fin.read((char*)uploadTemp, sizeForCopy+50);
        
        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0 || (finData [0] = uploadTemp [sizeForCopy-21]) != 0 || (finData [0] = uploadTemp [sizeForCopy-22]) != 0 || (finData [0] = uploadTemp [sizeForCopy-23]) != 0 || (finData [0] = uploadTemp [sizeForCopy-24]) != 0 || (finData [0] = uploadTemp [sizeForCopy-25]) != 0){
            usleep(50000);
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0 || (finData [0] = uploadTemp [sizeForCopy-21]) != 0 || (finData [0] = uploadTemp [sizeForCopy-22]) != 0 || (finData [0] = uploadTemp [sizeForCopy-23]) != 0 || (finData [0] = uploadTemp [sizeForCopy-24]) != 0 || (finData [0] = uploadTemp [sizeForCopy-25]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0 || (finData [0] = uploadTemp [sizeForCopy-21]) != 0 || (finData [0] = uploadTemp [sizeForCopy-22]) != 0 || (finData [0] = uploadTemp [sizeForCopy-23]) != 0 || (finData [0] = uploadTemp [sizeForCopy-24]) != 0 || (finData [0] = uploadTemp [sizeForCopy-25]) != 0){
                    readingError = 1;
                }
            }
        }
        
        fin.close();
        
        unsigned long readPosition = 0;
        int stepCount = 0;
        
        if (readingError == 0){
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++;
                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                    finData [15] = uploadTemp [readPosition], readPosition++;
                    finData [16] = uploadTemp [readPosition], readPosition++;
                    finData [17] = uploadTemp [readPosition], readPosition++;
                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                    finData [19] = uploadTemp [readPosition], readPosition++;
                    finData [20] = uploadTemp [readPosition], readPosition++;
                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                    finData [22] = uploadTemp [readPosition], readPosition++;
                    finData [23] = uploadTemp [readPosition], readPosition++;
                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                    
                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                    else finData [2] = finData [1]*256+finData [2];
                    
                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                    else finData [5] = finData [4]*256+finData [5];
                    
                    finData [7] = finData [6]*256+finData [7];
                    
                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                    
                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                    
                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                    
                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                    else{
                        
                        lineageCommTemp [lineageCommTempCount] = finData [2], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [5], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [7], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [8], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [13], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [18], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [21], lineageCommTempCount++;
                        lineageCommTemp [lineageCommTempCount] = finData [24], lineageCommTempCount++;
                    }
                }
                
            } while (stepCount != 3);
        }
        
        delete [] uploadTemp;
    }
    
    if (checkFlag == 1 && readingError == 0){
        sizeForCopy = 0;
        
        if (stat(startEndCommPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *startEndCommTemp = new int [sizeForCopy+50];
        int startEndCommCount = 0;
        
        if (sizeForCopy != 0){
            fin.open(startEndCommPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        startEndCommTemp [startEndCommCount] = atoi(dataString.c_str()), startEndCommCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8+counterB];
        //	cout<<" startEndCommTemp "<<counterA<<endl;
        //}
        
        sizeForCopy = 0;
        
        if (stat(eventTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *eventTemp = new int [sizeForCopy+50];
        int eventTempCount = 0;
        
        if (sizeForCopy != 0){
            string getString;
            
            fin.open(eventTempPath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != "End") eventTemp [eventTempCount] = atoi(getString.c_str()), eventTempCount++;
                    
                } while (getString != "End");
                
                fin.close();
            }
        }
        
        sizeForCopy = 0;
        
        if (stat(mitosisTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *mitosisCommTemp = new int [sizeForCopy+50];
        int mitosisCommTempCount = 0;
        
        if (sizeForCopy != 0){
            string getString;
            
            fin.open(mitosisTempPath.c_str(), ios::in);
            
            if (fin.is_open()){
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != "") mitosisCommTemp [mitosisCommTempCount] = atoi(getString.c_str()), mitosisCommTempCount++;
                    
                } while (getString != "");
                
                fin.close();
            }
        }
        
        //for (int counterA = 0; counterA < mitosisCommTempCount/4; counterA++){
        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mitosisCommTemp [counterA*4+counterB];
        //	cout<<" mitosisCommTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8+counterB];
        //    cout<<" startEndCommTemp "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineageCommTempCount/8; counterA++){
        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageCommTemp [counterA*8+counterB];
        //    cout<<" lineageCommTemp "<<counterA<<endl;
        //}
        //}
        
        //cout<<lineageCommTempCount<<" "<<startEndCommCount<<" "<<eventTempCount<<" Proceeding"<<endl;
        
        int eventEntryNoCheck = 0;
        
        for (int counter1 = 0; counter1 < eventTempCount/4; counter1++){
            if (eventTemp [counter1*4] != 0) eventEntryNoCheck++;
        }
        
        if (lineageCommTempCount != 0 && startEndCommCount != 0 && eventEntryNoCheck != 0){
            //-----Lineage Start-----
            int lineageEntryStart = 10000;
            int lineageEntryEnd = 0; //-----Image no-----
            int lineageStartPosition = 0;
            int lineageEndPosition = 0;
            
            for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                if (startEndCommTemp [counter1*8] == lineageAmendTemp && startEndCommTemp [counter1*8+1] == cellAmendTemp){
                    
                    if (startEndCommTemp [counter1*8+7] > lineageEntryEnd){
                        lineageEntryEnd = startEndCommTemp [counter1*8+7];
                        lineageEndPosition = startEndCommTemp [counter1*8+6];
                    }
                    
                    if (startEndCommTemp [counter1*8+5] < lineageEntryStart){
                        lineageEntryStart = startEndCommTemp [counter1*8+5];
                        lineageStartPosition = startEndCommTemp [counter1*8+4];
                    }
                }
            }
            
            int initialParentNumber = lineageCommTemp [lineageStartPosition*8+4];
            int endParentLingNumber = lineageCommTemp [lineageEndPosition*8+7];
            int endParentCellNumber = lineageCommTemp [lineageEndPosition*8+4];
            
            //cout<<lineageEntryStart<<" "<<lineageEntryEnd<<" "<<lineageStartPosition<<" "<<endParentLingNumber<<" "<<endParentCellNumber<<" Status"<<endl;
            
            //-----1. Image no, 2. Event type, 3. lineage no, 4. cell no-----
            
            int eventEntryMax = 0;
            
            for (int counter1 = 0; counter1 < eventTempCount/4; counter1++){
                if (eventEntryMax < eventTemp [counter1*4]) eventEntryMax = eventTemp [counter1*4];
            }
            
            int *arrayEventSequenceReorganize = new int [eventTempCount*2+1];
            int eventSequenceReorganizeCount = 0;
            
            for (int counter1 = 0; counter1 < eventTempCount*2; counter1++){
                arrayEventSequenceReorganize [counter1] = 0;
            }
            
            int newUpperLimit = 0;
            
            for (int counter1 = lineageEntryStart; counter1 <= eventEntryMax; counter1++){
                for (int counter2 = 0; counter2 < eventTempCount/4; counter2++){
                    if (eventTemp [counter2*4] == counter1){
                        arrayEventSequenceReorganize [eventSequenceReorganizeCount] = eventTemp [counter2*4], eventSequenceReorganizeCount++;
                        arrayEventSequenceReorganize [eventSequenceReorganizeCount] = eventTemp [counter2*4+1], eventSequenceReorganizeCount++;
                        arrayEventSequenceReorganize [eventSequenceReorganizeCount] = eventTemp [counter2*4+2], eventSequenceReorganizeCount++;
                        arrayEventSequenceReorganize [eventSequenceReorganizeCount] = eventTemp [counter2*4+3], eventSequenceReorganizeCount++;
                    }
                    if (newUpperLimit == 0 && eventTemp [counter2*4] == counter1 && (eventTemp [counter2*4+1] == 32 || eventTemp [counter2*4+1] == 33 || eventTemp [counter2*4+1] == 42 || eventTemp [counter2*4+1] == 43 || eventTemp [counter2*4+1] == 44 || eventTemp [counter2*4+1] == 52 || eventTemp [counter2*4+1] == 53 || eventTemp [counter2*4+1] == 54 || eventTemp [counter2*4+1] == 55)){
                        newUpperLimit = counter1;
                    }
                    
                    if (newUpperLimit == 0 && eventTemp [counter2*4] == counter1 && (eventTemp [counter2*4+1] == 7 || eventTemp [counter2*4+1] == 8 || eventTemp [counter2*4+1] == 91)){
                        newUpperLimit = counter1;
                    }
                }
            }
            
            if (newUpperLimit == 0) newUpperLimit = eventEntryMax;
            
            int firstEventTimePoint = 0;
            int upperLimitEventType = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                    upperLimitEventType = arrayEventSequenceReorganize [counter1*4+1];
                    break;
                }
                
                if (counter1 == 0) firstEventTimePoint = arrayEventSequenceReorganize [counter1*4];
            }
            
            int mitosisNumberCheck = 0;
            int lastMitosisPosition = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                if (arrayEventSequenceReorganize [counter1*4+1] == 6){
                    mitosisNumberCheck++;
                    lastMitosisPosition = counter1;
                }
            }
            
            if (mitosisNumberCheck > 1){
                for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                    if (arrayEventSequenceReorganize [counter1*4+1] == 6 && arrayEventSequenceReorganize [counter1*4] != lastMitosisPosition){
                        arrayEventSequenceReorganize [counter1*4+1] = 2;
                    }
                }
            }
            
            //cout<<newUpperLimit<<" "<<upperLimitEventType<<" UpLimit_Type "<<firstEventTimePoint<<endl;
            
            //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8+counterB];
            //	cout<<" startEndCommTemp "<<counterA<<endl;
            //}
            
            string extension = "";
            
            //-----Extract relevant lineage data-----
            int *arrayLineageExtractionAuto = new int [10000];
            int lineageExtractionAutoCount = 0;
            int lineageExtractionAutoLimit = 10000;
            
            for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                if (startEndCommTemp [counter1*8] == lineageAmendTemp){
                    for (int counter2 = startEndCommTemp [counter1*8+4]; counter2 <= startEndCommTemp [counter1*8+6]; counter2++){
                        if (lineageExtractionAutoCount+8 > lineageExtractionAutoLimit){
                            int *arrayUpDate = new int [lineageExtractionAutoCount+10];
                            
                            for (int counter3 = 0; counter3 < lineageExtractionAutoCount; counter3++) arrayUpDate [counter3] = arrayLineageExtractionAuto [counter3];
                            
                            delete [] arrayLineageExtractionAuto;
                            arrayLineageExtractionAuto = new int [lineageExtractionAutoLimit+10000];
                            lineageExtractionAutoLimit = lineageExtractionAutoLimit+10000;
                            
                            for (int counter3 = 0; counter3 < lineageExtractionAutoCount; counter3++) arrayLineageExtractionAuto [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+1], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+2], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+3], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+4], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+5], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+6], lineageExtractionAutoCount++;
                        arrayLineageExtractionAuto [lineageExtractionAutoCount] = lineageCommTemp [counter2*8+7], lineageExtractionAutoCount++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractionAutoCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtractionAuto [counterA*8+counterB];
            //	cout<<" lineageExtraction "<<counterA<<endl;
            //}
            
            int lineageEventTypeEqEvent = 0;
            int lineageEventMitosisCount = 0;
            int cellFirstImageNo = 0;
            
            for (int counter1 = 0; counter1 < lineageExtractionAutoCount/8; counter1++){
                if (arrayLineageExtractionAuto [counter1*8+5] == cellAmendTemp && arrayLineageExtractionAuto [counter1*8+2] == firstEventTimePoint){
                    lineageEventTypeEqEvent = arrayLineageExtractionAuto [counter1*8+3];
                }
                
                if (arrayLineageExtractionAuto [counter1*8+5] == cellAmendTemp && arrayLineageExtractionAuto [counter1*8+3] == 6) lineageEventMitosisCount = 1;
                
                if (arrayLineageExtractionAuto [counter1*8+5] == cellAmendTemp){
                    if (cellFirstImageNo == 0) cellFirstImageNo = arrayLineageExtractionAuto [counter1*8+2];
                }
            }
            
            //cout<<lineageEventTypeEqEvent<<" "<<lineageEventMitosisCount<<" eventInfo"<<endl;
            
            //-----Event Sequence Reorganize-----
            //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
            //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
            //-----DEND LineageEntry DEnd 32, TEnd, 42, HEnd 52-----
            
            //-----1. Image no, 2. Event type, 3. lineage no, 4. cell no-----
            
            if (lineageEventMitosisCount == 1){
                for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                    if (arrayEventSequenceReorganize [counter1*4+1] == 6) arrayEventSequenceReorganize [counter1*4+1] = 2;
                }
            }
            
            if (lineageEventTypeEqEvent == 1 || lineageEventTypeEqEvent == 31 || lineageEventTypeEqEvent == 41 || lineageEventTypeEqEvent == 51 || lineageEventTypeEqEvent == 6) arrayEventSequenceReorganize [1] = lineageEventTypeEqEvent;
            
            //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
            //	cout<<" eventSequenceReorganize "<<counterA<<endl;
            //}
            
            //-----Mitosis number check. If there is IP, mitosis number should be after IP-----
            string warningAuto = "";
            int processTypeCell = 0;
            int checkEnd = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                if (arrayEventSequenceReorganize [counter1*4+1] == 11){
                    if (checkEnd == 0) checkEnd = counter1;
                    else if (checkEnd > 0) checkEnd = counter1;
                }
            }
            
            int eventStartPoint = arrayEventSequenceReorganize [0];
            
            //-----Mitosis Event relation check-----
            if (upperLimitEventType == 2) processTypeCell = 1; //-----Track entry-----
            else if (upperLimitEventType == 32 || upperLimitEventType == 33 || upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44 || upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55){
                processTypeCell = 2; //-----Done and progeny entry-----
            }
            else if (upperLimitEventType == 6 || upperLimitEventType == 10 || upperLimitEventType == 11){
                processTypeCell = 1; //-----Track entry-----
            }
            else if (upperLimitEventType == 7 || upperLimitEventType == 8 || upperLimitEventType == 91){
                processTypeCell = 3; //-----Done-----
            }
            else if (upperLimitEventType == 1 || upperLimitEventType == 31 || upperLimitEventType == 41 || upperLimitEventType == 51) processTypeCell = 1;
            
            //-----Cell lineage Construction-----
            int *cellLineageCellExtract = new int [imageEndAuto*8+50];
            
            for (int counter1 = 0; counter1 < imageEndAuto*8+50; counter1++) cellLineageCellExtract [counter1] = 0;
            
            int extractImagePositionData = 0;
            
            for (int counter1 = 0; counter1 < lineageExtractionAutoCount/8; counter1++){
                //-----Extract information of target cell-----
                if (arrayLineageExtractionAuto [counter1*8+5] == cellAmendTemp){
                    extractImagePositionData = arrayLineageExtractionAuto [counter1*8+2];
                    
                    cellLineageCellExtract [extractImagePositionData*8] = arrayLineageExtractionAuto [counter1*8];
                    cellLineageCellExtract [extractImagePositionData*8+1] = arrayLineageExtractionAuto [counter1*8+1];
                    cellLineageCellExtract [extractImagePositionData*8+2] = arrayLineageExtractionAuto [counter1*8+2];
                    cellLineageCellExtract [extractImagePositionData*8+3] = arrayLineageExtractionAuto [counter1*8+3];
                    cellLineageCellExtract [extractImagePositionData*8+4] = arrayLineageExtractionAuto [counter1*8+4];
                    cellLineageCellExtract [extractImagePositionData*8+5] = arrayLineageExtractionAuto [counter1*8+5];
                    cellLineageCellExtract [extractImagePositionData*8+6] = arrayLineageExtractionAuto [counter1*8+6];
                    cellLineageCellExtract [extractImagePositionData*8+7] = arrayLineageExtractionAuto [counter1*8+7];
                }
            }
            
            //for (int counterA = 0; counterA <= newUpperLimit; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellLineageCellExtract [counterA*8+counterB];
            //    cout<<" cellLineageCellExtract "<<counterA<<endl;
            //}
            
            //-----1. X position, 2. Y position, 3. Time point, 4. Event Type, 5. Next Cell number, Fusion: hold cell number of Fusion partner-----
            //-----6. Cell Number, 7. Cell Lineage Number, 8. For Fusion, Cell lineage Number-----
            int *arrayNewCellTemp = new int [50];
            int newCellTempCount = 0;
            
            string extension2;
            string getString;
            string connectDataTempPath;
            string connectStatusTempPath;
            string connectGravityCenterPath;
            
            int newUpperLimitAdjust = 0;
            int newCellNumber = 0;
            int imagePositionData = 0;
            int stepCount = 0;
            int xPositionEntry = 0;
            int yPositionEntry = 0;
            int xPositionSave = 0;
            int yPositionSave = 0;
            int gravityCenterXHoldTemp1 = 0;
            int gravityCenterYHoldTemp1 = 0;
            int gravityCellNoTemp1 = 0;
            int gravityCenterXHoldTemp2 = 0;
            int gravityCenterYHoldTemp2 = 0;
            int gravityCellNoTemp2 = 0;
            int gravityCenterXHoldTemp3 = 0;
            int gravityCenterYHoldTemp3 = 0;
            int gravityCellNoTemp3 = 0;
            int gravityCenterXHoldTemp4 = 0;
            int gravityCenterYHoldTemp4 = 0;
            int gravityCellNoTemp4 = 0;
            int finData [19];
            
            unsigned long readPosition = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                upperLimitEventType = arrayEventSequenceReorganize [counter1*4+1];
                newCellNumber = arrayEventSequenceReorganize [counter1*4+3];
                imagePositionData = arrayEventSequenceReorganize [counter1*4];
                
                arrayTimePointSaveList [imagePositionData] = 1;
                
                extension2 = to_string(arrayEventSequenceReorganize [counter1*4]);
                
                if (extension2.length() == 1) extension2 = "000"+extension2;
                else if (extension2.length() == 2) extension2 = "00"+extension2;
                else if (extension2.length() == 3) extension2 = "0"+extension2;
                
                connectGravityCenterPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension2+"_GCCenterInfo";
                
                fin.open(connectGravityCenterPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    getline(fin, getString), gravityCenterXHoldTemp1 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterYHoldTemp1 = atoi(getString.c_str());
                    getline(fin, getString); //gravityAverageHoldTemp1 = atoi(getString.c_str());
                    getline(fin, getString), gravityCellNoTemp1 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterXHoldTemp2 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterYHoldTemp2 = atoi(getString.c_str());
                    getline(fin, getString); //gravityAverageHoldTemp2 = atoi(getString.c_str());
                    getline(fin, getString), gravityCellNoTemp2 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterXHoldTemp3 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterYHoldTemp3 = atoi(getString.c_str());
                    getline(fin, getString); //gravityAverageHoldTemp3 = atoi(getString.c_str());
                    getline(fin, getString), gravityCellNoTemp3 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterXHoldTemp4 = atoi(getString.c_str());
                    getline(fin, getString), gravityCenterYHoldTemp4 = atoi(getString.c_str());
                    getline(fin, getString); //gravityAverageHoldTemp4 = atoi(getString.c_str());
                    getline(fin, getString), gravityCellNoTemp4 = atoi(getString.c_str());
                    
                    fin.close();
                }
                
                if (upperLimitEventType != 32 && upperLimitEventType != 33 && upperLimitEventType != 42 && upperLimitEventType != 43 && upperLimitEventType != 44 && upperLimitEventType != 52 && upperLimitEventType != 53 && upperLimitEventType != 54 && upperLimitEventType != 55){
                    xPositionSave = gravityCenterXHoldTemp1;
                    yPositionSave = gravityCenterYHoldTemp1;
                }
                else if (upperLimitEventType == 32){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                }
                else if (upperLimitEventType == 33){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                }
                else if (upperLimitEventType == 42){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                }
                else if (upperLimitEventType == 43){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                }
                else if (upperLimitEventType == 44){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                }
                else if (upperLimitEventType == 52){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                    else if (gravityCellNoTemp4 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp4;
                        yPositionSave = gravityCenterYHoldTemp4;
                    }
                }
                else if (upperLimitEventType == 53){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                    else if (gravityCellNoTemp4 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp4;
                        yPositionSave = gravityCenterYHoldTemp4;
                    }
                }
                else if (upperLimitEventType == 54){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                    else if (gravityCellNoTemp4 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp4;
                        yPositionSave = gravityCenterYHoldTemp4;
                    }
                }
                else if (upperLimitEventType == 55){
                    if (gravityCellNoTemp1 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp1;
                        yPositionSave = gravityCenterYHoldTemp1;
                    }
                    else if (gravityCellNoTemp2 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp2;
                        yPositionSave = gravityCenterYHoldTemp2;
                    }
                    else if (gravityCellNoTemp3 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp3;
                        yPositionSave = gravityCenterYHoldTemp3;
                    }
                    else if (gravityCellNoTemp4 == newCellNumber){
                        xPositionSave = gravityCenterXHoldTemp4;
                        yPositionSave = gravityCenterYHoldTemp4;
                    }
                }
                
                //for (int counterA = 0; counterA < relTempCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayRelTemp [counterA*6+counterB];
                //	cout<<" arrayRelTemp "<<counterA<<endl;
                //}
                
                //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target, 2: Dummy), 6. reserve=========
                
                //-----1. X position, 2. Y position, 3. Time point, 4. Event Type, 5. Next Cell number, Fusion: hold cell number of Fusion partner-----
                //-----6. Cell Number, 7. Cell Lineage Number, 8. For Fusion, Cell lineage Number-----
                
                xPositionEntry = xPositionSave;
                yPositionEntry = yPositionSave;
                
                if (imagePositionData == firstEventTimePoint){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = upperLimitEventType;
                    
                    if (lineageEventTypeEqEvent == 1 || lineageEventTypeEqEvent == 31 || lineageEventTypeEqEvent == 41 || lineageEventTypeEqEvent == 51) cellLineageCellExtract [imagePositionData*8+4] = initialParentNumber;
                    else if (lineageEventTypeEqEvent == 92) cellLineageCellExtract [imagePositionData*8+4] = endParentCellNumber;
                    else cellLineageCellExtract [imagePositionData*8+4] = 0;
                    
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    
                    if (lineageEventTypeEqEvent == 92)  cellLineageCellExtract [imagePositionData*8+7] = endParentLingNumber;
                    else cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                }
                else if (imagePositionData == imageEndAuto){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 2;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    newUpperLimitAdjust = imageEndAuto;
                }
                else if (upperLimitEventType == 2){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 2;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                }
                else if (upperLimitEventType == 6){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 6;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                }
                else if (upperLimitEventType == 7){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 7;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    newUpperLimitAdjust = imagePositionData;
                    break;
                }
                else if (upperLimitEventType == 8){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 8;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    newUpperLimitAdjust = imagePositionData;
                    
                    break;
                }
                else if (upperLimitEventType == 10){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 10;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                }
                else if (upperLimitEventType == 11){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 11;
                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                    
                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                }
                else if (upperLimitEventType == 32 || upperLimitEventType == 33){
                    cellLineageCellExtract [(imagePositionData-1)*8+3] = 32;
                    
                    newUpperLimitAdjust = imagePositionData-1;
                    
                    arrayNewCellTemp [newCellTempCount] = xPositionEntry, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = yPositionEntry, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = imagePositionData, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = 31, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = cellAmendTemp, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = newCellNumber, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = lineageAmendTemp, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = 0, newCellTempCount++;
                }
                else if (upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44){
                    cellLineageCellExtract [(imagePositionData-1)*8+3] = 42;
                    
                    newUpperLimitAdjust = imagePositionData-1;
                    
                    arrayNewCellTemp [newCellTempCount] = xPositionEntry, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = yPositionEntry, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = imagePositionData, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = 41, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = cellAmendTemp, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = newCellNumber, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = lineageAmendTemp, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = 0, newCellTempCount++;
                }
                else if (upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55){
                    cellLineageCellExtract [(imagePositionData-1)*8+3] = 52;
                    newUpperLimitAdjust = imagePositionData-1;
                    
                    arrayNewCellTemp [newCellTempCount] = xPositionEntry, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = yPositionEntry, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = imagePositionData, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = 51, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = cellAmendTemp, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = newCellNumber, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = lineageAmendTemp, newCellTempCount++;
                    arrayNewCellTemp [newCellTempCount] = 0, newCellTempCount++;
                }
                else if (upperLimitEventType == 91){
                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                    cellLineageCellExtract [imagePositionData*8+3] = 91;
                    cellLineageCellExtract [imagePositionData*8+4] = newCellNumber;
                    cellLineageCellExtract [imagePositionData*8+5] = cellAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                    cellLineageCellExtract [imagePositionData*8+7] = arrayEventSequenceReorganize [counter1*4+2];
                    
                    newUpperLimitAdjust = imagePositionData;
                    
                    //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
                    //    cout<<" eventSequenceReorganize "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < lineageCommTempCount/8; counter2++){
                        if (lineageCommTemp [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && lineageCommTemp [counter2*8+5] == arrayEventSequenceReorganize [counter1*4+3] && lineageCommTemp [counter2*8+6] == arrayEventSequenceReorganize [counter1*4+2]){
                            lineageCommTemp [counter2*8] = xPositionEntry;
                            lineageCommTemp [counter2*8+1] = yPositionEntry;
                            lineageCommTemp [counter2*8+3] = 92;
                            lineageCommTemp [counter2*8+4] = cellAmendTemp;
                            lineageCommTemp [counter2*8+7] = lineageAmendTemp;
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < lineageExtractionAutoCount/8; counter2++){
                        if (arrayLineageExtractionAuto [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageExtractionAuto [counter2*8+5] == arrayEventSequenceReorganize [counter1*4+3]){
                            arrayLineageExtractionAuto [counter2*8] = xPositionEntry;
                            arrayLineageExtractionAuto [counter2*8+1] = yPositionEntry;
                            arrayLineageExtractionAuto [counter2*8+3] = 92;
                            arrayLineageExtractionAuto [counter2*8+4] = cellAmendTemp;
                            arrayLineageExtractionAuto [counter2*8+7] = lineageAmendTemp;
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 1; counterA <= newUpperLimit; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellLineageCellExtract [counterA*8+counterB];
            //    cout<<" cellLineageCellExtract "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < newCellTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayNewCellTemp [counterA*8+counterB];
            //    cout<<" arrayNewCellTemp "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageExtractionAutoCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtractionAuto [counterA*8+counterB];
            //	cout<<" arrayLineageExtractionAuto "<<counterA<<endl;
            //}
            
            //-----Lineage Data Reorganize, One cell form one block-----
            int *lineageExtractionTemp = new int [lineageExtractionAutoCount+10000];
            int lineageExtractionTempCount = 0;
            
            for (int counter1 = 0; counter1 < lineageExtractionAutoCount/8; counter1++){
                if (arrayLineageExtractionAuto [counter1*8+5] != cellAmendTemp){
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+1], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+2], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+3], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+4], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+5], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+6], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+7], lineageExtractionTempCount++;
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
            //    cout<<" lineageExtractionTemp "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < lineageExtractionAutoCount/8; counter1++){
                if (cellFirstImageNo <= arrayLineageExtractionAuto [counter1*8+2] && arrayLineageExtractionAuto [counter1*8+2] < eventStartPoint && arrayLineageExtractionAuto [counter1*8+5] == cellAmendTemp){
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+1], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+2], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+3], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+4], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+5], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+6], lineageExtractionTempCount++;
                    lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtractionAuto [counter1*8+7], lineageExtractionTempCount++;
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
            //    cout<<" lineageExtractionTemp "<<counterA<<endl;
            //}
            
            for (int counter1 = eventStartPoint; counter1 <= newUpperLimitAdjust; counter1++){
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+1], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+2], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+3], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+4], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+5], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+6], lineageExtractionTempCount++;
                lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+7], lineageExtractionTempCount++;
            }
            
            delete [] cellLineageCellExtract;
            delete [] arrayLineageExtractionAuto;
            
            //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
            //    cout<<" lineageExtractionTemp "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < newCellTempCount; counter1++) lineageExtractionTemp [lineageExtractionTempCount] = arrayNewCellTemp [counter1], lineageExtractionTempCount++;
            
            delete [] arrayNewCellTemp;
            
            //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
            //    cout<<" lineageExtractionTemp "<<counterA<<endl;
            //}
            
            int *arrayLineageExtractionAuto2 = new int [lineageExtractionTempCount+lineageCommTempCount+10000];
            int lineageExtractionCount2 = 0;
            
            for (int counter1 = 0; counter1 < lineageCommTempCount/8; counter1++){
                if (lineageCommTemp [counter1*8+6] != lineageAmendTemp){
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+1], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+2], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+3], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+4], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+5], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+6], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageCommTemp [counter1*8+7], lineageExtractionCount2++;
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtractionAuto2 [counterA*8+counterB];
            //    cout<<" arrayLineageExtractionAuto2 "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < lineageExtractionTempCount/8; counter1++){
                if (lineageExtractionTemp [counter1*8+6] != 0){
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+1], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+2], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+3], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+4], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+5], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+6], lineageExtractionCount2++;
                    arrayLineageExtractionAuto2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+7], lineageExtractionCount2++;
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
            //    cout<<" lineageExtractionTemp "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtractionAuto2 [counterA*8+counterB];
            //    cout<<" arrayLineageExtractionAuto2 "<<counterA<<endl;
            //}
            
            delete [] lineageCommTemp;
            lineageCommTemp = new int [lineageExtractionCount2+500];
            lineageCommTempCount = 0;
            
            for (int counter1 = 0; counter1 < lineageExtractionCount2; counter1++) lineageCommTemp [lineageCommTempCount] = arrayLineageExtractionAuto2 [counter1], lineageCommTempCount++;
            
            delete [] arrayLineageExtractionAuto2;
            
            //-----(Backup create)-----
            if (autoTrackFirstSave == 0){
                string tempBackUpPath = backUpTempPath+"/"+analysisID+"_"+treatmentNameAuto+"_LineageData";
                string tempBackUpPath2 = tempBackUpPath+"~5";
                string tempBackUpPath3;
                
                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.close();
                    
                    tempBackUpPath2 = tempBackUpPath+"~1";
                    remove (tempBackUpPath2.c_str());
                    
                    tempBackUpPath2 = tempBackUpPath+"~2";
                    tempBackUpPath3 = tempBackUpPath+"~1";
                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                    
                    tempBackUpPath2 = tempBackUpPath+"~3";
                    tempBackUpPath3 = tempBackUpPath+"~2";
                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                    
                    tempBackUpPath2 = tempBackUpPath+"~4";
                    tempBackUpPath3 = tempBackUpPath+"~3";
                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                    
                    tempBackUpPath2 = tempBackUpPath+"~5";
                    tempBackUpPath3 = tempBackUpPath+"~4";
                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                    
                    rename (lineageCommPath.c_str(), tempBackUpPath2.c_str());
                }
                else{
                    
                    tempBackUpPath2 = tempBackUpPath+"~4";
                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        tempBackUpPath2 = tempBackUpPath+"~5";
                        rename (lineageCommPath.c_str(), tempBackUpPath2.c_str());
                    }
                    else{
                        
                        tempBackUpPath2 = tempBackUpPath+"~3";
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            rename (lineageCommPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                rename (lineageCommPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~1";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    rename (lineageCommPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    rename (lineageCommPath.c_str(), tempBackUpPath2.c_str());
                                }
                            }
                        }
                    }
                }
            }
            
            //-----Lineage Data Save-----
            char *writingArray = new char [lineageCommTempCount/8*25+25];
            
            unsigned long indexCount = 0;
            int readBit [4];
            int dataTemp = 0;
            
            for (int counter1 = 0; counter1 < lineageCommTempCount/8; counter1++){
                if (lineageCommTemp [counter1*8] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8];
                }
                
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                if (lineageCommTemp [counter1*8+1] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8+1]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8+1];
                }
                
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = lineageCommTemp [counter1*8+2];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                writingArray [indexCount] = (char)lineageCommTemp [counter1*8+3], indexCount++;
                
                if (lineageCommTemp [counter1*8+4] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8+4]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8+4];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                if (lineageCommTemp [counter1*8+5] < 0){
                    writingArray [indexCount] = 1, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8+5]*-1;
                }
                else{
                    
                    writingArray [indexCount] = 0, indexCount++;
                    dataTemp = lineageCommTemp [counter1*8+5];
                }
                
                readBit [0] = dataTemp/16777216;
                dataTemp = dataTemp%16777216;
                readBit [1] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [2] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [3] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                writingArray [indexCount] = (char)readBit [3], indexCount++;
                
                dataTemp = lineageCommTemp [counter1*8+6];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                dataTemp = lineageCommTemp [counter1*8+7];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile (lineageCommPath.c_str(), ofstream::binary);
            outfile.write ((char*) writingArray, indexCount);
            outfile.close();
            
            delete [] writingArray;
            
            //-----File Move to _Connect-----
            string connectDataRevPath;
            string connectStatusPath;
            string connectRelTempPath;
            string connectRelPath;
            string connectMapTempPath;
            string connectMapPath;
            string connectAmendPath;
            
            int upperEventCDOFFind = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                extension = to_string(arrayEventSequenceReorganize [counter1*4]);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                if (upperEventCDOFFind == 0){
                    
                    connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_MasterDataTemp";
                    connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
                    
                    fin.open(connectDataTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectDataRevPath.c_str());
                        rename (connectDataTempPath.c_str(), connectDataRevPath.c_str());
                    }
                    
                    connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_StatusTemp";
                    connectStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_Status";
                    
                    fin.open(connectStatusTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectStatusPath.c_str());
                        rename (connectStatusTempPath.c_str(), connectStatusPath.c_str());
                    }
                    
                    connectRelTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_ConnectLineageRelTemp";
                    connectRelPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_ConnectLineageRel";
                    
                    fin.open(connectRelTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectRelPath.c_str());
                        rename (connectRelTempPath.c_str(), connectRelPath.c_str());
                    }
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_RevisedTempMap";
                    connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_RevisedMap";
                    
                    fin.open(connectMapTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        string tempBackUpPath = backUpTempPath+"/"+analysisID+"_"+treatmentNameAuto+"_RevisedMap";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            remove (connectMapPath.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                        
                        rename (connectMapTempPath.c_str(), connectMapPath.c_str());
                    }
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_ExtendLineDataTemp";
                    connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_ExtendLineData";
                    
                    fin.open(connectMapTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectMapPath.c_str());
                        rename (connectMapTempPath.c_str(), connectMapPath.c_str());
                    }
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_ExtendAreaDataTemp";
                    connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_ExtendAreaData";
                    
                    fin.open(connectMapTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectMapPath.c_str());
                        rename (connectMapTempPath.c_str(), connectMapPath.c_str());
                    }
                    
                    remove (eventTempPath.c_str());
                    remove (mitosisTempPath.c_str());
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_GCCenterInfo";
                    
                    remove (connectMapTempPath.c_str());
                }
                else{
                    
                    connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_MasterDataTemp";
                    
                    fin.open(connectDataTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectDataTempPath.c_str());
                    }
                    
                    connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_StatusTemp";
                    
                    fin.open(connectStatusTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectStatusTempPath.c_str());
                    }
                    
                    connectRelTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_ConnectLineageRelTemp";
                    
                    fin.open(connectRelTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectRelTempPath.c_str());
                    }
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_RevisedTempMap";
                    
                    fin.open(connectMapTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectMapTempPath.c_str());
                    }
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_ExtendLineDataTemp";
                    
                    fin.open(connectMapTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectMapTempPath.c_str());
                    }
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_ExtendAreaDataTemp";
                    
                    fin.open(connectMapTempPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        remove (connectMapTempPath.c_str());
                    }
                    
                    remove (eventTempPath.c_str());
                    remove (mitosisTempPath.c_str());
                    
                    connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+extension+"_GCCenterInfo";
                    
                    remove (connectMapTempPath.c_str());
                }
                
                if (arrayEventSequenceReorganize [counter1*4+1] == 7 || arrayEventSequenceReorganize [counter1*4+1] == 8){
                    upperEventCDOFFind = 1;
                }
            }
            
            int nextConnectNo = 1;
            
            //-----Lineage Start/End List-----
            //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStartEnd";
            
            startEndCommCount = 0;
            int cellNumberStart = -1;
            int lineageNumberStart = 0;
            int firstEntryFind = 0;
            
            for (int counter1 = 0; counter1 < lineageCommTempCount/8; counter1++){
                if ((lineageCommTemp [counter1*8+6] != lineageNumberStart || lineageCommTemp [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                    lineageNumberStart = lineageCommTemp [counter1*8+6];
                    cellNumberStart = lineageCommTemp [counter1*8+5];
                    
                    startEndCommTemp [startEndCommCount] = lineageNumberStart, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = cellNumberStart, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8], startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8+1], startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = counter1, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8+2], startEndCommCount++;
                    
                    firstEntryFind = 1;
                }
                else if ((lineageCommTemp [counter1*8+6] != lineageNumberStart || lineageCommTemp [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                    lineageNumberStart = lineageCommTemp [counter1*8+6];
                    cellNumberStart = lineageCommTemp [counter1*8+5];
                    
                    startEndCommTemp [startEndCommCount] = counter1-1, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [(counter1-1)*8+2], startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageNumberStart, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = cellNumberStart, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8], startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8+1], startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = counter1, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8+2], startEndCommCount++;
                }
                
                if (counter1 == lineageCommTempCount/8-1){
                    startEndCommTemp [startEndCommCount] = counter1, startEndCommCount++;
                    startEndCommTemp [startEndCommCount] = lineageCommTemp [counter1*8+2], startEndCommCount++;
                }
            }
            
            //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8 +counterB];
            //   cout<<" startEndCommTemp "<<counterA<<endl;
            //}
            
            if (startEndCommCount != 0){
                char *mainDataEntry = new char [startEndCommCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < startEndCommCount; counter1++){
                    extension = to_string(startEndCommTemp [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
                outfile2.write (mainDataEntry, totalEntryCount);
                outfile2.close();
                
                delete [] mainDataEntry;
            }
            
            int fusionMarkFind = 0;
            
            //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8 +counterB];
            //   cout<<" startEndCommTemp "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                if (startEndCommTemp [counter1*8] == lineageAmendTemp && startEndCommTemp [counter1*8+1] == cellAmendTemp){
                    for (int counter2 = startEndCommTemp [counter1*8+4]; counter2 <= startEndCommTemp [counter1*8+6]; counter2++){
                        if (lineageCommTemp [counter2*8+3] == 10) fusionMarkFind = 1;
                    }
                }
            }
            
            if (processTypeCell == 1){
                extension = to_string(newUpperLimit);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_lineDataAmend";
                connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                int *masterReadForAmend = new int [sizeForCopy+50];
                int masterReadForAmendCount = 0;
                
                readingError = 0;
                
                if (checkFlag == 1){
                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                // for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                //	cout<<" masterReadForAmend "<<counterA<<endl;
                //}
                
                int entryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                    if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp) entryCount++;
                }
                
                //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                indexCount = 0;
                
                writingArray = new char [entryCount*13+20];
                
                for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                    if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp){
                        dataTemp = newUpperLimit;
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = masterReadForAmend [counter1*7];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        dataTemp = masterReadForAmend [counter1*7+1];
                        readBit [0] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [1] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        
                        writingArray [indexCount] = (char)upperLimitEventType, indexCount++;
                        
                        dataTemp = masterReadForAmend [counter1*7+3];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                        
                        dataTemp = masterReadForAmend [counter1*7+6];
                        readBit [0] = dataTemp/65536;
                        dataTemp = dataTemp%65536;
                        readBit [1] = dataTemp/256;
                        dataTemp = dataTemp%256;
                        readBit [2] = dataTemp;
                        
                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                    }
                }
                
                for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile2 (connectAmendPath.c_str(), ofstream::binary);
                outfile2.write ((char*)writingArray, indexCount);
                outfile2.close();
                
                delete [] writingArray;
                delete [] masterReadForAmend;
                
                //=========Queue List creation==========
                //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Status, 6. Processing status-----
                //-----Status: MANU,EVAL-----
                //-----Processing Status: WAIT, PROC, PEND-----
                
                if (checkStatusAuto == "NX" || checkStatusAuto == "IM"){
                    string *queueListUpdateTemp = new string [queueListCount+50];
                    int queueListUpdateTempCount = 0;
                    
                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                    //	cout<<" arrayQueueList "<<counterA<<endl;
                    //}
                    
                    string imageNoTemp = "";
                    string imageIFTemp = "";
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6+5] != "Proc"){
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+1], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+2], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+3], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+4], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+5], queueListUpdateTempCount++;
                        }
                        else{
                            
                            imageNoTemp = arrayQueueList [counter1*6+3];
                            imageIFTemp = arrayQueueList [counter1*6+4];
                        }
                    }
                    
                    string imageNoIFTemp = imageNoTemp.substr(0, imageNoTemp.find(":"));
                    
                    string endCheckTemp = "";
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+1] == lineageNoAuto && arrayQueueList [counter1*6+2] == cellNoAuto){
                            endCheckTemp = arrayQueueList [counter1*6+4];
                            break;
                        }
                    }
                    
                    if ((int)endCheckTemp.find("/m") != -1) endCheckTemp = endCheckTemp.substr(0, endCheckTemp.find("/m"));
                    
                    if (atoi(endCheckTemp.c_str()) <= newUpperLimit) endCheckTemp = "0";
                    
                    if ((int)imageNoTemp.find(":") != -1) imageNoTemp = imageNoTemp.substr(imageNoTemp.find(":")+1);
                    
                    extension = to_string(newUpperLimit);
                    
                    int ifSetFindFlag = 0;
                    
                    if ((int)imageIFTemp.find("IF") != -1) ifSetFindFlag = 1;
                    
                    queueListUpdateTemp [queueListUpdateTempCount] = treatmentNameAuto, queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = lineageNoAuto, queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = cellNoAuto, queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = extension+":"+imageNoTemp, queueListUpdateTempCount++;
                    
                    //cout<<treatmentNameAuto<<" "<<lineageNoAuto<<" "<<cellNoAuto<<" "<<extension+":"+imageNoTemp<<" "<<"AA1"<<endl;
                    
                    if (fusionMarkFind == 0 && checkStatusAuto != "IM" && ifSetFindFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = endCheckTemp, queueListUpdateTempCount++;
                    else if (fusionMarkFind == 1 && checkStatusAuto != "IM" && ifSetFindFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = endCheckTemp+"/m", queueListUpdateTempCount++;
                    else if (fusionMarkFind == 0 && checkStatusAuto == "IM" && ifSetFindFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = "IF", queueListUpdateTempCount++;
                    else if (fusionMarkFind == 1 && checkStatusAuto == "IM" && ifSetFindFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = "IF/m", queueListUpdateTempCount++;
                    else if (fusionMarkFind == 0 && ifSetFindFlag == 1) queueListUpdateTemp [queueListUpdateTempCount] = "IF", queueListUpdateTempCount++;
                    else if (fusionMarkFind == 1 && ifSetFindFlag == 1) queueListUpdateTemp [queueListUpdateTempCount] = "IF/m", queueListUpdateTempCount++;
                    
                    queueListUpdateTemp [queueListUpdateTempCount] = "Wait", queueListUpdateTempCount++;
                    
                    if (queueListUpdateTempCount > queueListLimit){
                        delete [] arrayQueueList;
                        arrayQueueList = new string [queueListUpdateTempCount+5000];
                        queueListLimit = queueListUpdateTempCount+5000;
                    }
                    
                    queueListCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListUpdateTempCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
                    
                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                    //    cout<<" arrayQueueList "<<counterA<<endl;
                    //}
                    
                    delete [] queueListUpdateTemp;
                    
                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                    
                    if (autoTrackFirstSave == 0){
                        string tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (queueListCount != 0){
                        char *mainDataEntry = new char [queueListCount*12+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < queueListCount; counter1++){
                            extension = arrayQueueList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                        outfile3.write (mainDataEntry, totalEntryCount);
                        outfile3.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    string *doneListUpdateTemp = new string [doneListCount+50];
                    int doneListUpdateTempCount = 0;
                    
                    int doneFineFlag = 0;
                    
                    //for (int counterA = 0; counterA < doneListUpdateTempCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<doneListUpdateTemp [counterA*5+counterB];
                    //    cout<<" doneListUpdateTemp "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != lineageNoAuto || arrayDoneList [counter1*5+2] != cellNoAuto){
                            doneFineFlag = 1;
                            
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < doneListUpdateTempCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<doneListUpdateTemp [counterA*5+counterB];
                    //    cout<<" doneListUpdateTemp "<<counterA<<endl;
                    //}
                    
                    string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                    
                    if (autoTrackFirstSave == 0){
                        string tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (doneFineFlag == 1){
                        doneListCount = 0;
                        
                        for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                        
                        char *mainDataEntry2 = new char [doneListCount*10+10];
                        int totalEntryCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < doneListCount; counter1++){
                            extension = arrayDoneList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry2 [totalEntryCount2] = (char)extension.at((unsigned long)counter2), totalEntryCount2++;
                            }
                            
                            mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                        }
                        
                        mainDataEntry2 [totalEntryCount2] = 'E', totalEntryCount2++;
                        mainDataEntry2 [totalEntryCount2] = 'n', totalEntryCount2++;
                        mainDataEntry2 [totalEntryCount2] = 'd', totalEntryCount2++;
                        mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                        
                        ofstream outfile4 (doneListPath.c_str(), ofstream::binary);
                        outfile4.write (mainDataEntry2, totalEntryCount2);
                        outfile4.close();
                        
                        delete [] mainDataEntry2;
                    }
                    
                    delete [] doneListUpdateTemp;
                }
                
                if (checkStatusAuto == "BD" || checkStatusAuto == "TD" || checkStatusAuto == "HD" || checkStatusAuto == "MD" || checkStatusAuto == "NS" || checkStatusAuto == "CD" || checkStatusAuto == "IP" || checkStatusAuto == "MC" || checkStatusAuto == "AC" || checkStatusAuto == "DB" || checkStatusAuto == "RC" || checkStatusAuto == "SC" || checkStatusAuto == "CM" || checkStatusAuto == "CN" || checkStatusAuto == "FM" || checkStatusAuto == "TL" || checkStatusAuto == "FE" || checkStatusAuto == "FO" || checkStatusAuto == "MF" || checkStatusAuto == "NM" || checkStatusAuto == "DL" || checkStatusAuto == "OF" || checkStatusAuto == "FC" || checkStatusAuto == "ME" || checkStatusAuto == "CF" || checkStatusAuto == "TM"){
                    string *queueListUpdateTemp = new string [queueListCount+50];
                    int queueListUpdateTempCount = 0;
                    
                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                    //    cout<<" arrayQueueList "<<counterA<<endl;
                    //}
                    
                    string imageNoTemp = "";
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != lineageNoAuto || arrayQueueList [counter1*6+2] != cellNoAuto){
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+1], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+2], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+3], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+4], queueListUpdateTempCount++;
                            queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+5], queueListUpdateTempCount++;
                        }
                        else imageNoTemp = arrayQueueList [counter1*6+3];
                    }
                    
                    int findString = (int)imageNoTemp.find(":");
                    if (findString != -1) imageNoTemp = imageNoTemp.substr((unsigned long)findString+1);
                    
                    queueListCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListUpdateTempCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
                    
                    delete [] queueListUpdateTemp;
                    
                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                    
                    if (autoTrackFirstSave == 0){
                        string tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (queueListCount != 0){
                        char *mainDataEntry = new char [queueListCount*12+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < queueListCount; counter1++){
                            extension = arrayQueueList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                        outfile3.write (mainDataEntry, totalEntryCount);
                        outfile3.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    string *doneListUpdateTemp = new string [doneListCount+50];
                    int doneListUpdateTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != lineageNoAuto || arrayDoneList [counter1*5+2] != cellNoAuto){
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < doneListUpdateTempCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                    //    cout<<" arrayDoneList "<<counterA<<endl;
                    //}
                    
                    doneListCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                    
                    if (doneListCount+10 > doneListLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate doneListUpDate];
                    }
                    
                    extension = to_string(newUpperLimit);
                    
                    arrayDoneList [doneListCount] = treatmentNameAuto, doneListCount++;
                    arrayDoneList [doneListCount] = lineageNoAuto, doneListCount++;
                    arrayDoneList [doneListCount] = cellNoAuto, doneListCount++;
                    arrayDoneList [doneListCount] = extension+":"+imageNoTemp, doneListCount++;
                    
                    if (fusionMarkFind == 0) arrayDoneList [doneListCount] = checkStatusAuto, doneListCount++;
                    else arrayDoneList [doneListCount] = checkStatusAuto+"/m", doneListCount++;
                    
                    string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                    
                    if (autoTrackFirstSave == 0){
                        string tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (doneListCount != 0){
                        char *mainDataEntry2 = new char [doneListCount*10+10];
                        int totalEntryCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < doneListCount; counter1++){
                            extension = arrayDoneList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry2 [totalEntryCount2] = (char)extension.at((unsigned long)counter2), totalEntryCount2++;
                            }
                            
                            mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                        }
                        
                        mainDataEntry2 [totalEntryCount2] = 'E', totalEntryCount2++;
                        mainDataEntry2 [totalEntryCount2] = 'n', totalEntryCount2++;
                        mainDataEntry2 [totalEntryCount2] = 'd', totalEntryCount2++;
                        mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                        
                        ofstream outfile4 (doneListPath.c_str(), ofstream::binary);
                        outfile4.write (mainDataEntry2, totalEntryCount2);
                        outfile4.close();
                        
                        delete [] mainDataEntry2;
                    }
                    
                    delete [] doneListUpdateTemp;
                }
                
                string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_CellStatus";
                
                sizeForCopy = 0;
                
                if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *masterReadForCellInfo = new int [sizeForCopy+50];
                int masterReadForCellInfoCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //	cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                    if (masterReadForCellInfo [counter1*7] == cellAmendTemp && masterReadForCellInfo [counter1*7+6] == lineageAmendTemp){
                        masterReadForCellInfo [counter1*7+2] = -1;
                        masterReadForCellInfo [counter1*7+4] = 0;
                        
                        if (fusionMarkFind == 0){
                            if (checkStatusAuto == "MD") masterReadForCellInfo [counter1*7+5] = 23;
                            else if (checkStatusAuto == "NS") masterReadForCellInfo [counter1*7+5] = 24;
                            else if (checkStatusAuto == "IP") masterReadForCellInfo [counter1*7+5] = 25;
                            else if (checkStatusAuto == "MC") masterReadForCellInfo [counter1*7+5] = 26;
                            else if (checkStatusAuto == "AC") masterReadForCellInfo [counter1*7+5] = 27;
                            else if (checkStatusAuto == "DB") masterReadForCellInfo [counter1*7+5] = 28;
                            else if (checkStatusAuto == "RC") masterReadForCellInfo [counter1*7+5] = 29;
                            else if (checkStatusAuto == "SC") masterReadForCellInfo [counter1*7+5] = 30;
                            else if (checkStatusAuto == "CM") masterReadForCellInfo [counter1*7+5] = 31;
                            else if (checkStatusAuto == "CN") masterReadForCellInfo [counter1*7+5] = 32;
                            else if (checkStatusAuto == "FM") masterReadForCellInfo [counter1*7+5] = 33;
                            else if (checkStatusAuto == "TL" || checkStatusAuto == "TM") masterReadForCellInfo [counter1*7+5] = 34;
                            else if (checkStatusAuto == "FE") masterReadForCellInfo [counter1*7+5] = 35;
                            else if (checkStatusAuto == "FO") masterReadForCellInfo [counter1*7+5] = 36;
                            else if (checkStatusAuto == "MF") masterReadForCellInfo [counter1*7+5] = 37;
                            else if (checkStatusAuto == "NM") masterReadForCellInfo [counter1*7+5] = 38;
                            else if (checkStatusAuto == "DL") masterReadForCellInfo [counter1*7+5] = 39;
                            else if (checkStatusAuto == "OF") masterReadForCellInfo [counter1*7+5] = 40;
                            else if (checkStatusAuto == "FC") masterReadForCellInfo [counter1*7+5] = 41;
                            else if (checkStatusAuto == "ME") masterReadForCellInfo [counter1*7+5] = 42;
                            else if (checkStatusAuto == "CF") masterReadForCellInfo [counter1*7+5] = 43;
                            else if (checkStatusAuto == "XS") masterReadForCellInfo [counter1*7+5] = 44;
                            else if (checkStatusAuto == "AM") masterReadForCellInfo [counter1*7+5] = 45;
                            else if (checkStatusAuto == "CL") masterReadForCellInfo [counter1*7+5] = 46;
                            else if (checkStatusAuto == "FP") masterReadForCellInfo [counter1*7+5] = 47;
                            else if (checkStatusAuto == "NX") masterReadForCellInfo [counter1*7+5] = 0;
                        }
                        else if (fusionMarkFind == 1){
                            if (checkStatusAuto == "MD") masterReadForCellInfo [counter1*7+5] = 53;
                            else if (checkStatusAuto == "NS") masterReadForCellInfo [counter1*7+5] = 54;
                            else if (checkStatusAuto == "IP") masterReadForCellInfo [counter1*7+5] = 55;
                            else if (checkStatusAuto == "MC") masterReadForCellInfo [counter1*7+5] = 56;
                            else if (checkStatusAuto == "AC") masterReadForCellInfo [counter1*7+5] = 57;
                            else if (checkStatusAuto == "DB") masterReadForCellInfo [counter1*7+5] = 58;
                            else if (checkStatusAuto == "RC") masterReadForCellInfo [counter1*7+5] = 59;
                            else if (checkStatusAuto == "SC") masterReadForCellInfo [counter1*7+5] = 60;
                            else if (checkStatusAuto == "CM") masterReadForCellInfo [counter1*7+5] = 61;
                            else if (checkStatusAuto == "CN") masterReadForCellInfo [counter1*7+5] = 62;
                            else if (checkStatusAuto == "FM") masterReadForCellInfo [counter1*7+5] = 63;
                            else if (checkStatusAuto == "TL" || checkStatusAuto == "TM") masterReadForCellInfo [counter1*7+5] = 64;
                            else if (checkStatusAuto == "FE") masterReadForCellInfo [counter1*7+5] = 65;
                            else if (checkStatusAuto == "FO") masterReadForCellInfo [counter1*7+5] = 66;
                            else if (checkStatusAuto == "MF") masterReadForCellInfo [counter1*7+5] = 67;
                            else if (checkStatusAuto == "NM") masterReadForCellInfo [counter1*7+5] = 68;
                            else if (checkStatusAuto == "DL") masterReadForCellInfo [counter1*7+5] = 69;
                            else if (checkStatusAuto == "OF") masterReadForCellInfo [counter1*7+5] = 70;
                            else if (checkStatusAuto == "FC") masterReadForCellInfo [counter1*7+5] = 71;
                            else if (checkStatusAuto == "ME") masterReadForCellInfo [counter1*7+5] = 72;
                            else if (checkStatusAuto == "CF") masterReadForCellInfo [counter1*7+5] = 73;
                            else if (checkStatusAuto == "XS") masterReadForCellInfo [counter1*7+5] = 74;
                            else if (checkStatusAuto == "AM") masterReadForCellInfo [counter1*7+5] = 75;
                            else if (checkStatusAuto == "CL") masterReadForCellInfo [counter1*7+5] = 76;
                            else if (checkStatusAuto == "FP") masterReadForCellInfo [counter1*7+5] = 78;
                            else if (checkStatusAuto == "NX") masterReadForCellInfo [counter1*7+5] = 77;
                        }
                        
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount; counter1++){
                    extension = to_string(masterReadForCellInfo [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile3 (lineageFolderPath2.c_str(), ofstream::binary);
                outfile3.write (mainDataEntry, totalEntryCount);
                outfile3.close();
                
                delete [] mainDataEntry;
                delete [] masterReadForCellInfo;
                
                //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                int numberOfEntry = 0;
                
                for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                    if (startEndCommTemp [counter1*8] == lineageAmendTemp) numberOfEntry++;
                }
                
                string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStatus";
                
                sizeForCopy = 0;
                
                if (stat(connectDataInfoPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *masterReadForLineageInfo = new int [sizeForCopy+50];
                int masterReadForLineageInfoCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(connectDataInfoPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                masterReadForLineageInfo [masterReadForLineageInfoCount] = atoi(dataString.c_str()), masterReadForLineageInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                }
                
                for (int counter1 = 0; counter1 < masterReadForLineageInfoCount/3; counter1++){
                    if (masterReadForLineageInfo [counter1*3] == lineageAmendTemp){
                        masterReadForLineageInfo [counter1*3+1] = 0;
                        masterReadForLineageInfo [counter1*3+2] = numberOfEntry;
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForLineageInfoCount/3; counterA++){
                //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<masterReadForLineageInfo [counterA*3+counterB];
                //	cout<<" masterReadForLineageInfo "<<counterA<<endl;
                //}
                
                mainDataEntry = new char [masterReadForLineageInfoCount*6+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForLineageInfoCount; counter1++){
                    extension = to_string(masterReadForLineageInfo [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile4 (connectDataInfoPath.c_str(), ofstream::binary);
                outfile4.write (mainDataEntry, totalEntryCount);
                outfile4.close();
                
                delete [] mainDataEntry;
                delete [] masterReadForLineageInfo;
            }
            
            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
            //	cout<<" arrayQueueList "<<counterA<<endl;
            //}
            
            if (processTypeCell == 2){
                extension = to_string(newUpperLimit);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                int *masterReadForAmend = new int [sizeForCopy+50];
                int masterReadForAmendCount = 0;
                readingError = 0;
                
                if (checkFlag == 1){
                    fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                    masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                //	cout<<" masterReadForAmend "<<counterA<<endl;
                //}
                
                string cellNumberString;
                string newCellFolderPath;
                int entryCount = 0;
                
                for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                    if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                        cellNumberString = to_string(arrayEventSequenceReorganize [counter1*4+3]);
                        
                        if (arrayEventSequenceReorganize [counter1*4+3] >= 0){
                            if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                            else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                            else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                            else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                            else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                            else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                            else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                            else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                            else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                        }
                        else{
                            
                            cellNumberString = cellNumberString.substr(1);
                            
                            if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                            else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                            else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                            else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                            else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                            else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                            else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                            else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                            else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                        }
                        
                        newCellFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNumberString;
                        mkdir(newCellFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        entryCount = 0;
                        
                        for (int counter2 = 0; counter2 < masterReadForAmendCount/7; counter2++){
                            if (masterReadForAmend [counter2*7+4] == arrayEventSequenceReorganize [counter1*4+3] && masterReadForAmend [counter2*7+6] == lineageAmendTemp) entryCount++;
                        }
                        
                        connectAmendPath = newCellFolderPath+"/"+analysisID+"_"+lineageNoAuto+"_lineDataAmend";
                        
                        //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<masterReadForAmend [counterA*6+counterB];
                        //    cout<<" masterReadForAmend "<<counterA<<endl;
                        //}
                        
                        //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                        indexCount = 0;
                        
                        writingArray = new char [entryCount*13+20];
                        
                        for (int counter2 = 0; counter2 < masterReadForAmendCount/7; counter2++){
                            if (masterReadForAmend [counter2*7+4] == arrayEventSequenceReorganize [counter1*4+3] && masterReadForAmend [counter2*7+6] == lineageAmendTemp){
                                dataTemp = newUpperLimit;
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = masterReadForAmend [counter2*7];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = masterReadForAmend [counter2*7+1];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                writingArray [indexCount] = 1, indexCount++;
                                
                                dataTemp = masterReadForAmend [counter2*7+3];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = masterReadForAmend [counter2*7+6];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < 13; counter2++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (connectAmendPath.c_str(), ofstream::binary);
                        outfile2.write ((char*)writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                    }
                }
                
                delete [] masterReadForAmend;
                
                connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_lineDataAmend";
                remove (connectAmendPath.c_str());
                
                //==========Cell Status Info==========
                string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_CellStatus";
                
                sizeForCopy = 0;
                
                if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *masterReadForCellInfo = new int [sizeForCopy+50];
                int masterReadForCellInfoCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                }
                
                for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                    if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                        masterReadForCellInfo [masterReadForCellInfoCount] = arrayEventSequenceReorganize [counter1*4+3], masterReadForCellInfoCount++;
                        masterReadForCellInfo [masterReadForCellInfoCount] = newUpperLimit, masterReadForCellInfoCount++;
                        masterReadForCellInfo [masterReadForCellInfoCount] = -1, masterReadForCellInfoCount++;
                        
                        if (upperLimitEventType == 32 || upperLimitEventType == 33) masterReadForCellInfo [masterReadForCellInfoCount] = 3, masterReadForCellInfoCount++;
                        else if (upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44) masterReadForCellInfo [masterReadForCellInfoCount] = 4, masterReadForCellInfoCount++;
                        else if (upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55) masterReadForCellInfo [masterReadForCellInfoCount] = 5, masterReadForCellInfoCount++;
                        
                        masterReadForCellInfo [masterReadForCellInfoCount] = 0, masterReadForCellInfoCount++;
                        masterReadForCellInfo [masterReadForCellInfoCount] = 0, masterReadForCellInfoCount++;
                        masterReadForCellInfo [masterReadForCellInfoCount] = arrayEventSequenceReorganize [counter1*4+2], masterReadForCellInfoCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                    if (masterReadForCellInfo [counter1*7] == cellAmendTemp && masterReadForCellInfo [counter1*7+6] == lineageAmendTemp){
                        masterReadForCellInfo [counter1*7+2] = newUpperLimit-1;
                        
                        if (upperLimitEventType == 32 || upperLimitEventType == 33) masterReadForCellInfo [counter1*7+4] = 3;
                        else if (upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44) masterReadForCellInfo [counter1*7+4] = 4;
                        else if (upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55) masterReadForCellInfo [counter1*7+4] = 5;
                        
                        if (fusionMarkFind == 0){
                            if (checkStatusAuto == "TD") masterReadForCellInfo [counter1*7+5] = 21;
                            else if (checkStatusAuto == "HD") masterReadForCellInfo [counter1*7+5] = 22;
                            else masterReadForCellInfo [counter1*7+5] = 0;
                        }
                        else{
                            
                            if (checkStatusAuto == "TD") masterReadForCellInfo [counter1*7+5] = 51;
                            else if (checkStatusAuto == "HD") masterReadForCellInfo [counter1*7+5] = 52;
                            else masterReadForCellInfo [counter1*7+5] = 77;
                        }
                        
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount; counter1++){
                    extension = to_string(masterReadForCellInfo [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
                outfile2.write (mainDataEntry, totalEntryCount);
                outfile2.close();
                
                delete [] mainDataEntry;
                delete [] masterReadForCellInfo;
                
                int numberOfNewCells = 0;
                
                for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                    if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                        numberOfNewCells++;
                        
                        cellNumberString = to_string(arrayEventSequenceReorganize [counter1*4+3]);
                        
                        if (arrayEventSequenceReorganize [counter1*4+3] >= 0){
                            if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                            else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                            else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                            else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                            else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                            else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                            else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                            else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                            else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                        }
                        else{
                            
                            cellNumberString = cellNumberString.substr(1);
                            
                            if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                            else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                            else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                            else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                            else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                            else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                            else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                            else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                            else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                        }
                        
                        extension = to_string(newUpperLimit);
                        
                        if (queueListCount+12 > queueListLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate queueListUpDate];
                        }
                        
                        arrayQueueList [queueListCount] = treatmentNameAuto, queueListCount++;
                        arrayQueueList [queueListCount] = lineageNoAuto, queueListCount++;
                        arrayQueueList [queueListCount] = cellNumberString, queueListCount++;
                        arrayQueueList [queueListCount] = extension+":"+extension, queueListCount++;
                        arrayQueueList [queueListCount] = "0", queueListCount++;
                        arrayQueueList [queueListCount] = "Wait", queueListCount++;
                    }
                }
                
                string *queueStringTemp = new string [queueListCount+50];
                int queueStringTempCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != lineageNoAuto || arrayQueueList [counter1*6+2] != cellNoAuto){
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                    }
                }
                
                string imageNoTemp = "";
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+1] == lineageNoAuto && arrayQueueList [counter1*6+2] == cellNoAuto){
                        imageNoTemp = arrayQueueList [counter1*6+3];
                    }
                }
                
                int findString = (int)imageNoTemp.find(":");
                if (findString != -1) imageNoTemp = imageNoTemp.substr((unsigned long)findString+1);
                
                queueListCount = 0;
                
                for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
                
                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                
                if (autoTrackFirstSave == 0){
                    string tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                    string tempBackUpPath2 = tempBackUpPath+"~5";
                    string tempBackUpPath3;
                    
                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        tempBackUpPath2 = tempBackUpPath+"~1";
                        remove (tempBackUpPath2.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~2";
                        tempBackUpPath3 = tempBackUpPath+"~1";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~3";
                        tempBackUpPath3 = tempBackUpPath+"~2";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        tempBackUpPath3 = tempBackUpPath+"~3";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~5";
                        tempBackUpPath3 = tempBackUpPath+"~4";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                    }
                    else{
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (queueListCount != 0){
                    mainDataEntry = new char [queueListCount*12+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                        extension = arrayQueueList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                    outfile3.write (mainDataEntry, totalEntryCount);
                    outfile3.close();
                    
                    delete [] mainDataEntry;
                }
                
                delete [] queueStringTemp;
                
                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                //    cout<<" arrayDoneList "<<counterA<<endl;
                //}
                
                string *doneListUpdateTemp = new string [doneListCount+50];
                int doneListUpdateTempCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                    if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != lineageNoAuto || arrayDoneList [counter1*5+2] != cellNoAuto){
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                    }
                }
                
                //=========Done List UpDate==========
                //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Check status-----
                //-----Check Status: OK, LST, CFU, CDV, UK, MAU-----
                
                string checkStatusAutoTemp = "";
                
                if (fusionMarkFind == 0){
                    if (checkStatusAuto == "TD") checkStatusAutoTemp = "TD";
                    else if (checkStatusAuto == "HD") checkStatusAutoTemp = "HD";
                    else if (checkStatusAuto == "TD") checkStatusAutoTemp = "MD";
                    else checkStatusAutoTemp = "OK";
                }
                else{
                    
                    if (checkStatusAuto == "TD") checkStatusAutoTemp = "TD/m";
                    else if (checkStatusAuto == "HD") checkStatusAutoTemp = "HD/m";
                    else if (checkStatusAuto == "TD") checkStatusAutoTemp = "MD/m";
                    else checkStatusAutoTemp = "OK/m";
                }
                
                extension = to_string(newUpperLimit-1);
                
                doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameAuto, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = lineageNoAuto, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = cellNoAuto, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+imageNoTemp, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = checkStatusAutoTemp, doneListUpdateTempCount++;
                
                if (doneListUpdateTempCount > doneListLimit){
                    delete [] arrayDoneList;
                    arrayDoneList = new string [doneListUpdateTempCount+500];
                    doneListLimit = doneListUpdateTempCount+500;
                }
                
                doneListCount = 0;
                
                for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                
                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                
                if (autoTrackFirstSave == 0){
                    string tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                    string tempBackUpPath2 = tempBackUpPath+"~5";
                    string tempBackUpPath3;
                    
                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        tempBackUpPath2 = tempBackUpPath+"~1";
                        remove (tempBackUpPath2.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~2";
                        tempBackUpPath3 = tempBackUpPath+"~1";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~3";
                        tempBackUpPath3 = tempBackUpPath+"~2";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        tempBackUpPath3 = tempBackUpPath+"~3";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~5";
                        tempBackUpPath3 = tempBackUpPath+"~4";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                    }
                    else{
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (doneListCount != 0){
                    mainDataEntry = new char [doneListCount*10+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount; counter1++){
                        extension = arrayDoneList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile4 (doneListPath.c_str(), ofstream::binary);
                    outfile4.write (mainDataEntry, totalEntryCount);
                    outfile4.close();
                    
                    delete [] mainDataEntry;
                }
                
                delete [] doneListUpdateTemp;
                
                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                //	cout<<" arrayDoneList "<<counterA<<endl;
                //}
                
                //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                int numberOfEntry = 0;
                
                for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                    if (startEndCommTemp [counter1*8] == lineageAmendTemp) numberOfEntry++;
                }
                
                string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStatus";
                
                sizeForCopy = 0;
                
                if (stat(connectDataInfoPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *masterReadForLineageInfo = new int [sizeForCopy+50];
                int masterReadForLineageInfoCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(connectDataInfoPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                masterReadForLineageInfo [masterReadForLineageInfoCount] = atoi(dataString.c_str()), masterReadForLineageInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                }
                
                for (int counter1 = 0; counter1 < masterReadForLineageInfoCount/3; counter1++){
                    if (masterReadForLineageInfo [counter1*3] == lineageAmendTemp){
                        masterReadForLineageInfo [counter1*3+1] = 0;
                        masterReadForLineageInfo [counter1*3+2] = numberOfEntry;
                        break;
                    }
                }
                
                mainDataEntry = new char [masterReadForLineageInfoCount*6+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForLineageInfoCount; counter1++){
                    extension = to_string(masterReadForLineageInfo [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile5 (connectDataInfoPath.c_str(), ofstream::binary);
                outfile5.write (mainDataEntry, totalEntryCount);
                outfile5.close();
                
                delete [] mainDataEntry;
                delete [] masterReadForLineageInfo;
            }
            
            //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
            //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
            //-----DEND LineageEntry DEnd 32, TEnd, 42, HEnd 52-----
            
            if (processTypeCell == 3){
                string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_CellStatus";
                
                sizeForCopy = 0;
                
                if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *masterReadForCellInfo = new int [sizeForCopy+50];
                int masterReadForCellInfoCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End") masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++, dataString = "";
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                    if (masterReadForCellInfo [counter1*7] == cellAmendTemp){
                        masterReadForCellInfo [counter1*7+2] = newUpperLimit;
                        
                        if (upperLimitEventType == 7) masterReadForCellInfo [counter1*7+4] = 6;
                        else if (upperLimitEventType == 8) masterReadForCellInfo [counter1*7+4] = 9;
                        else if (upperLimitEventType == 91) masterReadForCellInfo [counter1*7+4] = 7;
                        
                        if (fusionMarkFind == 0){
                            if (checkStatusAuto == "OF") masterReadForCellInfo [counter1*7+5] = 40;
                            else if (checkStatusAuto == "FC") masterReadForCellInfo [counter1*7+5] = 41;
                            else masterReadForCellInfo [counter1*7+5] = 0;
                        }
                        else{
                            
                            if (checkStatusAuto == "OF") masterReadForCellInfo [counter1*7+5] = 70;
                            else if (checkStatusAuto == "FC") masterReadForCellInfo [counter1*7+5] = 71;
                            else masterReadForCellInfo [counter1*7+5] = 77;
                        }
                        
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount; counter1++){
                    extension = to_string(masterReadForCellInfo [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
                outfile2.write (mainDataEntry, totalEntryCount);
                outfile2.close();
                
                delete [] mainDataEntry;
                
                //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                //	cout<<" masterReadForCellInfo "<<counterA<<endl;
                //}
                
                string *queueStringTemp = new string [queueListCount+50];
                int queueStringTempCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != lineageNoAuto || arrayQueueList [counter1*6+2] != cellNoAuto){
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                    }
                }
                
                string imageNoTemp = "";
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+1] == lineageNoAuto && arrayQueueList [counter1*6+2] == cellNoAuto){
                        imageNoTemp = arrayQueueList [counter1*6+3];
                    }
                }
                
                if ((int)imageNoTemp.find(":") != -1) imageNoTemp = imageNoTemp.substr(imageNoTemp.find(":")+1);
                
                queueListCount = 0;
                
                for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
                
                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                
                if (autoTrackFirstSave == 0){
                    string tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                    string tempBackUpPath2 = tempBackUpPath+"~5";
                    string tempBackUpPath3;
                    
                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        tempBackUpPath2 = tempBackUpPath+"~1";
                        remove (tempBackUpPath2.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~2";
                        tempBackUpPath3 = tempBackUpPath+"~1";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~3";
                        tempBackUpPath3 = tempBackUpPath+"~2";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        tempBackUpPath3 = tempBackUpPath+"~3";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~5";
                        tempBackUpPath3 = tempBackUpPath+"~4";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                    }
                    else{
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (queueListCount != 0){
                    mainDataEntry = new char [queueListCount*12+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                        extension = arrayQueueList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                    outfile3.write (mainDataEntry, totalEntryCount);
                    outfile3.close();
                    
                    delete [] mainDataEntry;
                }
                
                delete [] queueStringTemp;
                
                //=========Done List UpDate==========
                //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Check status-----
                //-----Check Status: OK, LST, CFU, CDD, CTD, CHD, UN-----
                
                string *doneListUpdateTemp = new string [doneListCount+50];
                int doneListUpdateTempCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                    if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != lineageNoAuto || arrayDoneList [counter1*5+2] != cellNoAuto){
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                    }
                }
                
                string checkStatusAutoTemp = "";
                
                if (fusionMarkFind == 0){
                    if (checkStatusAuto == "OF") checkStatusAutoTemp = "OF";
                    else if (checkStatusAuto == "FC") checkStatusAutoTemp = "FC";
                    else checkStatusAutoTemp = "OK";
                }
                else{
                    
                    if (checkStatusAuto == "OF") checkStatusAutoTemp = "OF/m";
                    else if (checkStatusAuto == "FC") checkStatusAutoTemp = "FC/m";
                    else checkStatusAutoTemp = "OK/m";
                }
                
                extension = to_string(newUpperLimit);
                
                doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameAuto, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = lineageNoAuto, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = cellNoAuto, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+imageNoTemp, doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = checkStatusAutoTemp, doneListUpdateTempCount++;
                
                if (doneListUpdateTempCount > doneListLimit){
                    delete [] arrayDoneList;
                    arrayDoneList = new string [doneListUpdateTempCount+500];
                    doneListLimit = doneListUpdateTempCount+500;
                }
                
                doneListCount = 0;
                
                for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                
                delete [] doneListUpdateTemp;
                
                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                
                if (autoTrackFirstSave == 0){
                    string tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                    string tempBackUpPath2 = tempBackUpPath+"~5";
                    string tempBackUpPath3;
                    
                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        tempBackUpPath2 = tempBackUpPath+"~1";
                        remove (tempBackUpPath2.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~2";
                        tempBackUpPath3 = tempBackUpPath+"~1";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~3";
                        tempBackUpPath3 = tempBackUpPath+"~2";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        tempBackUpPath3 = tempBackUpPath+"~3";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        tempBackUpPath2 = tempBackUpPath+"~5";
                        tempBackUpPath3 = tempBackUpPath+"~4";
                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                        
                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                    }
                    else{
                        
                        tempBackUpPath2 = tempBackUpPath+"~4";
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                }
                            }
                        }
                    }
                }
                
                if (doneListCount != 0){
                    mainDataEntry = new char [doneListCount*10+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount; counter1++){
                        extension = arrayDoneList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile4 (doneListPath.c_str(), ofstream::binary);
                    outfile4.write (mainDataEntry, totalEntryCount);
                    outfile4.close();
                    
                    delete [] mainDataEntry;
                }
                
                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                //	cout<<" arrayDoneList "<<counterA<<endl;
                //}
                
                connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_lineDataAmend";
                remove (connectAmendPath.c_str());
                
                //===========fusion line end=========
                if (upperLimitEventType == 91){
                    int fusionLingNo = 0;
                    int fusionCellNo = 0;
                    int fusionImageNo = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                        if (arrayEventSequenceReorganize [counter1*4+1] == 91){
                            fusionLingNo = arrayEventSequenceReorganize [counter1*4+2];
                            fusionCellNo = arrayEventSequenceReorganize [counter1*4+3];
                            fusionImageNo = arrayEventSequenceReorganize [counter1*4];
                        }
                    }
                    
                    extension = to_string(fusionImageNo);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    int *masterReadForAmend = new int [sizeForCopy+50];
                    int masterReadForAmendCount = 0;
                    
                    readingError = 0;
                    
                    if (checkFlag == 1){
                        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                    else{
                                        
                                        masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                        masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                    
                    int entryCount = 0;
                    
                    for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                        if (masterReadForAmend [counter1*7+4] == fusionCellNo && masterReadForAmend [counter1*7+6] == fusionLingNo) entryCount++;
                    }
                    
                    string cellLineageString = to_string(fusionLingNo);
                    
                    if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
                    else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
                    else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
                    else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
                    else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
                    
                    string cellNumberString = to_string(fusionCellNo);
                    
                    if (fusionCellNo >= 0){
                        if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                        else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                        else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                        else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                        else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                        else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                        else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                        else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                        else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                    }
                    else{
                        
                        cellNumberString = cellNumberString.substr(1);
                        
                        if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                        else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                        else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                        else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                        else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                        else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                        else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                        else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                        else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                    }
                    
                    string newCellFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+cellLineageString+"/"+cellNumberString;
                    
                    connectAmendPath = newCellFolderPath+"/"+analysisID+"_"+cellLineageString+"_lineDataAmend";
                    
                    //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                    indexCount = 0;
                    
                    writingArray = new char [entryCount*13+20];
                    
                    for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                        if (masterReadForAmend [counter1*7+4] == fusionCellNo && masterReadForAmend [counter1*7+6] == fusionLingNo){
                            dataTemp = newUpperLimit;
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7+1];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = 1, indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7+3];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = masterReadForAmend [counter1*7+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                    
                    ofstream outfile5 (connectAmendPath.c_str(), ofstream::binary);
                    outfile5.write ((char*)writingArray, indexCount);
                    outfile5.close();
                    
                    delete [] writingArray;
                    delete [] masterReadForAmend;
                    
                    queueStringTemp = new string [queueListCount+50];
                    queueStringTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != cellLineageString || arrayQueueList [counter1*6+2] != cellNumberString){
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                        }
                    }
                    
                    imageNoTemp = "";
                    string statusFuseTemp = "";
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+1] == cellLineageString && arrayQueueList [counter1*6+2] == cellNumberString){
                            imageNoTemp = arrayQueueList [counter1*6+3];
                            statusFuseTemp = arrayQueueList [counter1*6+4];
                        }
                    }
                    
                    queueListCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
                    
                    queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                    
                    if (autoTrackFirstSave == 0){
                        string tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (queueListCount != 0){
                        mainDataEntry = new char [queueListCount*12+10];
                        totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < queueListCount; counter1++){
                            extension = arrayQueueList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile6 (queueListPath.c_str(), ofstream::binary);
                        outfile6.write (mainDataEntry, totalEntryCount);
                        outfile6.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    delete [] queueStringTemp;
                    
                    lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+cellLineageString+"/"+analysisID+"_"+cellLineageString+"_CellStatus";
                    
                    sizeForCopy = 0;
                    
                    if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    masterReadForCellInfo = new int [sizeForCopy+50];
                    masterReadForCellInfoCount = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End") masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++, dataString = "";
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                    //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                        if (masterReadForCellInfo [counter1*7] == fusionCellNo){
                            if ((int)statusFuseTemp.find("/m") == -1) masterReadForCellInfo [counter1*7+5] = 47;
                            else masterReadForCellInfo [counter1*7+5] = 78;
                            
                            break;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                    //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                    //}
                    
                    mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < masterReadForCellInfoCount; counter1++){
                        extension = to_string(masterReadForCellInfo [counter1]);
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile8 (lineageFolderPath2.c_str(), ofstream::binary);
                    outfile8.write (mainDataEntry, totalEntryCount);
                    outfile8.close();
                    
                    delete [] mainDataEntry;
                    
                    //=========Done List UpDate==========
                    //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Check status-----
                    //-----Check Status: OK, LST, CFU, CDD, CTD, CHD, UN-----
                    
                    doneListUpdateTemp = new string [doneListCount+50];
                    doneListUpdateTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != cellLineageString || arrayDoneList [counter1*5+2] != cellNumberString){
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                            doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                        }
                    }
                    
                    checkStatusAutoTemp = "";
                    
                    if ((int)statusFuseTemp.find("/m") == -1) checkStatusAutoTemp = "FP";
                    else checkStatusAutoTemp = "FP/m";
                    
                    doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameAuto, doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = cellLineageString, doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = cellNumberString, doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = imageNoTemp, doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = checkStatusAutoTemp, doneListUpdateTempCount++;
                    
                    if (doneListUpdateTempCount > doneListLimit){
                        delete [] arrayDoneList;
                        arrayDoneList = new string [doneListUpdateTempCount+500];
                        doneListLimit = doneListUpdateTempCount+500;
                    }
                    
                    doneListCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                    
                    delete [] doneListUpdateTemp;
                    
                    doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                    
                    if (autoTrackFirstSave == 0){
                        string tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                    }
                    
                    if (doneListCount != 0){
                        mainDataEntry = new char [doneListCount*10+10];
                        totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < doneListCount; counter1++){
                            extension = arrayDoneList [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile7 (doneListPath.c_str(), ofstream::binary);
                        outfile7.write (mainDataEntry, totalEntryCount);
                        outfile7.close();
                        
                        delete [] mainDataEntry;
                    }
                }
                
                //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                int numberOfEntry = 0;
                
                for (int counter1 = 0; counter1 < startEndCommCount/8; counter1++){
                    if (startEndCommTemp [counter1*8] == lineageAmendTemp) numberOfEntry++;
                }
                
                int completionCheck = 0;
                
                //-----Completion check-----
                for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                    if (masterReadForCellInfo [counter1*7+2] == -1){
                        completionCheck = 1;
                        break;
                    }
                    else if (masterReadForCellInfo [counter1*7+4] == 0){
                        completionCheck = 1;
                        break;
                    }
                    else if (masterReadForCellInfo [counter1*7+5] != 0){
                        completionCheck = 1;
                        break;
                    }
                }
                
                delete [] masterReadForCellInfo;
                
                string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStatus";
                
                sizeForCopy = 0;
                
                if (stat(connectDataInfoPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *masterReadForLineageInfo = new int [sizeForCopy+50];
                int masterReadForLineageInfoCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(connectDataInfoPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                masterReadForLineageInfo [masterReadForLineageInfoCount] = atoi(dataString.c_str()), masterReadForLineageInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                }
                
                for (int counter1 = 0; counter1 < masterReadForLineageInfoCount/3; counter1++){
                    if (masterReadForLineageInfo [counter1*3] == lineageAmendTemp){
                        if (completionCheck == 1) masterReadForLineageInfo [counter1*3+1] = 0;
                        else if (completionCheck == 0) masterReadForLineageInfo [counter1*3+1] = 1;
                        
                        masterReadForLineageInfo [counter1*3+2] = numberOfEntry;
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < masterReadForLineageInfoCount/3; counterA++){
                //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<masterReadForLineageInfo [counterA*3+counterB];
                //	cout<<" masterReadForLineageInfo "<<counterA<<endl;
                //}
                
                mainDataEntry = new char [masterReadForLineageInfoCount*6+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < masterReadForLineageInfoCount; counter1++){
                    extension = to_string(masterReadForLineageInfo [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile6 (connectDataInfoPath.c_str(), ofstream::binary);
                outfile6.write (mainDataEntry, totalEntryCount);
                outfile6.close();
                
                delete [] mainDataEntry;
                delete [] masterReadForLineageInfo;
            }
            
            delete [] lineageExtractionTemp;
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
            //	cout<<" arrayPositionRevise "<<counterA<<endl;
            //}
            
            //=======Lineage partner line=======
            if (fusionPartnerInfoCount != 0){
                string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_FusionPartner";
                
                sizeForCopy = 0;
                
                if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+fusionPartnerInfoCount+50];
                int lineagePartnerInfoTempCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(cellFusionPartnerPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        string treatmentNameGet;
                        string lineageNoGet;
                        string cellNoGet;
                        string imageNoGet;
                        string partnerLingNoGet;
                        string partnerCellNoGet;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            getline(fin, treatmentNameGet);
                            
                            if (treatmentNameGet == "") terminationFlag = 0;
                            else{
                                
                                getline(fin, lineageNoGet);
                                getline(fin, cellNoGet);
                                getline(fin, imageNoGet);
                                getline(fin, partnerLingNoGet);
                                getline(fin, partnerCellNoGet);
                                
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                }
                
                string imageNoString;
                string lingPartnerString;
                string cellPartnerString;
                string lingString;
                string cellString;
                
                for (int counter1 = 0; counter1 < fusionPartnerInfoCount/3; counter1++){
                    imageNoString = to_string(fusionPartnerInfo [counter1*3]);
                    lingPartnerString = to_string(fusionPartnerInfo [counter1*3+1]);
                    cellPartnerString = to_string(fusionPartnerInfo [counter1*3+2]);
                    
                    lingString = lineageNoAuto.substr(1);
                    lingString = to_string(atoi(lingString.c_str()));
                    cellString = cellNoAuto.substr(1);
                    cellString = to_string(atoi(cellString.c_str()));
                    
                    arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameAuto, lineagePartnerInfoTempCount++;
                    arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lingString, lineagePartnerInfoTempCount++;
                    arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellString, lineagePartnerInfoTempCount++;
                    arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoString, lineagePartnerInfoTempCount++;
                    arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lingPartnerString, lineagePartnerInfoTempCount++;
                    arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellPartnerString, lineagePartnerInfoTempCount++;
                }
                
                if (lineagePartnerInfoTempCount != 0){
                    ofstream oin;
                    oin.open(cellFusionPartnerPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount; counter1++) oin<<arrayLineagePartnerInfoTemp [counter1]<<endl;
                    
                    oin.close();
                }
                else remove (cellFusionPartnerPath.c_str());
                
                delete [] arrayLineagePartnerInfoTemp;
            }
            
            //=======Mitosis Set array=======
            string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_MitosisData";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                if (processTypeCell == 3 || processTypeCell == 2){
                    int *arrayMitosisTemp = new int [sizeForCopy+50];
                    int mitosisTempCount = 0;
                    int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                    int mitosisTempCount2 = 0;
                    
                    int overflowCheck = 0;
                    
                    fin.open(mitosisStatusPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        string lineageNoGet;
                        string cellNoGet;
                        string imageNoGet;
                        string setTypeGet;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            getline(fin, lineageNoGet);
                            
                            if (lineageNoGet == "") terminationFlag = 0;
                            else{
                                
                                getline(fin, cellNoGet);
                                getline(fin, imageNoGet);
                                getline(fin, setTypeGet);
                                
                                arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                
                                if (mitosisTempCount > 2100000000){
                                    overflowCheck = 1;
                                    break;
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                    
                    //for (int counterA = 0; counterA < mitosisTempCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp [counterA*4+counterB];
                    //    cout<<" arrayMitosisTemp "<<counterA<<endl;
                    //}
                    
                    if (overflowCheck == 0){
                        for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                            if (arrayMitosisTemp [counter1*4] != lineageAmendTemp || arrayMitosisTemp [counter1*4+1] != cellAmendTemp){
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                        //    cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                        //}
                        
                        if (mitosisTempCount2 != 0){
                            ofstream oin;
                            oin.open(mitosisStatusPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                            
                            oin.close();
                        }
                        else remove (mitosisStatusPath.c_str());
                    }
                    else remove (mitosisStatusPath.c_str());
                    
                    delete [] arrayMitosisTemp;
                    delete [] arrayMitosisTemp2;
                }
            }
            
            if (processTypeCell == 1){
                int mitosisSetFind = 0;
                int lineageFirstPoint = 0;
                int lineageLastPoint = 0;
                
                for (int counter1 = 0; counter1 < lineageCommTempCount/8; counter1++){
                    if (lineageCommTemp [counter1*8+6] == lineageAmendTemp && lineageCommTemp [counter1*8+5] == cellAmendTemp){
                        if (lineageCommTemp [counter1*8+3] == 10) mitosisSetFind = lineageCommTemp [counter1*8+2];
                        if (lineageLastPoint < lineageCommTemp [counter1*8+2]) lineageLastPoint = lineageCommTemp [counter1*8+2];
                        if (lineageFirstPoint == 0) lineageFirstPoint = lineageCommTemp [counter1*8+2];
                    }
                }
                
                int *arrayMitosisTemp = new int [sizeForCopy+50];
                int mitosisTempCount = 0;
                int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                int mitosisTempCount2 = 0;
                int *arrayMitosisTemp3 = new int [sizeForCopy+50];
                int mitosisTempCount3 = 0;
                
                int overflowCheck = 0;
                
                fin.open(mitosisStatusPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    string lineageNoGet;
                    string cellNoGet;
                    string imageNoGet;
                    string setTypeGet;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, lineageNoGet);
                        
                        if (lineageNoGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, setTypeGet);
                            
                            arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                            
                            if (mitosisTempCount > 2100000000){
                                overflowCheck = 1;
                                break;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
                
                //for (int counterA = 0; counterA < mitosisCommTempCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<mitosisCommTemp [counterA*4+counterB];
                //    cout<<" mitosisCommTemp "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < mitosisTempCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp [counterA*4+counterB];
                //    cout<<" arrayMitosisTemp "<<counterA<<endl;
                //}
                
                if (overflowCheck == 0){
                    for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                        if (arrayMitosisTemp [counter1*4] != lineageAmendTemp || arrayMitosisTemp [counter1*4+1] != cellAmendTemp){
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                        }
                        else{
                            
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4], mitosisTempCount3++;
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+1], mitosisTempCount3++;
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+2], mitosisTempCount3++;
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+3], mitosisTempCount3++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                    //    cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < mitosisTempCount3/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp3 [counterA*4+counterB];
                    //    cout<<" arrayMitosisTemp3 "<<counterA<<endl;
                    //}
                    
                    int *arrayMitosisTemp4 = new int [(lineageLastPoint-lineageFirstPoint+1)*4+50];
                    int mitosisTempCount4 = 0;
                    
                    for (int counter1 = lineageFirstPoint; counter1 <= lineageLastPoint; counter1++){
                        arrayMitosisTemp4 [mitosisTempCount4] = lineageAmendTemp, mitosisTempCount4++;
                        arrayMitosisTemp4 [mitosisTempCount4] = cellAmendTemp, mitosisTempCount4++;
                        arrayMitosisTemp4 [mitosisTempCount4] = counter1, mitosisTempCount4++;
                        
                        if (mitosisSetFind != 0 && mitosisSetFind == counter1) arrayMitosisTemp4 [mitosisTempCount4] = 10, mitosisTempCount4++;
                        else arrayMitosisTemp4 [mitosisTempCount4] = 0, mitosisTempCount4++;
                    }
                    
                    if (mitosisSetFind == 0){
                        int prevFirstPoint = 0;
                        int prevLastPoint = 0;
                        
                        for (int counter1 = 0; counter1 < mitosisTempCount3/4; counter1++){
                            if (prevFirstPoint == 0) prevFirstPoint = arrayMitosisTemp3 [counter1*4+2];
                            
                            prevLastPoint = arrayMitosisTemp3 [counter1*4+2];
                        }
                        
                        if (prevFirstPoint < lineageFirstPoint) prevFirstPoint = lineageFirstPoint;
                        if (prevLastPoint > lineageLastPoint) prevLastPoint = lineageLastPoint;
                        if (prevFirstPoint > lineageLastPoint || prevLastPoint < lineageFirstPoint) prevFirstPoint = 0;
                        
                        if (prevFirstPoint != 0){
                            int prevFind = 0;
                            int prevCount = 0;
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount4/4; counter1++){
                                if (prevLastPoint > prevFirstPoint){
                                    if (arrayMitosisTemp4 [counter1*4+2] == prevFirstPoint){
                                        if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        prevFind = 1;
                                        prevCount++;
                                    }
                                    else if (arrayMitosisTemp4 [counter1*4+2] == prevLastPoint){
                                        if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        prevFind = 0;
                                    }
                                    else if (prevFind == 1){
                                        if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        prevCount++;
                                    }
                                }
                                
                                if (arrayMitosisTemp4 [counter1*4] == prevFirstPoint && prevLastPoint == prevFirstPoint){
                                    if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                    
                                    arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                }
                            }
                        }
                        
                        prevFirstPoint = 0;
                        prevLastPoint = 0;
                        
                        for (int counter1 = 0; counter1 < mitosisCommTempCount/4; counter1++){
                            if (prevFirstPoint == 0) prevFirstPoint = mitosisCommTemp [counter1*4+2];
                            
                            prevLastPoint = mitosisCommTemp [counter1*4+2];
                        }
                        
                        if (prevFirstPoint < lineageFirstPoint) prevFirstPoint = lineageFirstPoint;
                        if (prevLastPoint > lineageLastPoint) prevLastPoint = lineageLastPoint;
                        if (prevFirstPoint > lineageLastPoint || prevLastPoint < lineageFirstPoint) prevFirstPoint = 0;
                        
                        if (prevFirstPoint != 0){
                            int prevFind = 0;
                            int prevCount = 0;
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount4/4; counter1++){
                                if (prevLastPoint > prevFirstPoint){
                                    if (arrayMitosisTemp4 [counter1*4+2] == prevFirstPoint){
                                        if (mitosisCommTemp [prevCount*4+3] == 10) mitosisCommTemp [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = mitosisCommTemp [prevCount*4+3];
                                        prevFind = 1;
                                        prevCount++;
                                    }
                                    else if (arrayMitosisTemp4 [counter1*4+2] == prevLastPoint){
                                        if (mitosisCommTemp [prevCount*4+3] == 10) mitosisCommTemp [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = mitosisCommTemp [prevCount*4+3];
                                        prevFind = 0;
                                    }
                                    else if (prevFind == 1){
                                        if (mitosisCommTemp [prevCount*4+3] == 10) mitosisCommTemp [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = mitosisCommTemp [prevCount*4+3];
                                        prevCount++;
                                    }
                                }
                                
                                if (arrayMitosisTemp4 [counter1*4] == prevFirstPoint && prevLastPoint == prevFirstPoint){
                                    if (mitosisCommTemp [prevCount*4+3] == 10) mitosisCommTemp [prevCount*4+3] = 0;
                                    
                                    arrayMitosisTemp4 [counter1*4+3] = mitosisCommTemp [prevCount*4+3];
                                }
                            }
                        }
                        
                        ofstream oin;
                        oin.open(mitosisStatusPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                        for (int counter1 = 0; counter1 < mitosisTempCount4; counter1++) oin<<arrayMitosisTemp4 [counter1]<<endl;
                        
                        oin.close();
                        
                        delete [] arrayMitosisTemp4;
                    }
                }
                else remove (mitosisStatusPath.c_str());
                
                delete [] arrayMitosisTemp;
                delete [] arrayMitosisTemp2;
                delete [] arrayMitosisTemp3;
            }
            
            if (autoTrackFirstSave == 0) autoTrackFirstSave = 1;
            
            returnResults = nextConnectNo;
            
            delete [] arrayEventSequenceReorganize;
        }
        
        delete [] startEndCommTemp;
        delete [] eventTemp;
        delete [] mitosisCommTemp;
        
        subCompleteFlag = 0;
    }
    else returnResults = -1;
    
    delete [] lineageCommTemp;
    
    return returnResults;
}

@end
