//
//  AreaSetFluorescent.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-01-28.
//
//

#ifndef AREASETFLUORORESCENT_H
#define AREASETFLUORORESCENT_H
#import "Controller.h"
#endif

@interface AreaSetFluorescent : NSObject {
    id fileUpdate;
}

-(int)newFluorescentLineCut;
-(int)newFluorescentAreaSet;

@end
