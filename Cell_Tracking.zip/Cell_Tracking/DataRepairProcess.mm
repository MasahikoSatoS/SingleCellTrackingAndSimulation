//
//  DataRepairProcess.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#import "DataRepairProcess.h"

@implementation DataRepairProcess

-(int)lineageProcessMain{
    int returnValue = 0;
    
    string clearLineage;
    string cellNumberString;
    string folderPath3;
    string connectStartEndPath;
    string imagePositionString;
    
    int stepCount = 0;
    int finData [25];
    int lastEventType = 0;
    int entryCount = 0;
    int dataTemp = 0;
    int readBit [3];
    
    unsigned long readPosition = 0;
    long indexCount = 0;
    
    ifstream fin;
    
    nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
    
    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    if (checkFlag == 1){
        //-----Lineage data upload-----
        arrayLineageRepairData = new int [sizeForCopy+50];
        lineageDataRepairCount = 0;
        
        int returnValue2 = 0;
        int processType2 = -1;
        
        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
        returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
        
        if (returnValue2 == 0){
            int maxLingNo = 0;
            int totalCellData = 0;
            
            for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                if (arrayLineageRepairData [counter2*8+6] > maxLingNo){
                    maxLingNo = arrayLineageRepairData [counter2*8+6];
                }
                
                if (arrayLineageRepairData [counter2*8+3] == 1 || arrayLineageRepairData [counter2*8+3] == 31 || arrayLineageRepairData [counter2*8+3] == 41 || arrayLineageRepairData [counter2*8+3] == 51 || arrayLineageRepairData [counter2*8+3] == 13) totalCellData++;
            }
            
            //-----TrackData, Treat folder check (delete or create)-----
            int *lingList = new int [maxLingNo+10];
            
            for (int counter2 = 0; counter2 < maxLingNo+10; counter2++) lingList [counter2] = 0;
            
            for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                lingList [arrayLineageRepairData [counter2*8+6]]++;
            }
            
            //for (int counterA = 1; counterA <= maxLingNo; counterA++){
            //    cout<<counterA<<" "<<lingList [counterA]<<" LinList"<<endl;
            //}
            
            string imageFolderSTPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Treat";
            string entry;
            
            fileDeleteCount = 0;
            
            DIR *dir = opendir(imageFolderSTPath.c_str());
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("L") != -1){
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
            
            string *fileInfo = new string [fileDeleteCount+10];
            int fileInfoCount = 0;
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) fileInfo [fileInfoCount] = arrayFileDelete [counter1], fileInfoCount++;
            
            int matchFind = 0;
            
            string imageFolderSTLingPath;
            string entry2;
            string entry3;
            string sourceAnalysisPath2;
            
            for (int counter1 = 0; counter1 < fileInfoCount; counter1++){
                matchFind = 0;
                
                for (int counter2 = 1; counter2 <= maxLingNo; counter2++){
                    if (lingList [counter2] != 0 && counter2 == atoi(fileInfo [counter1].substr(1).c_str())){
                        matchFind = 1;
                        break;
                    }
                }
                
                if (matchFind == 0){
                    imageFolderSTLingPath = imageFolderSTPath+"/"+fileInfo [counter1];
                    
                    dir = opendir(imageFolderSTLingPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                sourceAnalysisPath2 = imageFolderSTLingPath+"/"+entry;
                                
                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate fileDeleteUpDate];
                                        }
                                        
                                        arrayFileDelete [fileDeleteCount] = sourceAnalysisPath2+"/"+entry2, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                        remove (arrayFileDelete [counter3].c_str());
                    }
                    
                    dir = opendir(imageFolderSTLingPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = imageFolderSTLingPath+"/"+entry, fileDeleteCount++;
                        }
                        
                        closedir (dir);
                    }
                    
                    for (int counter3 = 0; counter3 < fileDeleteCount; counter3++){
                        remove (arrayFileDelete [counter3].c_str());
                    }
                    
                    remove (imageFolderSTLingPath.c_str());
                }
            }
            
            string extension;
            
            for (int counter1 = 1; counter1 <= maxLingNo; counter1++){
                if (lingList [counter1] != 0){
                    matchFind = 0;
                    
                    for (int counter2 = 0; counter2 < fileInfoCount; counter2++){
                        if (counter1 == atoi(fileInfo [counter2].substr(1).c_str())){
                            matchFind = 1;
                            break;
                        }
                    }
                    
                    if (matchFind == 0){
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) extension = "L0000"+extension;
                        else if (extension.length() == 2) extension = "L000"+extension;
                        else if (extension.length() == 3) extension = "L00"+extension;
                        else if (extension.length() == 4) extension = "L0";
                        else if (extension.length() == 5) extension = "L";
                        
                        imageFolderSTLingPath = imageFolderSTPath+"/"+extension;
                        
                        mkdir(imageFolderSTLingPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    }
                }
            }
            
            delete [] fileInfo;
            
            //-----Cell sub-folder check (create or delete)-----
            int *arrayLineageRepairData2 = new int [lineageDataRepairCount+50];
            int lineageDataRepairCount2 = 0;
            
            int cellDataCount = 0;
            
            string cellLineageString;
            string imageFolderSTLingPath2;
            
            for (int counter1 = 1; counter1 <= maxLingNo; counter1++){
                if (lingList [counter1] != 0){
                    lineageDataRepairCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                        if (arrayLineageRepairData [counter2*8+6] == counter1){
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+1], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+2], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+3], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+4], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+5], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+6], lineageDataRepairCount2++;
                            arrayLineageRepairData2 [lineageDataRepairCount2] = arrayLineageRepairData [counter2*8+7], lineageDataRepairCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataRepairCount2/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData2 [counterA*8+counterB];
                    //    cout<<" arrayLineageRepairData2 "<<counterA<<endl;
                    //}
                    
                    int *arrayCellData = new int [lineageDataRepairCount2+50];
                    cellDataCount = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataRepairCount2/8; counter2++){
                        if (arrayLineageRepairData2 [counter2*8+5] != -1){
                            matchFind = 0;
                            
                            for (int counter3 = 0; counter3 < cellDataCount; counter3++){
                                if (arrayLineageRepairData2 [counter2*8+5] == arrayCellData [counter3]){
                                    matchFind = 1;
                                    break;
                                }
                            }
                            
                            if (matchFind == 0){
                                arrayCellData [cellDataCount] = arrayLineageRepairData2 [counter2*8+5], cellDataCount++;
                            }
                        }
                    }
                    
                    cellLineageString = to_string(counter1);
                    
                    if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
                    else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
                    else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
                    else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
                    else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
                    
                    imageFolderSTLingPath = imageFolderSTPath+"/"+cellLineageString;
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(imageFolderSTLingPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("C") != -1){
                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate fileDeleteUpDate];
                                    }
                                    
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    fileInfo = new string [fileDeleteCount+10];
                    fileInfoCount = 0;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount; counter2++) fileInfo [fileInfoCount] = arrayFileDelete [counter2], fileInfoCount++;
                    
                    for (int counter2 = 0; counter2 < fileInfoCount; counter2++){
                        matchFind = 0;
                        
                        for (int counter3 = 0; counter3 < cellDataCount; counter3++){
                            if (arrayCellData [counter3] == atoi(fileInfo [counter2].substr(1).c_str())){
                                matchFind = 1;
                                break;
                            }
                        }
                        
                        if (matchFind == 0){
                            imageFolderSTLingPath2 = imageFolderSTLingPath+"/"+fileInfo [counter2];
                            
                            dir = opendir(imageFolderSTLingPath2.c_str());
                            fileDeleteCount = 0;
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate fileDeleteUpDate];
                                    }
                                    
                                    arrayFileDelete [fileDeleteCount] = imageFolderSTLingPath2+"/"+entry, fileDeleteCount++;
                                }
                                
                                closedir (dir);
                            }
                            
                            for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                                remove (arrayFileDelete [counter4].c_str());
                            }
                            
                            remove (imageFolderSTLingPath2.c_str());
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < cellDataCount; counter2++){
                        matchFind = 0;
                        
                        for (int counter3 = 0; counter3 < fileInfoCount; counter3++){
                            if (arrayCellData [counter2] == atoi(fileInfo [counter3].substr(1).c_str())){
                                matchFind = 1;
                                break;
                            }
                        }
                        
                        if (matchFind == 0){
                            cellNumberString = to_string(arrayCellData [counter2]);
                            
                            if (arrayCellData [counter2] >= 0){
                                if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                                else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                                else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                                else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                                else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                                else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                                else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                                else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                                else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                            }
                            else{
                                
                                cellNumberString = cellNumberString.substr(1);
                                
                                if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                                else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                                else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                                else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                                else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                                else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                                else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                                else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                                else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                            }
                            
                            imageFolderSTLingPath2 = imageFolderSTLingPath+"/"+cellNumberString;
                            
                            mkdir(imageFolderSTLingPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        }
                    }
                    
                    delete [] arrayCellData;
                    delete [] fileInfo;
                }
            }
            
            //-----Start-End data create and save-----
            int *arrayLineageStartEndTemp = new int [(totalCellData+1)*8+10];
            int lineageStartEndTempCount = 0;
            int *arrayLineageStartEndTemp2 = new int [(totalCellData+1)*9+10];
            int lineageStartEndTempCount2 = 0;
            
            int cellNumberStart = -1;
            int lineageNumberStart = 0;
            int firstEntryFind = 0;
            
            for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                if ((arrayLineageRepairData [counter2*8+6] != lineageNumberStart || arrayLineageRepairData [counter2*8+5] != cellNumberStart) && firstEntryFind == 0){
                    lineageNumberStart = arrayLineageRepairData [counter2*8+6];
                    cellNumberStart = arrayLineageRepairData [counter2*8+5];
                    
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = lineageNumberStart, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = cellNumberStart, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8], lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8+1], lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = counter2, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8+2], lineageStartEndTempCount++;
                    
                    firstEntryFind = 1;
                }
                else if ((arrayLineageRepairData [counter2*8+6] != lineageNumberStart || arrayLineageRepairData [counter2*8+5] != cellNumberStart) && firstEntryFind == 1){
                    lineageNumberStart = arrayLineageRepairData [counter2*8+6];
                    cellNumberStart = arrayLineageRepairData [counter2*8+5];
                    
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = counter2-1, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [(counter2-1)*8+2], lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = lineageNumberStart, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = cellNumberStart, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8], lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8+1], lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = counter2, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8+2], lineageStartEndTempCount++;
                }
                
                if (counter2 == lineageDataRepairCount/8-1){
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = counter2, lineageStartEndTempCount++;
                    arrayLineageStartEndTemp [lineageStartEndTempCount] = arrayLineageRepairData [counter2*8+2], lineageStartEndTempCount++;
                }
            }
            
            if (lineageStartEndTempCount != 0){
                connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageStartEnd";
                
                char *mainDataEntry = new char [lineageStartEndTempCount*7+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndTempCount; counter1++){
                    extension = to_string(arrayLineageStartEndTemp [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile5 (connectStartEndPath.c_str(), ofstream::binary);
                outfile5.write (mainDataEntry, totalEntryCount);
                outfile5.close();
                
                delete [] mainDataEntry;
            }
            
            //for (int counterA = 0; counterA < lineageStartEndTempCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEndTemp [counterA*8 +counterB];
            //    cout<<" arrayLineageStartEndTemp "<<counterA<<endl;
            //}
            
            //-----Amend line data check-----
            for (int counter2 = 0; counter2 < lineageStartEndTempCount/8; counter2++){
                lastEventType = arrayLineageRepairData [arrayLineageStartEndTemp [counter2*8+6]*8+3];
                
                //-----Check Amend line-----
                clearLineage = to_string(arrayLineageStartEndTemp [counter2*8]);
                
                if (clearLineage.length() == 1) clearLineage = "L0000"+clearLineage;
                else if (clearLineage.length() == 2) clearLineage = "L000"+clearLineage;
                else if (clearLineage.length() == 3) clearLineage = "L00"+clearLineage;
                else if (clearLineage.length() == 4) clearLineage = "L0"+clearLineage;
                else if (clearLineage.length() == 5) clearLineage = "L"+clearLineage;
                
                cellNumberString = to_string(arrayLineageStartEndTemp [counter2*8+1]);
                
                if (arrayLineageStartEndTemp [counter2*8+1] >= 0){
                    if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                    else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                    else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                    else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                    else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                    else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                    else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                    else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                    else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                }
                else{
                    
                    cellNumberString = cellNumberString.substr(1);
                    
                    if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                    else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                    else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                    else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                    else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                    else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                    else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                    else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                    else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                }
                
                folderPath3 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+nameStringRep+"_Treat/"+clearLineage+"/"+cellNumberString+"/"+analysisID+"_"+clearLineage+"_lineDataAmend";
                
                if (lastEventType == 1 || lastEventType == 2 || lastEventType == 31 || lastEventType == 41 || lastEventType == 51 || lastEventType == 61 || lastEventType == 6 || lastEventType == 92 || lastEventType == 10 || lastEventType == 11){
                    imagePositionString = to_string(arrayLineageStartEndTemp [counter2*8+7]);
                    
                    if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                    else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                    else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                    
                    masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+imagePositionString+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    int readingError = 0;
                    
                    for (int counter3 = 0; counter3 < 6; counter3++){
                        sizeForCopy = 0;
                        
                        if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter3 == 0) size1 = sizeForCopy;
                            else if (counter3 == 1) size2 = sizeForCopy;
                            else if (counter3 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter3 == 3) size1 = sizeForCopy;
                            else if (counter3 == 4) size2 = sizeForCopy;
                            else if (counter3 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    arrayPositionReviseVer = new int [sizeForCopy+50];
                    positionReviseVerCount = 0;
                    
                    if (checkFlag == 1){
                        fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                        else{
                                            
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [1], positionReviseVerCount++;
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [3], positionReviseVerCount++;
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [4], positionReviseVerCount++;
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [7], positionReviseVerCount++;
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [12], positionReviseVerCount++;
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [13], positionReviseVerCount++;
                                            arrayPositionReviseVer [positionReviseVerCount] = finData [16], positionReviseVerCount++;
                                        }
                                    }
                                    else if (stepCount == 1){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        finData [9] = finData [8]*256+finData [9];
                                        
                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    }
                                    else if (stepCount == 2){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        entryCount = 0;
                        
                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                            if (arrayPositionReviseVer [counter3*7+4] == arrayLineageStartEndTemp [counter2*8+1] && arrayPositionReviseVer [counter3*7+6] == arrayLineageStartEndTemp [counter2*8]){
                                entryCount++;
                            }
                        }
                        
                        indexCount = 0;
                        
                        char *writingArray = new char [entryCount*13+20];
                        
                        for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                            if (arrayPositionReviseVer [counter3*7+4] == arrayLineageStartEndTemp [counter2*8+1] && arrayPositionReviseVer [counter3*7+6] == arrayLineageStartEndTemp [counter2*8]){
                                dataTemp = arrayLineageStartEndTemp [counter2*8+7];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = arrayPositionReviseVer [counter3*7];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = arrayPositionReviseVer [counter3*7+1];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                writingArray [indexCount] = 1, indexCount++;
                                
                                dataTemp = arrayPositionReviseVer [counter3*7+3];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = arrayPositionReviseVer [counter3*7+6];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < 13; counter3++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile4 (folderPath3.c_str(), ofstream::binary);
                        outfile4.write ((char*)writingArray, indexCount);
                        outfile4.close();
                        
                        delete [] writingArray;
                    }
                    
                    delete [] arrayPositionReviseVer;
                }
                else{
                    
                    remove (folderPath3.c_str());
                }
            }
            
            //*********arrayCellNumberInfo**********
            //1. Cell Number
            //2. Starting time
            //3. End Time (if OP, -1) [Display, OP, CL]
            //4, Starting Status (0: no entry, 1:I, 2:M, 3:BD, 4:TD, 5:HD, 6:CD, 7:FU, 8:IP, 9:OF, 10:EF) [Display, IN, BD, TD, HD, FU]
            //5. End status (0: no entry, 1:I, 2:M, 3:BD, 4:TD, 5:HD, 6:CD, 7:FU, 8:IP, 9:OF, 10:EF) [Display OP, BD, TD, HD, CD, FU, OF, EF]
            //6. Check results
            //WO Mark(21: TD, 22: HD, 23: MD, 24: NS, 25: IP, 26: MC, 27: AC, 28: DB, 29: RC, 30: SC, 31: CM, 32: CN, 33: FM, 34: TL, 35: FE, 36: FO, 37: MF, 38: NM, 39: DL, 40: OF, 41: FC, 42: ME, 43: CF, 44: XS, 45: AM, 46: CL)
            //W Mark(51: TD/m, 52: HD/m, 53: MD/m, 54: NS/m, 55: IP/m, 56: MC/m, 57: AC/m, 58: DB/m, 59: RC/m, 60: SC/m, 61: CM/m, 62: CN/m, 63: FM/m, 64: TL/m, 65: FE/m, 66: FO/m, 67: MF/m, 68: NM/m, 69: DL/m, 70: OF/m, 71: FC/m, 72: ME/m, 73: CF/m, 74: XS/m, 75 AM/m, 76: CL/m, 77: /m)
            //7. Lineage No
            
            //**********Start/End assay*********
            //1. Lineage no;
            //2. Cell no;
            //3. X position;
            //4. Y position;
            //5. Start;
            //6. Image start;
            //7. End;
            //8. Image end
            
            //*********Done List**********
            //1. Treatment name;
            //2. Lineage No;
            //3. Cell number;
            //4. Image number (End);
            //5. Check status;
            //WO Mark(TD, HD, MD, NS, IP, MC, AC, DB, RC, SC, CM, CN, FM, TL, FE, FO, MF, NM, DL, OF, FC, ME, CF, XS, AM, CL, OK. OK/e)
            //W Mark(TD/m, HD/m, MD/m, NS/m, IP/m, MC/m, AC/m, DB/m, RC/m, SC/m, CM/m, CN/m, FM/m, TL/m, FE/m, FO/m, MF/m, NM/m, DL/m, OF/m, FC/m, ME/m, CF/m, XS/m, AM/m, CL/m, OK/m, OK/me)
            
            //*********Queue List**********
            //1. Treatment name; 30
            //2. Lineage No; 6
            //3. Cell number; 11
            //4. Image number (at the point of Amend); 4
            //5. Status (None (N), /m (m)) 5
            //6. Processing status 4
            //[Wait: Waiting, Proc: Processing: Redo: Will re-do]
            
            int *warningList = new int [lineageStartEndTempCount/8];
            
            for (int counter2 = 0; counter2 < lineageStartEndTempCount/8; counter2++) warningList [counter2] = -1;
            
            for (int counter2 = 0; counter2 < lineageStartEndTempCount/8; counter2++){
                for (int counter3 = 0; counter3 < queueListCount/6; counter3++){
                    if (arrayLineageStartEndTemp [counter2*8] == atoi(arrayQueueList [counter3*6+1].substr(1).c_str()) && arrayLineageStartEndTemp [counter2*8+1] == atoi(arrayQueueList [counter3*6+2].substr(1).c_str())){
                        warningList [counter2] = 100;
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < lineageStartEndTempCount/8; counter2++){
                for (int counter3 = 0; counter3 < doneListCount/5; counter3++){
                    if (arrayLineageStartEndTemp [counter2*8] == atoi(arrayDoneList [counter3*5+1].substr(1).c_str()) && arrayLineageStartEndTemp [counter2*8+1] == atoi(arrayDoneList [counter3*5+2].substr(1).c_str())){
                        if (arrayDoneList [counter3*5+4] == "TD" || arrayDoneList [counter3*5+4] == "TD/m") warningList [counter2] = 21;
                        else if (arrayDoneList [counter3*5+4] == "HD" || arrayDoneList [counter3*5+4] == "TD/m") warningList [counter2] = 22;
                        else if (arrayDoneList [counter3*5+4] == "MD" || arrayDoneList [counter3*5+4] == "MD/m") warningList [counter2] = 23;
                        else if (arrayDoneList [counter3*5+4] == "NS" || arrayDoneList [counter3*5+4] == "NS/m") warningList [counter2] = 24;
                        else if (arrayDoneList [counter3*5+4] == "IP" || arrayDoneList [counter3*5+4] == "IP/m") warningList [counter2] = 25;
                        else if (arrayDoneList [counter3*5+4] == "MC" || arrayDoneList [counter3*5+4] == "MC/m") warningList [counter2] = 26;
                        else if (arrayDoneList [counter3*5+4] == "AC" || arrayDoneList [counter3*5+4] == "AC/m") warningList [counter2] = 27;
                        else if (arrayDoneList [counter3*5+4] == "DB" || arrayDoneList [counter3*5+4] == "DB/m") warningList [counter2] = 28;
                        else if (arrayDoneList [counter3*5+4] == "RC" || arrayDoneList [counter3*5+4] == "RC/m") warningList [counter2] = 29;
                        else if (arrayDoneList [counter3*5+4] == "SC" || arrayDoneList [counter3*5+4] == "SC/m") warningList [counter2] = 30;
                        else if (arrayDoneList [counter3*5+4] == "CM" || arrayDoneList [counter3*5+4] == "CM/m") warningList [counter2] = 31;
                        else if (arrayDoneList [counter3*5+4] == "CN" || arrayDoneList [counter3*5+4] == "CN/m") warningList [counter2] = 32;
                        else if (arrayDoneList [counter3*5+4] == "FM" || arrayDoneList [counter3*5+4] == "FM/m") warningList [counter2] = 33;
                        else if (arrayDoneList [counter3*5+4] == "TL" || arrayDoneList [counter3*5+4] == "TL/m") warningList [counter2] = 34;
                        else if (arrayDoneList [counter3*5+4] == "FE" || arrayDoneList [counter3*5+4] == "FE/m") warningList [counter2] = 35;
                        else if (arrayDoneList [counter3*5+4] == "FO" || arrayDoneList [counter3*5+4] == "FO/m") warningList [counter2] = 36;
                        else if (arrayDoneList [counter3*5+4] == "MF" || arrayDoneList [counter3*5+4] == "MF/m") warningList [counter2] = 37;
                        else if (arrayDoneList [counter3*5+4] == "NM" || arrayDoneList [counter3*5+4] == "NM/m") warningList [counter2] = 38;
                        else if (arrayDoneList [counter3*5+4] == "DL" || arrayDoneList [counter3*5+4] == "DL/m") warningList [counter2] = 39;
                        else if (arrayDoneList [counter3*5+4] == "OF" || arrayDoneList [counter3*5+4] == "OF/m") warningList [counter2] = 40;
                        else if (arrayDoneList [counter3*5+4] == "FC" || arrayDoneList [counter3*5+4] == "FC/m") warningList [counter2] = 41;
                        else if (arrayDoneList [counter3*5+4] == "ME" || arrayDoneList [counter3*5+4] == "ME/m") warningList [counter2] = 42;
                        else if (arrayDoneList [counter3*5+4] == "CF" || arrayDoneList [counter3*5+4] == "CF/m") warningList [counter2] = 43;
                        else if (arrayDoneList [counter3*5+4] == "XS" || arrayDoneList [counter3*5+4] == "XS/m") warningList [counter2] = 44;
                        else if (arrayDoneList [counter3*5+4] == "AM" || arrayDoneList [counter3*5+4] == "AM/m") warningList [counter2] = 45;
                        else if (arrayDoneList [counter3*5+4] == "CL" || arrayDoneList [counter3*5+4] == "CL/m") warningList [counter2] = 46;
                        else if (arrayDoneList [counter3*5+4] == "FP" || arrayDoneList [counter3*5+4] == "FP/m") warningList [counter2] = 47;
                        else if (arrayDoneList [counter3*5+4] == "OK" || arrayDoneList [counter3*5+4] == "OK/m") warningList [counter2] = 0;
                    }
                }
            }
            
            int fusionMark = 0;
            int cellInfoProcessTempCount = 0;
            
            string lineageFolderPath;
            
            int *lineageInfoList = new int [maxLingNo*3+10];
            int lineageInfoListCount = 0;
            
            string *arrayQueueListTemp = new string [queueListCount+(lineageStartEndTempCount/8)*6+10];
            int queueListCountTemp = 0;
            string *arrayQueueListTemp2 = new string [queueListCount+10];
            int queueListCountTemp2 = 0;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] == nameStringRep){
                    arrayQueueListTemp2 [queueListCountTemp2] = arrayQueueList [counter1*6], queueListCountTemp2++;
                    arrayQueueListTemp2 [queueListCountTemp2] = arrayQueueList [counter1*6+1], queueListCountTemp2++;
                    arrayQueueListTemp2 [queueListCountTemp2] = arrayQueueList [counter1*6+2], queueListCountTemp2++;
                    arrayQueueListTemp2 [queueListCountTemp2] = arrayQueueList [counter1*6+3], queueListCountTemp2++;
                    arrayQueueListTemp2 [queueListCountTemp2] = arrayQueueList [counter1*6+4], queueListCountTemp2++;
                    arrayQueueListTemp2 [queueListCountTemp2] = arrayQueueList [counter1*6+5], queueListCountTemp2++;
                }
                else{
                    
                    arrayQueueListTemp [queueListCountTemp] = arrayQueueList [counter1*6], queueListCountTemp++;
                    arrayQueueListTemp [queueListCountTemp] = arrayQueueList [counter1*6+1], queueListCountTemp++;
                    arrayQueueListTemp [queueListCountTemp] = arrayQueueList [counter1*6+2], queueListCountTemp++;
                    arrayQueueListTemp [queueListCountTemp] = arrayQueueList [counter1*6+3], queueListCountTemp++;
                    arrayQueueListTemp [queueListCountTemp] = arrayQueueList [counter1*6+4], queueListCountTemp++;
                    arrayQueueListTemp [queueListCountTemp] = arrayQueueList [counter1*6+5], queueListCountTemp++;
                }
            }
            
            string *arrayDoneListTemp = new string [doneListCount+(lineageStartEndTempCount/8)*5+10];
            int doneListCountTemp = 0;
            string *arrayDoneListTemp2 = new string [doneListCount+10];
            int doneListCountTemp2 = 0;
            
            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                if (arrayDoneList [counter1*5] == nameStringRep){
                    arrayDoneListTemp2 [doneListCountTemp2] = arrayDoneList [counter1*5], doneListCountTemp2++;
                    arrayDoneListTemp2 [doneListCountTemp2] = arrayDoneList [counter1*5+1], doneListCountTemp2++;
                    arrayDoneListTemp2 [doneListCountTemp2] = arrayDoneList [counter1*5+2], doneListCountTemp2++;
                    arrayDoneListTemp2 [doneListCountTemp2] = arrayDoneList [counter1*5+3], doneListCountTemp2++;
                    arrayDoneListTemp2 [doneListCountTemp2] = arrayDoneList [counter1*5+4], doneListCountTemp2++;
                }
                else{
                    
                    arrayDoneListTemp [doneListCountTemp] = arrayDoneList [counter1*5], doneListCountTemp++;
                    arrayDoneListTemp [doneListCountTemp] = arrayDoneList [counter1*5+1], doneListCountTemp++;
                    arrayDoneListTemp [doneListCountTemp] = arrayDoneList [counter1*5+2], doneListCountTemp++;
                    arrayDoneListTemp [doneListCountTemp] = arrayDoneList [counter1*5+3], doneListCountTemp++;
                    arrayDoneListTemp [doneListCountTemp] = arrayDoneList [counter1*5+4], doneListCountTemp++;
                }
            }
            
            int lastEventTemp = 0;
            int firstEventTemp = 0;
            int completionCheck = 0;
            
            string extension2;
            
            //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
            //    cout<<" arrayLineageRepairData "<<counterA<<endl;
            //}
            
            for (int counter1 = 1; counter1 <= maxLingNo; counter1++){
                lineageStartEndTempCount2 = 0;
                
                for (int counter2 = 0; counter2 < lineageStartEndTempCount/8; counter2++){
                    if (arrayLineageStartEndTemp [counter2*8] == counter1){
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+1], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+2], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+3], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+4], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+5], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+6], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = arrayLineageStartEndTemp [counter2*8+7], lineageStartEndTempCount2++;
                        arrayLineageStartEndTemp2 [lineageStartEndTempCount2] = warningList [counter2], lineageStartEndTempCount2++;
                    }
                }
                
                //for (int counterA = 0; counterA < lineageStartEndTempCount2/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageStartEndTemp2 [counterA*9+counterB];
                //    cout<<" arrayLineageStartEndTemp2 "<<counterA<<endl;
                //}
                
                if (lineageStartEndTempCount2 != 0){
                    extension = to_string(counter1);
                    
                    if (extension.length() == 1) extension = "L0000"+extension;
                    else if (extension.length() == 2) extension = "L000"+extension;
                    else if (extension.length() == 3) extension = "L00"+extension;
                    else if (extension.length() == 4) extension = "L0"+extension;
                    else if (extension.length() == 5) extension = "L"+extension;
                    
                    lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Treat/"+extension+"/"+analysisID+"_"+extension+"_CellStatus";
                    
                    int *cellInfoProcessTemp = new int [(lineageStartEndTempCount2/8)*7+10];
                    cellInfoProcessTempCount = 0;
                    
                    //*********arrayCellNumberInfo**********
                    //1. Cell Number
                    //2. Starting time
                    //3. End Time (if OP, -1) [Display, OP, CL]
                    //4, Starting Status (0: no entry, 1:I, 2:M, 3:BD, 4:TD, 5:HD, 6:CD, 7:FU, 8:IP, 9:OF, 10:EF) [Display, IN, BD, TD, HD, FU]
                    //5. End status (0: no entry, 1:I, 2:M, 3:BD, 4:TD, 5:HD, 6:CD, 7:FU, 8:IP, 9:OF, 10:EF) [Display OP, BD, TD, HD, CD, FU, OF, EF]
                    //6. Check results
                    //WO Mark(21: TD, 22: HD, 23: MD, 24: NS, 25: IP, 26: MC, 27: AC, 28: DB, 29: RC, 30: SC, 31: CM, 32: CN, 33: FM, 34: TL, 35: FE, 36: FO, 37: MF, 38: NM, 39: DL, 40: OF, 41: FC, 42: ME, 43: CF, 44: XS, 45: AM, 46: CL)
                    //W Mark(51: TD/m, 52: HD/m, 53: MD/m, 54: NS/m, 55: IP/m, 56: MC/m, 57: AC/m, 58: DB/m, 59: RC/m, 60: SC/m, 61: CM/m, 62: CN/m, 63: FM/m, 64: TL/m, 65: FE/m, 66: FO/m, 67: MF/m, 68: NM/m, 69: DL/m, 70: OF/m, 71: FC/m, 72: ME/m, 73: CF/m, 74: XS/m, 75 AM/m, 76: CL/m, 77: /m)
                    //7. Lineage No
                    
                    //**********Start/End assay*********
                    //1. Lineage no;
                    //2. Cell no;
                    //3. X position;
                    //4. Y position;
                    //5. Start;
                    //6. Image start;
                    //7. End;
                    //8. Image end
                    
                    //**********arrayLineageData**********
                    //1. X position
                    //2. Y position
                    //3. Time Point
                    //4. Event Type
                    //[1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92]
                    //[FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One]
                    //5. Parent Cell Number/Fusion: Hold cell number of fusion partner
                    //6. Cell Number
                    //7. Cell Lineage No
                    //8. For Fusion, Hold cell lineage No of fusion partner
                    
                    //Insert Dummy: -1, -1, time point, event type: 13, 0, -1, ing no, 0
                    
                    completionCheck = 0;
                    
                    for (int counter2 = 0; counter2 < lineageStartEndTempCount2/9; counter2++){ //-----Fusion case, add into the Queue list-----
                        if (arrayLineageStartEndTemp2 [counter2*9+1] != -1){
                            lastEventTemp = 0;
                            firstEventTemp = 0;
                            fusionMark = 0;
                            
                            for (int counter3 = arrayLineageStartEndTemp2 [counter2*9+4]; counter3 <= arrayLineageStartEndTemp2 [counter2*9+6]; counter3++){
                                if (arrayLineageRepairData [counter3*8+3] == 10) fusionMark = 1;
                                if (counter3 == arrayLineageStartEndTemp2 [counter2*9+6]) lastEventTemp = arrayLineageRepairData [counter3*8+3];
                                if (counter3 == arrayLineageStartEndTemp2 [counter2*9+4]) firstEventTemp = arrayLineageRepairData [counter3*8+3];
                            }
                            
                            cellInfoProcessTemp [cellInfoProcessTempCount] = arrayLineageStartEndTemp2 [counter2*9+1], cellInfoProcessTempCount++;
                            cellInfoProcessTemp [cellInfoProcessTempCount] = arrayLineageStartEndTemp2 [counter2*9+5], cellInfoProcessTempCount++;
                            
                            if (lastEventTemp == 2 || lastEventTemp == 6 || lastEventTemp == 92 || lastEventTemp == 10 || lastEventTemp == 11 || lastEventTemp == 12){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = -1, cellInfoProcessTempCount++;
                                completionCheck = 1;
                            }
                            else{
                                
                                if (lastEventTemp == firstEventTemp){
                                    cellInfoProcessTemp [cellInfoProcessTempCount] = -1, cellInfoProcessTempCount++;
                                    completionCheck = 1;
                                }
                                else cellInfoProcessTemp [cellInfoProcessTempCount] = arrayLineageStartEndTemp2 [counter2*9+7], cellInfoProcessTempCount++;
                            }
                            
                            cellInfoProcessTemp [cellInfoProcessTempCount] = firstEventTemp, cellInfoProcessTempCount++;
                            
                            //[1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92]
                            //[FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One]
                            
                            if (lastEventTemp == 2 || lastEventTemp == 6 || lastEventTemp == 92 || lastEventTemp == 10 || lastEventTemp == 11 || lastEventTemp == 12){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 0, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 1 || lastEventTemp == 31 || lastEventTemp == 41 || lastEventTemp == 51){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 0, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 32 || lastEventTemp == 33){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 3, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 42 || lastEventTemp == 43 || lastEventTemp == 44){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 4, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 52 || lastEventTemp == 53 || lastEventTemp == 54 || lastEventTemp == 55){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 5, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 7){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 6, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 91){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 7, cellInfoProcessTempCount++;
                            }
                            else if (lastEventTemp == 8){
                                cellInfoProcessTemp [cellInfoProcessTempCount] = 9, cellInfoProcessTempCount++;
                            }
                            
                            if (fusionMark == 1){
                                if (arrayLineageStartEndTemp2 [counter2*9+8] == 21) cellInfoProcessTemp [cellInfoProcessTempCount] = 51, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 22) cellInfoProcessTemp [cellInfoProcessTempCount] = 52, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 23) cellInfoProcessTemp [cellInfoProcessTempCount] = 53, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 24) cellInfoProcessTemp [cellInfoProcessTempCount] = 54, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 25) cellInfoProcessTemp [cellInfoProcessTempCount] = 55, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 26) cellInfoProcessTemp [cellInfoProcessTempCount] = 56, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 27) cellInfoProcessTemp [cellInfoProcessTempCount] = 57, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 28) cellInfoProcessTemp [cellInfoProcessTempCount] = 58, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 29) cellInfoProcessTemp [cellInfoProcessTempCount] = 59, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 30) cellInfoProcessTemp [cellInfoProcessTempCount] = 60, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 31) cellInfoProcessTemp [cellInfoProcessTempCount] = 61, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 32) cellInfoProcessTemp [cellInfoProcessTempCount] = 62, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 33) cellInfoProcessTemp [cellInfoProcessTempCount] = 63, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 34) cellInfoProcessTemp [cellInfoProcessTempCount] = 64, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 35) cellInfoProcessTemp [cellInfoProcessTempCount] = 65, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 36) cellInfoProcessTemp [cellInfoProcessTempCount] = 66, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 37) cellInfoProcessTemp [cellInfoProcessTempCount] = 67, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 38) cellInfoProcessTemp [cellInfoProcessTempCount] = 68, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 39) cellInfoProcessTemp [cellInfoProcessTempCount] = 69, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 40) cellInfoProcessTemp [cellInfoProcessTempCount] = 70, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 41) cellInfoProcessTemp [cellInfoProcessTempCount] = 71, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 42) cellInfoProcessTemp [cellInfoProcessTempCount] = 72, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 43) cellInfoProcessTemp [cellInfoProcessTempCount] = 73, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 44) cellInfoProcessTemp [cellInfoProcessTempCount] = 74, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 45) cellInfoProcessTemp [cellInfoProcessTempCount] = 75, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 46) cellInfoProcessTemp [cellInfoProcessTempCount] = 76, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 47) cellInfoProcessTemp [cellInfoProcessTempCount] = 78, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 0) cellInfoProcessTemp [cellInfoProcessTempCount] = 77, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 100) cellInfoProcessTemp [cellInfoProcessTempCount] = 77, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == -1) cellInfoProcessTemp [cellInfoProcessTempCount] = 64, cellInfoProcessTempCount++;
                            }
                            else if (fusionMark == 0){
                                if (arrayLineageStartEndTemp2 [counter2*9+8] == -1) cellInfoProcessTemp [cellInfoProcessTempCount] = 34, cellInfoProcessTempCount++;
                                else if (arrayLineageStartEndTemp2 [counter2*9+8] == 100) cellInfoProcessTemp [cellInfoProcessTempCount] = 0, cellInfoProcessTempCount++;
                                else cellInfoProcessTemp [cellInfoProcessTempCount] = arrayLineageStartEndTemp2 [counter2*9+8], cellInfoProcessTempCount++;
                            }
                            
                            cellInfoProcessTemp [cellInfoProcessTempCount] = arrayLineageStartEndTemp2 [counter2*9], cellInfoProcessTempCount++;
                            
                            char *mainDataEntry = new char [cellInfoProcessTempCount*7+10];
                            int totalEntryCount = 0;
                            
                            for (int counter3 = 0; counter3 < cellInfoProcessTempCount; counter3++){
                                extension = to_string(cellInfoProcessTemp [counter3]);
                                
                                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile2 (lineageFolderPath.c_str(), ofstream::binary);
                            outfile2.write (mainDataEntry, totalEntryCount);
                            outfile2.close();
                            
                            delete [] mainDataEntry;
                            
                            //[1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92]
                            //[FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One]
                            
                            if (lastEventTemp == 1 || lastEventTemp == 2 || lastEventTemp == 31 || lastEventTemp == 41 || lastEventTemp == 51 || lastEventTemp == 6 || lastEventTemp == 92 || lastEventTemp == 10 || lastEventTemp == 11 || lastEventTemp == 12){
                                
                                //*********Done List**********
                                //1. Treatment name;
                                //2. Lineage No;
                                //3. Cell number;
                                //4. Image number (End);
                                //5. Check status;
                                //WO Mark(TD, HD, MD, NS, IP, MC, AC, DB, RC, SC, CM, CN, FM, TL, FE, FO, MF, NM, DL, OF, FC, ME, CF, XS, AM, CL, OK. OK/e)
                                //W Mark(TD/m, HD/m, MD/m, NS/m, IP/m, MC/m, AC/m, DB/m, RC/m, SC/m, CM/m, CN/m, FM/m, TL/m, FE/m, FO/m, MF/m, NM/m, DL/m, OF/m, FC/m, ME/m, CF/m, XS/m, AM/m, CL/m, OK/m, OK/me)
                                
                                //*********Queue List**********
                                //1. Treatment name; 30
                                //2. Lineage No; 6
                                //3. Cell number; 11
                                //4. Image number (at the point of Amend); 4
                                //5. Status (None (N), /m (m)) 5
                                //6. Processing status 4
                                //[Wait: Waiting, Proc: Processing: Redo: Will re-do]
                                
                                matchFind = 0;
                                
                                for (int counter3 = 0; counter3 < doneListCountTemp2/5; counter3++){
                                    if (arrayLineageStartEndTemp2 [counter2*9] == atoi(arrayDoneListTemp2 [counter3*5+1].substr(1).c_str()) && arrayLineageStartEndTemp2 [counter2*9+1] == atoi(arrayDoneListTemp2 [counter3*5+2].substr(1).c_str())){
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+1], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+2], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+3], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+4], doneListCountTemp++;
                                        
                                        matchFind = 1;
                                        
                                        break;
                                    }
                                }
                                
                                if (matchFind == 0){
                                    matchFind = 0;
                                    
                                    for (int counter3 = 0; counter3 < queueListCountTemp2/6; counter3++){
                                        if (arrayLineageStartEndTemp2 [counter2*9] == atoi(arrayQueueListTemp2 [counter3*6+1].substr(1).c_str()) && arrayLineageStartEndTemp2 [counter2*9+1] == atoi(arrayQueueListTemp2 [counter3*6+2].substr(1).c_str())){
                                            arrayQueueListTemp [queueListCountTemp] = arrayQueueListTemp2 [counter3*6], queueListCountTemp++;
                                            arrayQueueListTemp [queueListCountTemp] = arrayQueueListTemp2 [counter3*6+1], queueListCountTemp++;
                                            arrayQueueListTemp [queueListCountTemp] = arrayQueueListTemp2 [counter3*6+2], queueListCountTemp++;
                                            arrayQueueListTemp [queueListCountTemp] = arrayQueueListTemp2 [counter3*6+3], queueListCountTemp++;
                                            arrayQueueListTemp [queueListCountTemp] = arrayQueueListTemp2 [counter3*6+4], queueListCountTemp++;
                                            arrayQueueListTemp [queueListCountTemp] = arrayQueueListTemp2 [counter3*6+5], queueListCountTemp++;
                                            
                                            matchFind = 1;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                if (matchFind == 0){
                                    extension = to_string(arrayLineageStartEndTemp2 [counter2*9]);
                                    
                                    if (extension.length() == 1) extension = "L0000"+extension;
                                    else if (extension.length() == 2) extension = "L000"+extension;
                                    else if (extension.length() == 3) extension = "L00"+extension;
                                    else if (extension.length() == 4) extension = "L0"+extension;
                                    else if (extension.length() == 5) extension = "L"+extension;
                                    
                                    extension2 = to_string(arrayLineageStartEndTemp2 [counter2*9+1]);
                                    
                                    if (arrayLineageStartEndTemp2 [counter2*9+1] >= 0){
                                        if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                                        else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                                        else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                                        else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                                        else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                                        else if (extension2.length() == 6) extension2 = "C000"+extension2;
                                        else if (extension2.length() == 7) extension2 = "C00"+extension2;
                                        else if (extension2.length() == 8) extension2 = "C0"+extension2;
                                        else if (extension2.length() == 9) extension2 = "C"+extension2;
                                    }
                                    else{
                                        
                                        extension2 = extension2.substr(1);
                                        
                                        if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                                        else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                                        else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                                        else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                                        else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                                        else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                                        else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                                        else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                                        else if (extension2.length() == 9) extension2 = "C-"+extension2;
                                    }
                                    
                                    arrayQueueListTemp [queueListCountTemp] = nameStringRep, queueListCountTemp++;
                                    arrayQueueListTemp [queueListCountTemp] = extension, queueListCountTemp++;
                                    arrayQueueListTemp [queueListCountTemp] = extension2, queueListCountTemp++;
                                    arrayQueueListTemp [queueListCountTemp] = to_string(arrayLineageStartEndTemp2 [counter2*9+5])+":"+to_string(arrayLineageStartEndTemp2 [counter2*9+5]), queueListCountTemp++;
                                    
                                    arrayQueueListTemp [queueListCountTemp] = "0", queueListCountTemp++;
                                    arrayQueueListTemp [queueListCountTemp] = "Wait", queueListCountTemp++;
                                }
                            }
                            else{
                                
                                matchFind = 0;
                                
                                for (int counter3 = 0; counter3 < doneListCountTemp2/5; counter3++){
                                    if (arrayLineageStartEndTemp2 [counter2*9] == atoi(arrayDoneListTemp2 [counter3*5+1].substr(1).c_str()) && arrayLineageStartEndTemp2 [counter2*9+1] == atoi(arrayDoneListTemp2 [counter3*5+2].substr(1).c_str())){
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+1], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+2], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+3], doneListCountTemp++;
                                        arrayDoneListTemp [doneListCountTemp] = arrayDoneListTemp2 [counter3*5+4], doneListCountTemp++;
                                        
                                        matchFind = 1;
                                        
                                        break;
                                    }
                                }
                                
                                if (matchFind == 0){
                                    extension = to_string(arrayLineageStartEndTemp2 [counter2*9]);
                                    
                                    if (extension.length() == 1) extension = "L0000"+extension;
                                    else if (extension.length() == 2) extension = "L000"+extension;
                                    else if (extension.length() == 3) extension = "L00"+extension;
                                    else if (extension.length() == 4) extension = "L0"+extension;
                                    else if (extension.length() == 5) extension = "L"+extension;
                                    
                                    extension2 = to_string(arrayLineageStartEndTemp2 [counter2*9+1]);
                                    
                                    if (arrayLineageStartEndTemp2 [counter2*9+1] >= 0){
                                        if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                                        else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                                        else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                                        else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                                        else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                                        else if (extension2.length() == 6) extension2 = "C000"+extension2;
                                        else if (extension2.length() == 7) extension2 = "C00"+extension2;
                                        else if (extension2.length() == 8) extension2 = "C0"+extension2;
                                        else if (extension2.length() == 9) extension2 = "C"+extension2;
                                    }
                                    else{
                                        
                                        extension2 = extension2.substr(1);
                                        
                                        if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                                        else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                                        else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                                        else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                                        else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                                        else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                                        else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                                        else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                                        else if (extension2.length() == 9) extension2 = "C-"+extension2;
                                    }
                                    
                                    arrayDoneListTemp [doneListCountTemp] = nameStringRep, doneListCountTemp++;
                                    arrayDoneListTemp [doneListCountTemp] = extension, doneListCountTemp++;
                                    arrayDoneListTemp [doneListCountTemp] = extension2, doneListCountTemp++;
                                    arrayDoneListTemp [doneListCountTemp] = to_string(arrayLineageStartEndTemp2 [counter2*9+5])+":"+to_string(arrayLineageStartEndTemp2 [counter2*9+5]), doneListCountTemp++;
                                    
                                    arrayDoneListTemp [doneListCountTemp] = "TL", doneListCountTemp++;
                                }
                            }
                        }
                    }
                    
                    lineageInfoList [lineageInfoListCount] = counter1, lineageInfoListCount++;
                    
                    if (completionCheck == 1) lineageInfoList [lineageInfoListCount] = 1, lineageInfoListCount++;
                    else lineageInfoList [lineageInfoListCount] = 0, lineageInfoListCount++;
                    
                    lineageInfoList [lineageInfoListCount] = lineageStartEndTempCount2/9, lineageInfoListCount++;
                    
                    delete [] cellInfoProcessTemp;
                }
            }
            
            string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageStatus";
            
            //*********arrayCellLineageInfo**********
            //1. Cell Lineage NO
            //2. Status, 1: Done, 0: Open; Garbage 3: Done, 2: Open;
            //3. Number of cells in the lineage
            
            char *mainDataEntry = new char [lineageInfoListCount*6+10];
            int totalEntryCount = 0;
            
            for (int counter1 = 0; counter1 < lineageInfoListCount; counter1++){
                extension = to_string(lineageInfoList [counter1]);
                
                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile5 (connectDataInfoPath.c_str(), ofstream::binary);
            outfile5.write (mainDataEntry, totalEntryCount);
            outfile5.close();
            
            delete [] mainDataEntry;
            
            if (treatmentNameHold == nameStringRep){
                delete [] arrayCellLineageInfo;
                arrayCellLineageInfo = new int [lineageInfoListCount+300];
                
                cellLineageInfoLimit = lineageInfoListCount+300;
                cellLineageInfoCount = 0;
                
                for (int counter1 = 0; counter1 < lineageInfoListCount; counter1++) arrayCellLineageInfo [cellLineageInfoCount] = lineageInfoList [counter1], cellLineageInfoCount++;
            }
            
            //=========Queue List creation==========
            //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Status, 6. Processing status-----
            //-----Status: MANU, EVAL-----
            //-----Processing Status: WAIT, PROC, PEND-----
            
            if (queueListCount+12 > queueListLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate queueListUpDate];
            }
            
            queueListCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCountTemp; counter1++) arrayQueueList [queueListCount] = arrayQueueListTemp [counter1],queueListCount++;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                mainDataEntry = new char [queueListCount*12+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile6 (queueListPath.c_str(), ofstream::binary);
                outfile6.write (mainDataEntry, totalEntryCount);
                outfile6.close();
                
                delete [] mainDataEntry;
            }
            
            if (doneListCount+10 > doneListLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate doneListUpDate];
            }
            
            doneListCount = 0;
            
            for (int counter1 = 0; counter1 < doneListCountTemp; counter1++) arrayDoneList [doneListCount] = arrayDoneListTemp [counter1], doneListCount++;
            
            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
            
            if (doneListCount != 0){
                mainDataEntry = new char [doneListCount*10+10];
                totalEntryCount = 0;
                
                for (int counter2 = 0; counter2 < doneListCount; counter2++){
                    extension = arrayDoneList [counter2];
                    
                    for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                outfile2.write (mainDataEntry, totalEntryCount);
                outfile2.close();
                
                delete [] mainDataEntry;
            }
            
            //********arrayLineagePartnerInfo*********
            //1.TreatName
            //2.Lineage No
            //3.Cell no
            //4.W-image position
            //5.Partner Lineage No
            //6.Partner Cell No
            
            //********arrayMitosisStatus*********
            //1.Lineage No
            //2.Cell no
            //3.Image No
            //4.Status data (10: Mitosis, 1,2,6: Mitosis status, 3,4: cell death status)
            
            //=======Lineage partner line=======
            string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+nameStringRep+"_FusionPartner";
            
            sizeForCopy = 0;
            
            if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                int lineagePartnerInfoTempCount = 0;
                
                string *arrayLineagePartnerInfoTemp2 = new string [sizeForCopy+50];
                int lineagePartnerInfoTempCount2 = 0;
                
                fin.open(cellFusionPartnerPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    string treatmentNameGet;
                    string lineageNoGet;
                    string cellNoGet;
                    string imageNoGet;
                    string partnerLingNoGet;
                    string partnerCellNoGet;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, treatmentNameGet);
                        
                        if (treatmentNameGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, lineageNoGet);
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, partnerLingNoGet);
                            getline(fin, partnerCellNoGet);
                            
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
                
                for (int counter2 = 0; counter2 < lineageStartEndTempCount/8; counter2++){ //-----Fusion case, add into the Queue list-----
                    fusionMark = 0;
                    
                    for (int counter3 = arrayLineageStartEndTemp [counter2*8+4]; counter3 <= arrayLineageStartEndTemp [counter2*8+6]; counter3++){
                        if (arrayLineageRepairData [counter3*8+3] == 10) fusionMark = 1;
                    }
                    
                    //********arrayLineagePartnerInfo*********
                    //1.TreatName
                    //2.Lineage No
                    //3.Cell no
                    //4.W-image position
                    //5.Partner Lineage No
                    //6.Partner Cell No
                    
                    if (fusionMark == 1){
                        for (int counter3 = 0; counter3 < lineagePartnerInfoTempCount/6; counter3++){
                            extension = to_string(arrayLineageStartEndTemp [counter2*9]);
                            
                            if (extension.length() == 1) extension = "L0000"+extension;
                            else if (extension.length() == 2) extension = "L000"+extension;
                            else if (extension.length() == 3) extension = "L00"+extension;
                            else if (extension.length() == 4) extension = "L0"+extension;
                            else if (extension.length() == 5) extension = "L"+extension;
                            
                            extension2 = to_string(arrayLineageStartEndTemp [counter2*9+1]);
                            
                            if (arrayLineageStartEndTemp [counter2*9+1] >= 0){
                                if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                                else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                                else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                                else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                                else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                                else if (extension2.length() == 6) extension2 = "C000"+extension2;
                                else if (extension2.length() == 7) extension2 = "C00"+extension2;
                                else if (extension2.length() == 8) extension2 = "C0"+extension2;
                                else if (extension2.length() == 9) extension2 = "C"+extension2;
                            }
                            else{
                                
                                extension2 = extension2.substr(1);
                                
                                if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                                else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                                else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                                else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                                else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                                else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                                else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                                else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                                else if (extension2.length() == 9) extension2 = "C-"+extension2;
                            }
                            
                            if (arrayLineagePartnerInfoTemp [counter3*6] == extension && arrayLineagePartnerInfoTemp [counter3*6+1] == extension2){
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+1], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+2], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+3], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+4], lineagePartnerInfoTempCount2++;
                                arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter3*6+5], lineagePartnerInfoTempCount2++;
                                break;
                            }
                        }
                    }
                }
                
                lineagePartnerInfoCount = 0;
                
                for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) arrayLineagePartnerInfo [lineagePartnerInfoCount] = arrayLineagePartnerInfoTemp2 [counter1], lineagePartnerInfoCount++;
                
                if (lineagePartnerInfoTempCount2 != 0){
                    ofstream oin;
                    oin.open(cellFusionPartnerPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) oin<<arrayLineagePartnerInfoTemp2 [counter1]<<endl;
                    
                    oin.close();
                }
                else remove (cellFusionPartnerPath.c_str());
                
                delete [] arrayLineagePartnerInfoTemp;
                delete [] arrayLineagePartnerInfoTemp2;
            }
            
            //=======Mitosis Set array=======
            string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_MitosisData";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter2 = 0; counter2 < 6; counter2++){
                sizeForCopy = 0;
                
                if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter2 == 0) size1 = sizeForCopy;
                    else if (counter2 == 1) size2 = sizeForCopy;
                    else if (counter2 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter2 == 3) size1 = sizeForCopy;
                    else if (counter2 == 4) size2 = sizeForCopy;
                    else if (counter2 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                //********arrayMitosisStatus*********
                //1.Lineage No
                //2.Cell no
                //3.Image No
                //4.Status data (10: Mitosis, 1,2,6: Mitosis status, 3,4: cell death status)
                
                int *arrayMitosisTemp = new int [sizeForCopy+50];
                int mitosisTempCount = 0;
                int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                int mitosisTempCount2 = 0;
                
                fin.open(mitosisStatusPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    string lineageNoGet;
                    string cellNoGet;
                    string imageNoGet;
                    string setTypeGet;
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, lineageNoGet);
                        
                        if (lineageNoGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, setTypeGet);
                            
                            arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
                
                for (int counter1 = 0; counter1 < lineageStartEndTempCount/8; counter1++){
                    for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                        if (arrayLineageStartEndTemp [counter1*8] == arrayMitosisTemp [counter2*4] && arrayLineageStartEndTemp [counter1*8+1] == arrayMitosisTemp [counter2*4+1]){
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+1], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+2], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+3], mitosisTempCount2++;
                        }
                    }
                }
                
                if (mitosisTempCount2 != 0){
                    ofstream oin;
                    oin.open(mitosisStatusPath.c_str(), ios::out);
                    
                    if (oin.is_open()){
                        for (int counter2 = 0; counter2 < mitosisTempCount2; counter2++) oin<<arrayMitosisTemp2 [counter2]<<endl;
                        
                        oin.close();
                    }
                }
                else remove (mitosisStatusPath.c_str());
                
                delete [] arrayMitosisTemp;
                delete [] arrayMitosisTemp2;
            }
            
            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            [dataRepairReadWrite lineageDataSave];
            
            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            [dataRepairReadWrite lineageRelDataSet];
            
            delete [] lineageInfoList;
            delete [] arrayQueueListTemp;
            delete [] arrayQueueListTemp2;
            delete [] arrayDoneListTemp;
            delete [] arrayDoneListTemp2;
            
            delete [] warningList;
            delete [] lingList;
            delete [] arrayLineageRepairData2;
            delete [] arrayLineageStartEndTemp;
            delete [] arrayLineageStartEndTemp2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else returnValue = -1;
        
        delete [] arrayLineageRepairData;
    }
    else returnValue = -1;
    
    return returnValue;
}

@end
