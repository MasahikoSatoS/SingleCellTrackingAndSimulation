//
//  DicExpandAll.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 9/14/16.
//
//

#ifndef DICEXPANDALL_H
#define DICEXPANDALL_H
#import "Controller.h" 
#endif

@interface DicExpandAll : NSObject{
    id lineSet;
    id targetFind2;
    id fileUpdate;
}

-(id)init;
-(void)dealloc;

-(void)mergeExtend:(int)groupNoMerge :(int)maxNo;

@end
