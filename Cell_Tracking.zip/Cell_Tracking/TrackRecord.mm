//
// TrackRecord.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 03/11/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackRecord.h"

@implementation TrackRecord

-(int)trackDataSaveMain:(int)recordType{
    string errorPath = "/Users/"+pathNameString+"/Desktop/CLIA_Error";
    mkdir(errorPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    int returnResults = 0;
    forceSetAutoFlag = 0;
    
    string cellLineageExtract = cellLineageNoHold.substr(1);
    string cellNoExtract = cellNoHold.substr(1);
    int lineageAmendTemp = atoi(cellLineageExtract.c_str());
    int cellAmendTemp = atoi(cellNoExtract.c_str());
    
    //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
    //    cout<<" arrayLineageData "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    //-----Lineage Start-----
    int lineageEntryStart = 10000;
    int lineageEntryEnd = 0; //-----Image no-----
    int lineageStartPosition = 0;
    
    for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
        if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
            if (arrayLineageStartEnd [counter1*8+7] > lineageEntryEnd) lineageEntryEnd = arrayLineageStartEnd [counter1*8+7];
            
            if (arrayLineageStartEnd [counter1*8+5] < lineageEntryStart){
                lineageEntryStart = arrayLineageStartEnd [counter1*8+5];
                lineageStartPosition = arrayLineageStartEnd [counter1*8+4];
            }
        }
    }
    
    int initialEventType = arrayLineageData [lineageStartPosition*8+3];
    int initialParentNumber = arrayLineageData [lineageStartPosition*8+4];
    int lastEventType = arrayLineageData [lineageEntryEnd*8+3];
    
    //cout<<initialEventType<<" "<<initialParentNumber<<" "<<lastEventType<<" Event"<<endl;
    
    //-----Event Sequence Reorganize-----
    //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
    //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
    //-----DEND LineageEntry DEnd 32, TEnd, 42, HEnd 52-----
    
    //-----1. Image no, 2. Event type, 3. lineage no, 4. cell no-----
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    string connectRelationTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
    string entry;
    
    int minFileTime = 1000000;
    int maxFileTime = 0;
    
    DIR *dir = opendir(connectRelationTempPath.c_str());
    struct dirent *dent;
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                if ((int)entry.find("_ConnectLineageRelTemp") != -1){
                    if (atoi(entry.substr(0, entry.find("_ConnectLineageRelTemp")).c_str()) < minFileTime) minFileTime = atoi(entry.substr(0, entry.find("_ConnectLineageRelTemp")).c_str());
                    if (atoi(entry.substr(0, entry.find("_ConnectLineageRelTemp")).c_str()) > maxFileTime) maxFileTime = atoi(entry.substr(0, entry.find("_ConnectLineageRelTemp")).c_str());
                }
            }
        }
        
        closedir(dir);
    }
    
    int minDivFusionPoint = 1000000;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33 || arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44 || arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55 || arrayEventSequence [counter1*4+1] == 91 || arrayEventSequence [counter1*4+1] == 7 || arrayEventSequence [counter1*4+1] == 8)){
            minDivFusionPoint = arrayEventSequence [counter1*4];
        }
    }
    
    ifstream fin;
    
    string connectRelationPath;
    string extension;
    long sizeForCopy = 0;
    unsigned long readPosition = 0;
    
    int connectLineageRelSaveCount = 0;
    int stepCount = 0;
    int finData [19];
    int lineageFind = 0;
    int numberFind = 0;
    int eventBefore = 0;
    
    struct stat sizeOfFile;
    struct stat sizeOfFile2;
    
    for (int counter1 = minFileTime; counter1 <= maxFileTime; counter1++){
        extension = to_string(counter1);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        connectRelationTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
        
        sizeForCopy = 0;
        
        if (stat(connectRelationTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            int *arrayConnectLineageRelSaveTemp = new int [sizeForCopy+50];
            connectLineageRelSaveCount = 0;
            
            fin.open(connectRelationTempPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                readPosition = 0;
                stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                        finData [3] = uploadTemp [readPosition], readPosition++;
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                        else{
                            
                            arrayConnectLineageRelSaveTemp [connectLineageRelSaveCount] = finData [2], connectLineageRelSaveCount++;
                            arrayConnectLineageRelSaveTemp [connectLineageRelSaveCount] = finData [5], connectLineageRelSaveCount++;
                            arrayConnectLineageRelSaveTemp [connectLineageRelSaveCount] = finData [7], connectLineageRelSaveCount++;
                            arrayConnectLineageRelSaveTemp [connectLineageRelSaveCount] = finData [12], connectLineageRelSaveCount++;
                            arrayConnectLineageRelSaveTemp [connectLineageRelSaveCount] = finData [13], connectLineageRelSaveCount++;
                            arrayConnectLineageRelSaveTemp [connectLineageRelSaveCount] = finData [14], connectLineageRelSaveCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
                
                lineageFind = 0;
                
                for (int counter2 = 0; counter2 < connectLineageRelSaveCount/6; counter2++){
                    if (arrayConnectLineageRelSaveTemp [counter2*6] == lineageAmendTemp && arrayConnectLineageRelSaveTemp [counter2*6+3] == cellAmendTemp){
                        lineageFind = 1;
                        break;
                    }
                }
                
                if (lineageFind == 0){
                    for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                        if (arrayEventSequence [counter2*4] == counter1){
                            arrayEventSequence [counter2*4] = 0;
                            break;
                        }
                    }
                }
                else if (lineageFind == 1){
                    numberFind = 0;
                    
                    for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                        if (arrayEventSequence [counter2*4] == counter1){
                            numberFind = 1;
                            break;
                        }
                    }
                    
                    if (numberFind == 0){
                        eventBefore = 0;
                        
                        for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                            if (arrayEventSequence [counter2*4] < counter1 && (arrayEventSequence [counter2*4+1] == 1 || arrayEventSequence [counter2*4+1] == 31 || arrayEventSequence [counter2*4+1] == 41 || arrayEventSequence [counter2*4+1] == 51)){
                                eventBefore = 1;
                            }
                        }
                        
                        if (eventBefore == 1 && (minDivFusionPoint == 1000000 || minDivFusionPoint > counter1)){
                            if (eventSequenceCount+4 > eventSequenceLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate eventSequenceUpDate];
                            }
                            
                            arrayEventSequence [eventSequenceCount] = counter1, eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = lineageAmendTemp, eventSequenceCount++;
                            arrayEventSequence [eventSequenceCount] = cellAmendTemp, eventSequenceCount++;
                        }
                    }
                }
            }
            else{
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.close();
                }
                else{
                    
                    for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
                        if (arrayEventSequence [counter2*4] == counter1){
                            arrayEventSequence [counter2*4] = 0;
                            break;
                        }
                    }
                }
            }
            
            delete [] arrayConnectLineageRelSaveTemp;
        }
    }
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    int divisionCompleteCheckBD = 0;
    int divisionCompleteCheckTD = 0;
    int divisionCompleteCheckHD = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 32) divisionCompleteCheckBD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 33) divisionCompleteCheckBD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 42) divisionCompleteCheckTD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 43) divisionCompleteCheckTD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 44) divisionCompleteCheckTD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 52) divisionCompleteCheckHD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 53) divisionCompleteCheckHD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 54) divisionCompleteCheckHD++;
        if (cellAmendTemp != arrayEventSequence [counter1*4+3] && arrayEventSequence [counter1*4+1] == 55) divisionCompleteCheckHD++;
    }
    
    if (divisionCompleteCheckBD != 0 && divisionCompleteCheckBD != 2){
        int divisionTime = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33){
                divisionTime = arrayEventSequence [counter1*4];
                break;
            }
        }
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (divisionTime <= arrayEventSequence [counter1*4]) arrayEventSequence [counter1*4] = 0;
        }
    }
    else if (divisionCompleteCheckTD != 0 && divisionCompleteCheckTD != 3){
        int divisionTime = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44){
                divisionTime = arrayEventSequence [counter1*4];
                break;
            }
        }
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (divisionTime <= arrayEventSequence [counter1*4]) arrayEventSequence [counter1*4] = 0;
        }
    }
    else if (divisionCompleteCheckHD != 0 && divisionCompleteCheckHD != 4){
        int divisionTime = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55){
                divisionTime = arrayEventSequence [counter1*4];
                break;
            }
        }
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (divisionTime <= arrayEventSequence [counter1*4]) arrayEventSequence [counter1*4] = 0;
        }
    }
    
    if (divisionCompleteCheckBD == 2 || divisionCompleteCheckTD == 3 || divisionCompleteCheckHD == 4){
        int divisionTime = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 52){
                divisionTime = arrayEventSequence [counter1*4];
                break;
            }
        }
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (divisionTime < arrayEventSequence [counter1*4]) arrayEventSequence [counter1*4] = 0;
        }
    }
    
    int fusionCheck = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4+1] == 91){
            fusionCheck = arrayEventSequence [counter1*4];
            break;
        }
    }
    
    if (fusionCheck != 0){
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (fusionCheck < arrayEventSequence [counter1*4]) arrayEventSequence [counter1*4] = 0;
        }
    }
    
    int eventEntryMin = 10000;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] != 0 && eventEntryMin > arrayEventSequence [counter1*4]) eventEntryMin = arrayEventSequence [counter1*4];
    }
    
    int eventEntryLimit = eventEntryMin;
    int entryFind = 0;
    
    for (int counter1 = eventEntryMin; counter1 < eventEntryMin+eventSequenceCount/4; counter1++){
        entryFind = 0;
        
        for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
            if (eventEntryLimit == arrayEventSequence [counter2*4]){
                eventEntryLimit++;
                entryFind = 1;
                break;
            }
        }
        
        if (entryFind == 0){
            eventEntryLimit--;
            break;
        }
    }
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (eventEntryLimit < arrayEventSequence [counter1*4]) arrayEventSequence [counter1*4] = 0;
    }
    
    int eventEntryMax = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (eventEntryMax < arrayEventSequence [counter1*4]) eventEntryMax = arrayEventSequence [counter1*4];
    }
    
    int *arrayEventSequenceReorganize = new int [eventSequenceCount*2+1];
    int eventSequenceReorganizeCount = 0;
    for (int counter1 = 0; counter1 < eventSequenceCount*2; counter1++) arrayEventSequenceReorganize [counter1] = 0;
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    int newUpperLimit = 0;
    
    for (int counter1 = lineageEntryStart; counter1 <= eventEntryMax; counter1++){
        for (int counter2 = 0; counter2 < eventSequenceCount/4; counter2++){
            if (arrayEventSequence [counter2*4] == counter1){
                arrayEventSequenceReorganize [eventSequenceReorganizeCount] = arrayEventSequence [counter2*4], eventSequenceReorganizeCount++;
                arrayEventSequenceReorganize [eventSequenceReorganizeCount] = arrayEventSequence [counter2*4+1], eventSequenceReorganizeCount++;
                arrayEventSequenceReorganize [eventSequenceReorganizeCount] = arrayEventSequence [counter2*4+2], eventSequenceReorganizeCount++;
                arrayEventSequenceReorganize [eventSequenceReorganizeCount] = arrayEventSequence [counter2*4+3], eventSequenceReorganizeCount++;
            }
            if (newUpperLimit == 0 && arrayEventSequence [counter2*4] == counter1 && (arrayEventSequence [counter2*4+1] == 32 || arrayEventSequence [counter2*4+1] == 33 || arrayEventSequence [counter2*4+1] == 42 || arrayEventSequence [counter2*4+1] == 43 || arrayEventSequence [counter2*4+1] == 44 || arrayEventSequence [counter2*4+1] == 52 || arrayEventSequence [counter2*4+1] == 53 || arrayEventSequence [counter2*4+1] == 54 || arrayEventSequence [counter2*4+1] == 55)){
                newUpperLimit = counter1;
            }
            if (newUpperLimit == 0 && arrayEventSequence [counter2*4] == counter1 && (arrayEventSequence [counter2*4+1] == 7 || arrayEventSequence [counter2*4+1] == 8 || arrayEventSequence [counter2*4+1] == 91)){
                newUpperLimit = counter1;
            }
        }
    }
    
    //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
    //    cout<<" arrayEventSequenceReorganize "<<counterA<<endl;
    //}
    
    string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
    string checkFilePath = "";
    string checkFilePathD = "";
    string getString;
    
    int smallestTimeGC = 0;
    int gravityCenterBothZero = 0;
    int gravityCenterXTemp = 0;
    int gravityCenterYTemp = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
        if (arrayEventSequenceReorganize [counter1*4] > 0){
            extension = to_string(arrayEventSequenceReorganize [counter1*4]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            checkFilePath = connectDataTempPath+"/"+extension+"_GCCenterInfo";
            checkFilePathD = connectDataTempPath+"/"+extension+"_GCCenterInfoD";
            
            if (stat(checkFilePath.c_str(), &sizeOfFile) == 0 || stat(checkFilePathD.c_str(), &sizeOfFile2) == 0){
                smallestTimeGC = arrayEventSequenceReorganize [counter1*4];
                
                if (stat(checkFilePath.c_str(), &sizeOfFile) == 0){
                    fin.open(checkFilePath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        getline(fin, getString), gravityCenterXTemp = atoi(getString.c_str());
                        getline(fin, getString), gravityCenterYTemp = atoi(getString.c_str());
                        
                        fin.close();
                        
                        if (gravityCenterXTemp == 0 && gravityCenterYTemp == 0) gravityCenterBothZero = 1;
                    }
                }
            }
            else{
                
                break;
            }
        }
    }
    
    if (smallestTimeGC != 0 && smallestTimeGC < newUpperLimit){
        int newLimitCount = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
            if (arrayEventSequenceReorganize [counter1*4] <= smallestTimeGC){
                newLimitCount = newLimitCount+4;
            }
        }
        
        if (smallestTimeGC < newUpperLimit-1){
            divisionTypeHold = 0;
            fusionOperation = 0;
            
            int fusionFindFlag = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                if (arrayEventSequenceReorganize [counter1*4] == smallestTimeGC && arrayEventSequenceReorganize [counter1*4+1] == 91){
                    fusionFindFlag = 1;
                    break;
                }
            }
            
            if (fusionFindFlag == 0){
                eventSequenceReorganizeCount = newLimitCount;
                newUpperLimit = smallestTimeGC;
            }
            else{
                
                eventSequenceReorganizeCount = newLimitCount-4;
                newUpperLimit = smallestTimeGC-1;
            }
        }
    }
    
    if (newUpperLimit == 0) newUpperLimit = eventEntryMax;
    
    int fusionFindInEvent = 0;
    int divisionFindInEvent = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
        if (arrayEventSequenceReorganize [counter1*4+1] == 91){
            fusionFindInEvent = 1;
        }
        
        if (arrayEventSequenceReorganize [counter1*4+1] == 32 || arrayEventSequenceReorganize [counter1*4+1] == 42 || arrayEventSequenceReorganize [counter1*4+1] == 52){
            divisionFindInEvent = 1;
        }
    }
    
    if (divisionFindInEvent == 0 && divisionTypeHold != 0){
        divisionTypeHold = 0;
    }
    
    //cout<<fusionFindInEvent<<" "<<newUpperLimit<<" "<<fusionOperation<<" fusion"<<endl;
    
    if (fusionFindInEvent == 0 && fusionOperation != 0){
        fusionOperation = 0;
    }
    
    //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
    //    cout<<" arrayEventSequenceReorganize "<<counterA<<endl;
    //}
    
    int fusionNoCorrect = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
        if (arrayEventSequenceReorganize [counter1*4+1] == 91 || arrayEventSequenceReorganize [counter1*4+1] == 92){
            extension = to_string(arrayEventSequenceReorganize [counter1*4]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            checkFilePathD = connectDataTempPath+"/"+extension+"_MasterDataTempD";
            
            if (stat(checkFilePathD.c_str(), &sizeOfFile) == 0){
                fusionNoCorrect = 0;
                
                for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                    if (arrayLineageStartEnd [counter2*8] == lineageAmendTemp && arrayLineageStartEnd [counter2*8+1] == cellAmendTemp){
                        for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                            if (arrayLineageData [counter3*8+7] != 0) fusionNoCorrect = arrayLineageData [counter3*8+7];
                        }
                    }
                }
                
                if (arrayEventSequenceReorganize [counter1*4+1] == arrayEventSequenceReorganize [counter1*4+2] && fusionNoCorrect != 0) arrayEventSequenceReorganize [counter1*4+2] = fusionNoCorrect;
            }
        }
    }
    
    //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
    //    cout<<" arrayEventSequenceReorganize "<<counterA<<endl;
    //}
    
    int upperLimitEventImageNo = 0;
    int upperLimitEventType = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
        if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
            upperLimitEventType = arrayEventSequenceReorganize [counter1*4+1];
            upperLimitEventImageNo = arrayEventSequenceReorganize [counter1*4];
            break;
        }
    }
    
    //cout<<newUpperLimit<<" "<<upperLimitEventType<<" UpLimit_Type"<<endl;
    
    string connectTrackPath = "";
    int gapFind = 0;
    int gapPosition = 0;
    int saveFlag = 0;
    
    //cout<<firstModificationPoint<<" "<<trackingUpperLimit<<" First_UpLimit"<<endl;
    
    for (int counter1 = firstModificationPoint; counter1 <= trackingUpperLimit; counter1++){
        extension = to_string(counter1);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        checkFilePath = connectDataTempPath+"/"+extension+"_MasterDataTemp";
        checkFilePathD = connectDataTempPath+"/"+extension+"_MasterDataTempD";
        
        if (stat(checkFilePath.c_str(), &sizeOfFile) == -1 && stat(checkFilePathD.c_str(), &sizeOfFile2) == -1 && gapFind == 0){
            gapFind = 1;
            gapPosition = counter1;
        }
        else if ((stat(checkFilePath.c_str(), &sizeOfFile) == 0 || stat(checkFilePathD.c_str(), &sizeOfFile2) == 0) && gapFind == 1){
            break;
        }
        
        if (counter1 == trackingUpperLimit && gapFind == 0) gapPosition = counter1+1;
    }
    
    if (gapPosition > upperLimitMap) gapPosition = upperLimitMap;
    else gapPosition--;
    
    //cout<<gapPosition<<" "<<newUpperLimit<<" "<<imageNumberTrackForDisplay<<" "<<lineModificationFlag<<" "<<divisionTypeHold<<" "<<fusionOperation<<" "<<lineModificationFlag<<" ModInfo"<<endl;
    
    int saveResultsReturn = 0;
    
    //-----Upper Limit readjust and Save Temp data if it has not been done-----
    if ((gapPosition+1 == newUpperLimit && imageNumberTrackForDisplay == newUpperLimit) || lineModificationFlag == 1){
        if (divisionTypeHold != 0){
            int divSetCount = 0;
            int trackSave = 0;
            
            string connectDivString1 = "";
            string connectDivString2 = "";
            string connectDivString3 = "";
            string connectDivString4 = "";
            
            int connectDivInt1 = 0;
            int connectDivInt2 = 0;
            int connectDivInt3 = 0;
            int connectDivInt4 = 0;
            
            if (divisionTypeHold >= 2){
                connectDivString1 = cellNoHoldDiv1.substr(1);
                connectDivString2 = cellNoHoldDiv2.substr(1);
                connectDivInt1 = atoi(connectDivString1.c_str());
                connectDivInt2 = atoi(connectDivString2.c_str());
            }
            
            if (divisionTypeHold >= 3){
                connectDivString3 = cellNoHoldDiv3.substr(1);
                connectDivInt3 = atoi(connectDivString3.c_str());
            }
            
            if (divisionTypeHold == 4){
                connectDivString4 = cellNoHoldDiv4.substr(1);
                connectDivInt4 = atoi(connectDivString4.c_str());
            }
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                if (divisionTypeHold >= 2 && arrayEventSequenceReorganize [counter1*4+3] == connectDivInt1) divSetCount++;
                if (divisionTypeHold >= 2 && arrayEventSequenceReorganize [counter1*4+3] == connectDivInt2) divSetCount++;
                if (divisionTypeHold >= 3 && arrayEventSequenceReorganize [counter1*4+3] == connectDivInt3) divSetCount++;
                if (divisionTypeHold == 4 && arrayEventSequenceReorganize [counter1*4+3] == connectDivInt4) divSetCount++;
            }
            
            if (divisionTypeHold == 2 && divSetCount == 2) trackSave = 1;
            if (divisionTypeHold == 3 && divSetCount == 3) trackSave = 1;
            if (divisionTypeHold == 4 && divSetCount == 4) trackSave = 1;
            
            if (trackSave == 1){
                int fluorescentCurrentStatus = 0;
                
                if (fluorescentDetectionDisplay == 1) fluorescentCurrentStatus = 1;
                
                saveFlag = 1;
                int saveTypeDef = 2;
                int gravityCenterCheckMode = 1;
                trackingDataSave = [[TrackingDataSave alloc] init];
                saveResultsReturn = [trackingDataSave trackingDataSaveTemp:saveTypeDef:fluorescentCurrentStatus:gravityCenterCheckMode];
            }
        }
        else if (fusionOperation == 1){
            fusionMarkImage = 10000;
            saveFlag = 1;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8+5] <= imageNumberTrackForDisplay-1){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        if (arrayLineageData [counter2*8+2] >= imageNumberTrackForDisplay-1 && arrayLineageData [counter2*8+2] <= imageNumberTrackForDisplay+10){
                            if (arrayLineageData [counter2*8+3] == 10 && arrayLineageData [counter2*8+5] == fusionPartnerCellNo && arrayLineageData [counter2*8+6] == fusionPartnerLin){
                                if (fusionMarkImage > arrayLineageData [counter2*8+2]){
                                    fusionMarkImage = arrayLineageData [counter2*8+2];
                                    break;
                                }
                            }
                        }
                    }
                }
            }
            
            int fluorescentCurrentStatus = 0;
            
            if (fluorescentDetectionDisplay == 1) fluorescentCurrentStatus = 1;
            
            int saveTypeDef = 2;
            int gravityCenterCheckMode = 1;
            trackingDataSave = [[TrackingDataSave alloc] init];
            saveResultsReturn = [trackingDataSave trackingDataSaveTemp:saveTypeDef:fluorescentCurrentStatus:gravityCenterCheckMode];
        }
        else if (lineModificationFlag == 1){
            int fluorescentCurrentStatus = 0;
            
            if (fluorescentDetectionDisplay == 1) fluorescentCurrentStatus = 1;
            
            saveFlag = 1;
            int saveTypeDef = 2;
            int gravityCenterCheckMode = 1;
            trackingDataSave = [[TrackingDataSave alloc] init];
            saveResultsReturn = [trackingDataSave trackingDataSaveTemp:saveTypeDef:fluorescentCurrentStatus:gravityCenterCheckMode];
        }
    }
    else if (gapPosition < newUpperLimit){
        newUpperLimit = gapPosition;
        
        int *eventSequenceTemp = new int [eventSequenceReorganizeCount+10];
        int eventSequenceTempCount = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
            if (arrayEventSequenceReorganize [counter1*4] <= newUpperLimit){
                eventSequenceTemp [eventSequenceTempCount] = arrayEventSequenceReorganize [counter1*4], eventSequenceTempCount++;
                eventSequenceTemp [eventSequenceTempCount] = arrayEventSequenceReorganize [counter1*4+1], eventSequenceTempCount++;
                eventSequenceTemp [eventSequenceTempCount] = arrayEventSequenceReorganize [counter1*4+2], eventSequenceTempCount++;
                eventSequenceTemp [eventSequenceTempCount] = arrayEventSequenceReorganize [counter1*4+3], eventSequenceTempCount++;
            }
        }
        
        eventSequenceReorganizeCount = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceTempCount; counter1++) arrayEventSequenceReorganize [eventSequenceReorganizeCount] = eventSequenceTemp [counter1], eventSequenceReorganizeCount++;
        
        delete [] eventSequenceTemp;
        
        upperLimitEventImageNo = 0;
        upperLimitEventType = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
            if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                upperLimitEventType = arrayEventSequenceReorganize [counter1*4+1];
                upperLimitEventImageNo = arrayEventSequenceReorganize [counter1*4];
                break;
            }
        }
        
        saveFlag = 1;
    }
    else if (gapPosition == newUpperLimit) saveFlag = 1;
    
    if (saveResultsReturn == 0 && gravityCenterBothZero == 0){
        if (recordType == 1){
            if (upperLimitEventImageNo != lineageEntryEnd && (lastEventType == 31 || lastEventType == 41 || lastEventType == 51 || lastEventType == 91 || lastEventType == 8 || lastEventType == 7)) saveFlag = 0;
        }
        
        //==========Process 1, check Lineage structure, if end is BD etc and gap is before STOP, CD, OF, FU.
        //Mitosis ===== allow to type more than one, =====Remove earlier one ==== For auto as well =====
        //======Lost even line set, cannot set======
        
        //cout<<saveFlag<<" "<<newUpperLimit<<" SaveFlag_UpLimit"<<endl;
        
        int warningType2 = 0;
        
        if (saveFlag == 1){
            //-----Extract relevant lineage data-----
            arrayLineageExtraction = new int [10000];
            lineageExtractionCount = 0;
            lineageExtractionLimit = 10000;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                        if (lineageExtractionCount+8 > lineageExtractionLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate lineageExtractionUpDate];
                        }
                        
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+1], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+2], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+3], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+4], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+5], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+6], lineageExtractionCount++;
                        arrayLineageExtraction [lineageExtractionCount] = arrayLineageData [counter2*8+7], lineageExtractionCount++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
            //    cout<<" arrayLineageExtraction "<<counterA<<endl;
            //}
            
            //-----1. Image no, 2. Event type, 3. lineage no, 4. cell no-----
            string extension3;
            string connectDataTempPathA;
            string connectDataTempPathB;
            string connectDataTempPathD;
            
            int imagePositionData = 0;
            int eventTypeData = 0;
            int newTypeFind = 0;
            
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                if (arrayLineageExtraction [counter1*8+5] == cellAmendTemp){
                    imagePositionData = arrayLineageExtraction [counter1*8+2];
                    eventTypeData = arrayLineageExtraction [counter1*8+3];
                    newTypeFind = 0;
                    
                    for (int counter2 = 0; counter2 < eventSequenceReorganizeCount/4; counter2++){
                        if (imagePositionData == arrayEventSequenceReorganize [counter2*4] && eventTypeData != arrayEventSequenceReorganize [counter2*4+1]){
                            newTypeFind = 1;
                            break;
                        }
                    }
                    
                    if (newTypeFind == 1){
                        extension3 = to_string(imagePositionData);
                        
                        if (extension3.length() == 1) extension3 = "000"+extension3;
                        else if (extension3.length() == 2) extension3 = "00"+extension3;
                        else if (extension3.length() == 3) extension3 = "0"+extension3;
                        
                        connectDataTempPathA = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_MasterDataTemp";
                        
                        if (stat(connectDataTempPathA.c_str(), &sizeOfFile) == -1){
                            connectDataTempPathB = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_MasterDataTempD";
                            remove(connectDataTempPathB.c_str());
                            
                            connectDataTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension3+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter2 = 0; counter2 < 6; counter2++){
                                sizeForCopy = 0;
                                
                                if (stat(connectDataTempPathD.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter1 == 0) size1 = sizeForCopy;
                                    else if (counter1 == 1) size2 = sizeForCopy;
                                    else if (counter1 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter1 == 3) size1 = sizeForCopy;
                                    else if (counter1 == 4) size2 = sizeForCopy;
                                    else if (counter1 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (checkFlag == 1){
                                ifstream infile (connectDataTempPathD.c_str(), ifstream::binary);
                                ofstream outfile (connectDataTempPathA.c_str(), ofstream::binary);
                                
                                if (infile.is_open() && outfile.is_open()){
                                    char* buffer = new char[sizeForCopy];
                                    infile.read (buffer, sizeForCopy);
                                    outfile.write (buffer, sizeForCopy);
                                    delete[] buffer;
                                    
                                    outfile.close();
                                    infile.close();
                                }
                                else{
                                    
                                    usleep (5000);
                                    
                                    ifstream infile2 (connectDataTempPathD.c_str(), ifstream::binary);
                                    ofstream outfile2 (connectDataTempPathA.c_str(), ofstream::binary);
                                    
                                    if (infile2.is_open() && outfile2.is_open()){
                                        char* buffer = new char[sizeForCopy];
                                        infile2.read (buffer, sizeForCopy);
                                        outfile2.write (buffer, sizeForCopy);
                                        delete[] buffer;
                                        
                                        outfile2.close();
                                        infile2.close();
                                        
                                    }
                                }
                            }
                            
                            connectDataTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension3+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                            connectDataTempPathA = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_StatusTemp";
                            connectDataTempPathB = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_StatusTempD";
                            
                            remove(connectDataTempPathB.c_str());
                            
                            if (stat(connectDataTempPathD.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (connectDataTempPathD.c_str(), ifstream::binary);
                                ofstream outfile (connectDataTempPathA.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                            
                            connectDataTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension3+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                            connectDataTempPathA = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_ConnectLineageRelTemp";
                            connectDataTempPathB = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_ConnectLineageRelTempD";
                            
                            remove(connectDataTempPathB.c_str());
                            
                            if (stat(connectDataTempPathD.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (connectDataTempPathD.c_str(), ifstream::binary);
                                ofstream outfile (connectDataTempPathA.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                            
                            connectDataTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                            connectDataTempPathA = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_RevisedTempMap";
                            connectDataTempPathB = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_RevisedTempMapD";
                            
                            remove(connectDataTempPathB.c_str());
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectDataTempPathD.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (connectDataTempPathD.c_str(), ifstream::binary);
                                ofstream outfile (connectDataTempPathA.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                            
                            connectDataTempPathA = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_GCCenterInfo";
                            connectDataTempPathB = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension3+"_GCCenterInfoD";
                            
                            remove(connectDataTempPathB.c_str());
                            
                            ofstream oin;
                            oin.open(connectDataTempPathA.c_str(), ios::out);
                            oin<<gravityCenterXHold1<<endl;
                            oin<<gravityCenterYHold1<<endl;
                            oin<<gravityAverageHold1<<endl;
                            oin<<gravityCellNo1<<endl;
                            oin<<gravityCenterXHold2<<endl;
                            oin<<gravityCenterYHold2<<endl;
                            oin<<gravityAverageHold2<<endl;
                            oin<<gravityCellNo2<<endl;
                            oin<<gravityCenterXHold3<<endl;
                            oin<<gravityCenterYHold3<<endl;
                            oin<<gravityAverageHold3<<endl;
                            oin<<gravityCellNo3<<endl;
                            oin<<gravityCenterXHold4<<endl;
                            oin<<gravityCenterYHold4<<endl;
                            oin<<gravityAverageHold4<<endl;
                            oin<<gravityCellNo4<<endl;
                            oin.close();
                        }
                    }
                }
            }
            
            //-----Mitosis number check. If there is IP, mitosis number should be after IP-----
            int mitosisNumberCheck = 0;
            int lastMitosisPosition = 0;
            int abortFlag = 0;
            int processTypeCell = 0;
            int checkStart = 0;
            int checkEnd = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                if (arrayEventSequenceReorganize [counter1*4+1] == 11){
                    if (checkEnd == 0){
                        checkStart = 0;
                        checkEnd = counter1;
                    }
                    else if (checkEnd > 0){
                        checkStart = checkEnd+1;
                        checkEnd = counter1;
                    }
                    
                    mitosisNumberCheck = 0;
                    
                    for (int counter2 = checkStart; counter2 <= counter1; counter2++){
                        if (arrayEventSequenceReorganize [counter2*4+1] == 6) mitosisNumberCheck++;
                    }
                    
                    if (mitosisNumberCheck >= 1){
                        abortFlag = 1;
                        warningType2 = 1;
                        break;
                    }
                    else mitosisNumberCheck = 0;
                }
                
                if (arrayEventSequenceReorganize [counter1*4+1] == 6){
                    mitosisNumberCheck++;
                    lastMitosisPosition = arrayEventSequenceReorganize [counter1*4];
                }
            }
            
            if (mitosisNumberCheck > 1 && abortFlag == 0){
                for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                    if (arrayEventSequenceReorganize [counter1*4+1] == 6 && arrayEventSequenceReorganize [counter1*4] != lastMitosisPosition){
                        arrayEventSequenceReorganize [counter1*4+1] = 2;
                    }
                }
            }
            
            if (abortFlag == 0 && upperLimitEventImageNo >= lineageEntryStart){
                //-----Mitosis Event relation check-----
                if (upperLimitEventType == 2){
                    processTypeCell = 1; //-----Track entry-----
                }
                else if (upperLimitEventType == 32 || upperLimitEventType == 33 || upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44 || upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55){
                    if (mitosisNumberCheck == 0){
                        abortFlag = 1;
                        warningType2 = 2;
                    }
                    else processTypeCell = 2; //-----Done and progeny entry-----
                }
                else if (upperLimitEventType == 6 || upperLimitEventType == 10 || upperLimitEventType == 11){
                    processTypeCell = 1; //-----Track entry-----
                }
                else if (upperLimitEventType == 7 || upperLimitEventType == 8 || upperLimitEventType == 91){
                    processTypeCell = 3; //-----Done-----
                }
                else if (upperLimitEventType == 1 || upperLimitEventType == 31 || upperLimitEventType == 41 || upperLimitEventType == 51) processTypeCell = 1;
                
                if (processTypeCell == 2){
                    int divisionFindFlag = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                        if (arrayEventSequenceReorganize [counter1*4+1] == 33) divisionFindFlag = 2;
                        if (arrayEventSequenceReorganize [counter1*4+1] == 43) divisionFindFlag = 2;
                        if (arrayEventSequenceReorganize [counter1*4+1] == 44) divisionFindFlag = 2;
                        if (arrayEventSequenceReorganize [counter1*4+1] == 53) divisionFindFlag = 2;
                        if (arrayEventSequenceReorganize [counter1*4+1] == 54) divisionFindFlag = 2;
                    }
                    
                    if (divisionFindFlag == 0) processTypeCell = 3;
                }
                
                if (abortFlag == 0){
                    //-----Cell lineage Construction-----
                    int *cellLineageCellExtract = new int [imageEndHold*8+50];
                    for (int counter1 = 0; counter1 < imageEndHold*8+50; counter1++) cellLineageCellExtract [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                        //-----Extract information of target cell-----
                        
                        if (arrayLineageExtraction [counter1*8+5] == cellAmendTemp){
                            imagePositionData = arrayLineageExtraction [counter1*8+2];
                            
                            cellLineageCellExtract [imagePositionData*8] = arrayLineageExtraction [counter1*8];
                            cellLineageCellExtract [imagePositionData*8+1] = arrayLineageExtraction [counter1*8+1];
                            cellLineageCellExtract [imagePositionData*8+2] = arrayLineageExtraction [counter1*8+2];
                            cellLineageCellExtract [imagePositionData*8+3] = arrayLineageExtraction [counter1*8+3];
                            cellLineageCellExtract [imagePositionData*8+4] = arrayLineageExtraction [counter1*8+4];
                            cellLineageCellExtract [imagePositionData*8+5] = arrayLineageExtraction [counter1*8+5];
                            cellLineageCellExtract [imagePositionData*8+6] = arrayLineageExtraction [counter1*8+6];
                            cellLineageCellExtract [imagePositionData*8+7] = arrayLineageExtraction [counter1*8+7];
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= timeEndHold; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellLineageCellExtract [counterA*8+counterB];
                    //    cout<<" cellLineageCellExtract "<<counterA<<endl;
                    //}
                    
                    int removeStart = 100000;
                    int timeTemp = 0;
                    int timeMatchFlag = 0;
                    
                    for (int counter1 = 1; counter1 <= imageEndHold; counter1++){
                        timeTemp = cellLineageCellExtract [counter1*8+2];
                        timeMatchFlag = 0;
                        
                        if (timeTemp != 0){
                            for (int counter2 = 0; counter2 < eventSequenceReorganizeCount/4; counter2++){
                                if (arrayEventSequenceReorganize [counter2*4] == timeTemp) timeMatchFlag = 1;
                            }
                            
                            if (timeMatchFlag == 0){
                                cellLineageCellExtract [counter1*8] = 0;
                                cellLineageCellExtract [counter1*8+1] = 0;
                                cellLineageCellExtract [counter1*8+2] = 0;
                                cellLineageCellExtract [counter1*8+3] = 0;
                                cellLineageCellExtract [counter1*8+4] = 0;
                                cellLineageCellExtract [counter1*8+5] = 0;
                                cellLineageCellExtract [counter1*8+6] = 0;
                                cellLineageCellExtract [counter1*8+7] = 0;
                                
                                if (removeStart > counter1) removeStart = counter1;
                            }
                        }
                    }
                    
                    // for (int counterA = 1; counterA <= newUpperLimit; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellLineageCellExtract [counterA*8+counterB];
                    //	cout<<" cellLineageCellExtract "<<counterA<<endl;
                    //}
                    
                    int deleteStatusCheck = 1;
                    
                    if (removeStart != 100000){
                        int deleteCellNo = cellAmendTemp;
                        int processType = 3;
                        
                        addDelete = [[AddDelete alloc] init];
                        deleteStatusCheck = [addDelete delLineageMain:lineageAmendTemp:processType:deleteCellNo:removeStart];
                        
                        if (deleteStatusCheck == 0){
                            usleep (50000);
                            
                            addDelete = [[AddDelete alloc] init];
                            deleteStatusCheck = [addDelete delLineageMain:lineageAmendTemp:processType:deleteCellNo:removeStart];
                            
                            if (deleteStatusCheck == 0){
                                usleep (50000);
                                
                                addDelete = [[AddDelete alloc] init];
                                deleteStatusCheck = [addDelete delLineageMain:lineageAmendTemp:processType:deleteCellNo:removeStart];
                            }
                        }
                    }
                    
                    if (deleteStatusCheck == 1){
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //	cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 1; counterA <= timeEndHold; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellLineageCellExtract [counterA*8+counterB];
                        //    cout<<" cellLineageCellExtract "<<counterA<<endl;
                        //}
                        
                        //-----1. X position, 2. Y position, 3. Time point, 4. Event Type, 5. Next Cell number, Fusion: hold cell number of Fusion partner-----
                        //-----6. Cell Number, 7. Cell Lineage Number, 8. For Fusion, Cell lineage Number-----
                        
                        int mitosisImageNo = 0;
                        int mitosisLineageNo = 0;
                        int mitosisCellNo = 0;
                        
                        int *arrayNewCellTemp = new int [50];
                        int newCellTempCount = 0;
                        
                        //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
                        //    cout<<" eventSequenceReorganize "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
                        //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                        // 	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                        //	cout<<" arrayLineageExtraction "<<counterA<<endl;
                        //}
                        
                        string extension2;
                        string connectStatusTempPath;
                        string connectGravityCenterPath;
                        
                        int newUpperLimitAdjust = 0;
                        int newCellNumber = 0;
                        int endNoChange = 0;
                        int xPositionEntry = 0;
                        int yPositionEntry = 0;
                        int fusionMarkImageTemp = 0;
                        int averageValue = 0;
                        int processType = 0;
                        int xPositionSave = 0;
                        int yPositionSave = 0;
                        int averageSave = 0;
                        int gravityCenterXHoldTemp1 = 0;
                        int gravityCenterYHoldTemp1 = 0;
                        int gravityAverageHoldTemp1 = 0;
                        int gravityCellNoTemp1 = 0;
                        int gravityCenterXHoldTemp2 = 0;
                        int gravityCenterYHoldTemp2 = 0;
                        int gravityAverageHoldTemp2 = 0;
                        int gravityCellNoTemp2 = 0;
                        int gravityCenterXHoldTemp3 = 0;
                        int gravityCenterYHoldTemp3 = 0;
                        int gravityAverageHoldTemp3 = 0;
                        int gravityCellNoTemp3 = 0;
                        int gravityCenterXHoldTemp4 = 0;
                        int gravityCenterYHoldTemp4 = 0;
                        int gravityAverageHoldTemp4 = 0;
                        int gravityCellNoTemp4 = 0;
                        int fusionCellTemp = 0;
                        int fusionLingTemp = 0;
                        
                        double mitosisSDSave = 0;
                        
                        //cout<<upperLimitEventType<<" "<<firstModificationPoint<<" "<<newUpperLimit<<" Limit"<<endl;
                        
                        for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                            if (arrayEventSequenceReorganize [counter1*4] >= firstModificationPoint && arrayEventSequenceReorganize [counter1*4] <= newUpperLimit){
                                upperLimitEventType = arrayEventSequenceReorganize [counter1*4+1];
                                newCellNumber = arrayEventSequenceReorganize [counter1*4+3];
                                imagePositionData = arrayEventSequenceReorganize [counter1*4];
                                endNoChange = 0;
                                
                                arrayTimePointSaveList [imagePositionData] = 1;
                                
                                extension2 = to_string(arrayEventSequenceReorganize [counter1*4]);
                                
                                if (extension2.length() == 1) extension2 = "000"+extension2;
                                else if (extension2.length() == 2) extension2 = "00"+extension2;
                                else if (extension2.length() == 3) extension2 = "0"+extension2;
                                
                                if (cellAmendTemp == newCellNumber && (upperLimitEventType == 32 || upperLimitEventType == 42 || upperLimitEventType == 52)) endNoChange = 1;
                                
                                connectGravityCenterPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension2+"_GCCenterInfo";
                                
                                xPositionSave = -1;
                                yPositionSave = -1;
                                
                                fin.open(connectGravityCenterPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    getline(fin, getString), gravityCenterXHoldTemp1 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterYHoldTemp1 = atoi(getString.c_str());
                                    getline(fin, getString), gravityAverageHoldTemp1 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCellNoTemp1 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterXHoldTemp2 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterYHoldTemp2 = atoi(getString.c_str());
                                    getline(fin, getString), gravityAverageHoldTemp2 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCellNoTemp2 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterXHoldTemp3 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterYHoldTemp3 = atoi(getString.c_str());
                                    getline(fin, getString), gravityAverageHoldTemp3 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCellNoTemp3 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterXHoldTemp4 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCenterYHoldTemp4 = atoi(getString.c_str());
                                    getline(fin, getString), gravityAverageHoldTemp4 = atoi(getString.c_str());
                                    getline(fin, getString), gravityCellNoTemp4 = atoi(getString.c_str());
                                    
                                    fin.close();
                                }
                                else{
                                    
                                    gravityCenterXHoldTemp1 = -1;
                                    gravityCenterYHoldTemp1 = -1;
                                    gravityAverageHoldTemp1 = -1;
                                }
                                
                                if (gravityCenterXHoldTemp1 != -1 && gravityCenterYHoldTemp1 != -1){
                                    if (upperLimitEventType != 32 && upperLimitEventType != 33 && upperLimitEventType != 42 && upperLimitEventType != 43 && upperLimitEventType != 44 && upperLimitEventType != 52 && upperLimitEventType != 53 && upperLimitEventType != 54 && upperLimitEventType != 55){
                                        xPositionSave = gravityCenterXHoldTemp1;
                                        yPositionSave = gravityCenterYHoldTemp1;
                                        averageSave = gravityAverageHoldTemp1;
                                    }
                                    else if (upperLimitEventType == 32){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                    }
                                    else if (upperLimitEventType == 33){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                    }
                                    else if (upperLimitEventType == 42){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                    }
                                    else if (upperLimitEventType == 43){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                    }
                                    else if (upperLimitEventType == 44){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                    }
                                    else if (upperLimitEventType == 52){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                        else if (gravityCellNoTemp4 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp4;
                                            yPositionSave = gravityCenterYHoldTemp4;
                                            averageSave = gravityAverageHoldTemp4;
                                        }
                                    }
                                    else if (upperLimitEventType == 53){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                        else if (gravityCellNoTemp4 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp4;
                                            yPositionSave = gravityCenterYHoldTemp4;
                                            averageSave = gravityAverageHoldTemp4;
                                        }
                                    }
                                    else if (upperLimitEventType == 54){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                        else if (gravityCellNoTemp4 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp4;
                                            yPositionSave = gravityCenterYHoldTemp4;
                                            averageSave = gravityAverageHoldTemp4;
                                        }
                                    }
                                    else if (upperLimitEventType == 55){
                                        if (gravityCellNoTemp1 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp1;
                                            yPositionSave = gravityCenterYHoldTemp1;
                                            averageSave = gravityAverageHoldTemp1;
                                        }
                                        else if (gravityCellNoTemp2 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp2;
                                            yPositionSave = gravityCenterYHoldTemp2;
                                            averageSave = gravityAverageHoldTemp2;
                                        }
                                        else if (gravityCellNoTemp3 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp3;
                                            yPositionSave = gravityCenterYHoldTemp3;
                                            averageSave = gravityAverageHoldTemp3;
                                        }
                                        else if (gravityCellNoTemp4 == newCellNumber){
                                            xPositionSave = gravityCenterXHoldTemp4;
                                            yPositionSave = gravityCenterYHoldTemp4;
                                            averageSave = gravityAverageHoldTemp4;
                                        }
                                    }
                                }
                                
                                if (upperLimitEventType == 6 && mitosisInfoSetCount < 10 && averageSave != -1){
                                    averageValue = averageSave;
                                    processType = 2;
                                    
                                    mitosisSD = [[MitosisSD alloc] init];
                                    mitosisSDSave = [mitosisSD mitosisSDReturn:imagePositionData:processType];
                                    
                                    if (mitosisInfoSetCount != 10){
                                        arrayMitosisValueInfo [mitosisInfoSetCount] = averageValue;
                                        arrayMitosisSDInfo [mitosisInfoSetCount] = mitosisSDSave, mitosisInfoSetCount++;
                                    }
                                    
                                    string mitosisDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/mitosisParameter.dat";
                                    
                                    ofstream oin;
                                    
                                    oin.open(mitosisDataPath.c_str(), ios::out);
                                    
                                    for (int counter2 = 0; counter2 < 20; counter2++) oin<<arrayMitosisSDInfo [counter2]<<endl;
                                    for (int counter2 = 0; counter2 < 20; counter2++) oin<<arrayMitosisValueInfo [counter2]<<endl;
                                    
                                    oin<<mitosisInfoSetCount<<endl;
                                    oin<<mitosisInfoRemoveCount<<endl;
                                    
                                    oin.close();
                                }
                                
                                //-----1. X position, 2. Y position, 3. Time point, 4. Event Type, 5. Next Cell number, Fusion: hold cell number of Fusion partner-----
                                //-----6. Cell Number, 7. Cell Lineage Number, 8. For Fusion, Cell lineage Number-----
                                
                                if (xPositionSave == -1 || yPositionSave == -1){
                                    for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                        if (arrayLineageExtraction [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageExtraction [counter2*8+5] == cellAmendTemp &&  arrayLineageExtraction [counter2*8+6] == lineageAmendTemp){
                                            xPositionEntry = arrayLineageExtraction [counter2*8];
                                            yPositionEntry = arrayLineageExtraction [counter2*8+1];
                                            break;
                                        }
                                    }
                                }
                                else{
                                    
                                    xPositionEntry = xPositionSave;
                                    yPositionEntry = yPositionSave;
                                }
                                
                                //cout<<xPositionEntry<<" "<<yPositionEntry<<" position"<<endl;
                                
                                if (upperLimitEventType == 1 || upperLimitEventType == 31 || upperLimitEventType == 41 || upperLimitEventType == 51){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = initialEventType;
                                    cellLineageCellExtract [imagePositionData*8+4] = initialParentNumber;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (firstModificationPoint == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (imagePositionData == imageEndHold){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 2;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    newUpperLimitAdjust = imageEndHold;
                                }
                                else if (upperLimitEventType == 2){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 2;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (upperLimitEventType == 6){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 6;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                    
                                    mitosisImageNo = imagePositionData;
                                    mitosisLineageNo = lineageAmendTemp;
                                    mitosisCellNo = newCellNumber;
                                }
                                else if (upperLimitEventType == 7){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 7;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    newUpperLimitAdjust = imagePositionData;
                                    
                                    break;
                                }
                                else if (upperLimitEventType == 8){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 8;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    newUpperLimitAdjust = imagePositionData;
                                    
                                    break;
                                }
                                else if (upperLimitEventType == 10){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 10;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (upperLimitEventType == 11){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 11;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (endNoChange == 0 && (upperLimitEventType == 32 || upperLimitEventType == 33)){
                                    cellLineageCellExtract [(imagePositionData-1)*8+3] = 32;
                                    
                                    newUpperLimitAdjust = imagePositionData-1;
                                    
                                    arrayNewCellTemp [newCellTempCount] = xPositionEntry, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = yPositionEntry, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = imagePositionData, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = 31, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = cellAmendTemp, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = newCellNumber, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = lineageAmendTemp, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = 0, newCellTempCount++;
                                }
                                else if (endNoChange == 1 && upperLimitEventType == 32){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 32;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (endNoChange == 0 && (upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44)){
                                    cellLineageCellExtract [(imagePositionData-1)*8+3] = 42;
                                    
                                    newUpperLimitAdjust = imagePositionData-1;
                                    
                                    arrayNewCellTemp [newCellTempCount] = xPositionEntry, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = yPositionEntry, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = imagePositionData, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = 41, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = cellAmendTemp, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = newCellNumber, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = lineageAmendTemp, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = 0, newCellTempCount++;
                                }
                                else if (endNoChange == 1 && upperLimitEventType == 42){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 42;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (endNoChange == 0 && (upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55)){
                                    cellLineageCellExtract [(imagePositionData-1)*8+3] = 52;
                                    newUpperLimitAdjust = imagePositionData-1;
                                    
                                    arrayNewCellTemp [newCellTempCount] = xPositionEntry, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = yPositionEntry, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = imagePositionData, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = 51, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = cellAmendTemp, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = newCellNumber, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = lineageAmendTemp, newCellTempCount++;
                                    arrayNewCellTemp [newCellTempCount] = 0, newCellTempCount++;
                                }
                                else if (endNoChange == 1 && upperLimitEventType == 52){
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 52;
                                    cellLineageCellExtract [imagePositionData*8+4] = 0;
                                    cellLineageCellExtract [imagePositionData*8+5] = newCellNumber;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = 0;
                                    
                                    if (imagePositionData == newUpperLimit) newUpperLimitAdjust = newUpperLimit;
                                }
                                else if (upperLimitEventType == 91){
                                    if (arrayEventSequenceReorganize [counter1*4+2] == lineageAmendTemp && arrayEventSequenceReorganize [counter1*4+3] == cellAmendTemp){
                                        fusionCellTemp = 0;
                                        fusionLingTemp = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                            if (arrayLineageData [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageData [counter2*8+3] == 92 && arrayLineageData [counter2*8+4] == cellAmendTemp && arrayLineageData [counter2*8+7] == lineageAmendTemp){
                                                arrayLineageData [counter2*8] = xPositionEntry;
                                                arrayLineageData [counter2*8+1] = yPositionEntry;
                                                
                                                fusionCellTemp = arrayLineageData [counter2*8+5];
                                                fusionLingTemp = arrayLineageData [counter2*8+6];
                                                
                                                break;
                                            }
                                        }
                                        
                                        cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                        cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                        cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                        cellLineageCellExtract [imagePositionData*8+3] = 91;
                                        cellLineageCellExtract [imagePositionData*8+4] = fusionCellTemp;
                                        cellLineageCellExtract [imagePositionData*8+5] = cellAmendTemp;
                                        cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                        cellLineageCellExtract [imagePositionData*8+7] = fusionLingTemp;
                                        
                                        newUpperLimitAdjust = imagePositionData;
                                        
                                        for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                            if (arrayLineageExtraction [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageExtraction [counter2*8+5] == arrayEventSequenceReorganize [counter1*4+3] && arrayLineageExtraction [counter2*8+6] == arrayEventSequenceReorganize [counter1*4+2]){
                                                arrayLineageExtraction [counter2*8] = xPositionEntry;
                                                arrayLineageExtraction [counter2*8+1] = yPositionEntry;
                                                break;
                                            }
                                        }
                                    }
                                    else{
                                        
                                        cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                        cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                        cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                        cellLineageCellExtract [imagePositionData*8+3] = 91;
                                        cellLineageCellExtract [imagePositionData*8+4] = newCellNumber;
                                        cellLineageCellExtract [imagePositionData*8+5] = cellAmendTemp;
                                        cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                        cellLineageCellExtract [imagePositionData*8+7] = arrayEventSequenceReorganize [counter1*4+2];
                                        
                                        newUpperLimitAdjust = imagePositionData;
                                        
                                        fusionMarkImageTemp = 10000;
                                        
                                        for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                                            if (arrayLineageStartEnd [counter2*8+5] <= imageNumberTrackForDisplay-1){
                                                for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                                    if (arrayLineageData [counter3*8+2] >= imageNumberTrackForDisplay-1 && arrayLineageData [counter3*8+2] <= imageNumberTrackForDisplay+10){
                                                        if (arrayLineageData [counter3*8+3] == 10 && arrayLineageData [counter3*8+5] == fusionPartnerCellNo && arrayLineageData [counter3*8+6] == fusionPartnerLin){
                                                            if (fusionMarkImageTemp > arrayLineageData [counter3*8+2]){
                                                                fusionMarkImageTemp = arrayLineageData [counter3*8+2];
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < lineageStartEndCount/8; counter2++){
                                            if (arrayLineageStartEnd [counter2*8] == arrayEventSequenceReorganize [counter1*4+2] && arrayLineageStartEnd [counter2*8+1] == arrayEventSequenceReorganize [counter1*4+3]){
                                                for (int counter3 = arrayLineageStartEnd [counter2*8+4]; counter3 <= arrayLineageStartEnd [counter2*8+6]; counter3++){
                                                    if (arrayLineageData [counter3*8+2] == arrayEventSequenceReorganize [counter1*4]){
                                                        arrayLineageData [counter3*8] = xPositionEntry;
                                                        arrayLineageData [counter3*8+1] = yPositionEntry;
                                                        arrayLineageData [counter3*8+3] = 92;
                                                        arrayLineageData [counter3*8+4] = cellAmendTemp;
                                                        arrayLineageData [counter3*8+7] = lineageAmendTemp;
                                                    }
                                                    
                                                    if (arrayLineageData [counter3*8+3] == 10 && arrayLineageData [counter3*8+2] == fusionMarkImageTemp){
                                                        arrayLineageData [counter3*8+3] = 2;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                            if (arrayLineageExtraction [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageExtraction [counter2*8+5] == arrayEventSequenceReorganize [counter1*4+3]){
                                                arrayLineageExtraction [counter2*8] = xPositionEntry;
                                                arrayLineageExtraction [counter2*8+1] = yPositionEntry;
                                                arrayLineageExtraction [counter2*8+3] = 92;
                                                arrayLineageExtraction [counter2*8+4] = cellAmendTemp;
                                                arrayLineageExtraction [counter2*8+7] = lineageAmendTemp;
                                            }
                                            
                                            if (arrayLineageExtraction [counter2*8+3] == 10 && arrayLineageExtraction [counter2*8+2] == fusionMarkImageTemp){
                                                arrayLineageExtraction [counter2*8+3] = 2;
                                            }
                                        }
                                    }
                                }
                                else if (upperLimitEventType == 92){
                                    fusionCellTemp = 0;
                                    fusionLingTemp = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                        if (arrayLineageData [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageData [counter2*8+3] == 91 && arrayLineageData [counter2*8+4] == cellAmendTemp && arrayLineageData [counter2*8+7] == lineageAmendTemp){
                                            arrayLineageData [counter2*8] = xPositionEntry;
                                            arrayLineageData [counter2*8+1] = yPositionEntry;
                                            
                                            fusionCellTemp = arrayLineageData [counter2*8+5];
                                            fusionLingTemp = arrayLineageData [counter2*8+6];
                                            
                                            break;
                                        }
                                    }
                                    
                                    cellLineageCellExtract [imagePositionData*8] = xPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+1] = yPositionEntry;
                                    cellLineageCellExtract [imagePositionData*8+2] = imagePositionData;
                                    cellLineageCellExtract [imagePositionData*8+3] = 92;
                                    cellLineageCellExtract [imagePositionData*8+4] = fusionCellTemp;
                                    cellLineageCellExtract [imagePositionData*8+5] = cellAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+6] = lineageAmendTemp;
                                    cellLineageCellExtract [imagePositionData*8+7] = fusionLingTemp;
                                    
                                    newUpperLimitAdjust = imagePositionData;
                                    
                                    for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                        if (arrayLineageExtraction [counter2*8+2] == arrayEventSequenceReorganize [counter1*4] && arrayLineageExtraction [counter2*8+5] == arrayEventSequenceReorganize [counter1*4+3] && arrayLineageExtraction [counter2*8+6] == arrayEventSequenceReorganize [counter1*4+2]){
                                            arrayLineageExtraction [counter2*8] = xPositionEntry;
                                            arrayLineageExtraction [counter2*8+1] = yPositionEntry;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 1; counterA <= newUpperLimit; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellLineageCellExtract [counterA*8+counterB];
                        //    cout<<" cellLineageCellExtract "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //	cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < newCellTempCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayNewCellTemp [counterA*8+counterB];
                        //	cout<<" arrayNewCellTemp "<<counterA<<endl;
                        //}
                        
                        //-----Lineage Data Reorganize, One cell form one block-----
                        int *lineageExtractionTemp = new int [lineageDataCount+50];
                        int lineageExtractionTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                            if (arrayLineageExtraction [counter1*8+5] != cellAmendTemp){
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+1], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+2], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+3], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+4], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+5], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+6], lineageExtractionTempCount++;
                                lineageExtractionTemp [lineageExtractionTempCount] = arrayLineageExtraction [counter1*8+7], lineageExtractionTempCount++;
                            }
                        }
                        
                        for (int counter1 = 1; counter1 <= newUpperLimitAdjust; counter1++){
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+1], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+2], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+3], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+4], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+5], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+6], lineageExtractionTempCount++;
                            lineageExtractionTemp [lineageExtractionTempCount] = cellLineageCellExtract [counter1*8+7], lineageExtractionTempCount++;
                        }
                        
                        delete [] cellLineageCellExtract;
                        
                        for (int counter1 = 0; counter1 < newCellTempCount; counter1++) lineageExtractionTemp [lineageExtractionTempCount] = arrayNewCellTemp [counter1], lineageExtractionTempCount++;
                        
                        delete [] arrayNewCellTemp;
                        
                        //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
                        //    cout<<" lineageExtractionTemp "<<counterA<<endl;
                        //}
                        
                        int *arrayLineageExtraction2 = new int [lineageExtractionTempCount+lineageDataCount+10000];
                        int lineageExtractionCount2 = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                            if (arrayLineageData [counter1*8+6] != lineageAmendTemp){
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+1], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+2], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+3], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+4], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+5], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+6], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageData [counter1*8+7], lineageExtractionCount2++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction2 [counterA*8+counterB];
                        //	cout<<" arrayLineageExtraction2 "<<counterA<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < lineageExtractionTempCount/8; counter1++){
                            if (lineageExtractionTemp [counter1*8+6] != 0){
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+1], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+2], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+3], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+4], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+5], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+6], lineageExtractionCount2++;
                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageExtractionTemp [counter1*8+7], lineageExtractionCount2++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction2 [counterA*8+counterB];
                        //    cout<<" arrayLineageExtraction2 "<<counterA<<endl;
                        //}
                        
                        if (lineageDataStatus == 1) delete [] arrayLineageData;
                        arrayLineageData = new int [lineageExtractionCount2+500];
                        lineageDataCount = 0;
                        lineageDataLimit = lineageExtractionCount2+500;
                        lineageDataStatus = 1;
                        
                        for (int counter1 = 0; counter1 < lineageExtractionCount2; counter1++) arrayLineageData [lineageDataCount] = arrayLineageExtraction2 [counter1], lineageDataCount++;
                        delete [] arrayLineageExtraction2;
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //    cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //-----Lineage Data Save-----
                        string connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+analysisID+"_"+treatmentNameHold+"_LineageData";
                        
                        //-----(Backup create)-----
                        string tempBackUpPath = backUpTempPath+"/"+analysisID+"_"+treatmentNameHold+"_LineageData";
                        string tempBackUpPath2 = tempBackUpPath+"~5";
                        string tempBackUpPath3;
                        
                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            tempBackUpPath2 = tempBackUpPath+"~1";
                            remove (tempBackUpPath2.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~2";
                            tempBackUpPath3 = tempBackUpPath+"~1";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~3";
                            tempBackUpPath3 = tempBackUpPath+"~2";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            tempBackUpPath3 = tempBackUpPath+"~3";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            tempBackUpPath3 = tempBackUpPath+"~4";
                            rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                            
                            rename (connectDataLineagePath.c_str(), tempBackUpPath2.c_str());
                        }
                        else{
                            
                            tempBackUpPath2 = tempBackUpPath+"~4";
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                rename (connectDataLineagePath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    rename (connectDataLineagePath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        rename (connectDataLineagePath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            rename (connectDataLineagePath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            rename (connectDataLineagePath.c_str(), tempBackUpPath2.c_str());
                                        }
                                    }
                                }
                            }
                        }
                        
                        //-----
                        
                        lineageWritingCheck = 1;
                        
                        char *writingArray = new char [lineageDataCount/8*25+25];
                        
                        unsigned long indexCount = 0;
                        int readBit [4];
                        int dataTemp;
                        
                        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                            if (arrayLineageData [counter1*8] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = arrayLineageData [counter1*8]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = arrayLineageData [counter1*8];
                            }
                            
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            if (arrayLineageData [counter1*8+1] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = arrayLineageData [counter1*8+1]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = arrayLineageData [counter1*8+1];
                            }
                            
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = arrayLineageData [counter1*8+2];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)arrayLineageData [counter1*8+3], indexCount++;
                            
                            if (arrayLineageData [counter1*8+4] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = arrayLineageData [counter1*8+4]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = arrayLineageData [counter1*8+4];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            if (arrayLineageData [counter1*8+5] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = arrayLineageData [counter1*8+5]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = arrayLineageData [counter1*8+5];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            dataTemp = arrayLineageData [counter1*8+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = arrayLineageData [counter1*8+7];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile (connectDataLineagePath.c_str(), ofstream::binary);
                        outfile.write ((char*) writingArray, indexCount);
                        outfile.close();
                        
                        delete [] writingArray;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            fin.open(connectDataLineagePath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                fin.close();
                                lineageWritingCheck = 0;
                                terminationFlag = 0;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
                        //	cout<<" arrayEventSequenceReorganize "<<counterA<<endl;
                        //}
                        
                        //-----File Move to _Connect-----
                        string connectDataRevPath;
                        string connectStatusPath;
                        string connectRelTempPath;
                        string connectRelPath;
                        string connectMapTempPath;
                        string connectMapPath;
                        string connectTempPathD;
                        
                        for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                            if (arrayEventSequenceReorganize [counter1*4] >= firstModificationPoint && arrayEventSequenceReorganize [counter1*4] <= newUpperLimit){
                                extension = to_string(arrayEventSequenceReorganize [counter1*4]);
                                
                                if (extension.length() == 1) extension = "000"+extension;
                                else if (extension.length() == 2) extension = "00"+extension;
                                else if (extension.length() == 3) extension = "0"+extension;
                                
                                connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
                                connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTempD";
                                
                                fin.open(connectDataTempPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    remove (connectDataRevPath.c_str());
                                    rename (connectDataTempPath.c_str(), connectDataRevPath.c_str());
                                    remove (connectTempPathD.c_str());
                                }
                                
                                connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
                                connectStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTempD";
                                
                                fin.open(connectStatusTempPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    remove (connectStatusPath.c_str());
                                    rename (connectStatusTempPath.c_str(), connectStatusPath.c_str());
                                    remove (connectTempPathD.c_str());
                                }
                                
                                connectRelTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
                                connectRelPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTempD";
                                
                                fin.open(connectRelTempPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    remove (connectRelPath.c_str());
                                    rename (connectRelTempPath.c_str(), connectRelPath.c_str());
                                    remove (connectTempPathD.c_str());
                                }
                                
                                connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_RevisedTempMap";
                                connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_RevisedTempMapD";
                                
                                fin.open(connectMapTempPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    //-----(Backup create)-----
                                    tempBackUpPath = backUpTempPath+"/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                        remove (tempBackUpPath2.c_str());
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        tempBackUpPath3 = tempBackUpPath+"~1";
                                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        tempBackUpPath3 = tempBackUpPath+"~2";
                                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~4";
                                        tempBackUpPath3 = tempBackUpPath+"~3";
                                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~5";
                                        tempBackUpPath3 = tempBackUpPath+"~4";
                                        rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                        
                                        rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~4";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~5";
                                            rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~3";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~4";
                                                rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~2";
                                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    fin.close();
                                                    
                                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                                    rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                                }
                                                else{
                                                    
                                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                                    
                                                    if (fin.is_open()){
                                                        fin.close();
                                                        
                                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                                        rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                                    }
                                                    else{
                                                        
                                                        tempBackUpPath2 = tempBackUpPath+"~1";
                                                        rename (connectMapPath.c_str(), tempBackUpPath2.c_str());
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    rename (connectMapTempPath.c_str(), connectMapPath.c_str());
                                    remove (connectTempPathD.c_str());
                                }
                                
                                connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTemp";
                                connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTempD";
                                
                                fin.open(connectMapTempPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    remove (connectMapPath.c_str());
                                    rename (connectMapTempPath.c_str(), connectMapPath.c_str());
                                    remove (connectTempPathD.c_str());
                                }
                                
                                connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendAreaDataTemp";
                                connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendAreaDataTempD";
                                
                                fin.open(connectMapTempPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    remove (connectMapPath.c_str());
                                    rename (connectMapTempPath.c_str(), connectMapPath.c_str());
                                    remove (connectTempPathD.c_str());
                                }
                                
                                connectMapTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_GCCenterInfo";
                                connectTempPathD = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_GCCenterInfoD";
                                
                                remove (connectMapTempPath.c_str());
                                remove (connectTempPathD.c_str());
                            }
                        }
                        
                        string connectStatusTempPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
                        
                        string removeFilePath;
                        
                        fileDeleteCount = 0;
                        
                        dir = opendir(connectStatusTempPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate fileDeleteUpDate];
                                }
                                
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                entry = arrayFileDelete [counter1];
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                    int findFile2 = (int)entry.find("CutTemp");
                                    int findFile3 = (int)entry.find("GCCurrentTemp");
                                    int findFile4 = (int)entry.find("MasterDataTemp");
                                    int findFile5 = (int)entry.find("RevisedTempMap");
                                    int findFile6 = (int)entry.find("StatusTemp");
                                    int findFile7 = (int)entry.find("LinkDataTemp");
                                    int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                    int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                    int findFile10 = (int)entry.find("EventTemp");
                                    int findFile11 = (int)entry.find("MitosisDataTemp");
                                    int findFile12 = (int)entry.find("GCCenterInfo");
                                    
                                    if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                        removeFilePath = connectStatusTempPath+"/"+entry;
                                        remove (removeFilePath.c_str());
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractionTempCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageExtractionTemp [counterA*8+counterB];
                        //	cout<<" lineageExtractionTemp "<<counterA<<endl;
                        //}
                        
                        //-----Lineage Start/End List-----
                        //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
                        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                        
                        lineageStartEndCount = 0;
                        
                        int cellNumberStart = -1;
                        int lineageNumberStart = 0;
                        int firstEntryFind = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                            if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                                lineageNumberStart = arrayLineageData [counter1*8+6];
                                cellNumberStart = arrayLineageData [counter1*8+5];
                                
                                arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                                
                                firstEntryFind = 1;
                            }
                            else if ((arrayLineageData [counter1*8+6] != lineageNumberStart || arrayLineageData [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                                lineageNumberStart = arrayLineageData [counter1*8+6];
                                cellNumberStart = arrayLineageData [counter1*8+5];
                                
                                arrayLineageStartEnd [lineageStartEndCount] = counter1-1, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [(counter1-1)*8+2], lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = lineageNumberStart, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = cellNumberStart, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8], lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+1], lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                            }
                            
                            if (counter1 == lineageDataCount/8-1){
                                arrayLineageStartEnd [lineageStartEndCount] = counter1, lineageStartEndCount++;
                                arrayLineageStartEnd [lineageStartEndCount] = arrayLineageData [counter1*8+2], lineageStartEndCount++;
                            }
                            
                            if (lineageStartEndCount+24 > lineageStartEndLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate lineageStartEndUpDate];
                            }
                        }
                        
                        //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                        //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
                        //}
                        
                        if (lineageStartEndCount != 0){
                            char *mainDataEntry = new char [lineageStartEndCount*7+10];
                            int totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < lineageStartEndCount; counter1++){
                                extension = to_string(arrayLineageStartEnd [counter1]);
                                
                                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
                            outfile2.write (mainDataEntry, totalEntryCount);
                            outfile2.close();
                            
                            delete [] mainDataEntry;
                        }
                        
                        int fusionMarkFind = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                            if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                    if (arrayLineageData [counter2*8+3] == 10) fusionMarkFind = 1;
                                }
                            }
                        }
                        
                        int fusionMarkPartnerFind = 0;
                        int fusionLingPartner = 0;
                        int fusionCellPartner = 0;
                        
                        if (upperLimitEventType == 91){
                            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                                if (arrayEventSequenceReorganize [counter1*4+1] == 91){
                                    fusionLingPartner = arrayEventSequenceReorganize [counter1*4+2];
                                    fusionCellPartner = arrayEventSequenceReorganize [counter1*4+3];
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                                if (arrayLineageStartEnd [counter1*8] == fusionLingPartner && arrayLineageStartEnd [counter1*8+1] == fusionCellPartner){
                                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                        if (arrayLineageData [counter2*8+3] == 10) fusionMarkPartnerFind = 1;
                                    }
                                }
                            }
                        }
                        
                        //==========XYPositionList update==========
                        if (xyPositionListStatus == 1) delete [] arrayXYPositionList;
                        arrayXYPositionList = new int [lineageExtractionTempCount+500];
                        xyPositionListCount = 0;
                        xyPositionListStatus = 1;
                        
                        for (int counter1 = 0; counter1 < lineageExtractionTempCount/8; counter1++){
                            arrayXYPositionList [xyPositionListCount] = lineageExtractionTemp [counter1*8+2], xyPositionListCount++; //-----Image Number-----
                            arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++; //-----Connect Number-----
                            arrayXYPositionList [xyPositionListCount] = lineageExtractionTemp [counter1*8], xyPositionListCount++; //-----X Position-----
                            arrayXYPositionList [xyPositionListCount] = lineageExtractionTemp [counter1*8+1], xyPositionListCount++; //-----Y Position-----
                            
                            if (cellAmendTemp == lineageExtractionTemp [counter1*8+5]) arrayXYPositionList [xyPositionListCount] = 1, xyPositionListCount++; //-----Target-----
                            else arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++;
                        }
                        
                        //for (int counterA = 0; counterA < xyPositionListCount/5; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayXYPositionList [counterA*5+counterB];
                        //	cout<<" arrayXYPositionList "<<counterA<<endl;
                        //}
                        
                        if ((int)targetLostMark.find("Lost") != -1) processTypeCell = 1;
                        
                        int readingError = 0;
                        
                        if (processTypeCell == 1){
                            extension = to_string(newUpperLimit);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            string connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                            connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            readingError = 0;
                            
                            for (int counter1 = 0; counter1 < 6; counter1++){
                                sizeForCopy = 0;
                                
                                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter1 == 0) size1 = sizeForCopy;
                                    else if (counter1 == 1) size2 = sizeForCopy;
                                    else if (counter1 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter1 == 3) size1 = sizeForCopy;
                                    else if (counter1 == 4) size2 = sizeForCopy;
                                    else if (counter1 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            int *masterReadForAmend = new int [sizeForCopy+50];
                            int masterReadForAmendCount = 0;
                            
                            if (checkFlag == 1){
                                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                            finData [14] = uploadTemp [readPosition], readPosition++;
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                            
                                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                            }
                            
                            //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                            //	cout<<" masterReadForAmend "<<counterA<<endl;
                            //}
                            
                            //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                            
                            int entryCount = 0;
                            
                            for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                                if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp) entryCount++;
                            }
                            
                            indexCount = 0;
                            
                            writingArray = new char [entryCount*13+20];
                            
                            for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                                if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp){
                                    dataTemp = newUpperLimit;
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = masterReadForAmend [counter1*7];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = masterReadForAmend [counter1*7+1];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)upperLimitEventType, indexCount++;
                                    
                                    dataTemp = masterReadForAmend [counter1*7+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterReadForAmend [counter1*7+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile3 (connectAmendPath.c_str(), ofstream::binary);
                            outfile3.write ((char*)writingArray, indexCount);
                            outfile3.close();
                            
                            delete [] writingArray;
                            
                            if (connectLineListLocalStatus == 1) delete [] arrayConnectLineListLocal;
                            arrayConnectLineListLocal = new int [masterReadForAmendCount+500];
                            connectLineListLocalCount = 0;
                            connectLineListLocalLimit = masterReadForAmendCount+500;
                            connectLineListLocalStatus = 1;
                            
                            for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                                if (masterReadForAmend [counter1*7+4] == cellAmendTemp && masterReadForAmend [counter1*7+6] == lineageAmendTemp){
                                    arrayConnectLineListLocal [connectLineListLocalCount] = masterReadForAmend [counter1*7], connectLineListLocalCount++; //-----X Position-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = masterReadForAmend [counter1*7+1], connectLineListLocalCount++; //-----Y Position-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = upperLimitEventType, connectLineListLocalCount++; //-----Event Type-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = masterReadForAmend [counter1*7+3], connectLineListLocalCount++; //-----Connect No-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = masterReadForAmend [counter1*7+6], connectLineListLocalCount++; //-----Lineage No-----
                                    arrayConnectLineListLocal [connectLineListLocalCount] = newUpperLimit, connectLineListLocalCount++; //-----Image no-----
                                }
                            }
                            
                            //for (int counterA = 0; counterA < connectLineListLocalCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineListLocal [counterA*6+counterB];
                            //	cout<<" arrayConnectLineListLocal "<<counterA<<endl;
                            //}
                            
                            delete [] masterReadForAmend;
                            
                            extension = to_string(newUpperLimit);
                            
                            //=========Queue List creation==========
                            if (targetLostMark == ""){
                                string *queueListUpdateTemp = new string [queueListCount+50];
                                int queueListUpdateTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                    if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+1] != cellLineageNoHold || arrayQueueList [counter1*6+2] != cellNoHold){
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+1], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+2], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+3], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+4], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+5], queueListUpdateTempCount++;
                                    }
                                }
                                
                                string endCheckTemp = "";
                                
                                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                    if (arrayQueueList [counter1*6] == treatmentNameHold && arrayQueueList [counter1*6+1] == cellLineageNoHold && arrayQueueList [counter1*6+2] == cellNoHold){
                                        endCheckTemp = arrayQueueList [counter1*6+4];
                                        break;
                                    }
                                }
                                
                                if ((int)endCheckTemp.find("/m") != -1) endCheckTemp = endCheckTemp.substr(0, endCheckTemp.find("/m"));
                                
                                if (atoi(endCheckTemp.c_str()) <= newUpperLimit) endCheckTemp = "0";
                                
                                int ifSetFlag = 0;
                                
                                if (ifStartHold != 0 && ifStartHold <= newUpperLimit+1) ifSetFlag = 1;
                                
                                int ifAlreadySetFlag = 0;
                                
                                if ((int)endCheckTemp.find("IF") != -1) ifAlreadySetFlag = 1;
                                
                                queueListUpdateTemp [queueListUpdateTempCount] = treatmentNameHold, queueListUpdateTempCount++;
                                queueListUpdateTemp [queueListUpdateTempCount] = cellLineageNoHold, queueListUpdateTempCount++;
                                queueListUpdateTemp [queueListUpdateTempCount] = cellNoHold, queueListUpdateTempCount++;
                                queueListUpdateTemp [queueListUpdateTempCount] = extension+":"+extension, queueListUpdateTempCount++;
                                
                                if (fusionMarkFind == 0 && ifSetFlag == 0 && ifAlreadySetFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = endCheckTemp, queueListUpdateTempCount++;
                                else if (fusionMarkFind == 1 && ifSetFlag == 0 && ifAlreadySetFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = endCheckTemp+"/m", queueListUpdateTempCount++;
                                else if (fusionMarkFind == 0 && ifSetFlag == 1 && ifAlreadySetFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = "IF", queueListUpdateTempCount++;
                                else if (fusionMarkFind == 1 && ifSetFlag == 1 && ifAlreadySetFlag == 0) queueListUpdateTemp [queueListUpdateTempCount] = "IF/m", queueListUpdateTempCount++;
                                else if (fusionMarkFind == 0 && ifAlreadySetFlag == 1) queueListUpdateTemp [queueListUpdateTempCount] = "IF", queueListUpdateTempCount++;
                                else if (fusionMarkFind == 1 && ifAlreadySetFlag == 1) queueListUpdateTemp [queueListUpdateTempCount] = "IF/m", queueListUpdateTempCount++;
                                
                                queueListUpdateTemp [queueListUpdateTempCount] = "Wait", queueListUpdateTempCount++;
                                
                                if (queueListUpdateTempCount > queueListLimit){
                                    delete [] arrayQueueList;
                                    arrayQueueList = new string [queueListUpdateTempCount+5000];
                                    queueListLimit = queueListUpdateTempCount+5000;
                                }
                                
                                queueListCount = 0;
                                
                                for (int counter1 = 0; counter1 < queueListUpdateTempCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
                                
                                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                //	cout<<" arrayQueueList "<<counterA<<endl;
                                //}
                                
                                delete [] queueListUpdateTemp;
                                
                                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                
                                //-----(Backup create)-----
                                tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    remove (tempBackUpPath2.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    tempBackUpPath3 = tempBackUpPath+"~1";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    tempBackUpPath3 = tempBackUpPath+"~2";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    tempBackUpPath3 = tempBackUpPath+"~3";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    tempBackUpPath3 = tempBackUpPath+"~4";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~5";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~4";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~3";
                                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~1";
                                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    fin.close();
                                                    
                                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                                }
                                                else{
                                                    
                                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (queueListCount != 0){
                                    char *mainDataEntry = new char [queueListCount*12+10];
                                    int totalEntryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                        extension2 = arrayQueueList [counter1];
                                        
                                        for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                            mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile2 (queueListPath.c_str(), ofstream::binary);
                                    outfile2.write (mainDataEntry, totalEntryCount);
                                    outfile2.close();
                                    
                                    delete [] mainDataEntry;
                                }
                            }
                            else{
                                
                                string *queueListUpdateTemp = new string [queueListCount+50];
                                int queueListUpdateTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                    if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+1] != cellLineageNoHold || arrayQueueList [counter1*6+2] != cellNoHold){
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+1], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+2], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+3], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+4], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter1*6+5], queueListUpdateTempCount++;
                                    }
                                }
                                
                                queueListCount = 0;
                                for (int counter1 = 0; counter1 < queueListUpdateTempCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
                                
                                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                //	cout<<" arrayQueueList "<<counterA<<endl;
                                //}
                                
                                delete [] queueListUpdateTemp;
                                
                                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                
                                if (queueListCount != 0){
                                    char *mainDataEntry = new char [queueListCount*12+10];
                                    int totalEntryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                        extension2 = arrayQueueList [counter1];
                                        
                                        for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                            mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile2 (queueListPath.c_str(), ofstream::binary);
                                    outfile2.write (mainDataEntry, totalEntryCount);
                                    outfile2.close();
                                    
                                    delete [] mainDataEntry;
                                }
                            }
                            
                            if (targetLostMark == ""){
                                string *doneListUpdateTemp = new string [doneListCount+50];
                                int doneListUpdateTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                    if (arrayDoneList [counter1*5] != treatmentNameHold || arrayDoneList [counter1*5+1] != cellLineageNoHold || arrayDoneList [counter1*5+2] != cellNoHold){
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                    }
                                }
                                
                                doneListCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                                
                                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                                //	cout<<" arrayDoneList "<<counterA<<endl;
                                //}
                                
                                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                
                                //-----(Backup create)-----
                                tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                    remove (tempBackUpPath2.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                    tempBackUpPath3 = tempBackUpPath+"~1";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    tempBackUpPath3 = tempBackUpPath+"~2";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    tempBackUpPath3 = tempBackUpPath+"~3";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    tempBackUpPath3 = tempBackUpPath+"~4";
                                    rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                    
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~4";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~5";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~3";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~4";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~2";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~3";
                                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~1";
                                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    fin.close();
                                                    
                                                    tempBackUpPath2 = tempBackUpPath+"~2";
                                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                                }
                                                else{
                                                    
                                                    tempBackUpPath2 = tempBackUpPath+"~1";
                                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                                }
                                            }
                                        }
                                    }
                                }
                                
                                if (doneListCount != 0){
                                    char *mainDataEntry = new char [doneListCount*10+10];
                                    int totalEntryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                        extension2 = arrayDoneList [counter1];
                                        
                                        for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                            mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                                    outfile2.write (mainDataEntry, totalEntryCount);
                                    outfile2.close();
                                    
                                    delete [] mainDataEntry;
                                }
                                
                                delete [] doneListUpdateTemp;
                            }
                            else{
                                
                                string *doneListUpdateTemp = new string [doneListCount+50];
                                int doneListUpdateTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                    if (arrayDoneList [counter1*5] != treatmentNameHold || arrayDoneList [counter1*5+1] != cellLineageNoHold || arrayDoneList [counter1*5+2] != cellNoHold){
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                    }
                                }
                                
                                if (fusionMarkFind == 1){
                                    doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameHold, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = cellLineageNoHold, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = cellNoHold, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+extension, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = "TL/m", doneListUpdateTempCount++;
                                }
                                else{
                                    
                                    doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameHold, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = cellLineageNoHold, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = cellNoHold, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+extension, doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = "TL", doneListUpdateTempCount++;
                                }
                                
                                if (doneListUpdateTempCount > doneListLimit){
                                    delete [] arrayDoneList;
                                    arrayDoneList = new string [doneListUpdateTempCount+500];
                                    doneListLimit = doneListUpdateTempCount+500;
                                }
                                
                                doneListCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                                
                                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                                //	cout<<" arrayDoneList "<<counterA<<endl;
                                //}
                                
                                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                
                                if (doneListCount != 0){
                                    char *mainDataEntry = new char [doneListCount*10+10];
                                    int totalEntryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                        extension2 = arrayDoneList [counter1];
                                        
                                        for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                            mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                                    outfile2.write (mainDataEntry, totalEntryCount);
                                    outfile2.close();
                                    
                                    delete [] mainDataEntry;
                                }
                                
                                delete [] doneListUpdateTemp;
                            }
                            
                            //==========Cell Status Info==========
                            if (targetLostMark == ""){
                                for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                                    if (arrayCellNumberInfo [counter1*7] == cellAmendTemp && arrayCellNumberInfo [counter1*7+6] == lineageAmendTemp){
                                        arrayCellNumberInfo [counter1*7+2] = -1;
                                        arrayCellNumberInfo [counter1*7+4] = 0;
                                        
                                        if (fusionMarkFind == 0) arrayCellNumberInfo [counter1*7+5] = 0;
                                        else if (fusionMarkFind == 1) arrayCellNumberInfo [counter1*7+5] = 77;
                                        
                                        break;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                                //	cout<<" cellNumberInfoCount "<<counterA<<endl;
                                //}
                                
                                string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_CellStatus";
                                
                                char *mainDataEntry = new char [cellNumberInfoCount*7+10];
                                int totalEntryCount = 0;
                                
                                for (int counter1 = 0; counter1 < cellNumberInfoCount; counter1++){
                                    extension2 = to_string(arrayCellNumberInfo [counter1]);
                                    
                                    for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                        mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
                                outfile2.write (mainDataEntry, totalEntryCount);
                                outfile2.close();
                                
                                delete [] mainDataEntry;
                            }
                            else{
                                
                                for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                                    if (arrayCellNumberInfo [counter1*7] == cellAmendTemp && arrayCellNumberInfo [counter1*7+6] == lineageAmendTemp){
                                        arrayCellNumberInfo [counter1*7+2] = -1;
                                        arrayCellNumberInfo [counter1*7+4] = 0;
                                        
                                        if (fusionMarkFind == 0 && arrayCellNumberInfo [counter1*7+5] == 64) arrayCellNumberInfo [counter1*7+5] = 34;
                                        else if (fusionMarkFind == 1 && arrayCellNumberInfo [counter1*7+5] == 34) arrayCellNumberInfo [counter1*7+5] = 64;
                                        
                                        break;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                                //	cout<<" cellNumberInfoCount "<<counterA<<endl;
                                //}
                                
                                string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_CellStatus";
                                
                                char *mainDataEntry = new char [cellNumberInfoCount*7+10];
                                int totalEntryCount = 0;
                                
                                for (int counter1 = 0; counter1 < cellNumberInfoCount; counter1++){
                                    extension2 = to_string(arrayCellNumberInfo [counter1]);
                                    
                                    for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                        mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
                                outfile2.write (mainDataEntry, totalEntryCount);
                                outfile2.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                            int numberOfEntry = 0;
                            
                            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp) numberOfEntry++;
                            }
                            
                            string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
                            
                            for (int counter1 = 0; counter1 < cellLineageInfoCount/3; counter1++){
                                if (arrayCellLineageInfo [counter1*3] == lineageAmendTemp){
                                    arrayCellLineageInfo [counter1*3+1] = 0;
                                    arrayCellLineageInfo [counter1*3+2] = numberOfEntry;
                                    break;
                                }
                            }
                            
                            char *mainDataEntry = new char [cellLineageInfoCount*6+10];
                            int totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < cellLineageInfoCount; counter1++){
                                extension2 = to_string(arrayCellLineageInfo [counter1]);
                                
                                for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile4 (connectDataInfoPath.c_str(), ofstream::binary);
                            outfile4.write (mainDataEntry, totalEntryCount);
                            outfile4.close();
                            
                            delete [] mainDataEntry;
                        }
                        
                        if (processTypeCell == 2){
                            extension = to_string(newUpperLimit);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            readingError = 0;
                            
                            for (int counter1 = 0; counter1 < 6; counter1++){
                                sizeForCopy = 0;
                                
                                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter1 == 0) size1 = sizeForCopy;
                                    else if (counter1 == 1) size2 = sizeForCopy;
                                    else if (counter1 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter1 == 3) size1 = sizeForCopy;
                                    else if (counter1 == 4) size2 = sizeForCopy;
                                    else if (counter1 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            int *masterReadForAmend = new int [sizeForCopy+50];
                            int masterReadForAmendCount = 0;
                            
                            if (checkFlag == 1){
                                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                            finData [14] = uploadTemp [readPosition], readPosition++;
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                            
                                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                                masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                            }
                            
                            //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                            //	cout<<" masterReadForAmend "<<counterA<<endl;
                            //}
                            
                            string cellNumberString;
                            string newCellFolderPath;
                            string connectAmendPath;
                            
                            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                                if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                                    cellNumberString = to_string(arrayEventSequenceReorganize [counter1*4+3]);
                                    
                                    if (arrayEventSequenceReorganize [counter1*4+3] >= 0){
                                        if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                                        else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                                        else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                                        else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                                        else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                                        else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                                        else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                                        else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                                        else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                                    }
                                    else{
                                        
                                        cellNumberString = cellNumberString.substr(1);
                                        
                                        if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                                        else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                                        else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                                        else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                                        else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                                        else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                                        else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                                        else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                                        else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                                    }
                                    
                                    newCellFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNumberString;
                                    
                                    mkdir(newCellFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    int entryCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < masterReadForAmendCount/7; counter2++){
                                        if (masterReadForAmend [counter2*7+4] == arrayEventSequenceReorganize [counter1*4+3] && masterReadForAmend [counter2*7+6] == lineageAmendTemp){
                                            entryCount++;
                                        }
                                    }
                                    
                                    connectAmendPath = newCellFolderPath+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                                    
                                    //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                                    
                                    indexCount = 0;
                                    
                                    writingArray = new char [entryCount*13+20];
                                    
                                    for (int counter2 = 0; counter2 < masterReadForAmendCount/7; counter2++){
                                        if (masterReadForAmend [counter2*7+4] == arrayEventSequenceReorganize [counter1*4+3] && masterReadForAmend [counter2*7+6] == lineageAmendTemp){
                                            dataTemp = newUpperLimit;
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter2*7];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter2*7+1];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            writingArray [indexCount] = 1, indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter2*7+3];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter2*7+6];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < 13; counter2++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile4 (connectAmendPath.c_str(), ofstream::binary);
                                    outfile4.write ((char*)writingArray, indexCount);
                                    outfile4.close();
                                    
                                    delete [] writingArray;
                                }
                            }
                            
                            delete [] masterReadForAmend;
                            
                            connectLineListLocalCount = 0;
                            
                            connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                            remove (connectAmendPath.c_str());
                            
                            //==========Cell Status Info==========
                            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                                if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                                    if (cellNumberInfoCount+7 > cellNumberInfoLimit){
                                        int *arrayUpDate = new int [cellNumberInfoCount+10];
                                        
                                        for (int counter2 = 0; counter2 < cellNumberInfoCount; counter2++) arrayUpDate [counter2] = arrayCellNumberInfo [counter2];
                                        
                                        delete [] arrayCellNumberInfo;
                                        arrayCellNumberInfo = new int [cellNumberInfoLimit+10000];
                                        cellNumberInfoLimit = cellNumberInfoLimit+10000;
                                        
                                        for (int counter2 = 0; counter2 < cellNumberInfoCount; counter2++) arrayCellNumberInfo [counter2] = arrayUpDate [counter2];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayCellNumberInfo [cellNumberInfoCount] = arrayEventSequenceReorganize [counter1*4+3], cellNumberInfoCount++;
                                    arrayCellNumberInfo [cellNumberInfoCount] = newUpperLimit, cellNumberInfoCount++;
                                    arrayCellNumberInfo [cellNumberInfoCount] = -1, cellNumberInfoCount++;
                                    
                                    if (upperLimitEventType == 32 || upperLimitEventType == 33) arrayCellNumberInfo [cellNumberInfoCount] = 3, cellNumberInfoCount++;
                                    else if (upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44) arrayCellNumberInfo [cellNumberInfoCount] = 4, cellNumberInfoCount++;
                                    else if (upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55) arrayCellNumberInfo [cellNumberInfoCount] = 5, cellNumberInfoCount++;
                                    
                                    arrayCellNumberInfo [cellNumberInfoCount] = 0, cellNumberInfoCount++;
                                    arrayCellNumberInfo [cellNumberInfoCount] = 0, cellNumberInfoCount++;
                                    arrayCellNumberInfo [cellNumberInfoCount] = arrayEventSequenceReorganize [counter1*4+2], cellNumberInfoCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                                if (arrayCellNumberInfo [counter1*7] == cellAmendTemp && arrayCellNumberInfo [counter1*7+6] == lineageAmendTemp){
                                    arrayCellNumberInfo [counter1*7+2] = newUpperLimit-1;
                                    
                                    if (upperLimitEventType == 32 || upperLimitEventType == 33) arrayCellNumberInfo [counter1*7+4] = 3;
                                    else if (upperLimitEventType == 42 || upperLimitEventType == 43 || upperLimitEventType == 44) arrayCellNumberInfo [counter1*7+4] = 4;
                                    else if (upperLimitEventType == 52 || upperLimitEventType == 53 || upperLimitEventType == 54 || upperLimitEventType == 55) arrayCellNumberInfo [counter1*7+4] = 5;
                                    
                                    if (fusionMarkFind == 1) arrayCellNumberInfo [counter1*7+5] = 21;
                                    else if (fusionMarkFind == 0) arrayCellNumberInfo [counter1*7+5] = 0;
                                    
                                    break;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                            //	cout<<" arrayCellNumberInfo "<<counterA<<endl;
                            //}
                            
                            string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_CellStatus";
                            
                            char* mainDataEntry = new char [cellNumberInfoCount*7+10];
                            int totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < cellNumberInfoCount; counter1++){
                                extension2 = to_string(arrayCellNumberInfo [counter1]);
                                
                                for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
                            outfile2.write (mainDataEntry, totalEntryCount);
                            outfile2.close();
                            
                            delete [] mainDataEntry;
                            
                            //for (int counterA = 0; counterA < eventSequenceReorganizeCount/4; counterA++){
                            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceReorganize [counterA*4+counterB];
                            //	cout<<" arrayEventSequenceReorganize "<<counterA<<endl;
                            //}
                            
                            int numberOfNewCells = 0;
                            int ifSetFlag = 0;
                            
                            if (ifStartHold != 0 && ifStartHold == newUpperLimit+1) ifSetFlag = 1;
                            
                            for (int counter1 = 0; counter1 < eventSequenceReorganizeCount/4; counter1++){
                                if (arrayEventSequenceReorganize [counter1*4] == newUpperLimit){
                                    numberOfNewCells++;
                                    
                                    cellNumberString = to_string(arrayEventSequenceReorganize [counter1*4+3]);
                                    
                                    if (arrayEventSequenceReorganize [counter1*4+3] >= 0){
                                        if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                                        else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                                        else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                                        else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                                        else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                                        else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                                        else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                                        else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                                        else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                                    }
                                    else{
                                        
                                        cellNumberString = cellNumberString.substr(1);
                                        
                                        if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                                        else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                                        else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                                        else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                                        else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                                        else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                                        else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                                        else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                                        else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                                    }
                                    
                                    extension = to_string(newUpperLimit);
                                    
                                    if (queueListCount+12 > queueListLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate queueListUpDate];
                                    }
                                    
                                    arrayQueueList [queueListCount] = treatmentNameHold, queueListCount++;
                                    arrayQueueList [queueListCount] = cellLineageNoHold, queueListCount++;
                                    arrayQueueList [queueListCount] = cellNumberString, queueListCount++;
                                    arrayQueueList [queueListCount] = extension+":"+extension, queueListCount++;
                                    
                                    if (ifSetFlag == 0) arrayQueueList [queueListCount] = "0", queueListCount++;
                                    else arrayQueueList [queueListCount] = "IF", queueListCount++;
                                    
                                    arrayQueueList [queueListCount] = "Wait", queueListCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //	cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            string *queueStringTemp = new string [queueListCount+50];
                            int queueStringTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+1] != cellLineageNoHold || arrayQueueList [counter1*6+2] != cellNoHold){
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                                }
                            }
                            
                            queueListCount = 0;
                            for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
                            
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //	cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                            
                            //-----(Backup create)-----
                            tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~1";
                                remove (tempBackUpPath2.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                tempBackUpPath3 = tempBackUpPath+"~1";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                tempBackUpPath3 = tempBackUpPath+"~2";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                tempBackUpPath3 = tempBackUpPath+"~3";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                tempBackUpPath3 = tempBackUpPath+"~4";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~4";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~3";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~2";
                                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~1";
                                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (queueListCount != 0){
                                mainDataEntry = new char [queueListCount*12+10];
                                totalEntryCount = 0;
                                
                                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                    extension = arrayQueueList [counter1];
                                    
                                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                                outfile3.write (mainDataEntry, totalEntryCount);
                                outfile3.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            delete [] queueStringTemp;
                            
                            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                            //	cout<<" arrayDoneList "<<counterA<<endl;
                            //}
                            
                            string *doneListUpdateTemp = new string [doneListCount+50];
                            int doneListUpdateTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                if (arrayDoneList [counter1*5] != treatmentNameHold || arrayDoneList [counter1*5+1] != cellLineageNoHold || arrayDoneList [counter1*5+2] != cellNoHold){
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                }
                            }
                            
                            extension = to_string(newUpperLimit-1);
                            
                            if (fusionMarkFind == 1){
                                doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellLineageNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+extension, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = "/m", doneListUpdateTempCount++;
                            }
                            else{
                                
                                doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellLineageNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+extension, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = "OK", doneListUpdateTempCount++;
                            }
                            
                            if (doneListUpdateTempCount > doneListLimit){
                                delete [] arrayDoneList;
                                arrayDoneList = new string [doneListUpdateTempCount+500];
                                doneListLimit = doneListUpdateTempCount+500;
                            }
                            
                            doneListCount = 0;
                            
                            for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                            
                            delete [] doneListUpdateTemp;
                            
                            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                            
                            //-----(Backup create)-----
                            tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~1";
                                remove (tempBackUpPath2.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                tempBackUpPath3 = tempBackUpPath+"~1";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                tempBackUpPath3 = tempBackUpPath+"~2";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                tempBackUpPath3 = tempBackUpPath+"~3";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                tempBackUpPath3 = tempBackUpPath+"~4";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~4";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~3";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~2";
                                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~1";
                                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (doneListCount != 0){
                                mainDataEntry = new char [doneListCount*10+10];
                                totalEntryCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                    extension = arrayDoneList [counter1];
                                    
                                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile4 (doneListPath.c_str(), ofstream::binary);
                                outfile4.write (mainDataEntry, totalEntryCount);
                                outfile4.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                            //	cout<<" arrayDoneList "<<counterA<<endl;
                            //}
                            
                            //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                            int numberOfEntry = 0;
                            
                            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp) numberOfEntry++;
                            }
                            
                            string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
                            
                            for (int counter1 = 0; counter1 < cellLineageInfoCount/3; counter1++){
                                if (arrayCellLineageInfo [counter1*3] == lineageAmendTemp){
                                    arrayCellLineageInfo [counter1*3+1] = 0;
                                    arrayCellLineageInfo [counter1*3+2] = numberOfEntry;
                                    break;
                                }
                            }
                            
                            mainDataEntry = new char [cellLineageInfoCount*6+10];
                            totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < cellLineageInfoCount; counter1++){
                                extension = to_string(arrayCellLineageInfo [counter1]);
                                
                                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile5 (connectDataInfoPath.c_str(), ofstream::binary);
                            outfile5.write (mainDataEntry, totalEntryCount);
                            outfile5.close();
                            
                            delete [] mainDataEntry;
                            
                            //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                            //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                            //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                            //}
                        }
                        
                        if (processTypeCell == 3){
                            for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                                if (arrayCellNumberInfo [counter1*7] == cellAmendTemp){
                                    arrayCellNumberInfo [counter1*7+2] = newUpperLimit;
                                    
                                    if (upperLimitEventType == 7) arrayCellNumberInfo [counter1*7+4] = 6;
                                    else if (upperLimitEventType == 8) arrayCellNumberInfo [counter1*7+4] = 9;
                                    else if (upperLimitEventType == 91) arrayCellNumberInfo [counter1*7+4] = 7;
                                    
                                    if (fusionMarkFind == 1 && arrayCellNumberInfo [counter1*7+5] == 0) arrayCellNumberInfo [counter1*7+5] = 77;
                                    else if (fusionMarkFind == 0) arrayCellNumberInfo [counter1*7+5] = 0;
                                }
                                
                                if (fusionLingPartner != 0 && lineageAmendTemp == fusionLingPartner){
                                    if (arrayCellNumberInfo [counter1*7] == fusionCellPartner){
                                        if (fusionMarkPartnerFind == 1){
                                            if (arrayCellNumberInfo [counter1*7+5] == 21) arrayCellNumberInfo [counter1*7+5] = 51;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 22) arrayCellNumberInfo [counter1*7+5] = 52;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 23) arrayCellNumberInfo [counter1*7+5] = 53;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 24) arrayCellNumberInfo [counter1*7+5] = 54;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 25) arrayCellNumberInfo [counter1*7+5] = 55;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 26) arrayCellNumberInfo [counter1*7+5] = 56;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 27) arrayCellNumberInfo [counter1*7+5] = 57;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 28) arrayCellNumberInfo [counter1*7+5] = 58;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 29) arrayCellNumberInfo [counter1*7+5] = 59;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 30) arrayCellNumberInfo [counter1*7+5] = 60;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 31) arrayCellNumberInfo [counter1*7+5] = 61;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 32) arrayCellNumberInfo [counter1*7+5] = 62;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 33) arrayCellNumberInfo [counter1*7+5] = 63;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 34) arrayCellNumberInfo [counter1*7+5] = 64;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 35) arrayCellNumberInfo [counter1*7+5] = 65;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 36) arrayCellNumberInfo [counter1*7+5] = 66;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 37) arrayCellNumberInfo [counter1*7+5] = 67;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 38) arrayCellNumberInfo [counter1*7+5] = 68;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 39) arrayCellNumberInfo [counter1*7+5] = 69;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 40) arrayCellNumberInfo [counter1*7+5] = 70;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 41) arrayCellNumberInfo [counter1*7+5] = 71;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 42) arrayCellNumberInfo [counter1*7+5] = 72;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 43) arrayCellNumberInfo [counter1*7+5] = 73;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 44) arrayCellNumberInfo [counter1*7+5] = 74;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 45) arrayCellNumberInfo [counter1*7+5] = 75;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 46) arrayCellNumberInfo [counter1*7+5] = 76;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 47) arrayCellNumberInfo [counter1*7+5] = 78;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 0) arrayCellNumberInfo [counter1*7+5] = 77;
                                        }
                                        else if (fusionMarkPartnerFind == 0){
                                            if (arrayCellNumberInfo [counter1*7+5] == 51) arrayCellNumberInfo [counter1*7+5] = 21;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 52) arrayCellNumberInfo [counter1*7+5] = 22;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 53) arrayCellNumberInfo [counter1*7+5] = 23;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 54) arrayCellNumberInfo [counter1*7+5] = 24;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 55) arrayCellNumberInfo [counter1*7+5] = 25;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 56) arrayCellNumberInfo [counter1*7+5] = 26;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 57) arrayCellNumberInfo [counter1*7+5] = 27;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 58) arrayCellNumberInfo [counter1*7+5] = 28;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 59) arrayCellNumberInfo [counter1*7+5] = 29;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 60) arrayCellNumberInfo [counter1*7+5] = 30;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 61) arrayCellNumberInfo [counter1*7+5] = 31;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 62) arrayCellNumberInfo [counter1*7+5] = 32;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 63) arrayCellNumberInfo [counter1*7+5] = 33;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 64) arrayCellNumberInfo [counter1*7+5] = 34;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 65) arrayCellNumberInfo [counter1*7+5] = 35;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 66) arrayCellNumberInfo [counter1*7+5] = 36;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 67) arrayCellNumberInfo [counter1*7+5] = 37;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 68) arrayCellNumberInfo [counter1*7+5] = 38;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 69) arrayCellNumberInfo [counter1*7+5] = 39;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 70) arrayCellNumberInfo [counter1*7+5] = 40;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 71) arrayCellNumberInfo [counter1*7+5] = 41;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 72) arrayCellNumberInfo [counter1*7+5] = 42;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 73) arrayCellNumberInfo [counter1*7+5] = 43;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 74) arrayCellNumberInfo [counter1*7+5] = 44;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 75) arrayCellNumberInfo [counter1*7+5] = 45;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 76) arrayCellNumberInfo [counter1*7+5] = 46;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 78) arrayCellNumberInfo [counter1*7+5] = 47;
                                            else if (arrayCellNumberInfo [counter1*7+5] == 77) arrayCellNumberInfo [counter1*7+5] = 0;
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                            //	cout<<" arrayCellNumberInfo "<<counterA<<endl;
                            //}
                            
                            string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_CellStatus";
                            
                            char *mainDataEntry = new char [cellNumberInfoCount*7+10];
                            int totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < cellNumberInfoCount; counter1++){
                                extension = to_string(arrayCellNumberInfo [counter1]);
                                
                                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
                            outfile2.write (mainDataEntry, totalEntryCount);
                            outfile2.close();
                            
                            delete [] mainDataEntry;
                            
                            if (fusionLingPartner != 0 && lineageAmendTemp != fusionLingPartner){
                                string fusionLingString = to_string(fusionLingPartner);
                                
                                if (fusionLingString.length() == 1) fusionLingString = "L0000"+fusionLingString;
                                else if (fusionLingString.length() == 2) fusionLingString = "L000"+fusionLingString;
                                else if (fusionLingString.length() == 3) fusionLingString = "L00"+fusionLingString;
                                else if (fusionLingString.length() == 4) fusionLingString = "L0"+fusionLingString;
                                else if (fusionLingString.length() == 5) fusionLingString = "L"+fusionLingString;
                                
                                string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+fusionLingString+"/"+analysisID+"_"+fusionLingString+"_CellStatus";
                                
                                sizeForCopy = 0;
                                
                                if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    int *arrayCellNumberInfoTemp = new int [sizeForCopy*2+50];
                                    int cellNumberInfoTempCount = 0;
                                    
                                    fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        char *uploadTemp = new char [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        fin.close();
                                        
                                        string dataString = "";
                                        readPosition = 0;
                                        
                                        do{
                                            
                                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                            else{
                                                
                                                if (dataString != "End"){
                                                    arrayCellNumberInfoTemp [cellNumberInfoTempCount] = atoi(dataString.c_str()), cellNumberInfoTempCount++;
                                                    dataString = "";
                                                }
                                            }
                                            
                                            readPosition++;
                                            
                                        } while (dataString != "End");
                                        
                                        delete [] uploadTemp;
                                    }
                                    
                                    //for (int counterA = 0; counterA < cellNumberInfoTempCount/7; counterA++){
                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfoTemp [counterA*7+counterB];
                                    //    cout<<" arrayCellNumberInfoTemp "<<counterA<<endl;
                                    //}
                                    
                                    for (int counter1 = 0; counter1 < cellNumberInfoTempCount/7; counter1++){
                                        if (arrayCellNumberInfoTemp [counter1*7] == fusionCellPartner){
                                            if (fusionMarkPartnerFind == 1){
                                                if (arrayCellNumberInfoTemp [counter1*7+5] == 21) arrayCellNumberInfoTemp [counter1*7+5] = 51;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 22) arrayCellNumberInfoTemp [counter1*7+5] = 52;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 23) arrayCellNumberInfoTemp [counter1*7+5] = 53;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 24) arrayCellNumberInfoTemp [counter1*7+5] = 54;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 25) arrayCellNumberInfoTemp [counter1*7+5] = 55;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 26) arrayCellNumberInfoTemp [counter1*7+5] = 56;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 27) arrayCellNumberInfoTemp [counter1*7+5] = 57;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 28) arrayCellNumberInfoTemp [counter1*7+5] = 58;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 29) arrayCellNumberInfoTemp [counter1*7+5] = 59;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 30) arrayCellNumberInfoTemp [counter1*7+5] = 60;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 31) arrayCellNumberInfoTemp [counter1*7+5] = 61;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 32) arrayCellNumberInfoTemp [counter1*7+5] = 62;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 33) arrayCellNumberInfoTemp [counter1*7+5] = 63;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 34) arrayCellNumberInfoTemp [counter1*7+5] = 64;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 35) arrayCellNumberInfoTemp [counter1*7+5] = 65;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 36) arrayCellNumberInfoTemp [counter1*7+5] = 66;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 37) arrayCellNumberInfoTemp [counter1*7+5] = 67;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 38) arrayCellNumberInfoTemp [counter1*7+5] = 68;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 39) arrayCellNumberInfoTemp [counter1*7+5] = 69;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 40) arrayCellNumberInfoTemp [counter1*7+5] = 70;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 41) arrayCellNumberInfoTemp [counter1*7+5] = 71;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 42) arrayCellNumberInfoTemp [counter1*7+5] = 72;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 43) arrayCellNumberInfoTemp [counter1*7+5] = 73;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 44) arrayCellNumberInfoTemp [counter1*7+5] = 74;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 45) arrayCellNumberInfoTemp [counter1*7+5] = 75;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 46) arrayCellNumberInfoTemp [counter1*7+5] = 76;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 47) arrayCellNumberInfoTemp [counter1*7+5] = 78;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 0) arrayCellNumberInfoTemp [counter1*7+5] = 77;
                                            }
                                            else if (fusionMarkPartnerFind == 0){
                                                if (arrayCellNumberInfoTemp [counter1*7+5] == 51) arrayCellNumberInfoTemp [counter1*7+5] = 21;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 52) arrayCellNumberInfoTemp [counter1*7+5] = 22;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 53) arrayCellNumberInfoTemp [counter1*7+5] = 23;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 54) arrayCellNumberInfoTemp [counter1*7+5] = 24;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 55) arrayCellNumberInfoTemp [counter1*7+5] = 25;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 56) arrayCellNumberInfoTemp [counter1*7+5] = 26;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 57) arrayCellNumberInfoTemp [counter1*7+5] = 27;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 58) arrayCellNumberInfoTemp [counter1*7+5] = 28;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 59) arrayCellNumberInfoTemp [counter1*7+5] = 29;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 60) arrayCellNumberInfoTemp [counter1*7+5] = 30;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 61) arrayCellNumberInfoTemp [counter1*7+5] = 31;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 62) arrayCellNumberInfoTemp [counter1*7+5] = 32;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 63) arrayCellNumberInfoTemp [counter1*7+5] = 33;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 64) arrayCellNumberInfoTemp [counter1*7+5] = 34;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 65) arrayCellNumberInfoTemp [counter1*7+5] = 35;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 66) arrayCellNumberInfoTemp [counter1*7+5] = 36;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 67) arrayCellNumberInfoTemp [counter1*7+5] = 37;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 68) arrayCellNumberInfoTemp [counter1*7+5] = 38;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 69) arrayCellNumberInfoTemp [counter1*7+5] = 39;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 70) arrayCellNumberInfoTemp [counter1*7+5] = 40;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 71) arrayCellNumberInfoTemp [counter1*7+5] = 41;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 72) arrayCellNumberInfoTemp [counter1*7+5] = 42;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 73) arrayCellNumberInfoTemp [counter1*7+5] = 43;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 74) arrayCellNumberInfoTemp [counter1*7+5] = 44;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 75) arrayCellNumberInfoTemp [counter1*7+5] = 45;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 76) arrayCellNumberInfoTemp [counter1*7+5] = 46;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 78) arrayCellNumberInfoTemp [counter1*7+5] = 47;
                                                else if (arrayCellNumberInfoTemp [counter1*7+5] == 77) arrayCellNumberInfoTemp [counter1*7+5] = 0;
                                            }
                                            
                                            break;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < cellNumberInfoTempCount/7; counterA++){
                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfoTemp [counterA*7+counterB];
                                    //    cout<<" arrayCellNumberInfoTemp "<<counterA<<endl;
                                    //}
                                    
                                    char *mainDataEntry2 = new char [cellNumberInfoTempCount*7+10];
                                    int totalEntryCount2 = 0;
                                    
                                    for (int counter1 = 0; counter1 < cellNumberInfoTempCount; counter1++){
                                        extension = to_string(arrayCellNumberInfoTemp [counter1]);
                                        
                                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                            mainDataEntry2 [totalEntryCount2] = (char)extension.at((unsigned long)counter2), totalEntryCount2++;
                                        }
                                        
                                        mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                                    }
                                    
                                    mainDataEntry2 [totalEntryCount2] = 'E', totalEntryCount2++;
                                    mainDataEntry2 [totalEntryCount2] = 'n', totalEntryCount2++;
                                    mainDataEntry2 [totalEntryCount2] = 'd', totalEntryCount2++;
                                    mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                                    
                                    ofstream outfile5 (connectDataStatus2.c_str(), ofstream::binary);
                                    outfile5.write (mainDataEntry2, totalEntryCount2);
                                    outfile5.close();
                                    
                                    delete [] mainDataEntry2;
                                    delete [] arrayCellNumberInfoTemp;
                                }
                            }
                            
                            //=========Queue List creation==========
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //	cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            string *queueStringTemp = new string [queueListCount+50];
                            int queueStringTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+1] != cellLineageNoHold || arrayQueueList [counter1*6+2] != cellNoHold){
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                                }
                            }
                            
                            queueListCount = 0;
                            for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
                            
                            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                            
                            //-----(Backup create)-----
                            tempBackUpPath = backUpTempPath+"/"+"*QueueList.dat";
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~1";
                                remove (tempBackUpPath2.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                tempBackUpPath3 = tempBackUpPath+"~1";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                tempBackUpPath3 = tempBackUpPath+"~2";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                tempBackUpPath3 = tempBackUpPath+"~3";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                tempBackUpPath3 = tempBackUpPath+"~4";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~4";
                                        rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~3";
                                            rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~2";
                                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~1";
                                                rename (queueListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (queueListCount != 0){
                                mainDataEntry = new char [queueListCount*12+10];
                                totalEntryCount = 0;
                                
                                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                                    extension = arrayQueueList [counter1];
                                    
                                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                                outfile3.write (mainDataEntry, totalEntryCount);
                                outfile3.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            delete [] queueStringTemp;
                            
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //	cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                            //	cout<<" arrayDoneList "<<counterA<<endl;
                            //}
                            
                            //=========Done List UpDate==========
                            string *doneListUpdateTemp = new string [doneListCount+50];
                            int doneListUpdateTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                if (arrayDoneList [counter1*5] != treatmentNameHold || arrayDoneList [counter1*5+1] != cellLineageNoHold || arrayDoneList [counter1*5+2] != cellNoHold){
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+1], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+2], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+3], doneListUpdateTempCount++;
                                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter1*5+4], doneListUpdateTempCount++;
                                }
                            }
                            
                            extension = to_string(newUpperLimit);
                            
                            if (fusionMarkFind == 1){
                                doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellLineageNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+extension, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = "/m", doneListUpdateTempCount++;
                            }
                            else{
                                
                                doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellLineageNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = cellNoHold, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = extension+":"+extension, doneListUpdateTempCount++;
                                doneListUpdateTemp [doneListUpdateTempCount] = "OK", doneListUpdateTempCount++;
                            }
                            
                            if (doneListUpdateTempCount > doneListLimit){
                                delete [] arrayDoneList;
                                arrayDoneList = new string [doneListUpdateTempCount+500];
                                doneListLimit = doneListUpdateTempCount+500;
                            }
                            
                            doneListCount = 0;
                            
                            for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
                            
                            delete [] doneListUpdateTemp;
                            
                            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                            
                            //-----(Backup create)-----
                            tempBackUpPath = backUpTempPath+"/"+"*DoneList.dat";
                            tempBackUpPath2 = tempBackUpPath+"~5";
                            
                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                fin.close();
                                
                                tempBackUpPath2 = tempBackUpPath+"~1";
                                remove (tempBackUpPath2.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~2";
                                tempBackUpPath3 = tempBackUpPath+"~1";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~3";
                                tempBackUpPath3 = tempBackUpPath+"~2";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                tempBackUpPath3 = tempBackUpPath+"~3";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                tempBackUpPath2 = tempBackUpPath+"~5";
                                tempBackUpPath3 = tempBackUpPath+"~4";
                                rename (tempBackUpPath2.c_str(), tempBackUpPath3.c_str());
                                
                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                            }
                            else{
                                
                                tempBackUpPath2 = tempBackUpPath+"~4";
                                fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    fin.close();
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~5";
                                    rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                }
                                else{
                                    
                                    tempBackUpPath2 = tempBackUpPath+"~3";
                                    fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        fin.close();
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~4";
                                        rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                    }
                                    else{
                                        
                                        tempBackUpPath2 = tempBackUpPath+"~2";
                                        fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.close();
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~3";
                                            rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                        }
                                        else{
                                            
                                            tempBackUpPath2 = tempBackUpPath+"~1";
                                            fin.open(tempBackUpPath2.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.close();
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~2";
                                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                            else{
                                                
                                                tempBackUpPath2 = tempBackUpPath+"~1";
                                                rename (doneListPath.c_str(), tempBackUpPath2.c_str());
                                            }
                                        }
                                    }
                                }
                            }
                            
                            if (doneListCount != 0){
                                mainDataEntry = new char [doneListCount*10+10];
                                totalEntryCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                                    extension = arrayDoneList [counter1];
                                    
                                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile5 (doneListPath.c_str(), ofstream::binary);
                                outfile5.write (mainDataEntry, totalEntryCount);
                                outfile5.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                            //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                            //	cout<<" arrayDoneList "<<counterA<<endl;
                            //}
                            
                            connectLineListLocalCount = 0;
                            
                            string connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_lineDataAmend";
                            remove (connectAmendPath.c_str());
                            
                            //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                            int numberOfEntry = 0;
                            
                            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp) numberOfEntry++;
                            }
                            
                            int completionCheck = 0;
                            
                            //-----Completion check-----
                            for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                                if (arrayCellNumberInfo [counter1*7+2] == -1){
                                    completionCheck = 1;
                                    break;
                                }
                                else if (arrayCellNumberInfo [counter1*7+4] == 0){
                                    completionCheck = 1;
                                    break;
                                }
                                else if (arrayCellNumberInfo [counter1*7+5] != 0){
                                    completionCheck = 1;
                                    break;
                                }
                            }
                            
                            string connectDataInfoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
                            
                            for (int counter1 = 0; counter1 < cellLineageInfoCount/3; counter1++){
                                if (arrayCellLineageInfo [counter1*3] == lineageAmendTemp){
                                    if (completionCheck == 1) arrayCellLineageInfo [counter1*3+1] = 0;
                                    else if (completionCheck == 0) arrayCellLineageInfo [counter1*3+1] = 1;
                                    
                                    arrayCellLineageInfo [counter1*3+2] = numberOfEntry;
                                    break;
                                }
                            }
                            
                            mainDataEntry = new char [cellLineageInfoCount*6+10];
                            totalEntryCount = 0;
                            
                            for (int counter1 = 0; counter1 < cellLineageInfoCount; counter1++){
                                extension = to_string(arrayCellLineageInfo [counter1]);
                                
                                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile4 (connectDataInfoPath.c_str(), ofstream::binary);
                            outfile4.write (mainDataEntry, totalEntryCount);
                            outfile4.close();
                            
                            delete [] mainDataEntry;
                        }
                        
                        delete [] lineageExtractionTemp;
                        
                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                        //	cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        //-----Mitosis Pattern Save-----
                        if (mitosisImageNo != 0){
                            int saveType = 1;
                            snapShot = [[SnapShot alloc] init];
                            [snapShot snapShotMain:saveType:mitosisImageNo:mitosisLineageNo:mitosisCellNo];
                            
                            mitosisSaveCount++;
                            
                            if (mitosisSaveCount == 16){
                                mitosisSaveCount = 0;
                                
                                int overflowCheck = 0;
                                
                                string mitosisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/"+"Mitosis.dat";
                                
                                if (stat(mitosisPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    int listPointNumberShot = 0;
                                    
                                    int *arrayCellListDisplayTemp = new int [sizeForCopy+50];
                                    int cellListDisplayTempCount = 0;
                                    
                                    fin.open(mitosisPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        fin.close();
                                        
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--2. Entry No
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--5. X Position
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--10. Area
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [5] = finData [4]*256+finData [5];
                                                finData [7] = finData [6]*256+finData [7];
                                                
                                                if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                                                else{
                                                    
                                                    arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [1], cellListDisplayTempCount++;
                                                    arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [3], cellListDisplayTempCount++;
                                                    arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [5], cellListDisplayTempCount++;
                                                    arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [7], cellListDisplayTempCount++;
                                                    
                                                    if (cellListDisplayTempCount > 2100000000){
                                                        overflowCheck = 1;
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        listPointNumberShot = arrayCellListDisplayTemp [(cellListDisplayTempCount/4-1)*4];
                                        
                                        delete [] uploadTemp;
                                    }
                                    
                                    //for (int counterA = 0; counterA < cellListDisplayTempCount/3; counterA++){
                                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< arrayCellListDisplayTemp [counterA*3+counterB];
                                    //    cout<<"  arrayCellListDisplayTemp "<<counterA<<endl;
                                    //}
                                    
                                    if (overflowCheck == 0){
                                        int **duplicateRemoveMap = new int *[101];
                                        int **duplicateRemoveMap2 = new int *[101];
                                        
                                        for (int counter1 = 0; counter1 < 101; counter1++){
                                            duplicateRemoveMap [counter1] = new int [101];
                                            duplicateRemoveMap2 [counter1] = new int [101];
                                        }
                                        
                                        int sequentialStart = 0;
                                        int totalMap1 = 0;
                                        int totalMap2 = 0;
                                        int deleteMap = 0;
                                        
                                        for (int counter1 = 1; counter1 <= listPointNumberShot-1; counter1++){
                                            for (int counterY = 0; counterY < 101; counterY++){
                                                for (int counterX = 0; counterX < 101; counterX++) duplicateRemoveMap [counterY][counterX] = 0;
                                            }
                                            
                                            sequentialStart = 0;
                                            totalMap1 = 0;
                                            
                                            for (int counter2 = 0; counter2 < cellListDisplayTempCount/4; counter2++){
                                                if (arrayCellListDisplayTemp [counter2*4] == counter1 && sequentialStart == 0){
                                                    duplicateRemoveMap [arrayCellListDisplayTemp [counter2*4+2]][arrayCellListDisplayTemp [counter2*4+1]] = 1;
                                                    sequentialStart = 1;
                                                    totalMap1++;
                                                }
                                                else if (arrayCellListDisplayTemp [counter2*4] == counter1 && sequentialStart == 1){
                                                    duplicateRemoveMap [arrayCellListDisplayTemp [counter2*4+2]][arrayCellListDisplayTemp [counter2*4+1]] = 1;
                                                    totalMap1++;
                                                }
                                                else if (arrayCellListDisplayTemp [counter2*4] != counter1 && sequentialStart == 1){
                                                    break;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < 101; counterA++){
                                            //	for (int counterB = 0; counterB < 101; counterB++) cout<<" "<<duplicateRemoveMap [counterA][counterB];
                                            //	cout<<" duplicateRemoveMap "<<counterA<<endl;
                                            //}
                                            
                                            if (totalMap1 != 0){
                                                for (int counter2 = counter1+1; counter2 <= listPointNumberShot; counter2++){
                                                    for (int counterY = 0; counterY < 101; counterY++){
                                                        for (int counterX = 0; counterX < 101; counterX++) duplicateRemoveMap2 [counterY][counterX] = 0;
                                                    }
                                                    
                                                    sequentialStart = 0;
                                                    totalMap2 = 0;
                                                    
                                                    for (int counter3 = 0; counter3 < cellListDisplayTempCount/4; counter3++){
                                                        if (arrayCellListDisplayTemp [counter3*4] == counter2 && sequentialStart == 0){
                                                            duplicateRemoveMap2 [arrayCellListDisplayTemp [counter3*4+2]][arrayCellListDisplayTemp [counter3*4+1]] = 1;
                                                            sequentialStart = 1;
                                                            totalMap2++;
                                                        }
                                                        else if (arrayCellListDisplayTemp [counter3*4] == counter2 && sequentialStart == 1){
                                                            duplicateRemoveMap2 [arrayCellListDisplayTemp [counter3*4+2]][arrayCellListDisplayTemp [counter3*4+1]] = 1;
                                                            totalMap2++;
                                                        }
                                                        else if (arrayCellListDisplayTemp [counter3*4] != counter2 && sequentialStart == 1){
                                                            break;
                                                        }
                                                    }
                                                    
                                                    //for (int counterA = 0; counterA < 101; counterA++){
                                                    //    for (int counterB = 0; counterB < 101; counterB++) cout<<" "<<duplicateRemoveMap2 [counterA][counterB];
                                                    //    cout<<" duplicateRemoveMap2 "<<counterA<<endl;
                                                    //}
                                                    
                                                    deleteMap = 0;
                                                    
                                                    for (int counterY = 0; counterY < 101; counterY++){
                                                        for (int counterX = 0; counterX < 101; counterX++){
                                                            if (duplicateRemoveMap [counterY][counterX] != 0 && duplicateRemoveMap2 [counterY][counterX] != 0) deleteMap++;
                                                        }
                                                    }
                                                    
                                                    if (deleteMap/(double)totalMap2 > 0.95 && deleteMap/(double)totalMap1 > 0.95){
                                                        for (int counter3 = 0; counter3 < cellListDisplayTempCount/4; counter3++){
                                                            if (arrayCellListDisplayTemp [counter3*4] == counter2) arrayCellListDisplayTemp [counter3*4] = 0;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        for (int counter1 = 0; counter1 < 101; counter1++){
                                            delete [] duplicateRemoveMap [counter1];
                                            delete [] duplicateRemoveMap2 [counter1];
                                        }
                                        
                                        delete [] duplicateRemoveMap;
                                        delete [] duplicateRemoveMap2;
                                        
                                        int *arrayCellListDisplayTemp2 = new int [cellListDisplayTempCount+50];
                                        int cellListDisplayTempCount2 = 0;
                                        
                                        int sequentialNumber = 0;
                                        int sequentialPosition = 0;
                                        
                                        for (int counter1 = 0; counter1 < cellListDisplayTempCount/4; counter1++){
                                            if (arrayCellListDisplayTemp [counter1*3] != 0){
                                                if (sequentialNumber != arrayCellListDisplayTemp [counter1*4]){
                                                    sequentialNumber = arrayCellListDisplayTemp [counter1*4];
                                                    sequentialPosition++;
                                                }
                                                
                                                arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = sequentialPosition, cellListDisplayTempCount2++;
                                                arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+1], cellListDisplayTempCount2++;
                                                arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+2], cellListDisplayTempCount2++;
                                                arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+3], cellListDisplayTempCount2++;
                                            }
                                        }
                                        
                                        writingArray = new char [cellListDisplayTempCount2*2+20];
                                        
                                        indexCount = 0;
                                        
                                        for (int counter1 = 0; counter1 < cellListDisplayTempCount2/4; counter1++){
                                            dataTemp = arrayCellListDisplayTemp2 [counter1*4];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = arrayCellListDisplayTemp2 [counter1*4+1];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = arrayCellListDisplayTemp2 [counter1*4+2];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = arrayCellListDisplayTemp2 [counter1*4+3];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        }
                                        
                                        for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile2 (mitosisPath.c_str(), ofstream::binary);
                                        outfile2.write ((char*) writingArray, indexCount);
                                        outfile2.close();
                                        
                                        delete [] writingArray;
                                        delete [] arrayCellListDisplayTemp2;
                                    }
                                    
                                    delete [] arrayCellListDisplayTemp;
                                }
                            }
                        }
                        
                        //=======Lineage partner line=======
                        string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_FusionPartner";
                        
                        sizeForCopy = 0;
                        
                        if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                            
                            string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                            int lineagePartnerInfoTempCount = 0;
                            
                            string *arrayLineagePartnerInfoTemp2 = new string [sizeForCopy+50];
                            int lineagePartnerInfoTempCount2 = 0;
                            
                            fin.open(cellFusionPartnerPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                string treatmentNameGet;
                                string lineageNoGet;
                                string cellNoGet;
                                string imageNoGet;
                                string partnerLingNoGet;
                                string partnerCellNoGet;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    getline(fin, treatmentNameGet);
                                    
                                    if (treatmentNameGet == "") terminationFlag = 0;
                                    else{
                                        
                                        getline(fin, lineageNoGet);
                                        getline(fin, cellNoGet);
                                        getline(fin, imageNoGet);
                                        getline(fin, partnerLingNoGet);
                                        getline(fin, partnerCellNoGet);
                                        
                                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                                    }
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                            }
                            
                            string lingNoTemp;
                            string cellNoTemp;
                            string imageNoTemp;
                            
                            int lineageTempInt = 0;
                            int cellNoTempInt = 0;
                            int timePointTempInt = 0;
                            
                            for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                                if (arrayLineageData [counter1*8+3] == 10){
                                    lineageTempInt = arrayLineageData [counter1*8+6];
                                    cellNoTempInt = arrayLineageData [counter1*8+5];
                                    timePointTempInt = arrayLineageData [counter1*8+2];
                                    
                                    for (int counter2 = 0; counter2 < lineagePartnerInfoTempCount/6; counter2++){
                                        lingNoTemp = arrayLineagePartnerInfoTemp [counter2*6+1];
                                        cellNoTemp = arrayLineagePartnerInfoTemp [counter2*6+2];
                                        imageNoTemp = arrayLineagePartnerInfoTemp [counter2*6+3];
                                        
                                        if (arrayLineagePartnerInfoTemp [counter2*6] == treatmentNameHold && atoi(lingNoTemp.c_str()) == lineageTempInt && atoi(cellNoTemp.c_str()) == cellNoTempInt && atoi(imageNoTemp.c_str()) == timePointTempInt){
                                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6], lineagePartnerInfoTempCount2++;
                                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+1], lineagePartnerInfoTempCount2++;
                                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+2], lineagePartnerInfoTempCount2++;
                                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+3], lineagePartnerInfoTempCount2++;
                                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+4], lineagePartnerInfoTempCount2++;
                                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+5], lineagePartnerInfoTempCount2++;
                                        }
                                    }
                                }
                            }
                            
                            if (lineagePartnerInfoTempCount2 != 0){
                                ofstream oin;
                                oin.open(cellFusionPartnerPath.c_str(), ios::out);
                                
                                for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) oin<<arrayLineagePartnerInfoTemp2 [counter1]<<endl;
                                
                                oin.close();
                            }
                            else remove (cellFusionPartnerPath.c_str());
                            
                            delete [] arrayLineagePartnerInfoTemp;
                            delete [] arrayLineagePartnerInfoTemp2;
                        }
                        
                        //=======Mitosis Set array=======
                        string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_MitosisData";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        
                        for (int counter1 = 0; counter1 < 6; counter1++){
                            sizeForCopy = 0;
                            
                            if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter1 == 0) size1 = sizeForCopy;
                                else if (counter1 == 1) size2 = sizeForCopy;
                                else if (counter1 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter1 == 3) size1 = sizeForCopy;
                                else if (counter1 == 4) size2 = sizeForCopy;
                                else if (counter1 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        if (checkFlag == 1){
                            if (processTypeCell == 3 || processTypeCell == 2){
                                int *arrayMitosisTemp = new int [sizeForCopy+50];
                                int mitosisTempCount = 0;
                                int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                                int mitosisTempCount2 = 0;
                                
                                fin.open(mitosisStatusPath.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    string lineageNoGet;
                                    string cellNoGet;
                                    string imageNoGet;
                                    string setTypeGet;
                                    
                                    do{
                                        
                                        terminationFlag = 1;
                                        getline(fin, lineageNoGet);
                                        
                                        if (lineageNoGet == "") terminationFlag = 0;
                                        else{
                                            
                                            getline(fin, cellNoGet);
                                            getline(fin, imageNoGet);
                                            getline(fin, setTypeGet);
                                            
                                            arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                            arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                            arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                            arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                        }
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < mitosisTempCount/4; counterA++){
                                //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp [counterA*4+counterB];
                                //	cout<<" arrayMitosisTemp "<<counterA<<endl;
                                //}
                                
                                for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                                    if (arrayMitosisTemp [counter1*4] != lineageAmendTemp || arrayMitosisTemp [counter1*4+1] != cellAmendTemp){
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                                        arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                                //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                                //	cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                                //}
                                
                                if (mitosisTempCount2 != 0){
                                    ofstream oin;
                                    oin.open(mitosisStatusPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                                    
                                    oin.close();
                                }
                                else remove (mitosisStatusPath.c_str());
                                
                                delete [] arrayMitosisTemp;
                                delete [] arrayMitosisTemp2;
                            }
                        }
                        
                        if (processTypeCell == 1){
                            int mitosisSetFind = 0;
                            int lineageFirstPoint = 0;
                            int lineageLastPoint = 0;
                            
                            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
                            //	cout<<" arrayLineageData "<<counterA<<endl;
                            //}
                            
                            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                                    for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                        if (arrayLineageData [counter2*8+3] == 6) mitosisSetFind = arrayLineageData [counter2*8+2];
                                        if (lineageLastPoint < arrayLineageData [counter2*8+2]) lineageLastPoint = arrayLineageData [counter2*8+2];
                                        if (lineageFirstPoint == 0) lineageFirstPoint = arrayLineageData [counter2*8+2];
                                    }
                                }
                            }
                            
                            //cout<<mitosisSetFind<<" "<<lineageFirstPoint<<" "<<lineageLastPoint <<" LineageEnd"<<endl;
                            
                            int *arrayMitosisTemp = new int [sizeForCopy+50];
                            int mitosisTempCount = 0;
                            int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                            int mitosisTempCount2 = 0;
                            int *arrayMitosisTemp3 = new int [sizeForCopy+50];
                            int mitosisTempCount3 = 0;
                            
                            fin.open(mitosisStatusPath.c_str(), ios::in);
                            
                            if (fin.is_open()){
                                string lineageNoGet;
                                string cellNoGet;
                                string imageNoGet;
                                string setTypeGet;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    getline(fin, lineageNoGet);
                                    
                                    if (lineageNoGet == "") terminationFlag = 0;
                                    else{
                                        
                                        getline(fin, cellNoGet);
                                        getline(fin, imageNoGet);
                                        getline(fin, setTypeGet);
                                        
                                        arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                        arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                        arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                        arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                    }
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                            }
                            
                            //for (int counterA = 0; counterA < mitosisTempCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp [counterA*4+counterB];
                            //    cout<<" arrayMitosisTemp "<<counterA<<endl;
                            //}
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                                if (arrayMitosisTemp [counter1*4] != lineageAmendTemp || arrayMitosisTemp [counter1*4+1] != cellAmendTemp){
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                                }
                                else{
                                    
                                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4], mitosisTempCount3++;
                                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+1], mitosisTempCount3++;
                                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+2], mitosisTempCount3++;
                                    arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+3], mitosisTempCount3++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                            //    cout<<" arrayMitosisTempe2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < mitosisTempCount3/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp3 [counterA*4+counterB];
                            //    cout<<" arrayMitosisTempe3 "<<counterA<<endl;
                            //}
                            
                            int *arrayMitosisTemp4 = new int [(lineageLastPoint-lineageFirstPoint+1)*4+50];
                            int mitosisTempCount4 = 0;
                            
                            for (int counter1 = lineageFirstPoint; counter1 <= lineageLastPoint; counter1++){
                                arrayMitosisTemp4 [mitosisTempCount4] = lineageAmendTemp, mitosisTempCount4++;
                                arrayMitosisTemp4 [mitosisTempCount4] = cellAmendTemp, mitosisTempCount4++;
                                arrayMitosisTemp4 [mitosisTempCount4] = counter1, mitosisTempCount4++;
                                
                                if (mitosisSetFind != 0 && mitosisSetFind == counter1){
                                    arrayMitosisTemp4 [mitosisTempCount4] = 10, mitosisTempCount4++;
                                }
                                else arrayMitosisTemp4 [mitosisTempCount4] = 0, mitosisTempCount4++;
                            }
                            
                            if (mitosisSetFind == 0){
                                int prevFirstPoint = 0;
                                int prevLastPoint = 0;
                                
                                for (int counter1 = 0; counter1 < mitosisTempCount3/4; counter1++){
                                    if (prevFirstPoint == 0) prevFirstPoint = arrayMitosisTemp3 [counter1*4+2];
                                    
                                    prevLastPoint = arrayMitosisTemp3 [counter1*4+2];
                                }
                                
                                if (prevFirstPoint < lineageFirstPoint) prevFirstPoint = lineageFirstPoint;
                                if (prevLastPoint > lineageLastPoint) prevLastPoint = lineageLastPoint;
                                if (prevFirstPoint > lineageLastPoint || prevLastPoint < lineageFirstPoint) prevFirstPoint = 0;
                                
                                if (prevFirstPoint != 0){
                                    int prevFind = 0;
                                    int prevCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < mitosisTempCount4/4; counter1++){
                                        if (prevLastPoint > prevFirstPoint){
                                            if (arrayMitosisTemp4 [counter1*4+2] == prevFirstPoint){
                                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                
                                                arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                                prevFind = 1;
                                                prevCount++;
                                            }
                                            else if (arrayMitosisTemp4 [counter1*4+2] == prevLastPoint){
                                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                
                                                arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                                prevFind = 0;
                                            }
                                            else if (prevFind == 1){
                                                if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                                
                                                arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                                prevCount++;
                                            }
                                        }
                                        
                                        if (arrayMitosisTemp4 [counter1*4] == prevFirstPoint && prevLastPoint == prevFirstPoint){
                                            if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                            
                                            arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                            //    cout<<" arrayMitosisTempe2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < mitosisTempCount4/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp4 [counterA*4+counterB];
                            //    cout<<" arrayMitosisTempe4 "<<counterA<<endl;
                            //}
                            
                            ofstream oin;
                            oin.open(mitosisStatusPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount4; counter1++) oin<<arrayMitosisTemp4 [counter1]<<endl;
                            
                            oin.close();
                            
                            delete [] arrayMitosisTemp;
                            delete [] arrayMitosisTemp2;
                            delete [] arrayMitosisTemp3;
                            delete [] arrayMitosisTemp4;
                        }
                        
                        revisedWorkingMapTime2 = 0;
                        cellLineageInfoListCreationCall = 5;
                        cellNumberInfoListCreationCall = 5;
                        
                        if (recordType == 2 && (processTypeCell == 2 || processTypeCell == 3)) returnResults = 30;
                        else{
                            
                            returnResults = 1;
                            
                            if (recordType == 1){
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Data Deletion Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    if (warningType2 == 1){
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Multiple Mitoses Detected"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        if (recordType != 2){
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Set Mitosis Needed"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        else returnResults = 20;
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Lineage Data Fault"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            delete [] arrayLineageExtraction;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Event Sequence Issue or Use Add/Remove"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    delete [] arrayEventSequenceReorganize;
    
    return returnResults;
}

@end
