//
// TrackingDataSave.h
// Cell_Tracking
//
// Created by Masahiko Sato on 13/10/02.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGDATASAVE_H
#define TRACKINGDATASAVE_H
#import "Controller.h" 
#endif

@interface TrackingDataSave : NSObject {
    id dataSaveRead;
}

-(int)trackingDataSaveTemp:(int)saveTypeDef :(int)fluorescentStatus :(int)gravityCenterCheckMode;

@end
