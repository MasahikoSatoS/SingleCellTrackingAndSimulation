//
//  FluorescentQuantitationTable.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 3/12/17.
//
//

#ifndef FLUORESCENTQUANTITATIONCONTROLLER_H
#define FLUORESCENTQUANTITATIONCONTROLLER_H
#import "Controller.h" 
#endif

@interface FluorescentQuantitationTable : NSObject<NSTableViewDataSource>{
    int fluorescentOperationTableCount; //Fluorescent table count
    int rowfluorescentOperationTable; //Fluorescent row
    
    IBOutlet NSTableView *fluorescentQuantOpTableControle;
    
    NSTimer *fluorescentQuantOpTableTimer;
}

-(id)init;
-(void)dealloc;
-(void)display;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
