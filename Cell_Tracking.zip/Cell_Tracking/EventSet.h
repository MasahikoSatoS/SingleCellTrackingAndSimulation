//
// EventSet.h
// Cell_Tracking
//
// Created by Masahiko Sato on 12/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef EVENTSET_H
#define EVENTSET_H
#import "Controller.h"
#endif

@interface EventSet : NSObject {
    id mitosisSD;
}

-(void)mitosisSet;
-(void)cellDeathSet;
-(int)bipolarDivisionSet;
-(int)tripolarDivisionSet;
-(int)tetrapolarDivisionSet;
-(int)cellFusionSet;
-(void)fusionMarkSet;
-(void)impartialMitosisSet;
-(void)correctionSet;
-(void)outOfFrameSet;
-(int)primaryAddition;
-(int)primarySubtract;
-(int)secondaryAddition;
-(int)secondarySubtract;

@end
