//
//  Controller2.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#ifndef CONTROLLER2_H
#define CONTROLLER2_H
#import "Controller.h"
#endif

@interface Controller2 : NSObject{
    IBOutlet NSTextField *autoExpandDisplay;
    IBOutlet NSTextField *fluorescentQuantDivNoDisplay;
    IBOutlet NSTextField *fluorescentQuantStatusDisplay;
    IBOutlet NSTextField *phaseStatusDisplay;
    
    IBOutlet NSStepper *stepperFluorescentSetCount;
    
    id folderCopy;
    id fileUpdate;
    id dataSaveRead;
    id tiffFileRead;
}

-(void)fileReQuantConstruct:(int)quantConst;

-(IBAction)restorePreviousData:(id)sender;
-(IBAction)deletePreviousData:(id)sender;

-(IBAction)databaseRepairStart:(id)sender;

-(IBAction)lineWidthSet1:(id)sender;
-(IBAction)lineWidthSet2:(id)sender;
-(IBAction)lineWidthSet3:(id)sender;
-(IBAction)lineWidthSet4:(id)sender;
-(IBAction)lineTypeFine:(id)sender;
-(IBAction)lineTypeNormal:(id)sender;

-(IBAction)fluorescentOptionStart:(id)sender;
-(IBAction)stepperFluorescentDivSet:(id)sender;
-(IBAction)autoExpandSet:(id)sender;
-(IBAction)fluorescentOptionSet:(id)sender;
-(IBAction)fluorescentUpDate:(id)sender;
-(IBAction)fluorescentSave:(id)sender;
-(IBAction)fluorescentReQuantitation:(id)sender;
-(IBAction)fluorescentReConstruct:(id)sender;
-(IBAction)fluorescentApplyAll:(id)sender;

-(IBAction)imageExportStart:(id)sender;
-(IBAction)phaseStatusSet:(id)sender;

-(IBAction)saveAsAnalysis:(id)sender;
-(IBAction)patternRegister:(id)sender;
-(IBAction)toolParameterSet:(id)sender;

@end
