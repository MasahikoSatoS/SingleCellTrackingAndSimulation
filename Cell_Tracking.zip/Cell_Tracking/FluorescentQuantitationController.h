//
//  FluorescentQuantitationController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 3/12/17.
//
//

#ifndef FLUORESCENTQUANTITATIONCONTROLLER_H
#define FLUORESCENTQUANTITATIONCONTROLLER_H
#import "Controller.h" 
#endif

@interface FluorescentQuantitationController : NSObject{
    IBOutlet NSWindow *fluorescentQuantOptionsWindow;
    
    NSWindowController *fluorescentQuantOptionsController;
    
    NSTimer *fluorescentQuantOptionsTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;
-(IBAction)mergeOpData:(id)sender;
-(IBAction)restoreOriginalData:(id)sender;
-(IBAction)clearSelectedData:(id)sender;

@end
