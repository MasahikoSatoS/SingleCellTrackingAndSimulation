//
// Cleaning.h
// Cell_Tracking
//
// Created by Masahiko Sato on 15/11/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef CLEANING_H
#define CLEANING_H
#import "Controller.h" 
#endif

@interface Cleaning : NSObject {
    id fileUpdate;
}

-(void)cleaningMain;

@end
