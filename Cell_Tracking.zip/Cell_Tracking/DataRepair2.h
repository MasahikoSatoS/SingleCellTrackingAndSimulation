//
//  DataRepair2.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#ifndef DATABASEREPAIR2_H
#define DATABASEREPAIR2_H
#import "Controller.h"
#endif

@interface DataRepair2 : NSObject{
    id fileUpdate;
    id dataRepairReadWrite;
    id dataRepairProcess;
}

-(void)dataProcessRepair3;

-(IBAction)dataRepair3:(id)sender;
-(IBAction)dataRepair4:(id)sender;

@end
