//
//  DatabaseLineListTable.h
//  Cell_Tracking
//
//  Created by Imaging on 2019-06-13.
//

#ifndef DATABASELINELISTTABLE_H
#define DATABASELINELISTTABLE_H
#import "Controller.h" 
#endif

@interface DatabaseLineListTable : NSObject<NSTableViewDataSource>{
    int repairListTableCount; //List count
    int rowRepairListTable; //List table Row
    
    IBOutlet NSTableView *tableViewDatabaseList;
    
    NSTimer *databaseListDisplayTimer;
}

-(id)init;
-(void)dealloc;
-(void)display;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
