//
// EventSet.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 12/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "EventSet.h"

@implementation EventSet

//-----LINE DATA AMEND-----
//-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
//-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
//-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----

-(void)mitosisSet{
    int findFlag = 0;
    int impartialMitosisFind = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
        if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 11) impartialMitosisFind = 1;
    }
    
    if (findFlag == 1){
        if (impartialMitosisFind == 0){
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //    cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                    arrayEventSequence [counter1*4+1] = 6;
                    break;
                }
            }
            
            eventSequenceHoldCount = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                }
            }
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //    cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            divisionWarning = "MI_Set";
            divisionWarningType = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Found IP After This Time Point"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)cellDeathSet{
    int findFlag = 0;
    int divisionFusionFindFag = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33)) divisionFusionFindFag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44)) divisionFusionFindFag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55)) divisionFusionFindFag = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 91) divisionFusionFindFag = 1;
    }
    
    if (findFlag == 1){
        if (divisionFusionFindFag == 0){
            trackingUpperLimit = imageNumberTrackForDisplay;
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4+1] = 7;
                if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] > imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
            }
            
            string timeString = to_string(imageNumberTrackForDisplay);
            
            if (timeString.length() == 1) timeString = "000"+timeString;
            else if (timeString.length() == 2) timeString = "00"+timeString;
            else if (timeString.length() == 3) timeString = "0"+timeString;
            
            string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTemp";
            string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTempD";
            
            int entryDataCheck = 0;
            
            ifstream fin;
            fin.open(connectDataTempPath.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            fin.open(connectDataTempPathDummy.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            if (entryDataCheck == 1) overTimeRemoveFlag = 1;
            
            eventSequenceHoldCount = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                }
            }
            
            lineageGravityCenterCurrentHoldCount = 0;
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay){
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4], lineageGravityCenterCurrentHoldCount++;
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+1], lineageGravityCenterCurrentHoldCount++;
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+2], lineageGravityCenterCurrentHoldCount++;
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+3], lineageGravityCenterCurrentHoldCount++;
                }
            }
            
            //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
            //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
            //	cout<<" arrayEventSequence "<<counterA<<endl;
            //}
            
            trackingOnInfoDisplay = 1;
            divisionWarning = "CD_Set";
            divisionWarningType = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Found Division or Fusion: Use Save-Rmv to Create New End, Then Set CD"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)bipolarDivisionSet{
    int findFlag = 0;
    int mitosisFind = 0;
    int otherDivFind = 0;
    int onePrevious = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 6) mitosisFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1 && arrayEventSequence [counter1*4+1] != 2) onePrevious = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 91) otherDivFind = 1;
    }
    
    if (findFlag == 1){
        if (mitosisFind == 1 && otherDivFind == 0 && onePrevious == 0){
            int newCellNumber1 = [self primaryAddition];
            int newCellNumber2 = [self primarySubtract];
            
            string extension1 = to_string(newCellNumber1);
            string extension2 = to_string(newCellNumber2);
            
            if (newCellNumber1 >= 0){
                if (extension1.length() == 1) extension1 = "C00000000"+extension1;
                else if (extension1.length() == 2) extension1 = "C0000000"+extension1;
                else if (extension1.length() == 3) extension1 = "C000000"+extension1;
                else if (extension1.length() == 4) extension1 = "C00000"+extension1;
                else if (extension1.length() == 5) extension1 = "C0000"+extension1;
                else if (extension1.length() == 6) extension1 = "C000"+extension1;
                else if (extension1.length() == 7) extension1 = "C00"+extension1;
                else if (extension1.length() == 8) extension1 = "C0"+extension1;
                else if (extension1.length() == 9) extension1 = "C"+extension1;
            }
            if (newCellNumber1 < 0){
                extension1 = extension1.substr(1);
                if (extension1.length() == 1) extension1 = "C-00000000"+extension1;
                else if (extension1.length() == 2) extension1 = "C-0000000"+extension1;
                else if (extension1.length() == 3) extension1 = "C-000000"+extension1;
                else if (extension1.length() == 4) extension1 = "C-00000"+extension1;
                else if (extension1.length() == 5) extension1 = "C-0000"+extension1;
                else if (extension1.length() == 6) extension1 = "C-000"+extension1;
                else if (extension1.length() == 7) extension1 = "C-00"+extension1;
                else if (extension1.length() == 8) extension1 = "C-0"+extension1;
                else if (extension1.length() == 9) extension1 = "C-"+extension1;
            }
            if (newCellNumber2 >= 0){
                if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C000"+extension2;
                else if (extension2.length() == 7) extension2 = "C00"+extension2;
                else if (extension2.length() == 8) extension2 = "C0"+extension2;
                else if (extension2.length() == 9) extension2 = "C"+extension2;
            }
            if (newCellNumber2 < 0){
                extension2 = extension2.substr(1);
                if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                else if (extension2.length() == 9) extension2 = "C-"+extension2;
            }
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] > imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
            }
            
            string timeString = to_string(imageNumberTrackForDisplay);
            
            if (timeString.length() == 1) timeString = "000"+timeString;
            else if (timeString.length() == 2) timeString = "00"+timeString;
            else if (timeString.length() == 3) timeString = "0"+timeString;
            
            string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTemp";
            string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTempD";
            
            int entryDataCheck = 0;
            
            ifstream fin;
            fin.open(connectDataTempPath.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            fin.open(connectDataTempPathDummy.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            if (entryDataCheck == 1) overTimeRemoveFlag = 1;
            
            cellNoHoldDiv1 = extension1;
            cellNoHoldDiv2 = extension2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            if (otherDivFind == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Found Another Division"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0; //-----Other Division Fusion Find-----
            }
            else if (mitosisFind == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mitosis Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0; //-----Mitosis Absent-----
            }
            else if (onePrevious == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"BD End Occupied"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0; //-----BD end position Overlap with others-----
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"BD Set Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //	cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    return findFlag;
}

-(int)tripolarDivisionSet{
    int findFlag = 0;
    int mitosisFind = 0;
    int otherDivFind = 0;
    int onePrevious = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 6) mitosisFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1 && arrayEventSequence [counter1*4+1] != 2) onePrevious = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 91) otherDivFind = 1;
    }
    
    if (findFlag == 1){
        if (mitosisFind == 1 && otherDivFind == 0 && onePrevious == 0){
            int newCellNumber1 = [self primaryAddition];
            int newCellNumber2 = [self primarySubtract];
            int newCellNumber3 = [self secondaryAddition];
            
            string extension1 = to_string(newCellNumber1);
            string extension2 = to_string(newCellNumber2);
            string extension3 = to_string(newCellNumber3);
            
            if (newCellNumber1 >= 0){
                if (extension1.length() == 1) extension1 = "C00000000"+extension1;
                else if (extension1.length() == 2) extension1 = "C0000000"+extension1;
                else if (extension1.length() == 3) extension1 = "C000000"+extension1;
                else if (extension1.length() == 4) extension1 = "C00000"+extension1;
                else if (extension1.length() == 5) extension1 = "C0000"+extension1;
                else if (extension1.length() == 6) extension1 = "C000"+extension1;
                else if (extension1.length() == 7) extension1 = "C00"+extension1;
                else if (extension1.length() == 8) extension1 = "C0"+extension1;
                else if (extension1.length() == 9) extension1 = "C"+extension1;
            }
            if (newCellNumber1 < 0){
                extension1 = extension1.substr(1);
                if (extension1.length() == 1) extension1 = "C-00000000"+extension1;
                else if (extension1.length() == 2) extension1 = "C-0000000"+extension1;
                else if (extension1.length() == 3) extension1 = "C-000000"+extension1;
                else if (extension1.length() == 4) extension1 = "C-00000"+extension1;
                else if (extension1.length() == 5) extension1 = "C-0000"+extension1;
                else if (extension1.length() == 6) extension1 = "C-000"+extension1;
                else if (extension1.length() == 7) extension1 = "C-00"+extension1;
                else if (extension1.length() == 8) extension1 = "C-0"+extension1;
                else if (extension1.length() == 9) extension1 = "C-"+extension1;
            }
            if (newCellNumber2 >= 0){
                if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C000"+extension2;
                else if (extension2.length() == 7) extension2 = "C00"+extension2;
                else if (extension2.length() == 8) extension2 = "C0"+extension2;
                else if (extension2.length() == 9) extension2 = "C"+extension2;
            }
            if (newCellNumber2 < 0){
                extension2 = extension2.substr(1);
                if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                else if (extension2.length() == 9) extension2 = "C-"+extension2;
            }
            if (newCellNumber3 >= 0){
                if (extension3.length() == 1) extension3 = "C00000000"+extension3;
                else if (extension3.length() == 2) extension3 = "C0000000"+extension3;
                else if (extension3.length() == 3) extension3 = "C000000"+extension3;
                else if (extension3.length() == 4) extension3 = "C00000"+extension3;
                else if (extension3.length() == 5) extension3 = "C0000"+extension3;
                else if (extension3.length() == 6) extension3 = "C000"+extension3;
                else if (extension3.length() == 7) extension3 = "C00"+extension3;
                else if (extension3.length() == 8) extension3 = "C0"+extension3;
                else if (extension3.length() == 9) extension3 = "C"+extension3;
            }
            if (newCellNumber3 < 0){
                extension3 = extension3.substr(1);
                if (extension3.length() == 1) extension3 = "C-00000000"+extension3;
                else if (extension3.length() == 2) extension3 = "C-0000000"+extension3;
                else if (extension3.length() == 3) extension3 = "C-000000"+extension3;
                else if (extension3.length() == 4) extension3 = "C-00000"+extension3;
                else if (extension3.length() == 5) extension3 = "C-0000"+extension3;
                else if (extension3.length() == 6) extension3 = "C-000"+extension3;
                else if (extension3.length() == 7) extension3 = "C-00"+extension3;
                else if (extension3.length() == 8) extension3 = "C-0"+extension3;
                else if (extension3.length() == 9) extension3 = "C-"+extension3;
            }
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] > imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
            }
            
            string timeString = to_string(imageNumberTrackForDisplay);
            
            if (timeString.length() == 1) timeString = "000"+timeString;
            else if (timeString.length() == 2) timeString = "00"+timeString;
            else if (timeString.length() == 3) timeString = "0"+timeString;
            
            string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTemp";
            string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTempD";
            
            int entryDataCheck = 0;
            
            ifstream fin;
            fin.open(connectDataTempPath.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            fin.open(connectDataTempPathDummy.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            if (entryDataCheck == 1) overTimeRemoveFlag = 1;
            
            cellNoHoldDiv1 = extension1;
            cellNoHoldDiv2 = extension2;
            cellNoHoldDiv3 = extension3;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            if (otherDivFind == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Found Another Division"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
            else if (mitosisFind == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mitosis Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
            else if (onePrevious == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"TD End Occupied"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0; //-----BD end position Overlap with others-----
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"TD Set Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return findFlag;
}

-(int)tetrapolarDivisionSet{
    int findFlag = 0;
    int mitosisFind = 0;
    int otherDivFind = 0;
    int onePrevious = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55)) otherDivFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 6) mitosisFind = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1 && arrayEventSequence [counter1*4+1] != 2) onePrevious = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 91) otherDivFind = 1;
    }
    
    if (findFlag == 1){
        if (mitosisFind == 1 && otherDivFind == 0 && onePrevious == 0){
            int newCellNumber1 = [self primaryAddition];
            int newCellNumber2 = [self primarySubtract];
            int newCellNumber3 = [self secondaryAddition];
            int newCellNumber4 = [self secondarySubtract];
            
            string extension1 = to_string(newCellNumber1);
            string extension2 = to_string(newCellNumber2);
            string extension3 = to_string(newCellNumber3);
            string extension4 = to_string(newCellNumber4);
            
            if (newCellNumber1 >= 0){
                if (extension1.length() == 1) extension1 = "C00000000"+extension1;
                else if (extension1.length() == 2) extension1 = "C0000000"+extension1;
                else if (extension1.length() == 3) extension1 = "C000000"+extension1;
                else if (extension1.length() == 4) extension1 = "C00000"+extension1;
                else if (extension1.length() == 5) extension1 = "C0000"+extension1;
                else if (extension1.length() == 6) extension1 = "C000"+extension1;
                else if (extension1.length() == 7) extension1 = "C00"+extension1;
                else if (extension1.length() == 8) extension1 = "C0"+extension1;
                else if (extension1.length() == 9) extension1 = "C"+extension1;
            }
            if (newCellNumber1 < 0){
                extension1 = extension1.substr(1);
                if (extension1.length() == 1) extension1 = "C-00000000"+extension1;
                else if (extension1.length() == 2) extension1 = "C-0000000"+extension1;
                else if (extension1.length() == 3) extension1 = "C-000000"+extension1;
                else if (extension1.length() == 4) extension1 = "C-00000"+extension1;
                else if (extension1.length() == 5) extension1 = "C-0000"+extension1;
                else if (extension1.length() == 6) extension1 = "C-000"+extension1;
                else if (extension1.length() == 7) extension1 = "C-00"+extension1;
                else if (extension1.length() == 8) extension1 = "C-0"+extension1;
                else if (extension1.length() == 9) extension1 = "C-"+extension1;
            }
            if (newCellNumber2 >= 0){
                if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C000"+extension2;
                else if (extension2.length() == 7) extension2 = "C00"+extension2;
                else if (extension2.length() == 8) extension2 = "C0"+extension2;
                else if (extension2.length() == 9) extension2 = "C"+extension2;
            }
            if (newCellNumber2 < 0){
                extension2 = extension2.substr(1);
                if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                else if (extension2.length() == 9) extension2 = "C-"+extension2;
            }
            if (newCellNumber3 >= 0){
                if (extension3.length() == 1) extension3 = "C00000000"+extension3;
                else if (extension3.length() == 2) extension3 = "C0000000"+extension3;
                else if (extension3.length() == 3) extension3 = "C000000"+extension3;
                else if (extension3.length() == 4) extension3 = "C00000"+extension3;
                else if (extension3.length() == 5) extension3 = "C0000"+extension3;
                else if (extension3.length() == 6) extension3 = "C000"+extension3;
                else if (extension3.length() == 7) extension3 = "C00"+extension3;
                else if (extension3.length() == 8) extension3 = "C0"+extension3;
                else if (extension3.length() == 9) extension3 = "C"+extension3;
            }
            if (newCellNumber3 < 0){
                extension3 = extension3.substr(1);
                if (extension3.length() == 1) extension3 = "C-00000000"+extension3;
                else if (extension3.length() == 2) extension3 = "C-0000000"+extension3;
                else if (extension3.length() == 3) extension3 = "C-000000"+extension3;
                else if (extension3.length() == 4) extension3 = "C-00000"+extension3;
                else if (extension3.length() == 5) extension3 = "C-0000"+extension3;
                else if (extension3.length() == 6) extension3 = "C-000"+extension3;
                else if (extension3.length() == 7) extension3 = "C-00"+extension3;
                else if (extension3.length() == 8) extension3 = "C-0"+extension3;
                else if (extension3.length() == 9) extension3 = "C-"+extension3;
            }
            if (newCellNumber4 >= 0){
                if (extension4.length() == 1) extension4 = "C00000000"+extension4;
                else if (extension4.length() == 2) extension4 = "C0000000"+extension4;
                else if (extension4.length() == 3) extension4 = "C000000"+extension4;
                else if (extension4.length() == 4) extension4 = "C00000"+extension4;
                else if (extension4.length() == 5) extension4 = "C0000"+extension4;
                else if (extension4.length() == 6) extension4 = "C000"+extension4;
                else if (extension4.length() == 7) extension4 = "C00"+extension4;
                else if (extension4.length() == 8) extension4 = "C0"+extension4;
                else if (extension4.length() == 9) extension4 = "C"+extension4;
            }
            if (newCellNumber4 < 0){
                extension4 = extension4.substr(1);
                if (extension4.length() == 1) extension4 = "C-00000000"+extension4;
                else if (extension4.length() == 2) extension4 = "C-0000000"+extension4;
                else if (extension4.length() == 3) extension4 = "C-000000"+extension4;
                else if (extension4.length() == 4) extension4 = "C-00000"+extension4;
                else if (extension4.length() == 5) extension4 = "C-0000"+extension4;
                else if (extension4.length() == 6) extension4 = "C-000"+extension4;
                else if (extension4.length() == 7) extension4 = "C-00"+extension4;
                else if (extension4.length() == 8) extension4 = "C-0"+extension4;
                else if (extension4.length() == 9) extension4 = "C-"+extension4;
            }
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] > imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
            }
            
            string timeString = to_string(imageNumberTrackForDisplay);
            
            if (timeString.length() == 1) timeString = "000"+timeString;
            else if (timeString.length() == 2) timeString = "00"+timeString;
            else if (timeString.length() == 3) timeString = "0"+timeString;
            
            string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTemp";
            string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTempD";
            
            int entryDataCheck = 0;
            
            ifstream fin;
            fin.open(connectDataTempPath.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            fin.open(connectDataTempPathDummy.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            if (entryDataCheck == 1) overTimeRemoveFlag = 1;
            
            cellNoHoldDiv1 = extension1;
            cellNoHoldDiv2 = extension2;
            cellNoHoldDiv3 = extension3;
            cellNoHoldDiv4 = extension4;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            if (otherDivFind == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Found Another Division"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
            else if (mitosisFind == 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Mitosis Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
            else if (onePrevious == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"HD End Occupied"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0; //-----BD end position Overlap with others-----
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"HD Set Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                findFlag = 0;
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return findFlag;
}

-(int)cellFusionSet{
    int findFlag = 0;
    int otherDivFind = 0;
    int saveFileCheck = 0;
    
    string extension;
    string connectCheckPath;
    string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold;
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //	cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
    //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
    //}
    
    struct stat sizeOfFile;
    
    for (int counter1 = firstModificationPoint; counter1 < imageNumberTrackForDisplay; counter1++){
        extension = to_string(counter1);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        connectCheckPath = connectDataTempPath+"/"+extension+"_MasterDataTemp";
        
        if (stat(connectCheckPath.c_str(), &sizeOfFile) == -1){
            connectCheckPath = connectDataTempPath+"/"+extension+"_MasterDataTempD";
            
            if (stat(connectCheckPath.c_str(), &sizeOfFile) == -1) saveFileCheck = 1;
        }
    }
    
    if (saveFileCheck == 0){
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
            if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33)) otherDivFind = 1;
            if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44)) otherDivFind = 1;
            if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55)) otherDivFind = 1;
            if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 91) otherDivFind = 1;
        }
        
        if (findFlag == 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Found Another Event"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (otherDivFind == 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Found Another Division"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
            
            findFlag = 0;
        }
        else{
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] > imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
            }
            
            string timeString = to_string(imageNumberTrackForDisplay);
            
            if (timeString.length() == 1) timeString = "000"+timeString;
            else if (timeString.length() == 2) timeString = "00"+timeString;
            else if (timeString.length() == 3) timeString = "0"+timeString;
            
            connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTemp";
            string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTempD";
            
            int entryDataCheck = 0;
            
            ifstream fin;
            
            fin.open(connectDataTempPath.c_str(), ios::in);
            
            if (fin.is_open()){
                entryDataCheck = 1;
                fin.close();
            }
            
            fin.open(connectDataTempPathDummy.c_str(), ios::in);
            
            if (fin.is_open()){
                entryDataCheck = 1;
                fin.close();
            }
            
            if (entryDataCheck == 1) overTimeRemoveFlag = 1;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Image Sequence Gap"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return findFlag;
}

-(void)fusionMarkSet{
    int findFlag = 0;
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
    }
    
    if (findFlag == 1){
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                arrayEventSequence [counter1*4+1] = 10;
                break;
            }
        }
        
        eventSequenceHoldCount = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
            }
        }
        
        divisionWarning = "FM_Set";
        divisionWarningType = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)impartialMitosisSet{
    int findFlag = 0;
    int previousMitosisFind = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2){
            findFlag = 1;
        }
    }
    
    if (findFlag == 1){
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4] < imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 6){
                previousMitosisFind = arrayEventSequence [counter1*4];
                break;
            }
        }
        
        if (previousMitosisFind == 0){
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                    arrayEventSequence [counter1*4+1] = 11;
                    break;
                }
            }
            
            eventSequenceHoldCount = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                }
            }
            
            divisionWarning = "IP_Set";
            divisionWarningType = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        if (previousMitosisFind != 0){
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == previousMitosisFind){
                    arrayEventSequence [counter1*4+1] = 11;
                    break;
                }
            }
            
            string extension1 = to_string(previousMitosisFind);
            
            divisionWarning = "IP_Set/MI_T= "+extension1;
            divisionWarningType = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)correctionSet{
    //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
    //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
    
    int findFlag = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] != 2){
            findFlag = arrayEventSequence [counter1*4+1];
            break;
        }
    }
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    if (divisionTypeHold == 0 && fusionOperation == 0){
        if (findFlag != 0){
            if ((findFlag == 32 || findFlag == 33 || findFlag == 42 || findFlag == 43 || findFlag == 44 || findFlag == 52 || findFlag == 53 || findFlag == 54 || findFlag == 55 || findFlag == 91) && divisionTypeHold == 0 && lineModificationRecord == 1){
                string extension = to_string(imageNumberTrackForDisplay);
                
                if (extension.length() == 1) extension = "000"+extension;
                else if (extension.length() == 2) extension = "00"+extension;
                else if (extension.length() == 3) extension = "0"+extension;
                
                string connectStatusTempPath4 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTempD";
                
                ifstream fin;
                
                fin.open(connectStatusTempPath4.c_str(), ios::in);
                
                if (fin.is_open()){
                    fin.close();
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Division or Fusion Remove Blocked: Save-Rmv to Save"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    eventSequenceHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay-1) arrayEventSequence [counter1*4+1] = 2;
                    }
                    
                    lineageGravityCenterCurrentHoldCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                        if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
                    }
                    
                    //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
                    //    cout<<" arrayEventSequenceHold "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                    //    cout<<" arrayEventSequence "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                    //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
                    //    cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
                    //}
                    
                    string connectStatusTempPath1 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
                    string connectStatusTempPath3 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
                    connectStatusTempPath4 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_RevisedTempMap";
                    string connectStatusTempPath5 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
                    string connectStatusTempPath7 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_LinkDataTemp";
                    string connectStatusTempPath8 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTemp";
                    string connectStatusTempPath9 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendAreaDataTemp";
                    string connectStatusTempPath10 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_GCCenterInfo";
                    
                    remove (connectStatusTempPath1.c_str());
                    remove (connectStatusTempPath3.c_str());
                    remove (connectStatusTempPath4.c_str());
                    remove (connectStatusTempPath5.c_str());
                    remove (connectStatusTempPath7.c_str());
                    remove (connectStatusTempPath8.c_str());
                    remove (connectStatusTempPath9.c_str());
                    remove (connectStatusTempPath10.c_str());
                    
                    gravityCenterXHold1 = 0;
                    gravityCenterYHold1 = 0;
                    gravityAverageHold1 = 0;
                    gravityCellNo1 = 0;
                    gravityCenterXHold2 = 0;
                    gravityCenterYHold2 = 0;
                    gravityAverageHold2 = 0;
                    gravityCellNo2 = 0;
                    gravityCenterXHold3 = 0;
                    gravityCenterYHold3 = 0;
                    gravityAverageHold3 = 0;
                    gravityCellNo3 = 0;
                    gravityCenterXHold4 = 0;
                    gravityCenterYHold4 = 0;
                    gravityAverageHold4 = 0;
                    gravityCellNo4 = 0;
                    
                    trackingUpperLimit = upperLimitMap;
                    trackingOnInfoDisplay = 1;
                    
                    if (findFlag == 91){
                        fusionPartnerLin = 0;
                        fusionPartnerCellNo = -1;
                        fusionMarkImage = 10000;
                        fusionStatusFollow = 0;
                    }
                    
                    divisionFusionCancelFlag = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else if (findFlag == 6 || findFlag == 10 || findFlag == 11){
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == findFlag){
                        arrayEventSequence [counter1*4+1] = 2;
                        break;
                    }
                }
                
                eventSequenceHoldCount = 0;
                
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
                // 	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
                //	cout<<" arrayEventSequenceHold "<<counterA<<endl;
                //}
                
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                if (lineagePartnerInfoCount != 0){
                    string lingNoTemp;
                    string cellNoTemp;
                    string imageNoTemp;
                    
                    string *arrayLineagePartnerInfoTemp = new string [lineagePartnerInfoCount+50];
                    int lineagePartnerInfoTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoCount/6; counter1++){
                        lingNoTemp = arrayLineagePartnerInfo [counter1*6+1];
                        cellNoTemp = arrayLineagePartnerInfo [counter1*6+2];
                        imageNoTemp = arrayLineagePartnerInfo [counter1*6+3];
                        
                        if (arrayLineagePartnerInfo [counter1*6] != treatmentNameHold || atoi(lingNoTemp.c_str()) != lineageAmendTemp || atoi(cellNoTemp.c_str()) != cellAmendTemp || atoi(imageNoTemp.c_str()) != imageNumberTrackForDisplay){
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = arrayLineagePartnerInfo [counter1*6], lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = arrayLineagePartnerInfo [counter1*6+1], lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = arrayLineagePartnerInfo [counter1*6+2], lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = arrayLineagePartnerInfo [counter1*6+3], lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = arrayLineagePartnerInfo [counter1*6+4], lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = arrayLineagePartnerInfo [counter1*6+5], lineagePartnerInfoTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineagePartnerInfoTempCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineagePartnerInfoTemp [counterA*6+counterB];
                    //    cout<<" arrayLineagePartnerInfoTemp "<<counterA<<endl;
                    //}
                    
                    if (lineagePartnerInfoTempCount == 0){
                        if (lineagePartnerInfoStatus == 1){
                            delete [] arrayLineagePartnerInfo;
                            lineagePartnerInfoCount = 0;
                            lineagePartnerInfoStatus = 0;
                        }
                    }
                    else{
                        
                        lineagePartnerInfoCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount; counter1++) arrayLineagePartnerInfo [lineagePartnerInfoCount] = arrayLineagePartnerInfoTemp [counter1], lineagePartnerInfoCount++;
                    }
                    
                    //for (int counterA = 0; counterA < lineagePartnerInfoCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineagePartnerInfo [counterA*6+counterB];
                    //    cout<<" arrayLineagePartnerInfo "<<counterA<<endl;
                    //}
                    
                    delete [] arrayLineagePartnerInfoTemp;
                }
                
                string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_FusionPartner";
                
                struct stat sizeOfFile;
                long sizeForCopy = 0;
                
                if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                    int lineagePartnerInfoTempCount = 0;
                    
                    ifstream fin;
                    fin.open(cellFusionPartnerPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        string treatmentNameGet;
                        string lineageNoGet;
                        string cellNoGet;
                        string imageNoGet;
                        string partnerLingNoGet;
                        string partnerCellNoGet;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            getline(fin, treatmentNameGet);
                            
                            if (treatmentNameGet == "") terminationFlag = 0;
                            else{
                                
                                getline(fin, lineageNoGet);
                                getline(fin, cellNoGet);
                                getline(fin, imageNoGet);
                                getline(fin, partnerLingNoGet);
                                getline(fin, partnerCellNoGet);
                                
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                    
                    //for (int counterA = 0; counterA < lineagePartnerInfoTempCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayLineagePartnerInfoTemp [counterA*6+counterB];
                    //    cout<<" arrayLineagePartnerInfoTemp "<<counterA<<endl;
                    //}
                    
                    string lingNoTemp;
                    string cellNoTemp;
                    string imageNoTemp;
                    
                    string *arrayLineagePartnerInfoTemp2 = new string [lineagePartnerInfoTempCount+50];
                    int lineagePartnerInfoTempCount2 = 0;
                    
                    for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount/6; counter1++){
                        lingNoTemp = arrayLineagePartnerInfoTemp [counter1*6+1];
                        cellNoTemp = arrayLineagePartnerInfoTemp [counter1*6+2];
                        imageNoTemp = arrayLineagePartnerInfoTemp [counter1*6+3];
                        
                        if (arrayLineagePartnerInfoTemp [counter1*6] != treatmentNameHold || atoi(lingNoTemp.c_str()) != lineageAmendTemp || atoi(cellNoTemp.c_str()) != cellAmendTemp || atoi(imageNoTemp.c_str()) != imageNumberTrackForDisplay){
                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6], lineagePartnerInfoTempCount2++;
                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+1], lineagePartnerInfoTempCount2++;
                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+2], lineagePartnerInfoTempCount2++;
                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+3], lineagePartnerInfoTempCount2++;
                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+4], lineagePartnerInfoTempCount2++;
                            arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+5], lineagePartnerInfoTempCount2++;
                        }
                    }
                    
                    if (lineagePartnerInfoTempCount2 != 0){
                        ofstream oin;
                        oin.open(cellFusionPartnerPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) oin<<arrayLineagePartnerInfoTemp2 [counter1]<<endl;
                        
                        oin.close();
                    }
                    else remove (cellFusionPartnerPath.c_str());
                    
                    delete [] arrayLineagePartnerInfoTemp;
                    delete [] arrayLineagePartnerInfoTemp2;
                }
                
                if (findFlag == 6 && mitosisInfoRemoveCount < 10){
                    cellLineageExtract = cellLineageNoHold.substr(1);
                    string cellNumberExtract = cellNoHold.substr(1);
                    
                    int cellLineageTempInt = atoi(cellLineageExtract.c_str());
                    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
                    int connectNoTemp = 0;
                    
                    for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                        if (arrayConnectLineageRel [counter1*6] == cellLineageTempInt && arrayConnectLineageRel [counter1*6+3] == cellNumberTempInt){
                            connectNoTemp = arrayConnectLineageRel [counter1*6+1];
                            break;
                        }
                    }
                    
                    int averageValue = 0;
                    
                    for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){
                        if (arrayGravityCenterRev [counter1*6+4] == connectNoTemp){
                            averageValue = arrayGravityCenterRev [counter1*6+3];
                        }
                    }
                    
                    int processType = 1;
                    int imageNoEvent = 0;
                    
                    mitosisSD = [[MitosisSD alloc] init];
                    double mitosisSDSave = [mitosisSD mitosisSDReturn:imageNoEvent:processType];
                    
                    if (mitosisInfoRemoveCount != 10){
                        arrayMitosisValueInfo [mitosisInfoRemoveCount+10] = averageValue;
                        arrayMitosisSDInfo [mitosisInfoRemoveCount+10] = mitosisSDSave, mitosisInfoRemoveCount++;
                    }
                    
                    string mitosisDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/mitosisParameter.dat";
                    
                    ofstream oin;
                    
                    oin.open(mitosisDataPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < 20; counter1++) oin<<arrayMitosisSDInfo [counter1]<<endl;
                    for (int counter1 = 0; counter1 < 20; counter1++) oin<<arrayMitosisValueInfo [counter1]<<endl;
                    
                    oin<<mitosisInfoSetCount<<endl;
                    oin<<mitosisInfoRemoveCount<<endl;
                    
                    oin.close();
                }
                
                divisionWarning = "";
                divisionWarningType = 0;
                trackingOnInfoDisplay = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (findFlag == 7 || findFlag == 8){
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == findFlag){
                        arrayEventSequence [counter1*4+1] = 2;
                        break;
                    }
                }
                
                eventSequenceHoldCount = 0;
                
                for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                    if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                        arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
                // 	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
                //	cout<<" arrayEventSequenceHold "<<counterA<<endl;
                //}
                
                divisionWarning = "";
                divisionWarningType = 0;
                trackingUpperLimit = upperLimitMap;
                trackingOnInfoDisplay = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Correction: Not Allowed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Event Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Division or Fusion Set On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //    cout<<" arrayEventSequence "<<counterA<<endl;
    //}
}

-(void)outOfFrameSet{
    int findFlag = 0;
    int divisionFusionFindFag = 0;
    
    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay && arrayEventSequence [counter1*4+1] == 2) findFlag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 32 || arrayEventSequence [counter1*4+1] == 33)) divisionFusionFindFag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 42 || arrayEventSequence [counter1*4+1] == 43 || arrayEventSequence [counter1*4+1] == 44)) divisionFusionFindFag = 1;
        if (arrayEventSequence [counter1*4] != 0 && (arrayEventSequence [counter1*4+1] == 52 || arrayEventSequence [counter1*4+1] == 53 || arrayEventSequence [counter1*4+1] == 54 || arrayEventSequence [counter1*4+1] == 55)) divisionFusionFindFag = 1;
        if (arrayEventSequence [counter1*4] != 0 && arrayEventSequence [counter1*4+1] == 91) divisionFusionFindFag = 1;
    }
    
    if (findFlag == 1){
        if (divisionFusionFindFag == 0){
            trackingUpperLimit = imageNumberTrackForDisplay;
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4+1] = 8;
                if (arrayEventSequence [counter1*4] > imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
            }
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] > imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
            }
            
            string timeString = to_string(imageNumberTrackForDisplay);
            
            if (timeString.length() == 1) timeString = "000"+timeString;
            else if (timeString.length() == 2) timeString = "00"+timeString;
            else if (timeString.length() == 3) timeString = "0"+timeString;
            
            string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTemp";
            string connectDataTempPathDummy = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+timeString+"_MasterDataTempD";
            
            int entryDataCheck = 0;
            
            ifstream fin;
            fin.open(connectDataTempPath.c_str(), ios::in);
            
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            fin.open(connectDataTempPathDummy.c_str(), ios::in);
            if (fin.is_open()) entryDataCheck = 1, fin.close();
            
            if (entryDataCheck == 1) overTimeRemoveFlag = 1;
            
            eventSequenceHoldCount = 0;
            
            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                    arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
                }
            }
            
            lineageGravityCenterCurrentHoldCount = 0;
            
            for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
                if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay){
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4], lineageGravityCenterCurrentHoldCount++;
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+1], lineageGravityCenterCurrentHoldCount++;
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+2], lineageGravityCenterCurrentHoldCount++;
                    arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+3], lineageGravityCenterCurrentHoldCount++;
                }
            }
            
            trackingOnInfoDisplay = 1;
            divisionWarning = "OF_Set";
            divisionWarningType = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Found Division or Fusion: Use Save-Rmv to Create New End, Then Set OF"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Found Another Event"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)primaryAddition{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = -100000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt+10000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt+1000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt+100000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt+10000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt+1000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt+100;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt+10;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt+1;
        }
        else{
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)primarySubtract{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = 100000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt-10000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt-1000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt-100000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt-10000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt-1000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt-100;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt-10;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt-1;
        }
        else{
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)secondaryAddition{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = -200000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt+20000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt+2000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt+200000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt+20000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt+2000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt+200;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt+20;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt+2;
        }
        else{
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)secondarySubtract{
    string cellNumberExtract = cellNoHold.substr(1);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = 200000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt-20000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt-2000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt-200000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt-20000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt-2000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt-200;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt-20;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt-2;
        }
        else{
            
            string lineageNumberExtract = cellLineageNoHold.substr(1);
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "5"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(0, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(1, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "3"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "4"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                        if (arrayLineageData [counter1*8+6] == atoi(lineageNumberExtract.c_str())){
                            if ((to_string(arrayLineageData [counter1*8+5])).substr(1, 1) == "6"){
                                if (atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str()) > cellExtensionEntry){
                                    cellExtensionEntry = atoi((to_string(arrayLineageData [counter1*8+5])).substr(2, 5).c_str());
                                }
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

@end
