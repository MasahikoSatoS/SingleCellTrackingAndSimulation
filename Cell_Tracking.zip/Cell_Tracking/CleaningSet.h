//
//  CleaningSet.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 10/4/16.
//
//

#ifndef CLEANINGSET_H
#define CLEANINGSET_H
#import "Controller.h" 
#endif

@interface CleaningSet : NSObject{
}

-(IBAction)cleaningData:(id)sender;

@end
