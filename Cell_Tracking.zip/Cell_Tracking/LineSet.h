//
// LineSet.h
// Cell_Tracking
//
// Created by Masahiko Sato on 06/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef LINESET_H
#define LINESET_H
#import "Controller.h"
#endif

@interface LineSet : NSObject {
    int *targetGapFill; //Target fill data
    int targetGapFillCount;
    int targetGapFillAddition;
    int targetGapFillLimit;
    
    id newAreaCreation;
    id areaCircleCut;
    id newAreaCreationTrack;
    id areaCircleCutTrack;
    id areaSetFluorescent;
    id fileUpdate;
}

-(void)lineSetProcess:(int)processType;
-(int)dataRead:(int)readImage;
-(void)gapFillUpdate;

@end
