//
//  MitosisSD.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2016-02-20.
//
//

#ifndef MITOSISSD_H
#define MITOSISSD_H
#import "Controller.h" 
#endif

@interface MitosisSD : NSObject {
}

-(double)mitosisSDReturn:(int)imageNo :(int)processType;

@end
