//
// Controller.m
// Cell_Tracking
//
// Created by Masahiko Sato on 08/01/10.
// Copyright Masahiko Sato 2010 All rights reserved.
//

#import "Controller.h"

//-----Main Controller related-----
int initialSetOperation;
int analysisLoadOperation;
int trackingTableOperation;
int navigationOperation;
int listWindowOperation;
int searchWindowOperation;
int maxTimePoint;
int timeOneHold;
int timeEndHold;
int ifStartHold;
int imageEndHold;
int setStatus1;
int setStatus2;
int setStatus3;
int setStatus4;
int setStatus5;
int setStatus6;
int setStatus7;
int setStatus8;
int addDelInsert;
int clearBack;
int doubleClick;
int queueHoldingStatus;
int autoExpand;
int autoExpandLine;
int listCrickMonitor;
int imageNumber;
int imageLoadMonitor;
int trackingTableSetDone;
int lineageCellSwitch;
int trackingImageLock;
int tableTrackingProcessing;
int overTimeRemoveFlag;
int divisionFusionCancelFlag;
int autoRefStatus;
int imageReadTiming;
int imageReadTimingNavigation;
int displaySetDICFlag;
int displaySetFluorescentFlag;
int displaySetCutFlag1;
int displaySetCutFlag2;
int displaySetCutFlag3;
int displaySetCutFlag4;
int displaySetCutFlag5;
int displaySetCutFlag6;
int displaySetCutFlag7;
int imageDimension;
int trackingCheckInterval;
int quickLineageConnect;
int cellJumpFirstLast;
int mitosisSaveCount;
string errorInfoFlag;
int queueDisplayOptions;
int doneDisplayOptions;
int imageReturnPosition;
int imageReturnPositionSet;
int autoTrackingLimitHold;
int analysisSavingInProgress;
int mainSavingInProgress;
int cleaningProgress;
double progressValue;
int progressTiming;
int progressTimingB;
int progressTimingC;
double lineWidth;
int lineTypeSet;
int cleaningManualProgress;
int dataEntryStatus;
string treatSetNameHold;
int autoTrackFirstSave;
string saveInfo;
int errorNoHold;

int tableRowHold;
int tableCallCount;
int tableCurrentRowHold;
int tableNewRowHold;

int cellLineageInfoListCreationCall;
int cellNumberInfoListCreationCall;
int displayWindowCall;
int listSwitchCall;
int listSwitchCallStatus;
int quickLineSetCall;
int quickLineageCall;
int quickConnectCall;
int inputNumber;
int inputNumberCall;

int *arrayCellLineageInfo;
int cellLineageInfoCount;
int cellLineageInfoLimit;
int cellLineageInfoStatus;
int *arrayCellNumberInfo;
int cellNumberInfoCount;
int cellNumberInfoLimit;
int cellNumberInfoStatus;
int *arrayLineageData;
int lineageDataCount;
int lineageDataLimit;
int lineageDataAddition;
int lineageDataStatus;
string *arrayQueueList;
int queueListCount;
int queueListLimit;
string *arrayQueueListDisplay;
int queueListDisplayCount;
int queueListDisplayLimit;
string *arrayDoneList;
int doneListCount;
int doneListLimit;
string *arrayDoneListDisplay;
int doneListDisplayCount;
int doneListDisplayLimit;
string *arrayTreatmentStatus;
int treatmentStatusCount;
string *arrayGetList;
int getListCount;
int getListLimit;
string *arrayImageSizeList;
int imageSizeListCount;
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;
string *arrayLineagePartnerInfo;
int lineagePartnerInfoCount;
int lineagePartnerInfoStatus;
int *arrayMergeSelect;
int mergeSelectCount;
int *arrayTimePointSaveList;
int timePointListMax;
int timePointListSaveStatus;
int restoreDataFlag;
int autoCheckFlag;
int *autoCheckTemp;
int autoCheckTempCount;
int autoCheckTempLimit;
int autoCheckTempStatus;
int phaseStatus;

string pathNameString;
string analysisImageName;
string analysisImageNameSelect;
string analysisID;
string analysisIDSelect;
string treatmentNameHold;
string treatmentNameKeep;
string cellLineageNoHold;
string cellNoHold;

uint8_t *fileReadArray;
string exType;
string exTypeIF;
int tifImageColorGray;

//-----Initial Set and Analysis-----
int saveDataStatus;
int listTableCall;
string *arrayDirectoryInfo;
int directoryInfoCount;
int directoryInfoLimit;
string *arrayDirectoryInitialInfo;
int directoryInitialInfoCount;
int directoryInitialInfoLimit;
string *arraySelectedTreatmentProc;
int selectedTreatmentProcCount;
string *arrayTrackingList;
int trackingListCount;
int trackingListLimit;
string destinationName;
string destinationAnalysisPath;
string sourceAnalysisPath;

//-----Tracking controller-----
int cellDivisionSetCount;
int divisionTypeHold;
int divisionWarningType;
int fusionOperation;
int fusionPartnerLin;
int fusionPartnerCellNo;
int fusionMarkImage;
int fusionStatusFollow;
int saveShortCutNumber;
int listOnOffFlag;
string *arrayListHold;
int listHoldCount;
int listHoldProcessFlag;
int forceSetAutoFlag;
int lineageWritingCheck;

int trackJump;
int displayJump;
int removeAll;
int xCellPosition;
int yCellPosition;
int displayPositionType;
int trackingOn;
int trackingOnInfoDisplay;
int windowLock;
int areaSelectStatus;
int lineDraw;
int doubleClickStatusHold;
int tableListSwitch;
int trackingPermit;
int trackingLowerLimit;
int trackingUpperLimit;
int upperLimitMap;
int firstModificationPoint;
int lineModificationFlag;
int cutBase;
int lineModificationRecord;
int characterDisplayFlag;
int characterDisplayNavFlag;
int cutOff1;
int cutOff2;
int cutOff3;
int cutOff4;
int cutOff5;
int cutOff6;
int cutOff7;
int cutStatusDic;
int cutStatusFluorescent;
int cutDisplay;
int backForwardMode;
int mergeAllFlag;

int lineSetWindowCallTrack;
int lineSetWindowCallDisplay;
int lineAreaCall;
string gravityCenterNotRecorded;

int gravityCenterXHold1;
int gravityCenterYHold1;
int gravityAverageHold1;
int gravityCellNo1;
int gravityCenterXHold2;
int gravityCenterYHold2;
int gravityAverageHold2;
int gravityCellNo2;
int gravityCenterXHold3;
int gravityCenterYHold3;
int gravityAverageHold3;
int gravityCellNo3;
int gravityCenterXHold4;
int gravityCenterYHold4;
int gravityAverageHold4;
int gravityCellNo4;

int *arrayConnectLineListLocal;
int connectLineListLocalCount;
int connectLineListLocalLimit;
int connectLineListLocalStatus;
int *arrayLineageGRCurrent;
int lineageGRCurrentCount;
int lineageGRCurrentLimit;
int *arrayReferenceLine;
int referenceLineCount;
int referenceLineLimit;
int *arrayLineageStartEnd;
int lineageStartEndCount;
int lineageStartEndLimit;
int lineageStartEndStatus;
int *arrayXYPositionList;
int xyPositionListCount;
int xyPositionListStatus;
int *arrayMasterLineForTracking;
int masterLineForTrackingCount;
int masterLineForTrackingStatus;
int *arrayMasterLineForDisplay;
int masterLineForDisplayCount;
int masterLineForDisplayStatus;
int *arrayMasterLineGravityCenter;
int masterLineGravityCenterCount;
int masterLineGravityCenterLimit;
int masterLineGravityCenterStatus;
int *arrayMasterLineSelected;
int masterLineSelectedCount;
int masterLineSelectedLimit;
int masterLineSelectedAddition;
int masterLineSelectedStatus;
int *arrayPositionRevise;
int positionReviseCount;
int positionReviseLimit;
int positionReviseAddition;
int positionReviseStatus;
int *arrayTargetHold;
int targetHoldCount;
int targetHoldLimit;
int targetHoldStatus;
int *arrayTargetHoldInfo;
int targetHoldInfoCount;
int targetHoldInfoLimit;
int *arrayConnectLineageRel;
int connectLineageRelCount;
int connectLineageRelLimit;
int connectLineageRelStatus;
int *arrayEventSequence;
int eventSequenceCount;
int eventSequenceLimit;
int *arrayEventSequenceHold;
int eventSequenceHoldCount;
int *arrayLineageGravityCenterCurrentHold;
int lineageGravityCenterCurrentHoldCount;
int *arrayLineageExtraction;
int lineageExtractionCount;
int lineageExtractionLimit;
int *arrayMasterLineSelectedDisplay;
int masterLineSelectedDisplayCount;
int masterLineSelectedDisplayStatus;
int masterLineSelectedDisplayLimit;
int masterLineSelectedDisplayAddition;
int *arrayMasterLineGravityCenterDisplay;
int masterLineGCDisplayCount;
int masterLineGCDisplayStatus;
int masterLineGCDisplayLimit;
int *lineageProcessList;
int *arrayTarget;
int targetCount;
int targetLimit;
int targetStatus;
int *arrayTargetPrevHold;
int targetPrevHoldCount;
int targetPrevHoldLimit;
int targetPrevHoldStatus;
int *arrayGapData;
int gapDataCount;
int gapDataLimit;
int *arrayLineDataProcessing;
int lineDataProcessingCount;
int *arrayGravityCenterRev;
int gravityCenterRevCount;
int gravityCenterRevLimit;
int gravityCenterRevStatus;
int *arrayTimeSelected;
int timeSelectedCount;
int timeSelectedLimit;
int timeSelectedStatus;
int *arrayTimeSelectedHold;
int timeSelectedHoldCount;
int timeSelectedHoldStatus;
int *arrayAssociateData;
int associateDataCount;
int associateDataLimit;
int associateDataStatus;
int *attachedNumberList;
int attachedNumberListCount;
int attachedNumberListStatus;
int *groupNumberList;
int groupNumberListCount;
int groupNumberListStatus;
int *cellEndHold;
int cellEndHoldCount;
int cellEndHoldLimit;
int cellEndHoldStatus;

int **sourceImage;
int sourceImageStatus;
int **revisedMap;
int revisedMapStatus;
int **revisedWorkingMap;
int revisedWorkingMapStatus;
int **revisedWorkingMap2;
int revisedWorkingMapTime2;
int revisedWorkingMapSize2;
int revisedWorkingMapStatus2;
string revisedWorkingMapName2;

int **internalZeroMap;
int **targetMap;
int *arrayListPattern;
int listPatternCount;
int listPatternStatus;

string cellNoHoldDiv1;
string cellNoHoldDiv2;
string cellNoHoldDiv3;
string cellNoHoldDiv4;
string divisionWarning;
string targetLostMark;

int cutLimitValueHold;
int cutDisplayValueHold;
int forceSetStatus;

int fluorescentDisplayMode;
int fluorescentDisplayRange;
int fluorescentDisplayMax;

//-----Paths-----
string imageFolderPath;
string displayImagePath;
string trackDataFolderPath;
string masterDataFolderPath;
string backUpTempPath;

//-----Tracking Window-----
int imageWidthTrack;
int imageHeightTrack;
int magnificationTrack;
int imageNumberTrackForDisplay;
int keyLockON;
double xPositionTrack;
double yPositionTrack;
double windowWidthTrack;
double windowHeightTrack;

//-----Display Window-----
int imageWidthDisplay;
int imageHeightDisplay;
int magnificationDisplay;
int imageNumberDisplayForDisplay;
double xPositionDisplay;
double yPositionDisplay;
int synchroOn;
double windowWidthDisplay;
double windowHeightDisplay;

//-----List Window-----
int listDisplaySelection;
int listToTrackCall;
int currentPageNoCell;
int currentPageNoMitosis;
int boxImageNumber;
string listLingNoHold;
string listCellNoHold;
string listLingRecent;
string listCellRecent;
string listLingCurrent;
string listCellCurrent;
int listLoadingProcessing;

//-----Time One-----
int timeOneStatus;
int tableDataSetDone;
int timeOneX;
int timeOneY;
int timeOneQuickSet;
int currentConnectNo;
int currentPositionSet;
int timeOneLaunch;
string timeOneConnectStatus;

int **connectMap200;
int **connectMap220;
int **connectMap240;
int **connectMapA;
int **connectMapB;
int **connectMapC;
int **connectMapD;
int **connectivityMap;
int dicAllStartFlag;

//-----Communication related-----
int connectionSend1;
int *fusionPartnerInfo;
int fusionPartnerInfoCount;
int fusionPartnerInfoLimit;
string treatmentNameAuto;
string lineageNoAuto;
string cellNoAuto;
string checkStatusAuto;
string imageNoAuto;
string additionalInfoAuto;
string instructionCCPath;
string instructionRRPath;
int queueRestartFlag;
int multipleLaunchBlock;
int firstTrackStart;
int reviseTimingCount;
int upDateCompleteFlag;

//-----Activity monitor-----
int runStatusCellCurving;
int cellCurvingRunningFlag;
int subCompleteFlag;

//-----Fluorescent-----
int fluorescentNo1;
int fluorescentNo2;
int fluorescentNo3;
int fluorescentNo4;
int fluorescentNo5;
int fluorescentNo6;
int fluorescentEntryCount;
int fluorescentDetection;
int fluorescentDisplayNo;
int fluorescentDetectionDisplay;
int fluorescentCutOff1;
int fluorescentCutOff2;
int fluorescentCutOff3;
int fluorescentCutOff4;
int fluorescentCutOff5;
int fluorescentCutOff6;
int fluorescentValueDisplayControl;
int sliderBarSet;

int **fluorescentMap1;
int fluorescentMapStatus1;
int fluorescentMapFind1;
int **fluorescentMap2;
int fluorescentMapStatus2;
int fluorescentMapFind2;
int **fluorescentMap3;
int fluorescentMapStatus3;
int fluorescentMapFind3;
int **fluorescentMap4;
int fluorescentMapStatus4;
int fluorescentMapFind4;
int **fluorescentMap5;
int fluorescentMapStatus5;
int fluorescentMapFind5;
int **fluorescentMap6;
int fluorescentMapStatus6;
int fluorescentMapFind6;
int *expandFluorescentOutline;
int expandFluorescentOutlineCount;
int expandFluorescentOutlineLimit;
int expandFluorescentOutlineStatus;
int *expandFluorescentData;
int expandFluorescentDataCount;
int expandFluorescentDataLimit;
int expandFluorescentDataStatus;
int *connectDataExchange;
int connectDataExchangeStatus;
int *arrayFluorescentCutOff;
int fluorescentCutOffCount;
int fluorescentCutOffStatus;

string fluorescentName1;
string fluorescentName2;
string fluorescentName3;
string fluorescentName4;
string fluorescentName5;
string fluorescentName6;
string fluorescentColorNameTemp1;
string fluorescentColorNameTemp2;
string fluorescentColorNameTemp3;
string fluorescentColorNameTemp4;
string fluorescentColorNameTemp5;
string fluorescentColorNameTemp6;

//-----Fluorescent IF option-----
int ifEntry;
int fluorescentNoHold1;
int fluorescentNoHold2;
int fluorescentNoHold3;
int fluorescentNoHold4;
int fluorescentNoHold5;
int fluorescentNoHold6;
int fluorescentEntryCountHold;
string fluorescentNameHold1;
string fluorescentNameHold2;
string fluorescentNameHold3;
string fluorescentNameHold4;
string fluorescentNameHold5;
string fluorescentNameHold6;
string fluorescentRoundNo;
string *arrayIFDataHold;
int ifConnectNoUpDate;
int ifConnectNoCurrent;

//-----Search List-----
string treatmentNameSearch;
string treatmentNameSearchSelect;
string searchStatus1;
string searchStatus2;
string searchStatus3;
string searchStatus4;
int tableCallSearchCount;
int tableCurrentRowHoldSearch;
int tableNewRowHoldSearch;
int *arrayLineageSearchData;
int lineageDataSearchCount;
int lineageDataSearchStatus;
int *arrayLineageStartEndSearch;
int lineageStartEndSearchCount;
int lineageStartEndSearchStatus;
int *arrayLineageList;
int lineageListCount;
int lineageListStatus;
int *arraySearchCellList;
int searchCellListCount;
int searchCellListStatus;

//-----Option Operation-----
string selectedTreatName;
int optionCall;
int optionDisplayCall;
int optionWindowOperation;
int tableRowHoldOperation;
int tableCallOperationCount;
int tableCurrentRowHoldOperation;
int tableNewRowHoldOperation;
int *arrayOperationData;
int operationDataStatus;

//-----ParameterSet-----
int parameterSethWindowOperation;
double mitosisSDHold;
int mitosisValueHold;
int divisionDistanceHold;
double *arrayMitosisSDInfo;
int *arrayMitosisValueInfo;
int mitosisInfoSetCount;
int mitosisInfoRemoveCount;
int mitosisAreaHold;
double mitosisRelativeLowHold;
double mitosisRelativeHighHold;
double *arrayForAreaSize;
int forAreaSizeCount;
int displayMode;
int jumpAllFlag;
int connectExpandFlag;
int mapMergeStatus;
int percentOverlap;
int gravityCenterMoveLimitFlag;
int autoCheckDistanceHold;
int autoCheckAreaHold;
int autoCheckDivisionHold;
int autoCheckDistanceFoldHold;
int autoCheckIntensityHold;
int optionalShiftPercent;
int mitosisOffFlag;
int fusionMarkSetFlag;

//-----Verification repair-----
int repairWindowOperation;
int *checkList;
int checkListCount;
int checkListLimit;
int checkListStatus;
int *checkErrorTimeList;
int checkErrorTimeListCount;
int checkErrorTimeListStatus;
int rowRepairOperationTable;
int repairOperationTableCurrentRow;
int *checkResults;
int checkResultsCount;
int checkResultsLimit;
int checkResultsStatus;
int connectForVerifyHold;
int dataTypeSend;
int *arrayLineageRepairData;
int lineageDataRepairCount;
string lineageDataPath;
int *arrayPositionReviseVer;
int positionReviseVerCount;
int *arrayGravityCenterVerRev;
int gravityCenterRevVerCount;
int *arrayRepairDataHoldVerRev;
int repairDataHoldVerCount;
string masterDataRevPath;
string *arrayListString;
int listStringCount;
int listStringLimit;
int listStringStatus;
int listArrayStatusHold;
int repairListTableCurrentRow;
int treatmentMainDisplayCall;
int secondLineDisplayCall;
int secondLineDisplayRemoveCall;
string treatVerNameHold;
int verificationPositionCall;
int xPositionVer;
int yPositionVer;
int connectVer;
int errorNumberHold;
int errorTimeModeHold;
string nameStringRep;
int progressControl;
int checkOverrideFlag;

//-----Image sequence operation-----
int imageSeqOperation;
int seqImageClick;
int seqImageFirst;
int seqImageLast;
int seqImageCheck;
int seqImageMitosis;
int seqImageFusionMark;
int seqImageTop;
int seqOpenFlag;
int seqImageNoSet1;
int seqImageNoSet2;
int seqImageNoSet3;
int seqImageNoSet4;
int seqImageNoSet5;
int seqImageNoSet6;
int seqImageNoSet7;
int seqImageNoSet8;
int seqImageNoSet9;
int seqImageNoSet10;
int noOfSeqDisplay;
int imageWidthSeq;
int seqWindowFront;
int trackForwardControl;

//-----Fluorescent quantitation option-----
int fluorescentDivisionNo;
int fluorescentDivisionTime;
int fluorescentDivisionCh;
int fluorescentDivisionStatus;
int fluorescentOptionOperation;
int fluorescentOpOperationTableCurrentRow;
int *fluorescentOpInformationHold;
int fluorescentOpInformationCount;
int fluorescentOpInformationStatus;
int *fluorescentLevelDataHold;
int fluorescentLevelDataCount;
int fluorescentLevelDataStatus;
int fluorescentLevelDataLimit;
int fluorescentSaveCount;
string fluorescentSavePath;
int fluorescentLevelValueHold;

//-----Image export-----
int exportOperation;
int *arrayPositionExport;
int positionExportCount;
int positionExportStatus;
int *arrayGravityCenterExport;
int gravityCenterExportCount;
int gravityCenterExportStatus;
int *arrayTimeSelectedExport;
int timeSelectedExportCount;
int timeSelectedExportStatus;
int imageHeightExport;
CGFloat *colorList;
int colorListCount;
int colorListStatus;
double *cellNoHoldExport;
int channelNoExport;
int outlineWidthExport;
int nonTargetWidthExport;
int nonTargetLengthExport;
int nonTargetFontExport;
int targetWidthExport;
int targetLengthExport;
int targetFontExport;
int titleFontExport;
int titleNameExport;
string titleNameExportHold;
string pathExtension;
string displayImageLoadPath;
string displayImageSavePath;
string displayImageAllPath;
int timingEx;
int startExport;
int endExport;
int windowLockEX;
double boxStartImageX;
double boxStartImageY;
double boxEndImageX;
double boxEndImageY;
int *noOfCellsInArea;
int noOfCellsInAreaCount;
int noOfCellsInAreaStatus;
int densityDiameterHold;
int densityValueMaxHold;
int densityModeHold;
int **circleAreaHold;
int circleAreaHoldStatus;
CGFloat *arrayColorRange;
int lineageFontColorExport;
string ascIIstring;
int lineageLimitHold;
int *arrayMotilityBasicInfo;
int motilityBasicInfoStatus;
int motilityBasicInfoCount;
int thresholdCutHold;
int areaSizeMinHold;
int areaSizeMaxHold;
int thresholdStatusHold;
int *particleCountingDataHold;
int particleCountingDataHoldCount;
int particleCountingDataHoldStatus;
int xyPositionCall;
int xPositionExHold;
int yPositionExHold;
int displayOutlineSet;
int displayNonTargetSet;
double displayTargetFontSizeSet;
string *arrayLineTrace;
int lineTraceCount;
int lineTraceLimit;
int lineTraceStatus;
int lineTraceOnOff;
int lineTraceStartX;
int lineTraceStartY;
int lineTraceStartTimePoint;
int lineTraceEndX;
int lineTraceEndY;
int lineTraceEndTimePoint; 
int lineTraceActive;
int lineTraceDeleteOn;
int lineExportColor;
int lineExportWidth;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        initialSetOperation = 0;
        analysisLoadOperation = 0;
        trackingTableOperation = 0;
        navigationOperation = 0;
        listWindowOperation = 0;
        searchWindowOperation = 0;
        maxTimePoint = 0;
        timeOneHold = 0;
        timeEndHold = 0;
        ifStartHold = 0;
        imageEndHold = 0;
        setStatus1 = 0;
        setStatus2 = 0;
        setStatus3 = 0;
        setStatus4 = 0;
        setStatus5 = 0;
        setStatus6 = 0;
        setStatus7 = 0;
        setStatus8 = 0;
        addDelInsert = 0;
        clearBack = 0;
        doubleClick = 0;
        autoExpand = 1;
        autoExpandLine = 0;
        listCrickMonitor = 0;
        imageLoadMonitor = 0;
        trackingTableSetDone = 0;
        lineageCellSwitch = 0;
        trackingImageLock = 0;
        tableTrackingProcessing = 0;
        overTimeRemoveFlag = 0;
        divisionFusionCancelFlag = 0;
        autoRefStatus = 0;
        imageReadTiming = 0;
        imageReadTimingNavigation = 0;
        displaySetDICFlag = 0;
        displaySetFluorescentFlag = 0;
        displaySetCutFlag1 = 0;
        displaySetCutFlag2 = 0;
        displaySetCutFlag3 = 0;
        displaySetCutFlag4 = 0;
        displaySetCutFlag5 = 0;
        displaySetCutFlag6 = 0;
        displaySetCutFlag7 = 0;
        imageDimension = 0;
        trackingCheckInterval = 10;
        cellJumpFirstLast = 0;
        mitosisSaveCount = 0;
        errorInfoFlag = "0";
        imageReturnPositionSet = 0;
        analysisSavingInProgress = 0;
        mainSavingInProgress = 0;
        cleaningProgress = 0;
        progressValue = 0;
        progressTiming = 0;
        progressTimingB = 0;
        progressTimingC = 0;
        lineWidth = 1;
        lineTypeSet = 0;
        cleaningManualProgress = 0;
        firstCleaningFlag = 0;
        dataEntryStatus = 0;
        errorNoHold = 0;
        
        tableRowHold = 0;
        tableCallCount = 0;
        
        cellLineageInfoListCreationCall = 0;
        cellNumberInfoListCreationCall = 0;
        displayWindowCall = 0;
        listSwitchCall = 1;
        listSwitchCallStatus = 0;
        quickLineSetCall = 0;
        quickLineageCall = 0;
        quickConnectCall = 0;
        inputNumber = 0;
        inputNumberCall = 0;
        
        cellLineageInfoStatus = 0;
        cellNumberInfoStatus = 0;
        lineageDataStatus = 0;
        lineagePartnerInfoStatus = 0;
        timePointListSaveStatus = 0;
        restoreDataFlag = 0;
        autoCheckFlag = 0;
        autoCheckTempStatus = 0;
        phaseStatus = 0;
        
        fluorescentDisplayMode = 0;
        fluorescentDisplayRange = 2;
        fluorescentDisplayMax = 255;
        
        analysisImageName = "";
        analysisImageNameSelect = "";
        analysisID = "";
        analysisIDSelect = "";
        treatmentNameHold = "";
        treatmentNameKeep = "";
        cellLineageNoHold = "";
        cellNoHold = "";
        
        listTableCall = 0;
        
        divisionTypeHold = 0;
        divisionWarningType = 0;
        fusionOperation = 0;
        fusionPartnerLin = 0;
        fusionPartnerCellNo = -1;
        fusionMarkImage = 10000;
        fusionStatusFollow = 0;
        saveShortCutNumber = 0;
        listOnOffFlag = 0;
        listHoldProcessFlag = 0;
        forceSetAutoFlag = 0;
        lineageWritingCheck = 0;
        
        trackJump = 0;
        displayJump = 0;
        removeAll = 0;
        trackingOn = 0;
        trackingOnInfoDisplay = 0;
        windowLock = 0;
        doubleClickStatusHold = 0;
        tableListSwitch = 1;
        trackingPermit = 0;
        firstModificationPoint = 10000;
        lineModificationFlag = 0;
        cutBase = 0;
        lineModificationRecord = 0;
        characterDisplayFlag = 0;
        characterDisplayNavFlag = 0;
        cutOff1 = 240;
        cutOff2 = 230;
        cutOff3 = 220;
        cutOff4 = 190;
        cutOff5 = 160;
        cutOff6 = 130;
        cutOff7 = 90;
        cutStatusDic = 0;
        cutStatusFluorescent = 0;
        cutDisplay = 7;
        backForwardMode = 0;
        mergeAllFlag = 0;
        
        lineSetWindowCallTrack = 0;
        lineSetWindowCallDisplay = 0;
        lineAreaCall = 0;
        gravityCenterNotRecorded = "nil";
        
        connectLineListLocalStatus = 0;
        lineageStartEndStatus = 0;
        masterLineForTrackingStatus = 0;
        masterLineForDisplayStatus = 0;
        masterLineGravityCenterStatus = 0;
        masterLineSelectedStatus = 0;
        positionReviseStatus = 0;
        targetHoldStatus = 0;
        connectLineageRelStatus = 0;
        masterLineSelectedDisplayStatus = 0;
        masterLineGCDisplayStatus = 0;
        gravityCenterRevStatus = 0;
        timeSelectedStatus = 0;
        timeSelectedHoldStatus = 0;
        associateDataStatus = 0;
        attachedNumberListStatus = 0;
        groupNumberListStatus = 0;
        cellEndHoldStatus = 0;
        
        sourceImageStatus = 0;
        revisedMapStatus = 0;
        revisedWorkingMapStatus = 0;
        revisedWorkingMapTime2 = 0;
        revisedWorkingMapSize2 = 0;
        revisedWorkingMapStatus2 = 0;
        revisedWorkingMapName2 = "";
        
        listPatternStatus = 0;
        
        divisionWarning = "";
        targetLostMark = "";
        cutLimitValueHold = 20;
        cutDisplayValueHold = 90;
        forceSetStatus = 0;
        
        magnificationTrack = 10;
        keyLockON = 0;
        
        magnificationDisplay = 10;
        imageNumberDisplayForDisplay = 0;
        synchroOn = 0;
        
        listDisplaySelection = 0;
        listToTrackCall = 0;
        currentPageNoCell = 1;
        currentPageNoMitosis = 1;
        boxImageNumber = 0;
        
        listLingNoHold = "";
        listCellNoHold = "";
        listLingRecent = "";
        listCellRecent = "";
        listLingCurrent = "";
        listCellCurrent = "";
        listLoadingProcessing = 0;
        
        timeOneStatus = 0;
        tableDataSetDone = 0;
        timeOneX = 0;
        timeOneY = 0;
        timeOneQuickSet = 0;
        currentConnectNo = 0;
        currentPositionSet = 1;
        timeOneLaunch = 0;
        
        dicAllStartFlag = 0;
        
        connectionSend1 = 0;
        queueRestartFlag = 0;
        multipleLaunchBlock = 0;
        firstTrackStart = 0;
        reviseTimingCount = 0;
        upDateCompleteFlag = 0;
        
        runStatusCellCurving = 0;
        cellCurvingRunningFlag = 0;
        subCompleteFlag = 0;
        
        fluorescentNo1 = 0;
        fluorescentNo2 = 0;
        fluorescentNo3 = 0;
        fluorescentNo4 = 0;
        fluorescentNo5 = 0;
        fluorescentNo6 = 0;
        fluorescentEntryCount = 0;
        fluorescentDetection = 0;
        fluorescentDisplayNo = 0;
        fluorescentDetectionDisplay = 0;
        fluorescentCutOff1 = 150;
        fluorescentCutOff2 = 150;
        fluorescentCutOff3 = 150;
        fluorescentCutOff4 = 150;
        fluorescentCutOff5 = 150;
        fluorescentCutOff6 = 150;
        fluorescentValueDisplayControl = 0;
        sliderBarSet = 0;
        
        fluorescentMapStatus1 = 0;
        fluorescentMapFind1 = 0;
        fluorescentMapStatus2 = 0;
        fluorescentMapFind2 = 0;
        fluorescentMapStatus3 = 0;
        fluorescentMapFind3 = 0;
        fluorescentMapStatus4 = 0;
        fluorescentMapFind4 = 0;
        fluorescentMapStatus5 = 0;
        fluorescentMapFind5 = 0;
        fluorescentMapStatus6 = 0;
        fluorescentMapFind6 = 0;
        expandFluorescentOutlineStatus = 0;
        expandFluorescentDataStatus = 0;
        connectDataExchangeStatus = 0;
        fluorescentCutOffStatus = 0;
        
        fluorescentName1 = "";
        fluorescentName2 = "";
        fluorescentName3 = "";
        fluorescentName4 = "";
        fluorescentName5 = "";
        fluorescentName6 = "";
        fluorescentColorNameTemp1 = "";
        fluorescentColorNameTemp2 = "";
        fluorescentColorNameTemp3 = "";
        fluorescentColorNameTemp4 = "";
        fluorescentColorNameTemp5 = "";
        fluorescentColorNameTemp6 = "";
        
        ifEntry = 0;
        fluorescentNoHold1 = 0;
        fluorescentNoHold2 = 0;
        fluorescentNoHold3 = 0;
        fluorescentNoHold4 = 0;
        fluorescentNoHold5 = 0;
        fluorescentNoHold6 = 0;
        fluorescentEntryCountHold = 0;
        fluorescentNameHold1 = "";
        fluorescentNameHold2 = "";
        fluorescentNameHold3 = "";
        fluorescentNameHold4 = "";
        fluorescentNameHold5 = "";
        fluorescentNameHold6 = "";
        fluorescentRoundNo = "";
        
        tableCallSearchCount = 0;
        lineageDataSearchStatus = 0;
        lineageStartEndSearchStatus = 0;
        lineageListStatus = 0;
        searchCellListStatus = 0;
        
        optionCall = 0;
        optionDisplayCall = 0;
        optionWindowOperation = 0;
        tableRowHoldOperation = 0;
        tableCallOperationCount = 0;
        operationDataStatus = 0;
        
        parameterSethWindowOperation = 0;
        forAreaSizeCount = 0;
        
        repairWindowOperation = 0;
        checkListStatus = 0;
        checkErrorTimeListStatus = 0;
        repairOperationTableCurrentRow = 0;
        checkResultsStatus = 0;
        listStringStatus = 0;
        repairListTableCurrentRow = 0;
        treatmentMainDisplayCall = 0;
        secondLineDisplayCall = 0;
        secondLineDisplayRemoveCall = 0;
        verificationPositionCall = 0;
        connectVer = 0;
        progressControl = 0;
        checkOverrideFlag = 0;
        
        imageSeqOperation = 0;
        seqImageClick = 0;
        seqImageFirst = 0;
        seqImageLast = 0;
        seqImageCheck = 0;
        seqImageMitosis = 0;
        seqImageFusionMark = 0;
        seqImageTop = 0;
        seqOpenFlag = 0;
        noOfSeqDisplay = 1;
        imageWidthSeq = 130;
        seqWindowFront = 0;
        trackForwardControl = 0;
        
        fluorescentDivisionTime = 0;
        fluorescentDivisionCh = 0;
        fluorescentOptionOperation = 0;
        fluorescentOpOperationTableCurrentRow = 0;
        fluorescentOpInformationStatus = 0;
        fluorescentLevelDataStatus = 0;
        
        exportOperation = 0;
        positionExportStatus = 0;
        gravityCenterExportStatus = 0;
        timeSelectedExportStatus = 0;
        colorListStatus = 0;
        channelNoExport = 0;
        outlineWidthExport = 1;
        nonTargetWidthExport = 5;
        nonTargetLengthExport = 2;
        nonTargetFontExport = 2;
        targetWidthExport = 5;
        targetLengthExport = 2;
        targetFontExport = 2;
        titleFontExport = 4;
        titleNameExport = 0;
        titleNameExportHold = "";
        timingEx = 0;
        startExport = 0;
        endExport = 0;
        windowLock = 0;
        densityModeHold = 0;
        circleAreaHoldStatus = 0;
        lineageFontColorExport = 0;
        displayImageLoadPath = "";
        densityDiameterHold = 0;
        densityValueMaxHold = 0;
        lineageLimitHold = 0;
        motilityBasicInfoStatus = 0;
        thresholdCutHold = 0;
        areaSizeMinHold = 0;
        areaSizeMaxHold = 0;
        thresholdStatusHold = 0;
        particleCountingDataHoldStatus = 0;
        xyPositionCall = 0;
        displayOutlineSet = 1;
        displayNonTargetSet = 1;
        displayTargetFontSizeSet = 1;
        lineTraceOnOff = 0;
        lineTraceDeleteOn = 0;
        lineExportColor = 0;
        lineExportWidth = 0;
        
        treatmentDisplayFirstSet = 0;
        firstCleaningFlag = 0;
        
        arraySelectedTreatmentProc = new string [100];
        selectedTreatmentProcCount = 0;
        arrayDirectoryInitialInfo = new string [500];
        directoryInitialInfoCount = 0;
        directoryInitialInfoLimit = 500;
        arrayTrackingList = new string [500];
        trackingListCount = 0;
        trackingListLimit = 500;
        arrayDirectoryInfo = new string [500];
        directoryInfoCount = 0;
        directoryInfoLimit = 500;
        arrayQueueList = new string [5000];
        queueListCount = 0;
        queueListLimit = 5000;
        arrayQueueListDisplay = new string [5000];
        queueListDisplayCount = 0;
        queueListDisplayLimit = 5000;
        arrayDoneList = new string [5000];
        doneListCount = 0;
        doneListLimit = 5000;
        arrayDoneListDisplay = new string [5000];
        doneListDisplayCount = 0;
        doneListDisplayLimit = 5000;
        arrayTreatmentStatus = new string [200];
        treatmentStatusCount = 0;
        arrayGetList = new string [500];
        getListCount = 0;
        getListLimit = 500;
        arrayImageSizeList = new string [200];
        imageSizeListCount = 0;
        arrayIFDataHold = new string [450];
        fusionPartnerInfo = new int [50];
        fusionPartnerInfoCount = 0;
        fusionPartnerInfoLimit = 50;
        arrayMergeSelect = new int [10];
        mergeSelectCount = 0;
        arrayListHold = new string [60];
        listHoldCount = 0;
        arrayMitosisSDInfo = new double [25];
        mitosisInfoSetCount = 0;
        mitosisInfoRemoveCount = 0;
        arrayMitosisValueInfo = new int [25];
        arrayLineTrace = new string [500];
        lineTraceCount = 0;
        lineTraceLimit = 500;
        lineTraceStatus = 0;
    }
    
    return self;
}

- (void)awakeFromNib{
    [trackingIntervalDisplay setDelegate:self];
    [limitIntervalDisplay setDelegate:self];
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [tableViewList setDataSource:self];
    
    [fluorescentQuantTimeDisplay setDelegate:self];
    [fluorescentQuantChDisplay setDelegate:self];
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    imageFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    trackDataFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data";
    masterDataFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"06_Cell_Tracking_images";
    instructionCCPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"CC_Instruction";
    instructionRRPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"RR_Instruction";
    backUpTempPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveBackUp";
    
    [sliderFluorescent setMaxValue:255];
    [sliderFluorescent setMinValue:1];
    
    [stepperFluorescentSetCount setMinValue:0];
    [stepperFluorescentSetCount setMaxValue:4];
    [stepperFluorescentSetCount setIntValue:0];
    
    mkdir(trackDataFolderPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    mkdir(backUpTempPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    [self initialConditionSet];
    
    [trackingIntervalDisplay setIntegerValue:trackingCheckInterval];
    [stepperInterval setIntValue:[trackingIntervalDisplay intValue]];
    
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [controller frame];
    
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 20;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    [controller setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    arrayForAreaSize = new double [70];
    forAreaSizeCount = 0;
    
    controllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(statusCheck) userInfo:nil repeats:YES];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCommunication object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToActiveProcess object:self];
}

-(void)initialConditionSet{
    [listTreatmentDisplay setStringValue:@""];
    [inputNoSet setStringValue:@""];
    [errorExplanationDisplay setStringValue:@"nil"];
    [optionCheck setStringValue:@""];
    
    //-----Saved condition check-----
    string savedDataPath = trackDataFolderPath+"/*LineageTrackingCurrent.dat";
    string getString;
    
    //-----Saved condition read-----
    ifstream fin;
    fin.open(savedDataPath.c_str(), ios::in);
    
    if (fin.is_open()){
        treatmentStatusCount = 0;
        queueDisplayOptions = 0;
        doneDisplayOptions = 0;
        imageReturnPosition = 0;
        
        getline(fin, getString), analysisImageName = getString;
        getline(fin, getString), analysisID = getString;
        getline(fin, getString), autoExpand = atoi(getString.c_str());
        getline(fin, getString), autoExpandLine = atoi(getString.c_str());
        getline(fin, getString), trackingCheckInterval = atoi(getString.c_str());
        getline(fin, getString), queueDisplayOptions = atoi(getString.c_str());
        getline(fin, getString), doneDisplayOptions = atoi(getString.c_str());
        getline(fin, getString), imageReturnPosition = atoi(getString.c_str());
        getline(fin, getString), fluorescentEntryCount = atoi(getString.c_str());
        getline(fin, getString), fluorescentNo1 = atoi(getString.c_str());
        getline(fin, getString), fluorescentNo2 = atoi(getString.c_str());
        getline(fin, getString), fluorescentNo3 = atoi(getString.c_str());
        getline(fin, getString), fluorescentNo4 = atoi(getString.c_str());
        getline(fin, getString), fluorescentNo5 = atoi(getString.c_str());
        getline(fin, getString), fluorescentNo6 = atoi(getString.c_str());
        getline(fin, getString);
        
        if (getString == "nil") fluorescentName1 = "";
        else fluorescentName1 = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") fluorescentName2 = "";
        else fluorescentName2 = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") fluorescentName3 = "";
        else fluorescentName3 = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") fluorescentName4 = "";
        else fluorescentName4 = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") fluorescentName5 = "";
        else fluorescentName5 = getString;
        
        getline(fin, getString);
        
        if (getString == "nil") fluorescentName6 = "";
        else fluorescentName6 = getString;
        
        for (int counter1 = 0; counter1 < 16; counter1++){
            getline(fin, getString);
            
            if (getString != "IFDATA"){
                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                getline(fin, getString);
                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
            }
            else{
                
                break;
            }
        }
        
        for (int counter1 = 0; counter1 < 450; counter1++) arrayIFDataHold [counter1] = "nil";
        
        int ifDataHoldCount = 0;
        
        for (int counter1 = 0; counter1 < 450; counter1 = counter1+156){
            getline(fin, getString);
            
            if (getString != "END"){
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                getline(fin, getString);
                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
            }
            else{
                
                break;
            }
        }
        
        fin.close();
        
        //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
        //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < 90/9; counterA++){
        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
        //    cout<<" arrayIFDataHold "<<counterA<<endl;
        //}
        
        if (queueDisplayOptions == 0) [queueOptionCheck setStringValue:@"AL"];
        else if (queueDisplayOptions == 1) [queueOptionCheck setStringValue:@"TR"];
        else if (queueDisplayOptions == 2) [queueOptionCheck setStringValue:@"CK"];
        else if (queueDisplayOptions == 3) [queueOptionCheck setStringValue:@"TE"];
        else if (queueDisplayOptions == 4) [queueOptionCheck setStringValue:@"AU"];
        
        if (doneDisplayOptions == 0) [doneOptionCheck setStringValue:@"AL"];
        else if (doneDisplayOptions == 1) [doneOptionCheck setStringValue:@"TR"];
        else if (doneDisplayOptions == 2) [doneOptionCheck setStringValue:@"CK"];
        else if (doneDisplayOptions == 3) [doneOptionCheck setStringValue:@"OK"];
        else if (doneDisplayOptions == 4) [doneOptionCheck setStringValue:@"AU"];
        
        if (imageReturnPosition == 0) [returnOptionCheck setStringValue:@"LT"];
        else if (imageReturnPosition == 1) [returnOptionCheck setStringValue:@"CK"];
        
        string entry;
        string treatmentNameTemp;
        string sourceImagePath;
        string entryNumber;
        string sourceImagePath2;
        string extension;
        
        imageSizeListCount = 0;
        
        int bitPosition = 0;
        int imageSizeTemp = 0;
        int bitData = 0;
        int verticalBit [4];
        
        unsigned long stripFirstAddress = 0;
        unsigned long stripByteCountAddress = 0;
        unsigned long nextAddress = 0;
        unsigned long headPosition = 0;
        unsigned long stripEntry = 0;
        
        double xPosition = 0;
        double yPosition = 0;
        
        int imageWidth = 0;
        int imageHeight = 0;
        int imageBit = 0; //Check 8, 16
        int imageCompression = 0; //Check 1
        int photoMetric = 0;//Check 0, 1, 2
        int endianType = 0;
        int samplePerPix = 0;
        int dataConversion [4];
        int numberOfLayers = 0;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            treatmentNameTemp = arrayTreatmentStatus [counter1*9];
            
            sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameTemp+"_Stitch/";
            entryNumber = "";
            
            DIR *dir = opendir(sourceImagePath.c_str());
            struct dirent *dent;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("STimage") != -1){
                            entryNumber = entry;
                            
                            if ((int)entry.find("tif") != -1 || (int)entry.find("TIF") != -1){
                                exType = ".tif";
                                exTypeIF = ".TIF";
                            }
                            else if ((int)entry.find("bmp") != -1 || (int)entry.find("BMP") != -1){
                                exType = ".bmp";
                                exTypeIF = ".BMP";
                            }
                            
                            break;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            sourceImagePath2 = sourceImagePath+entryNumber;
            imageSizeTemp = 512;
            
            if (exType == ".tif"){
                tifImageColorGray = 0;
                
                struct stat sizeOfFile;
                long sizeForCopy = 0;
                
                if (stat(sourceImagePath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fileReadArray = new uint8_t [sizeForCopy+50];
                    fin.open(sourceImagePath2.c_str(), ios::in | ios::binary);
                    
                    fin.read((char*)fileReadArray, sizeForCopy+50);
                    fin.close();
                    
                    dataConversion [0] = fileReadArray [0];
                    dataConversion [1] = fileReadArray [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = fileReadArray [7];
                        dataConversion [1] = fileReadArray [6];
                        dataConversion [2] = fileReadArray [5];
                        dataConversion [3] = fileReadArray [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = fileReadArray [4];
                        dataConversion [1] = fileReadArray [5];
                        dataConversion [2] = fileReadArray [6];
                        dataConversion [3] = fileReadArray [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    if (endianType == 1){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (photoMetric == 2) tifImageColorGray = 1;
                        else if (photoMetric == 0) tifImageColorGray = 0;
                        
                        imageSizeTemp = imageWidth;
                    }
                    else if (endianType == 0){
                        tiffFileRead = [[TiffFileRead alloc] init];
                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                        
                        if (photoMetric == 2) tifImageColorGray = 1;
                        else if (photoMetric == 0) tifImageColorGray = 0;
                        
                        imageSizeTemp = imageWidth;
                    }
                    
                    extension = to_string (imageSizeTemp);
                    
                    arrayImageSizeList [imageSizeListCount] = treatmentNameTemp, imageSizeListCount++; //-----Treat Name-----
                    arrayImageSizeList [imageSizeListCount] = extension, imageSizeListCount++; //-----Size-----
                    
                    delete [] fileReadArray;
                }
            }
            else if (exType == ".bmp"){
                bitPosition = 0;
                
                fin.open(sourceImagePath2.c_str(),ios::in | ios::binary);
                
                if (fin.is_open()){
                    while ((bitData = fin.get()) != EOF){
                        if (bitPosition == 22) verticalBit [0] = bitData;
                        if (bitPosition == 23) verticalBit [1] = bitData;
                        if (bitPosition == 24) verticalBit [2] = bitData;
                        if (bitPosition == 25){
                            verticalBit [3] = bitData;
                            
                            imageSizeTemp = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                            break;
                        }
                        
                        bitPosition++;
                    }
                    
                    fin.close();
                    
                    extension = to_string (imageSizeTemp);
                    
                    arrayImageSizeList [imageSizeListCount] = treatmentNameTemp, imageSizeListCount++; //-----Treat Name-----
                    arrayImageSizeList [imageSizeListCount] = extension, imageSizeListCount++; //-----Size-----
                }
            }
        }
    }
    else{
        
        analysisImageName = "";
        analysisID = "";
        treatmentStatusCount = 0;
        imageSizeListCount = 0;
        autoExpand = 1;
        autoExpandLine = 0;
    }
    
    if (autoExpand == 1) [autoExpandDisplay setStringValue:@"On"];
    else [autoExpandDisplay setStringValue:@"Off"];
    
    if (autoExpandLine == 1) [autoExpandLineDisplay setStringValue:@"On"];
    else [autoExpandLineDisplay setStringValue:@"Off"];
    
    //-----If Saved Conditions were found, check whether "_TrackData" folder is created. If not, clear variables and array-----
    int findFlag1 = 0;
    int findFlag2 = 0;
    
    if (analysisImageName != "" && analysisID != ""){
        string referenceString1 = analysisImageName+"_Series";
        string referenceString2 = analysisID+"_TrackData";
        string entry;
        string entry2;
        string analysisIDPath;
        
        DIR *dir = opendir(trackDataFolderPath.c_str());
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if (referenceString1 == entry){
                        findFlag1 = 1;
                        analysisIDPath = trackDataFolderPath+"/"+referenceString1;
                        
                        dir2 = opendir(analysisIDPath.c_str());
                        
                        if (dir2 != NULL){
                            while ((dent2 = readdir(dir2))){
                                entry2 = dent2 -> d_name;
                                
                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                    if (referenceString2 == entry2){
                                        findFlag2 = 1;
                                        break;
                                    }
                                }
                            }
                            
                            closedir(dir2);
                        }
                        if (findFlag1 == 1){
                            break;
                        }
                    }
                }
            }
            
            closedir(dir);
        }
        else{
            
            analysisImageName = "";
            analysisID = "";
            treatmentStatusCount = 0;
            imageSizeListCount = 0;
        }
    }
    else{
        
        analysisImageName = "";
        analysisID = "";
        treatmentStatusCount = 0;
        imageSizeListCount = 0;
    }
    
    //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
    //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
    //}
    
    //-----If both findFlag1 != 0, findFlag2 != 0, start process: if it is not, do initial selection or Analysis load-----
    if (findFlag1 == 1 && findFlag2 == 1){
        [analysisSeriesDisplay setStringValue:@(analysisImageName.c_str())];
        [analysisIDDisplay setStringValue:@(analysisID.c_str())];
        [timeOneDisplay setStringValue:@"nil"];
        [timeEndDisplay setStringValue:@"nil"];
        [timeMaxDisplay setStringValue:@"nil"];
        [ifStartDisplay setStringValue:@"nil"];
        [imageEndDisplay setStringValue:@"nil"];
        
        if (fluorescentNo1 == 1){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 2){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 3){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 4){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 5){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 6){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 7){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 8){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 9){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 0){
            [ch2Label setTextColor:[NSColor blackColor]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor blackColor]];
            [ch2Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo2 == 1){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 2){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 3){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 4){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 5){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 6){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 7){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 8){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 9){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 0){
            [ch3Label setTextColor:[NSColor blackColor]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor blackColor]];
            [ch3Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo3 == 1){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 2){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 3){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 4){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 5){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 6){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 7){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 8){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 9){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 0){
            [ch4Label setTextColor:[NSColor blackColor]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor blackColor]];
            [ch4Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo4 == 1){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 2){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 3){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 4){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 5){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 6){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 7){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 8){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 9){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 0){
            [ch5Label setTextColor:[NSColor blackColor]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor blackColor]];
            [ch5Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo5 == 1){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 2){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 3){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 4){
            [ch6Label setTextColor:[NSColor redColor]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 5){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 6){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 7){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 8){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 9){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 0){
            [ch6Label setTextColor:[NSColor blackColor]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor blackColor]];
            [ch6Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo6 == 1){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 2){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 3){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 4){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 5){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 6){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 7){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 8){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 9){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 0){
            [ch7Label setTextColor:[NSColor blackColor]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor blackColor]];
            [ch7Display setStringValue:@"nil"];
        }
        
        //-----Queue control status-----
        queueHoldingStatus = 0;
        [queueHoldingDisplay setTextColor:[NSColor blackColor]];
        [queueHoldingDisplay setStringValue:@"Holding"];
        
        //-----QueueList and DoneList read-----
        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
        string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
        
        long sizeForQueue = 0;
        long sizeForDone = 0;
        queueListCount = 0;
        doneListCount = 0;
        
        struct stat sizeOfFile;
        
        if (stat(queueListPath.c_str(), &sizeOfFile) == 0){
            sizeForQueue = sizeOfFile.st_size;
        }
        
        if (stat(doneListPath.c_str(), &sizeOfFile) == 0){
            sizeForDone = sizeOfFile.st_size;
        }
        
        if (sizeForQueue != 0){
            if (queueListLimit < sizeForQueue){
                queueListLimit = (int)sizeForQueue+5000;
                
                delete [] arrayQueueList;
                arrayQueueList = new string [queueListLimit];
            }
            
            fin.open(queueListPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForQueue];
                fin.read((char*)uploadTemp, sizeForQueue);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        arrayQueueList [queueListCount] = dataString, queueListCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        string extension = to_string(imageEndHold);
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            if (arrayQueueList [counter1*6+5] == "Proc"){
                arrayQueueList [counter1*6+5] = "Wait";
                break;
            }
        }
        
        if (sizeForDone != 0){
            if (doneListLimit < sizeForDone){
                doneListLimit = (int)sizeForDone+5000;
                
                delete [] arrayDoneList;
                arrayDoneList = new string [doneListLimit];
            }
            
            fin.open(doneListPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForDone];
                fin.read((char*)uploadTemp, sizeForDone);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        arrayDoneList [doneListCount] = dataString, doneListCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
        //	cout<<" arrayQueueList "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < doneListCount/5; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
        //    cout<<" arrayDoneList "<<counterA<<endl;
        //}
        
        //-----Treatment status set: 1. TreatmentName, 2. Lineage Data Check, 3. LineageStatus Check, 4. Other 8 files check-----
        string nameString;
        string lineageFilePath;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            extension = arrayTreatmentStatus [counter1*9+4];
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            nameString = arrayTreatmentStatus [counter1*9];
            findFlag1 = 0;
            
            lineageFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+nameString+"_Connect/"+analysisID+"_"+nameString+"_LineageData";
            
            fin.open(lineageFilePath.c_str(), ios::in);
            
            if (fin.is_open()) arrayTreatmentStatus [counter1*9+1] = "1", fin.close();
            else arrayTreatmentStatus [counter1*9+1] = "0";
            
            lineageFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+nameString+"_Connect/"+analysisID+"_"+nameString+"_LineageStatus";
            
            fin.open(lineageFilePath.c_str(), ios::in);
            
            if (fin.is_open()) arrayTreatmentStatus [counter1*9+2] = "1", fin.close();
            else arrayTreatmentStatus [counter1*9+2] = "0";
            
            lineageFilePath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+nameString+"_Processed/"+extension+"_"+analysisImageName+"_"+nameString+"_Map";
            fin.open(lineageFilePath.c_str(), ios::in);
            
            if (fin.is_open()) fin.close();
            else findFlag1 = 1;
            
            lineageFilePath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+nameString+"_Processed/"+extension+"_"+analysisImageName+"_"+nameString+"_MasterData";
            fin.open(lineageFilePath.c_str(), ios::in);
            
            if (fin.is_open()) fin.close();
            else findFlag1 = 1;
            
            if (findFlag1 == 0) arrayTreatmentStatus [counter1*9+3] = "1";
            else arrayTreatmentStatus [counter1*9+3] = "0";
        }
        
        //cout<<analysisImageName<<" "<<analysisID<<" "<<timeOneHold<<" "<<timeEndHold<<" "<<maxTimePoint<<" SetData"<<endl;
        
        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
        
        arrayOperationData = new int [treatmentStatusCount/9*4+50];
        operationDataStatus = 1;
        
        fin.open(optionPath.c_str(), ios::in);
        
        if (fin.is_open()){
            int entryCount = 0;
            
            do{
                
                getline(fin, getString);
                
                if (getString != "End"){
                    arrayOperationData [entryCount] = atoi(getString.c_str()), entryCount++;
                    getline(fin, getString);
                    arrayOperationData [entryCount] = atoi(getString.c_str()), entryCount++;
                    getline(fin, getString);
                    arrayOperationData [entryCount] = atoi(getString.c_str()), entryCount++;
                    getline(fin, getString);
                    arrayOperationData [entryCount] = atoi(getString.c_str()), entryCount++;
                }
                
            } while (getString != "End");
            
            fin.close();
        }
        else{
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                arrayOperationData [counter1*4] = 0;
                arrayOperationData [counter1*4+1] = 0;
                arrayOperationData [counter1*4+2] = 0;
                arrayOperationData [counter1*4+3] = 1;
            }
        }
        
        string trackingParameterPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"TrackingParameters";
        
        fin.open(trackingParameterPath.c_str(), ios::in);
        
        if (fin.is_open()){
            getline(fin, getString);
            autoTrackingLimitHold = atoi(getString.c_str());
            getline(fin, getString);
            mitosisSDHold = atof(getString.c_str());
            getline(fin, getString);
            mitosisValueHold = atoi(getString.c_str());
            getline(fin, getString);
            divisionDistanceHold = atoi(getString.c_str());
            getline(fin, getString);
            mitosisAreaHold = atoi(getString.c_str());
            getline(fin, getString);
            mitosisRelativeLowHold = atof(getString.c_str());
            getline(fin, getString);
            mitosisRelativeHighHold = atof(getString.c_str());
            getline(fin, getString);
            jumpAllFlag = atoi(getString.c_str());
            getline(fin, getString);
            connectExpandFlag = atoi(getString.c_str());
            getline(fin, getString);
            mapMergeStatus = atoi(getString.c_str());
            getline(fin, getString);
            percentOverlap = atoi(getString.c_str());
            getline(fin, getString);
            gravityCenterMoveLimitFlag = atoi(getString.c_str());
            getline(fin, getString);
            autoCheckDistanceHold = atoi(getString.c_str());
            getline(fin, getString);
            autoCheckAreaHold = atoi(getString.c_str());
            getline(fin, getString);
            autoCheckDivisionHold = atoi(getString.c_str());
            getline(fin, getString);
            autoCheckDistanceFoldHold = atoi(getString.c_str());
            getline(fin, getString);
            autoCheckIntensityHold = atoi(getString.c_str());
            getline(fin, getString);
            optionalShiftPercent = atoi(getString.c_str());
            getline(fin, getString);
            mitosisOffFlag = atoi(getString.c_str());
            getline(fin, getString);
            fusionMarkSetFlag = atoi(getString.c_str());
            fin.close();
        }
        else{
            
            autoTrackingLimitHold = 0;
            mitosisSDHold = 0.25;
            mitosisValueHold = 200;
            divisionDistanceHold = 50;
            mitosisAreaHold = 50;
            mitosisRelativeLowHold = 0.8;
            mitosisRelativeHighHold = 1.25;
            jumpAllFlag = 0;
            connectExpandFlag = 0;
            mapMergeStatus = 0;
            percentOverlap = 40;
            gravityCenterMoveLimitFlag = 0;
            autoCheckDistanceHold = 1;
            autoCheckAreaHold = 1;
            autoCheckDivisionHold = 1;
            autoCheckDistanceFoldHold = 1;
            autoCheckIntensityHold = 1;
            optionalShiftPercent = 20;
            mitosisOffFlag = 0;
            fusionMarkSetFlag = 0;
        }
        
        [limitIntervalDisplay setIntegerValue:autoTrackingLimitHold];
        
        string mitosisDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/mitosisParameter.dat";
        
        for (int counter1 = 0; counter1 < 20; counter1++){
            arrayMitosisSDInfo [counter1] = 0;
            arrayMitosisValueInfo [counter1] = 0;
        }
        
        long sizeForCopy = 0;
        
        if (stat(mitosisDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            fin.open(mitosisDataPath.c_str(), ios::in);
            
            if (fin.is_open()){
                for (int counter1 = 0; counter1 < 20; counter1++){
                    getline(fin, getString);
                    arrayMitosisSDInfo [counter1] = atof(getString.c_str());
                }
                
                for (int counter1 = 0; counter1 < 20; counter1++){
                    getline(fin, getString);
                    arrayMitosisValueInfo [counter1] = atoi(getString.c_str());
                }
                
                getline(fin, getString);
                mitosisInfoSetCount = atoi(getString.c_str());
                getline(fin, getString);
                mitosisInfoRemoveCount = atoi(getString.c_str());
                
                fin.close();
            }
        }
    }
    else{
        
        analysisImageName = "";
        analysisID = "";
        treatmentStatusCount = 0;
        imageSizeListCount = 0;
    }
    
    //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
    //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
    //}
    
    //-----Fluorescent quantitation option parameter set-----
    string fluorescentCountStatusPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FluoQuant";
    
    fin.open(fluorescentCountStatusPath.c_str(), ios::in);
    
    if (fin.is_open()){
        getline(fin, getString), fluorescentDivisionNo = atoi(getString.c_str());
        getline(fin, getString), fluorescentDivisionTime = atoi(getString.c_str());
        getline(fin, getString), fluorescentDivisionCh = atoi(getString.c_str());
        getline(fin, getString), fluorescentDivisionStatus = atoi(getString.c_str());
        
        if (fluorescentDivisionNo == 0){
            [fluorescentQuantDivNoDisplay setStringValue:@"nil"];
            [fluorescentQuantTimeDisplay setStringValue:@""];
            [fluorescentQuantChDisplay setStringValue:@""];
        }
        else{
            
            [fluorescentQuantDivNoDisplay setIntegerValue:fluorescentDivisionNo];
            [fluorescentQuantTimeDisplay setIntegerValue:fluorescentDivisionTime];
            [fluorescentQuantChDisplay setIntegerValue:fluorescentDivisionCh];
        }
        
        if (fluorescentDivisionStatus == 1) [fluorescentQuantStatusDisplay setStringValue:@"On"];
        else [fluorescentQuantStatusDisplay setStringValue:@"Off"];
        
        [stepperFluorescentSetCount setIntValue:fluorescentDivisionNo];
    }
    else{
        
        fluorescentDivisionNo = 0;
        fluorescentDivisionTime = 0;
        fluorescentDivisionCh = 0;
        fluorescentDivisionStatus = 0;
        
        [fluorescentQuantDivNoDisplay setStringValue:@"nil"];
        [fluorescentQuantStatusDisplay setStringValue:@"Off"];
        [fluorescentQuantTimeDisplay setStringValue:@""];
        [fluorescentQuantChDisplay setStringValue:@""];
    }
    
    arrayColorRange = new CGFloat [150];
    arrayColorRange [0] = 16/(double)255, arrayColorRange [1] = 22/(double)255, arrayColorRange [2] = 255/(double)255;
    arrayColorRange [3] = 31/(double)255, arrayColorRange [4] = 49/(double)255, arrayColorRange [5] = 237/(double)255;
    arrayColorRange [6] = 54/(double)255, arrayColorRange [7] = 88/(double)255, arrayColorRange [8] = 255/(double)255;
    arrayColorRange [9] = 43/(double)255, arrayColorRange [10] = 136/(double)255, arrayColorRange [11] = 255/(double)255;
    arrayColorRange [12] = 65/(double)255, arrayColorRange [13] = 178/(double)255, arrayColorRange [14] = 236/(double)255;
    arrayColorRange [15] = 77/(double)255, arrayColorRange [16] = 228/(double)255, arrayColorRange [17] = 249/(double)255;
    arrayColorRange [18] = 109/(double)255, arrayColorRange [19] = 250/(double)255, arrayColorRange [20] = 234/(double)255;
    arrayColorRange [21] = 104/(double)255, arrayColorRange [22] = 250/(double)255, arrayColorRange [23] = 203/(double)255;
    arrayColorRange [24] = 105/(double)255, arrayColorRange [25] = 247/(double)255, arrayColorRange [26] = 175/(double)255;
    arrayColorRange [27] = 104/(double)255, arrayColorRange [28] = 242/(double)255, arrayColorRange [29] = 119/(double)255;
    arrayColorRange [30] = 102/(double)255, arrayColorRange [31] = 242/(double)255, arrayColorRange [32] = 93/(double)255;
    arrayColorRange [33] = 108/(double)255, arrayColorRange [34] = 244/(double)255, arrayColorRange [35] = 58/(double)255;
    arrayColorRange [36] = 120/(double)255, arrayColorRange [37] = 242/(double)255, arrayColorRange [38] = 33/(double)255;
    arrayColorRange [39] = 110/(double)255, arrayColorRange [40] = 250/(double)255, arrayColorRange [41] = 53/(double)255;
    arrayColorRange [42] = 132/(double)255, arrayColorRange [43] = 255/(double)255, arrayColorRange [44] = 43/(double)255;
    arrayColorRange [45] = 166/(double)255, arrayColorRange [46] = 254/(double)255, arrayColorRange [47] = 46/(double)255;
    arrayColorRange [48] = 199/(double)255, arrayColorRange [49] = 255/(double)255, arrayColorRange [50] = 72/(double)255;
    arrayColorRange [51] = 244/(double)255, arrayColorRange [52] = 251/(double)255, arrayColorRange [53] = 51/(double)255;
    arrayColorRange [54] = 234/(double)255, arrayColorRange [55] = 225/(double)255, arrayColorRange [56] = 58/(double)255;
    arrayColorRange [57] = 234/(double)255, arrayColorRange [58] = 185/(double)255, arrayColorRange [59] = 44/(double)255;
    arrayColorRange [60] = 240/(double)255, arrayColorRange [61] = 136/(double)255, arrayColorRange [62] = 39/(double)255;
    arrayColorRange [63] = 229/(double)255, arrayColorRange [64] = 93/(double)255, arrayColorRange [65] = 41/(double)255;
    arrayColorRange [66] = 222/(double)255, arrayColorRange [67] = 64/(double)255, arrayColorRange [68] = 25/(double)255;
    arrayColorRange [69] = 246/(double)255, arrayColorRange [70] = 20/(double)255, arrayColorRange [71] = 40/(double)255;
    arrayColorRange [72] = 255/(double)255, arrayColorRange [73] = 0/(double)255, arrayColorRange [74] = 0/(double)255;
    
    //-----Other processings-----
    if (analysisImageName != "" && analysisID != "") [listBrowser reloadColumn:0];
}

-(void)statusCheck{
    //-----Browse view call-----
    if (setStatus1 == 1){
        setStatus1 = 0;
        [self initialConditionSet];
    }
    
    if (setStatus2 == 2){
        setStatus2 = 3;
        [listBrowser reloadColumn:1];
    }
    
    if (setStatus3 == 3 || setStatus7 == 7){
        if (setStatus8 == 1){
            setStatus8 = 2;
        }
        else if (setStatus8 >= 2 && setStatus8 < 5){
            setStatus8++;
        }
        else if (setStatus8 == 5){
            if (lineageWritingCheck == 0){
                setStatus8 = 0;
                [listBrowser reloadColumn:1];
            }
        }
    }
    
    if (setStatus4 == 4){
        setStatus4 = 0;
        
        [analysisSeriesDisplay setStringValue:@(analysisImageName.c_str())];
        [analysisIDDisplay setStringValue:@(analysisID.c_str())];
        
        if (timeOneHold == 0) [timeOneDisplay setStringValue:@"nil"];
        else [timeOneDisplay setIntegerValue:timeOneHold];
        
        if (timeEndHold == 0) [timeEndDisplay setStringValue:@"nil"];
        else [timeEndDisplay setIntegerValue:timeEndHold];
        
        if (maxTimePoint == 0) [timeMaxDisplay setStringValue:@"nil"];
        else [timeMaxDisplay setIntegerValue:maxTimePoint];
        
        if (ifStartHold == 0) [ifStartDisplay setStringValue:@"nil"];
        else [ifStartDisplay setIntegerValue:ifStartHold];
        
        if (imageEndHold == 0) [imageEndDisplay setStringValue:@"nil"];
        else [imageEndDisplay setIntegerValue:imageEndHold];
        
        if (fluorescentNo1 == 1){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 2){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 3){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 4){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 5){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 6){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 7){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 8){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 9){
            [ch2Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch2Display setStringValue:@(fluorescentName1.c_str())];
        }
        else if (fluorescentNo1 == 0){
            [ch2Label setTextColor:[NSColor blackColor]];
            [ch2Label setStringValue:@"Ch2:"];
            [ch2Display setTextColor:[NSColor blackColor]];
            [ch2Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo2 == 1){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 2){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 3){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 4){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 5){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 6){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 7){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 8){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 9){
            [ch3Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch3Display setStringValue:@(fluorescentName2.c_str())];
        }
        else if (fluorescentNo2 == 0){
            [ch3Label setTextColor:[NSColor blackColor]];
            [ch3Label setStringValue:@"Ch3:"];
            [ch3Display setTextColor:[NSColor blackColor]];
            [ch3Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo3 == 1){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 2){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 3){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 4){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 5){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 6){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 7){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 8){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 9){
            [ch4Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch4Display setStringValue:@(fluorescentName3.c_str())];
        }
        else if (fluorescentNo3 == 0){
            [ch4Label setTextColor:[NSColor blackColor]];
            [ch4Label setStringValue:@"Ch4:"];
            [ch4Display setTextColor:[NSColor blackColor]];
            [ch4Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo4 == 1){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 2){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 3){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 4){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 5){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 6){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 7){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 8){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 9){
            [ch5Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch5Display setStringValue:@(fluorescentName4.c_str())];
        }
        else if (fluorescentNo4 == 0){
            [ch5Label setTextColor:[NSColor blackColor]];
            [ch5Label setStringValue:@"Ch5:"];
            [ch5Display setTextColor:[NSColor blackColor]];
            [ch5Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo5 == 1){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 2){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 3){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 4){
            [ch6Label setTextColor:[NSColor redColor]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 5){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 6){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 7){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 8){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 9){
            [ch6Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch6Display setStringValue:@(fluorescentName5.c_str())];
        }
        else if (fluorescentNo5 == 0){
            [ch6Label setTextColor:[NSColor blackColor]];
            [ch6Label setStringValue:@"Ch6:"];
            [ch6Display setTextColor:[NSColor blackColor]];
            [ch6Display setStringValue:@"nil"];
        }
        
        if (fluorescentNo6 == 1){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 2){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 3){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:1 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 4){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 5){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0 blue:1 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 6){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0 green:1 blue:1 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 7){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:1 green:0.674 blue:0 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 8){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0.627 green:0.125 blue:0.941 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 9){
            [ch7Label setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor colorWithCalibratedRed:0.529 green:0.808 blue:0.922 alpha:1]];
            [ch7Display setStringValue:@(fluorescentName6.c_str())];
        }
        else if (fluorescentNo6 == 0){
            [ch7Label setTextColor:[NSColor blackColor]];
            [ch7Label setStringValue:@"Ch7:"];
            [ch7Display setTextColor:[NSColor blackColor]];
            [ch7Display setStringValue:@"nil"];
        }
    }
    
    if (setStatus5 == 5){
        setStatus5 = 0;
        
        if (timeOneHold == 0) [timeOneDisplay setStringValue:@"nil"];
        else [timeOneDisplay setIntegerValue:timeOneHold];
        
        if (timeEndHold == 0) [timeEndDisplay setStringValue:@"nil"];
        else [timeEndDisplay setIntegerValue:timeEndHold];
        
        if (maxTimePoint == 0) [timeMaxDisplay setStringValue:@"nil"];
        else [timeMaxDisplay setIntegerValue:maxTimePoint];
        
        if (ifStartHold == 0) [ifStartDisplay setStringValue:@"nil"];
        else [ifStartDisplay setIntegerValue:ifStartHold];
        
        if (imageEndHold == 0) [imageEndDisplay setStringValue:@"nil"];
        else [imageEndDisplay setIntegerValue:imageEndHold];
    }
    
    //-----Time one Table view control-----
    if (tableDataSetDone == 1){
        tableDataSetDone = 2;
        
        NSInteger lowClear = [tableViewList selectedRow];
        
        if (lowClear != -1) [tableViewList deselectRow:lowClear];
        
        [tableViewList reloadData];
    }
    
    //-----Tracking Table view control-----
    if (tableTrackingProcessing == 1){
        tableTrackingProcessing = 2;
        
        NSInteger lowClear = [tableViewList selectedRow];
        
        if (lowClear != -1) [tableViewList deselectRow:lowClear];
        
        [tableViewList reloadData];
    }
    
    //-----Table View Image display and prevent multiple round processing-----
    if (tableCallCount == 1){
        tableCallCount = 0;
        tableCurrentRowHold = tableNewRowHold;
        
        if ((listSwitchCall == 1 || listSwitchCall == 2) && trackingOn == 2){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    //-----Table View for search-----
    if (tableCallSearchCount == 1){
        tableCallSearchCount = 0;
        tableCurrentRowHoldSearch = tableNewRowHoldSearch;
    }
    
    if (tableCallSearchCount > 1) tableCallSearchCount = 0;
    
    //-----Table View for Operations-----
    if (tableCallOperationCount == 1){
        tableCallOperationCount = 0;
        tableCurrentRowHoldOperation = tableNewRowHoldOperation;
    }
    
    if (tableCallOperationCount > 1) tableCallOperationCount = 0;
    
    //-----Display Window call-----
    if (displayWindowCall == 1){
        displayWindowCall = 2;
        verificationPositionCall = 0;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
    }
    if (displayWindowCall == 3) displayWindowCall = 0;
    
    //-----Cut line display call-----
    if (lineSetWindowCallTrack == 2) lineSetWindowCallTrack = 0;
    if (lineSetWindowCallDisplay == 2) lineSetWindowCallDisplay = 0;
    
    //-----Cut line display call-----
    if (listSwitchCallStatus == 1){
        listSwitchCallStatus = 0;
        
        NSInteger lowClear = [tableViewList selectedRow];
        
        if (lowClear != -1) [tableViewList deselectRow:lowClear];
        
        [tableViewList reloadData];
    }
    
    //-----Time one end/exit processing-----
    if (timeOneStatus == 4 || timeOneStatus == 5){
        if (timeOneStatus == 4) timeOneStatus = 40;
        if (timeOneStatus == 5) timeOneStatus = 50;
        
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
            delete [] sourceImage [counter1];
            delete [] revisedMap [counter1];
            delete [] revisedWorkingMap [counter1];
            delete [] connectMap200 [counter1];
            delete [] connectMap220 [counter1];
            delete [] connectMap240 [counter1];
            delete [] connectMapA [counter1];
            delete [] connectMapB [counter1];
            delete [] connectMapC [counter1];
            delete [] connectMapD [counter1];
        }
        
        delete [] sourceImage;
        delete [] revisedMap;
        delete [] revisedWorkingMap;
        delete [] connectMap200;
        delete [] connectMap220;
        delete [] connectMap240;
        delete [] connectMapA;
        delete [] connectMapB;
        delete [] connectMapC;
        delete [] connectMapD;
        
        delete [] arrayTarget;
        targetStatus = 0;
        
        delete [] arrayPositionRevise;
        delete [] arrayGravityCenterRev;
        delete [] arrayTimeSelected;
        delete [] arrayTimeSelectedHold;
        delete [] arrayTargetHold;
        delete [] arrayTargetHoldInfo;
        delete [] arrayAssociateData;
        delete [] arrayReferenceLine;
        
        if (attachedNumberListStatus == 1) delete [] attachedNumberList;
        if (groupNumberListStatus == 1) delete [] groupNumberList;
        
        if (fluorescentMapStatus1 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap1 [counter1];
            
            delete [] fluorescentMap1;
            fluorescentMapStatus1 = 0;
        }
        
        if (fluorescentMapStatus2 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap2 [counter1];
            
            delete [] fluorescentMap2;
            fluorescentMapStatus2 = 0;
        }
        
        if (fluorescentMapStatus3 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap3 [counter1];
            
            delete [] fluorescentMap3;
            fluorescentMapStatus3 = 0;
        }
        
        if (fluorescentMapStatus4 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap4 [counter1];
            
            delete [] fluorescentMap4;
            fluorescentMapStatus4 = 0;
        }
        
        if (fluorescentMapStatus5 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap5 [counter1];
            
            delete [] fluorescentMap5;
            fluorescentMapStatus5 = 0;
        }
        
        if (fluorescentMapStatus6 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap6 [counter1];
            
            delete [] fluorescentMap6;
            fluorescentMapStatus6 = 0;
        }
        
        if (expandFluorescentOutlineStatus == 1){
            delete [] expandFluorescentOutline;
            expandFluorescentOutlineStatus = 0;
        }
        
        if (expandFluorescentDataStatus == 1){
            delete [] expandFluorescentData;
            expandFluorescentDataStatus = 0;
        }
        
        targetCount = 0;
        positionReviseCount = 0;
        gravityCenterRevCount = 0;
        timeSelectedCount = 0;
        timeSelectedHoldCount = 0;
        targetHoldCount = 0;
        targetHoldInfoCount = 0;
        associateDataStatus = 0;
        attachedNumberListStatus = 0;
        groupNumberListStatus = 0;
        fluorescentDisplayNo = 0;
        
        if (timeOneStatus == 40){
            [listName setStringValue:@"Check List"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        if (timeOneStatus == 50){
            [listName setStringValue:@"Check List"];
            [statusDisplay setStringValue:@"Tracking"];
        }
        
        timeOneStatus = 0;
        setStatus2 = 2;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
    }
    else if (trackingOn == 6 || trackingOn == 7){ //-----Tracking end/exit processing-----
        if (trackingOn == 6) trackingOn = 60;
        if (trackingOn == 7) trackingOn = 70;
        
        for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
            delete [] sourceImage [counter1];
            delete [] revisedMap [counter1];
            delete [] revisedWorkingMap [counter1];
        }
        
        delete [] sourceImage;
        delete [] revisedMap;
        delete [] revisedWorkingMap;
        
        delete [] arrayTarget;
        targetStatus = 0;
        
        delete [] arrayPositionRevise;
        delete [] arrayGravityCenterRev;
        delete [] arrayTimeSelected;
        delete [] arrayTimeSelectedHold;
        delete [] arrayTargetHold;
        delete [] arrayTargetHoldInfo;
        delete [] arrayConnectLineageRel;
        delete [] arrayLineageGRCurrent;
        delete [] arrayReferenceLine;
        delete [] arrayEventSequence;
        delete [] arrayEventSequenceHold;
        delete [] arrayLineageGravityCenterCurrentHold;
        delete [] arrayAssociateData;
        
        if (fluorescentMapStatus1 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap1 [counter1];
            
            delete [] fluorescentMap1;
            fluorescentMapStatus1 = 0;
        }
        
        if (fluorescentMapStatus2 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap2 [counter1];
            
            delete [] fluorescentMap2;
            fluorescentMapStatus2 = 0;
        }
        
        if (fluorescentMapStatus3 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap3 [counter1];
            
            delete [] fluorescentMap3;
            fluorescentMapStatus3 = 0;
        }
        
        if (fluorescentMapStatus4 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap4 [counter1];
            
            delete [] fluorescentMap4;
            fluorescentMapStatus4 = 0;
        }
        
        if (fluorescentMapStatus5 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap5 [counter1];
            
            delete [] fluorescentMap5;
            fluorescentMapStatus5 = 0;
        }
        
        if (fluorescentMapStatus6 == 1){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap6 [counter1];
            
            delete [] fluorescentMap6;
            fluorescentMapStatus6 = 0;
        }
        
        if (expandFluorescentOutlineStatus == 1){
            delete [] expandFluorescentOutline;
            expandFluorescentOutlineStatus = 0;
        }
        
        if (expandFluorescentDataStatus == 1){
            delete [] expandFluorescentData;
            expandFluorescentDataStatus = 0;
        }
        
        sourceImageStatus = 0;
        revisedMapStatus = 0;
        revisedWorkingMapStatus = 0;
        targetCount = 0;
        positionReviseCount = 0;
        gravityCenterRevCount = 0;
        timeSelectedCount = 0;
        timeSelectedHoldCount = 0;
        targetHoldCount = 0;
        targetHoldInfoCount = 0;
        connectLineageRelCount = 0;
        lineageGRCurrentCount = 0;
        referenceLineCount = 0;
        positionReviseStatus = 0;
        gravityCenterRevStatus = 0;
        timeSelectedStatus = 0;
        timeSelectedHoldStatus = 0;
        targetHoldStatus = 0;
        connectLineageRelStatus = 0;
        eventSequenceCount = 0;
        eventSequenceHoldCount = 0;
        lineageGravityCenterCurrentHoldCount = 0;
        associateDataStatus = 0;
        lineDraw = 0;
        trackingImageLock = 0;
        
        if (trackingOn == 60){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        trackingOn = 1;
        
        if (setStatus7 == 0){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
    }
    
    //-----Hold till images are loaded-----
    if (imageLoadMonitor == 4) imageLoadMonitor = 5;
    
    //-----Call when cell lineage List is not found-----
    if (cellLineageInfoListCreationCall == 2){
        cellLineageInfoListCreationCall = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Time One"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        [contentInLineage setStringValue:@"nil"];
        [lineageStatus setStringValue:@"nil"];
        [lineageCurrentNumber setStringValue:@"nil"];
    }
    
    //-----Call when cell lineage is selected-----
    if (cellLineageInfoListCreationCall >= 5){
        if (cellLineageInfoListCreationCall == 5) cellLineageInfoListCreationCall = 50;
        
        int cellContentCount = 0;
        int lineageStatusTemp = 0;
        
        string lineageNumberExtract = "";
        
        if (cellLineageNoHold != ""){
            lineageNumberExtract = cellLineageNoHold.substr(1);
            
            for (int counter1 = 0; counter1 < cellLineageInfoCount/3; counter1++){
                if (arrayCellLineageInfo [counter1*3] == atoi (lineageNumberExtract.c_str())){
                    lineageStatusTemp = arrayCellLineageInfo [counter1*3+1];
                    cellContentCount = arrayCellLineageInfo [counter1*3+2];
                    break;
                }
            }
        }
        
        if (cellLineageInfoListCreationCall == 50){
            [lineageCurrentNumber setIntegerValue:atoi(lineageNumberExtract.c_str())];
            [contentInLineage setIntegerValue:cellContentCount];
            
            if (lineageStatusTemp == 0) [lineageStatus setStringValue:@"Open"];
            else if (lineageStatusTemp == 1) [lineageStatus setStringValue:@"Comp"];
            else if (lineageStatusTemp == 2) [lineageStatus setStringValue:@"OpenGb"];
            else if (lineageStatusTemp == 3) [lineageStatus setStringValue:@"CompGb"];
        }
        else{
            
            [lineageCurrentNumber setStringValue:@"nil"];
            [lineageStatus setStringValue:@"nil"];
            [contentInLineage setStringValue:@"nil"];
        }
        
        cellLineageInfoListCreationCall = 0;
    }
    
    if (cellNumberInfoListCreationCall >= 5){
        if (cellNumberInfoListCreationCall == 5) cellNumberInfoListCreationCall = 50;
        
        NSString *startStatusTemp = @"";
        NSString *endStatusTemp = @"";
        
        int startTimeTemp = 0;
        int endTimeTemp = 0;
        int startStatusInt = 0;
        int endStatusInt = 0;
        
        string cellNumberExtract = "";
        
        if (cellNoHold != ""){
            cellNumberExtract = cellNoHold.substr(1);
            
            for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                if (arrayCellNumberInfo [counter1*7] == atoi (cellNumberExtract.c_str())){
                    startTimeTemp = arrayCellNumberInfo [counter1*7+1];
                    endTimeTemp = arrayCellNumberInfo [counter1*7+2];
                    startStatusInt = arrayCellNumberInfo [counter1*7+3];
                    endStatusInt = arrayCellNumberInfo [counter1*7+4];
                    break;
                }
            }
        }
        
        if (cellNumberInfoListCreationCall == 50){
            [cellCurrentNumber setIntegerValue:atoi(cellNumberExtract.c_str())];
            [cellCurrentStTime setIntegerValue:startTimeTemp];
            
            if (endTimeTemp == -1) [cellCurrentEndTime setStringValue:@"OP"];
            else [cellCurrentEndTime setIntegerValue:endTimeTemp];
            
            if (startStatusInt == 1) startStatusTemp = @"IN";
            else if (startStatusInt == 3) startStatusTemp = @"BD";
            else if (startStatusInt == 4) startStatusTemp = @"TD";
            else if (startStatusInt == 5) startStatusTemp = @"HD";
            else if (startStatusInt == 7) startStatusTemp = @"FU";
            
            if (endStatusInt == 0) endStatusTemp = @"OP";
            else if (endStatusInt == 3) endStatusTemp = @"BD";
            else if (endStatusInt == 4) endStatusTemp = @"TD";
            else if (endStatusInt == 5) endStatusTemp = @"HD";
            else if (endStatusInt == 6) endStatusTemp = @"CD";
            else if (endStatusInt == 7) endStatusTemp = @"FU";
            else if (endStatusInt == 9) endStatusTemp = @"OF";
            else if (endStatusInt == 10) endStatusTemp = @"EF";
            
            [cellCurrentStStatus setStringValue:startStatusTemp];
            [cellCurrentEndStatus setStringValue:endStatusTemp];
        }
        else{
            
            [cellCurrentNumber setStringValue:@"nil"];
            [cellCurrentStTime setStringValue:@"nil"];
            [cellCurrentEndTime setStringValue:@"nil"];
            [cellCurrentStStatus setStringValue:@"nil"];
            [cellCurrentEndStatus setStringValue:@"nil"];
        }
        
        cellNumberInfoListCreationCall = 0;
    }
    
    //-----Table Set when Tracking is clicked-----
    if (trackingTableSetDone == 1){
        trackingTableSetDone = 2;
        
        NSInteger lowClear = [tableViewList selectedRow];
        
        if (lowClear != -1) [tableViewList deselectRow:lowClear];
        
        [tableViewList reloadData];
    }
    
    if (trackingOnInfoDisplay == 1 || trackingOnInfoDisplay == 2){
        if (trackingOnInfoDisplay == 1){
            trackingOnInfoDisplay = 0;
            [lowerLimitTrack setIntegerValue: trackingLowerLimit];
            [upperLimitTrack setIntegerValue: trackingUpperLimit];
        }
        else if (trackingOnInfoDisplay == 2){
            trackingOnInfoDisplay = 0;
            [lowerLimitTrack setStringValue: @"nil"];
            [upperLimitTrack setStringValue: @"nil"];
        }
    }
    
    //-----Add Del Insert Display control-----
    if (addDelInsert > 1) addDelInsert = 0;
    
    //-----Clear brash control-----
    if (clearBack > 1) clearBack = 0;
    
    if (trackJump > 1) trackJump = 0;
    
    if (displayJump > 1) displayJump = 0;
    
    if (imageReadTiming > 1 && imageReadTimingNavigation > 1){
        treatmentNameKeep = treatmentNameHold;
        imageReadTiming = 0;
        imageReadTimingNavigation = 0;
        listLingNoHold = "";
        listCellNoHold = "";
    }
    
    if (sliderBarSet > 1) sliderBarSet = 0;
    
    if (cellJumpFirstLast > 7) cellJumpFirstLast = 0;
    
    if (quickLineageCall > 2) quickLineageCall = 0;
    
    if (quickConnectCall > 2) quickConnectCall = 0;
    
    if (timeOneLaunch > 1) timeOneLaunch = 0;
    
    //-----Call Tracking Display from List-----
    if (listToTrackCall == 1){
        listToTrackCall = 2;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
    }
    
    if (listToTrackCall > 2) listToTrackCall = 0;
    
    //-----Area line message display control-----
    if (lineAreaCall > 1) lineAreaCall = 0;
    
    if (fluorescentValueDisplayControl == 1){
        fluorescentValueDisplayControl = 0;
        
        if (fluorescentDisplayNo == 1){
            [fluorescentValue setIntegerValue: fluorescentCutOff1];
            
            double knobSet = fluorescentCutOff1;
            [sliderFluorescentKnob setDoubleValue:knobSet];
        }
        else if (fluorescentDisplayNo == 2){
            [fluorescentValue setIntegerValue: fluorescentCutOff2];
            
            double knobSet = fluorescentCutOff2;
            [sliderFluorescentKnob setDoubleValue:knobSet];
        }
        else if (fluorescentDisplayNo == 3){
            [fluorescentValue setIntegerValue: fluorescentCutOff3];
            
            double knobSet = fluorescentCutOff3;
            [sliderFluorescentKnob setDoubleValue:knobSet];
        }
        else if (fluorescentDisplayNo == 4){
            [fluorescentValue setIntegerValue: fluorescentCutOff4];
            
            double knobSet = fluorescentCutOff4;
            [sliderFluorescentKnob setDoubleValue:knobSet];
        }
        else if (fluorescentDisplayNo == 5){
            [fluorescentValue setIntegerValue: fluorescentCutOff5];
            
            double knobSet = fluorescentCutOff5;
            [sliderFluorescentKnob setDoubleValue:knobSet];
        }
        else if (fluorescentDisplayNo == 6){
            [fluorescentValue setIntegerValue: fluorescentCutOff6];
            
            double knobSet = fluorescentCutOff6;
            [sliderFluorescentKnob setDoubleValue:knobSet];
        }
    }
    
    if (listTableCall == 1){
        listTableCall = 0;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageListTable object:self];
    }
    
    if (runStatusCellCurving == 1){
        runStatusCellCurving = 2;
        connectionSend1 = 1;
    }
    else if (cellCurvingRunningFlag == 1){
        cellCurvingRunningFlag = 0;
        [queueHoldingDisplay setTextColor:[NSColor redColor]];
        [queueHoldingDisplay setStringValue:@"Processing"];
    }
    else if (cellCurvingRunningFlag == 2){
        runStatusCellCurving = 0;
        cellCurvingRunningFlag = 0;
        
        [queueHoldingDisplay setTextColor:[NSColor blackColor]];
        [queueHoldingDisplay setStringValue:@"Holding"];
        
        ifstream fin;
        
        fin.open(instructionCCPath.c_str(), ios::in);
        
        if (fin.is_open()){
            fin.close();
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6+5] == "Proc"){
                    arrayQueueList [counter1*6+5] = "Wait";
                    break;
                }
            }
            
            if (searchWindowOperation != 0){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
            }
        }
        
        queueHoldingStatus = 0;
    }
    
    if (errorInfoFlag != "0"){
        if ((int)errorInfoFlag.find("/m") != -1) errorInfoFlag = errorInfoFlag.substr(0, 2);
        
        if (errorInfoFlag == "nil" || errorInfoFlag == "OK") errorInfoFlag = "nil";
        else{
            
            if (errorInfoFlag == "TD") errorInfoFlag = "Tripolar cell division: Check accuracy";
            else if (errorInfoFlag == "HD") errorInfoFlag = "Tetrapolar cell division: Check accuracy";
            else if (errorInfoFlag == "MD") errorInfoFlag = "Multipolar cell division: Check accuracy";
            else if (errorInfoFlag == "NS") errorInfoFlag = "No empty time point before cell division: Need one time point between mitosis and cell division";
            else if (errorInfoFlag == "IP") errorInfoFlag = "Impartial mitosis: Check accuracy";
            else if (errorInfoFlag == "MC") errorInfoFlag = "Mitosis setting was cleared: Check status";
            else if (errorInfoFlag == "AC") errorInfoFlag = "Mitosis/cell death status: Need to check";
            else if (errorInfoFlag == "DB") errorInfoFlag = "Cell debris: Check image and set Garbage";
            else if (errorInfoFlag == "RC") errorInfoFlag = "Cell death setting was cleared: Check status";
            else if (errorInfoFlag == "SC") errorInfoFlag = "Check cell death status";
            else if (errorInfoFlag == "CM") errorInfoFlag = "Check division: One or more divided cells show low intensity";
            else if (errorInfoFlag == "CN") errorInfoFlag = "Check division: No mitosis found";
            else if (errorInfoFlag == "FM") errorInfoFlag = "Check fusion: Multiple cell fusions";
            else if (errorInfoFlag == "TL") errorInfoFlag = "Target area lost: Check image";
            else if (errorInfoFlag == "FE") errorInfoFlag = "Fusion area lost: Check image";
            else if (errorInfoFlag == "FO") errorInfoFlag = "Fusion position is occupied by other event";
            else if (errorInfoFlag == "MF") errorInfoFlag = "Mitosis set fail: Check image";
            else if (errorInfoFlag == "NM") errorInfoFlag = "Mitosis set fail: Check image, No next outline data";
            else if (errorInfoFlag == "DL") errorInfoFlag = "Cell division: Lost area, Check image";
            else if (errorInfoFlag == "OF") errorInfoFlag = "Out of frame, Check accuracy";
            else if (errorInfoFlag == "FC") errorInfoFlag = "Cell fusion (End Fusion): Check accuracy";
            else if (errorInfoFlag == "FP") errorInfoFlag = "Cell fusion (Non-End Fusion): Check area";
            else if (errorInfoFlag == "ME") errorInfoFlag = "Multiple cell fusion ends found: Check image";
            else if (errorInfoFlag == "CF") errorInfoFlag = "No overlapped segment found";
            else if (errorInfoFlag == "XS") errorInfoFlag = "Data save error";
            else if (errorInfoFlag == "AM") errorInfoFlag = "Outline data missing: Do cleaning";
            else if (errorInfoFlag == "CL") errorInfoFlag = "No overlapped segment found (First round fail)";
            else errorInfoFlag = "nil";
        }
        
        [errorExplanationDisplay setStringValue:@(errorInfoFlag.c_str())];
        
        errorInfoFlag = "0";
    }
    
    if (quickLineageCall == 1){
        quickLineageCall = 2;
        [self lineageQuickSet];
    }
    
    if (cellJumpFirstLast == 1){
        cellJumpFirstLast = 4;
        [self cellJumpTopLast];
    }
    
    if (cellJumpFirstLast == 2){
        cellJumpFirstLast = 5;
        [self cellJumpTopLast];
    }
    
    if (cellJumpFirstLast == 3){
        cellJumpFirstLast = 6;
        [self cellJumpTopLast];
    }
    
    if (quickConnectCall == 1){
        quickConnectCall = 2;
        [self connectQuickSet];
    }
    
    if (optionCall == 1){
        optionCall = 0;
        
        if (optionWindowOperation == 1){
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToOptionOperations object:self];
        }
    }
    
    if (optionDisplayCall == 1){
        optionDisplayCall = 0;
        [optionCheck setTextColor:[NSColor redColor]];
        [optionCheck setStringValue:@"CK: Track Options"];
    }
    
    if (listHoldProcessFlag > -1){
        int lineNumberTemp = listHoldProcessFlag;
        listHoldProcessFlag = -1;
        
        [self listProcessQueueDone:lineNumberTemp];
    }
    
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue) progressTiming = 2;
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue) progressTiming = 4;
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == 0){
            [progressIndicator stopAnimation:self];
            
            if (!progressIndicator) progressTiming = 0;
        }
    }
    
    if (progressTiming == 6){
        [backSave startAnimation:self];
        
        if (backSave) progressTiming = 7;
    }
    else if (progressTiming == 8){
        [backSave stopAnimation:self];
        
        if (backSave) progressTiming = 0;
    }
    
    if (progressTimingB == 1){
        [queueCheck startAnimation:self];
        
        if (queueCheck) progressTimingB = 2;
    }
    else if (progressTimingB == 3){
        [queueCheck stopAnimation:self];
        
        if (!queueCheck) progressTimingB = 0;
    }
    
    if (progressTimingC == 1){
        [doneCheck startAnimation:self];
        
        if (doneCheck) progressTimingC = 2;
    }
    else if (progressTimingC == 3){
        [doneCheck stopAnimation:self];
        
        if (!doneCheck) progressTimingC = 0;
    }
    
    if (cleaningManualProgress == 1 && firstTrackStart == 1){
        firstTrackStart = 2;
        cleaningManualProgress = 2;
        folderCopy = [[FolderCopy alloc] init];
        [folderCopy folderDeleteMain];
    }
    else if (cleaningManualProgress == 2 && firstTrackStart == 3){
        firstTrackStart = 0;
        cleaningManualProgress = 3;
    }
    else if (cleaningManualProgress == 3 && firstTrackStart == 0){
        cleaningManualProgress = 4;
        errorNoHold = 0;
        folderCopy = [[FolderCopy alloc] init];
        [folderCopy folderCopyMain];
        
        if (errorNoHold != 0){
            cleaningManualProgress = 1;
            firstTrackStart = 1;
            errorNoHold = 0;
        }
    }
    else if (cleaningManualProgress == 5 && firstTrackStart == 0){
        cleaningManualProgress = 6;
        
        errorNoHold = 0;
        cleaning = [[Cleaning alloc] init];
        [cleaning cleaningMain];
        
        if (errorNoHold != 0){
            cleaningManualProgress = 20;
            errorNoHold = 0;
        }
    }
    else if (cleaningManualProgress == 20 && firstTrackStart == 0){
        cleaningManualProgress = 21;
        restoreDataFlag = 2;
        folderCopy = [[FolderCopy alloc] init];
        [folderCopy folderDeleteMain];
    }
    else if (firstTrackStart == 0 && restoreDataFlag == 3){
        restoreDataFlag = 4;
        errorNoHold = 0;
        folderCopy = [[FolderCopy alloc] init];
        [folderCopy folderCopyMain];
        
        if (errorNoHold != 0){
            restoreDataFlag = 0;
            cleaningManualProgress = 20;
            errorNoHold = 0;
        }
    }
    else if (cleaningManualProgress == 21 && restoreDataFlag == 5){
        restoreDataFlag = 0;
        cleaningManualProgress = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Cleaning Unsuccessful"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (cleaningManualProgress == 7 && firstTrackStart == 0) cleaningManualProgress = 0;
    
    if ((queueRestartFlag == 1 || queueRestartFlag == 2) && queueHoldingStatus == 0){
        if (queueRestartFlag == 1) queueRestartFlag = 3;
        if (queueRestartFlag == 2) queueRestartFlag = 4;
        
        if (queueRestartFlag == 3 && multipleLaunchBlock <= 2){
            queueRestartFlag = 0;
            multipleLaunchBlock++;
            
            [self queueHoldControlMain];
        }
        else if (queueRestartFlag == 3 && multipleLaunchBlock > 2) queueRestartFlag = 0;
        
        if (queueRestartFlag == 4) queueRestartFlag = 5;
    }
    else if (queueRestartFlag == 5 && queueHoldingStatus == 0){
        queueRestartFlag = 6;
        [queueHoldingDisplay setTextColor:[NSColor redColor]];
        [queueHoldingDisplay setStringValue:@"Backup"];
    }
    else if (queueRestartFlag == 6 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && firstTrackStart == 1){
        firstTrackStart = 2;
        
        for (int counter1 = 0; counter1 < timeEndHold+1; counter1++) arrayTimePointSaveList [counter1] = 1;
        
        if (firstCleaningFlag == 1){
            folderCopy = [[FolderCopy alloc] init];
            [folderCopy folderDeleteMain];
        }
        else firstTrackStart = 3;
    }
    else if (queueRestartFlag == 6 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && firstTrackStart == 3){
        firstTrackStart = 0;
        reviseTimingCount = 600;
        upDateCompleteFlag = 1;
    }
    else if (queueRestartFlag == 6 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && firstTrackStart == 0 && upDateCompleteFlag == 0){
        queueRestartFlag = 7;
        errorNoHold = 0;
        
        if (firstCleaningFlag == 1){
            folderCopy = [[FolderCopy alloc] init];
            [folderCopy folderCopyMain];
        }
        else queueRestartFlag = 8;
        
        if (errorNoHold != 0){
            queueRestartFlag = 6;
            firstTrackStart = 1;
            errorNoHold = 0;
        }
        else if (firstCleaningFlag == 1) firstCleaningFlag = 0;
    }
    else if (queueRestartFlag == 8 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && firstTrackStart == 0){
        queueRestartFlag = 9;
        [queueHoldingDisplay setStringValue:@"Cleaning"];
    }
    else if (queueRestartFlag == 9 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && firstTrackStart == 0){
        queueRestartFlag = 10;
        errorNoHold = 0;
        cleaning = [[Cleaning alloc] init];
        [cleaning cleaningMain];
        
        if (errorNoHold != 0){
            queueRestartFlag = 20;
            errorNoHold = 0;
        }
    }
    else if (queueRestartFlag == 20 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0 && firstTrackStart == 0){
        queueRestartFlag = 21;
        restoreDataFlag = 2;
        
        if (firstCleaningFlag == 1){
            folderCopy = [[FolderCopy alloc] init];
            [folderCopy folderDeleteMain];
        }
        else restoreDataFlag = 3;
    }
    else if (queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0 && firstTrackStart == 0 && restoreDataFlag == 3){
        restoreDataFlag = 4;
        errorNoHold = 0;
        
        if (firstCleaningFlag == 1){
            folderCopy = [[FolderCopy alloc] init];
            [folderCopy folderCopyMain];
        }
        else restoreDataFlag = 5;
        
        if (errorNoHold != 0){
            restoreDataFlag = 0;
            queueRestartFlag = 20;
            errorNoHold = 0;
            firstCleaningFlag = 0;
        }
        else if (firstCleaningFlag == 1) firstCleaningFlag = 0;
    }
    else if (queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0 && firstTrackStart == 0 && restoreDataFlag == 5){
        restoreDataFlag = 0;
        queueRestartFlag = 9;
    }
    else if (queueRestartFlag == 11 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0 && firstTrackStart == 0){
        queueRestartFlag = 0;
        [self queueHoldControlMain];
    }
    else if (queueRestartFlag == 12 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0 && firstTrackStart == 0){
        [queueHoldingDisplay setTextColor:[NSColor blackColor]];
        [queueHoldingDisplay setStringValue:@"Holding"];
        queueRestartFlag = 0;
    }
    
    if (restoreDataFlag == 1){
        restoreDataFlag = 2;
        folderCopy = [[FolderCopy alloc] init];
        [folderCopy folderDeleteMain];
    }
    else if (restoreDataFlag == 3){
        restoreDataFlag = 4;
        errorNoHold = 0;
        folderCopy = [[FolderCopy alloc] init];
        [folderCopy folderCopyMain];
        
        if (errorNoHold != 0){
            restoreDataFlag = 1;
            errorNoHold = 0;
        }
    }
    else if (restoreDataFlag == 5){
        restoreDataFlag = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Quit and Restart Cell Tracking"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    if (seqImageClick != 0 && seqImageClick != 100){
        if (seqImageClick == 1 && seqImageNoSet1 <= seqImageLast){
            imageNumber = seqImageNoSet1;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 2 && seqImageNoSet2 <= seqImageLast){
            imageNumber = seqImageNoSet2;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 3 && seqImageNoSet3 <= seqImageLast){
            imageNumber = seqImageNoSet3;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 4 && seqImageNoSet4 <= seqImageLast){
            imageNumber = seqImageNoSet4;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 5 && seqImageNoSet5 <= seqImageLast){
            imageNumber = seqImageNoSet5;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 6 && seqImageNoSet6 <= seqImageLast){
            imageNumber = seqImageNoSet6;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 7 && seqImageNoSet7 <= seqImageLast){
            imageNumber = seqImageNoSet7;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 8 && seqImageNoSet8 <= seqImageLast){
            imageNumber = seqImageNoSet8;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 9 && seqImageNoSet9 <= seqImageLast){
            imageNumber = seqImageNoSet9;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else if (seqImageClick == 10 && seqImageNoSet10 <= seqImageLast){
            imageNumber = seqImageNoSet10;
            imageReturnPositionSet = 1;
            listCrickMonitor = 1;
            seqImageClick = 100;
        }
        else seqImageClick = 0;
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == trackingIntervalDisplay){
            if ([trackingIntervalDisplay intValue] >= 10 && [trackingIntervalDisplay intValue] <= 50){
                [stepperInterval setIntValue:[trackingIntervalDisplay intValue]];
                trackingCheckInterval = [stepperInterval intValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveTrackingCurrent];
            }
            else [trackingIntervalDisplay setIntegerValue:trackingCheckInterval];
        }
        
        if ([aNotification object] == limitIntervalDisplay){
            if ([limitIntervalDisplay intValue] >= 0 && [limitIntervalDisplay intValue] <= 10000){
                [stepperLimitInterval setIntValue:[limitIntervalDisplay intValue]];
                autoTrackingLimitHold = [stepperLimitInterval intValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
            else [limitIntervalDisplay setIntegerValue:autoTrackingLimitHold];
        }
        
        if ([aNotification object] == fluorescentQuantTimeDisplay){
            if (fluorescentDivisionStatus == 0 && [fluorescentQuantTimeDisplay intValue] >= timeOneHold && [fluorescentQuantTimeDisplay intValue] <= imageEndHold){
                fluorescentDivisionTime = [fluorescentQuantTimeDisplay intValue];
                [fluorescentQuantTimeDisplay setIntegerValue:fluorescentDivisionTime];
                
                string fluorescentCountStatusPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FluoQuant";
                
                ofstream oin;
                oin.open(fluorescentCountStatusPath.c_str(), ios::out);
                oin<<fluorescentDivisionNo<<endl;
                oin<<fluorescentDivisionTime<<endl;
                oin<<fluorescentDivisionCh<<endl;
                oin<<fluorescentDivisionStatus<<endl;
                oin.close();
            }
        }
        
        if ([aNotification object] == fluorescentQuantChDisplay){
            if (fluorescentDivisionStatus == 0 && [fluorescentQuantChDisplay intValue] >= 1 && [fluorescentQuantChDisplay intValue] <= 12){
                fluorescentDivisionCh = [fluorescentQuantChDisplay intValue];
                [fluorescentQuantChDisplay setIntegerValue:fluorescentDivisionCh];
                
                string fluorescentCountStatusPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FluoQuant";
                
                ofstream oin;
                oin.open(fluorescentCountStatusPath.c_str(), ios::out);
                oin<<fluorescentDivisionNo<<endl;
                oin<<fluorescentDivisionTime<<endl;
                oin<<fluorescentDivisionCh<<endl;
                oin<<fluorescentDivisionStatus<<endl;
                oin.close();
            }
            else [fluorescentQuantChDisplay setIntegerValue:fluorescentDivisionCh];
        }
    }
}

-(IBAction)stepperActionInterval:(id)sender{
    [trackingIntervalDisplay setIntValue: [stepperInterval intValue]];
    trackingCheckInterval = [stepperInterval intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveTrackingCurrent];
}

-(IBAction)stepperLimitInterval:(id)sender{
    [limitIntervalDisplay setIntValue: [stepperLimitInterval intValue]];
    autoTrackingLimitHold = [stepperLimitInterval intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(BOOL)validateToolbarItem:(NSToolbarItem *)theItem2 {
    BOOL returnResult;
    
    if (imageLoadMonitor > 0 && imageLoadMonitor < 5 && [theItem2 tag] == -4) returnResult = NO;
    else{
        
        imageLoadMonitor = 0;
        returnResult = YES;
    }
    
    if (timeOneStatus > 0){
        if ([theItem2 tag] == -3 || [theItem2 tag] == -18) returnResult = NO;
        else returnResult = YES;
    }
    if (queueHoldingStatus == 1){
        if ([theItem2 tag] == -18 || [theItem2 tag] == -1 || [theItem2 tag] == -2 || [theItem2 tag] == -4) returnResult = NO;
        else returnResult = YES;
    }
    if (trackingOn == 3){
        if ([theItem2 tag] == -4 || [theItem2 tag] == -18 || [theItem2 tag] == -19) returnResult = NO;
        else returnResult = YES;
    }
    if (trackingOn > 0){
        if ([theItem2 tag] == -1 || [theItem2 tag] == -2) returnResult = NO;
        else returnResult = YES;
    }
    
    return returnResult;
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    getListCount = 0;
    int entryNumber = 0;
    
    if (analysisImageName != "" && trackingImageLock == 0){
        if (column == 0){
            entryNumber = treatmentStatusCount/9;
            
            if (trackingOn == 1) [statusDisplay setStringValue:@"Tracking"];
        }
        
        if (column == 1){
            NSString *path;
            path = [sender path];
            
            string columnOneEntryHold = [path UTF8String];
            string columnOneEntryHoldExtract = columnOneEntryHold.substr(1);
            
            if ((int)columnOneEntryHoldExtract.find("/") != -1) columnOneEntryHoldExtract = columnOneEntryHoldExtract.substr(0, columnOneEntryHoldExtract.find("/"));
            if ((int)columnOneEntryHoldExtract.find("/") != -1) columnOneEntryHoldExtract = columnOneEntryHoldExtract.substr(0, columnOneEntryHoldExtract.find("/"));
            
            int treatNameMatch = 0;
            
            if (treatmentNameHold != columnOneEntryHoldExtract) treatNameMatch = 1;
            
            if ((setStatus3 == 0 && setStatus7 == 0 && timeOneStatus == 0) || ((setStatus3 != 0 || setStatus7 != 0) && treatmentNameHold == columnOneEntryHoldExtract) || treatNameMatch == 1){
                if (trackingOn == 1) [statusDisplay setStringValue:@"Tracking"];
                
                string numberExtract = columnOneEntryHold.substr(1);
                
                if (setStatus7 == 7) numberExtract = treatmentNameHold;
                else if ((int)numberExtract.find("/") != -1){
                    numberExtract = numberExtract.substr(0, numberExtract.find("/"));
                    treatmentNameHold = numberExtract;
                }
                
                int entryCheck = 0;
                
                for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                    if (numberExtract == arrayTreatmentStatus [counter1*9] && arrayTreatmentStatus [counter1*9+1] == "1" && arrayTreatmentStatus [counter1*9+2] == "1"){
                        entryCheck = 1;
                        dataEntryStatus = 1;
                    }
                    else dataEntryStatus = 0;
                }
                
                //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
                //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
                //}
                
                if (entryCheck == 1){
                    int entryCheck2 = 0;
                    int errorCheck = 0;
                    
                    if (treatmentNameHold == "" || treatNameMatch == 1 || setStatus2 == 3){
                        setStatus2 = 0;
                        ifstream fin;
                        
                        struct stat sizeOfFile;
                        long sizeForCopy = 0;
                        
                        saveInfo = numberExtract;
                        
                        dataSaveRead = [[DataSaveRead alloc] init];
                        errorCheck = [dataSaveRead lineageDataRead];
                        
                        string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+numberExtract+"_Connect/"+ analysisID+"_"+numberExtract+"_LineageStatus";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (entryCheck2 != 0) entryCheck2 = 1;
                            
                            if (cellLineageInfoStatus == 0){
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                                cellLineageInfoStatus = 1;
                            }
                            else if (sizeForCopy*2 > cellLineageInfoCount){
                                delete [] arrayCellLineageInfo;
                                arrayCellLineageInfo = new int [sizeForCopy*2+50];
                                cellLineageInfoLimit = (int)sizeForCopy*2+50;
                            }
                            
                            cellLineageInfoCount = 0;
                            
                            fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                char *uploadTemp = new char [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                string dataString = "";
                                int readPosition = 0;
                                
                                do{
                                    
                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                    else if (dataString != "End"){
                                        arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++;
                                        dataString = "";
                                    }
                                    
                                    readPosition++;
                                    
                                } while (dataString != "End");
                                
                                delete [] uploadTemp;
                            }
                        }
                        
                        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+numberExtract+"_Connect/"+ analysisID+"_"+numberExtract+"_LineageStartEnd";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (lineageStartEndStatus == 0){
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                            lineageStartEndStatus = 1;
                        }
                        else if (sizeForCopy > lineageStartEndCount){
                            delete [] arrayLineageStartEnd;
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                        }
                        
                        lineageStartEndCount = 0;
                        
                        fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                        //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
                        //}
                        
                        listCrickMonitor = 1;
                    }
                    else entryCheck2 = 1;
                    
                    if (columnOneEntryHold != "" && entryCheck2 == 1 && errorCheck == 0){
                        //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                        //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                        //}
                        
                        string extension = "";
                        
                        for (int counter1 = 0; counter1 < cellLineageInfoCount/3; counter1++){
                            extension = to_string(arrayCellLineageInfo [counter1*3]);
                            
                            if (extension.length() == 1) extension = "L0000"+extension;
                            else if (extension.length() == 2) extension = "L000"+extension;
                            else if (extension.length() == 3) extension = "L00"+extension;
                            else if (extension.length() == 4) extension = "L0"+extension;
                            else if (extension.length() == 5) extension = "L"+extension;
                            
                            if (getListCount+2 > getListLimit){
                                string *arrayUpDate = new string [getListCount+10];
                                
                                for (int counter2 = 0; counter2 < getListCount; counter2++) arrayUpDate [counter2] = arrayGetList [counter2];
                                
                                delete [] arrayGetList;
                                arrayGetList = new string [getListLimit+500];
                                getListLimit = getListLimit+500;
                                
                                for (int counter2 = 0; counter2 < getListCount; counter2++) arrayGetList [counter2] = arrayUpDate [counter2];
                                delete [] arrayUpDate;
                            }
                            
                            arrayGetList [getListCount] = extension, getListCount++;
                            entryNumber++;
                        }
                    }
                    else{
                        
                        entryNumber = 1;
                        setStatus6 = 1;
                        setStatus3 = 0;
                        setStatus7 = 0;
                        
                        if (errorCheck == 1){
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Lineage Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    
                    if (setStatus3 == 3 || setStatus7 == 7){
                        setStatus3 = 0;
                        listCrickMonitor = 1;
                    }
                    
                    setStatus4 = 4;
                }
                else{
                    
                    entryNumber = 1;
                    setStatus6 = 2;
                    setStatus3 = 0;
                    setStatus7 = 0;
                    
                    lineageDataCount = 0;
                    cellLineageInfoCount = 0;
                    lineageStartEndCount = 0;
                }
            }
            else{
                
                entryNumber = 1;
                setStatus6 = 1;
                setStatus3 = 0;
                setStatus7 = 0;
            }
            
            if (trackingOn == 1){
                lineageCellSwitch = 1;
                trackingTableSetDone = 1;
            }
        }
        
        if (column == 2){
            NSString *path;
            path = [sender path];
            string analysisNameTemp = [path UTF8String];
            
            if (analysisNameTemp != "" && (int)analysisNameTemp.find("/L") != -1){
                if (trackingOn == 1) [statusDisplay setStringValue:@"Tracking"];
                
                analysisNameTemp = analysisNameTemp.substr(1);
                
                string numberExtract = analysisNameTemp.substr(0, analysisNameTemp.find("/"));
                analysisNameTemp = analysisNameTemp.substr(analysisNameTemp.find("/")+1);
                
                int entryCheck2 = 0;
                int errorCheck = 0;
                ifstream fin;
                
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                saveInfo = numberExtract;
                
                dataSaveRead = [[DataSaveRead alloc] init];
                errorCheck = [dataSaveRead lineageDataRead];
                
                if (errorCheck == 0){
                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+numberExtract+"_Connect/"+ analysisID+"_"+numberExtract+"_LineageStartEnd";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (lineageStartEndStatus == 0){
                        arrayLineageStartEnd = new int [sizeForCopy+50];
                        lineageStartEndLimit = (int)sizeForCopy+50;
                        lineageStartEndStatus = 1;
                    }
                    else if (sizeForCopy > lineageStartEndCount){
                        delete [] arrayLineageStartEnd;
                        arrayLineageStartEnd = new int [sizeForCopy+50];
                        lineageStartEndLimit = (int)sizeForCopy+50;
                    }
                    
                    lineageStartEndCount = 0;
                    
                    fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+numberExtract+"_Treat/"+analysisNameTemp+"/"+analysisID+"_"+analysisNameTemp+"_CellStatus";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        entryCheck2 = 1;
                        
                        if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                        arrayCellNumberInfo = new int [sizeForCopy*2+50];
                        cellNumberInfoCount = 0;
                        cellNumberInfoLimit = (int)sizeForCopy*2+50;
                        cellNumberInfoStatus = 1;
                        
                        fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                            if (numberExtract == arrayTreatmentStatus [counter1*9]) entryCheck2 = 0;
                        }
                    }
                    
                    if (entryCheck2 == 1){
                        string extension = "";
                        
                        for (int counter1 = 0; counter1 < cellNumberInfoCount/7; counter1++){
                            extension = to_string(arrayCellNumberInfo [counter1*7]);
                            
                            if (arrayCellNumberInfo [counter1*7] >= 0){
                                if (extension.length() == 1) extension = "C00000000"+extension;
                                else if (extension.length() == 2) extension = "C0000000"+extension;
                                else if (extension.length() == 3) extension = "C000000"+extension;
                                else if (extension.length() == 4) extension = "C00000"+extension;
                                else if (extension.length() == 5) extension = "C0000"+extension;
                                else if (extension.length() == 6) extension = "C000"+extension;
                                else if (extension.length() == 7) extension = "C00"+extension;
                                else if (extension.length() == 8) extension = "C0"+extension;
                                else if (extension.length() == 9) extension = "C"+extension;
                            }
                            else{
                                
                                extension = extension.substr(1);
                                
                                if (extension.length() == 1) extension = "C-00000000"+extension;
                                else if (extension.length() == 2) extension = "C-0000000"+extension;
                                else if (extension.length() == 3) extension = "C-000000"+extension;
                                else if (extension.length() == 4) extension = "C-00000"+extension;
                                else if (extension.length() == 5) extension = "C-0000"+extension;
                                else if (extension.length() == 6) extension = "C-000"+extension;
                                else if (extension.length() == 7) extension = "C-00"+extension;
                                else if (extension.length() == 8) extension = "C-0"+extension;
                                else if (extension.length() == 9) extension = "C-"+extension;
                            }
                            
                            if (getListCount+2 > getListLimit){
                                string *arrayUpDate = new string [getListCount+10];
                                
                                for (int counter2 = 0; counter2 < getListCount; counter2++) arrayUpDate [counter2] = arrayGetList [counter2];
                                
                                delete [] arrayGetList;
                                arrayGetList = new string [getListLimit+500];
                                getListLimit = getListLimit+500;
                                
                                for (int counter2 = 0; counter2 < getListCount; counter2++) arrayGetList [counter2] = arrayUpDate [counter2];
                                delete [] arrayUpDate;
                            }
                            
                            arrayGetList [getListCount] = extension, getListCount++;
                            entryNumber++;
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Lineage Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            if (trackingOn == 1){
                lineageCellSwitch = 2;
                trackingTableSetDone = 1;
            }
        }
    }
    else if (column == 1 || column == 2) entryNumber = 1;
    
    return entryNumber;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (analysisImageName != "" && trackingImageLock == 0 && setStatus6 == 0){
        if (column == 0 && trackingImageLock == 0){
            string folderName = arrayTreatmentStatus [row*9];
            [cell setObjectValue: @(folderName.c_str())];
            [cell setLoaded:YES];
        }
        
        if (column == 1 && trackingImageLock == 0){
            string folderName = arrayGetList [row];
            [cell setObjectValue: @(folderName.c_str())];
            [cell setLoaded:YES];
        }
        
        if (column == 2 && trackingImageLock == 0){
            string folderName = arrayGetList [row];
            [cell setObjectValue: @(folderName.c_str())];
            [cell setLeaf:YES];
        }
    }
    else if ((column == 1 || column == 2) && setStatus6 == 0){
        [cell setObjectValue: @"Tracking On"];
        [cell setLeaf:YES];
    }
    else{
        
        if (column == 1 && setStatus6 == 1){
            [cell setObjectValue: @"Reload"];
            [cell setLeaf:YES];
        }
        else if (column == 1 && setStatus6 == 2){
            [cell setObjectValue: @"No Data"];
            [cell setLeaf:YES];
        }
        else if (column == 1 && setStatus6 == 3){
            [cell setObjectValue: @"No Lineage"];
            [cell setLeaf:YES];
        }
        
        setStatus6 = 0;
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    saveDataStatus = 0; //-----No longer allow to clear Initial set-----
    
    if (timeOneStatus == 0 && trackingImageLock == 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        NSString *nodePath = [browser path];
        string nodePathString = [nodePath UTF8String];
        
        int findString = (int)nodePathString.find ("Reload");
        
        if (findString == -1) findString = (int)nodePathString.find ("No Data");
        else if (findString == -1) findString = (int)nodePathString.find ("No Lineage");
        else if (findString == -1) findString = (int)nodePathString.find ("Tracking On");
        
        if (nodePathString != "" && findString == -1){
            nodePathString = nodePathString.substr(1);
            
            string treatmentTemp = "";
            string lineageTemp = "";
            string cellNoTemp = "";
            
            int findString1 = (int)nodePathString.find("/");
            
            if (findString1 != -1){
                treatmentTemp = nodePathString.substr(0, (unsigned long)findString1);
                nodePathString = nodePathString.substr((unsigned long)findString1+1);
                
                if ((findString1 = (int)nodePathString.find("/")) != -1){
                    lineageTemp = nodePathString.substr(0, (unsigned long)findString1);
                    nodePathString = nodePathString.substr((unsigned long)findString1+1);
                    
                    if (nodePathString != "") cellNoTemp = nodePathString;
                }
                else lineageTemp = nodePathString;
            }
            else treatmentTemp = nodePathString;
            
            //cout<<treatmentTemp<<" "<<lineageTemp<<" "<<cellNoTemp<<" Treat_Lin_CellNo "<<lineageCellSwitch<<endl;
            
            int cellInfoFond = 0;
            
            if (cellLineageNoHold != "" && cellNoHold != "" && cellNoTemp != "" && lineageTemp != ""){
                string cellLineageExtract = lineageTemp.substr(1);
                string cellNoExtract = cellNoTemp.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                        cellInfoFond = 1;
                        break;
                    }
                }
            }
            else cellInfoFond = 1;
            
            if (cellInfoFond == 1){
                string treatmentNameHoldPrev = treatmentNameHold;
                
                if (treatmentTemp != ""){
                    treatmentNameHold = treatmentTemp;
                    [treatmentDisplay setStringValue: @(treatmentTemp.c_str())];
                    
                    if (treatmentDisplayFirstSet == 0) treatmentDisplayFirstSet = 1;
                }
                else{
                    
                    [treatmentDisplay setStringValue: @"nil"];
                    treatmentNameHold = "";
                }
                
                if (lineageTemp != ""){
                    cellLineageNoHold = lineageTemp;
                    [cellLineageNoDisplay setStringValue: @(lineageTemp.c_str())];
                }
                else{
                    
                    [cellLineageNoDisplay setStringValue: @"nil"];
                    cellLineageNoHold = "";
                }
                
                if (cellNoTemp != ""){
                    int errorCheck = 0;
                    long sizeForCopy = 0;
                    struct stat sizeOfFile;
                    
                    ifstream fin;
                    
                    saveInfo = treatmentNameHold;
                    
                    dataSaveRead = [[DataSaveRead alloc] init];
                    errorCheck = [dataSaveRead lineageDataRead];
                    
                    if (errorCheck == 0){
                        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
                        
                        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (lineageStartEndStatus == 1){
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                            lineageStartEndStatus = 1;
                        }
                        else if (sizeForCopy > lineageStartEndCount){
                            delete [] arrayLineageStartEnd;
                            arrayLineageStartEnd = new int [sizeForCopy+50];
                            lineageStartEndLimit = (int)sizeForCopy+50;
                        }
                        
                        lineageStartEndCount = 0;
                        
                        fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            int readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                        
                        cellNoHold = cellNoTemp;
                        [cellNoDisplay setStringValue: @(cellNoTemp.c_str())];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Lineage Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    [cellNoDisplay setStringValue: @"nil"];
                    cellNoHold = "";
                }
                
                if (treatmentTemp != "" || lineageTemp != "" || cellNoTemp != ""){
                    listCrickMonitor = 1;
                    timeOneStatus = 0;
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Selected Cell Deleted"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 0;
    tableCurrentRowHold = 0;
    
    if (tableDataSetDone == 2){
        if (listSwitchCall == 1){
            tableViewContent = gravityCenterRevCount/6;
            [listName setStringValue:@"Cells/Revised"];
            [listTreatmentDisplay setStringValue:@""];
        }
        
        if (listSwitchCall == 2){
            tableViewContent = targetHoldInfoCount/4;
            [listName setStringValue:@"Line/Circle"];
            [listTreatmentDisplay setStringValue:@""];
        }
    }
    
    if (tableTrackingProcessing == 2){
        if (listSwitchCall == 1){
            tableViewContent = connectLineageRelCount/6;
            [listName setStringValue:@"Cells/Revised"];
            [listTreatmentDisplay setStringValue:@""];
        }
        
        if (listSwitchCall == 2){
            tableViewContent = targetHoldInfoCount/4;
            [listName setStringValue:@"Line/Circle"];
            [listTreatmentDisplay setStringValue:@""];
        }
    }
    
    //cout<<trackingTableSetDone<<" "<<tableListSwitch<<" "<<lineageCellSwitch<<" "<<tableTrackingProcessing<<" statusInfo"<<endl;
    
    if (trackingTableSetDone == 2){
        if (tableListSwitch == 1){
            tableViewContent = doneListCount/5;
            [listName setStringValue:@"Check List"];
            
            if (doneListDisplayLimit < doneListLimit){
                delete [] arrayDoneListDisplay;
                arrayDoneListDisplay = new string [doneListLimit+500];
                doneListDisplayCount = 0;
                doneListDisplayLimit = doneListLimit+500;
            }
            
            if (doneDisplayOptions == 0){
                for (int counter1 = 0; counter1 < doneListCount; counter1++) arrayDoneListDisplay [counter1] = arrayDoneList [counter1];
                
                doneListDisplayCount = doneListCount;
                tableViewContent = doneListDisplayCount/5;
                
                [listTreatmentDisplay setStringValue:@"All"];
            }
            else if (doneDisplayOptions == 1){
                doneListDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                    if (arrayDoneList [counter1*5] == treatmentNameHold){
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+1], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+2], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+3], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+4], doneListDisplayCount++;
                    }
                }
                
                tableViewContent = doneListDisplayCount/5;
                [listTreatmentDisplay setStringValue:@(treatmentNameHold.c_str())];
            }
            else if (doneDisplayOptions == 2){
                string imageNumberLast;
                string checkPointDisplay;
                string statusDisplayDone;
                
                doneListDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                    imageNumberLast = arrayDoneList [counter1*5+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    checkPointDisplay = arrayDoneList [counter1*5+3];
                    if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
                    
                    statusDisplayDone = arrayDoneList [counter1*5+4];
                    
                    int statusCheck = 0;
                    
                    if (statusDisplayDone == "OK" ||  statusDisplayDone == "OK/m" ||  statusDisplayDone == "OK/e" ||  statusDisplayDone == "OK/me") statusCheck = 1;
                    
                    if (arrayDoneList [counter1*5] == treatmentNameHold && (atoi(imageNumberLast.c_str()) > atoi(checkPointDisplay.c_str()) || statusCheck == 0)){
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+1], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+2], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+3], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+4], doneListDisplayCount++;
                    }
                }
                
                tableViewContent = doneListDisplayCount/5;
                
                [listTreatmentDisplay setStringValue:@"Check"];
            }
            else if (doneDisplayOptions == 3){
                string imageNumberLast;
                string checkPointDisplay;
                string statusDisplayDone;
                
                doneListDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                    imageNumberLast = arrayDoneList [counter1*5+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    checkPointDisplay = arrayDoneList [counter1*5+3];
                    if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
                    
                    statusDisplayDone = arrayDoneList [counter1*5+4];
                    
                    int statusCheck = 0;
                    
                    if (statusDisplayDone == "OK" ||  statusDisplayDone == "OK/m" ||  statusDisplayDone == "OK/e" ||  statusDisplayDone == "OK/me") statusCheck = 1;
                    
                    if (arrayDoneList [counter1*5] == treatmentNameHold && atoi(imageNumberLast.c_str()) == atoi(checkPointDisplay.c_str()) && statusCheck == 1){
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+1], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+2], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+3], doneListDisplayCount++;
                        arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+4], doneListDisplayCount++;
                    }
                }
                
                tableViewContent = doneListDisplayCount/5;
                
                [listTreatmentDisplay setStringValue:@"OK"];
            }
            else if (doneDisplayOptions == 4){
                progressTimingC = 1;
                
                if (autoCheckFlag == 0){
                    doneListDisplayCount = 0;
                    
                    string checkPointDisplay;
                    string imageNumberLast;
                    int minCheckTime = 100000;
                    int endOfTime = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] == treatmentNameHold){
                            imageNumberLast = arrayDoneList [counter1*5+3];
                            checkPointDisplay = arrayDoneList [counter1*5+3];
                            
                            if (imageNumberLast.substr(0, imageNumberLast.find(":")) != checkPointDisplay.substr(checkPointDisplay.find(":")+1)){
                                if ((int)imageNumberLast.find(":") != -1 && atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str()) > endOfTime) endOfTime = atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str());
                                if ((int)checkPointDisplay.find(":") != -1 && atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str()) < minCheckTime) minCheckTime = atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str());
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] == treatmentNameHold){
                            imageNumberLast = arrayQueueList [counter1*6+3];
                            checkPointDisplay = arrayQueueList [counter1*6+3];
                            
                            if (imageNumberLast.substr(0, imageNumberLast.find(":")) != checkPointDisplay.substr(checkPointDisplay.find(":")+1)){
                                if ((int)imageNumberLast.find(":") != -1 && atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str()) > endOfTime) endOfTime = atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str());
                                if ((int)checkPointDisplay.find(":") != -1 && atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str()) < minCheckTime) minCheckTime = atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str());
                            }
                        }
                    }
                    
                    if (minCheckTime != 100000 && endOfTime != 0 && cellNoHold != "" && cellLineageNoHold != ""){
                        string autoCheckPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_AutoCheckData";
                        
                        long sizeForCopy = 0;
                        struct stat sizeOfFile;
                        
                        if (stat(autoCheckPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (autoCheckTempStatus == 1){
                            delete [] autoCheckTemp;
                            autoCheckTempCount = 0;
                        }
                        
                        if (sizeForCopy != 0){
                            autoCheckTemp = new int [sizeForCopy+50];
                            autoCheckTempLimit = sizeForCopy+50;
                            autoCheckTempCount = 0;
                        }
                        else{
                            
                            autoCheckTemp = new int [10000];
                            autoCheckTempLimit = 10000;
                            autoCheckTempCount = 0;
                            
                            minCheckTime = timeOneHold;
                        }
                        
                        ifstream fin;
                        
                        if (sizeForCopy != 0){
                            int terminationFlag = 0;
                            string getString;
                            
                            fin.open(autoCheckPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString != ""){
                                        autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Time
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Lineage no
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Cell no
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Event type
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----x Position
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----y Position
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Area
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Average
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                                
                                //for (int counterA = 0; counterA < autoCheckTempCount/8; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<autoCheckTemp [counterA*8+counterB];
                                //   cout<<" autoCheckTemp "<<counterA<<endl;
                                //}
                                
                                int *autoCheckTemp2 = new int [sizeForCopy+50];
                                int autoCheckTempCount2 = 0;
                                
                                for (int counter1 = 0; counter1 < autoCheckTempCount/8; counter1++){
                                    if (autoCheckTemp [counter1*8] < minCheckTime){
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+1], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+2], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+3], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+4], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+5], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+6], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+7], autoCheckTempCount2++;
                                    }
                                }
                                
                                autoCheckTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < autoCheckTempCount2; counter1++) autoCheckTemp [autoCheckTempCount] = autoCheckTemp2 [counter1], autoCheckTempCount++;
                                
                                delete [] autoCheckTemp2;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < autoCheckTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<autoCheckTemp [counterA*8+counterB];
                        //    cout<<" autoCheckTemp "<<counterA<<endl;
                        //}
                        
                        int readPosition = 0;
                        int stepCount = 0;
                        int finData [20];
                        int connectLineageRelVerCount = 0;
                        int checkFlag = 0;
                        int readingError = 0;
                        int gravityCenterRevTempCount = 0;
                        
                        long size1 = 0;
                        long size2 = 0;
                        
                        string extension;
                        string connectRelationPath;
                        string connectDataPath;
                        
                        for (int counter1 = minCheckTime; counter1 <= endOfTime; counter1++){
                            extension = to_string(counter1);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter2 = 0; counter2 < 6; counter2++){
                                sizeForCopy = 0;
                                
                                if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter2 == 0) size1 = sizeForCopy;
                                    else if (counter2 == 1) size2 = sizeForCopy;
                                    else if (counter2 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter2 == 3) size1 = sizeForCopy;
                                    else if (counter2 == 4) size2 = sizeForCopy;
                                    else if (counter2 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (checkFlag == 1){
                                //-----Master Data upLoad-----
                                int *arrayGravityCenterTemp = new int [sizeForCopy+50];
                                gravityCenterRevTempCount = 0;
                                
                                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    readingError = 0;
                                    
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++;
                                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData [9] = finData [8]*256+finData [9];
                                                
                                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                                else{
                                                    
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        delete [] uploadTemp;
                                        
                                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
                                        connectLineageRelVerCount = 0;
                                        
                                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            readPosition = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                                    finData [3] = uploadTemp [readPosition], readPosition++;
                                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                                    finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                                    finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                    finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                    finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                    
                                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                    finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                    finData [7] = finData [6]*256+finData [7];
                                                    
                                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                    
                                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                            
                                            delete [] uploadTemp;
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectLineageRelVerCount/6; counter2++){
                                            if (autoCheckTempCount+10 > autoCheckTempLimit){
                                                int *arrayUpDate = new int [autoCheckTempCount+10];
                                                
                                                for (int counter3 = 0; counter3 < autoCheckTempCount; counter3++) arrayUpDate [counter3] = autoCheckTemp [counter3];
                                                
                                                delete [] autoCheckTemp;
                                                autoCheckTemp = new int [autoCheckTempLimit+10000];
                                                autoCheckTempLimit = autoCheckTempLimit+10000;
                                                
                                                for (int counter3 = 0; counter3 < autoCheckTempCount; counter3++) autoCheckTemp [counter3] = arrayUpDate [counter3];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            autoCheckTemp [autoCheckTempCount] = counter1, autoCheckTempCount++;
                                            autoCheckTemp [autoCheckTempCount] = arrayConnectLineageRelVer [counter2*6], autoCheckTempCount++;
                                            autoCheckTemp [autoCheckTempCount] = arrayConnectLineageRelVer [counter2*6+3], autoCheckTempCount++;
                                            autoCheckTemp [autoCheckTempCount] = 0, autoCheckTempCount++; //======Event add
                                            
                                            for (int counter3 = 0; counter3 < gravityCenterRevTempCount/6; counter3++){
                                                if (arrayConnectLineageRelVer [counter2*6+1] == arrayGravityCenterTemp [counter3*6+4]){
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6], autoCheckTempCount++;
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6+1], autoCheckTempCount++;
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6+2], autoCheckTempCount++;
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6+3], autoCheckTempCount++;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        delete [] arrayConnectLineageRelVer;
                                    }
                                }
                                
                                delete [] arrayGravityCenterTemp;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < autoCheckTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<autoCheckTemp [counterA*8+counterB];
                        //    cout<<" autoCheckTemp "<<counterA<<endl;
                        //}
                        
                        if (readingError == 0){
                            int autoCheckTempCount2 = 0;
                            int startTimePoint = 0;
                            int distanceCount = 0;
                            int xData1 = 0;
                            int yData1 = 0;
                            int statusCheckXY = 0;
                            int statusCheckArea = 0;
                            int statusCheckDiv = 0;
                            int areaCheckAverage = 0;
                            int areaCheckTotal = 0;
                            int intensityCheckAverage = 0;
                            int intensityCheckTotal = 0;
                            int startArea = 0;
                            int checkTime = 0;
                            int startIntensity = 0;
                            int newCellStart = 0;
                            double totalDistance = 0;
                            double averageDistance = 0;
                            
                            string lineageNoString;
                            string cellNoString;
                            
                            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                imageNumberLast = arrayDoneList [counter1*5+3];
                                checkPointDisplay = arrayDoneList [counter1*5+3];
                                
                                if ((imageNumberLast.substr(0, imageNumberLast.find(":")) != checkPointDisplay.substr(checkPointDisplay.find(":")+1)) || (imageNumberLast.substr(0, imageNumberLast.find(":")) == checkPointDisplay.substr(checkPointDisplay.find(":")+1) && arrayDoneList [counter1*5+4] != "OK")){
                                    if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
                                    
                                    if (arrayDoneList [counter1*5] == treatmentNameHold){
                                        int *autoCheckTemp2 = new int [autoCheckTempCount+50];
                                        autoCheckTempCount2 = 0;
                                        
                                        startTimePoint = 0;
                                        xData1 = 0;
                                        yData1 = 0;
                                        startArea = 0;
                                        startIntensity = 0;
                                        
                                        lineageNoString = arrayDoneList [counter1*5+1].substr(1);
                                        cellNoString = arrayDoneList [counter1*5+2].substr(1);
                                        
                                        for (int counter2 = 0; counter2 < autoCheckTempCount/8; counter2++){
                                            if (autoCheckTemp [counter2*8+1] == atoi(lineageNoString.c_str()) && autoCheckTemp [counter2*8+2] == atoi(cellNoString.c_str())){
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+3], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+4], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+5], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+6], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+7], autoCheckTempCount2++;
                                                
                                                if (startTimePoint == 0){
                                                    startTimePoint = autoCheckTemp [counter2*8];
                                                    xData1 = autoCheckTemp [counter2*8+4];
                                                    yData1 = autoCheckTemp [counter2*8+5];
                                                    startArea = autoCheckTemp [counter2*8+6];
                                                    startIntensity = autoCheckTemp [counter2*8+7];
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < autoCheckTempCount2/6; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<autoCheckTemp2 [counterA*6+counterB];
                                        //    cout<<" autoCheckTemp2 "<<counterA<<endl;
                                        //}
                                        
                                        averageDistance = 0;
                                        areaCheckAverage = 0;
                                        intensityCheckAverage = 0;
                                        
                                        newCellStart = 0;
                                        
                                        if (atoi(checkPointDisplay.c_str())-startTimePoint > 5){
                                            totalDistance = 0;
                                            distanceCount = 0;
                                            xData1 = 0;
                                            yData1 = 0;
                                            areaCheckTotal = 0;
                                            intensityCheckTotal = 0;
                                            
                                            for (int counter2 = autoCheckTempCount2/6; counter2 >= 0; counter2--){
                                                if (autoCheckTemp2 [counter2*6] == atoi(checkPointDisplay.c_str())){
                                                    xData1 = autoCheckTemp2 [counter2*6+2];
                                                    yData1 = autoCheckTemp2 [counter2*6+3];
                                                }
                                                else if (xData1 != 0 && yData1 != 0 && distanceCount != 4){
                                                    totalDistance = totalDistance+sqrt((xData1-autoCheckTemp2 [counter2*6+2])*(xData1-autoCheckTemp2 [counter2*6+2])+(yData1-autoCheckTemp2 [counter2*6+3])*(yData1-autoCheckTemp2 [counter2*6+3]));
                                                    
                                                    areaCheckTotal = areaCheckTotal+autoCheckTemp2 [counter2*6+4];
                                                    intensityCheckTotal = intensityCheckTotal+autoCheckTemp2 [counter2*6+5];
                                                    
                                                    xData1 = autoCheckTemp2 [counter2*6+2];
                                                    yData1 = autoCheckTemp2 [counter2*6+3];
                                                    
                                                    distanceCount++;
                                                }
                                            }
                                            
                                            averageDistance = totalDistance/(double)4;
                                            areaCheckAverage = (int)(areaCheckTotal/(double)4);
                                            intensityCheckAverage = (int)(intensityCheckTotal/(double)4);
                                        }
                                        else if (autoCheckTempCount2/6 > 2){
                                            averageDistance = sqrt((xData1-autoCheckTemp2 [8])*(xData1-autoCheckTemp2 [8])+(yData1-autoCheckTemp2 [9])*(yData1-autoCheckTemp2 [9]));
                                            areaCheckAverage = startArea;
                                            intensityCheckAverage = startIntensity;
                                            newCellStart = 1;
                                        }
                                        
                                        statusCheckArea = 0;
                                        statusCheckXY = 0;
                                        xData1 = 0;
                                        yData1 = 0;
                                        
                                        for (int counter2 = 0; counter2 < autoCheckTempCount2/6; counter2++){
                                            if (autoCheckTemp2 [counter2*6] == atoi(checkPointDisplay.c_str())){
                                                xData1 = autoCheckTemp2 [counter2*6+2];
                                                yData1 = autoCheckTemp2 [counter2*6+3];
                                            }
                                            else if (xData1 != 0 && yData1 != 0){
                                                if (sqrt((xData1-autoCheckTemp2 [counter2*6+2])*(xData1-autoCheckTemp2 [counter2*6+2])+(yData1-autoCheckTemp2 [counter2*6+3])*(yData1-autoCheckTemp2 [counter2*6+3])) > averageDistance*autoCheckDistanceFoldHold && sqrt((xData1-autoCheckTemp2 [counter2*6+2])*(xData1-autoCheckTemp2 [counter2*6+2])+(yData1-autoCheckTemp2 [counter2*6+3])*(yData1-autoCheckTemp2 [counter2*6+3])) > autoCheckDistanceHold){ //=======Parameter
                                                    
                                                    statusCheckXY = autoCheckTemp2 [counter2*6];
                                                    break;
                                                }
                                                
                                                if (autoCheckTemp2 [counter2*6+4] > areaCheckAverage*autoCheckAreaHold){ //=======Parameter
                                                    statusCheckArea = autoCheckTemp2 [counter2*6];
                                                    break;
                                                }
                                                
                                                xData1 = autoCheckTemp2 [counter2*6+2];
                                                yData1 = autoCheckTemp2 [counter2*6+3];
                                            }
                                        }
                                        
                                        statusCheckDiv = 0;
                                        
                                        intensityCheckAverage = intensityCheckAverage+autoCheckIntensityHold;
                                        
                                        if (intensityCheckAverage >= 255) intensityCheckAverage = 255;
                                        
                                        if (autoCheckTempCount2/6 > autoCheckDivisionHold && autoCheckTempCount2/6-20 > 0){//=======Parameter
                                            for (int counter2 = autoCheckDivisionHold-20; counter2 < autoCheckTempCount2/6; counter2++){//=======Parameter
                                                if (autoCheckTemp2 [counter2*6+5] > intensityCheckAverage){
                                                    statusCheckDiv = autoCheckTemp2 [counter2*6];
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        checkTime = 0;
                                        
                                        if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv == 0) checkTime = statusCheckXY;
                                        else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv == 0) checkTime = statusCheckArea;
                                        else if (statusCheckXY == 0 && statusCheckArea == 0 && statusCheckDiv != 0) checkTime = statusCheckDiv;
                                        else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv == 0){
                                            if (statusCheckXY <= statusCheckArea) checkTime = statusCheckXY;
                                            else checkTime = statusCheckArea;
                                        }
                                        else if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv != 0){
                                            if (statusCheckXY <= statusCheckDiv) checkTime = statusCheckXY;
                                            else checkTime = statusCheckDiv;
                                        }
                                        else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv != 0){
                                            if (statusCheckArea <= statusCheckDiv) checkTime = statusCheckArea;
                                            else checkTime = statusCheckDiv;
                                        }
                                        else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv != 0){
                                            if (statusCheckXY <= statusCheckArea && statusCheckXY <= statusCheckDiv) checkTime = statusCheckXY;
                                            else if (statusCheckArea <= statusCheckXY && statusCheckArea <= statusCheckDiv) checkTime = statusCheckArea;
                                            else if (statusCheckDiv <= statusCheckXY && statusCheckDiv <= statusCheckArea) checkTime = statusCheckDiv;
                                        }
                                        
                                        if (checkTime != 0){
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+1], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+2], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = imageNumberLast.substr(0, imageNumberLast.find(":"))+":"+to_string(checkTime), doneListDisplayCount++;
                                            
                                            if (newCellStart == 0){
                                                if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv == 0) arrayDoneListDisplay [doneListDisplayCount] = "AX", doneListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayDoneListDisplay [doneListDisplayCount] = "AA", doneListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "AM", doneListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayDoneListDisplay [doneListDisplayCount] = "AXA", doneListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "AXM", doneListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "AAM", doneListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "AXAM", doneListDisplayCount++;
                                            }
                                            else{
                                                
                                                if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv == 0) arrayDoneListDisplay [doneListDisplayCount] = "BX", doneListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayDoneListDisplay [doneListDisplayCount] = "BA", doneListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "AM", doneListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayDoneListDisplay [doneListDisplayCount] = "BXA", doneListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "BXM", doneListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "BAM", doneListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayDoneListDisplay [doneListDisplayCount] = "BXAM", doneListDisplayCount++;
                                            }
                                        }
                                        else{
                                            
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+1], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+2], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+3], doneListDisplayCount++;
                                            arrayDoneListDisplay [doneListDisplayCount] = arrayDoneList [counter1*5+4], doneListDisplayCount++;
                                        }
                                        
                                        delete [] autoCheckTemp2;
                                    }
                                }
                            }
                            
                            ofstream oin;
                            oin.open(autoCheckPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < autoCheckTempCount/8; counter1++){
                                oin<<autoCheckTemp [counter1*8]<<endl;
                                oin<<autoCheckTemp [counter1*8+1]<<endl;
                                oin<<autoCheckTemp [counter1*8+2]<<endl;
                                oin<<autoCheckTemp [counter1*8+3]<<endl;
                                oin<<autoCheckTemp [counter1*8+4]<<endl;
                                oin<<autoCheckTemp [counter1*8+5]<<endl;
                                oin<<autoCheckTemp [counter1*8+6]<<endl;
                                oin<<autoCheckTemp [counter1*8+7]<<endl;
                            }
                            
                            oin.close();
                            
                            autoCheckFlag = 1;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    string *arrayDoneListDisplayTemp = new string [doneListDisplayCount+10];
                    int arrayDoneListDisplayTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListDisplayCount/5; counter1++){
                        for (int counter2 = 0; counter2 < doneListCount/5-1; counter2++){
                            
                            if (arrayDoneListDisplay [counter1*5] == arrayDoneList [counter2*5] && arrayDoneListDisplay [counter1*5+1] == arrayDoneList [counter2*5+1] && arrayDoneListDisplay [counter1*5+2] == arrayDoneList [counter2*5+2] &&(arrayDoneList [counter2*5+4] != "OK" || (arrayDoneList [counter2*5+4] == "OK" && arrayDoneList [counter2*5+3].substr(0, arrayDoneList [counter2*5+3].find(":")) != arrayDoneList [counter2*5+3].substr(arrayDoneList [counter2*5+3].find(":")+1)))){
                                arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5], arrayDoneListDisplayTempCount++;
                                arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+1], arrayDoneListDisplayTempCount++;
                                arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+2], arrayDoneListDisplayTempCount++;
                                arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+3], arrayDoneListDisplayTempCount++;
                                arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+4], arrayDoneListDisplayTempCount++;
                                break;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < doneListDisplayCount/5; counter1++){
                        if (arrayDoneListDisplay [counter1*5] == arrayDoneList [(doneListCount/5-1)*5] && arrayDoneListDisplay [counter1*5+1] == arrayDoneList [(doneListCount/5-1)*5+1] && arrayDoneListDisplay [counter1*5+2] == arrayDoneList [(doneListCount/5-1)*5+2] &&(arrayDoneList [(doneListCount/5-1)*5+4] != "OK" || (arrayDoneList [(doneListCount/5-1)*5+4] == "OK" && arrayDoneList [(doneListCount/5-1)*5+3].substr(0, arrayDoneList [(doneListCount/5-1)*5+3].find(":")) != arrayDoneList [(doneListCount/5-1)*5+3].substr(arrayDoneList [(doneListCount/5-1)*5+3].find(":")+1)))){
                            arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5], arrayDoneListDisplayTempCount++;
                            arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+1], arrayDoneListDisplayTempCount++;
                            arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+2], arrayDoneListDisplayTempCount++;
                            arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+3], arrayDoneListDisplayTempCount++;
                            
                            if (arrayDoneListDisplay [0] == arrayDoneList [(doneListCount/5-1)*5] && arrayDoneListDisplay [1] == arrayDoneList [(doneListCount/5-1)*5+1] && arrayDoneListDisplay [2] == arrayDoneList [(doneListCount/5-1)*5+2]){
                                arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneList [(doneListCount/5-1)*5+4], arrayDoneListDisplayTempCount++;
                            }
                            else arrayDoneListDisplayTemp [arrayDoneListDisplayTempCount] = arrayDoneListDisplay [counter1*5+4], arrayDoneListDisplayTempCount++;
                            
                            break;
                        }
                    }
                    
                    doneListDisplayCount = 0;
                    
                    for (int counter1 = 0; counter1 < arrayDoneListDisplayTempCount; counter1++) arrayDoneListDisplay [doneListDisplayCount] = arrayDoneListDisplayTemp [counter1], doneListDisplayCount++;
                    
                    delete [] arrayDoneListDisplayTemp;
                }
                
                tableViewContent = doneListDisplayCount/5;
                
                progressTimingC = 3;
                
                [listTreatmentDisplay setStringValue:@"AU"];
            }
        }
        else if (tableListSwitch == 2){
            [listName setStringValue:@"Queue List"];
            
            if (queueListDisplayLimit < queueListLimit){
                delete [] arrayQueueListDisplay;
                arrayQueueListDisplay = new string [queueListLimit+500];
                queueListDisplayCount = 0;
                queueListDisplayLimit = queueListLimit+500;
            }
            
            if (queueDisplayOptions == 0){
                for (int counter1 = 0; counter1 < queueListCount; counter1++) arrayQueueListDisplay [counter1] = arrayQueueList [counter1];
                
                queueListDisplayCount = queueListCount;
                tableViewContent = queueListDisplayCount/6;
                
                [listTreatmentDisplay setStringValue:@"All"];
            }
            else if (queueDisplayOptions == 1){
                queueListDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    if (arrayQueueList [counter1*6] == treatmentNameHold){
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+1], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+2], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+3], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+4], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+5], queueListDisplayCount++;
                    }
                }
                
                tableViewContent = queueListDisplayCount/6;
                [listTreatmentDisplay setStringValue:@(treatmentNameHold.c_str())];
            }
            else if (queueDisplayOptions == 2){
                string imageNumberLast;
                string checkPointDisplay;
                
                queueListDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    imageNumberLast = arrayQueueList [counter1*6+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    checkPointDisplay = arrayQueueList [counter1*6+3];
                    if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
                    
                    if (arrayQueueList [counter1*6] == treatmentNameHold && atoi(imageNumberLast.c_str()) >  atoi(checkPointDisplay.c_str())){
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+1], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+2], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+3], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+4], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+5], queueListDisplayCount++;
                    }
                }
                
                tableViewContent = queueListDisplayCount/6;
                
                [listTreatmentDisplay setStringValue:@"Check"];
            }
            else if (queueDisplayOptions == 3){ //============
                string imageNumberLast;
                
                queueListDisplayCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    imageNumberLast = arrayQueueList [counter1*6+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    if (arrayQueueList [counter1*6] == treatmentNameHold && atoi(imageNumberLast.c_str()) == timeEndHold){
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+1], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+2], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+3], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+4], queueListDisplayCount++;
                        arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+5], queueListDisplayCount++;
                    }
                }
                
                tableViewContent = queueListDisplayCount/6;
                
                [listTreatmentDisplay setStringValue:@"Track End"];
            }
            else if (queueDisplayOptions == 4){ //============
                progressTimingB = 1;
                
                if (autoCheckFlag == 0){
                    queueListDisplayCount = 0;
                    
                    string checkPointDisplay;
                    string imageNumberLast;
                    int minCheckTime = 100000;
                    int endOfTime = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] == treatmentNameHold){
                            imageNumberLast = arrayDoneList [counter1*5+3];
                            checkPointDisplay = arrayDoneList [counter1*5+3];
                            
                            if (imageNumberLast.substr(0, imageNumberLast.find(":")) != checkPointDisplay.substr(checkPointDisplay.find(":")+1)){
                                if ((int)imageNumberLast.find(":") != -1 && atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str()) > endOfTime) endOfTime = atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str());
                                
                                if ((int)checkPointDisplay.find(":") != -1 && atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str()) < minCheckTime) minCheckTime = atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str());
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] == treatmentNameHold){
                            imageNumberLast = arrayQueueList [counter1*6+3];
                            checkPointDisplay = arrayQueueList [counter1*6+3];
                            
                            if (imageNumberLast.substr(0, imageNumberLast.find(":")) != checkPointDisplay.substr(checkPointDisplay.find(":")+1)){
                                if ((int)imageNumberLast.find(":") != -1 && atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str()) > endOfTime) endOfTime = atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str());
                                if ((int)checkPointDisplay.find(":") != -1 && atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str()) < minCheckTime) minCheckTime = atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str());
                            }
                        }
                    }
                    
                    if (minCheckTime != 100000 && endOfTime != 0 && cellNoHold != "" && cellLineageNoHold != ""){
                        string autoCheckPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_AutoCheckData";
                        
                        long sizeForCopy = 0;
                        struct stat sizeOfFile;
                        
                        if (stat(autoCheckPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (autoCheckTempStatus == 1){
                            delete [] autoCheckTemp;
                            autoCheckTempCount = 0;
                        }
                        
                        if (sizeForCopy != 0){
                            autoCheckTemp = new int [sizeForCopy+50];
                            autoCheckTempLimit = sizeForCopy+50;
                            autoCheckTempCount = 0;
                        }
                        else{
                            
                            autoCheckTemp = new int [10000];
                            autoCheckTempLimit = 10000;
                            autoCheckTempCount = 0;
                            
                            minCheckTime = timeOneHold;
                        }
                        
                        ifstream fin;
                        
                        if (sizeForCopy != 0){
                            int terminationFlag = 0;
                            string getString;
                            
                            fin.open(autoCheckPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                do{
                                    
                                    terminationFlag = 1;
                                    
                                    getline(fin, getString);
                                    
                                    if (getString != ""){
                                        autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Time
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Lineage no
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Cell no
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Event type
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----x Position
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----y Position
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Area
                                        getline(fin, getString), autoCheckTemp [autoCheckTempCount] = atoi(getString.c_str()), autoCheckTempCount++; //----Average
                                    }
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                                
                                fin.close();
                                
                                //for (int counterA = 0; counterA < autoCheckTempCount/8; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<autoCheckTemp [counterA*8+counterB];
                                //   cout<<" autoCheckTemp "<<counterA<<endl;
                                //}
                                
                                int *autoCheckTemp2 = new int [sizeForCopy+50];
                                int autoCheckTempCount2 = 0;
                                
                                for (int counter1 = 0; counter1 < autoCheckTempCount/8; counter1++){
                                    if (autoCheckTemp [counter1*8] < minCheckTime){
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+1], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+2], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+3], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+4], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+5], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+6], autoCheckTempCount2++;
                                        autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter1*8+7], autoCheckTempCount2++;
                                    }
                                }
                                
                                autoCheckTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < autoCheckTempCount2; counter1++) autoCheckTemp [autoCheckTempCount] = autoCheckTemp2 [counter1], autoCheckTempCount++;
                                
                                delete [] autoCheckTemp2;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < autoCheckTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<autoCheckTemp [counterA*8+counterB];
                        //    cout<<" autoCheckTemp "<<counterA<<endl;
                        //}
                        
                        int readPosition = 0;
                        int stepCount = 0;
                        int finData [20];
                        int connectLineageRelVerCount = 0;
                        int readingError = 0;
                        int gravityCenterRevTempCount = 0;
                        
                        long size1 = 0;
                        long size2 = 0;
                        int checkFlag = 0;
                        
                        string extension;
                        string connectRelationPath;
                        string connectDataPath;
                        
                        for (int counter1 = minCheckTime; counter1 <= endOfTime; counter1++){
                            extension = to_string(counter1);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter2 = 0; counter2 < 6; counter2++){
                                sizeForCopy = 0;
                                
                                if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter2 == 0) size1 = sizeForCopy;
                                    else if (counter2 == 1) size2 = sizeForCopy;
                                    else if (counter2 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter2 == 3) size1 = sizeForCopy;
                                    else if (counter2 == 4) size2 = sizeForCopy;
                                    else if (counter2 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (checkFlag == 1){
                                
                                //-----Master Data upLoad-----
                                int *arrayGravityCenterTemp = new int [sizeForCopy+50];
                                gravityCenterRevTempCount = 0;
                                
                                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                readingError = 1;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++;
                                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData [9] = finData [8]*256+finData [9];
                                                
                                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                                else{
                                                    
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                                                    arrayGravityCenterTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        delete [] uploadTemp;
                                        
                                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
                                        connectLineageRelVerCount = 0;
                                        
                                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            readPosition = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                                    finData [3] = uploadTemp [readPosition], readPosition++;
                                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                                    finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                                    finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                    finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                    finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                    
                                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                    finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                    finData [7] = finData [6]*256+finData [7];
                                                    
                                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                    
                                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                                        arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                            
                                            delete [] uploadTemp;
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectLineageRelVerCount/6; counter2++){
                                            if (autoCheckTempCount+10 > autoCheckTempLimit){
                                                int *arrayUpDate = new int [autoCheckTempCount+10];
                                                
                                                for (int counter3 = 0; counter3 < autoCheckTempCount; counter3++) arrayUpDate [counter3] = autoCheckTemp [counter3];
                                                
                                                delete [] autoCheckTemp;
                                                autoCheckTemp = new int [autoCheckTempLimit+10000];
                                                autoCheckTempLimit = autoCheckTempLimit+10000;
                                                
                                                for (int counter3 = 0; counter3 < autoCheckTempCount; counter3++) autoCheckTemp [counter3] = arrayUpDate [counter3];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            autoCheckTemp [autoCheckTempCount] = counter1, autoCheckTempCount++;
                                            autoCheckTemp [autoCheckTempCount] = arrayConnectLineageRelVer [counter2*6], autoCheckTempCount++;
                                            autoCheckTemp [autoCheckTempCount] = arrayConnectLineageRelVer [counter2*6+3], autoCheckTempCount++;
                                            autoCheckTemp [autoCheckTempCount] = 0, autoCheckTempCount++; //======Event add
                                            
                                            for (int counter3 = 0; counter3 < gravityCenterRevTempCount/6; counter3++){
                                                if (arrayConnectLineageRelVer [counter2*6+1] == arrayGravityCenterTemp [counter3*6+4]){
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6], autoCheckTempCount++;
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6+1], autoCheckTempCount++;
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6+2], autoCheckTempCount++;
                                                    autoCheckTemp [autoCheckTempCount] = arrayGravityCenterTemp [counter3*6+3], autoCheckTempCount++;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        delete [] arrayConnectLineageRelVer;
                                    }
                                }
                                
                                delete [] arrayGravityCenterTemp;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < autoCheckTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<autoCheckTemp [counterA*8+counterB];
                        //    cout<<" autoCheckTemp "<<counterA<<endl;
                        //}
                        
                        if (readingError == 0){
                            int autoCheckTempCount2 = 0;
                            int startTimePoint = 0;
                            int distanceCount = 0;
                            int xData1 = 0;
                            int yData1 = 0;
                            int statusCheckXY = 0;
                            int statusCheckArea = 0;
                            int statusCheckDiv = 0;
                            int areaCheckAverage = 0;
                            int areaCheckTotal = 0;
                            int intensityCheckAverage = 0;
                            int intensityCheckTotal = 0;
                            int startArea = 0;
                            int checkTime = 0;
                            int startIntensity = 0;
                            int newCellStart = 0;
                            double totalDistance = 0;
                            double averageDistance = 0;
                            
                            string lineageNoString;
                            string cellNoString;
                            
                            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                imageNumberLast = arrayQueueList [counter1*6+3];
                                checkPointDisplay = arrayQueueList [counter1*6+3];
                                
                                if (imageNumberLast.substr(0, imageNumberLast.find(":")) != checkPointDisplay.substr(checkPointDisplay.find(":")+1) && atoi(imageNumberLast.substr(0, imageNumberLast.find(":")).c_str())-1 != atoi(checkPointDisplay.substr(checkPointDisplay.find(":")+1).c_str())){
                                    if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
                                    
                                    if (arrayQueueList [counter1*6] == treatmentNameHold){
                                        int *autoCheckTemp2 = new int [autoCheckTempCount+50];
                                        autoCheckTempCount2 = 0;
                                        
                                        startTimePoint = 0;
                                        xData1 = 0;
                                        yData1 = 0;
                                        startArea = 0;
                                        startIntensity = 0;
                                        
                                        lineageNoString = arrayQueueList [counter1*6+1].substr(1);
                                        cellNoString = arrayQueueList [counter1*6+2].substr(1);
                                        
                                        for (int counter2 = 0; counter2 < autoCheckTempCount/8; counter2++){
                                            if (autoCheckTemp [counter2*8+1] == atoi(lineageNoString.c_str()) && autoCheckTemp [counter2*8+2] == atoi(cellNoString.c_str())){
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+3], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+4], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+5], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+6], autoCheckTempCount2++;
                                                autoCheckTemp2 [autoCheckTempCount2] = autoCheckTemp [counter2*8+7], autoCheckTempCount2++;
                                                
                                                if (startTimePoint == 0){
                                                    startTimePoint = autoCheckTemp [counter2*8];
                                                    xData1 = autoCheckTemp [counter2*8+4];
                                                    yData1 = autoCheckTemp [counter2*8+5];
                                                    startArea = autoCheckTemp [counter2*8+6];
                                                    startIntensity = autoCheckTemp [counter2*8+7];
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < autoCheckTempCount2/6; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<autoCheckTemp2 [counterA*6+counterB];
                                        //    cout<<" autoCheckTemp2 "<<counterA<<endl;
                                        //}
                                        
                                        averageDistance = 0;
                                        areaCheckAverage = 0;
                                        intensityCheckAverage = 0;
                                        newCellStart = 0;
                                        
                                        if (atoi(checkPointDisplay.c_str())-startTimePoint > 5){
                                            totalDistance = 0;
                                            distanceCount = 0;
                                            xData1 = 0;
                                            yData1 = 0;
                                            areaCheckTotal = 0;
                                            intensityCheckTotal = 0;
                                            
                                            for (int counter2 = autoCheckTempCount2/6; counter2 >= 0; counter2--){
                                                if (autoCheckTemp2 [counter2*6] == atoi(checkPointDisplay.c_str())){
                                                    xData1 = autoCheckTemp2 [counter2*6+2];
                                                    yData1 = autoCheckTemp2 [counter2*6+3];
                                                }
                                                else if (xData1 != 0 && yData1 != 0 && distanceCount != 4){
                                                    totalDistance = totalDistance+sqrt((xData1-autoCheckTemp2 [counter2*6+2])*(xData1-autoCheckTemp2 [counter2*6+2])+(yData1-autoCheckTemp2 [counter2*6+3])*(yData1-autoCheckTemp2 [counter2*6+3]));
                                                    
                                                    areaCheckTotal = areaCheckTotal+autoCheckTemp2 [counter2*6+4];
                                                    intensityCheckTotal = intensityCheckTotal+autoCheckTemp2 [counter2*6+5];
                                                    
                                                    xData1 = autoCheckTemp2 [counter2*6+2];
                                                    yData1 = autoCheckTemp2 [counter2*6+3];
                                                    
                                                    distanceCount++;
                                                }
                                            }
                                            
                                            averageDistance = totalDistance/(double)4;
                                            areaCheckAverage = (int)(areaCheckTotal/(double)4);
                                            intensityCheckAverage = (int)(intensityCheckTotal/(double)4);
                                        }
                                        else if (autoCheckTempCount2/6 > 2){
                                            averageDistance = sqrt((xData1-autoCheckTemp2 [8])*(xData1-autoCheckTemp2 [8])+(yData1-autoCheckTemp2 [9])*(yData1-autoCheckTemp2 [9]));
                                            areaCheckAverage = startArea;
                                            intensityCheckAverage = startIntensity;
                                            newCellStart = 1;
                                        }
                                        
                                        statusCheckArea = 0;
                                        statusCheckXY = 0;
                                        xData1 = 0;
                                        yData1 = 0;
                                        
                                        for (int counter2 = 0; counter2 < autoCheckTempCount2/6; counter2++){
                                            if (autoCheckTemp2 [counter2*6] == atoi(checkPointDisplay.c_str())){
                                                xData1 = autoCheckTemp2 [counter2*6+2];
                                                yData1 = autoCheckTemp2 [counter2*6+3];
                                            }
                                            else if (xData1 != 0 && yData1 != 0){
                                                if (sqrt((xData1-autoCheckTemp2 [counter2*6+2])*(xData1-autoCheckTemp2 [counter2*6+2])+(yData1-autoCheckTemp2 [counter2*6+3])*(yData1-autoCheckTemp2 [counter2*6+3])) > averageDistance*autoCheckDistanceFoldHold && sqrt((xData1-autoCheckTemp2 [counter2*6+2])*(xData1-autoCheckTemp2 [counter2*6+2])+(yData1-autoCheckTemp2 [counter2*6+3])*(yData1-autoCheckTemp2 [counter2*6+3])) > autoCheckDistanceHold){ //=======Parameter
                                                    
                                                    statusCheckXY = autoCheckTemp2 [counter2*6];
                                                    break;
                                                }
                                                
                                                if (autoCheckTemp2 [counter2*6+4] > areaCheckAverage*autoCheckAreaHold){ //=======Parameter
                                                    statusCheckArea = autoCheckTemp2 [counter2*6];
                                                    break;
                                                }
                                                
                                                xData1 = autoCheckTemp2 [counter2*6+2];
                                                yData1 = autoCheckTemp2 [counter2*6+3];
                                            }
                                        }
                                        
                                        statusCheckDiv = 0;
                                        
                                        intensityCheckAverage = intensityCheckAverage+autoCheckIntensityHold;
                                        
                                        if (intensityCheckAverage >= 255) intensityCheckAverage = 255;
                                        
                                        if (autoCheckTempCount2/6 > autoCheckDivisionHold && autoCheckTempCount2/6-20 > 0){//=======Parameter
                                            for (int counter2 = autoCheckDivisionHold-20; counter2 < autoCheckTempCount2/6; counter2++){//=======Parameter
                                                if (autoCheckTemp2 [counter2*6+5] > intensityCheckAverage){
                                                    statusCheckDiv = autoCheckTemp2 [counter2*6];
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        checkTime = 0;
                                        
                                        if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv == 0) checkTime = statusCheckXY;
                                        else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv == 0) checkTime = statusCheckArea;
                                        else if (statusCheckXY == 0 && statusCheckArea == 0 && statusCheckDiv != 0) checkTime = statusCheckDiv;
                                        else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv == 0){
                                            if (statusCheckXY <= statusCheckArea) checkTime = statusCheckXY;
                                            else checkTime = statusCheckArea;
                                        }
                                        else if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv != 0){
                                            if (statusCheckXY <= statusCheckDiv) checkTime = statusCheckXY;
                                            else checkTime = statusCheckDiv;
                                        }
                                        else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv != 0){
                                            if (statusCheckArea <= statusCheckDiv) checkTime = statusCheckArea;
                                            else checkTime = statusCheckDiv;
                                        }
                                        else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv != 0){
                                            if (statusCheckXY <= statusCheckArea && statusCheckXY <= statusCheckDiv) checkTime = statusCheckXY;
                                            else if (statusCheckArea <= statusCheckXY && statusCheckArea <= statusCheckDiv) checkTime = statusCheckArea;
                                            else if (statusCheckDiv <= statusCheckXY && statusCheckDiv <= statusCheckArea) checkTime = statusCheckDiv;
                                        }
                                        
                                        if (checkTime != 0){
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+1], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+2], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = imageNumberLast.substr(0, imageNumberLast.find(":"))+":"+to_string(checkTime), queueListDisplayCount++;
                                            
                                            if (newCellStart == 0){
                                                if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv == 0) arrayQueueListDisplay [queueListDisplayCount] = "AX", queueListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayQueueListDisplay [queueListDisplayCount] = "AA", queueListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "AM", queueListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayQueueListDisplay [queueListDisplayCount] = "AXA", queueListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "AXM", queueListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "AAM", queueListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "AXAM", queueListDisplayCount++;
                                            }
                                            else{
                                                
                                                if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv == 0) arrayQueueListDisplay [queueListDisplayCount] = "BX", queueListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayQueueListDisplay [queueListDisplayCount] = "BA", queueListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "AM", queueListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv == 0) arrayQueueListDisplay [queueListDisplayCount] = "BXA", queueListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea == 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "BXM", queueListDisplayCount++;
                                                else if (statusCheckXY == 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "BAM", queueListDisplayCount++;
                                                else if (statusCheckXY != 0 && statusCheckArea != 0 && statusCheckDiv != 0) arrayQueueListDisplay [queueListDisplayCount] = "BXAM", queueListDisplayCount++;
                                            }
                                            
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+5], queueListDisplayCount++;
                                        }
                                        else{
                                            
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+1], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+2], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+3], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+4], queueListDisplayCount++;
                                            arrayQueueListDisplay [queueListDisplayCount] = arrayQueueList [counter1*6+5], queueListDisplayCount++;
                                        }
                                        
                                        delete [] autoCheckTemp2;
                                    }
                                }
                            }
                            
                            ofstream oin;
                            oin.open(autoCheckPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < autoCheckTempCount/8; counter1++){
                                oin<<autoCheckTemp [counter1*8]<<endl;
                                oin<<autoCheckTemp [counter1*8+1]<<endl;
                                oin<<autoCheckTemp [counter1*8+2]<<endl;
                                oin<<autoCheckTemp [counter1*8+3]<<endl;
                                oin<<autoCheckTemp [counter1*8+4]<<endl;
                                oin<<autoCheckTemp [counter1*8+5]<<endl;
                                oin<<autoCheckTemp [counter1*8+6]<<endl;
                                oin<<autoCheckTemp [counter1*8+7]<<endl;
                            }
                            
                            oin.close();
                            
                            autoCheckFlag = 1;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    string *arrayQueueListDisplayTemp = new string [queueListDisplayCount+10];
                    int arrayQueueListDisplayTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListDisplayCount/6; counter1++){
                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                            if (arrayQueueListDisplay [counter1*6] == arrayQueueList [counter2*6] && arrayQueueListDisplay [counter1*6+1] == arrayQueueList [counter2*6+1] && arrayQueueListDisplay [counter1*6+2] == arrayQueueList [counter2*6+2] && arrayQueueList [counter2*6+3].substr(arrayQueueList [counter2*6+3].find(":")+1).c_str() != arrayQueueList [counter2*6+3].substr(0, arrayQueueList [counter2*6+3].find(":"))){
                                arrayQueueListDisplayTemp [arrayQueueListDisplayTempCount] = arrayQueueListDisplay [counter1*6], arrayQueueListDisplayTempCount++;
                                arrayQueueListDisplayTemp [arrayQueueListDisplayTempCount] = arrayQueueListDisplay [counter1*6+1], arrayQueueListDisplayTempCount++;
                                arrayQueueListDisplayTemp [arrayQueueListDisplayTempCount] = arrayQueueListDisplay [counter1*6+2], arrayQueueListDisplayTempCount++;
                                arrayQueueListDisplayTemp [arrayQueueListDisplayTempCount] = arrayQueueListDisplay [counter1*6+3], arrayQueueListDisplayTempCount++;
                                arrayQueueListDisplayTemp [arrayQueueListDisplayTempCount] = arrayQueueListDisplay [counter1*6+4], arrayQueueListDisplayTempCount++;
                                arrayQueueListDisplayTemp [arrayQueueListDisplayTempCount] = arrayQueueListDisplay [counter1*6+5], arrayQueueListDisplayTempCount++;
                                break;
                            }
                        }
                    }
                    
                    queueListDisplayCount = 0;
                    
                    for (int counter1 = 0; counter1 < arrayQueueListDisplayTempCount; counter1++) arrayQueueListDisplay [queueListDisplayCount] = arrayQueueListDisplayTemp [counter1], queueListDisplayCount++;
                    
                    delete [] arrayQueueListDisplayTemp;
                }
                
                tableViewContent = queueListDisplayCount/6;
                
                progressTimingB = 3;
                
                [listTreatmentDisplay setStringValue:@"AU"];
            }
        }
        else if (tableListSwitch == 3){
            if (lineageCellSwitch == 1){
                tableViewContent = cellLineageInfoCount/3;
                [listName setStringValue:@"Lineage List"];
                [listTreatmentDisplay setStringValue:@(treatmentNameHold.c_str())];
            }
            else if (lineageCellSwitch == 2){
                tableViewContent = cellNumberInfoCount/7;
                [listName setStringValue:@"Cell No List"];
                [listTreatmentDisplay setStringValue:@""];
            }
            else{
                
                tableViewContent = 0;
                [listName setStringValue:@"None"];
                [listTreatmentDisplay setStringValue:@""];
            }
        }
    }
    
    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
    //	cout<<" arrayQueueList "<<counterA<<endl;
    //}
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (tableDataSetDone == 2 || tableTrackingProcessing == 2){
        if (listSwitchCall == 1 && tableDataSetDone == 2){
            int statusData = arrayTimeSelected [rowIndex*10];
            int vectorNumber = arrayGravityCenterRev [rowIndex*6+4];
            int xPosition = arrayGravityCenterRev [rowIndex*6];
            int yPosition = arrayGravityCenterRev [rowIndex*6+1];
            
            string xyPosition = "";
            string extension = "";
            string extension2 = "";
            
            extension = to_string(xPosition);
            extension2 = to_string(yPosition);
            
            xyPosition = xyPosition+"X-"+extension+" Y-"+extension2;
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 1){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && (statusData == 0 || statusData == 5 || statusData == 6)){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && (statusData == 3 || statusData == 4)){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 7){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 2){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 1){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(xyPosition.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && (statusData == 0 || statusData == 5 || statusData == 6)){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(xyPosition.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && (statusData == 3 || statusData == 4)){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(xyPosition.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 7){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(xyPosition.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 2){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(xyPosition.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 1){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Track" attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && (statusData == 0 || statusData == 5 || statusData == 6)){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Non-Track" attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && (statusData == 3 || statusData == 4)){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Deleted" attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 7){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Cell Conf." attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 2){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Noise" attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else if (listSwitchCall == 1 && tableTrackingProcessing == 2){
            int statusData = arrayConnectLineageRel [rowIndex*6+4];
            int lineageNoRel = arrayConnectLineageRel [rowIndex*6];
            int cellNumberRel = arrayConnectLineageRel [rowIndex*6+3];
            int vectorNumber = arrayConnectLineageRel [rowIndex*6+1];
            
            string extension = "";
            string extension2 = "";
            string lineageCellInfo;
            
            extension = to_string(cellNumberRel);
            extension2 = to_string(lineageNoRel);
            
            if (cellNumberRel >= 0){
                if (extension.length() == 1) extension = "C00000000"+extension;
                else if (extension.length() == 2) extension = "C0000000"+extension;
                else if (extension.length() == 3) extension = "C000000"+extension;
                else if (extension.length() == 4) extension = "C00000"+extension;
                else if (extension.length() == 5) extension = "C0000"+extension;
                else if (extension.length() == 6) extension = "C000"+extension;
                else if (extension.length() == 7) extension = "C00"+extension;
                else if (extension.length() == 8) extension = "C0"+extension;
                else if (extension.length() == 9) extension = "C"+extension;
            }
            else{
                
                extension = extension.substr(1);
                
                if (extension.length() == 1) extension = "C-00000000"+extension;
                else if (extension.length() == 2) extension = "C-0000000"+extension;
                else if (extension.length() == 3) extension = "C-000000"+extension;
                else if (extension.length() == 4) extension = "C-00000"+extension;
                else if (extension.length() == 5) extension = "C-0000"+extension;
                else if (extension.length() == 6) extension = "C-000"+extension;
                else if (extension.length() == 7) extension = "C-00"+extension;
                else if (extension.length() == 8) extension = "C-0"+extension;
                else if (extension.length() == 9) extension = "C-"+extension;
            }
            
            if (extension2.length() == 1) extension2 = "L0000"+extension2;
            else if (extension2.length() == 2) extension2 = "L000"+extension2;
            else if (extension2.length() == 3) extension2 = "L00"+extension2;
            else if (extension2.length() == 4) extension2 = "L0"+extension2;
            else if (extension2.length() == 5) extension2 = "L"+extension2;
            
            if (statusData == 1) lineageCellInfo = extension2+": Tag";
            else if (statusData == 0) lineageCellInfo = extension2+": Non";
            else if (statusData == 2) lineageCellInfo = extension2+": Dmy";
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 2){
                [attributes setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 2){
                [attributes setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"N_Entry" attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(lineageCellInfo.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(lineageCellInfo.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 2){
                [attributes setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(lineageCellInfo.c_str()) attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else if (listSwitchCall == 2){
            int statusData = arrayTargetHoldInfo [rowIndex*4+2];
            int vectorNumber = arrayTargetHoldInfo [rowIndex*4+3];
            int xPosition = arrayTargetHoldInfo [rowIndex*4];
            int yPosition = arrayTargetHoldInfo [rowIndex*4+1];
            
            string extension = to_string(xPosition);
            string extension2 = to_string(yPosition);
            string xyPosition = "X-"+extension+" Y-"+extension2;
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:[NSString stringWithFormat:@"%d", vectorNumber] attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(xyPosition.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Line" attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 1){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@"Circle" attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else{
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
    }
    else if (trackingTableSetDone == 2){
        if (tableListSwitch == 1 && doneListDisplayCount/5 > rowIndex){
            string cellTreatmentDisplay = arrayDoneListDisplay [rowIndex*5];
            string cellLineageDisplay = arrayDoneListDisplay [rowIndex*5+1];
            string cellNumberDisplay = arrayDoneListDisplay [rowIndex*5+2];
            string imageNumberDisplay = arrayDoneListDisplay [rowIndex*5+3];
            
            string imageNumberLast = arrayDoneListDisplay [rowIndex*5+3];
            if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
            
            string checkPointDisplay = arrayDoneListDisplay [rowIndex*5+3];
            if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
            
            string doneStatusDisplay = arrayDoneListDisplay [rowIndex*5+4];
            
            cellLineageDisplay = cellLineageDisplay.substr(1);
            cellLineageDisplay = "L"+cellLineageDisplay;
            
            int checkPointMark = 0;
            
            if (atoi(imageNumberLast.c_str()) > atoi(checkPointDisplay.c_str())) checkPointMark = 1;
            
            int statusData = 0;
            
            if (doneStatusDisplay != "OK" && doneStatusDisplay != "OK/e") statusData = 1;
            else statusData = 0;
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 0 && checkPointMark == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 1 && checkPointMark == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && checkPointMark == 1){
                [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellTreatmentDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellTreatmentDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusData == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(doneStatusDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusData == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(doneStatusDisplay.c_str()) attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else if (tableListSwitch == 2 && queueListDisplayCount/6 > rowIndex){
            string cellTreatmentDisplay = arrayQueueListDisplay [rowIndex*6];
            string cellLineageDisplay = arrayQueueListDisplay [rowIndex*6+1];
            string cellNumberDisplay = arrayQueueListDisplay [rowIndex*6+2];
            string imageNumberDisplay = arrayQueueListDisplay [rowIndex*6+3];
            
            string imageNumberLast = arrayQueueListDisplay [rowIndex*6+3];
            if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
            
            string checkPointDisplay = arrayQueueListDisplay [rowIndex*6+3];
            if ((int)checkPointDisplay.find(":") != -1) checkPointDisplay = checkPointDisplay.substr(checkPointDisplay.find(":")+1);
            
            string endCheckDisplay = arrayQueueListDisplay [rowIndex*6+4];
            string processingStatusDisplay = arrayQueueListDisplay [rowIndex*6+5];
            
            cellLineageDisplay = cellLineageDisplay.substr(1);
            cellLineageDisplay = "L"+cellLineageDisplay;
            
            int statusData = 0;
            
            if (processingStatusDisplay == "Proc") statusData = 1;
            else if (processingStatusDisplay == "Wait" || processingStatusDisplay == "Redo") statusData = 0;
            else if (processingStatusDisplay == "End") statusData = 3;
            else statusData = 0;
            
            if (processingStatusDisplay == "Proc") endCheckDisplay = "Proc";
            else if (processingStatusDisplay == "Redo") endCheckDisplay = "Redo";
            
            int checkPointMark = 0;
            
            if (atoi(imageNumberLast.c_str()) >  atoi(checkPointDisplay.c_str())) checkPointMark = 1;
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 0 && checkPointMark == 0){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 1 && checkPointMark == 0){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 3 && checkPointMark == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && checkPointMark == 1){
                [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(imageNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 0){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellTreatmentDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellTreatmentDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 3){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellTreatmentDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 0){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 3){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusData == 0){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusData == 3){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellNumberDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusData == 0){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(endCheckDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusData == 1){
                [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(endCheckDisplay.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusData == 3){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(endCheckDisplay.c_str()) attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else if (tableListSwitch == 3 && lineageCellSwitch == 2 && cellNumberInfoCount/7 > rowIndex){
            int cellNumberDisplayInt = arrayCellNumberInfo [rowIndex*7];
            int cellStartingTime = arrayCellNumberInfo [rowIndex*7+1];
            int cellEndTime = arrayCellNumberInfo [rowIndex*7+2];
            int cellStartingStatus = arrayCellNumberInfo [rowIndex*7+3];
            int cellEndStatus = arrayCellNumberInfo [rowIndex*7+4];
            int checkStatus = arrayCellNumberInfo [rowIndex*7+5];
            int statusData = 1;
            
            int numberOfParent = -1;
            int numberOfSibling1 = -1;
            int numberOfSibling2 = -1;
            int numberOfSibling3 = -1;
            int numberOfProgeny1 = -1;
            int numberOfProgeny2 = -1;
            int numberOfProgeny3 = -1;
            int numberOfProgeny4 = -1;
            int siblingEntryCount = 0;
            int progenyEntryCount = 0;
            
            if (cellLineageNoHold != "" && cellNoHold != ""){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                string cellNoExtract = cellNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                int cellAmendTemp = atoi(cellNoExtract.c_str());
                
                //-----Lineage Start-----
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                        if (cellAmendTemp != 0){
                            numberOfParent = arrayLineageData [arrayLineageStartEnd [counter1*8+4]*8+4];
                            break;
                        }
                    }
                }
                
                int lineageEntryStart = 0;
                
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                        lineageEntryStart = arrayLineageStartEnd [counter1*8+4];
                        
                        if (numberOfParent == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && siblingEntryCount == 0) numberOfSibling1 = arrayLineageData [lineageEntryStart*8+5], siblingEntryCount++;
                        else if (numberOfParent == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && siblingEntryCount == 1) numberOfSibling2 = arrayLineageData [lineageEntryStart*8+5], siblingEntryCount++;
                        else if (numberOfParent == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && siblingEntryCount == 2) numberOfSibling3 = arrayLineageData [lineageEntryStart*8+5], siblingEntryCount++;
                        
                        if (cellAmendTemp == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && progenyEntryCount == 0) numberOfProgeny1 = arrayLineageData [lineageEntryStart*8+5], progenyEntryCount++;
                        else if (cellAmendTemp == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && progenyEntryCount == 1) numberOfProgeny2 = arrayLineageData [lineageEntryStart*8+5], progenyEntryCount++;
                        else if (cellAmendTemp == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && progenyEntryCount == 2) numberOfProgeny3 = arrayLineageData [lineageEntryStart*8+5], progenyEntryCount++;
                        else if (cellAmendTemp == arrayLineageData [lineageEntryStart*8+4] && arrayLineageData [lineageEntryStart*8+5] != cellAmendTemp && progenyEntryCount == 3) numberOfProgeny4 = arrayLineageData [lineageEntryStart*8+5], progenyEntryCount++;
                    }
                }
            }
            
            int statusCol1 = 0;
            
            if (cellNumberDisplayInt == numberOfSibling1 || cellNumberDisplayInt == numberOfSibling2 || cellNumberDisplayInt == numberOfSibling3) statusCol1 = 1;
            if (cellNumberDisplayInt == numberOfProgeny1 || cellNumberDisplayInt == numberOfProgeny2 || cellNumberDisplayInt == numberOfProgeny3 || cellNumberDisplayInt == numberOfProgeny4) statusCol1 = 2;
            if (cellNumberDisplayInt == numberOfParent) statusCol1 = 3;
            
            //cout<<rowIndex<<" "<<cellNumberDisplayInt<<" "<<cellStartingTime<<" "<<cellEndTime<<" "<<cellStartingStatus<<" "<<cellEndStatus<<" "<<checkStatus<<" INFO"<<endl;
            
            //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
            //	cout<<" arrayCellNumberInfo "<<counterA<<endl;
            //}
            
            string cellStartingTemp = "";
            string cellEndTemp = "";
            string completionStatus = "";
            string checkStatusTemp = "";
            string extension;
            string extension2;
            
            extension = to_string(cellNumberDisplayInt);
            extension2 = to_string(cellStartingTime);
            
            if (cellStartingStatus == 1) cellStartingTemp = "IN";
            else if (cellStartingStatus == 3) cellStartingTemp = "BD";
            else if (cellStartingStatus == 4) cellStartingTemp = "TD";
            else if (cellStartingStatus == 5) cellStartingTemp = "HD";
            else if (cellStartingStatus == 7) cellStartingTemp = "FU";
            
            if (cellEndStatus == 0) cellEndTemp = "OP";
            else if (cellEndStatus == 3) cellEndTemp = "BD";
            else if (cellEndStatus == 4) cellEndTemp = "TD";
            else if (cellEndStatus == 5) cellEndTemp = "HD";
            else if (cellEndStatus == 6) cellEndTemp = "CD";
            else if (cellEndStatus == 7) cellEndTemp = "FU";
            else if (cellEndStatus == 9) cellEndTemp = "OF";
            else if (cellEndStatus == 10) cellEndTemp = "EF";
            
            if (cellEndTime == -1) completionStatus = "OP";
            else if (cellEndTime > 0) completionStatus = "CL";
            
            if (checkStatus == 21) checkStatusTemp = "TD";
            else if (checkStatus == 22) checkStatusTemp = "HD";
            else if (checkStatus == 23) checkStatusTemp = "MD";
            else if (checkStatus == 24) checkStatusTemp = "NS";
            else if (checkStatus == 25) checkStatusTemp = "IP";
            else if (checkStatus == 26) checkStatusTemp = "MC";
            else if (checkStatus == 27) checkStatusTemp = "AC";
            else if (checkStatus == 28) checkStatusTemp = "DB";
            else if (checkStatus == 29) checkStatusTemp = "RC";
            else if (checkStatus == 30) checkStatusTemp = "SC";
            else if (checkStatus == 31) checkStatusTemp = "CM";
            else if (checkStatus == 32) checkStatusTemp = "CN";
            else if (checkStatus == 33) checkStatusTemp = "FM";
            else if (checkStatus == 34) checkStatusTemp = "TL";
            else if (checkStatus == 35) checkStatusTemp = "FE";
            else if (checkStatus == 36) checkStatusTemp = "FO";
            else if (checkStatus == 37) checkStatusTemp = "MF";
            else if (checkStatus == 38) checkStatusTemp = "NM";
            else if (checkStatus == 39) checkStatusTemp = "DL";
            else if (checkStatus == 40) checkStatusTemp = "OF";
            else if (checkStatus == 41) checkStatusTemp = "FC";
            else if (checkStatus == 42) checkStatusTemp = "ME";
            else if (checkStatus == 43) checkStatusTemp = "CF";
            else if (checkStatus == 44) checkStatusTemp = "XS";
            else if (checkStatus == 45) checkStatusTemp = "AM";
            else if (checkStatus == 46) checkStatusTemp = "CL";
            else if (checkStatus == 47) checkStatusTemp = "FP";
            else if (checkStatus == 0) checkStatusTemp = "OK";
            else if (checkStatus == 51) checkStatusTemp = "TD/m";
            else if (checkStatus == 52) checkStatusTemp = "HD/m";
            else if (checkStatus == 53) checkStatusTemp = "MD/m";
            else if (checkStatus == 54) checkStatusTemp = "NS/m";
            else if (checkStatus == 55) checkStatusTemp = "IP/m";
            else if (checkStatus == 56) checkStatusTemp = "MC/m";
            else if (checkStatus == 57) checkStatusTemp = "AC/m";
            else if (checkStatus == 58) checkStatusTemp = "DB/m";
            else if (checkStatus == 59) checkStatusTemp = "RC/m";
            else if (checkStatus == 60) checkStatusTemp = "SC/m";
            else if (checkStatus == 61) checkStatusTemp = "CM/m";
            else if (checkStatus == 62) checkStatusTemp = "CN/m";
            else if (checkStatus == 63) checkStatusTemp = "FM/m";
            else if (checkStatus == 64) checkStatusTemp = "TL/m";
            else if (checkStatus == 65) checkStatusTemp = "FE/m";
            else if (checkStatus == 66) checkStatusTemp = "FO/m";
            else if (checkStatus == 67) checkStatusTemp = "MF/m";
            else if (checkStatus == 68) checkStatusTemp = "NM/m";
            else if (checkStatus == 69) checkStatusTemp = "DL/m";
            else if (checkStatus == 70) checkStatusTemp = "OF/m";
            else if (checkStatus == 71) checkStatusTemp = "FC/m";
            else if (checkStatus == 72) checkStatusTemp = "ME/m";
            else if (checkStatus == 73) checkStatusTemp = "CF/m";
            else if (checkStatus == 74) checkStatusTemp = "XS/m";
            else if (checkStatus == 75) checkStatusTemp = "AM/m";
            else if (checkStatus == 76) checkStatusTemp = "CL/m";
            else if (checkStatus == 78) checkStatusTemp = "FP/m";
            else if (checkStatus == 77) checkStatusTemp = "OK/m";
            
            if (completionStatus == "CL" && checkStatusTemp == "None") statusData = 1;
            else if (completionStatus == "CL" && checkStatusTemp != "None") statusData = 2;
            else if (completionStatus == "OP" && checkStatusTemp == "None") statusData = 0;
            else if (completionStatus == "OP" && checkStatusTemp != "None") statusData = 2;
            
            completionStatus = completionStatus+": "+cellStartingTemp+"-"+cellEndTemp;
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 0 && statusCol1 == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(checkStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 1 && statusCol1 == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(checkStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusData == 2 && statusCol1 == 0){
                [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(checkStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusCol1 == 1 && statusCol1 != 0){
                [attributes setObject:[NSColor cyanColor] forKey: NSForegroundColorAttributeName];
                [attributes setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(checkStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusCol1 == 2 && statusCol1 != 0){
                [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                [attributes setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(checkStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusCol1 == 3 && statusCol1 != 0){
                [attributes setObject:[NSColor whiteColor] forKey: NSForegroundColorAttributeName];
                [attributes setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(checkStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusData == 2){
                [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 0){
                [attributes setObject:[NSColor purpleColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(completionStatus.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 1){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(completionStatus.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusData == 2){
                [attributes setObject:[NSColor redColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(completionStatus.c_str()) attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else if (tableListSwitch == 3 && lineageCellSwitch == 1 && cellLineageInfoCount/3 > rowIndex){
            int cellLineageInt = arrayCellLineageInfo [rowIndex*3];
            int cellStatusInt = arrayCellLineageInfo [rowIndex*3+1];
            int cellContent = arrayCellLineageInfo [rowIndex*3+2];
            int fusionCellLineage = 0;
            string cellLineageStatusTemp = "";
            
            int *fusedLineage = new int [imageEndHold+5];
            int fusedLineageCount = 0;
            
            if (cellLineageNoHold != ""){
                string cellLineageExtract = cellLineageNoHold.substr(1);
                int lineageAmendTemp = atoi(cellLineageExtract.c_str());
                
                //-----Lineage Start-----
                for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                    if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp){
                        for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                            if (arrayLineageData [counter2*8+7] != 0 && arrayLineageData [counter2*8+7] != lineageAmendTemp){
                                fusedLineage [fusedLineageCount] = arrayLineageData [counter2*8+7], fusedLineageCount++;
                            }
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < fusedLineageCount; counter1++){
                    if (fusedLineage [counter1] == cellLineageInt){
                        fusionCellLineage = 1;
                        break;
                    }
                }
            }
            
            delete [] fusedLineage;
            
            string extension;
            string extension2;
            
            if (fusionCellLineage == 0) extension = to_string(cellLineageInt);
            else extension = "F"+to_string(cellLineageInt);
            
            extension2 = "Cells: "+to_string(cellContent);
            
            if (cellStatusInt == 0) cellLineageStatusTemp = "Open";
            else if (cellStatusInt == 1) cellLineageStatusTemp = "Comp";
            else if (cellStatusInt == 2) cellLineageStatusTemp = "OpenGb";
            else if (cellStatusInt == 3) cellLineageStatusTemp = "CompGb";
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"] && cellStatusInt == 1){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && cellStatusInt == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && (cellStatusInt == 2 || cellStatusInt == 3)){
                [attributes setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && cellStatusInt == 1){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && cellStatusInt == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && (cellStatusInt == 2 || cellStatusInt == 3)){
                [attributes setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(cellLineageStatusTemp.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && cellStatusInt == 1){
                [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension2.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && cellStatusInt == 0){
                [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension2.c_str()) attributes:attributes];
            }
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && (cellStatusInt == 2 || cellStatusInt == 3)){
                [attributes setObject:[NSColor orangeColor] forKey: NSForegroundColorAttributeName];
                attrStr = [[NSAttributedString alloc] initWithString:@(extension2.c_str()) attributes:attributes];
            }
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
        else{
            
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
            
            if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
            else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
            else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
            else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
        }
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    tableNewRowHold = rowIndex;
    
    //cout<<trackingImageLock<<" "<<tableCallCount<<" "<<listSwitchCall<<" "<<tableListSwitch<<" "<<trackingOn<<" Info"<<endl;
    
    if (trackingImageLock == 0 && (tableCallCount == 1 || tableCallCount == 2)){
        if (listSwitchCall == 1 && trackingOn == 2){
            int timeOneXTemp;
            int timeOneYTemp;
            int connectNoTemp;
            
            if (tableCallCount == 2){
                tableRowHold = rowIndex;
                timeOneXTemp = arrayGravityCenterRev [tableCurrentRowHold*6];
                timeOneYTemp = arrayGravityCenterRev [tableCurrentRowHold*6+1];
                connectNoTemp = arrayGravityCenterRev [tableCurrentRowHold*6+4];
            }
            else{
                
                tableRowHold = rowIndex;
                timeOneXTemp = arrayGravityCenterRev [rowIndex*6];
                timeOneYTemp = arrayGravityCenterRev [rowIndex*6+1];
                connectNoTemp = arrayGravityCenterRev [rowIndex*6+4];
            }
            
            if (arrayTimeSelected [(connectNoTemp-1)*10] != 3 && arrayTimeSelected [(connectNoTemp-1)*10] != 4){
                timeOneX = timeOneXTemp;
                timeOneY = timeOneYTemp;
            }
            
            errorInfoFlag = "nil";
        }
        
        if (listSwitchCall == 2 && trackingOn == 2){
            if (tableCallCount == 2){
                tableRowHold = rowIndex;
                timeOneX = arrayTargetHoldInfo [tableCurrentRowHold*4];
                timeOneY = arrayTargetHoldInfo [tableCurrentRowHold*4+1];
            }
            else{
                
                tableRowHold = rowIndex;
                timeOneX = arrayTargetHoldInfo [rowIndex*4];
                timeOneY = arrayTargetHoldInfo [rowIndex*4+1];
            }
            
            errorInfoFlag = "nil";
        }
        
        if (tableListSwitch == 1 && trackingOn == 1){
            string treatmentNameStringTemp;
            string cellLineageStringTemp;
            string cellNumberStringTemp;
            
            if (tableCallCount == 2){
                treatmentNameStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5];
                cellLineageStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5+1];
                cellNumberStringTemp = arrayDoneListDisplay [tableCurrentRowHold*5+2];
            }
            else{
                
                treatmentNameStringTemp = arrayDoneListDisplay [rowIndex*5];
                cellLineageStringTemp = arrayDoneListDisplay [rowIndex*5+1];
                cellNumberStringTemp = arrayDoneListDisplay [rowIndex*5+2];
            }
            
            int fileCheck = 0;
            
            ifstream fin;
            
            string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
            string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
            string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
            
            fin.open(connectDataPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectStartEndPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            if (fileCheck == 4){
                string imageNumberLast = "";
                string imageCheckTime = "";
                string treatmentNameHoldPrev = treatmentNameHold;
                
                if (tableCallCount == 2){
                    treatmentNameHold = arrayDoneListDisplay [tableCurrentRowHold*5];
                    cellLineageNoHold = arrayDoneListDisplay [tableCurrentRowHold*5+1];
                    cellNoHold = arrayDoneListDisplay [tableCurrentRowHold*5+2];
                    
                    imageNumberLast = arrayDoneListDisplay [tableCurrentRowHold*5+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    imageCheckTime = arrayDoneListDisplay [tableCurrentRowHold*5+3];
                    if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                    
                    if (imageReturnPosition == 0 && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AX" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AXA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AXM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AAM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "AXAM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BX" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BXA" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BXM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BAM" && arrayDoneListDisplay [tableCurrentRowHold*5+4] != "BXAM"){
                        imageNumber = atoi(imageNumberLast.c_str());
                        imageReturnPositionSet = 1;
                    }
                    else{
                        
                        imageNumber = atoi(imageCheckTime.c_str());
                        imageReturnPositionSet = 2;
                    }
                    
                    errorInfoFlag = arrayDoneListDisplay [tableCurrentRowHold*5+4];
                    tableRowHold = tableCurrentRowHold;
                }
                else{
                    
                    treatmentNameHold = arrayDoneListDisplay [rowIndex*5];
                    cellLineageNoHold = arrayDoneListDisplay [rowIndex*5+1];
                    cellNoHold = arrayDoneListDisplay [rowIndex*5+2];
                    
                    imageNumberLast = arrayDoneListDisplay [rowIndex*5+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    imageCheckTime = arrayDoneListDisplay [rowIndex*5+3];
                    if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                    
                    if (imageReturnPosition == 0 && arrayDoneListDisplay [rowIndex*5+4] != "AX" && arrayDoneListDisplay [rowIndex*5+4] != "AA" && arrayDoneListDisplay [rowIndex*5+4] != "AM" && arrayDoneListDisplay [rowIndex*5+4] != "AXA" && arrayDoneListDisplay [rowIndex*5+4] != "AXM" && arrayDoneListDisplay [rowIndex*5+4] != "AAM" && arrayDoneListDisplay [rowIndex*5+4] != "AXAM" && arrayDoneListDisplay [rowIndex*5+4] != "BX" && arrayDoneListDisplay [rowIndex*5+4] != "BA" && arrayDoneListDisplay [rowIndex*5+4] != "BM" && arrayDoneListDisplay [rowIndex*5+4] != "BXA" && arrayDoneListDisplay [rowIndex*5+4] != "BXM" && arrayDoneListDisplay [rowIndex*5+4] != "BAM" && arrayDoneListDisplay [rowIndex*5+4] != "BXAM"){
                        imageNumber = atoi(imageNumberLast.c_str());
                        imageReturnPositionSet = 1;
                    }
                    else{
                        
                        imageNumber = atoi(imageCheckTime.c_str());
                        imageReturnPositionSet = 2;
                    }
                    
                    errorInfoFlag = arrayDoneListDisplay [rowIndex*5+4];
                    tableRowHold = rowIndex;
                }
                
                //cout<<treatmentNameHold<<" "<<cellLineageNoHold<<" "<<cellNoHold<<" "<<imageNumber<<" " <<imageReturnPositionSet<<"  Data"<<endl;
                
                [treatmentDisplay setStringValue: @(treatmentNameHold.c_str())];
                [cellLineageNoDisplay setStringValue: @(cellLineageNoHold.c_str())];
                [cellNoDisplay setStringValue: @(cellNoHold.c_str())];
                
                int errorCheck = 0;
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                saveInfo = treatmentNameStringTemp;
                
                dataSaveRead = [[DataSaveRead alloc] init];
                errorCheck = [dataSaveRead lineageDataRead];
                
                if (errorCheck == 0){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (cellLineageInfoStatus == 0){
                        arrayCellLineageInfo = new int [sizeForCopy*2+50];
                        cellLineageInfoLimit = (int)sizeForCopy*2+50;
                        cellLineageInfoStatus = 1;
                    }
                    else if (sizeForCopy*2 > cellLineageInfoCount){
                        delete [] arrayCellLineageInfo;
                        arrayCellLineageInfo = new int [sizeForCopy*2+50];
                        cellLineageInfoLimit = (int)sizeForCopy*2+50;
                    }
                    
                    cellLineageInfoCount = 0;
                    
                    fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End") arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++, dataString = "";
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                    //    cout<<" arrayCellLineageInfo "<<counterA<<endl;
                    //}
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (lineageStartEndStatus == 0){
                        arrayLineageStartEnd = new int [sizeForCopy+50];
                        lineageStartEndLimit = (int)sizeForCopy+50;
                        lineageStartEndStatus = 1;
                    }
                    else if (sizeForCopy > lineageStartEndCount){
                        delete [] arrayLineageStartEnd;
                        arrayLineageStartEnd = new int [sizeForCopy+50];
                        lineageStartEndLimit = (int)sizeForCopy+50;
                    }
                    
                    lineageStartEndCount = 0;
                    
                    fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                    arrayCellNumberInfo = new int [sizeForCopy*2+50];
                    cellNumberInfoCount = 0;
                    cellNumberInfoLimit = (int)sizeForCopy*2+50;
                    cellNumberInfoStatus = 1;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    if (seqOpenFlag == 1 && imageSeqOperation == 1){
                        seqImageFirst = 0;
                        seqImageLast = atoi(imageNumberLast.c_str());
                        seqImageCheck = atoi(imageCheckTime.c_str());
                        seqImageMitosis = 0;
                        seqImageFusionMark = 0;
                        seqImageTop = atoi(imageCheckTime.c_str());
                        
                        seqImageNoSet1 = 0;
                        seqImageNoSet2 = 0;
                        seqImageNoSet3 = 0;
                        seqImageNoSet4 = 0;
                        seqImageNoSet5 = 0;
                        seqImageNoSet6 = 0;
                        seqImageNoSet7 = 0;
                        seqImageNoSet8 = 0;
                        seqImageNoSet9 = 0;
                        seqImageNoSet10 = 0;
                    }
                    
                    listCrickMonitor = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Lineage Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                
                //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
                //    cout<<" arrayLineageStartEnd "<<counterA<<endl;
                //}
            }
        }
        
        if (tableListSwitch == 2 && trackingOn == 1){
            string treatmentNameStringTemp;
            string cellLineageStringTemp;
            string cellNumberStringTemp;
            
            if (tableCallCount == 2){
                treatmentNameStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6];
                cellLineageStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                cellNumberStringTemp = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                tableRowHold = tableCurrentRowHold;
            }
            else{
                
                treatmentNameStringTemp = arrayQueueListDisplay [rowIndex*6];
                cellLineageStringTemp = arrayQueueListDisplay [rowIndex*6+1];
                cellNumberStringTemp = arrayQueueListDisplay [rowIndex*6+2];
                tableRowHold = rowIndex;
            }
            
            int fileCheck = 0;
            
            ifstream fin;
            
            string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
            string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
            string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
            
            fin.open(connectDataPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            string imageNumberLast = "";
            string imageCheckTime = "";
            
            if (fileCheck == 4){
                string treatmentNameHoldPrev = treatmentNameHold;
                
                if (tableCallCount == 2){
                    treatmentNameHold = arrayQueueListDisplay [tableCurrentRowHold*6];
                    cellLineageNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+1];
                    cellNoHold = arrayQueueListDisplay [tableCurrentRowHold*6+2];
                    
                    imageNumberLast = arrayQueueListDisplay [tableCurrentRowHold*6+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    imageCheckTime = arrayQueueListDisplay [tableCurrentRowHold*6+3];
                    if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                    
                    if (imageReturnPosition == 0 && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AX" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AXA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AXM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AAM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "AXAM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BX" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BXA" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BXM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BAM" && arrayQueueListDisplay [tableCurrentRowHold*6+4] != "BXAM"){
                        imageNumber = atoi(imageNumberLast.c_str());
                        imageReturnPositionSet = 1;
                    }
                    else{
                        
                        imageNumber = atoi(imageCheckTime.c_str());
                        imageReturnPositionSet = 2;
                    }
                }
                else{
                    
                    treatmentNameHold = arrayQueueListDisplay [rowIndex*6];
                    cellLineageNoHold = arrayQueueListDisplay [rowIndex*6+1];
                    cellNoHold = arrayQueueListDisplay [rowIndex*6+2];
                    
                    imageNumberLast = arrayQueueListDisplay [rowIndex*6+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    imageCheckTime = arrayQueueListDisplay [rowIndex*6+3];
                    if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                    
                    if (imageReturnPosition == 0 && arrayQueueListDisplay [rowIndex*6+4] != "AX" && arrayQueueListDisplay [rowIndex*6+4] != "AA" && arrayQueueListDisplay [rowIndex*6+4] != "AM" && arrayQueueListDisplay [rowIndex*6+4] != "AXA" && arrayQueueListDisplay [rowIndex*6+4] != "AXM" && arrayQueueListDisplay [rowIndex*6+4] != "AAM" && arrayQueueListDisplay [rowIndex*6+4] != "AXAM" && arrayQueueListDisplay [rowIndex*6+4] != "BX" && arrayQueueListDisplay [rowIndex*6+4] != "BA" && arrayQueueListDisplay [rowIndex*6+4] != "BM" && arrayQueueListDisplay [rowIndex*6+4] != "BXA" && arrayQueueListDisplay [rowIndex*6+4] != "BXM" && arrayQueueListDisplay [rowIndex*6+4] != "BAM" && arrayQueueListDisplay [rowIndex*6+4] != "BXAM"){
                        imageNumber = atoi(imageNumberLast.c_str());
                        imageReturnPositionSet = 1;
                    }
                    else{
                        
                        imageNumber = atoi(imageCheckTime.c_str());
                        imageReturnPositionSet = 2;
                    }
                }
                
                [treatmentDisplay setStringValue: @(treatmentNameHold.c_str())];
                [cellLineageNoDisplay setStringValue: @(cellLineageNoHold.c_str())];
                [cellNoDisplay setStringValue: @(cellNoHold.c_str())];
                
                int errorCheck = 0;
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                saveInfo = treatmentNameStringTemp;
                
                dataSaveRead = [[DataSaveRead alloc] init];
                errorCheck = [dataSaveRead lineageDataRead];
                
                if (errorCheck == 0){
                    sizeForCopy = 0;
                    
                    if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (cellLineageInfoStatus == 0){
                        arrayCellLineageInfo = new int [sizeForCopy*2+50];
                        cellLineageInfoLimit = (int)sizeForCopy*2+50;
                        cellLineageInfoStatus = 1;
                    }
                    else if (sizeForCopy*2 > cellLineageInfoCount){
                        delete [] arrayCellLineageInfo;
                        arrayCellLineageInfo = new int [sizeForCopy*2+50];
                        cellLineageInfoLimit = (int)sizeForCopy*2+50;
                    }
                    
                    cellLineageInfoCount = 0;
                    
                    fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                    //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                    //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                    //}
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (lineageStartEndStatus == 0){
                        arrayLineageStartEnd = new int [sizeForCopy+50];
                        lineageStartEndLimit = (int)sizeForCopy+50;
                        lineageStartEndStatus = 1;
                    }
                    else if (sizeForCopy > lineageStartEndCount){
                        delete [] arrayLineageStartEnd;
                        arrayLineageStartEnd = new int [sizeForCopy+50];
                        lineageStartEndLimit = (int)sizeForCopy+50;
                    }
                    
                    lineageStartEndCount = 0;
                    
                    fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                    arrayCellNumberInfo = new int [sizeForCopy*2+50];
                    cellNumberInfoCount = 0;
                    cellNumberInfoLimit = (int)sizeForCopy*2+50;
                    cellNumberInfoStatus = 1;
                    
                    fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTemp = new char [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        string dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                            else if (dataString != "End"){
                                arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTemp;
                    }
                    
                    if (seqOpenFlag == 1 && imageSeqOperation == 1){
                        seqImageFirst = 0;
                        seqImageLast = atoi(imageNumberLast.c_str());
                        seqImageCheck = atoi(imageCheckTime.c_str());
                        seqImageMitosis = 0;
                        seqImageFusionMark = 0;
                        seqImageTop = atoi(imageCheckTime.c_str());
                        
                        seqImageNoSet1 = 0;
                        seqImageNoSet2 = 0;
                        seqImageNoSet3 = 0;
                        seqImageNoSet4 = 0;
                        seqImageNoSet5 = 0;
                        seqImageNoSet6 = 0;
                        seqImageNoSet7 = 0;
                        seqImageNoSet8 = 0;
                        seqImageNoSet9 = 0;
                        seqImageNoSet10 = 0;
                    }
                    
                    errorInfoFlag = "nil";
                    listCrickMonitor = 1;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Lineage Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        
        if (tableListSwitch == 3 && lineageCellSwitch == 1 && trackingOn == 1){
            string extension;
            
            if (tableCallCount == 2) extension = to_string(arrayCellLineageInfo [tableCurrentRowHold*3]);
            else extension = to_string(arrayCellLineageInfo [rowIndex*3]);
            
            if (extension.length() == 1) extension = "L0000"+extension;
            else if (extension.length() == 2) extension = "L000"+extension;
            else if (extension.length() == 3) extension = "L00"+extension;
            else if (extension.length() == 4) extension = "L0"+extension;
            else if (extension.length() == 5) extension = "L"+extension;
            
            [treatmentDisplay setStringValue: @(treatmentNameHold.c_str())];
            [cellLineageNoDisplay setStringValue: @(extension.c_str())];
            
            errorInfoFlag = "nil";
            
            cellLineageNoHold = extension;
            cellNoHold = "";
            
            listCrickMonitor = 1;
        }
        
        if (tableListSwitch == 3 && lineageCellSwitch == 2 && trackingOn == 1){
            string extension;
            
            if (tableCallCount == 2) extension = to_string(arrayCellNumberInfo [tableCurrentRowHold*7]);
            else extension = to_string(arrayCellNumberInfo [rowIndex*7]);
            
            if (arrayCellNumberInfo [rowIndex*7] >= 0){
                if (extension.length() == 1) extension = "C00000000"+extension;
                else if (extension.length() == 2) extension = "C0000000"+extension;
                else if (extension.length() == 3) extension = "C000000"+extension;
                else if (extension.length() == 4) extension = "C00000"+extension;
                else if (extension.length() == 5) extension = "C0000"+extension;
                else if (extension.length() == 6) extension = "C000"+extension;
                else if (extension.length() == 7) extension = "C00"+extension;
                else if (extension.length() == 8) extension = "C0"+extension;
                else if (extension.length() == 9) extension = "C"+extension;
            }
            else{
                
                extension = extension.substr(1);
                
                if (extension.length() == 1) extension = "C-00000000"+extension;
                else if (extension.length() == 2) extension = "C-0000000"+extension;
                else if (extension.length() == 3) extension = "C-000000"+extension;
                else if (extension.length() == 4) extension = "C-00000"+extension;
                else if (extension.length() == 5) extension = "C-0000"+extension;
                else if (extension.length() == 6) extension = "C-000"+extension;
                else if (extension.length() == 7) extension = "C-00"+extension;
                else if (extension.length() == 8) extension = "C-0"+extension;
                else if (extension.length() == 9) extension = "C-"+extension;
            }
            
            int errorNoTemp = 0;
            string extension2;
            
            if (tableCallCount == 2){
                extension2 = to_string(arrayCellNumberInfo [tableCurrentRowHold*7+6]);
                errorNoTemp = arrayCellNumberInfo [tableCurrentRowHold*7+5];
                imageNumber = arrayCellNumberInfo [tableCurrentRowHold*7+1];
                tableRowHold = tableCurrentRowHold;
            }
            else{
                
                extension2 = to_string(arrayCellNumberInfo [rowIndex*7+6]);
                errorNoTemp = arrayCellNumberInfo [rowIndex*7+5];
                imageNumber = arrayCellNumberInfo [rowIndex*7+1];
                tableRowHold = rowIndex;
            }
            
            if (errorNoTemp == 21) errorInfoFlag = "TD";
            else if (errorNoTemp == 22) errorInfoFlag = "HD";
            else if (errorNoTemp == 23) errorInfoFlag = "MD";
            else if (errorNoTemp == 24) errorInfoFlag = "NS";
            else if (errorNoTemp == 25) errorInfoFlag = "IP";
            else if (errorNoTemp == 26) errorInfoFlag = "MC";
            else if (errorNoTemp == 27) errorInfoFlag = "AC";
            else if (errorNoTemp == 28) errorInfoFlag = "DB";
            else if (errorNoTemp == 29) errorInfoFlag = "RC";
            else if (errorNoTemp == 30) errorInfoFlag = "SC";
            else if (errorNoTemp == 31) errorInfoFlag = "CM";
            else if (errorNoTemp == 32) errorInfoFlag = "CN";
            else if (errorNoTemp == 33) errorInfoFlag = "FM";
            else if (errorNoTemp == 34) errorInfoFlag = "TL";
            else if (errorNoTemp == 35) errorInfoFlag = "FE";
            else if (errorNoTemp == 36) errorInfoFlag = "FO";
            else if (errorNoTemp == 37) errorInfoFlag = "MF";
            else if (errorNoTemp == 38) errorInfoFlag = "NM";
            else if (errorNoTemp == 39) errorInfoFlag = "DL";
            else if (errorNoTemp == 40) errorInfoFlag = "OF";
            else if (errorNoTemp == 41) errorInfoFlag = "FC";
            else if (errorNoTemp == 42) errorInfoFlag = "ME";
            else if (errorNoTemp == 43) errorInfoFlag = "CF";
            else if (errorNoTemp == 44) errorInfoFlag = "XS";
            else if (errorNoTemp == 45) errorInfoFlag = "AM";
            else if (errorNoTemp == 46) errorInfoFlag = "CL";
            else if (errorNoTemp == 47) errorInfoFlag = "FP";
            else if (errorNoTemp == 0) errorInfoFlag = "OK";
            else if (errorNoTemp == 51) errorInfoFlag = "TD";
            else if (errorNoTemp == 52) errorInfoFlag = "HD";
            else if (errorNoTemp == 53) errorInfoFlag = "MD";
            else if (errorNoTemp == 54) errorInfoFlag = "NS";
            else if (errorNoTemp == 55) errorInfoFlag = "IP";
            else if (errorNoTemp == 56) errorInfoFlag = "MC";
            else if (errorNoTemp == 57) errorInfoFlag = "AC";
            else if (errorNoTemp == 58) errorInfoFlag = "DB";
            else if (errorNoTemp == 59) errorInfoFlag = "RC";
            else if (errorNoTemp == 60) errorInfoFlag = "SC";
            else if (errorNoTemp == 61) errorInfoFlag = "CM";
            else if (errorNoTemp == 62) errorInfoFlag = "CN";
            else if (errorNoTemp == 63) errorInfoFlag = "FM";
            else if (errorNoTemp == 64) errorInfoFlag = "TL";
            else if (errorNoTemp == 65) errorInfoFlag = "FE";
            else if (errorNoTemp == 66) errorInfoFlag = "FO";
            else if (errorNoTemp == 67) errorInfoFlag = "MF";
            else if (errorNoTemp == 68) errorInfoFlag = "NM";
            else if (errorNoTemp == 69) errorInfoFlag = "DL";
            else if (errorNoTemp == 70) errorInfoFlag = "OF";
            else if (errorNoTemp == 71) errorInfoFlag = "FC";
            else if (errorNoTemp == 72) errorInfoFlag = "ME";
            else if (errorNoTemp == 73) errorInfoFlag = "CF";
            else if (errorNoTemp == 74) errorInfoFlag = "XS";
            else if (errorNoTemp == 75) errorInfoFlag = "AM";
            else if (errorNoTemp == 76) errorInfoFlag = "CL";
            else if (errorNoTemp == 78) errorInfoFlag = "FP";
            else if (errorNoTemp == 77) errorInfoFlag = "OK";
            
            if (extension2.length() == 1) extension2 = "L0000"+extension2;
            else if (extension2.length() == 2) extension2 = "L000"+extension2;
            else if (extension2.length() == 3) extension2 = "L00"+extension2;
            else if (extension2.length() == 4) extension2 = "L0"+extension2;
            else if (extension2.length() == 5) extension2 = "L"+extension2;
            
            [treatmentDisplay setStringValue: @(treatmentNameHold.c_str())];
            [cellLineageNoDisplay setStringValue: @(cellLineageNoHold.c_str())];
            [cellNoDisplay setStringValue: @(extension.c_str())];
            
            cellLineageNoHold = extension2;
            cellNoHold = extension;
            
            int fileCheck = 0;
            
            ifstream fin;
            
            string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
            string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
            string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_CellStatus";
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
            
            fin.open(connectDataPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            if (fileCheck == 4){
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                arrayCellNumberInfo = new int [sizeForCopy*2+50];
                cellNumberInfoCount = 0;
                cellNumberInfoLimit = (int)sizeForCopy*2+50;
                cellNumberInfoStatus = 1;
                
                fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                //	cout<<" arrayCellNumberInfo "<<counterA<<endl;
                //}
                
                listCrickMonitor = 1;
            }
        }
    }
    
    if (trackingImageLock == 1 && tableCallCount == 1){
        if (listSwitchCall == 2 && trackingOn == 3){
            if (tableCallCount == 2) tableRowHold = tableCurrentRowHold;
            else tableRowHold = rowIndex;
        }
    }
    
    return YES;
}

-(void)listProcessQueueDone:(int)lineNumberList{
    string treatmentNameStringTemp = arrayListHold [lineNumberList*5];
    string cellLineageStringTemp = arrayListHold [lineNumberList*5+1];
    string cellNumberStringTemp = arrayListHold [lineNumberList*5+2];
    string queueDone = arrayListHold [lineNumberList*5+4];
    
    if (queueDone != "Queue"){
        int fileCheck = 0;
        
        ifstream fin;
        
        string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
        string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
        string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
        
        fin.open(connectDataPath.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        fin.open(connectDataStatus.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        fin.open(connectDataStatus2.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        fin.open(connectStartEndPath.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        if (fileCheck == 4){
            string imageNumberLast = "";
            string imageCheckTime = "";
            string treatmentNameHoldPrev = treatmentNameHold;
            
            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                if (arrayDoneList [counter1*5] == treatmentNameStringTemp && arrayDoneList [counter1*5+1] == cellLineageStringTemp && arrayDoneList [counter1*5+2] == cellNumberStringTemp){
                    treatmentNameHold = arrayDoneListDisplay [counter1*5];
                    cellLineageNoHold = arrayDoneListDisplay [counter1*5+1];
                    cellNoHold = arrayDoneListDisplay [counter1*5+2];
                    
                    imageNumberLast = arrayDoneListDisplay [counter1*5+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    imageCheckTime = arrayDoneListDisplay [counter1*5+3];
                    if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                    
                    if (imageReturnPosition == 0){
                        imageNumber = atoi(imageNumberLast.c_str());
                        imageReturnPositionSet = 1;
                    }
                    else{
                        
                        imageNumber = atoi(imageCheckTime.c_str());
                        imageReturnPositionSet = 2;
                    }
                    
                    errorInfoFlag = arrayDoneListDisplay [counter1*5+4];
                    
                    break;
                }
            }
            
            //cout<<treatmentNameHold<<" "<<cellLineageNoHold<<" "<<cellNoHold<<" "<<imageNumber<<" " <<imageReturnPositionSet<<"  Data"<<endl;
            
            [treatmentDisplay setStringValue: @(treatmentNameHold.c_str())];
            [cellLineageNoDisplay setStringValue: @(cellLineageNoHold.c_str())];
            [cellNoDisplay setStringValue: @(cellNoHold.c_str())];
            
            int errorCheck = 0;
            long sizeForCopy = 0;
            struct stat sizeOfFile;
            
            saveInfo = treatmentNameStringTemp;
            
            dataSaveRead = [[DataSaveRead alloc] init];
            errorCheck = [dataSaveRead lineageDataRead];
            
            if (errorCheck == 0){
                sizeForCopy = 0;
                
                if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellLineageInfoStatus == 0){
                    arrayCellLineageInfo = new int [sizeForCopy*2+50];
                    cellLineageInfoLimit = (int)sizeForCopy*2+50;
                    cellLineageInfoStatus = 1;
                }
                else if (sizeForCopy*2 > cellLineageInfoCount){
                    delete [] arrayCellLineageInfo;
                    arrayCellLineageInfo = new int [sizeForCopy*2+50];
                    cellLineageInfoLimit = (int)sizeForCopy*2+50;
                }
                
                cellLineageInfoCount = 0;
                
                fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End") arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++, dataString = "";
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                //}
                
                sizeForCopy = 0;
                
                if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (lineageStartEndStatus == 0){
                    arrayLineageStartEnd = new int [sizeForCopy+50];
                    lineageStartEndLimit = (int)sizeForCopy+50;
                    lineageStartEndStatus = 1;
                }
                else if (sizeForCopy > lineageStartEndCount){
                    delete [] arrayLineageStartEnd;
                    arrayLineageStartEnd = new int [sizeForCopy+50];
                    lineageStartEndLimit = (int)sizeForCopy+50;
                }
                
                lineageStartEndCount = 0;
                
                fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                sizeForCopy = 0;
                
                if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                arrayCellNumberInfo = new int [sizeForCopy*2+50];
                cellNumberInfoCount = 0;
                cellNumberInfoLimit = (int)sizeForCopy*2+50;
                cellNumberInfoStatus = 1;
                
                fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                if (seqOpenFlag == 1 && imageSeqOperation == 1){
                    seqImageFirst = 0;
                    seqImageLast = atoi(imageNumberLast.c_str());
                    seqImageCheck = atoi(imageCheckTime.c_str());
                    seqImageMitosis = 0;
                    seqImageFusionMark = 0;
                    seqImageTop = atoi(imageCheckTime.c_str());
                    
                    seqImageNoSet1 = 0;
                    seqImageNoSet2 = 0;
                    seqImageNoSet3 = 0;
                    seqImageNoSet4 = 0;
                    seqImageNoSet5 = 0;
                    seqImageNoSet6 = 0;
                    seqImageNoSet7 = 0;
                    seqImageNoSet8 = 0;
                    seqImageNoSet9 = 0;
                    seqImageNoSet10 = 0;
                }
                
                listCrickMonitor = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Lineage Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
            //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
            //}
        }
    }
    else if (queueDone == "Queue"){
        int fileCheck = 0;
        
        ifstream fin;
        
        string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageData";
        string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStatus";
        string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Treat/"+cellLineageStringTemp+"/"+analysisID+"_"+cellLineageStringTemp+"_CellStatus";
        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameStringTemp+"_Connect/"+ analysisID+"_"+treatmentNameStringTemp+"_LineageStartEnd";
        
        fin.open(connectDataPath.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        fin.open(connectDataStatus.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        fin.open(connectDataStatus2.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        fin.open(connectDataStatus2.c_str(), ios::in);
        if (fin.is_open()) fin.close(), fileCheck++;
        
        if (fileCheck == 4){
            string imageNumberLast = "";
            string imageCheckTime = "";
            string treatmentNameHoldPrev = treatmentNameHold;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] == treatmentNameStringTemp && arrayQueueList [counter1*6+1] == cellLineageStringTemp && arrayQueueList [counter1*6+2] == cellNumberStringTemp){
                    treatmentNameHold = arrayQueueListDisplay [counter1*6];
                    cellLineageNoHold = arrayQueueListDisplay [counter1*6+1];
                    cellNoHold = arrayQueueListDisplay [counter1*6+2];
                    
                    imageNumberLast = arrayQueueListDisplay [counter1*6+3];
                    if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                    
                    imageCheckTime = arrayQueueListDisplay [counter1*6+3];
                    if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                    
                    if (imageReturnPosition == 0){
                        imageNumber = atoi(imageNumberLast.c_str());
                        imageReturnPositionSet = 1;
                    }
                    else{
                        
                        imageNumber = atoi(imageCheckTime.c_str());
                        imageReturnPositionSet = 2;
                    }
                    
                    break;
                }
            }
            
            [treatmentDisplay setStringValue: @(treatmentNameHold.c_str())];
            [cellLineageNoDisplay setStringValue: @(cellLineageNoHold.c_str())];
            [cellNoDisplay setStringValue: @(cellNoHold.c_str())];
            
            int errorCheck = 0;
            long sizeForCopy = 0;
            struct stat sizeOfFile;
            
            saveInfo = treatmentNameStringTemp;
            
            dataSaveRead = [[DataSaveRead alloc] init];
            errorCheck = [dataSaveRead lineageDataRead];
            
            if (errorCheck == 0){
                sizeForCopy = 0;
                
                if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellLineageInfoStatus == 0){
                    arrayCellLineageInfo = new int [sizeForCopy*2+50];
                    cellLineageInfoLimit = (int)sizeForCopy*2+50;
                    cellLineageInfoStatus = 1;
                }
                else if (sizeForCopy*2 > cellLineageInfoCount){
                    delete [] arrayCellLineageInfo;
                    arrayCellLineageInfo = new int [sizeForCopy*2+50];
                    cellLineageInfoLimit = (int)sizeForCopy*2+50;
                }
                
                cellLineageInfoCount = 0;
                
                fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayCellLineageInfo [cellLineageInfoCount] = atoi(dataString.c_str()), cellLineageInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < cellLineageInfoCount/3; counterA++){
                //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<arrayCellLineageInfo [counterA*3+counterB];
                //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                //}
                
                sizeForCopy = 0;
                
                if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (lineageStartEndStatus == 0){
                    arrayLineageStartEnd = new int [sizeForCopy+50];
                    lineageStartEndLimit = (int)sizeForCopy+50;
                    lineageStartEndStatus = 1;
                }
                else if (sizeForCopy > lineageStartEndCount){
                    delete [] arrayLineageStartEnd;
                    arrayLineageStartEnd = new int [sizeForCopy+50];
                    lineageStartEndLimit = (int)sizeForCopy+50;
                }
                
                lineageStartEndCount = 0;
                
                fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayLineageStartEnd [lineageStartEndCount] = atoi(dataString.c_str()), lineageStartEndCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                sizeForCopy = 0;
                
                if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                arrayCellNumberInfo = new int [sizeForCopy*2+50];
                cellNumberInfoCount = 0;
                cellNumberInfoLimit = (int)sizeForCopy*2+50;
                cellNumberInfoStatus = 1;
                
                fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                errorInfoFlag = "nil";
                
                if (seqOpenFlag == 1 && imageSeqOperation == 1){
                    seqImageFirst = 0;
                    seqImageLast = atoi(imageNumberLast.c_str());
                    seqImageCheck = atoi(imageCheckTime.c_str());
                    seqImageMitosis = 0;
                    seqImageFusionMark = 0;
                    seqImageTop = atoi(imageCheckTime.c_str());
                    
                    seqImageNoSet1 = 0;
                    seqImageNoSet2 = 0;
                    seqImageNoSet3 = 0;
                    seqImageNoSet4 = 0;
                    seqImageNoSet5 = 0;
                    seqImageNoSet6 = 0;
                    seqImageNoSet7 = 0;
                    seqImageNoSet8 = 0;
                    seqImageNoSet9 = 0;
                    seqImageNoSet10 = 0;
                }
                
                listCrickMonitor = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Lineage Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
}

-(void)cellJumpTopLast{
    if (treatmentNameHold != "" && cellLineageNoHold != "" && cellNoHold != ""){
        string lineageExtract = cellLineageNoHold.substr(1);
        int lineageExtractInt = atoi(lineageExtract.c_str());
        string cellNumberExtract = cellNoHold.substr(1);
        int cellNoExtractInt = atoi(cellNumberExtract.c_str());
        
        int firstTimePoint = 100000;
        int lastTimePoint = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (arrayLineageStartEnd [counter1*8] == lineageExtractInt && arrayLineageStartEnd [counter1*8+1] == cellNoExtractInt){
                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                    if (arrayLineageData [counter2*8+2] < firstTimePoint) firstTimePoint = arrayLineageData [counter2*8+2];
                    if (arrayLineageData [counter2*8+2] > lastTimePoint) lastTimePoint = arrayLineageData [counter2*8+2];
                }
            }
        }
        
        string checkPoint = "";
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            if (arrayQueueList [counter1*6] == treatmentNameHold && arrayQueueList [counter1*6+1] == cellLineageNoHold && arrayQueueList [counter1*6+2] == cellNoHold){
                checkPoint = arrayQueueList [counter1*6+3];
                break;
            }
        }
        
        if ((int)checkPoint.find(":") != -1) checkPoint = checkPoint.substr(checkPoint.find(":")+1);
        
        int jumpPosition = 1;
        
        if (cellJumpFirstLast == 4 && firstTimePoint != 100000) jumpPosition = firstTimePoint;
        else if (cellJumpFirstLast == 5 && lastTimePoint != 0) jumpPosition = lastTimePoint;
        else if (cellJumpFirstLast == 6 && checkPoint != "") jumpPosition = atoi(checkPoint.c_str());
        
        if (jumpPosition != 0){
            string extension3 = to_string(jumpPosition);
            
            if (extension3.length() == 1) extension3 = "000"+extension3;
            else if (extension3.length() == 2) extension3 = "00"+extension3;
            else if (extension3.length() == 3) extension3 = "0"+extension3;
            
            int fileCheck = 0;
            
            ifstream fin;
            
            string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
            string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
            string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+analysisID+"_"+cellLineageNoHold+"_CellStatus";
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
            
            fin.open(connectDataPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectStartEndPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            if (fileCheck == 4){
                imageNumber = jumpPosition;
                
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                arrayCellNumberInfo = new int [sizeForCopy*2+50];
                cellNumberInfoCount = 0;
                cellNumberInfoLimit = (int)sizeForCopy*2+50;
                cellNumberInfoStatus = 1;
                
                fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                //	cout<<" arrayCellNumberInfo "<<counterA<<endl;
                //}
                
                listCrickMonitor = 1;
            }
            else cellJumpFirstLast = 0;
        }
        else cellJumpFirstLast = 0;
    }
    else cellJumpFirstLast = 0;
}

-(void)lineageQuickSet{
    int connectFindFlag = 0;
    int quickLineageNo = 0;
    int quickCellNo = 0;
    
    string extension3 = to_string(imageNumberTrackForDisplay);
    
    if (extension3.length() == 1) extension3 = "000"+extension3;
    else if (extension3.length() == 2) extension3 = "00"+extension3;
    else if (extension3.length() == 3) extension3 = "0"+extension3;
    
    string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension3+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    
    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
        sizeForCopy = sizeOfFile.st_size;
    }
    
    if (sizeForCopy != 0){
        int *arrayConnectLineageRelTemp = new int [sizeForCopy+50];
        int connectLineageRelTempCount = 0;
        
        ifstream fin;
        
        fin.open(connectRelationPath .c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            fin.close();
            
            unsigned long readPosition = 0;
            int stepCount = 0;
            int finData [19];
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                    finData [3] = uploadTemp [readPosition], readPosition++;
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                    finData [9] = uploadTemp [readPosition], readPosition++;
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                    finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                    finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                    
                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                    finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                    finData [7] = finData [6]*256+finData [7];
                    
                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                    
                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                    else{
                        
                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                        arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                    }
                }
                
            } while (stepCount != 3);
            
            delete [] uploadTemp;
        }
        
        //for (int counterA = 0; counterA < connectLineageRelTempCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelTemp [counterA*6+counterB];
        //    cout<<" arrayConnectLineageRelTemp "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < connectLineageRelTempCount/6; counter1++){
            if (arrayConnectLineageRelTemp [counter1*6+1] == quickLineageConnect){
                connectFindFlag = 1;
                quickLineageNo = arrayConnectLineageRelTemp [counter1*6];
                quickCellNo = arrayConnectLineageRelTemp [counter1*6+3];
                break;
            }
        }
        
        delete [] arrayConnectLineageRelTemp;
        
        if (quickLineageNo == 0){
            if (quickLineageConnect != 0) [inputNoSet setIntegerValue:quickLineageConnect];
        }
        else [inputNoSet setIntegerValue:quickLineageNo];
        
        if (connectFindFlag == 1 && trackingOn == 1){
            string extension = to_string(quickLineageNo);
            
            if (extension.length() == 1) extension = "L0000"+extension;
            else if (extension.length() == 2) extension = "L000"+extension;
            else if (extension.length() == 3) extension = "L00"+extension;
            else if (extension.length() == 4) extension = "L0"+extension;
            else if (extension.length() == 5) extension = "L"+extension;
            
            string extension2 = to_string(quickCellNo);
            
            if (quickCellNo >= 0){
                if (extension2.length() == 1) extension2 = "C00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C000"+extension2;
                else if (extension2.length() == 7) extension2 = "C00"+extension2;
                else if (extension2.length() == 8) extension2 = "C0"+extension2;
                else if (extension2.length() == 9) extension2 = "C"+extension2;
            }
            else{
                
                extension2 = extension2.substr(1);
                
                if (extension2.length() == 1) extension2 = "C-00000000"+extension2;
                else if (extension2.length() == 2) extension2 = "C-0000000"+extension2;
                else if (extension2.length() == 3) extension2 = "C-000000"+extension2;
                else if (extension2.length() == 4) extension2 = "C-00000"+extension2;
                else if (extension2.length() == 5) extension2 = "C-0000"+extension2;
                else if (extension2.length() == 6) extension2 = "C-000"+extension2;
                else if (extension2.length() == 7) extension2 = "C-00"+extension2;
                else if (extension2.length() == 8) extension2 = "C-0"+extension2;
                else if (extension2.length() == 9) extension2 = "C-"+extension2;
            }
            
            int fileCheck = 0;
            
            string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageData";
            string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStatus";
            string connectDataStatus2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+extension+"/"+analysisID+"_"+extension+"_CellStatus";
            string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_LineageStartEnd";
            
            fin.open(connectDataPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectDataStatus2.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            fin.open(connectStartEndPath.c_str(), ios::in);
            if (fin.is_open()) fin.close(), fileCheck++;
            
            if (fileCheck == 4){
                cellLineageNoHold = extension;
                cellNoHold = extension2;
                imageNumber = revisedWorkingMapTime2;
                
                [cellLineageNoDisplay setStringValue: @(cellLineageNoHold.c_str())];
                [cellNoDisplay setStringValue: @(cellNoHold.c_str())];
                
                sizeForCopy = 0;
                
                if (stat(connectDataStatus2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (cellNumberInfoStatus == 1) delete [] arrayCellNumberInfo;
                arrayCellNumberInfo = new int [sizeForCopy*2+50];
                cellNumberInfoCount = 0;
                cellNumberInfoLimit = (int)sizeForCopy*2+50;
                cellNumberInfoStatus = 1;
                
                fin.open(connectDataStatus2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            arrayCellNumberInfo [cellNumberInfoCount] = atoi(dataString.c_str()), cellNumberInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
                
                //for (int counterA = 0; counterA < cellNumberInfoCount/7; counterA++){
                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayCellNumberInfo [counterA*7+counterB];
                //	cout<<" arrayCellNumberInfo "<<counterA<<endl;
                //}
                
                string imageNumberLast = "";
                string imageCheckTime = "";
                
                if (seqOpenFlag == 1 && imageSeqOperation == 1){
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] == treatmentNameHold && arrayQueueList [counter1*6+1] == cellLineageNoHold && arrayQueueList [counter1*6+2] == cellNoHold){
                            imageNumberLast = arrayQueueList [counter1*6+3];
                            if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                            
                            imageCheckTime = arrayQueueList [counter1*6+3];
                            if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                            
                            if (imageReturnPosition == 0) imageReturnPositionSet = 1;
                            else imageReturnPositionSet = 2;
                            
                            break;
                        }
                    }
                    
                    if (imageNumberLast == "" && imageCheckTime == ""){
                        for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                            if (arrayDoneList [counter1*5] == treatmentNameHold && arrayDoneList [counter1*5+1] == cellLineageNoHold && arrayDoneList [counter1*5+2] == cellNoHold){
                                imageNumberLast = arrayDoneList [counter1*5+3];
                                if ((int)imageNumberLast.find(":") != -1) imageNumberLast = imageNumberLast.substr(0, imageNumberLast.find(":"));
                                
                                imageCheckTime = arrayDoneList [counter1*5+3];
                                if ((int)imageCheckTime.find(":") != -1) imageCheckTime = imageCheckTime.substr(imageCheckTime.find(":")+1);
                                
                                if (imageReturnPosition == 0) imageReturnPositionSet = 1;
                                else imageReturnPositionSet = 2;
                                
                                break;
                            }
                        }
                    }
                    
                    seqImageFirst = 0;
                    seqImageLast = atoi(imageNumberLast.c_str());
                    seqImageCheck = atoi(imageCheckTime.c_str());
                    seqImageMitosis = 0;
                    seqImageFusionMark = 0;
                    seqImageTop = atoi(imageCheckTime.c_str());
                    
                    seqImageNoSet1 = 0;
                    seqImageNoSet2 = 0;
                    seqImageNoSet3 = 0;
                    seqImageNoSet4 = 0;
                    seqImageNoSet5 = 0;
                    seqImageNoSet6 = 0;
                    seqImageNoSet7 = 0;
                    seqImageNoSet8 = 0;
                    seqImageNoSet9 = 0;
                    seqImageNoSet10 = 0;
                }
                
                listCrickMonitor = 1;
            }
            else quickLineageConnect = 0;
            
            //for (int counterA = 0; counterA < lineageStartEndCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageStartEnd [counterA*8 +counterB];
            //	cout<<" arrayLineageStartEnd "<<counterA<<endl;
            //}
        }
        else quickLineageConnect = 0;
    }
    else quickLineageConnect = 0;
}

-(void)connectQuickSet{
    int quickLineageNo = 0;
    
    string extension3 = to_string(imageNumberTrackForDisplay);
    
    if (extension3.length() == 1) extension3 = "000"+extension3;
    else if (extension3.length() == 2) extension3 = "00"+extension3;
    else if (extension3.length() == 3) extension3 = "0"+extension3;
    
    string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension3+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
    
    struct stat sizeOfFile;
    
    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
        for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
            if (arrayConnectLineageRel [counter1*6+1] == quickLineageConnect){
                quickLineageNo = arrayConnectLineageRel [counter1*6];
                break;
            }
        }
        
        if (quickLineageNo == 0 && quickLineageConnect != 0){
            if (mergeSelectCount <= 7){
                int identicalNoFound = 0;
                
                for (int counter1 = 0; counter1 < mergeSelectCount; counter1++){
                    if (arrayMergeSelect [counter1] == quickLineageConnect){
                        arrayMergeSelect [counter1] = 0;
                        identicalNoFound = 1;
                    }
                }
                
                if (identicalNoFound == 1){
                    mergeSelectCount = 0;
                    
                    for (int counter1 = 0; counter1 < mergeSelectCount; counter1++){
                        if (arrayMergeSelect [counter1] != 0){
                            arrayMergeSelect [mergeSelectCount] = arrayMergeSelect [counter1], mergeSelectCount++;
                        }
                    }
                }
                else arrayMergeSelect [mergeSelectCount] = quickLineageConnect, mergeSelectCount++;
            }
            else{
                
                int identicalNoFound = 0;
                
                for (int counter1 = 0; counter1 < mergeSelectCount; counter1++){
                    if (arrayMergeSelect [counter1] == quickLineageConnect){
                        arrayMergeSelect [counter1] = 0;
                        identicalNoFound = 1;
                    }
                }
                
                if (identicalNoFound == 1){
                    mergeSelectCount = 0;
                    
                    for (int counter1 = 0; counter1 < mergeSelectCount; counter1++){
                        if (arrayMergeSelect [counter1] != 0){
                            arrayMergeSelect [mergeSelectCount] = arrayMergeSelect [counter1], mergeSelectCount++;
                        }
                    }
                }
            }
            
            listCrickMonitor = 1;
        }
    }
}

-(IBAction)toolBarInitial:(id)sender{
    if (initialSetOperation == 0 && timeOneStatus == 0){
        initialSetOperation = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageList object:self];
    }
    
    if (initialSetOperation == 2) initialSetOperation = 3;
}

-(IBAction)toolBarAnalysisLoad:(id)sender{
    if (analysisLoadOperation == 0 && timeOneStatus == 0){
        analysisLoadOperation = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToAnalysisLoad object:self];
    }
    
    if (analysisLoadOperation == 2) analysisLoadOperation = 3;
}

-(IBAction)toolBarTracking:(id)sender{
    if ((initialSetOperation == 0 || initialSetOperation == 2) && (analysisLoadOperation == 0 || analysisLoadOperation == 2) && analysisSavingInProgress == 0){
        if (trackingTableOperation == 0 && analysisImageName != "" && treatmentNameHold != "" && timeOneStatus == 0 && treatmentDisplayFirstSet == 1){
            trackingTableOperation = 1;
            displayPositionType = 0;
            imageLoadMonitor = 1;
            trackingTableSetDone = 1;
            trackingOn = 1;
            tableDataSetDone = 0;
            tableTrackingProcessing = 0;
            
            //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
            //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
            //}
            
            int entryCheck = 0;
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                if (treatmentNameHold == arrayTreatmentStatus [counter1*9] && arrayTreatmentStatus [counter1*9+2] == "1" && arrayTreatmentStatus [counter1*9+3] == "1"){
                    entryCheck = 1;
                    dataEntryStatus = 1;
                }
                else dataEntryStatus = 0;
            }
            
            if (entryCheck == 1) [statusDisplay setStringValue:@"Tracking"];
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Perform Time One"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingController object:self];
        }
        
        if (trackingTableOperation == 2) trackingTableOperation = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Close Initial Setting or Analysis Load"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)toolBarTimeOne:(id)sender{
    if (trackingTableOperation >= 1 && timeOneStatus == 0 && trackingOn == 1 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        int entryCheck = 0;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (treatmentNameHold == arrayTreatmentStatus [counter1*9] && arrayTreatmentStatus [counter1*9+3] == "1") entryCheck = 1;
        }
        
        if (ifEntry == 0){
            if (entryCheck == 1){
                timeOneStatus = 1;
                trackingTableSetDone = 0;
                trackingOn = 2;
                trackingImageLock = 0;
                currentPositionSet = 1;
                listOnOffFlag = 0;
                [listName setStringValue:@"Cells/Revised"];
                [statusDisplay setStringValue:@"Time One"];
                
                int lineSetError = 0;
                
                tableTrackingProcessing = 0;
                lineSet = [[LineSet alloc] init];
                lineSetError = [lineSet dataRead:imageNumber];
                
                if (lineSetError == 0){
                    if (dataEntryStatus == 1){
                        do{
                            
                            if (masterLineForTrackingStatus == 1 && masterLineForDisplayStatus == 1 && masterLineGravityCenterStatus == 1 && masterLineGCDisplayStatus == 1){
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTimeOne object:self];
                            }
                            
                        } while (masterLineForTrackingStatus == 0 || masterLineForDisplayStatus == 0 || masterLineGravityCenterStatus == 0 || masterLineGCDisplayStatus == 0);
                    }
                    else [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTimeOne object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Outline Data Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Exit IF Image"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if (trackingTableOperation >= 1 && timeOneStatus > 0 && queueHoldingStatus == 0 && trackingOn == 2 && mainSavingInProgress == 0 && cleaningProgress == 0){
        listSwitchCall = 1;
        trackingOn = 1;
        timeOneStatus = 5;
        areaSelectStatus = 0;
        windowLock = 0;
        doubleClickStatusHold = 0;
        lineDraw = 0;
        tableDataSetDone = 0;
        trackingTableSetDone = 1;
        tableListSwitch = 1;
        lineageCellSwitch = 1;
        tableTrackingProcessing = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)toolBarList:(id)sender{
    if (trackingTableOperation >= 1 && listWindowOperation == 0) listWindowOperation = 1;
    if (listWindowOperation == 2) listWindowOperation = 3;
}

-(IBAction)toolBarNavigation:(id)sender{
    if (trackingTableOperation >= 1 && navigationOperation == 0) navigationOperation = 1;
    if (navigationOperation == 2) navigationOperation = 3;
}

-(IBAction)addLineage:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        string addConnectNo = [[inputNoSet stringValue] UTF8String];
        
        string noStringTemp;
        int terminationFlag = 0;
        
        do {
            
            if ((int)addConnectNo.find(",") != -1){
                noStringTemp = addConnectNo.substr(0, addConnectNo.find(","));
                addConnectNo = noStringTemp+addConnectNo.substr(addConnectNo.find(",")+1);
            }
            else terminationFlag = 1;
            
        } while (terminationFlag == 0);
        
        int connectNoAdd = atoi(addConnectNo.c_str());
        [inputNoSet setStringValue:@""];
        
        if (trackingOn == 1 && imageNumberTrackForDisplay == timeOneHold && connectNoAdd > 0 && queueHoldingStatus == 0){
            addDelete = [[AddDelete alloc] init];
            int returnResults = [addDelete addLineageMain:connectNoAdd];
            
            if (returnResults == 1){
                int lineSetError = 0;
                
                lineSet = [[LineSet alloc] init];
                lineSetError = [lineSet dataRead:timeOneHold];
                
                if (lineSetError == 0){
                    setStatus3 = 3;
                    setStatus8 = 1;
                    
                    if (searchWindowOperation != 0){
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
        else{
            
            if (trackingOn != 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Tracking On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else if (imageNumberTrackForDisplay != timeOneHold){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Start Point"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else if (connectNoAdd <= 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Connect No. Error/Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)delLineage:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        string delLineageNo = [[inputNoSet stringValue] UTF8String];
        
        string noStringTemp;
        int terminationFlag = 0;
        
        do {
            
            if ((int)delLineageNo.find(",") != -1){
                noStringTemp = delLineageNo.substr(0, delLineageNo.find(","));
                delLineageNo = noStringTemp+delLineageNo.substr(delLineageNo.find(",")+1);
            }
            else terminationFlag = 1;
            
        } while (terminationFlag == 0);
        
        int lineageNoDel = atoi(delLineageNo.c_str());
        int processType = 1;
        int delCellNo = 0;
        int delStartNo = 0;
        [inputNoSet setStringValue:@""];
        
        if (trackingOn == 1 && lineageNoDel > 0 && queueHoldingStatus == 0){
            cellLineageNoHold = "";
            cellNoHold = "";
            progressTiming = 7;
            
            addDelete = [[AddDelete alloc] init];
            int returnResults = [addDelete delLineageMain:lineageNoDel:processType:delCellNo:delStartNo];
            
            if (returnResults == 1){
                int lineSetError = 0;
                
                lineSet = [[LineSet alloc] init];
                lineSetError = [lineSet dataRead:imageNumberTrackForDisplay];
                
                if (lineSetError == 0){
                    setStatus3 = 3;
                    setStatus8 = 1;
                    
                    if (searchWindowOperation != 0){
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                usleep (50000);
                
                addDelete = [[AddDelete alloc] init];
                returnResults = [addDelete delLineageMain:lineageNoDel:processType:delCellNo:delStartNo];
                
                if (returnResults == 1){
                    int lineSetError = 0;
                    
                    lineSet = [[LineSet alloc] init];
                    lineSetError = [lineSet dataRead:imageNumberTrackForDisplay];
                    
                    if (lineSetError == 0){
                        setStatus3 = 3;
                        setStatus8 = 1;
                        
                        if (searchWindowOperation != 0){
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else{
                    
                    usleep (50000);
                    
                    addDelete = [[AddDelete alloc] init];
                    returnResults = [addDelete delLineageMain:lineageNoDel:processType:delCellNo:delStartNo];
                    
                    if (returnResults == 1){
                        int lineSetError = 0;
                        
                        lineSet = [[LineSet alloc] init];
                        lineSetError = [lineSet dataRead:imageNumberTrackForDisplay];
                        
                        if (lineSetError == 0){
                            setStatus3 = 3;
                            setStatus8 = 1;
                            
                            if (searchWindowOperation != 0){
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
                            }
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    else if (lineageNoDel <= 0){
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Deletion Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            
            progressTiming = 8;
        }
        else{
            
            if (trackingOn != 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Tracking On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else if (lineageNoDel <= 0){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Lineage No. Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Auto Processing On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)insertLineage:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        string addConnectNo = [[inputNoSet stringValue] UTF8String];
        
        string noStringTemp;
        int terminationFlag = 0;
        
        do {
            
            if ((int)addConnectNo.find(",") != -1){
                noStringTemp = addConnectNo.substr(0, addConnectNo.find(","));
                addConnectNo = noStringTemp+addConnectNo.substr(addConnectNo.find(",")+1);
            }
            else terminationFlag = 1;
            
        } while (terminationFlag == 0);
        
        int connectNoAdd = atoi(addConnectNo.c_str());
        [inputNoSet setStringValue:@""];
        
        ifstream fin;
        
        string extension = to_string(imageNumberTrackForDisplay);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
        
        fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
        
        int fileCheck = 0;
        
        if (fin.is_open()){
            fin.close();
            fileCheck = 1;
        }
        
        if (fileCheck == 1){
            if (trackingOn == 1 && imageNumberTrackForDisplay != timeOneHold && imageNumberTrackForDisplay <= timeEndHold-1 && connectNoAdd > 0 && queueHoldingStatus == 0){
                addDelete = [[AddDelete alloc] init];
                int returnResults = [addDelete insertLineageMain:connectNoAdd];
                
                if (returnResults == 1){
                    int lineSetError = 0;
                    
                    lineSet = [[LineSet alloc] init];
                    lineSetError = [lineSet dataRead:imageNumberTrackForDisplay];
                    
                    if (lineSetError == 0){
                        setStatus3 = 3;
                        setStatus8 = 1;
                        
                        if (searchWindowOperation != 0){
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
            }
            else{
                
                if (trackingOn != 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Tracking On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (imageNumberTrackForDisplay == timeOneHold || imageNumberTrackForDisplay > timeEndHold-1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Start Point"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (connectNoAdd <= 0){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Connect No. Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Auto Processing On"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking Limit Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)queueHoldControl:(id)sender{
    if (queueRestartFlag == 0){
        firstTrackStart = 1;
        multipleLaunchBlock = 0;
        [self queueHoldControlMain];
    }
    else if (queueRestartFlag >= 6) queueRestartFlag = 12;
}

-(void)queueHoldControlMain{
    if (trackingOn == 1 && queueHoldingStatus == 0 && analysisImageName != "" && treatmentNameHold != "" && timeOneStatus == 0 && runStatusCellCurving == 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        
        [optionCheck setStringValue:@""];
        
        remove (instructionCCPath.c_str());
        remove (instructionRRPath.c_str());
        
        string treatmentNameOption = "";
        string timeOneString;
        string lineageDoneNo;
        string imageNoCommTemp;
        string doneListPath;
        string lineageCommPath;
        string lineageNo;
        string cellNoRedo;
        string extension;
        string queueListPath;
        string extension2;
        string optionPath;
        
        //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayOperationData [counterA*4+counterB];
        //    cout<<" arrayOperationData "<<counterA<<endl;
        //}
        
        int processType = 0;
        int doneListTempCount2 = 0;
        int lineageDoneNoInt = 0;
        int delCellNo = 0;
        int delStartNo = 0;
        int doneListTempCount = 0;
        int queueListTempCount = 0;
        int queueListTempCount2 = 0;
        int totalEntryCount = 0;
        int lineageCommTempCount = 0;
        int stepCount = 0;
        int finData [25];
        int timePointLast = 0;
        int findLineage = 0;
        int dataLoadingError = 0;
        int addDeleteStatus = 0;
        int checkFlag = 0;
        
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        
        unsigned long readPosition = 0;
        
        struct stat sizeOfFile;
        
        ifstream fin;
        ofstream oin;
        
        //======For Operation data processing========
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            checkFlag = 1;
            dataLoadingError = 0;
            
            if (arrayOperationData [counter1*4] == 2 && (arrayOperationData [counter1*4+2] == 1 || arrayOperationData [counter1*4+2] == 2 || arrayOperationData [counter1*4+1] == 3)){
                treatmentNameOption = arrayTreatmentStatus [counter1*9];
                timeOneString = arrayTreatmentStatus [counter1*9+4];
                
                if (arrayOperationData [counter1*4+2] != 3){
                    processType = 1;
                    
                    string *arrayDoneListTemp2 = new string [doneListCount+50];
                    doneListTempCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                        if (arrayDoneList [counter2*5] == treatmentNameOption && arrayDoneList [counter2*5+4] == "TL"){
                            arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter2*5], doneListTempCount2++;
                            arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter2*5+1], doneListTempCount2++;
                            arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter2*5+2], doneListTempCount2++;
                            arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter2*5+3], doneListTempCount2++;
                            arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter2*5+4], doneListTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < doneListTempCount2/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneListTemp2 [counterA*5+counterB];
                    //    cout<<" arrayDoneListTemp2 "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < doneListTempCount2/5; counter2++){
                        lineageDoneNo = arrayDoneListTemp2 [counter2*5+1];
                        lineageDoneNo = lineageDoneNo.substr(1);
                        lineageDoneNoInt = atoi(lineageDoneNo.c_str());
                        delCellNo = 0;
                        delStartNo = 0;
                        
                        treatmentNameAuto = treatmentNameOption;
                        
                        addDeleteAuto = [[AddDeleteAuto alloc] init];
                        addDeleteStatus = [addDeleteAuto delLineageMain:lineageDoneNoInt:processType:delCellNo:delStartNo];
                        
                        if (addDeleteStatus == -1){
                            usleep (50000);
                            
                            addDeleteAuto = [[AddDeleteAuto alloc] init];
                            addDeleteStatus = [addDeleteAuto delLineageMain:lineageDoneNoInt:processType:delCellNo:delStartNo];
                            
                            if (addDeleteStatus == -1){
                                usleep (50000);
                                
                                addDeleteAuto = [[AddDeleteAuto alloc] init];
                                [addDeleteAuto delLineageMain:lineageDoneNoInt:processType:delCellNo:delStartNo];
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA <  doneListCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                    //    cout<<" arrayDoneList "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                    //    cout<<" arrayQueueList "<<counterA<<endl;
                    //}
                    
                    if (arrayOperationData [counter1*4+2] == 1){
                        string *arrayDoneListTemp = new string [doneListCount+50];
                        doneListTempCount = 0;
                        string *arrayQueueListTemp = new string [queueListCount+50];
                        queueListTempCount = 0;
                        string *arrayQueueListTemp2 = new string [queueListCount+50];
                        queueListTempCount2 = 0;
                        
                        for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                            if (arrayDoneList [counter1*5] == treatmentNameOption && arrayDoneList [counter1*5+4] != "CF" && arrayDoneList [counter1*5+4] != "CF/m" && arrayDoneList [counter1*5+4] != "OK" && arrayDoneList [counter1*5+4] != "OK/m" && arrayDoneList [counter1*5+4] != "OK/e" && arrayDoneList [counter1*5+4] != "OK/me"&& arrayDoneList [counter1*5+2] == "C000000000"){
                                arrayQueueList [queueListCount] = treatmentNameOption, queueListCount++;
                                arrayQueueList [queueListCount] = arrayDoneList [counter2*5+1], queueListCount++;
                                arrayQueueList [queueListCount] = "C000000000", queueListCount++;
                                arrayQueueList [queueListCount] = arrayDoneList [counter2*5+3], queueListCount++;
                                arrayQueueList [queueListCount] = "0", queueListCount++;
                                arrayQueueList [queueListCount] = "Redo", queueListCount++;
                            }
                            else{
                                
                                arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter2*5], doneListTempCount++;
                                arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter2*5+1], doneListTempCount++;
                                arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter2*5+2], doneListTempCount++;
                                arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter2*5+3], doneListTempCount++;
                                arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter2*5+4], doneListTempCount++;
                            }
                        }
                        
                        doneListCount = 0;
                        for (int counter2 = 0; counter2 < doneListTempCount; counter2++) arrayDoneList [doneListCount] = arrayDoneListTemp [counter2], doneListCount++;
                        
                        // for (int counterA = 0; counterA < doneListCount/5; counterA++){
                        //     for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                        //     cout<<" arrayDoneList "<<counterA<<endl;
                        //}
                        
                        delete [] arrayDoneListTemp;
                        
                        doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                        
                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                            if (arrayQueueList [counter2*6] == treatmentNameOption){
                                imageNoCommTemp = arrayQueueList [counter1*6+3];
                                
                                if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
                                
                                if (arrayQueueList [counter2*6+5] != "Redo" && atoi(imageNoCommTemp.c_str()) <= atoi(timeOneString.c_str())+10 && arrayQueueList [counter2*6+2] == "C000000000"){
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+1], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+2], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+3], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+4], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = "Redo", queueListTempCount++;
                                }
                                else{
                                    
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+1], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+2], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+3], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+4], queueListTempCount++;
                                    arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter2*6+5], queueListTempCount++;
                                }
                            }
                            else{
                                
                                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter2*6], queueListTempCount2++;
                                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter2*6+1], queueListTempCount2++;
                                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter2*6+2], queueListTempCount2++;
                                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter2*6+3], queueListTempCount2++;
                                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter2*6+4], queueListTempCount2++;
                                arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter2*6+5], queueListTempCount2++;
                            }
                        }
                        
                        queueListCount = 0;
                        
                        for (int counter2 = 0; counter2 < queueListTempCount; counter2++) arrayQueueList [queueListCount] = arrayQueueListTemp [counter2], queueListCount++;
                        for (int counter2 = 0; counter2 < queueListTempCount2; counter2++) arrayQueueList [queueListCount] = arrayQueueListTemp2 [counter2], queueListCount++;
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //    cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        delete [] arrayQueueListTemp;
                        delete [] arrayQueueListTemp2;
                        
                        lineageCommPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameOption+"_Connect/"+analysisID+"_"+treatmentNameOption+"_LineageData";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        dataLoadingError = 0;
                        
                        for (int counter2 = 0; counter2 < 6; counter2++){
                            sizeForCopy = 0;
                            
                            if (stat(lineageCommPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter2 == 0) size1 = sizeForCopy;
                                else if (counter2 == 1) size2 = sizeForCopy;
                                else if (counter2 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter2 == 3) size1 = sizeForCopy;
                                else if (counter2 == 4) size2 = sizeForCopy;
                                else if (counter2 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        int *lineageCommTemp = new int [sizeForCopy+50];
                        lineageCommTempCount = 0;
                        
                        if (checkFlag == 1){
                            fin.open(lineageCommPath.c_str(), ios::in | ios::binary);
                            
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                                    dataLoadingError = 1;
                                }
                            }
                            
                            fin.close();
                            
                            if (dataLoadingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                        finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++;
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                        finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                        finData [16] = uploadTemp [readPosition], readPosition++;
                                        finData [17] = uploadTemp [readPosition], readPosition++;
                                        finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                        finData [19] = uploadTemp [readPosition], readPosition++;
                                        finData [20] = uploadTemp [readPosition], readPosition++;
                                        finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                        finData [22] = uploadTemp [readPosition], readPosition++;
                                        finData [23] = uploadTemp [readPosition], readPosition++;
                                        finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                        
                                        if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                        else finData [2] = finData [1]*256+finData [2];
                                        
                                        if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                        else finData [5] = finData [4]*256+finData [5];
                                        
                                        finData [7] = finData [6]*256+finData [7];
                                        
                                        if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                        else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                        
                                        if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                        else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                        
                                        finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                        finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                        
                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                        else{
                                            
                                            lineageCommTemp [lineageCommTempCount] = finData [2], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [5], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [7], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [8], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [13], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [18], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [21], lineageCommTempCount++;
                                            lineageCommTemp [lineageCommTempCount] = finData [24], lineageCommTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                            if (arrayQueueList [counter2*6] == treatmentNameOption && arrayQueueList [counter2*6+5] == "Redo"){
                                lineageNo = arrayQueueList [counter2*6+1];
                                lineageNo = lineageNo.substr(1);
                                cellNoRedo = arrayQueueList [counter2*6+2];
                                cellNoRedo = cellNoRedo.substr(1);
                                
                                timePointLast = 0;
                                findLineage = 0;
                                
                                for (int counter3 = 0; counter3 < lineageCommTempCount/8; counter3++){
                                    if (lineageCommTemp [counter3*8+6] == atoi(lineageNo.c_str()) && lineageCommTemp [counter3*8+5] == atoi(cellNoRedo.c_str()) && findLineage == 0){
                                        findLineage = 1;
                                        timePointLast = lineageCommTemp [counter3*8+2];
                                    }
                                    else if (lineageCommTemp [counter3*8+6] == atoi(lineageNo.c_str()) && lineageCommTemp [counter3*8+5] == atoi(cellNoRedo.c_str()) && findLineage == 1){
                                        timePointLast = lineageCommTemp [counter3*8+2];
                                    }
                                    else if ((lineageCommTemp [counter3*8+6] != atoi(lineageNo.c_str()) || lineageCommTemp [counter3*8+5] != atoi(cellNoRedo.c_str())) && findLineage == 1){
                                        break;
                                    }
                                }
                                
                                extension = to_string(timePointLast);
                                extension2 = to_string(atoi(timeOneString.c_str()));
                                
                                arrayQueueList [counter2*6+3] = extension+":"+extension2;
                            }
                        }
                        
                        delete [] lineageCommTemp;
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //    cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        if (checkFlag == 1 && dataLoadingError == 0){
                            queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                            
                            if (queueListCount != 0){
                                char *mainDataEntry = new char [queueListCount*12+10];
                                totalEntryCount = 0;
                                
                                for (int counter2 = 0; counter2 < queueListCount; counter2++){
                                    extension = arrayQueueList [counter2];
                                    
                                    for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile6 (queueListPath.c_str(), ofstream::binary);
                                outfile6.write (mainDataEntry, totalEntryCount);
                                outfile6.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            if (doneListCount != 0){
                                char *mainDataEntry = new char [doneListCount*10+10];
                                totalEntryCount = 0;
                                
                                for (int counter2 = 0; counter2 < doneListCount; counter2++){
                                    extension = arrayDoneList [counter2];
                                    
                                    for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile3 (doneListPath.c_str(), ofstream::binary);
                                outfile3.write (mainDataEntry, totalEntryCount);
                                outfile3.close();
                                
                                delete [] mainDataEntry;
                            }
                        }
                        
                        arrayOperationData [counter1*4+1] = 5;
                    }
                    else{
                        
                        arrayOperationData [counter1*4+1] = 5;
                        arrayOperationData [counter1*4+3] = 2;
                    }
                    
                    delete [] arrayDoneListTemp2;
                }
                else{
                    
                    arrayOperationData [counter1*4+1] = 5;
                    arrayOperationData [counter1*4+3] = 2;
                }
                
                optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
                
                oin.open(optionPath.c_str(), ios::out);
                
                for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                    oin<<arrayOperationData [counter2*4]<<endl;
                    oin<<arrayOperationData [counter2*4+1]<<endl;
                    oin<<arrayOperationData [counter2*4+2]<<endl;
                    oin<<arrayOperationData [counter2*4+3]<<endl;
                }
                
                oin<<"End"<<endl;
                oin.close();
            }
        }
        
        //===========================================
        
        if (checkFlag == 1 && dataLoadingError == 0){
            unsigned long hardMemorySize = [NSProcessInfo processInfo].physicalMemory;
            
            string treatmentNameTemp = "";
            int imageSizeMax = 0;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                treatmentNameTemp = arrayQueueList [counter1*6];
                
                for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                    if (arrayImageSizeList [counter2*2] == treatmentNameTemp){
                        if (imageSizeMax < atoi(arrayImageSizeList [counter2*2+1].c_str())){
                            imageSizeMax = atoi(arrayImageSizeList [counter2*2+1].c_str());
                        }
                    }
                }
            }
            
            hardMemorySize = hardMemorySize-805306368;
            unsigned long mapFileSize = (unsigned long)(imageSizeMax*imageSizeMax*4*7);
            
            double mapAllocationNumber = 0;
            if (mapFileSize != 0)  mapAllocationNumber = (double)(hardMemorySize/(unsigned long)mapFileSize);
            
            if (mapAllocationNumber >= 11){
                if ((int)mapAllocationNumber < trackingCheckInterval){
                    trackingCheckInterval = (int)mapAllocationNumber;
                    [trackingIntervalDisplay setIntegerValue:trackingCheckInterval];
                    [stepperInterval setIntValue:[trackingIntervalDisplay intValue]];
                }
                
                runStatusCellCurving = 1;
                firstCleaningFlag = 1;
                autoTrackFirstSave = 0;
                
                string cellCarvingLaunchPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"Cell_Imaging_processing_programs/Cell_Carving.app";
                
                NSWorkspaceOpenConfiguration* configuration = [NSWorkspaceOpenConfiguration configuration];
                [[NSWorkspace sharedWorkspace] openApplicationAtURL: [NSURL fileURLWithPath: @(cellCarvingLaunchPath .c_str())] configuration: configuration completionHandler:^(NSRunningApplication* app, NSError* error) {}];
                
                queueHoldingStatus = 1;
                optionCall = 1;
                trackingTableSetDone = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Insufficient Disk Space"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking Mode Off"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (queueHoldingStatus != 0 || runStatusCellCurving != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (analysisImageName == "" || treatmentNameHold == ""){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Analysis/Treatment Selected"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (timeOneStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)sliderAction:(id)sender{
    if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0){
        if (fluorescentDisplayNo == 1){
            fluorescentCutOff1 = (int)([sliderFluorescent doubleValue]);
            
            fluorescentValueDisplayControl = 1;
            sliderBarSet = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
        else if (fluorescentDisplayNo == 2){
            fluorescentCutOff2 = (int)([sliderFluorescent doubleValue]);
            
            fluorescentValueDisplayControl = 1;
            sliderBarSet = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
        else if (fluorescentDisplayNo == 3){
            fluorescentCutOff3 = (int)([sliderFluorescent doubleValue]);
            
            fluorescentValueDisplayControl = 1;
            sliderBarSet = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
        else if (fluorescentDisplayNo == 4){
            fluorescentCutOff4 = (int)([sliderFluorescent doubleValue]);
            
            fluorescentValueDisplayControl = 1;
            sliderBarSet = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
        else if (fluorescentDisplayNo == 5){
            fluorescentCutOff5 = (int)([sliderFluorescent doubleValue]);
            
            fluorescentValueDisplayControl = 1;
            sliderBarSet = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
        else if (fluorescentDisplayNo == 6){
            fluorescentCutOff6 = (int)([sliderFluorescent doubleValue]);
            
            fluorescentValueDisplayControl = 1;
            sliderBarSet = 1;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
    }
}

-(IBAction)endOfImageSet:(id)sender{
    if (trackingOn == 1 && queueHoldingStatus == 0 && tableListSwitch == 2 && mainSavingInProgress == 0 && cleaningProgress == 0){
        communication = [[Communication alloc] init];
        [communication timeEndRevise];
        
        //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
        //	for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
        //	cout<<" arrayTreatmentStatus "<<counterA<<endl;
        //}
        
        string treatmentNameTemp;
        string extractString;
        string lineageFilePath;
        string entry;
        string imageNoEnd;
        string imageNoCk;
        
        int largestOutline = 0;
        int boarderNo = 0;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            treatmentNameTemp = arrayTreatmentStatus [counter1*9];
            largestOutline = 0;
            
            lineageFilePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameTemp+"_Processed";
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(lineageFilePath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if ((int)entry.find("MasterData") != -1){
                        extractString = entry.substr(0, 4);
                        
                        if (atoi(extractString.c_str()) > largestOutline) largestOutline = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            if (largestOutline != 0){
                boarderNo = 0;
                
                if (arrayTreatmentStatus [counter1*9+7] == "nil") boarderNo = largestOutline;
                else if (atoi(arrayTreatmentStatus [counter1*9+5].c_str()) < atoi(arrayTreatmentStatus [counter1*9+7].c_str())-1){
                    boarderNo = largestOutline;
                }
                else if (atoi(arrayTreatmentStatus [counter1*9+5].c_str()) == atoi(arrayTreatmentStatus [counter1*9+7].c_str())-1){
                    if (largestOutline < atoi(arrayTreatmentStatus [counter1*9+7].c_str())-1) boarderNo = largestOutline;
                    else if (largestOutline == atoi(arrayTreatmentStatus [counter1*9+7].c_str())-1) boarderNo = atoi(arrayTreatmentStatus [counter1*9+7].c_str())-1;
                }
                else boarderNo = largestOutline;
                
                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                    if (arrayQueueList [counter2*6] == treatmentNameTemp){
                        
                        if (arrayQueueList [counter2*6+4] == "/m") arrayQueueList [counter2*6+4] = to_string(boarderNo)+"/m";
                        else{
                            
                            imageNoEnd = arrayQueueList [counter2*6+3].substr(0, arrayQueueList [counter2*6+3].find(":"));
                            imageNoCk = arrayQueueList [counter2*6+3].substr(arrayQueueList [counter2*6+3].find(":")+1);
                            
                            
                            if (arrayTreatmentStatus [counter1*9+7] == "nil"){
                                if (imageNoEnd != imageNoCk) arrayQueueList [counter2*6+4] = to_string(boarderNo);
                                else if (imageNoEnd == imageNoCk && boarderNo == atoi(imageNoEnd.c_str())) arrayQueueList [counter2*6+4] = "0";
                                else if (imageNoEnd == imageNoCk && boarderNo != atoi(imageNoEnd.c_str())) arrayQueueList [counter2*6+4] = to_string(boarderNo);
                                
                            }
                            else{
                                
                                if (imageNoEnd != imageNoCk && atoi(imageNoEnd.c_str()) <= boarderNo) arrayQueueList [counter2*6+4] = to_string(boarderNo);
                                else if (imageNoEnd != imageNoCk && atoi(imageNoEnd.c_str()) > boarderNo) arrayQueueList [counter2*6+4] = "IF";
                                else if (imageNoEnd == imageNoCk && boarderNo > atoi(imageNoEnd.c_str())) arrayQueueList [counter2*6+4] = to_string(boarderNo);
                                else if (imageNoEnd == imageNoCk && boarderNo == atoi(imageNoEnd.c_str())) arrayQueueList [counter2*6+4] = "IF";
                                else if (imageNoEnd == imageNoCk && boarderNo > atoi(imageNoEnd.c_str())) arrayQueueList [counter2*6+4] = "IF";
                            }
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
        //    cout<<" QueueListCount "<<counterA<<endl;
        //}
        
        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
        
        if (queueListCount != 0){
            string extension;
            
            char *mainDataEntry = new char [queueListCount*12+10];
            int totalEntryCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCount; counter1++){
                extension = arrayQueueList [counter1];
                
                for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile (queueListPath.c_str(), ofstream::binary);
            outfile.write (mainDataEntry, totalEntryCount);
            outfile.close();
            
            delete [] mainDataEntry;
        }
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing On or Other Processes Running"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)toolBarOption:(id)sender{
    if (queueHoldingStatus == 0 && trackingOn == 1 && timeOneStatus == 0){
        if (optionWindowOperation == 0){
            optionWindowOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToOptionController object:self];
        }
        
        if (optionWindowOperation == 2) optionWindowOperation = 3;
    }
    else{
        
        if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Uploaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)toolBarListSearch:(id)sender{
    if (queueHoldingStatus == 0 && trackingOn == 1 && timeOneStatus == 0){
        if (searchWindowOperation == 0){
            searchWindowOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchController object:self];
        }
        
        if (searchWindowOperation == 2) searchWindowOperation = 3;
    }
    else{
        
        if (queueHoldingStatus != 0){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 3){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn == 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Time One On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data Uploaded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)quitAnalysis:(id)sender{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        if (timeOneStatus == 2){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                delete [] sourceImage [counter1];
                delete [] revisedMap [counter1];
                delete [] revisedWorkingMap [counter1];
                delete [] connectMap200 [counter1];
                delete [] connectMap220 [counter1];
                delete [] connectMap240 [counter1];
                delete [] connectMapA [counter1];
                delete [] connectMapB [counter1];
                delete [] connectMapC [counter1];
                delete [] connectMapD [counter1];
            }
            
            delete [] sourceImage;
            delete [] revisedMap;
            delete [] revisedWorkingMap;
            delete [] connectMap200;
            delete [] connectMap220;
            delete [] connectMap240;
            delete [] connectMapA;
            delete [] connectMapB;
            delete [] connectMapC;
            delete [] connectMapD;
            
            delete [] arrayTarget;
            targetStatus = 0;
            
            delete [] arrayPositionRevise;
            delete [] arrayGravityCenterRev;
            delete [] arrayTimeSelected;
            delete [] arrayTimeSelectedHold;
            delete [] arrayTargetHold;
            delete [] arrayTargetHoldInfo;
            delete [] arrayAssociateData;
            
            if (attachedNumberListStatus == 1) delete [] attachedNumberList;
            if (groupNumberListStatus == 1) delete [] groupNumberList;
            
            if (fluorescentMapStatus1 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap1 [counter1];
                delete [] fluorescentMap1;
            }
            
            if (fluorescentMapStatus2 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap2 [counter1];
                delete [] fluorescentMap2;
            }
            
            if (fluorescentMapStatus3 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap3 [counter1];
                delete [] fluorescentMap3;
            }
            
            if (fluorescentMapStatus4 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap4 [counter1];
                delete [] fluorescentMap4;
            }
            
            if (fluorescentMapStatus5 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap5 [counter1];
                delete [] fluorescentMap5;
            }
            
            if (fluorescentMapStatus6 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap6 [counter1];
                delete [] fluorescentMap6;
            }
        }
        else if (trackingOn == 3){
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                delete [] sourceImage [counter1];
                delete [] revisedMap [counter1];
                delete [] revisedWorkingMap [counter1];
            }
            
            delete [] sourceImage;
            delete [] revisedMap;
            delete [] revisedWorkingMap;
            
            delete [] arrayTarget;
            targetStatus = 0;
            
            delete [] arrayPositionRevise;
            delete [] arrayGravityCenterRev;
            delete [] arrayTimeSelected;
            delete [] arrayTimeSelectedHold;
            delete [] arrayTargetHold;
            delete [] arrayTargetHoldInfo;
            delete [] arrayConnectLineageRel;
            delete [] arrayLineageGRCurrent;
            delete [] arrayReferenceLine;
            delete [] arrayEventSequence;
            delete [] arrayEventSequenceHold;
            delete [] arrayLineageGravityCenterCurrentHold;
            
            if (targetPrevHoldStatus == 1){
                delete [] arrayTargetPrevHold;
            }
            
            if (fluorescentMapStatus1 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap1 [counter1];
                delete [] fluorescentMap1;
            }
            
            if (fluorescentMapStatus2 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap2 [counter1];
                delete [] fluorescentMap2;
            }
            
            if (fluorescentMapStatus3 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap3 [counter1];
                delete [] fluorescentMap3;
            }
            
            if (fluorescentMapStatus4 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap4 [counter1];
                delete [] fluorescentMap4;
            }
            
            if (fluorescentMapStatus5 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap5 [counter1];
                delete [] fluorescentMap5;
            }
            
            if (fluorescentMapStatus6 == 1){
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) delete [] fluorescentMap6 [counter1];
                delete [] fluorescentMap6;
            }
        }
        
        if (masterLineForTrackingStatus == 1) delete [] arrayMasterLineForTracking;
        if (masterLineForDisplayStatus == 1) delete [] arrayMasterLineForDisplay;
        if (masterLineGravityCenterStatus == 1) delete [] arrayMasterLineGravityCenter;
        if (masterLineGCDisplayStatus == 1) delete [] arrayMasterLineGravityCenterDisplay;
        if (masterLineSelectedStatus == 1) delete [] arrayMasterLineSelected;
        if (masterLineSelectedDisplayStatus == 1) delete [] arrayMasterLineSelectedDisplay;
        if (xyPositionListStatus == 1) delete [] arrayXYPositionList;
        if (cellLineageInfoStatus == 1) delete [] arrayCellLineageInfo;
        if (connectLineListLocalStatus == 1) delete [] arrayConnectLineListLocal;
        if (lineageDataStatus == 1) delete [] arrayLineageData;
        if (lineageStartEndStatus == 1) delete [] arrayLineageStartEnd;
        if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
        if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
        if (cellEndHoldStatus == 1) delete [] cellEndHold;
        
        delete [] arrayTreatmentStatus;
        delete [] arrayQueueList;
        delete [] arrayQueueListDisplay;
        delete [] arrayDoneList;
        delete [] arrayDoneListDisplay;
        delete [] arrayGetList;
        delete [] arrayImageSizeList;
        delete [] arrayDirectoryInitialInfo;
        delete [] arraySelectedTreatmentProc;
        delete [] arrayDirectoryInfo;
        delete [] arrayTrackingList;
        delete [] arrayIFDataHold;
        delete [] fusionPartnerInfo;
        delete [] arrayMergeSelect;
        delete [] arrayListHold;
        delete [] arrayMitosisSDInfo;
        delete [] arrayMitosisValueInfo;
        delete [] arrayLineTrace;
        
        if (fluorescentCutOffStatus == 1) delete [] arrayFluorescentCutOff;
        
        delete [] arrayFileDelete;
        
        if (revisedWorkingMapStatus2 == 1){
            for (int counter1 = 0; counter1 < revisedWorkingMapSize2+1; counter1++) delete [] revisedWorkingMap2 [counter1];
            delete [] revisedWorkingMap2;
        }
        
        if (lineagePartnerInfoStatus == 1) delete [] arrayLineagePartnerInfo;
        if (lineageDataSearchStatus == 1) delete [] arrayLineageSearchData;
        if (lineageStartEndSearchStatus == 1) delete [] arrayLineageStartEndSearch;
        if (lineageListStatus == 1) delete [] arrayLineageList;
        if (operationDataStatus == 1) delete [] arrayOperationData;
        if (searchCellListStatus == 1) delete [] arraySearchCellList;
        if (listPatternStatus == 1) delete [] arrayListPattern;
        if (timePointListSaveStatus == 1) delete [] arrayTimePointSaveList;
        
        delete [] arrayForAreaSize;
        
        if (checkListStatus == 1) delete [] checkList;
        if (checkResultsStatus == 1) delete [] checkResults;
        if (checkErrorTimeListStatus == 1) delete [] checkErrorTimeList;
        if (listStringStatus == 0) delete [] arrayListString;
        
        if (fluorescentSaveCount != 0){
            fluorescentSaveCount = 0;
            
            if (fluorescentLevelDataCount != 0 && fluorescentSaveCount != 0){
                fluorescentSaveCount = 0;
                
                int readBit [3];
                int dataTemp = 0;
                unsigned long indexCount = 0;
                
                char *writingArray = new char [fluorescentLevelDataCount*2+20];
                
                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                    dataTemp = fluorescentLevelDataHold [counter1*4];
                    
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                    writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                    
                    dataTemp = fluorescentLevelDataHold [counter1*4+3];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                outfile2.write ((char*)writingArray, indexCount);
                outfile2.close();
                
                delete [] writingArray;
            }
        }
        
        if (fluorescentOpInformationStatus == 1) delete [] fluorescentOpInformationHold;
        if (fluorescentLevelDataStatus == 1) delete [] fluorescentLevelDataHold;
        if (autoCheckTempStatus == 1) delete [] autoCheckTemp;
        if (positionExportStatus == 1) delete [] arrayPositionExport;
        if (gravityCenterExportStatus == 1) delete [] arrayGravityCenterExport;
        if (timeSelectedExportStatus == 1) delete [] arrayTimeSelectedExport;
        if (colorListStatus == 1){
            delete [] colorList;
            delete [] cellNoHoldExport;
        }
        
        if (noOfCellsInAreaStatus == 1){
            delete [] noOfCellsInArea;
        }
        
        if (circleAreaHoldStatus == 1){
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++) delete [] circleAreaHold [counter1];
            delete [] circleAreaHold;
        }
        
        if (motilityBasicInfoStatus == 1){
            delete [] arrayMotilityBasicInfo;
        }
        
        delete [] arrayColorRange;
        
        if (particleCountingDataHoldStatus == 1){
            delete [] particleCountingDataHold;
        }
        
        exit (0);
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Save/Load In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
