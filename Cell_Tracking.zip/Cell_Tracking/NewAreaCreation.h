//
// NewAreaCreation.h
// Cell_Tracking
//
// Created by Masahiko Sato on 01/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef NEWAREACREATION_H
#define NEWAREACREATION_H
#import "Controller.h"
#endif

@interface NewAreaCreation : NSObject {
    id fileUpdate;
}

-(void)newAreaLine;

@end
