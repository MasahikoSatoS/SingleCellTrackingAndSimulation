//
//  DatabaseRepairOperation.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 12/6/16.
//
//

#import "DatabaseRepairOperation.h"

NSString *notificationToDatabaseRepairOperation = @"notificationExecuteDatabaseRepairOperation";

@implementation DatabaseRepairOperation

-(id)init{
    self = [super init];
    
    if (self != nil){
        repairOperationTableCount = 0;
        rowRepairOperationTable = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDatabaseRepairOperation object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [tableViewDatabaseRepair setDataSource:self];
    [tableViewDatabaseRepair reloadData];
    
    for (NSTableColumn* column in [tableViewDatabaseRepair tableColumns]) {
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Time" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Treat." attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Lineage." attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Cell" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Connect" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL6"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Error" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL7"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"Comments" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
    
    databaseRepairDisplayTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    //-----Table View for search-----
    if (repairOperationTableCount == 1){
        repairOperationTableCount = 0;
        rowRepairOperationTable = repairOperationTableCurrentRow;
    }
    
    if (repairOperationTableCount > 1) repairOperationTableCount = 0;
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 0;
    tableViewContent = checkListCount/8;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    if (checkListCount/8 > rowIndex){
        string entryNumber1;
        string entryNumber2;
        string entryNumber3;
        string entryNumber4;
        string entryNumber5;
        string entryNumber6;
        string entryNumber7;
        
        if (checkList [rowIndex*8] == -1) entryNumber1 = "LN";
        else entryNumber1 = to_string(checkList [rowIndex*8]);
        
        entryNumber2 = arrayTreatmentStatus [checkList [rowIndex*8+1]*9];
        
        entryNumber3 = to_string(checkList [rowIndex*8+2]);
        
        if (checkList [rowIndex*8+3] == 7) entryNumber4 = "-";
        else entryNumber4 = to_string(checkList [rowIndex*8+3]);
        
        entryNumber5 = to_string(checkList [rowIndex*8+4]);
        
        if (checkList [rowIndex*8+5] >= 1 && checkList [rowIndex*8+5] <= 46){
            entryNumber6 = to_string(checkList [rowIndex*8+5])+": ";
        }
        
        if (checkList [rowIndex*8+5] == 1) entryNumber6 = entryNumber6+"Orphan";
        else if (checkList [rowIndex*8+5] == 2) entryNumber6 = entryNumber6+"Lost sibling";
        else if (checkList [rowIndex*8+5] == 3) entryNumber6 = entryNumber6+"Multiple Mitosis";
        else if (checkList [rowIndex*8+5] == 4) entryNumber6 = entryNumber6+"No mitosis";
        else if (checkList [rowIndex*8+5] == 5) entryNumber6 = entryNumber6+"Fusion partner missing";
        else if (checkList [rowIndex*8+5] == 6) entryNumber6 = entryNumber6+"Connect No does not match";
        else if (checkList [rowIndex*8+5] == 7) entryNumber6 = entryNumber6+"PR may be Corrupted";
        else if (checkList [rowIndex*8+5] == 8) entryNumber6 = entryNumber6+"ST contains 0";
        else if (checkList [rowIndex*8+5] == 9) entryNumber6 = entryNumber6+"PR No corr. Map connect found";
        else if (checkList [rowIndex*8+5] == 10) entryNumber6 = entryNumber6+"PR line open";
        else if (checkList [rowIndex*8+5] == 11) entryNumber6 = entryNumber6+"No PR for Lineage found";
        else if (checkList [rowIndex*8+5] == 12) entryNumber6 = entryNumber6+"Map/PR shape-not match";
        else if (checkList [rowIndex*8+5] == 13) entryNumber6 = entryNumber6+"Overlap PR found";
        else if (checkList [rowIndex*8+5] == 14) entryNumber6 = entryNumber6+"ST may be Corrupted";
        else if (checkList [rowIndex*8+5] == 15) entryNumber6 = entryNumber6+"ST size/connect-not match";
        else if (checkList [rowIndex*8+5] == 16) entryNumber6 = entryNumber6+"ST connect missing";
        else if (checkList [rowIndex*8+5] == 17) entryNumber6 = entryNumber6+"ST connect (>= 11) missing";
        else if (checkList [rowIndex*8+5] == 18) entryNumber6 = entryNumber6+"ST PR position error";
        else if (checkList [rowIndex*8+5] == 19) entryNumber6 = entryNumber6+"ST status info missing";
        else if (checkList [rowIndex*8+5] == 20) entryNumber6 = entryNumber6+"ST lineage info missing";
        else if (checkList [rowIndex*8+5] == 21) entryNumber6 = entryNumber6+"ST status error";
        else if (checkList [rowIndex*8+5] == 22) entryNumber6 = entryNumber6+"ST lineage data fault";
        else if (checkList [rowIndex*8+5] == 23) entryNumber6 = entryNumber6+"GC may be Corrupted";
        else if (checkList [rowIndex*8+5] == 24) entryNumber6 = entryNumber6+"GC size/connect-not match";
        else if (checkList [rowIndex*8+5] == 25) entryNumber6 = entryNumber6+"GC connect missing";
        else if (checkList [rowIndex*8+5] == 26) entryNumber6 = entryNumber6+"GC connect/>= 11 missing";
        else if (checkList [rowIndex*8+5] == 27) entryNumber6 = entryNumber6+"AD may be Corrupted";
        else if (checkList [rowIndex*8+5] == 28) entryNumber6 = entryNumber6+"AD size/connect-not match";
        else if (checkList [rowIndex*8+5] == 29) entryNumber6 = entryNumber6+"AD connect missing";
        else if (checkList [rowIndex*8+5] == 30) entryNumber6 = entryNumber6+"AD connect (>= 11) missing";
        else if (checkList [rowIndex*8+5] == 31) entryNumber6 = entryNumber6+"RL may be Corrupted";
        else if (checkList [rowIndex*8+5] == 32) entryNumber6 = entryNumber6+"No RL for Lineage found";
        else if (checkList [rowIndex*8+5] == 33) entryNumber6 = entryNumber6+"Map contains < 0";
        else if (checkList [rowIndex*8+5] == 34) entryNumber6 = entryNumber6+"Fluo Line data missing";
        else if (checkList [rowIndex*8+5] == 35) entryNumber6 = entryNumber6+"Fluo Area data missing";
        else if (checkList [rowIndex*8+5] == 36) entryNumber6 = entryNumber6+"Fluo Line-may be corrupted";
        else if (checkList [rowIndex*8+5] == 37) entryNumber6 = entryNumber6+"Fluo Area multi. entry";
        //else if (checkList [rowIndex*8+5] == 38) entryNumber6 = entryNumber6+"Fluo Line data (>= 11) missing";
        else if (checkList [rowIndex*8+5] == 39) entryNumber6 = entryNumber6+"Fulo-end data entry error";
        //else if (checkList [rowIndex*8+5] == 40) entryNumber6 = "Lineage-No corr. Map Connect";
        else if (checkList [rowIndex*8+5] == 41) entryNumber6 = entryNumber6+"Fluo Area-may be corrupted";
        else if (checkList [rowIndex*8+5] == 42) entryNumber6 = entryNumber6+"Fluo Area file missing";
        else if (checkList [rowIndex*8+5] == 43) entryNumber6 = entryNumber6+"Fluo Line file missing";
        else if (checkList [rowIndex*8+5] == 44) entryNumber6 = entryNumber6+"Connect No. Error";
        else if (checkList [rowIndex*8+5] == 45) entryNumber6 = entryNumber6+"XY position does not match";
        else if (checkList [rowIndex*8+5] == 46) entryNumber6 = entryNumber6+"PR/GC/ST/RL/AD missing";
        //else if (checkList [rowIndex*8+5] == 47) entryNumber6 = entryNumber6+"Check Map";
        else if (checkList [rowIndex*8+5] == 48) entryNumber6 = "No error found";
        
        if (checkList [rowIndex*8+6] == 1) entryNumber7 = "Use Repair 3";
        else if (checkList [rowIndex*8+6] == 2) entryNumber7 = "Use Rep 15";
        else if (checkList [rowIndex*8+6] == 3) entryNumber7 = "Use Rep 14";
        else if (checkList [rowIndex*8+6] == 4) entryNumber7 = "Use Rep 14/15";
        else if (checkList [rowIndex*8+6] == 5) entryNumber7 = "PR: Check struct.";
        else if (checkList [rowIndex*8+6] == 6) entryNumber7 = "Use Rep 5 or 8B";
        else if (checkList [rowIndex*8+6] == 7) entryNumber7 = "AD: Check struct.";
        else if (checkList [rowIndex*8+6] == 8) entryNumber7 = "Use Rep 2 or 5";
        else if (checkList [rowIndex*8+6] == 9) entryNumber7 = "ST: Check struct.";
        else if (checkList [rowIndex*8+6] == 10) entryNumber7 = "Use Rep 7";
        else if (checkList [rowIndex*8+6] == 11) entryNumber7 = "GC: Check struct.";
        else if (checkList [rowIndex*8+6] == 12) entryNumber7 = "Use Rep 9";
        else if (checkList [rowIndex*8+6] == 13) entryNumber7 = "Use Rep 10";
        else if (checkList [rowIndex*8+6] == 14) entryNumber7 = "RL: Check struct.";
        else if (checkList [rowIndex*8+6] == 15) entryNumber7 = "Use Rep 8";
        else if (checkList [rowIndex*8+6] == 16) entryNumber7 = "Use Rep 11/12/14 or 15";
        else if (checkList [rowIndex*8+6] == 17) entryNumber7 = "F-Line data: Check struct.";
        else if (checkList [rowIndex*8+6] == 18) entryNumber7 = "Use Rep 5/15";
        else if (checkList [rowIndex*8+6] == 19) entryNumber7 = "F-Area data: Check struct.";
        else if (checkList [rowIndex*8+6] == 20) entryNumber7 = "Check error/Rep 14/15";
        else if (checkList [rowIndex*8+6] == 21) entryNumber7 = "If map is OK, use Rep 1 or 8B";
        else if (checkList [rowIndex*8+6] == 22) entryNumber7 = "Check map";
        else if (checkList [rowIndex*8+6] == 23) entryNumber7 = "No error found";
        else if (checkList [rowIndex*8+6] == 24) entryNumber7 = "Check fusion end data";
        else if (checkList [rowIndex*8+6] == 25) entryNumber7 = "Perform cleaning";
        else if (checkList [rowIndex*8+6] == 26) entryNumber7 = "Use Rep 6";
        else if (checkList [rowIndex*8+6] == 27) entryNumber7 = "Use Rep 5";
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber6.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber7.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    repairOperationTableCount++;
    repairOperationTableCurrentRow = rowIndex;
    
    if (repairOperationTableCount == 2){
        repairOperationTableCurrentRow = rowRepairOperationTable;
        treatmentMainDisplayCall = 1;
        
        if (errorTimeModeHold == 2){
            string errorNoString = to_string(checkList [repairOperationTableCurrentRow*8+5]);
            errorNumberHold = checkList [repairOperationTableCurrentRow*8+5];
            
            [errorNoDisplay setStringValue:@(errorNoString.c_str())];
        }
    }
    else{
        
        repairOperationTableCurrentRow = rowIndex;
        treatmentMainDisplayCall = 1;
        
        if (errorTimeModeHold == 2){
            string errorNoString = to_string(checkList [repairOperationTableCurrentRow*8+5]);
            errorNumberHold = checkList [repairOperationTableCurrentRow*8+5];
            
            [errorNoDisplay setStringValue:@(errorNoString.c_str())];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDatabaseRepairOperation object:nil];
}

@end
