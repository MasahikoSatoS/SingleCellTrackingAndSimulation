//
//  ExpandLine.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-01-26.
//
//

#import "ExpandLine.h"

@implementation ExpandLine

-(int)lineExtendTrackType1:(int)groupNoMerge{
    //=====ExpandType == 1: Expand all Lineage lines and save extended line of groupNoMerge, if overlapped lines are found, change these lines=======
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    int processResults = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == groupNoMerge){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == groupNoMerge){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    //=========A
    int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    int dimension2A = 0;
    int dimension2B = 0;
    
    if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
    if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
    
    dimension2A = (dimension2/2)*6;
    dimension2B = ((dimension2+20)/2)*6;
    
    int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
    int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
    int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
    int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
    //==========A
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    //=========B
    int *findReviseConnect = new int [1000];
    for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
    
    int **rangeMatrixA = new int *[dimension2A+4];
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        rangeMatrixA [counter2] = new int [dimension2A+4];
    }
    
    int **rangeMatrixB = new int *[dimension2B+4];
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        rangeMatrixB [counter2] = new int [dimension2B+4];
    }
    
    int *connectAnalysisXA = new int [dimension2A*4];
    int *connectAnalysisYA = new int [dimension2A*4];
    int *connectAnalysisTempXA = new int [dimension2A*4];
    int *connectAnalysisTempYA = new int [dimension2A*4];
    
    int *connectAnalysisXB = new int [dimension2B*4];
    int *connectAnalysisYB = new int [dimension2B*4];
    int *connectAnalysisTempXB = new int [dimension2B*4];
    int *connectAnalysisTempYB = new int [dimension2B*4];
    
    int freePixelFind = 0;
    int processConnectPosition = 0;
    int processConnectPosition2 = 0;
    int maxConnectRevise = 0;
    int findReviseConnectLimit = 1000;
    int connectivityNumberA = 0;
    int connectivityNumberB = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int connectTemp = 0;
    int maxConnect = 0;
    int processConnectNo = 0;
    int findFlag = 0;
    int cutOffFinal = 0;
    
    for (int counter2 = cutStatusFluorescent; counter2 < 240; counter2 = counter2+10){ //====DIC
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                    else rangeMatrixA [counterY][counterX] = -150;
                }
                else rangeMatrixA [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension2B; counterY++){
            for (int counterX = 0; counterX < dimension2B; counterX++){
                if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                    if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                    else rangeMatrixB [counterY][counterX] = -150;
                }
                else rangeMatrixB [counterY][counterX] = 0;
            }
        }
        
        //-----MapA-----
        connectivityNumberA = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] == -150){
                    connectivityNumberA++;
                    rangeMatrixA [counterY][counterX] = connectivityNumberA;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                        rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                        rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                        rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                        rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                        rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                        rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                        rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                        rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                    rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                    rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                    rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                    rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                    rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                    rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                    rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                    rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumberA+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] != 0) connectedPix [rangeMatrixA [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                    
                    if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrixA [counterY][counterX] = 0;
                    
                    if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
            findReviseConnectLimit = maxConnectRevise+50;
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                        if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        if (processConnectPosition != 0){
            freePixelFind = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                            }
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                        }
                    }
                }
            }
            
            //-----MapB-----
            connectivityNumberB = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] == -150){
                        connectivityNumberB++;
                        rangeMatrixB [counterY][counterX] = connectivityNumberB;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                            rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                            rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                            rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                            rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                            rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                            rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                            rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                            rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                        rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                        rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                        rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                        rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                        rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                        rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                        rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                        rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectedPix = new int [connectivityNumberB+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] != 0) connectedPix [rangeMatrixB [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
                else{
                    
                    connectedPix [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPix [connectTemp];
                        else rangeMatrixB [counterY][counterX] = 0;
                        
                        if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPix;
            
            int *findConnectNo2 = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                            if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition2 = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo2 [counter3] > processConnectNo){
                    processConnectNo = findConnectNo2 [counter3];
                    processConnectPosition2 = counter3;
                }
            }
            
            if (processConnectPosition2 != 0){
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                            rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                        }
                    }
                }
                
                findFlag = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 0){
                    cutOffFinal = counter2;
                    
                    delete [] findConnectNo;
                    delete [] findConnectNo2;
                    break;
                }
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo;
                delete [] findConnectNo2;
                break;
            }
            
            delete [] findConnectNo2;
        }
        else{
            
            if (counter2 != 20) cutOffFinal = counter2-10;
            else cutOffFinal = 0;
            
            delete [] findConnectNo;
            break;
        }
        
        delete [] findConnectNo;
    }
    
    delete [] connectAnalysisXA;
    delete [] connectAnalysisYA;
    delete [] connectAnalysisTempXA;
    delete [] connectAnalysisTempYA;
    
    delete [] connectAnalysisXB;
    delete [] connectAnalysisYB;
    delete [] connectAnalysisTempXB;
    delete [] connectAnalysisTempYB;
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        delete [] rangeMatrixA [counter2];
    }
    
    delete [] rangeMatrixA;
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        delete [] rangeMatrixB [counter2];
    }
    
    delete [] rangeMatrixB;
    //-----BB
    
    if (cutOffFinal != 0 && freePixelFind == 1){
        int extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0) extendConnectCount++;
        }
        
        int *extendConnectList = new int [extendConnectCount*2+1];
        extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0){
                extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            }
        }
        
        int connectFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            connectFind = 0;
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]) connectFind = 1;
            }
            
            if (connectFind == 1){
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2]){
                    if (maxPointDimX < expandFluorescentOutline [counter2*4]) maxPointDimX = expandFluorescentOutline [counter2*4];
                    if (minPointDimX > expandFluorescentOutline [counter2*4]) minPointDimX = expandFluorescentOutline [counter2*4];
                    if (maxPointDimY < expandFluorescentOutline [counter2*4+1]) maxPointDimY = expandFluorescentOutline [counter2*4+1];
                    if (minPointDimY > expandFluorescentOutline [counter2*4+1]) minPointDimY = expandFluorescentOutline [counter2*4+1];
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //=======CC
        int **rangeMatrix = new int *[dimension+4];
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            rangeMatrix [counter2] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                    else rangeMatrix [counterY][counterX] = -150;
                }
                else rangeMatrix [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == -150){
                    connectivityNumber++;
                    rangeMatrix [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                        rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                        rangeMatrix [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                        rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                        rangeMatrix [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                        rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                        rangeMatrix [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                        rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                        rangeMatrix [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                    rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                    rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                    rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                    rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                    rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                    rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                    rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                    rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == groupNoMerge){
                        if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        //========CC
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension+1];
            connectivityMapTemp2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == processConnectPosition){
                    connectivityMapTemp [counterY][counterX] = -1;
                }
            }
        }
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
        else endY = imageDimension;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
        else endX = imageDimension;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension) connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
        }
        
        terminationFlag = 0;
        int startOrder = 0;
        int findFreePoint = 0;
        int connectNo = 0;
        int remainingCheck = 0;
        
        do{
            
            for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < startOrder; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            remainingCheck = 0;
            
            for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
            }
            
            if (remainingCheck == 0) terminationFlag = 1;
            
            startOrder++;
            
            if (startOrder == extendConnectCount/2) startOrder = 0;
            
        } while (terminationFlag == 0);
        
        int **connectivityMapHold = new int *[dimension+1];
        for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMapHold [counter1] = new int [dimension+1];
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] == groupNoMerge) connectivityMapTemp2 [counterY][counterX] = 1;
                else connectivityMapTemp2 [counterY][counterX] = 0;
                
                connectivityMapHold [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
            }
        }
        
        //-----Zero Fill-----
        int **connectivityUpdate5 = new int *[dimension+4];
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            connectivityUpdate5 [counter1] = new int [dimension+4];
        }
        
        for (int counterX = 0; counterX < dimension+4; counterX++){
            for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension+2; counterA++){
        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
        //}
        
        int connectTemp2 = 0;
        
        if (connectivityNumber < -1){
            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
            
            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                    
                    if (connectTemp2 < -1){
                        connectTemp2 = connectTemp2*-1;
                        
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                    }
                }
            }
            
            int zeroFillFlag = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            if (zeroFillFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                        
                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] > 0){
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                            connectivityMapHold [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
            }
            
            delete [] connectCheckArray;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
        
        delete [] connectivityUpdate5;
        //-----
        
        int connectivityNumber2 = -3;
        int overlapFind = 0;
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int pixelValueTemp = 0;
        int pixelAreaTemp = 0;
        int expandDataTempCount2 = 0;
        int expandFluorescentOutlineTempCount = 0;
        
        double averageArea = 0;
        
        for (int counter1 = 1; counter1 <= fluorescentEntryCount; counter1++){
            int *overlapList = new int [extendConnectCount+10], overlapListCount = 0;
            for (int counter2 = 0; counter2 < extendConnectCount+10; counter2++) overlapList [counter2] = 0;
            
            if (counter1 > 1){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapHold [counterY][counterX];
                }
            }
            
            int **connectivityMapTemp4 = new int *[dimension+1];
            for (int counter2 = 0; counter2 < dimension+1; counter2++) connectivityMapTemp4 [counter2] = new int [dimension+1];
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] != groupNoMerge){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                        if (expandFluorescentOutline [counter3*4+2] == extendConnectList [counter2*2] && expandFluorescentOutline [counter3*4+3] == counter1){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp4 [counterY][counterX] = 0;
                        }
                        
                        for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                            if (expandFluorescentOutline [counter3*4+2] == extendConnectList [counter2*2] && expandFluorescentOutline [counter3*4+3] == counter1){
                                if (expandFluorescentOutline [counter3*4+1]-verticalStart > 0 && expandFluorescentOutline [counter3*4]-horizontalStart > 0) connectivityMapTemp4 [expandFluorescentOutline [counter3*4+1]-verticalStart][expandFluorescentOutline [counter3*4]-horizontalStart] = 1;
                            }
                        }
                        
                        connectivityNumber2 = -3;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapTemp4 [counterY][counterX] == 0){
                                    connectivityNumber2 = connectivityNumber2+2;
                                    connectivityMapTemp4 [counterY][counterX] = connectivityNumber2;
                                    
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                        connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                        connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                        connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                        connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                
                                                if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                    connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                    connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                    connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                    connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        overlapFind = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapTemp4 [counterY][counterX] > 0 && connectivityMapTemp2 [counterY][counterX] == 1){
                                    overlapFind = 1;
                                    break;
                                }
                            }
                        }
                        
                        if (overlapFind == 1) overlapList [overlapListCount] = extendConnectList [counter2*2], overlapListCount++;
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                        //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
                        //}
                    }
                }
            }
            
            //for (int counterA = 0; counterA < overlapListCount; counterA++) cout<<counterA<<" "<<overlapList [counterA]<<"  Overlap"<<endl;
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] connectivityMapTemp4 [counter2];
            delete [] connectivityMapTemp4;
            
            //-----Connectivity analysis, For Zero-----
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                            connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                            connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                            connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                            connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                    if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            //-----Determine number of pixels-----
            connectivityNumber = connectivityNumber*-1;
            
            connectedPix = new int [connectivityNumber+50];
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                        connectedPix [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            largestConnect = 0;
            largestConnectNo = 0;
            
            for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                if (connectedPix [counter2] > largestConnect){
                    largestConnect = connectedPix [counter2];
                    largestConnectNo = counter2;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPix;
            
            xPositionTempStart = 0;
            yPositionTempStart = 0;
            lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        connectivityMapTemp2 [counterY2][counterX2] = 1;
                        
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else connectivityMapTemp2 [counterY2][counterX2] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
            delete [] newConnectivityMapTemp;
            
            constructedLineCount = 0;
            
            int *arrayNewLines = new int [lineSize*2+50];
            
            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                            connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                            connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                            connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                            connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            int *expandFluorescentOutlineTemp = new int [expandFluorescentOutlineCount+50];
            expandFluorescentOutlineTempCount = 0;
            
            for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                if (expandFluorescentOutline [counter2*4+2] != groupNoMerge || expandFluorescentOutline [counter2*4+3] != counter1){
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4+1], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4+2], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4+3], expandFluorescentOutlineTempCount++;
                }
            }
            
            expandFluorescentOutlineCount = 0;
            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineCount++;
            
            delete [] expandFluorescentOutlineTemp;
            
            for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate expandFluorescentOutlineUpDate];
                }
                
                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                expandFluorescentOutline [expandFluorescentOutlineCount] = groupNoMerge, expandFluorescentOutlineCount++;
                expandFluorescentOutline [expandFluorescentOutlineCount] = counter1, expandFluorescentOutlineCount++;
            }
            
            delete [] arrayNewLines;
            
            pixelValueTemp = 0;
            pixelAreaTemp = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                            if (counter1 == 1){
                                if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 2){
                                if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap2 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 3){
                                if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap3 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 4){
                                if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap4 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 5){
                                if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap5 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 6){
                                if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap6 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                        }
                    }
                }
            }
            
            int *arrayExpandDataTemp2 = new int [expandFluorescentDataCount+50];
            expandDataTempCount2 = 0;
            
            for (int counter2 = 0; counter2 < expandFluorescentDataCount/4; counter2++){
                if (expandFluorescentData [counter2*4] != groupNoMerge || expandFluorescentData [counter2*4+1] != counter1){
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4+1], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4+2], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4+3], expandDataTempCount2++;
                }
            }
            
            expandFluorescentDataCount = 0;
            for (int counter2 = 0; counter2 < expandDataTempCount2; counter2++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp2 [counter2], expandFluorescentDataCount++;
            
            delete [] arrayExpandDataTemp2;
            
            averageArea = pixelValueTemp/(double)pixelAreaTemp;
            
            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate expandFluorescentDataUpDate];
            }
            
            expandFluorescentData [expandFluorescentDataCount] = groupNoMerge, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = counter1, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
            
            if (overlapListCount != 0){
                connectivityMapTemp4 = new int *[dimension+1];
                for (int counter2 = 0; counter2 < dimension+1; counter2++) connectivityMapTemp4 [counter2] = new int [dimension+1];
                
                for (int counter2 = 0; counter2 < overlapListCount; counter2++){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp4 [counterY][counterX] = 0;
                    }
                    
                    for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                        if (expandFluorescentOutline [counter3*4+2] == overlapList [counter2] && expandFluorescentOutline [counter3*4+3] == counter1){
                            if (expandFluorescentOutline [counter3*4+1]-verticalStart > 0 && expandFluorescentOutline [counter3*4]-horizontalStart > 0){
                                connectivityMapTemp4 [expandFluorescentOutline [counter3*4+1]-verticalStart][expandFluorescentOutline [counter3*4]-horizontalStart] = 1;
                            }
                        }
                    }
                    
                    connectivityNumber2 = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == 0){
                                connectivityNumber2 = connectivityNumber2+2;
                                connectivityMapTemp4 [counterY][counterX] = connectivityNumber2;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                    connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                    connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                    connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                    connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == -1) connectivityMapTemp4 [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] > 0 && connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp4 [counterY][counterX] = 0;
                        }
                    }
                    
                    //-----Connectivity analysis, For Zero-----
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectivityMapTemp4 [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                    connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                    connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                    connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                    connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == -1) connectivityMapTemp4 [counterY][counterX] = 0;
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] != 0){
                                if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0) connectivityMapTemp4 [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0) connectivityMapTemp4 [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0) connectivityMapTemp4 [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0) connectivityMapTemp4 [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] > 0) connectivityMapTemp4 [counterY][counterX] = 0;
                            if (connectivityMapTemp4 [counterY][counterX] < 0) connectivityMapTemp4 [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp4 [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                connectivityMapTemp4 [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && connectivityMapTemp4 [counterY2-1][counterX2] == 0){
                                    connectivityMapTemp4 [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && connectivityMapTemp4 [counterY2][counterX2+1] == 0){
                                    connectivityMapTemp4 [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && connectivityMapTemp4 [counterY2+1][counterX2] == 0){
                                    connectivityMapTemp4 [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && connectivityMapTemp4 [counterY2][counterX2-1] == 0){
                                    connectivityMapTemp4 [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //-----Determine number of pixels-----
                    connectivityNumber = connectivityNumber*-1;
                    
                    connectedPix = new int [connectivityNumber+50];
                    for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp4 [counterY2][counterX2] < -1){
                                connectedPix [connectivityMapTemp4 [counterY2][counterX2]*-1]++;
                            }
                        }
                    }
                    
                    newConnectivityMapTemp = new int *[dimension+4];
                    for (int counter3 = 0; counter3 < dimension+4; counter3++) newConnectivityMapTemp [counter3] = new int [dimension+4];
                    
                    for (int counterY = 0; counterY < dimension+4; counterY++){
                        for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                        if (connectedPix [counter3] > largestConnect){
                            largestConnect = connectedPix [counter3];
                            largestConnectNo = counter3;
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (connectivityMapTemp4 [counterY2][counterX2] == largestConnectNo*-1){
                                if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp4 [counterY2-1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                    connectivityMapTemp4 [counterY2-1][counterX2-1] = 0;
                                }
                                if (counterY2-1 >= 0 && connectivityMapTemp4 [counterY2-1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                    connectivityMapTemp4 [counterY2-1][counterX2] = 0;
                                }
                                if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp4 [counterY2-1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                    connectivityMapTemp4 [counterY2-1][counterX2+1] = 0;
                                }
                                if (counterX2+1 < dimension && connectivityMapTemp4 [counterY2][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                    connectivityMapTemp4 [counterY2][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp4 [counterY2+1][counterX2+1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                    connectivityMapTemp4 [counterY2+1][counterX2+1] = 0;
                                }
                                if (counterY2+1 < dimension && connectivityMapTemp4 [counterY2+1][counterX2] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                    connectivityMapTemp4 [counterY2+1][counterX2] = 0;
                                }
                                if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp4 [counterY2+1][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                    connectivityMapTemp4 [counterY2+1][counterX2-1] = 0;
                                }
                                if (counterX2-1 >= 0 && connectivityMapTemp4 [counterY2][counterX2-1] == 1){
                                    newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                    connectivityMapTemp4 [counterY2][counterX2-1] = 0;
                                }
                            }
                        }
                    }
                    
                    delete [] connectedPix;
                    
                    xPositionTempStart = 0;
                    yPositionTempStart = 0;
                    lineSize = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                connectivityMapTemp4 [counterY2][counterX2] = 1;
                                xPositionTempStart = counterX2;
                                yPositionTempStart = counterY2;
                                lineSize++;
                            }
                            else connectivityMapTemp4 [counterY2][counterX2] = 0;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < dimension+4; counter3++) delete [] newConnectivityMapTemp [counter3];
                    delete [] newConnectivityMapTemp;
                    
                    constructedLineCount = 0;
                    
                    arrayNewLines = new int [lineSize*2+50];
                    
                    connectivityMapTemp4 [yPositionTempStart][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    
                    do{
                        
                        findFlag = 0;
                        terminationFlag = 0;
                        
                        if (xPositionTempStart+1 < dimension){
                            if (connectivityMapTemp4 [yPositionTempStart][xPositionTempStart+1] == 1){
                                connectivityMapTemp4 [yPositionTempStart][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                connectivityMapTemp4 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart+1][xPositionTempStart] == 1){
                                connectivityMapTemp4 [yPositionTempStart+1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                connectivityMapTemp4 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart][xPositionTempStart-1] == 1){
                                connectivityMapTemp4 [yPositionTempStart][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                connectivityMapTemp4 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart-1][xPositionTempStart] == 1){
                                connectivityMapTemp4 [yPositionTempStart-1][xPositionTempStart] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                            }
                        }
                        if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                            if (connectivityMapTemp4 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                connectivityMapTemp4 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                                arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                                xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                            }
                        }
                        
                    } while (terminationFlag == 1);
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == -1) connectivityMapTemp4 [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == 0){
                                connectivityNumber = connectivityNumber+2;
                                connectivityMapTemp4 [counterY][counterX] = connectivityNumber;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                    connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                    connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                    connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                    connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == -1) connectivityMapTemp4 [counterY][counterX] = 0;
                        }
                    }
                    
                    expandFluorescentOutlineTemp = new int [expandFluorescentOutlineCount+50];
                    expandFluorescentOutlineTempCount = 0;
                    
                    for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                        if (expandFluorescentOutline [counter3*4+2] != overlapList [counter2] || expandFluorescentOutline [counter3*4+3] != counter1){
                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter3*4], expandFluorescentOutlineTempCount++;
                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter3*4+1], expandFluorescentOutlineTempCount++;
                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter3*4+2], expandFluorescentOutlineTempCount++;
                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter3*4+3], expandFluorescentOutlineTempCount++;
                        }
                    }
                    
                    expandFluorescentOutlineCount = 0;
                    for (int counter3 = 0; counter3 < expandFluorescentOutlineTempCount; counter3++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter3], expandFluorescentOutlineCount++;
                    
                    delete [] expandFluorescentOutlineTemp;
                    
                    for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate expandFluorescentOutlineUpDate];
                        }
                        
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter3*2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter3*2+1], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = overlapList [counter2], expandFluorescentOutlineCount++;
                        expandFluorescentOutline [expandFluorescentOutlineCount] = counter1, expandFluorescentOutlineCount++;
                    }
                    
                    delete [] arrayNewLines;
                    
                    pixelValueTemp = 0;
                    pixelAreaTemp = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] != 0){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                    if (counter1 == 1){
                                        if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY+verticalStart][counterX+horizontalStart];
                                        pixelAreaTemp++;
                                    }
                                    if (counter1 == 2){
                                        if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap2 [counterY+verticalStart][counterX+horizontalStart];
                                        pixelAreaTemp++;
                                    }
                                    if (counter1 == 3){
                                        if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap3 [counterY+verticalStart][counterX+horizontalStart];
                                        pixelAreaTemp++;
                                    }
                                    if (counter1 == 4){
                                        if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap4 [counterY+verticalStart][counterX+horizontalStart];
                                        pixelAreaTemp++;
                                    }
                                    if (counter1 == 5){
                                        if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap5 [counterY+verticalStart][counterX+horizontalStart];
                                        pixelAreaTemp++;
                                    }
                                    if (counter1 == 6){
                                        if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap6 [counterY+verticalStart][counterX+horizontalStart];
                                        pixelAreaTemp++;
                                    }
                                }
                            }
                        }
                    }
                    
                    arrayExpandDataTemp2 = new int [expandFluorescentDataCount+50];
                    expandDataTempCount2 = 0;
                    
                    for (int counter3 = 0; counter3 < expandFluorescentDataCount/4; counter3++){
                        if (expandFluorescentData [counter3*4] != overlapList [counter2] || expandFluorescentData [counter3*4+1] != counter1){
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter3*4], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter3*4+1], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter3*4+2], expandDataTempCount2++;
                            arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter3*4+3], expandDataTempCount2++;
                        }
                    }
                    
                    expandFluorescentDataCount = 0;
                    for (int counter3 = 0; counter3 < expandDataTempCount2; counter3++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp2 [counter3], expandFluorescentDataCount++;
                    
                    delete [] arrayExpandDataTemp2;
                    
                    averageArea = pixelValueTemp/(double)pixelAreaTemp;
                    
                    if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate expandFluorescentDataUpDate];
                    }
                    
                    expandFluorescentData [expandFluorescentDataCount] = overlapList [counter2], expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = counter1, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                    expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                }
                
                for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] connectivityMapTemp4 [counter2];
                delete [] connectivityMapTemp4;
            }
            
            delete [] overlapList;
        }
        
        delete [] extendConnectList;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
            delete [] connectivityMapHold [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        delete [] connectivityMapHold;
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            delete [] rangeMatrix [counter2];
        }
        
        delete [] rangeMatrix;
        
        delete [] findConnectNo;
        
        //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
        //    cout<<" expandFluorescentOutline "<<counterA<<endl;
        //}
    }
    else processResults = 1;
    
    delete [] findReviseConnect;
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    return processResults;
}

-(int)lineExtendTrackType2:(int)groupNoMerge{
    //=====expandType == 2: Expand Lineage lines, exclude area that overlap with existing area=======
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    int processResults = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == groupNoMerge){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == groupNoMerge){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    //=========A
    int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    int dimension2A = 0;
    int dimension2B = 0;
    
    if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
    if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
    
    dimension2A = (dimension2/2)*6;
    dimension2B = ((dimension2+20)/2)*6;
    
    int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
    int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
    int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
    int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
    //==========A
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    //=========B
    int *findReviseConnect = new int [1000];
    for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
    
    int **rangeMatrixA = new int *[dimension2A+4];
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        rangeMatrixA [counter2] = new int [dimension2A+4];
    }
    
    int **rangeMatrixB = new int *[dimension2B+4];
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        rangeMatrixB [counter2] = new int [dimension2B+4];
    }
    
    int *connectAnalysisXA = new int [dimension2A*4];
    int *connectAnalysisYA = new int [dimension2A*4];
    int *connectAnalysisTempXA = new int [dimension2A*4];
    int *connectAnalysisTempYA = new int [dimension2A*4];
    
    int *connectAnalysisXB = new int [dimension2B*4];
    int *connectAnalysisYB = new int [dimension2B*4];
    int *connectAnalysisTempXB = new int [dimension2B*4];
    int *connectAnalysisTempYB = new int [dimension2B*4];
    
    int freePixelFind = 0;
    int processConnectPosition = 0;
    int processConnectPosition2 = 0;
    int maxConnectRevise = 0;
    int findReviseConnectLimit = 1000;
    int connectivityNumberA = 0;
    int connectivityNumberB = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int connectTemp = 0;
    int maxConnect = 0;
    int processConnectNo = 0;
    int findFlag = 0;
    int cutOffFinal = 0;
    
    for (int counter2 = cutStatusFluorescent; counter2 < 240; counter2 = counter2+10){ //====DIC
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                    else rangeMatrixA [counterY][counterX] = -150;
                }
                else rangeMatrixA [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension2B; counterY++){
            for (int counterX = 0; counterX < dimension2B; counterX++){
                if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                    if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                    else rangeMatrixB [counterY][counterX] = -150;
                }
                else rangeMatrixB [counterY][counterX] = 0;
            }
        }
        
        //-----MapA-----
        connectivityNumberA = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] == -150){
                    connectivityNumberA++;
                    rangeMatrixA [counterY][counterX] = connectivityNumberA;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                        rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                        rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                        rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                        rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                        rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                        rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                        rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                        rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                    rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                    rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                    rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                    rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                    rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                    rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                    rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                    rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumberA+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] != 0) connectedPix [rangeMatrixA [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                    
                    if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrixA [counterY][counterX] = 0;
                    
                    if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
            findReviseConnectLimit = maxConnectRevise+50;
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                        if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        if (processConnectPosition != 0){
            freePixelFind = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                            }
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                        }
                    }
                }
            }
            
            //-----MapB-----
            connectivityNumberB = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] == -150){
                        connectivityNumberB++;
                        rangeMatrixB [counterY][counterX] = connectivityNumberB;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                            rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                            rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                            rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                            rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                            rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                            rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                            rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                            rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                        rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                        rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                        rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                        rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                        rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                        rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                        rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                        rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectedPix = new int [connectivityNumberB+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] != 0) connectedPix [rangeMatrixB [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
                else{
                    
                    connectedPix [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPix [connectTemp];
                        else rangeMatrixB [counterY][counterX] = 0;
                        
                        if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPix;
            
            int *findConnectNo2 = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                            if (rangeMatrixB [counterY][counterX] != 0){
                                findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                            }
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition2 = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo2 [counter3] > processConnectNo){
                    processConnectNo = findConnectNo2 [counter3];
                    processConnectPosition2 = counter3;
                }
            }
            
            if (processConnectPosition2 != 0){
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                            rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                        }
                    }
                }
                
                findFlag = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 0){
                    cutOffFinal = counter2;
                    
                    delete [] findConnectNo;
                    delete [] findConnectNo2;
                    break;
                }
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo;
                delete [] findConnectNo2;
                break;
            }
            
            delete [] findConnectNo2;
        }
        else{
            
            if (counter2 != 20) cutOffFinal = counter2-10;
            else cutOffFinal = 0;
            
            delete [] findConnectNo;
            break;
        }
        
        delete [] findConnectNo;
    }
    
    delete [] connectAnalysisXA;
    delete [] connectAnalysisYA;
    delete [] connectAnalysisTempXA;
    delete [] connectAnalysisTempYA;
    
    delete [] connectAnalysisXB;
    delete [] connectAnalysisYB;
    delete [] connectAnalysisTempXB;
    delete [] connectAnalysisTempYB;
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        delete [] rangeMatrixA [counter2];
    }
    
    delete [] rangeMatrixA;
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        delete [] rangeMatrixB [counter2];
    }
    
    delete [] rangeMatrixB;
    //-----BB
    
    if (cutOffFinal != 0 && freePixelFind == 1){
        int extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0) extendConnectCount++;
        }
        
        int *extendConnectList = new int [extendConnectCount*2+1];
        extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0){
                extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            }
        }
        
        int connectFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            connectFind = 0;
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]) connectFind = 1;
            }
            
            if (connectFind == 1){
                int startPosition = arrayTimeSelected [counter1*10+2];
                
                for (int counter2 = startPosition; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2]){
                    if (maxPointDimX < expandFluorescentOutline [counter2*4]) maxPointDimX = expandFluorescentOutline [counter2*4];
                    if (minPointDimX > expandFluorescentOutline [counter2*4]) minPointDimX = expandFluorescentOutline [counter2*4];
                    if (maxPointDimY < expandFluorescentOutline [counter2*4+1]) maxPointDimY = expandFluorescentOutline [counter2*4+1];
                    if (minPointDimY > expandFluorescentOutline [counter2*4+1]) minPointDimY = expandFluorescentOutline [counter2*4+1];
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //=======CC
        int **rangeMatrix = new int *[dimension+4];
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            rangeMatrix [counter2] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                    else rangeMatrix [counterY][counterX] = -150;
                }
                else rangeMatrix [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == -150){
                    connectivityNumber++;
                    rangeMatrix [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                        rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                        rangeMatrix [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                        rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                        rangeMatrix [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                        rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                        rangeMatrix [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                        rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                        rangeMatrix [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                    rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                    rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                    rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                    rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                    rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                    rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                    rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                    rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == groupNoMerge){
                        if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        //========CC
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension+1];
            connectivityMapTemp2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == processConnectPosition) connectivityMapTemp [counterY][counterX] = -1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
        else endY = imageDimension;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
        else endX = imageDimension;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension) connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        terminationFlag = 0;
        int startOrder = 0;
        int findFreePoint = 0;
        int connectNo = 0;
        int remainingCheck = 0;
        
        do{
            
            for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < startOrder; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            remainingCheck = 0;
            
            for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
            }
            
            if (remainingCheck == 0) terminationFlag = 1;
            
            startOrder++;
            
            if (startOrder == extendConnectCount/2) startOrder = 0;
            
        } while (terminationFlag == 0);
        
        int **connectivityMapHold = new int *[dimension+1];
        for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMapHold [counter1] = new int [dimension+1];
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] == groupNoMerge) connectivityMapTemp2 [counterY][counterX] = 1;
                else connectivityMapTemp2 [counterY][counterX] = 0;
                
                connectivityMapHold [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
            }
        }
        
        //-----Zero Fill-----
        int **connectivityUpdate5 = new int *[dimension+4];
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            connectivityUpdate5 [counter1] = new int [dimension+4];
        }
        
        for (int counterX = 0; counterX < dimension+4; counterX++){
            for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension+2; counterA++){
        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
        //}
        
        int connectTemp2 = 0;
        
        if (connectivityNumber < -1){
            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
            
            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                    
                    if (connectTemp2 < -1){
                        connectTemp2 = connectTemp2*-1;
                        
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                    }
                }
            }
            
            int zeroFillFlag = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            if (zeroFillFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                        
                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] > 0){
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                            connectivityMapHold [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
            }
            
            delete [] connectCheckArray;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
        
        delete [] connectivityUpdate5;
        //-----
        
        int connectivityNumber2 = 0;
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int fluorescentLineNoTemp = 0;
        int pixelValueTemp = 0;
        int pixelAreaTemp = 0;
        int expandDataTempCount2 = 0;
        int expandFluorescentOutlineTempCount = 0;
        
        double averageArea = 0;
        
        for (int counter1 = 1; counter1 <= fluorescentEntryCount; counter1++){
            int **connectivityMapTemp4 = new int *[dimension+1];
            for (int counter2 = 0; counter2 < dimension+1; counter2++) connectivityMapTemp4 [counter2] = new int [dimension+1];
            
            if (counter1 > 1){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapHold [counterY][counterX];
                }
            }
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] != groupNoMerge){
                    findFlag = 0;
                    
                    for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                        if (expandFluorescentOutline [counter3*4+2] == extendConnectList [counter2*2] && expandFluorescentOutline [counter3*4+3] == counter1){
                            findFlag = 1;
                            break;
                        }
                    }
                    
                    if (findFlag == 1){
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp4 [counterY][counterX] = 0;
                        }
                        
                        for (int counter3 = 0; counter3 < expandFluorescentOutlineCount/4; counter3++){
                            if (expandFluorescentOutline [counter3*4+2] == extendConnectList [counter2*2] && expandFluorescentOutline [counter3*4+3] == counter1){
                                if (expandFluorescentOutline [counter3*4+1]-verticalStart > 0 && expandFluorescentOutline [counter3*4]-horizontalStart > 0) connectivityMapTemp4 [expandFluorescentOutline [counter3*4+1]-verticalStart][expandFluorescentOutline [counter3*4]-horizontalStart] = 1;
                            }
                        }
                        
                        connectivityNumber2 = -3;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapTemp4 [counterY][counterX] == 0){
                                    connectivityNumber2 = connectivityNumber2+2;
                                    connectivityMapTemp4 [counterY][counterX] = connectivityNumber2;
                                    
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                        connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                        connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                        connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                        connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber2;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                
                                                if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                    connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                    connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                    connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                    connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber2;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapTemp4 [counterY][counterX] > 0 && connectivityMapTemp2 [counterY][counterX] == 1) connectivityMapTemp2 [counterY][counterX] = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                        //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
                        //}
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++) delete [] connectivityMapTemp4 [counter2];
            delete [] connectivityMapTemp4;
            
            //-----Connectivity analysis, For Zero-----
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                            connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                            connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                            connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                            connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                    if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                            connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                            connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
            //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
            //}
            
            //-----Determine number of pixels-----
            connectivityNumber = connectivityNumber*-1;
            
            connectedPix = new int [connectivityNumber+50];
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                        connectedPix [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter2 = 0; counter2 < dimension+4; counter2++) newConnectivityMapTemp [counter2] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            largestConnect = 0;
            largestConnectNo = 0;
            
            for (int counter2 = 2; counter2 <= connectivityNumber; counter2++){
                if (connectedPix [counter2] > largestConnect){
                    largestConnect = connectedPix [counter2];
                    largestConnectNo = counter2;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPix;
            
            xPositionTempStart = 0;
            yPositionTempStart = 0;
            lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        connectivityMapTemp2 [counterY2][counterX2] = 1;
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else connectivityMapTemp2 [counterY2][counterX2] = 0;
                }
            }
            
            for (int counter2 = 0; counter2 < dimension+4; counter2++) delete [] newConnectivityMapTemp [counter2];
            delete [] newConnectivityMapTemp;
            
            constructedLineCount = 0;
            
            int *arrayNewLines = new int [lineSize*2+50];
            
            connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                        
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                            connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                            connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                            connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                            connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                        connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                        connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                        connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                        connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
                }
            }
            
            int *expandFluorescentOutlineTemp = new int [expandFluorescentOutlineCount+50];
            expandFluorescentOutlineTempCount = 0;
            
            fluorescentLineNoTemp = 0;
            
            if (ifEntry == 0) fluorescentLineNoTemp = counter1;
            else if (ifEntry == 1) fluorescentLineNoTemp = counter1+6;
            
            for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                if (expandFluorescentOutline [counter2*4+2] != groupNoMerge || expandFluorescentOutline [counter2*4+3] != fluorescentLineNoTemp){
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4+1], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4+2], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter2*4+3], expandFluorescentOutlineTempCount++;
                }
            }
            
            expandFluorescentOutlineCount = 0;
            for (int counter2 = 0; counter2 < expandFluorescentOutlineTempCount; counter2++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter2], expandFluorescentOutlineCount++;
            
            delete [] expandFluorescentOutlineTemp;
            
            for (int counter2 = 0; counter2 < constructedLineCount/2; counter2++){
                if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate expandFluorescentOutlineUpDate];
                }
                
                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2], expandFluorescentOutlineCount++;
                expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter2*2+1], expandFluorescentOutlineCount++;
                expandFluorescentOutline [expandFluorescentOutlineCount] = groupNoMerge, expandFluorescentOutlineCount++;
                
                if (ifEntry == 0) expandFluorescentOutline [expandFluorescentOutlineCount] = counter1, expandFluorescentOutlineCount++;
                else if (ifEntry == 1) expandFluorescentOutline [expandFluorescentOutlineCount] = counter1+6, expandFluorescentOutlineCount++;
            }
            
            delete [] arrayNewLines;
            
            pixelValueTemp = 0;
            pixelAreaTemp = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapTemp2 [counterY][counterX] != 0){
                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                            if (counter1 == 1){
                                if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 2){
                                if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap2 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 3){
                                if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap3 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 4){
                                if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap4 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 5){
                                if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap5 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                            if (counter1 == 6){
                                if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap6 [counterY+verticalStart][counterX+horizontalStart];
                                pixelAreaTemp++;
                            }
                        }
                    }
                }
            }
            
            int *arrayExpandDataTemp2 = new int [expandFluorescentDataCount+50];
            expandDataTempCount2 = 0;
            
            for (int counter2 = 0; counter2 < expandFluorescentDataCount/4; counter2++){
                if (expandFluorescentData [counter2*4] != groupNoMerge || expandFluorescentData [counter2*4+1] != fluorescentLineNoTemp){
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4+1], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4+2], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter2*4+3], expandDataTempCount2++;
                }
            }
            
            expandFluorescentDataCount = 0;
            for (int counter2 = 0; counter2 < expandDataTempCount2; counter2++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp2 [counter2], expandFluorescentDataCount++;
            
            delete [] arrayExpandDataTemp2;
            
            averageArea = pixelValueTemp/(double)pixelAreaTemp;
            
            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate expandFluorescentDataUpDate];
            }
            
            expandFluorescentData [expandFluorescentDataCount] = groupNoMerge, expandFluorescentDataCount++;
            
            if (ifEntry == 0) expandFluorescentData [expandFluorescentDataCount] = counter1, expandFluorescentDataCount++;
            else if (ifEntry == 1) expandFluorescentData [expandFluorescentDataCount] = counter1+6, expandFluorescentDataCount++;
            
            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
        }
        
        delete [] extendConnectList;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
            delete [] connectivityMapHold [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        delete [] connectivityMapHold;
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            delete [] rangeMatrix [counter2];
        }
        
        delete [] rangeMatrix;
        
        delete [] findConnectNo;
    }
    else processResults = 1;
    
    delete [] findReviseConnect;
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    return processResults;
}

-(int)lineExtendTrackType3:(int)groupNoMerge{
    //=====expandType == 2: Expand Lineage lines, exclude area that overlap with existing area=======
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    int processResults = 0;
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
        if (arrayTimeSelected [counter1*10+8] == groupNoMerge){
            for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == groupNoMerge){
                    if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                    if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                    if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                    if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                }
                else{
                    
                    break;
                }
            }
        }
    }
    
    //=========A
    int horizontalLength2 = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength2 = (maxPointDimY-minPointDimY)/2*2;
    int dimension2 = 0;
    int dimension2A = 0;
    int dimension2B = 0;
    
    if (horizontalLength2 >= verticalLength2) dimension2 = horizontalLength2+10;
    if (horizontalLength2 < verticalLength2) dimension2 = verticalLength2+10;
    
    dimension2A = (dimension2/2)*6;
    dimension2B = ((dimension2+20)/2)*6;
    
    int horizontalStart2A = minPointDimX-(dimension2A-horizontalLength2)/2;
    int verticalStart2A = minPointDimY-(dimension2A-verticalLength2)/2;
    int horizontalStart2B = minPointDimX-(dimension2B-horizontalLength2)/2;
    int verticalStart2B = minPointDimY-(dimension2B-verticalLength2)/2;
    //==========A
    
    int startY = 0;
    int endY = 0;
    int startX = 0;
    int endX = 0;
    
    //=========B
    int *findReviseConnect = new int [1000];
    for (int counter2 = 0; counter2 < 1000; counter2++) findReviseConnect [counter2] = 0;
    
    int **rangeMatrixA = new int *[dimension2A+4];
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        rangeMatrixA [counter2] = new int [dimension2A+4];
    }
    
    int **rangeMatrixB = new int *[dimension2B+4];
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        rangeMatrixB [counter2] = new int [dimension2B+4];
    }
    
    int *connectAnalysisXA = new int [dimension2A*4];
    int *connectAnalysisYA = new int [dimension2A*4];
    int *connectAnalysisTempXA = new int [dimension2A*4];
    int *connectAnalysisTempYA = new int [dimension2A*4];
    
    int *connectAnalysisXB = new int [dimension2B*4];
    int *connectAnalysisYB = new int [dimension2B*4];
    int *connectAnalysisTempXB = new int [dimension2B*4];
    int *connectAnalysisTempYB = new int [dimension2B*4];
    
    int freePixelFind = 0;
    int processConnectPosition = 0;
    int processConnectPosition2 = 0;
    int maxConnectRevise = 0;
    int findReviseConnectLimit = 1000;
    int connectivityNumberA = 0;
    int connectivityNumberB = 0;
    int connectAnalysisCount = 0;
    int terminationFlag = 0;
    int connectAnalysisTempCount = 0;
    int xSource = 0;
    int ySource = 0;
    int connectTemp = 0;
    int maxConnect = 0;
    int processConnectNo = 0;
    int findFlag = 0;
    int cutOffFinal = 0;
    
    for (int counter2 = cutStatusFluorescent; counter2 < 240; counter2 = counter2+10){ //====FLU
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] == 100) rangeMatrixA [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2A][counterX+horizontalStart2A] < counter2) rangeMatrixA [counterY][counterX] = 0;
                    else rangeMatrixA [counterY][counterX] = -150;
                }
                else rangeMatrixA [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension2B; counterY++){
            for (int counterX = 0; counterX < dimension2B; counterX++){
                if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                    if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] == 100) rangeMatrixB [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart2B][counterX+horizontalStart2B] < counter2) rangeMatrixB [counterY][counterX] = 0;
                    else rangeMatrixB [counterY][counterX] = -150;
                }
                else rangeMatrixB [counterY][counterX] = 0;
            }
        }
        
        //-----MapA-----
        connectivityNumberA = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] == -150){
                    connectivityNumberA++;
                    rangeMatrixA [counterY][counterX] = connectivityNumberA;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixA [counterY-1][counterX-1] == -150){
                        rangeMatrixA [counterY-1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrixA [counterY-1][counterX] == -150){
                        rangeMatrixA [counterY-1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension2A && rangeMatrixA [counterY-1][counterX+1] == -150){
                        rangeMatrixA [counterY-1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension2A && rangeMatrixA [counterY][counterX+1] == -150){
                        rangeMatrixA [counterY][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX+1 < dimension2A && rangeMatrixA [counterY+1][counterX+1] == -150){
                        rangeMatrixA [counterY+1][counterX+1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX+1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && rangeMatrixA [counterY+1][counterX] == -150){
                        rangeMatrixA [counterY+1][counterX] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension2A && counterX-1 >= 0 && rangeMatrixA [counterY+1][counterX-1] == -150){
                        rangeMatrixA [counterY+1][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrixA [counterY][counterX-1] == -150){
                        rangeMatrixA [counterY][counterX-1] = connectivityNumberA;
                        connectAnalysisXA [connectAnalysisCount] = counterX-1, connectAnalysisYA [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisXA [counter3], ySource = connectAnalysisYA [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixA [ySource-1][xSource-1] == -150){
                                    rangeMatrixA [ySource-1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrixA [ySource-1][xSource] == -150){
                                    rangeMatrixA [ySource-1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension2A && rangeMatrixA [ySource-1][xSource+1] == -150){
                                    rangeMatrixA [ySource-1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension2A && rangeMatrixA [ySource][xSource+1] == -150){
                                    rangeMatrixA [ySource][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension2A && xSource+1 < dimension2A && rangeMatrixA [ySource+1][xSource+1] == -150){
                                    rangeMatrixA [ySource+1][xSource+1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && rangeMatrixA [ySource+1][xSource] == -150){
                                    rangeMatrixA [ySource+1][xSource] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension2A && xSource-1 >= 0 && rangeMatrixA [ySource+1][xSource-1] == -150){
                                    rangeMatrixA [ySource+1][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrixA [ySource][xSource-1] == -150){
                                    rangeMatrixA [ySource][xSource-1] = connectivityNumberA;
                                    connectAnalysisTempXA [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYA [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisXA [counter3] = connectAnalysisTempXA [counter3], connectAnalysisYA [counter3] = connectAnalysisTempYA [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumberA+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumberA; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (rangeMatrixA [counterY][counterX] != 0) connectedPix [rangeMatrixA [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumberA; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A];
                    
                    if ((connectTemp = rangeMatrixA [counterY][counterX]) != 0) rangeMatrixA [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrixA [counterY][counterX] = 0;
                    
                    if (rangeMatrixA [counterY][counterX] > maxConnect) maxConnect = rangeMatrixA [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
            findReviseConnectLimit = maxConnectRevise+50;
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension2A; counterY++){
            for (int counterX = 0; counterX < dimension2A; counterX++){
                if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == groupNoMerge){
                        if (rangeMatrixA [counterY][counterX] != 0) findConnectNo [rangeMatrixA [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        
        if (processConnectPosition != 0){
            freePixelFind = 0;
            
            for (int counterY = 0; counterY < dimension2A; counterY++){
                for (int counterX = 0; counterX < dimension2A; counterX++){
                    if (rangeMatrixA [counterY][counterX] == processConnectPosition){
                        if (counterY+verticalStart2A >= 0 && counterY+verticalStart2A < imageDimension && counterX+horizontalStart2A >= 0 && counterX+horizontalStart2A < imageDimension){
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] != 0){
                                findReviseConnect [revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A]]++;
                            }
                            
                            if (revisedWorkingMap [counterY+verticalStart2A][counterX+horizontalStart2A] == 0) freePixelFind = 1;
                        }
                    }
                }
            }
            
            //-----MapB-----
            connectivityNumberB = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] == -150){
                        connectivityNumberB++;
                        rangeMatrixB [counterY][counterX] = connectivityNumberB;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrixB [counterY-1][counterX-1] == -150){
                            rangeMatrixB [counterY-1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && rangeMatrixB [counterY-1][counterX] == -150){
                            rangeMatrixB [counterY-1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension2B && rangeMatrixB [counterY-1][counterX+1] == -150){
                            rangeMatrixB [counterY-1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension2B && rangeMatrixB [counterY][counterX+1] == -150){
                            rangeMatrixB [counterY][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX+1 < dimension2B && rangeMatrixB [counterY+1][counterX+1] == -150){
                            rangeMatrixB [counterY+1][counterX+1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX+1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && rangeMatrixB [counterY+1][counterX] == -150){
                            rangeMatrixB [counterY+1][counterX] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension2B && counterX-1 >= 0 && rangeMatrixB [counterY+1][counterX-1] == -150){
                            rangeMatrixB [counterY+1][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && rangeMatrixB [counterY][counterX-1] == -150){
                            rangeMatrixB [counterY][counterX-1] = connectivityNumberB;
                            connectAnalysisXB [connectAnalysisCount] = counterX-1, connectAnalysisYB [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                    xSource = connectAnalysisXB [counter3], ySource = connectAnalysisYB [counter3];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrixB [ySource-1][xSource-1] == -150){
                                        rangeMatrixB [ySource-1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && rangeMatrixB [ySource-1][xSource] == -150){
                                        rangeMatrixB [ySource-1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension2B && rangeMatrixB [ySource-1][xSource+1] == -150){
                                        rangeMatrixB [ySource-1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension2B && rangeMatrixB [ySource][xSource+1] == -150){
                                        rangeMatrixB [ySource][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension2B && xSource+1 < dimension2B && rangeMatrixB [ySource+1][xSource+1] == -150){
                                        rangeMatrixB [ySource+1][xSource+1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource+1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && rangeMatrixB [ySource+1][xSource] == -150){
                                        rangeMatrixB [ySource+1][xSource] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension2B && xSource-1 >= 0 && rangeMatrixB [ySource+1][xSource-1] == -150){
                                        rangeMatrixB [ySource+1][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && rangeMatrixB [ySource][xSource-1] == -150){
                                        rangeMatrixB [ySource][xSource-1] = connectivityNumberB;
                                        connectAnalysisTempXB [connectAnalysisTempCount] = xSource-1, connectAnalysisTempYB [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                    connectAnalysisXB [counter3] = connectAnalysisTempXB [counter3], connectAnalysisYB [counter3] = connectAnalysisTempYB [counter3];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectedPix = new int [connectivityNumberB+50];
            
            for (int counter3 = 0; counter3 <= connectivityNumberB; counter3++) connectedPix [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (rangeMatrixB [counterY][counterX] != 0) connectedPix [rangeMatrixB [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter3 = 1; counter3 <= connectivityNumberB; counter3++){
                if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
                else{
                    
                    connectedPix [counter3] = connectTemp;
                    connectTemp++;
                }
            }
            
            maxConnect = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if ((connectTemp = rangeMatrixB [counterY][counterX]) != 0) rangeMatrixB [counterY][counterX] = connectedPix [connectTemp];
                        else rangeMatrixB [counterY][counterX] = 0;
                        
                        if (rangeMatrixB [counterY][counterX] > maxConnect) maxConnect = rangeMatrixB [counterY][counterX];
                    }
                }
            }
            
            delete [] connectedPix;
            
            int *findConnectNo2 = new int [maxConnect+5];
            for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo2 [counter3] = 0;
            
            for (int counterY = 0; counterY < dimension2B; counterY++){
                for (int counterX = 0; counterX < dimension2B; counterX++){
                    if (counterY+verticalStart2B >= 0 && counterY+verticalStart2B < imageDimension && counterX+horizontalStart2B >= 0 && counterX+horizontalStart2B < imageDimension){
                        if (revisedWorkingMap [counterY+verticalStart2B][counterX+horizontalStart2B] == groupNoMerge){
                            if (rangeMatrixB [counterY][counterX] != 0) findConnectNo2 [rangeMatrixB [counterY][counterX]]++;
                        }
                    }
                }
            }
            
            processConnectNo = 0;
            processConnectPosition2 = 0;
            
            for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
                if (findConnectNo2 [counter3] > processConnectNo){
                    processConnectNo = findConnectNo2 [counter3];
                    processConnectPosition2 = counter3;
                }
            }
            
            if (processConnectPosition2 != 0){
                for (int counterY = 0; counterY < dimension2A; counterY++){
                    for (int counterX = 0; counterX < dimension2A; counterX++){
                        if ((counterY+verticalStart2A)-verticalStart2B >= 0 && (counterY+verticalStart2A)-verticalStart2B < dimension2B && (counterX+horizontalStart2A)-horizontalStart2B >= 0 && (counterX+horizontalStart2A)-horizontalStart2B < dimension2B){
                            rangeMatrixB [(counterY+verticalStart2A)-verticalStart2B][(counterX+horizontalStart2A)-horizontalStart2B] = 0;
                        }
                    }
                }
                
                findFlag = 0;
                
                for (int counterY = 0; counterY < dimension2B; counterY++){
                    for (int counterX = 0; counterX < dimension2B; counterX++){
                        if (rangeMatrixB [counterY][counterX] == processConnectPosition2){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 0){
                    cutOffFinal = counter2;
                    
                    delete [] findConnectNo;
                    delete [] findConnectNo2;
                    break;
                }
            }
            else{
                
                if (counter2 != 20) cutOffFinal = counter2-10;
                else cutOffFinal = 0;
                
                delete [] findConnectNo;
                delete [] findConnectNo2;
                break;
            }
            
            delete [] findConnectNo2;
        }
        else{
            
            if (counter2 != 20) cutOffFinal = counter2-10;
            else cutOffFinal = 0;
            
            delete [] findConnectNo;
            break;
        }
        
        delete [] findConnectNo;
    }
    
    delete [] connectAnalysisXA;
    delete [] connectAnalysisYA;
    delete [] connectAnalysisTempXA;
    delete [] connectAnalysisTempYA;
    
    delete [] connectAnalysisXB;
    delete [] connectAnalysisYB;
    delete [] connectAnalysisTempXB;
    delete [] connectAnalysisTempYB;
    
    for (int counter2 = 0; counter2 < dimension2A+4; counter2++){
        delete [] rangeMatrixA [counter2];
    }
    
    delete [] rangeMatrixA;
    
    for (int counter2 = 0; counter2 < dimension2B+4; counter2++){
        delete [] rangeMatrixB [counter2];
    }
    
    delete [] rangeMatrixB;
    //-----BB
    
    if (cutOffFinal != 0 && freePixelFind == 1){
        int extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0) extendConnectCount++;
        }
        
        int *extendConnectList = new int [extendConnectCount*2+1];
        extendConnectCount = 0;
        
        for (int counter1 = 1; counter1 < maxConnectRevise+1; counter1++){
            if (findReviseConnect [counter1] != 0){
                extendConnectList [extendConnectCount] = counter1, extendConnectCount++;
                extendConnectList [extendConnectCount] = 0, extendConnectCount++;
            }
        }
        
        int connectFind = 0;
        
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            connectFind = 0;
            
            for (int counter2 = 0; counter2 < extendConnectCount/2; counter2++){
                if (extendConnectList [counter2*2] == arrayTimeSelected [counter1*10+8]) connectFind = 1;
            }
            
            if (connectFind == 1){
                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                        if (maxPointDimX < arrayPositionRevise [counter2*7]) maxPointDimX = arrayPositionRevise [counter2*7];
                        if (minPointDimX > arrayPositionRevise [counter2*7]) minPointDimX = arrayPositionRevise [counter2*7];
                        if (maxPointDimY < arrayPositionRevise [counter2*7+1]) maxPointDimY = arrayPositionRevise [counter2*7+1];
                        if (minPointDimY > arrayPositionRevise [counter2*7+1]) minPointDimY = arrayPositionRevise [counter2*7+1];
                    }
                    else{
                        
                        break;
                    }
                }
            }
        }
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2]){
                    if (maxPointDimX < expandFluorescentOutline [counter2*4]) maxPointDimX = expandFluorescentOutline [counter2*4];
                    if (minPointDimX > expandFluorescentOutline [counter2*4]) minPointDimX = expandFluorescentOutline [counter2*4];
                    if (maxPointDimY < expandFluorescentOutline [counter2*4+1]) maxPointDimY = expandFluorescentOutline [counter2*4+1];
                    if (minPointDimY > expandFluorescentOutline [counter2*4+1]) minPointDimY = expandFluorescentOutline [counter2*4+1];
                }
            }
        }
        
        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
        int dimension = 0;
        
        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
        if (horizontalLength < verticalLength) dimension = verticalLength+30;
        
        dimension = (dimension/2)*2;
        
        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
        
        //=======CC
        int **rangeMatrix = new int *[dimension+4];
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            rangeMatrix [counter2] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (sourceImage [counterY+verticalStart][counterX+horizontalStart] == 100) rangeMatrix [counterY][counterX] = 0;
                    else if (sourceImage [counterY+verticalStart][counterX+horizontalStart] < cutOffFinal) rangeMatrix [counterY][counterX] = 0;
                    else rangeMatrix [counterY][counterX] = -150;
                }
                else rangeMatrix [counterY][counterX] = 0;
            }
        }
        
        int *connectAnalysisX = new int [dimension*4];
        int *connectAnalysisY = new int [dimension*4];
        int *connectAnalysisTempX = new int [dimension*4];
        int *connectAnalysisTempY = new int [dimension*4];
        
        int connectivityNumber = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == -150){
                    connectivityNumber++;
                    rangeMatrix [counterY][counterX] = connectivityNumber;
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && counterX-1 >= 0 && rangeMatrix [counterY-1][counterX-1] == -150){
                        rangeMatrix [counterY-1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && rangeMatrix [counterY-1][counterX] == -150){
                        rangeMatrix [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterY-1 >= 0 && counterX+1 < dimension && rangeMatrix [counterY-1][counterX+1] == -150){
                        rangeMatrix [counterY-1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && rangeMatrix [counterY][counterX+1] == -150){
                        rangeMatrix [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX+1 < dimension && rangeMatrix [counterY+1][counterX+1] == -150){
                        rangeMatrix [counterY+1][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && rangeMatrix [counterY+1][counterX] == -150){
                        rangeMatrix [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && counterX-1 >= 0 && rangeMatrix [counterY+1][counterX-1] == -150){
                        rangeMatrix [counterY+1][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && rangeMatrix [counterY][counterX-1] == -150){
                        rangeMatrix [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                
                                if (ySource-1 >= 0 && xSource-1 >= 0 && rangeMatrix [ySource-1][xSource-1] == -150){
                                    rangeMatrix [ySource-1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && rangeMatrix [ySource-1][xSource] == -150){
                                    rangeMatrix [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (ySource-1 >= 0 && xSource+1 < dimension && rangeMatrix [ySource-1][xSource+1] == -150){
                                    rangeMatrix [ySource-1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && rangeMatrix [ySource][xSource+1] == -150){
                                    rangeMatrix [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 > dimension && xSource+1 < dimension && rangeMatrix [ySource+1][xSource+1] == -150){
                                    rangeMatrix [ySource+1][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && rangeMatrix [ySource+1][xSource] == -150){
                                    rangeMatrix [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && xSource-1 >= 0 && rangeMatrix [ySource+1][xSource-1] == -150){
                                    rangeMatrix [ySource+1][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && rangeMatrix [ySource][xSource-1] == -150){
                                    rangeMatrix [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        int *connectedPix = new int [connectivityNumber+50];
        
        for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] != 0) connectedPix [rangeMatrix [counterY][counterX]]++;
            }
        }
        
        //-----Map up-date-----
        connectTemp = 1;
        
        for (int counter3 = 1; counter3 <= connectivityNumber; counter3++){
            if (connectedPix [counter3] < 10) connectedPix [counter3] = 0;
            else{
                
                connectedPix [counter3] = connectTemp;
                connectTemp++;
            }
        }
        
        maxConnect = 0;
        maxConnectRevise = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] > maxConnectRevise) maxConnectRevise = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                    
                    if ((connectTemp = rangeMatrix [counterY][counterX]) != 0) rangeMatrix [counterY][counterX] = connectedPix [connectTemp];
                    else rangeMatrix [counterY][counterX] = 0;
                    
                    if (rangeMatrix [counterY][counterX] > maxConnect) maxConnect = rangeMatrix [counterY][counterX];
                }
            }
        }
        
        delete [] connectedPix;
        
        int *findConnectNo = new int [maxConnect+5];
        for (int counter3 = 0; counter3 < maxConnect+5; counter3++) findConnectNo [counter3] = 0;
        
        if (maxConnectRevise+10 > findReviseConnectLimit){
            delete [] findReviseConnect;
            findReviseConnect = new int [maxConnectRevise+50];
        }
        
        for (int counter3 = 0; counter3 < maxConnectRevise+5; counter3++) findReviseConnect [counter3] = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                    if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == groupNoMerge){
                        if (rangeMatrix [counterY][counterX] != 0) findConnectNo [rangeMatrix [counterY][counterX]]++;
                    }
                }
            }
        }
        
        processConnectNo = 0;
        processConnectPosition = 0;
        
        for (int counter3 = 1; counter3 < maxConnect+1; counter3++){
            if (findConnectNo [counter3] > processConnectNo){
                processConnectNo = findConnectNo [counter3];
                processConnectPosition = counter3;
            }
        }
        //========CC
        
        int **connectivityMapTemp = new int *[dimension+1];
        int **connectivityMapTemp2 = new int *[dimension+1];
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            connectivityMapTemp [counter1] = new int [dimension+1];
            connectivityMapTemp2 [counter1] = new int [dimension+1];
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (rangeMatrix [counterY][counterX] == processConnectPosition) connectivityMapTemp [counterY][counterX] = -1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        // 	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //	cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        if (minPointDimY-30 >= 0) startY = minPointDimY-30;
        else startY = 0;
        
        if (maxPointDimY+30 < imageDimension) endY = maxPointDimY+31;
        else endY = imageDimension;
        
        if (minPointDimX-30 >= 0) startX = minPointDimX-30;
        else startX = 0;
        
        if (maxPointDimX+30 < imageDimension) endX = maxPointDimX+31;
        else endX = imageDimension;
        
        for (int counterY = startY; counterY < endY; counterY++){
            for (int counterX = startX; counterX < endX; counterX++){
                connectFind = 0;
                
                for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                    if (extendConnectList [counter1*2] == revisedWorkingMap [counterY][counterX]) connectFind = 1;
                }
                
                if (connectFind == 1){
                    if (counterY-verticalStart > 0 && counterY-verticalStart < dimension && counterX-horizontalStart > 0 && counterX-horizontalStart < dimension)  connectivityMapTemp [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp2 [counterY][counterX] = connectivityMapTemp [counterY][counterX];
        }
        
        terminationFlag = 0;
        int startOrder = 0;
        int findFreePoint = 0;
        int connectNo = 0;
        int remainingCheck = 0;
        
        do{
            
            for (int counter1 = startOrder; counter1 < extendConnectCount/2; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < startOrder; counter1++){
                connectNo = extendConnectList [counter1*2];
                
                if (extendConnectList [counter1*2+1] == 0){
                    findFreePoint = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp [counterY][counterX] == connectNo){
                                if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMapTemp [counterY-1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMapTemp [counterY-1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY-1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX+1 < dimension && connectivityMapTemp [counterY+1][counterX+1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX+1] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX] = connectNo, findFreePoint = 1;
                                }
                                if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMapTemp [counterY+1][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY+1][counterX-1] = connectNo, findFreePoint = 1;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == -1){
                                    connectivityMapTemp2 [counterY][counterX-1] = connectNo, findFreePoint = 1;
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
                    }
                    
                    if (findFreePoint == 0) extendConnectList [counter1*2+1] = 1;
                }
            }
            
            remainingCheck = 0;
            
            for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
                if (extendConnectList [counter1*2+1] == 0) remainingCheck = 1;
            }
            
            if (remainingCheck == 0) terminationFlag = 1;
            
            startOrder++;
            
            if (startOrder == extendConnectCount/2) startOrder = 0;
            
        } while (terminationFlag == 0);
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
        //    cout<<" connectivityMapTemp "<<counterA<<endl;
        //}
        
        int **connectivityMapHold = new int *[dimension+1];
        for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMapHold [counter1] = new int [dimension+1];
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp [counterY][counterX] == groupNoMerge) connectivityMapTemp2 [counterY][counterX] = 1;
                else connectivityMapTemp2 [counterY][counterX] = 0;
                
                connectivityMapHold [counterY][counterX] = connectivityMapTemp2 [counterY][counterX];
            }
        }
        
        //-----Zero Fill-----
        int **connectivityUpdate5 = new int *[dimension+4];
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            connectivityUpdate5 [counter1] = new int [dimension+4];
        }
        
        for (int counterX = 0; counterX < dimension+4; counterX++){
            for (int counterY = 0; counterY < dimension+4; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++) connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapTemp2 [counterY][counterX];
        }
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                if (connectivityUpdate5 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                        connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                        connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                        connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                        connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                    connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                    connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                    connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                    connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < dimension+2; counterA++){
        //	for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
        //	cout<<" connectivityUpdate5 "<<counterA<<endl;
        //}
        
        int connectTemp2 = 0;
        
        if (connectivityNumber < -1){
            int *connectCheckArray = new int [connectivityNumber*-1*2+5];
            
            for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                    
                    if (connectTemp2 < -1){
                        connectTemp2 = connectTemp2*-1;
                        
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                            else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                        }
                    }
                }
            }
            
            int zeroFillFlag = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            if (zeroFillFlag == 1){
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                        
                        if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                    }
                }
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        if (connectivityUpdate5 [counterY2][counterX2] > 0){
                            connectivityMapTemp2 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                            connectivityMapHold [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
            }
            
            delete [] connectCheckArray;
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivityUpdate5 [counter1];
        
        delete [] connectivityUpdate5;
        //-----
        
        int **connectivityMapTemp4 = new int *[dimension+1];
        for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMapTemp4 [counter1] = new int [dimension+1];
        
        int connectivityNumber2 = 0;
        
        for (int counter1 = 0; counter1 < extendConnectCount/2; counter1++){
            if (extendConnectList [counter1*2] != groupNoMerge){
                findFlag = 0;
                
                if (ifEntry == 0){
                    for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                        if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2] && expandFluorescentOutline [counter2*4+3] == fluorescentDisplayNo){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                else if (ifEntry == 1){
                    for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                        if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2] && expandFluorescentOutline [counter2*4+3] == fluorescentDisplayNo+6){
                            findFlag = 1;
                            break;
                        }
                    }
                }
                
                if (findFlag == 1){
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp4 [counterY][counterX] = 0;
                    }
                    
                    if (ifEntry == 0){
                        for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                            if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2] && expandFluorescentOutline [counter2*4+3] == fluorescentDisplayNo){
                                if (expandFluorescentOutline [counter2*4+1]-verticalStart > 0 && expandFluorescentOutline [counter2*4]-horizontalStart > 0) connectivityMapTemp4 [expandFluorescentOutline [counter2*4+1]-verticalStart][expandFluorescentOutline [counter2*4]-horizontalStart] = 1;
                            }
                        }
                    }
                    else if (ifEntry == 1){
                        for (int counter2 = 0; counter2 < expandFluorescentOutlineCount/4; counter2++){
                            if (expandFluorescentOutline [counter2*4+2] == extendConnectList [counter1*2] && expandFluorescentOutline [counter2*4+3] == fluorescentDisplayNo+6){
                                if (expandFluorescentOutline [counter2*4+1]-verticalStart > 0 && expandFluorescentOutline [counter2*4]-horizontalStart > 0) connectivityMapTemp4 [expandFluorescentOutline [counter2*4+1]-verticalStart][expandFluorescentOutline [counter2*4]-horizontalStart] = 1;
                            }
                        }
                    }
                    
                    connectivityNumber2 = -3;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] == 0){
                                connectivityNumber2 = connectivityNumber2+2;
                                connectivityMapTemp4 [counterY][counterX] = connectivityNumber2;
                                
                                connectAnalysisCount = 0;
                                
                                if (counterY-1 >= 0 && connectivityMapTemp4 [counterY-1][counterX] == 0){
                                    connectivityMapTemp4 [counterY-1][counterX] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                }
                                if (counterX+1 < dimension && connectivityMapTemp4 [counterY][counterX+1] == 0){
                                    connectivityMapTemp4 [counterY][counterX+1] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                if (counterY+1 < dimension && connectivityMapTemp4 [counterY+1][counterX] == 0){
                                    connectivityMapTemp4 [counterY+1][counterX] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                }
                                if (counterX-1 >= 0 && connectivityMapTemp4 [counterY][counterX-1] == 0){
                                    connectivityMapTemp4 [counterY][counterX-1] = connectivityNumber2;
                                    connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                            xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                            
                                            if (ySource-1 >= 0 && connectivityMapTemp4 [ySource-1][xSource] == 0){
                                                connectivityMapTemp4 [ySource-1][xSource] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && connectivityMapTemp4 [ySource][xSource+1] == 0){
                                                connectivityMapTemp4 [ySource][xSource+1] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && connectivityMapTemp4 [ySource+1][xSource] == 0){
                                                connectivityMapTemp4 [ySource+1][xSource] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && connectivityMapTemp4 [ySource][xSource-1] == 0){
                                                connectivityMapTemp4 [ySource][xSource-1] = connectivityNumber2;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                            connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (connectivityMapTemp4 [counterY][counterX] > 0 && connectivityMapTemp2 [counterY][counterX] == 1) connectivityMapTemp2 [counterY][counterX] = 0;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < dimension; counterA++){
                    //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
                    //    cout<<" connectivityMapTemp2 "<<counterA<<endl;
                    //}
                }
            }
        }
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMapTemp4 [counter1];
        delete [] connectivityMapTemp4;
        
        //-----Connectivity analysis, For Zero-----
        connectivityNumber = -3;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                        connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                        connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                        connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                        connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                    connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                    connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                    connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                    connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] != 0){
                    if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    else if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    else if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                    else if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0) connectivityMapTemp2 [counterY][counterX] = -1;
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] > 0) connectivityMapTemp2 [counterY][counterX] = 0;
                if (connectivityMapTemp2 [counterY][counterX] < 0) connectivityMapTemp2 [counterY][counterX] = 1;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp2 [counterA][counterB];
        //	cout<<" connectivityMapTemp2 "<<counterA<<endl;
        //}
        
        connectivityNumber = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (connectivityMapTemp2 [counterY2][counterX2] == 0){
                    connectivityNumber--;
                    connectAnalysisCount = 0;
                    
                    connectivityMapTemp2 [counterY2][counterX2] = connectivityNumber;
                    
                    if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 0){
                        connectivityMapTemp2 [counterY2-1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                    }
                    if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 0){
                        connectivityMapTemp2 [counterY2][counterX2+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 0){
                        connectivityMapTemp2 [counterY2+1][counterX2] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                    }
                    if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 0){
                        connectivityMapTemp2 [counterY2][counterX2-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                    connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                    connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                    connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                    connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Determine number of pixels-----
        connectivityNumber = connectivityNumber*-1;
        
        connectedPix = new int [connectivityNumber+50];
        for (int counter1 = 0; counter1 <= connectivityNumber; counter1++) connectedPix [counter1] = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (connectivityMapTemp2 [counterY2][counterX2] < -1){
                    connectedPix [connectivityMapTemp2 [counterY2][counterX2]*-1]++;
                }
            }
        }
        
        int **newConnectivityMapTemp = new int *[dimension+4];
        for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
        
        for (int counterY = 0; counterY < dimension+4; counterY++){
            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
        }
        
        int largestConnect = 0;
        int largestConnectNo = 0;
        
        for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
            if (connectedPix [counter1] > largestConnect){
                largestConnect = connectedPix [counter1];
                largestConnectNo = counter1;
            }
        }
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (connectivityMapTemp2 [counterY2][counterX2] == largestConnectNo*-1){
                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                        connectivityMapTemp2 [counterY2-1][counterX2-1] = 0;
                    }
                    if (counterY2-1 >= 0 && connectivityMapTemp2 [counterY2-1][counterX2] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                        connectivityMapTemp2 [counterY2-1][counterX2] = 0;
                    }
                    if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapTemp2 [counterY2-1][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                        connectivityMapTemp2 [counterY2-1][counterX2+1] = 0;
                    }
                    if (counterX2+1 < dimension && connectivityMapTemp2 [counterY2][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                        connectivityMapTemp2 [counterY2][counterX2+1] = 0;
                    }
                    if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2+1] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                        connectivityMapTemp2 [counterY2+1][counterX2+1] = 0;
                    }
                    if (counterY2+1 < dimension && connectivityMapTemp2 [counterY2+1][counterX2] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                        connectivityMapTemp2 [counterY2+1][counterX2] = 0;
                    }
                    if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapTemp2 [counterY2+1][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                        connectivityMapTemp2 [counterY2+1][counterX2-1] = 0;
                    }
                    if (counterX2-1 >= 0 && connectivityMapTemp2 [counterY2][counterX2-1] == 1){
                        newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                        connectivityMapTemp2 [counterY2][counterX2-1] = 0;
                    }
                }
            }
        }
        
        delete [] connectedPix;
        
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        
        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                    connectivityMapTemp2 [counterY2][counterX2] = 1;
                    
                    xPositionTempStart = counterX2;
                    yPositionTempStart = counterY2;
                    lineSize++;
                }
                else connectivityMapTemp2 [counterY2][counterX2] = 0;
            }
        }
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
        delete [] newConnectivityMapTemp;
        
        int constructedLineCount = 0;
        
        int *arrayNewLines = new int [lineSize*2+50];
        
        connectivityMapTemp2 [yPositionTempStart][xPositionTempStart] = -1;
        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
        
        do{
            
            findFlag = 0;
            terminationFlag = 0;
            
            if (xPositionTempStart+1 < dimension){
                if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] == 1){
                    connectivityMapTemp2 [yPositionTempStart][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                    connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (yPositionTempStart+1 < dimension && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] == 1){
                    connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                    connectivityMapTemp2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] == 1){
                    connectivityMapTemp2 [yPositionTempStart][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                    connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] == 1){
                    connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                }
            }
            if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                if (connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                    connectivityMapTemp2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                    arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart, constructedLineCount++;
                    arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart, constructedLineCount++;
                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                }
            }
            
        } while (terminationFlag == 1);
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 1;
            }
        }
        
        connectivityNumber = -3;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectivityMapTemp2 [counterY][counterX] = connectivityNumber;
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && connectivityMapTemp2 [counterY-1][counterX] == 0){
                        connectivityMapTemp2 [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivityMapTemp2 [counterY][counterX+1] == 0){
                        connectivityMapTemp2 [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivityMapTemp2 [counterY+1][counterX] == 0){
                        connectivityMapTemp2 [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivityMapTemp2 [counterY][counterX-1] == 0){
                        connectivityMapTemp2 [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivityMapTemp2 [ySource-1][xSource] == 0){
                                    connectivityMapTemp2 [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivityMapTemp2 [ySource][xSource+1] == 0){
                                    connectivityMapTemp2 [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivityMapTemp2 [ySource+1][xSource] == 0){
                                    connectivityMapTemp2 [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivityMapTemp2 [ySource][xSource-1] == 0){
                                    connectivityMapTemp2 [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] == -1) connectivityMapTemp2 [counterY][counterX] = 0;
            }
        }
        
        int *expandFluorescentOutlineTemp = new int [expandFluorescentOutlineCount+50];
        int expandFluorescentOutlineTempCount = 0;
        
        if (ifEntry == 0){
            for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                if (expandFluorescentOutline [counter1*4+2] != groupNoMerge || expandFluorescentOutline [counter1*4+3] != fluorescentDisplayNo){
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+1], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+2], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+3], expandFluorescentOutlineTempCount++;
                }
            }
        }
        else if (ifEntry == 1){
            for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                if (expandFluorescentOutline [counter1*4+2] != groupNoMerge || expandFluorescentOutline [counter1*4+3] != fluorescentDisplayNo+6){
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+1], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+2], expandFluorescentOutlineTempCount++;
                    expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = expandFluorescentOutline [counter1*4+3], expandFluorescentOutlineTempCount++;
                }
            }
        }
        
        expandFluorescentOutlineCount = 0;
        for (int counter1 = 0; counter1 < expandFluorescentOutlineTempCount; counter1++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineTemp [counter1], expandFluorescentOutlineCount++;
        
        delete [] expandFluorescentOutlineTemp;
        
        for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
            if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate expandFluorescentOutlineUpDate];
            }
            
            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter1*2], expandFluorescentOutlineCount++;
            expandFluorescentOutline [expandFluorescentOutlineCount] = arrayNewLines [counter1*2+1], expandFluorescentOutlineCount++;
            expandFluorescentOutline [expandFluorescentOutlineCount] = groupNoMerge, expandFluorescentOutlineCount++;
            
            if (ifEntry == 0) expandFluorescentOutline [expandFluorescentOutlineCount] = fluorescentDisplayNo, expandFluorescentOutlineCount++;
            else if (ifEntry == 1) expandFluorescentOutline [expandFluorescentOutlineCount] = fluorescentDisplayNo+6, expandFluorescentOutlineCount++;
        }
        
        delete [] arrayNewLines;
        
        int pixelValueTemp = 0;
        int pixelAreaTemp = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivityMapTemp2 [counterY][counterX] != 0){
                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                        if (fluorescentDisplayNo == 1){
                            if (fluorescentCutOff1 >= fluorescentMap1 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY+verticalStart][counterX+horizontalStart];
                            pixelAreaTemp++;
                        }
                        if (fluorescentDisplayNo == 2){
                            if (fluorescentCutOff2 >= fluorescentMap2 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap2 [counterY+verticalStart][counterX+horizontalStart];
                            pixelAreaTemp++;
                        }
                        if (fluorescentDisplayNo == 3){
                            if (fluorescentCutOff3 >= fluorescentMap3 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap3 [counterY+verticalStart][counterX+horizontalStart];
                            pixelAreaTemp++;
                        }
                        if (fluorescentDisplayNo == 4){
                            if (fluorescentCutOff4 >= fluorescentMap4 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap4 [counterY+verticalStart][counterX+horizontalStart];
                            pixelAreaTemp++;
                        }
                        if (fluorescentDisplayNo == 5){
                            if (fluorescentCutOff5 >= fluorescentMap5 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap5 [counterY+verticalStart][counterX+horizontalStart];
                            pixelAreaTemp++;
                        }
                        if (fluorescentDisplayNo == 6){
                            if (fluorescentCutOff6 >= fluorescentMap6 [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMap6 [counterY+verticalStart][counterX+horizontalStart];
                            pixelAreaTemp++;
                        }
                    }
                }
            }
        }
        
        int *arrayExpandDataTemp2 = new int [expandFluorescentDataCount+50];
        int expandDataTempCount2 = 0;
        
        if (ifEntry == 0){
            for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                if (expandFluorescentData [counter1*4] != groupNoMerge || expandFluorescentData [counter1*4+1] != fluorescentDisplayNo){
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4+1], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4+2], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4+3], expandDataTempCount2++;
                }
            }
        }
        else if (ifEntry == 1){
            for (int counter1 = 0; counter1 < expandFluorescentDataCount/4; counter1++){
                if (expandFluorescentData [counter1*4] != groupNoMerge || expandFluorescentData [counter1*4+1] != fluorescentDisplayNo+6){
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4+1], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4+2], expandDataTempCount2++;
                    arrayExpandDataTemp2 [expandDataTempCount2] = expandFluorescentData [counter1*4+3], expandDataTempCount2++;
                }
            }
        }
        
        expandFluorescentDataCount = 0;
        for (int counter1 = 0; counter1 < expandDataTempCount2; counter1++) expandFluorescentData [expandFluorescentDataCount] = arrayExpandDataTemp2 [counter1], expandFluorescentDataCount++;
        
        delete [] arrayExpandDataTemp2;
        
        double averageArea = pixelValueTemp/(double)pixelAreaTemp;
        
        if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
            fileUpdate = [[FileUpdate alloc] init];
            [fileUpdate expandFluorescentDataUpDate];
        }
        
        expandFluorescentData [expandFluorescentDataCount] = groupNoMerge, expandFluorescentDataCount++;
        
        if (ifEntry == 0) expandFluorescentData [expandFluorescentDataCount] = fluorescentDisplayNo, expandFluorescentDataCount++;
        else if (ifEntry == 1) expandFluorescentData [expandFluorescentDataCount] = fluorescentDisplayNo+6, expandFluorescentDataCount++;
        
        expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
        expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
        
        delete [] extendConnectList;
        
        for (int counter1 = 0; counter1 < dimension+1; counter1++){
            delete [] connectivityMapTemp [counter1];
            delete [] connectivityMapTemp2 [counter1];
            delete [] connectivityMapHold [counter1];
        }
        
        delete [] connectivityMapTemp;
        delete [] connectivityMapTemp2;
        delete [] connectivityMapHold;
        
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter2 = 0; counter2 < dimension+4; counter2++){
            delete [] rangeMatrix [counter2];
        }
        
        delete [] rangeMatrix;
        
        delete [] findConnectNo;
    }
    else processResults = 1;
    
    delete [] findReviseConnect;
    
    return processResults;
}

@end
