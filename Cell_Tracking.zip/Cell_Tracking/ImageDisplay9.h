//
//  ImageDisplay9.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/5/17.
//
//

#ifndef IMAGEDISPLAY9_H
#define IMAGEDISPLAY9_H
#import "Controller.h" 
#endif

@interface ImageDisplay9 : NSView {
    IBOutlet NSImage *seqImage9;
    
    id merge;
    id lineSet;
    id dataSaveRead;
}

-(void)keyDown:(NSEvent *)event;
-(void)mouseDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)dealloc;

@end
