//
//  QueueSort.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#import "QueueSort.h"

@implementation QueueSort

-(IBAction)queuePrioritySet:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && tableRowHold >= 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (queueListCount/6 > tableRowHold){
            string *queuePriorityUpdate = new string [queueListCount+50];
            int queuePriorityUpdateCount = 0;
            
            queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [tableRowHold*6], queuePriorityUpdateCount++;
            queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [tableRowHold*6+1], queuePriorityUpdateCount++;
            queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [tableRowHold*6+2], queuePriorityUpdateCount++;
            queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [tableRowHold*6+3], queuePriorityUpdateCount++;
            queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [tableRowHold*6+4], queuePriorityUpdateCount++;
            queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [tableRowHold*6+5], queuePriorityUpdateCount++;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (counter1 != tableRowHold){
                    queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [counter1*6], queuePriorityUpdateCount++;
                    queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [counter1*6+1], queuePriorityUpdateCount++;
                    queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [counter1*6+2], queuePriorityUpdateCount++;
                    queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [counter1*6+3], queuePriorityUpdateCount++;
                    queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [counter1*6+4], queuePriorityUpdateCount++;
                    queuePriorityUpdate [queuePriorityUpdateCount] = arrayQueueList [counter1*6+5], queuePriorityUpdateCount++;
                }
            }
            
            queueListCount = 0;
            for (int counter1 = 0; counter1 < queuePriorityUpdateCount; counter1++) arrayQueueList [queueListCount] = queuePriorityUpdate [counter1], queueListCount++;
            
            delete [] queuePriorityUpdate;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [queueListCount*12+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (queueListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)queueAreaSort:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (queueListCount/6 != 0){
            int timeOneSort = 0;
            
            for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                if (arrayTreatmentStatus [counter1*9] == treatmentNameHold){
                    timeOneSort = atoi(arrayTreatmentStatus [counter1*9+4].c_str());
                    break;
                }
            }
            
            string extension = to_string(timeOneSort);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
            
            ifstream fin;
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter3 = 0; counter3 < 6; counter3++){
                sizeForCopy = 0;
                
                if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter3 == 0) size1 = sizeForCopy;
                    else if (counter3 == 1) size2 = sizeForCopy;
                    else if (counter3 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter3 == 3) size1 = sizeForCopy;
                    else if (counter3 == 4) size2 = sizeForCopy;
                    else if (counter3 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            int *arrayPositionReviseTemp = new int [sizeForCopy+50];
            int positionReviseTempCount = 0;
            int *arrayPositionGCTemp = new int [sizeForCopy+50];
            int positionGCTempCount = 0;
            
            if (checkFlag == 1){
                int finData [17];
                readingError = 0;
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    
                    fin.close();
                    
                    if (readingError == 1){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [1], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [3], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [4], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [7], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [12], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [13], positionReviseTempCount++;
                                    arrayPositionReviseTemp [positionReviseTempCount] = finData [16], positionReviseTempCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    arrayPositionGCTemp [positionGCTempCount] = finData [1], positionGCTempCount++;
                                    arrayPositionGCTemp [positionGCTempCount] = finData [3], positionGCTempCount++;
                                    arrayPositionGCTemp [positionGCTempCount] = finData [6], positionGCTempCount++;
                                    arrayPositionGCTemp [positionGCTempCount] = finData [7], positionGCTempCount++;
                                    arrayPositionGCTemp [positionGCTempCount] = finData [10], positionGCTempCount++;
                                    arrayPositionGCTemp [positionGCTempCount] = finData [11], positionGCTempCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            //for (int counterA = 0; counterA < positionGCTempCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayPositionGCTemp [counterA*6+counterB];
            //    cout<<" arrayPositionGCTemp "<<counterA<<endl;
            //}
            
            if (checkFlag == 1 && readingError == 0){
                string connectStatusTemp = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
                
                sizeForCopy = 0;
                
                if (stat(connectStatusTemp.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                int *arrayStatusTemp = new int [sizeForCopy+50];
                int statusTempCount = 0;
                
                if (sizeForCopy != 0){
                    fin.open(connectStatusTemp.c_str(), ios::in | ios::binary);
                    
                    uint8_t *uploadTempA = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTempA, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [19];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTempA [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTempA [readPosition], readPosition++;
                            finData [2] = uploadTempA [readPosition], readPosition++;
                            finData [3] = uploadTempA [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTempA [readPosition], readPosition++;
                            finData [5] = uploadTempA [readPosition], readPosition++;
                            finData [6] = uploadTempA [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTempA [readPosition], readPosition++;
                            finData [8] = uploadTempA [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTempA [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTempA [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTempA [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTempA [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTempA [readPosition], readPosition++;
                            finData [14] = uploadTempA [readPosition], readPosition++;
                            finData [15] = uploadTempA [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTempA [readPosition], readPosition++;
                            finData [17] = uploadTempA [readPosition], readPosition++;
                            finData [18] = uploadTempA [readPosition], readPosition++; //--11 Lineage no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayStatusTemp [statusTempCount] = finData [0], statusTempCount++; //-----Selected, removed, eliminated status-----
                                arrayStatusTemp [statusTempCount] = finData [3], statusTempCount++; //-----When new line is created, enter line number which creates-----
                                arrayStatusTemp [statusTempCount] = finData [6], statusTempCount++; //-----PositionRevise Start-----
                                arrayStatusTemp [statusTempCount] = finData [8], statusTempCount++; //-----Cut line number-----
                                arrayStatusTemp [statusTempCount] = finData [9], statusTempCount++; //-----X Start-----
                                arrayStatusTemp [statusTempCount] = finData [10], statusTempCount++; //-----X End-----
                                arrayStatusTemp [statusTempCount] = finData [11], statusTempCount++; //-----Y Start-----
                                arrayStatusTemp [statusTempCount] = finData [12], statusTempCount++; //-----Y End-----
                                arrayStatusTemp [statusTempCount] = finData [15], statusTempCount++; //-----Connect-----
                                arrayStatusTemp [statusTempCount] = finData [18], statusTempCount++; //-----Lineage-----
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTempA;
                }
                
                //for (int counterA = 0; counterA < statusTempCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayStatusTemp [counterA*10+counterB];
                //    cout<<" arrayStatusTemp "<<counterA<<endl;
                //}
                
                string *arrayQueueListTemp = new string [queueListCount+50];
                int queueListTempCount = 0;
                string *arrayQueueListTemp2 = new string [queueListCount+50];
                int queueListTempCount2 = 0;
                string *arrayQueueListTemp3 = new string [queueListCount+50];
                int queueListTempCount3 = 0;
                string *arrayQueueListTemp4 = new string [queueListCount+50];
                int queueListTempCount4 = 0;
                int *arrayAreaSize = new int [queueListCount+50];
                int areaSizeCount = 0;
                
                string timeOneString = to_string(timeOneHold);
                string imageNoCommTemp;
                
                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                    imageNoCommTemp = arrayQueueList [counter1*6+3];
                    
                    if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
                    
                    if (arrayQueueList [counter1*6] != treatmentNameHold || arrayQueueList [counter1*6+2] != "C000000000" || imageNoCommTemp != timeOneString){
                        arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6], queueListTempCount++;
                        arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+1], queueListTempCount++;
                        arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+2], queueListTempCount++;
                        arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+3], queueListTempCount++;
                        arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+4], queueListTempCount++;
                        arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+5], queueListTempCount++;
                    }
                    else{
                        
                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6], queueListTempCount2++;
                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+1], queueListTempCount2++;
                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+2], queueListTempCount2++;
                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+3], queueListTempCount2++;
                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+4], queueListTempCount2++;
                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+5], queueListTempCount2++;
                    }
                }
                
                // for (int counterA = 0; counterA < queueListTempCount/6; counterA++){
                //     for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp [counterA*6+counterB];
                //     cout<<" arrayQueueListTemp "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < queueListTempCount2/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp2 [counterA*6+counterB];
                //     cout<<" arrayQueueListTemp2 "<<counterA<<endl;
                //}
                
                string lineageNoTemp;
                string cellNoTemp;
                int lineageRevInt = 0;
                int cellNoRevInt = 0;
                int cellStatusTemp = 0;
                int connectNoTemp = 0;
                int findInList = 0;
                int listPosition = 0;
                
                for (int counter1 = 0; counter1 < statusTempCount/10; counter1++){
                    if (arrayStatusTemp [counter1*10] == 1 || arrayStatusTemp [counter1*10] == 7){
                        lineageRevInt = arrayPositionReviseTemp [arrayStatusTemp [counter1*10+2]*7+6];
                        cellNoRevInt = arrayPositionReviseTemp [arrayStatusTemp [counter1*10+2]*7+4];
                        cellStatusTemp = arrayStatusTemp [counter1*10];
                        connectNoTemp = arrayPositionReviseTemp [arrayStatusTemp [counter1*10+2]*7+3];
                        findInList = 0;
                        listPosition = 0;
                        
                        for (int counter2 = 0; counter2 < queueListTempCount2/6; counter2++){
                            lineageNoTemp = arrayQueueListTemp2 [counter2*6+1];
                            lineageNoTemp = lineageNoTemp.substr(1);
                            cellNoTemp = arrayQueueListTemp2 [counter2*6+2];
                            cellNoTemp = cellNoTemp.substr(1);
                            
                            if (lineageRevInt == atoi(lineageNoTemp.c_str()) && cellNoRevInt == atoi(cellNoTemp.c_str())){
                                findInList = 1;
                                listPosition = counter2;
                                break;
                            }
                        }
                        
                        if (findInList == 1){
                            if (cellStatusTemp == 7){
                                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6], queueListTempCount3++;
                                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+1], queueListTempCount3++;
                                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+2], queueListTempCount3++;
                                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+3], queueListTempCount3++;
                                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+4], queueListTempCount3++;
                                arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp2 [listPosition*6+5], queueListTempCount3++;
                            }
                            else{
                                
                                arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6], queueListTempCount4++;
                                arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+1], queueListTempCount4++;
                                arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+2], queueListTempCount4++;
                                arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+3], queueListTempCount4++;
                                arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+4], queueListTempCount4++;
                                arrayQueueListTemp4 [queueListTempCount4] = arrayQueueListTemp2 [listPosition*6+5], queueListTempCount4++;
                                
                                arrayAreaSize [areaSizeCount] = arrayPositionGCTemp [(connectNoTemp-1)*6+2], areaSizeCount++;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < queueListTempCount3/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp3 [counterA*6+counterB];
                //    cout<<" arrayQueueListTemp3 "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < queueListTempCount4/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueListTemp4 [counterA*6+counterB];
                //    cout<<" arrayQueueListTemp4 "<<counterA<<endl;
                //}
                
                int terminationFlag = 0;
                int largestArea = 0;
                int largestConnectNo = 0;
                
                do{
                    
                    largestArea = 0;
                    largestConnectNo = 0;
                    
                    for (int counter1 = 0; counter1 < areaSizeCount; counter1++){
                        if (arrayAreaSize [counter1] > largestArea){
                            largestArea = arrayAreaSize [counter1];
                            largestConnectNo = counter1;
                        }
                    }
                    
                    if (largestArea == 0) terminationFlag = 1;
                    else{
                        
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+1], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+2], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+3], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+4], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp4 [largestConnectNo*6+5], queueListTempCount3++;
                        
                        arrayAreaSize [largestConnectNo] = 0;
                    }
                    
                } while (terminationFlag == 0);
                
                for (int counter1 = 0; counter1 < queueListTempCount3; counter1++) arrayQueueListTemp [queueListTempCount] = arrayQueueListTemp3 [counter1], queueListTempCount++;
                
                queueListTempCount3 = 0;
                
                for (int counter1 = 0; counter1 < queueListTempCount/6; counter1++){
                    if (arrayQueueListTemp [counter1*6] == treatmentNameHold){
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+1], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+2], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+3], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+4], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+5], queueListTempCount3++;
                    }
                }
                
                for (int counter1 = 0; counter1 < queueListTempCount/6; counter1++){
                    if (arrayQueueListTemp [counter1*6] != treatmentNameHold){
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+1], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+2], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+3], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+4], queueListTempCount3++;
                        arrayQueueListTemp3 [queueListTempCount3] = arrayQueueListTemp [counter1*6+5], queueListTempCount3++;
                    }
                }
                
                queueListCount = 0;
                for (int counter1 = 0; counter1 < queueListTempCount3; counter1++) arrayQueueList [queueListCount] = arrayQueueListTemp3 [counter1], queueListCount++;
                
                delete [] arrayQueueListTemp;
                delete [] arrayQueueListTemp2;
                delete [] arrayQueueListTemp3;
                delete [] arrayQueueListTemp4;
                delete [] arrayAreaSize;
                delete [] arrayStatusTemp;
                
                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                //    cout<<" arrayQueueList "<<counterA<<endl;
                //}
                
                if (queueListCount != 0){
                    string *arrayUpDate = new string [queueListCount+10];
                    int upDateCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] != "R"){
                            arrayUpDate [upDateCount] = arrayQueueList [counter1*6], upDateCount++;
                            arrayUpDate [upDateCount] = arrayQueueList [counter1*6+1], upDateCount++;
                            arrayUpDate [upDateCount] = arrayQueueList [counter1*6+2], upDateCount++;
                            arrayUpDate [upDateCount] = arrayQueueList [counter1*6+3], upDateCount++;
                            arrayUpDate [upDateCount] = arrayQueueList [counter1*6+4], upDateCount++;
                            arrayUpDate [upDateCount] = arrayQueueList [counter1*6+5], upDateCount++;
                        }
                    }
                    
                    queueListCount = 0;
                    for (int counter1 = 0; counter1 < upDateCount; counter1++) arrayQueueList [queueListCount] = arrayUpDate [counter1], queueListCount++;
                    delete [] arrayUpDate;
                }
                
                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                //    cout<<" arrayQueueList "<<counterA<<endl;
                //}
                
                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                
                if (queueListCount != 0){
                    char *mainDataEntry = new char [queueListCount*12+10];
                    int totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                        extension = arrayQueueList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                    outfile3.write (mainDataEntry, totalEntryCount);
                    outfile3.close();
                    
                    delete [] mainDataEntry;
                }
                
                trackingTableSetDone = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"File Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            delete [] arrayPositionReviseTemp;
            delete [] arrayPositionGCTemp;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeQueueIFTime:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (queueListCount/6 != 0){
            if (fluorescentDivisionTime != 0){
                string *currentQueueList = new string [queueListCount+10];
                int currentQueueListCount = 0;
                string *treatmentQueue = new string [queueListCount*2+10];
                int treatmentQueueCount = 0;
                string *statusQueue = new string [queueListCount+10];
                int statusQueueCount = 0;
                string *remainingQueueList = new string [queueListCount+10];
                int remainingQueueListCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++) currentQueueList [currentQueueListCount] = arrayQueueList [counter1], currentQueueListCount++;
                
                string treatmentEntry;
                string entryString;
                int entryCount = 0;
                int terminationFlag = 0;
                int entryNumber = 0;
                int findFlag = 0;
                
                do{
                    
                    terminationFlag = 0;
                    entryNumber = 0;
                    findFlag = 0;
                    treatmentEntry = "";
                    
                    for (int counter1 = 0; counter1 < currentQueueListCount/6; counter1++){
                        if (currentQueueList [counter1*6] != "" && findFlag == 0){
                            treatmentEntry = currentQueueList [counter1*6];
                            findFlag = 1;
                            entryCount++;
                            entryNumber++;
                            
                            entryString = to_string(entryCount);
                            
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                            
                            currentQueueList [counter1*6] = "";
                        }
                        else if (currentQueueList [counter1*6] != "" && findFlag == 1 && currentQueueList [counter1*6] == treatmentEntry){
                            entryNumber++;
                            
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                            treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                            
                            currentQueueList [counter1*6] = "";
                        }
                    }
                    
                    if (findFlag == 0) terminationFlag = 1;
                    
                } while (terminationFlag == 0);
                
                string imageNoExtract;
                
                //for (int counterA = 0; counterA < treatmentQueueCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<treatmentQueue [counterA*7+counterB];
                //    cout<<" treatmentQueue "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < treatmentQueueCount/7; counter1++){
                    imageNoExtract = treatmentQueue [counter1*7+3].substr(0, treatmentQueue [counter1*7+3].find(":"));
                    
                    if (atoi(imageNoExtract.c_str()) <= fluorescentDivisionTime){
                        statusQueue [statusQueueCount] = treatmentQueue [counter1*7], statusQueueCount++;
                        statusQueue [statusQueueCount] = treatmentQueue [counter1*7+1], statusQueueCount++;
                        statusQueue [statusQueueCount] = treatmentQueue [counter1*7+2], statusQueueCount++;
                        statusQueue [statusQueueCount] = treatmentQueue [counter1*7+3], statusQueueCount++;
                        statusQueue [statusQueueCount] = treatmentQueue [counter1*7+4], statusQueueCount++;
                        statusQueue [statusQueueCount] = treatmentQueue [counter1*7+5], statusQueueCount++;
                    }
                    else{
                        
                        remainingQueueList [remainingQueueListCount] = treatmentQueue [counter1*7], remainingQueueListCount++;
                        remainingQueueList [remainingQueueListCount] = treatmentQueue [counter1*7+1], remainingQueueListCount++;
                        remainingQueueList [remainingQueueListCount] = treatmentQueue [counter1*7+2], remainingQueueListCount++;
                        remainingQueueList [remainingQueueListCount] = treatmentQueue [counter1*7+3], remainingQueueListCount++;
                        remainingQueueList [remainingQueueListCount] = treatmentQueue [counter1*7+4], remainingQueueListCount++;
                        remainingQueueList [remainingQueueListCount] = treatmentQueue [counter1*7+5], remainingQueueListCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < treatmentQueueCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<statusQueue [counterA*6+counterB];
                //    cout<<" statusQueue "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < remainingQueueListCount/6; counter1++){
                    statusQueue [statusQueueCount] = remainingQueueList [counter1*6], statusQueueCount++;
                    statusQueue [statusQueueCount] = remainingQueueList [counter1*6+1], statusQueueCount++;
                    statusQueue [statusQueueCount] = remainingQueueList [counter1*6+2], statusQueueCount++;
                    statusQueue [statusQueueCount] = remainingQueueList [counter1*6+3], statusQueueCount++;
                    statusQueue [statusQueueCount] = remainingQueueList [counter1*6+4], statusQueueCount++;
                    statusQueue [statusQueueCount] = remainingQueueList [counter1*6+5], statusQueueCount++;
                }
                
                //for (int counterA = 0; counterA < statusQueueCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<statusQueue [counterA*6+counterB];
                //    cout<<" statusQueue "<<counterA<<endl;
                //}
                
                queueListCount = 0;
                for (int counter1 = 0; counter1 < statusQueueCount; counter1++) arrayQueueList [queueListCount] = statusQueue [counter1], queueListCount++;
                
                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                
                if (queueListCount != 0){
                    string extension;
                    
                    char *mainDataEntry = new char [queueListCount*12+10];
                    int totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                        extension = arrayQueueList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile (queueListPath.c_str(), ofstream::binary);
                    outfile.write (mainDataEntry, totalEntryCount);
                    outfile.close();
                    
                    delete [] mainDataEntry;
                }
                
                trackingTableSetDone = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                delete [] currentQueueList;
                delete [] treatmentQueue;
                delete [] statusQueue;
                delete [] remainingQueueList;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"IF Timing Set Needed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            //for (int counterA = 0; counterA < treatmentQueueCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<treatmentQueue [counterA*7+counterB];
            //    cout<<" treatmentQueue "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < currentQueueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<currentQueueList [counterA*6+counterB];
            //    cout<<" currentQueueList "<<counterA<<endl;
            //}
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeQueueList:(id)sender{
    //==========Organize order treatment (from largest), Lineage NO, Cell no==========
    
    if (tableListSwitch == 2 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (queueListCount/6 != 0){
            string *newQueueList = new string [queueListCount+10];
            int newQueueListCount = 0;
            string *currentQueueList = new string [queueListCount+10];
            int currentQueueListCount = 0;
            string *treatmentQueue = new string [queueListCount*2+10];
            int treatmentQueueCount = 0;
            string *statusQueue = new string [queueListCount+10];
            int statusQueueCount = 0;
            string *lineageQueue = new string [queueListCount+10];
            int lineageQueueCount = 0;
            int *entryNumberList = new int [100];
            
            for (int counter1 = 0; counter1 < queueListCount; counter1++) currentQueueList [currentQueueListCount] = arrayQueueList [counter1], currentQueueListCount++;
            
            string treatmentEntry;
            string entryString;
            int entryCount = 0;
            int terminationFlag = 0;
            int entryNumber = 0;
            int findFlag = 0;
            
            do{
                
                terminationFlag = 0;
                entryNumber = 0;
                findFlag = 0;
                treatmentEntry = "";
                
                for (int counter1 = 0; counter1 < currentQueueListCount/6; counter1++){
                    if (currentQueueList [counter1*6] != "" && findFlag == 0){
                        treatmentEntry = currentQueueList [counter1*6];
                        findFlag = 1;
                        entryCount++;
                        entryNumber++;
                        
                        entryString = to_string(entryCount);
                        
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                        
                        currentQueueList [counter1*6] = "";
                    }
                    else if (currentQueueList [counter1*6] != "" && findFlag == 1 && currentQueueList [counter1*6] == treatmentEntry){
                        entryNumber++;
                        
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                        
                        currentQueueList [counter1*6] = "";
                    }
                }
                
                if (findFlag == 0) terminationFlag = 1;
                else entryNumberList [entryCount] = entryNumber;
                
            } while (terminationFlag == 0);
            
            //for (int counterA = 0; counterA < treatmentQueueCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<treatmentQueue [counterA*7+counterB];
            //    cout<<" treatmentQueue "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < currentQueueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<currentQueueList [counterA*6+counterB];
            //    cout<<" currentQueueList "<<counterA<<endl;
            //}
            
            //for (int counterA = 1; counterA <= entryCount; counterA++){
            //    cout<<counterA<<" "<<entryNumberList [counterA]<<" List"<<endl;
            //}
            
            string treatmentNo;
            int largestEntryNumber = 0;
            int largestEntryPosition = 0;
            int terminationFlag2 = 0;
            int smallestLineageNo = 0;
            int terminationFlag3 = 0;
            int smallestCellNo = 0;
            
            do{
                
                terminationFlag = 0;
                largestEntryNumber = 0;
                largestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= entryCount; counter1++){
                    if (largestEntryNumber < entryNumberList [counter1]){
                        largestEntryNumber = entryNumberList [counter1];
                        largestEntryPosition = counter1;
                    }
                }
                
                if (largestEntryPosition == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [largestEntryPosition] = 0;
                    statusQueueCount = 0;
                    
                    for (int counter1 = 0; counter1 < treatmentQueueCount/7; counter1++){
                        treatmentNo = treatmentQueue [counter1*7+6];
                        
                        if (atoi(treatmentNo.c_str()) == largestEntryPosition){
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+1], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+2], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+3], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+4], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+5], statusQueueCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < statusQueueCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<statusQueue [counterA*6+counterB];
                    //    cout<<" statusQueue "<<counterA<<endl;
                    //}
                    
                    do{
                        
                        terminationFlag2 = 0;
                        smallestLineageNo = 100000;
                        
                        for (int counter1 = 0; counter1 < statusQueueCount/6; counter1++){
                            treatmentNo = statusQueue [counter1*6+1];
                            treatmentNo = treatmentNo.substr(1);
                            
                            if (atoi(treatmentNo.c_str()) != 0 && atoi(treatmentNo.c_str()) < smallestLineageNo) smallestLineageNo = atoi(treatmentNo.c_str());
                        }
                        
                        if (smallestLineageNo == 100000) terminationFlag2 = 1;
                        else{
                            
                            lineageQueueCount = 0;
                            
                            for (int counter1 = 0; counter1 < statusQueueCount/6; counter1++){
                                treatmentNo = statusQueue [counter1*6+1];
                                treatmentNo = treatmentNo.substr(1);
                                
                                if (atoi(treatmentNo.c_str()) == smallestLineageNo){
                                    lineageQueue [lineageQueueCount] = statusQueue [counter1*6], lineageQueueCount++;
                                    lineageQueue [lineageQueueCount] = statusQueue [counter1*6+1], lineageQueueCount++;
                                    lineageQueue [lineageQueueCount] = statusQueue [counter1*6+2], lineageQueueCount++;
                                    lineageQueue [lineageQueueCount] = statusQueue [counter1*6+3], lineageQueueCount++;
                                    lineageQueue [lineageQueueCount] = statusQueue [counter1*6+4], lineageQueueCount++;
                                    lineageQueue [lineageQueueCount] = statusQueue [counter1*6+5], lineageQueueCount++;
                                    statusQueue [counter1*6+1] = "L00000";
                                }
                            }
                            
                            do{
                                
                                terminationFlag3 = 0;
                                smallestCellNo = 999999999;
                                
                                for (int counter1 = 0; counter1 < lineageQueueCount/6; counter1++){
                                    treatmentNo = lineageQueue [counter1*6+2];
                                    treatmentNo = treatmentNo.substr(1);
                                    
                                    if (atoi(treatmentNo.c_str()) != -1 && atoi(treatmentNo.c_str()) < smallestCellNo) smallestCellNo = atoi(treatmentNo.c_str());
                                }
                                
                                //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                                //    cout<<" lineageDone "<<counterA<<endl;
                                //}
                                
                                if (smallestCellNo == 999999999) terminationFlag3 = 1;
                                else{
                                    
                                    for (int counter1 = 0; counter1 < lineageQueueCount/6; counter1++){
                                        treatmentNo = lineageQueue [counter1*6+2];
                                        treatmentNo = treatmentNo.substr(1);
                                        
                                        if (atoi(treatmentNo.c_str()) == smallestCellNo){
                                            newQueueList [newQueueListCount] = lineageQueue [counter1*6], newQueueListCount++;
                                            newQueueList [newQueueListCount] = lineageQueue [counter1*6+1], newQueueListCount++;
                                            newQueueList [newQueueListCount] = lineageQueue [counter1*6+2], newQueueListCount++;
                                            newQueueList [newQueueListCount] = lineageQueue [counter1*6+3], newQueueListCount++;
                                            newQueueList [newQueueListCount] = lineageQueue [counter1*6+4], newQueueListCount++;
                                            newQueueList [newQueueListCount] = lineageQueue [counter1*6+5], newQueueListCount++;
                                            lineageQueue [counter1*6+2] = "C-1";
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < newDoneListCount/5; counterA++){
                                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<newDoneList [counterA*5+counterB];
                                    //    cout<<" newDoneList "<<counterA<<endl;
                                    //}
                                }
                                
                            } while (terminationFlag3 == 0);
                        }
                        
                    } while (terminationFlag2 == 0);
                }
                
            } while (terminationFlag == 0);
            
            delete [] currentQueueList;
            delete [] treatmentQueue;
            delete [] statusQueue;
            delete [] lineageQueue;
            delete [] entryNumberList;
            
            //for (int counterA = 0; counterA < newQueueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<newQueueList [counterA*6+counterB];
            //    cout<<" newQueueList "<<counterA<<endl;
            //}
            
            string *queueListUpdateTemp = new string [newQueueListCount+50];
            int queueListUpdateTempCount = 0;
            
            for (int counter1 = 0; counter1 < newQueueListCount/6; counter1++){
                if (newQueueList [counter1*6] == treatmentNameHold){
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+1], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+2], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+3], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+4], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+5], queueListUpdateTempCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < newQueueListCount/6; counter1++){
                if (newQueueList [counter1*6] != treatmentNameHold){
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+1], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+2], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+3], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+4], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+5], queueListUpdateTempCount++;
                }
            }
            
            queueListCount = 0;
            for (int counter1 = 0; counter1 < newQueueListCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
            
            delete [] newQueueList;
            delete [] queueListUpdateTemp;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [queueListCount*12+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (queueListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeQueueEndTime:(id)sender{
    //==========Organize order treatment (from largest), Lineage NO, Cell no==========
    
    if (tableListSwitch == 2 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (queueListCount/6 != 0){
            string *newQueueList = new string [queueListCount+10];
            int newQueueListCount = 0;
            string *currentQueueList = new string [queueListCount+10];
            int currentQueueListCount = 0;
            string *treatmentQueue = new string [queueListCount*2+10];
            int treatmentQueueCount = 0;
            string *statusQueue = new string [queueListCount+10];
            int statusQueueCount = 0;
            int *entryNumberList = new int [100];
            
            for (int counter1 = 0; counter1 < queueListCount; counter1++) currentQueueList [currentQueueListCount] = arrayQueueList [counter1], currentQueueListCount++;
            
            string treatmentEntry;
            string entryString;
            int entryCount = 0;
            int terminationFlag = 0;
            int entryNumber = 0;
            int findFlag = 0;
            
            do{
                
                terminationFlag = 0;
                entryNumber = 0;
                findFlag = 0;
                treatmentEntry = "";
                
                for (int counter1 = 0; counter1 < currentQueueListCount/6; counter1++){
                    if (currentQueueList [counter1*6] != "" && findFlag == 0){
                        treatmentEntry = currentQueueList [counter1*6];
                        findFlag = 1;
                        entryCount++;
                        entryNumber++;
                        
                        entryString = to_string(entryCount);
                        
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                        
                        currentQueueList [counter1*6] = "";
                    }
                    else if (currentQueueList [counter1*6] != "" && findFlag == 1 && currentQueueList [counter1*6] == treatmentEntry){
                        entryNumber++;
                        
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                        
                        currentQueueList [counter1*6] = "";
                    }
                }
                
                if (findFlag == 0) terminationFlag = 1;
                else entryNumberList [entryCount] = entryNumber;
                
            } while (terminationFlag == 0);
            
            //for (int counterA = 0; counterA < treatmentQueueCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<treatmentQueue [counterA*7+counterB];
            //    cout<<" treatmentQueue "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < currentQueueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<currentQueueList [counterA*6+counterB];
            //    cout<<" currentQueueList "<<counterA<<endl;
            //}
            
            //for (int counterA = 1; counterA <= entryCount; counterA++){
            //    cout<<counterA<<" "<<entryNumberList [counterA]<<" List"<<endl;
            //}
            
            string treatmentNo;
            string endTimeNo;
            int largestEntryNumber = 0;
            int largestEntryPosition = 0;
            int terminationFlag2 = 0;
            int smallestLineageNo = 0;
            
            do{
                
                terminationFlag = 0;
                largestEntryNumber = 0;
                largestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= entryCount; counter1++){
                    if (largestEntryNumber < entryNumberList [counter1]){
                        largestEntryNumber = entryNumberList [counter1];
                        largestEntryPosition = counter1;
                    }
                }
                
                if (largestEntryPosition == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [largestEntryPosition] = 0;
                    statusQueueCount = 0;
                    
                    for (int counter1 = 0; counter1 < treatmentQueueCount/7; counter1++){
                        treatmentNo = treatmentQueue [counter1*7+6];
                        
                        if (atoi(treatmentNo.c_str()) == largestEntryPosition){
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+1], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+2], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+3], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+4], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+5], statusQueueCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < statusQueueCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<statusQueue [counterA*6+counterB];
                    //    cout<<" statusQueue "<<counterA<<endl;
                    //}
                    
                    do{
                        
                        terminationFlag2 = 0;
                        smallestLineageNo = 100000;
                        
                        for (int counter1 = 0; counter1 < statusQueueCount/6; counter1++){
                            endTimeNo = statusQueue [counter1*6+3].substr(0, statusQueue [counter1*6+3].find(":"));
                            treatmentNo = statusQueue [counter1*6+1].substr(1);
                            
                            if (atoi(treatmentNo.c_str()) != 0 && atoi(endTimeNo.c_str()) < smallestLineageNo) smallestLineageNo = atoi(endTimeNo.c_str());
                        }
                        
                        if (smallestLineageNo == 100000) terminationFlag2 = 1;
                        else{
                            
                            for (int counter1 = 0; counter1 < statusQueueCount/6; counter1++){
                                endTimeNo = statusQueue [counter1*6+3].substr(0, statusQueue [counter1*6+3].find(":"));
                                
                                if (atoi(endTimeNo.c_str()) == smallestLineageNo){
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+1], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+2], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+3], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+4], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+5], newQueueListCount++;
                                    statusQueue [counter1*6+1] = "0";
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                            //    cout<<" lineageDone "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < newDoneListCount/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<newDoneList [counterA*5+counterB];
                            //    cout<<" newDoneList "<<counterA<<endl;
                            //}
                        }
                        
                    } while (terminationFlag2 == 0);
                }
                
            } while (terminationFlag == 0);
            
            delete [] currentQueueList;
            delete [] treatmentQueue;
            delete [] statusQueue;
            delete [] entryNumberList;
            
            string *queueListUpdateTemp = new string [newQueueListCount+50];
            int queueListUpdateTempCount = 0;
            
            for (int counter1 = 0; counter1 < newQueueListCount/6; counter1++){
                if (newQueueList [counter1*6] == treatmentNameHold){
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+1], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+2], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+3], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+4], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+5], queueListUpdateTempCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < newQueueListCount/6; counter1++){
                if (newQueueList [counter1*6] != treatmentNameHold){
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+1], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+2], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+3], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+4], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+5], queueListUpdateTempCount++;
                }
            }
            
            queueListCount = 0;
            for (int counter1 = 0; counter1 < newQueueListCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
            
            delete [] newQueueList;
            delete [] queueListUpdateTemp;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [queueListCount*12+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (queueListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)organizeQueueCK:(id)sender{
    //==========Organize order treatment (from largest), Lineage NO, Cell no==========
    
    if (tableListSwitch == 2 && trackingOn == 1 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (queueListCount/6 != 0){
            string *newQueueList = new string [queueListCount+10];
            int newQueueListCount = 0;
            string *currentQueueList = new string [queueListCount+10];
            int currentQueueListCount = 0;
            string *treatmentQueue = new string [queueListCount*2+10];
            int treatmentQueueCount = 0;
            string *statusQueue = new string [queueListCount+10];
            int statusQueueCount = 0;
            int *entryNumberList = new int [100];
            
            for (int counter1 = 0; counter1 < queueListCount; counter1++) currentQueueList [currentQueueListCount] = arrayQueueList [counter1], currentQueueListCount++;
            
            string treatmentEntry;
            string entryString;
            int entryCount = 0;
            int terminationFlag = 0;
            int entryNumber = 0;
            int findFlag = 0;
            
            do{
                
                terminationFlag = 0;
                entryNumber = 0;
                findFlag = 0;
                treatmentEntry = "";
                
                for (int counter1 = 0; counter1 < currentQueueListCount/6; counter1++){
                    if (currentQueueList [counter1*6] != "" && findFlag == 0){
                        treatmentEntry = currentQueueList [counter1*6];
                        findFlag = 1;
                        entryCount++;
                        entryNumber++;
                        
                        entryString = to_string(entryCount);
                        
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                        
                        currentQueueList [counter1*6] = "";
                    }
                    else if (currentQueueList [counter1*6] != "" && findFlag == 1 && currentQueueList [counter1*6] == treatmentEntry){
                        entryNumber++;
                        
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+1], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+2], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+3], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+4], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = currentQueueList [counter1*6+5], treatmentQueueCount++;
                        treatmentQueue [treatmentQueueCount] = entryString, treatmentQueueCount++;
                        
                        currentQueueList [counter1*6] = "";
                    }
                }
                
                if (findFlag == 0) terminationFlag = 1;
                else entryNumberList [entryCount] = entryNumber;
                
            } while (terminationFlag == 0);
            
            //for (int counterA = 0; counterA < treatmentQueueCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<treatmentQueue [counterA*7+counterB];
            //    cout<<" treatmentQueue "<<counterA<<endl;
            //}
            
            //for (int counterA = 1; counterA <= entryCount; counterA++){
            //    cout<<counterA<<" "<<entryNumberList [counterA]<<" List"<<endl;
            //}
            
            string treatmentNo;
            string endTimeNo;
            int largestEntryNumber = 0;
            int largestEntryPosition = 0;
            int terminationFlag2 = 0;
            int smallestLineageNo = 0;
            
            do{
                
                terminationFlag = 0;
                largestEntryNumber = 0;
                largestEntryPosition = 0;
                
                for (int counter1 = 1; counter1 <= entryCount; counter1++){
                    if (largestEntryNumber < entryNumberList [counter1]){
                        largestEntryNumber = entryNumberList [counter1];
                        largestEntryPosition = counter1;
                    }
                }
                
                if (largestEntryPosition == 0) terminationFlag = 1;
                else{
                    
                    entryNumberList [largestEntryPosition] = 0;
                    statusQueueCount = 0;
                    
                    for (int counter1 = 0; counter1 < treatmentQueueCount/7; counter1++){
                        treatmentNo = treatmentQueue [counter1*7+6];
                        
                        if (atoi(treatmentNo.c_str()) == largestEntryPosition){
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+1], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+2], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+3], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+4], statusQueueCount++;
                            statusQueue [statusQueueCount] = treatmentQueue [counter1*7+5], statusQueueCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < statusQueueCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<statusQueue [counterA*6+counterB];
                    //    cout<<" statusQueue "<<counterA<<endl;
                    //}
                    
                    do{
                        
                        terminationFlag2 = 0;
                        smallestLineageNo = 100000;
                        
                        for (int counter1 = 0; counter1 < statusQueueCount/6; counter1++){
                            endTimeNo = statusQueue [counter1*6+3].substr(statusQueue [counter1*6+3].find(":")+1);
                            treatmentNo = statusQueue [counter1*6+1].substr(1);
                            
                            if (atoi(treatmentNo.c_str()) != 0 && atoi(endTimeNo.c_str()) < smallestLineageNo) smallestLineageNo = atoi(endTimeNo.c_str());
                        }
                        
                        if (smallestLineageNo == 100000) terminationFlag2 = 1;
                        else{
                            
                            for (int counter1 = 0; counter1 < statusQueueCount/6; counter1++){
                                endTimeNo = statusQueue [counter1*6+3].substr(statusQueue [counter1*6+3].find(":")+1);
                                
                                if (atoi(endTimeNo.c_str()) == smallestLineageNo){
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+1], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+2], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+3], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+4], newQueueListCount++;
                                    newQueueList [newQueueListCount] = statusQueue [counter1*6+5], newQueueListCount++;
                                    statusQueue [counter1*6+1] = "0";
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageDoneCount/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<lineageDone [counterA*5+counterB];
                            //    cout<<" lineageDone "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < newDoneListCount/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<newDoneList [counterA*5+counterB];
                            //    cout<<" newDoneList "<<counterA<<endl;
                            //}
                        }
                        
                    } while (terminationFlag2 == 0);
                }
                
            } while (terminationFlag == 0);
            
            delete [] currentQueueList;
            delete [] treatmentQueue;
            delete [] statusQueue;
            delete [] entryNumberList;
            
            string *queueListUpdateTemp = new string [newQueueListCount+50];
            int queueListUpdateTempCount = 0;
            
            for (int counter1 = 0; counter1 < newQueueListCount/6; counter1++){
                if (newQueueList [counter1*6] == treatmentNameHold){
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+1], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+2], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+3], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+4], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+5], queueListUpdateTempCount++;
                }
            }
            
            for (int counter1 = 0; counter1 < newQueueListCount/6; counter1++){
                if (newQueueList [counter1*6] != treatmentNameHold){
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+1], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+2], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+3], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+4], queueListUpdateTempCount++;
                    queueListUpdateTemp [queueListUpdateTempCount] = newQueueList [counter1*6+5], queueListUpdateTempCount++;
                }
            }
            
            queueListCount = 0;
            for (int counter1 = 0; counter1 < newQueueListCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
            
            delete [] newQueueList;
            delete [] queueListUpdateTemp;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                string extension;
                
                char *mainDataEntry = new char [queueListCount*12+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (queueListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            trackingTableSetDone = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Select List"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)queueDisplayAll:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && tableRowHold >= 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        queueDisplayOptions = 0;
        
        [queueOptionCheck setStringValue:@"AL"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)queueDisplayTreatment:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && tableRowHold >= 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        queueDisplayOptions = 1;
        
        [queueOptionCheck setStringValue:@"TR"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)queueDisplayCheck:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && tableRowHold >= 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        queueDisplayOptions = 2;
        
        [queueOptionCheck setStringValue:@"CK"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)queueDisplayFluoTime:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && tableRowHold >= 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        queueDisplayOptions = 3;
        
        [queueOptionCheck setStringValue:@"TE"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)queueDisplayAuto:(id)sender{
    if (tableListSwitch == 2 && trackingOn == 1 && tableRowHold >= 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        queueDisplayOptions = 4;
        autoCheckFlag = 0;
        
        [queueOptionCheck setStringValue:@"AU"];
        
        dataSaveRead = [[DataSaveRead alloc] init];
        [dataSaveRead saveTrackingCurrent];
        
        trackingTableSetDone = 1;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        if (tableListSwitch != 2){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Queue Mode"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing or Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

@end
