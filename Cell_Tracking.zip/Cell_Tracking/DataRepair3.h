//
//  DataRepair3.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#ifndef DATABASEREPAIR3_H
#define DATABASEREPAIR3_H
#import "Controller.h"
#endif

@interface DataRepair3 : NSObject{
    IBOutlet NSTextField *replaceFromTextDisplay;
    IBOutlet NSTextField *replaceToTextDisplay;
    IBOutlet NSTextField *replaceLineFromDisplay;
    IBOutlet NSTextField *replaceLineToDisplay;
    IBOutlet NSTextField *removeLineFromDisplay;
    IBOutlet NSTextField *removeLineToDisplay;
    
    IBOutlet NSTextField *lingNoSetDisplay;
    IBOutlet NSTextField *cellNoSetDisplay;
    IBOutlet NSTextField *timeSetDisplay;
    IBOutlet NSTextField *connectNoSetDisplay;
    IBOutlet NSTextField *channelNoSetDisplay;
    
    id fileUpdate;
    id dataRepairReadWrite;
    id dataRepairProcess;
}

-(IBAction)dataRepair12:(id)sender;
-(IBAction)dataRepair13:(id)sender;
-(IBAction)dataRepair14:(id)sender;
-(IBAction)dataRepair15:(id)sender;

@end
