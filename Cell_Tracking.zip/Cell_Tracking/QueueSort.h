//
//  QueueSort.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#ifndef QUEUESORT_H
#define QUEUESORT_H
#import "Controller.h"
#endif

@interface QueueSort : NSObject{
    IBOutlet NSTextField *queueOptionCheck;
    
    id dataSaveRead;
}

-(IBAction)queuePrioritySet:(id)sender;
-(IBAction)queueAreaSort:(id)sender;
-(IBAction)organizeQueueIFTime:(id)sender;
-(IBAction)organizeQueueList:(id)sender;
-(IBAction)organizeQueueEndTime:(id)sender;
-(IBAction)organizeQueueCK:(id)sender;
-(IBAction)queueDisplayAll:(id)sender;
-(IBAction)queueDisplayTreatment:(id)sender;
-(IBAction)queueDisplayCheck:(id)sender;
-(IBAction)queueDisplayAuto:(id)sender;

@end
