//
//  ImageListTable.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-02-10.
//
//

#ifndef IMAGELISTTABLE_H
#define IMAGELISTTABLE_H
#import "Controller.h"
#endif

@interface ImageListTable : NSObject <NSTableViewDataSource> {
    IBOutlet NSTableView *initialViewList;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
