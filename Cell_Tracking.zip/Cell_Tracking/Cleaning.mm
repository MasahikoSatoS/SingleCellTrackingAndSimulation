//
// Cleaning.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 15/11/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "Cleaning.h"

@implementation Cleaning

-(void)cleaningMain{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        cleaningProgress = 1;
        errorNoHold = 0;
        
        string *queueListClean;
        string *doneListClean;
        int *lineageClean;
        int *lineageStartEndClean;
        int *lineageStatusClean;
        int *arrayMitosisTemp;
        string *arrayLineagePartnerInfoTemp;
        int *autoCheckCleanTemp;
        int *lineageFolderList;
        
        string *lineageFolderListTemp;
        string *arrayFolderContentList;
        string *arrayLineagePartnerInfoTemp2;
        
        int *lineageNoRef;
        int *cellStatusTemp;
        int *amendTimeList;
        int *cellAmendTemp;
        int **revisedMapTemp;
        int *masterDataClean;
        int *masterGCenterClean;
        int *masterAssClean;
        int *masterStatusClean;
        int *masterRelClean;
        int *connectNoRef;
        int *masterDataCleanTemp;
        int *masterGCenterCleanTemp;
        int *masterAssCleanTemp;
        int *masterStatusCleanTemp;
        int *arrayExpandTemp2;
        int *arrayExpandDataTemp;
        int *arrayMitosisTemp2;
        int *masterRelCleanTemp;
        
        char *uploadTempChar;
        char *mainDataEntry;
        char *dataHoldMap;
        char *writingArray;
        uint8_t *uploadTemp;
        uint8_t *upload2;
        uint8_t *uploadTemp2;
        
        struct stat sizeOfFile;
        
        ifstream fin;
        ofstream oin;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
        string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
        string dataString;
        
        long sizeForQueue = 0;
        long sizeForDone = 0;
        
        if (stat(queueListPath.c_str(), &sizeOfFile) == 0){
            sizeForQueue = sizeOfFile.st_size;
        }
        
        if (stat(doneListPath.c_str(), &sizeOfFile) == 0){
            sizeForDone = sizeOfFile.st_size;
        }
        
        queueListClean = new string [sizeForQueue+50];
        int queueListCleanCount = 0;
        
        doneListClean = new string [sizeForDone+50];
        int doneListCleanCount = 0;
        
        if (sizeForQueue != 0){
            fin.open(queueListPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uploadTempChar = new char [sizeForQueue+50];
                
                fin.read((char*)uploadTempChar, sizeForQueue+50);
                fin.close();
                
                dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTempChar [readPosition] != 10) dataString = dataString+uploadTempChar [readPosition];
                    else if (dataString != "End"){
                        queueListClean [queueListCleanCount] = dataString, queueListCleanCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTempChar;
            }
        }
        
        if (sizeForDone != 0){
            fin.open(doneListPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uploadTempChar = new char [sizeForDone];
                
                fin.read((char*)uploadTempChar, sizeForDone);
                fin.close();
                
                dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTempChar [readPosition] != 10) dataString = dataString+uploadTempChar [readPosition];
                    else if (dataString != "End"){
                        doneListClean [doneListCleanCount] = dataString, doneListCleanCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTempChar;
            }
        }
        
        //for (int counterA = 0; counterA < queueListCleanCount/6; counterA++){
        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<queueListClean [counterA*6+counterB];
        //    cout<<" queueListClean "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < doneListCleanCount/5; counterA++){
        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<doneListClean [counterA*5+counterB];
        //    cout<<" doneListClean "<<counterA<<endl;
        //}
        
        //**********QUEU and DONE Upload check***********
        progressValue = (treatmentStatusCount/9)*4+1;
        progressTiming = 1;
        
        do usleep(10);
        while (progressTiming == 1);
        
        string lingDataPath;
        string connectStartEndPath;
        string lingStatusPath;
        string mitosisDataPath;
        string fusionPartnerPath;
        string autoCheckPath;
        string treatmentNameClear;
        string entry;
        string entry2;
        string entry3;
        string numberExtract;
        string clearLineage;
        string lineageFolderPath;
        string lineageFolderPath2;
        string clearLineage2;
        string folderPath;
        string folderPath2;
        string folderPath3;
        string extension;
        string extension2;
        string lineageFilePath;
        string connectStatusDataPath;
        string connectRelationPath;
        string connectMapPath;
        string lineageDataExtract;
        string treatmentNameGet;
        string lineageNoGet;
        string cellNoGet;
        string imageNoGet;
        string partnerLingNoGet;
        string partnerCellNoGet;
        string setTypeGet;
        string cellNumberString;
        string ifProcessingStatus;
        string getString;
        
        int lineageCleanCount = 0;
        int lineageStartEndCleanCount = 0;
        int lineageStatusCleanCount = 0;
        int mitosisTempCount = 0;
        int lineagePartnerInfoTempCount = 0;
        int autoCheckCleanTempCount = 0;
        int imageEndClean = 0;
        int imageTimeOneClean = 0;
        int commonDataUploadCheck = 0;
        int checkFlag = 0;
        int uploadCheckFlag = 0;
        int lineageFolderListCount = 0;
        int folderLingMatchFind = 0;
        int folderLingMatchFind2 = 0;
        int folderContentCount = 0;
        int indicatorCount = 0;
        int stepCount = 0;
        int finData [25];
        int readPosition2 = 0;
        int maxLineageNo = 0;
        int lineageNoRevise = 0;
        int cellFindFlag = 0;
        int cellFindFlag2 = 0;
        int totalEntryCount = 0;
        int cellStatusTempCount = 0;
        int masterDataCleanCount = 0;
        int masterGCenterCleanCount = 0;
        int masterAssCleanCount = 0;
        int connectNoRevise = 0;
        int masterDataCleanTempCount = 0;
        int masterGCenterCleanTempCount = 0;
        int masterAssCleanTempCount = 0;
        int readBit [4];
        int dataTemp = 0;
        int masterStatusCleanTempCount = 0;
        int connectNoTemp = 0;
        int masterRelCleanTempCount = 0;
        int cellAmendTempCount = 0;
        int imageSizeTreat= 0;
        int finData2 = 0;
        int yDimensionCount = 0;
        int xDimensionCount = 0;
        int readCount = 0;
        int dataTemp2 = 0;
        int entryCount = 0;
        int expandTempCount2 = 0;
        int lineagePartnerInfoTempCount2 = 0;
        int terminationFlag = 0;
        int mitosisTempCount2 = 0;
        int totalMapSizeTemp = 0;
        int amendFileCount = 0;
        int amendTimeListCount = 0;
        int renameCheck = 0;
        int newConnectNo = 0;
        int masterStatusCleanCount = 0;
        int masterRelCleanCount = 0;
        
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        
        unsigned long readPosition = 0;
        unsigned long indexCount = 0;
        
        double increment2 = 0;
        
        //**********Process each treatment*********
        //clock_t time1, time2, time3, time4, time5, time6, time7, time8, time9;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            treatmentNameClear = arrayTreatmentStatus [counter1*9];
            imageEndClean = atoi(arrayTreatmentStatus [counter1*9+8].c_str());
            imageTimeOneClean = atoi(arrayTreatmentStatus [counter1*9+4].c_str());
            
            /*
             Uploading 6 files
             1.Lineage data
             2.LineageStartEnd
             3.Lineage status
             4.MitosisData
             5.FusionPartner
             6.AutoCheckData
             
             If uploading of those are OK, process files in Connect and Treat folders.
             */
            
            commonDataUploadCheck = 0;
            
            //******Lineage data******
            lingDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+ analysisID+"_"+treatmentNameClear+"_LineageData";
            
            // time1 = clock();
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter2 = 0; counter2 < 6; counter2++){
                sizeForCopy = 0;
                
                if (stat(lingDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter2 == 0) size1 = sizeForCopy;
                    else if (counter2 == 1) size2 = sizeForCopy;
                    else if (counter2 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter2 == 3) size1 = sizeForCopy;
                    else if (counter2 == 4) size2 = sizeForCopy;
                    else if (counter2 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            lineageClean = new int [100];
            lineageCleanCount = 0;
            
            if (checkFlag == 1){
                uploadCheckFlag = 0;
                
                delete [] lineageClean;
                lineageClean = new int [sizeForCopy+50];
                fin.open(lingDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                            uploadCheckFlag = 1;
                        }
                    }
                    
                    fin.close();
                    
                    if (uploadCheckFlag == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++;
                                finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++;
                                finData [17] = uploadTemp [readPosition], readPosition++;
                                finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                finData [19] = uploadTemp [readPosition], readPosition++;
                                finData [20] = uploadTemp [readPosition], readPosition++;
                                finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                finData [22] = uploadTemp [readPosition], readPosition++;
                                finData [23] = uploadTemp [readPosition], readPosition++;
                                finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                
                                if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                else finData [2] = finData [1]*256+finData [2];
                                
                                if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                else finData [5] = finData [4]*256+finData [5];
                                
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                
                                if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                
                                finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    lineageClean [lineageCleanCount] = finData [2], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [5], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [7], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [8], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [13], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [18], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [21], lineageCleanCount++;
                                    lineageClean [lineageCleanCount] = finData [24], lineageCleanCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    else commonDataUploadCheck = 1;
                    
                    delete [] uploadTemp;
                }
                else commonDataUploadCheck = 1;
            }
            else if (stat(lingDataPath.c_str(), &sizeOfFile) == 0) commonDataUploadCheck = 1;
            
            //time2 = clock();
            //cout<<time2-time1<< " t2"<<endl;
            
            //for (int counterA = 0; counterA < lineageCleanCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageClean [counterA*8+counterB];
            //    cout<<" lineageClean "<<counterA<<endl;
            //}
            
            //******Start/end data******
            connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+ analysisID+"_"+treatmentNameClear+"_LineageStartEnd";
            
            lineageStartEndClean = new int [50];
            lineageStartEndCleanCount = 0;
            
            if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                delete [] lineageStartEndClean;
                lineageStartEndClean = new int [sizeForCopy+50];
                
                fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uploadTempChar = new char [sizeForCopy+50];
                    
                    fin.read((char*)uploadTempChar, sizeForCopy+50);
                    fin.close();
                    
                    dataString = "";
                    readPosition2 = 0;
                    
                    do{
                        
                        if (uploadTempChar [readPosition2] != 10) dataString = dataString+uploadTempChar [readPosition2];
                        else if (dataString != "End") lineageStartEndClean [lineageStartEndCleanCount] = atoi(dataString.c_str()), lineageStartEndCleanCount++, dataString = "";
                        
                        readPosition2++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTempChar;
                }
                else commonDataUploadCheck = 1;
            }
            else if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0) commonDataUploadCheck = 1;
            
            //******Status data******
            lingStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+ analysisID+"_"+treatmentNameClear+"_LineageStatus";
            
            lineageStatusClean = new int [50];
            lineageStatusCleanCount = 0;
            
            sizeForCopy = 0;
            
            if (stat(lingStatusPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                delete [] lineageStatusClean;
                lineageStatusClean = new int [sizeForCopy+50];
                
                fin.open(lingStatusPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uploadTempChar = new char [sizeForCopy+50];
                    
                    fin.read((char*)uploadTempChar, sizeForCopy+50);
                    fin.close();
                    
                    dataString = "";
                    readPosition2 = 0;
                    
                    do{
                        
                        if (uploadTempChar [readPosition2] != 10) dataString = dataString+uploadTempChar [readPosition2];
                        else if (dataString != "End"){
                            lineageStatusClean [lineageStatusCleanCount] = atoi(dataString.c_str()), lineageStatusCleanCount++;
                            dataString = "";
                        }
                        
                        readPosition2++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTempChar;
                }
                else commonDataUploadCheck = 1;
            }
            else if (stat(lingStatusPath.c_str(), &sizeOfFile) == 0) commonDataUploadCheck = 1;
            
            //time3 = clock();
            //cout<<time3-time2<< " t3"<<endl;
            
            indicatorCount++;
            
            progressValue = indicatorCount;
            progressTiming = 3;
            
            usleep(1000);
            
            //******Mitosis Set array******
            mitosisDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+ analysisID+"_"+treatmentNameClear+"_MitosisData";
            
            arrayMitosisTemp = new int [50];
            mitosisTempCount = 0;
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter2 = 0; counter2 < 6; counter2++){
                sizeForCopy = 0;
                
                if (stat(mitosisDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter2 == 0) size1 = sizeForCopy;
                    else if (counter2 == 1) size2 = sizeForCopy;
                    else if (counter2 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter2 == 3) size1 = sizeForCopy;
                    else if (counter2 == 4) size2 = sizeForCopy;
                    else if (counter2 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                delete [] arrayMitosisTemp;
                arrayMitosisTemp = new int [sizeForCopy+50];
                
                fin.open(mitosisDataPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, lineageNoGet);
                        
                        if (lineageNoGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, setTypeGet);
                            
                            arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                            arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
            }
            else if (stat(mitosisDataPath.c_str(), &sizeOfFile) == 0) commonDataUploadCheck = 1;
            
            //******Lineage Partner******
            fusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+ analysisID+"_"+treatmentNameClear+"_FusionPartner";
            
            arrayLineagePartnerInfoTemp = new string [50];
            lineagePartnerInfoTempCount = 0;
            
            sizeForCopy = 0;
            
            if (stat(fusionPartnerPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                delete [] arrayLineagePartnerInfoTemp;
                arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                
                fin.open(fusionPartnerPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    do{
                        
                        terminationFlag = 1;
                        getline(fin, treatmentNameGet);
                        
                        if (treatmentNameGet == "") terminationFlag = 0;
                        else{
                            
                            getline(fin, lineageNoGet);
                            getline(fin, cellNoGet);
                            getline(fin, imageNoGet);
                            getline(fin, partnerLingNoGet);
                            getline(fin, partnerCellNoGet);
                            
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                            arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                        }
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
            }
            
            //******AutoCheck******
            autoCheckPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_AutoCheckData";
            
            autoCheckCleanTemp = new int [50];
            autoCheckCleanTempCount = 0;
            
            if (stat(autoCheckPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                delete [] autoCheckCleanTemp;
                autoCheckCleanTemp = new int [sizeForCopy+50];
                
                fin.open(autoCheckPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    do{
                        
                        terminationFlag = 1;
                        
                        getline(fin, getString);
                        
                        if (getString != ""){
                            autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----Time
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----Lineage no
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----cell no
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----event type
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----x position
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----y position
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----area
                            getline(fin, getString), autoCheckCleanTemp [autoCheckCleanTempCount] = atoi(getString.c_str()), autoCheckCleanTempCount++; //----average
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    fin.close();
                }
            }
            
            // time4 = clock();
            // cout<<time4-time3<< " t4"<<endl;
            
            //for (int counterA = 0; counterA < lineageStartEndCleanCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageStartEndClean [counterA*8+counterB];
            //    cout<<" lineageStartEndClean "<<counterA<<endl;
            //}
            
            //clock_t time10, time11, time12, time13, time14, time15, time16, time17, time18;
            
            if (commonDataUploadCheck == 0){
                //========Create updated lineage no ref=========
                maxLineageNo = 0;
                
                //time10 = clock();
                
                for (int counter2 = 0; counter2 < lineageStartEndCleanCount/8; counter2++){
                    if (lineageStartEndClean [counter2*8] > maxLineageNo) maxLineageNo = lineageStartEndClean [counter2*8];
                }
                
                lineageNoRef = new int [maxLineageNo*2+10];
                
                for (int counter2 = 0; counter2 < maxLineageNo*2+10; counter2++) lineageNoRef [counter2] = 0;
                
                for (int counter2 = 0; counter2 < lineageStartEndCleanCount/8; counter2++){
                    lineageNoRef [lineageStartEndClean [counter2*8]*2] = lineageStartEndClean [counter2*8];
                }
                
                //time11 = clock();
                //cout<<time11-time10<< " t11"<<endl;
                
                lineageNoRevise = 0;
                
                for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                    if (lineageNoRef [counter2*2] != 0){
                        lineageNoRevise++;
                        lineageNoRef [counter2*2+1] = lineageNoRevise;
                    }
                }
                
                //for (int counterA = 1; counterA <= maxLineageNo; counterA++){
                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<lineageNoRef [counterA*2+counterB];
                //    cout<<" lineageNoRef "<<counterA<<endl;
                //}
                
                //==========Lineage folder info==========
                folderPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat";
                
                lineageFolderList = new int [100000];
                lineageFolderListCount = 0;
                lineageFolderListTemp = new string [100000];
                
                dir = opendir(folderPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            numberExtract = entry.substr(1);
                            
                            if (atoi(numberExtract.c_str()) != 0){
                                lineageFolderListTemp [lineageFolderListCount] = entry, lineageFolderListCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //-----Directory Sort-----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter2 = 0; counter2 < lineageFolderListCount; counter2++){
                        [unsortedArray addObject:@(lineageFolderListTemp [counter2].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter2 = 0; counter2 < [unsortedArray count]; counter2++){
                        lineageFolderListTemp [counter2] = [unsortedArray [counter2] UTF8String];
                    }
                }
                
                for (int counter2 = 0; counter2 < lineageFolderListCount; counter2++){
                    lineageFolderList [counter2] = atoi(lineageFolderListTemp [counter2].substr(1).c_str());
                }
                
                //for (int counterA = 0; counterA < lineageFolderListCount; counterA++){
                //    cout<<counterA<<" "<<lineageFolderList [counterA]<<" List"<<endl;
                //}
                
                delete [] lineageFolderListTemp;
                
                //=========Check Lineage folder-Lineage data consistency==========
                folderLingMatchFind = 0;
                
                for (int counter2 = 0; counter2 < lineageFolderListCount; counter2++){
                    folderLingMatchFind = 0;
                    
                    for (int counter3 = 0; counter3 < lineageStartEndCleanCount/8; counter3++){
                        if (lineageFolderList [counter2] == lineageStartEndClean [counter3*8]){
                            folderLingMatchFind = 1;
                            break;
                        }
                    }
                    
                    if (folderLingMatchFind == 0){
                        break;
                    }
                }
                
                folderLingMatchFind2 = 0;
                
                for (int counter2 = 0; counter2 < lineageStartEndCleanCount/8; counter2++){
                    folderLingMatchFind2 = 0;
                    
                    for (int counter3 = 0; counter3 < lineageFolderListCount; counter3++){
                        if (lineageStartEndClean [counter2*8] == lineageFolderList [counter3]){
                            folderLingMatchFind2 = 1;
                            break;
                        }
                    }
                    
                    if (folderLingMatchFind2 == 0){
                        break;
                    }
                }
                
                if (folderLingMatchFind == 1 && folderLingMatchFind2 == 1){
                    //=========Folder number update=========
                    amendFileCount = 0;
                    
                    for (int counter2 = 0; counter2 < lineageFolderListCount; counter2++){
                        if (lineageFolderList [counter2] <= maxLineageNo){
                            if (lineageNoRef [lineageFolderList [counter2]*2+1] != 0){
                                clearLineage = to_string (lineageFolderList [counter2]);
                                
                                if (clearLineage.length() == 1) clearLineage = "L0000"+clearLineage;
                                else if (clearLineage.length() == 2) clearLineage = "L000"+clearLineage;
                                else if (clearLineage.length() == 3) clearLineage = "L00"+clearLineage;
                                else if (clearLineage.length() == 4) clearLineage = "L0"+clearLineage;
                                else if (clearLineage.length() == 5) clearLineage = "L"+clearLineage;
                                
                                lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage;
                                
                                clearLineage2 = to_string (lineageNoRef [lineageFolderList [counter2]*2+1]);
                                
                                if (clearLineage2.length() == 1) clearLineage2 = "L0000"+clearLineage2;
                                else if (clearLineage2.length() == 2) clearLineage2 = "L000"+clearLineage2;
                                else if (clearLineage2.length() == 3) clearLineage2 = "L00"+clearLineage2;
                                else if (clearLineage2.length() == 4) clearLineage2 = "L0"+clearLineage2;
                                else if (clearLineage2.length() == 5) clearLineage2 = "L"+clearLineage2;
                                
                                lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage2;
                                
                                renameCheck = rename (lineageFolderPath.c_str(), lineageFolderPath2.c_str());
                                
                                if (renameCheck == -1) commonDataUploadCheck = 1;
                                
                                //==========Cell Status Info==========
                                folderContentCount = 0;
                                
                                dir = opendir(lineageFolderPath2.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            folderContentCount++;
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                else commonDataUploadCheck = 1;
                                
                                arrayFolderContentList = new string [folderContentCount+50];
                                
                                folderContentCount = 0;
                                
                                dir = opendir(lineageFolderPath2.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            arrayFolderContentList [folderContentCount] = entry, folderContentCount++;
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    //-----Directory Sort-----
                                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                    
                                    for (int counter3 = 0; counter3 < folderContentCount; counter3++){
                                        [unsortedArray addObject:@(arrayFolderContentList [counter3].c_str())];
                                    }
                                    
                                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                    
                                    for (NSUInteger counter3 = 0; counter3 < [unsortedArray count]; counter3++){
                                        arrayFolderContentList [counter3] = [unsortedArray [counter3] UTF8String];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < folderContentCount; counter3++){
                                        entry = arrayFolderContentList [counter3];
                                        
                                        cellFindFlag = (int)entry.find("C");
                                        cellFindFlag2 = (int)entry.find("CellStatus");
                                        
                                        if (cellFindFlag != -1 && cellFindFlag2 == -1){ //amend file name change
                                            folderPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage2+"/"+entry+"/"+analysisID+"_"+clearLineage+"_lineDataAmend";
                                            folderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage2+"/"+entry+"/"+analysisID+"_"+clearLineage2+"_lineDataAmend";
                                            
                                            rename (folderPath.c_str(), folderPath2.c_str());
                                            
                                            if (renameCheck == -1) commonDataUploadCheck = 1;
                                            
                                            amendFileCount++;
                                        }
                                        
                                        if (cellFindFlag != -1 && cellFindFlag2 != -1){
                                            folderPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage2+"/"+entry;
                                            folderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage2+"/"+analysisID+"_"+clearLineage2+"_CellStatus";
                                            
                                            sizeForCopy = 0;
                                            
                                            if (stat(folderPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                uploadTempChar = new char [sizeForCopy+50];
                                                
                                                fin.open(folderPath.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    fin.read((char*)uploadTempChar, sizeForCopy+50);
                                                    fin.close();
                                                    
                                                    cellStatusTemp = new int [sizeForCopy+50];
                                                    cellStatusTempCount = 0;
                                                    
                                                    dataString = "";
                                                    readPosition2 = 0;
                                                    
                                                    do{
                                                        
                                                        if (uploadTempChar [readPosition2] != 10) dataString = dataString+uploadTempChar [readPosition2];
                                                        else if (dataString != "End") cellStatusTemp [cellStatusTempCount] = atoi(dataString.c_str()), cellStatusTempCount++,
                                                            dataString = "";
                                                        
                                                        readPosition2++;
                                                        
                                                    } while (dataString != "End");
                                                    
                                                    //for (int counterA = 0; counterA < cellStatusTempCount/7; counterA++){
                                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<cellStatusTemp [counterA*7+counterB];
                                                    //    cout<<" cellStatusTemp "<<counterA<<endl;
                                                    //}
                                                    
                                                    for (int counter4 = 0; counter4 < cellStatusTempCount/7; counter4++){
                                                        cellStatusTemp [counter4*7+6] = atoi(clearLineage2.substr(1).c_str());
                                                    }
                                                    
                                                    //for (int counterA = 0; counterA < cellStatusTempCount/7; counterA++){
                                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<cellStatusTemp [counterA*7+counterB];
                                                    //    cout<<" cellStatusTemp "<<counterA<<endl;
                                                    //}
                                                    
                                                    mainDataEntry = new char [cellStatusTempCount*7+10];
                                                    totalEntryCount = 0;
                                                    
                                                    for (int counter4 = 0; counter4 < cellStatusTempCount; counter4++){
                                                        extension = to_string (cellStatusTemp [counter4]);
                                                        
                                                        for (int counter5 = 0; counter5 < (int)extension.length(); counter5++){
                                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter5), totalEntryCount++;
                                                        }
                                                        
                                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                                    }
                                                    
                                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                                    
                                                    ofstream outfile2 (folderPath2.c_str(), ofstream::binary);
                                                    
                                                    if (outfile2.is_open()){
                                                        outfile2.write (mainDataEntry, totalEntryCount);
                                                        outfile2.close();
                                                    }
                                                    else commonDataUploadCheck = 1;
                                                    
                                                    delete [] mainDataEntry;
                                                    delete [] cellStatusTemp;
                                                    
                                                    rename (folderPath.c_str(), folderPath2.c_str());
                                                }
                                                else commonDataUploadCheck = 1;
                                                
                                                delete [] uploadTempChar;
                                            }
                                            else commonDataUploadCheck = 1;
                                        }
                                    }
                                }
                                else commonDataUploadCheck = 1;
                                
                                delete [] arrayFolderContentList;
                            }
                        }
                    }
                    
                    // time13 = clock();
                    // cout<<time13-time12<< " t13"<<endl;
                    
                    amendTimeList = new int [amendFileCount*3+100];
                    amendTimeListCount = 0;
                    
                    //-----Amend Check-----
                    folderPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat";
                    
                    dir = opendir(folderPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                folderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+entry;
                                
                                dir2 = opendir(folderPath2.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                            folderPath3 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+entry+"/"+entry2+"/"+analysisID+"_"+entry+"_lineDataAmend";
                                            
                                            sizeForCopy = 0;
                                            
                                            if (stat(folderPath3.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                                
                                                fin.open(folderPath3.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    uploadTemp = new uint8_t [sizeForCopy+50];
                                                    
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    fin.close();
                                                    
                                                    cellAmendTemp = new int [sizeForCopy+50];
                                                    cellAmendTempCount = 0;
                                                    
                                                    readPosition = 0;
                                                    stepCount = 0;
                                                    
                                                    do{
                                                        
                                                        if (stepCount == 0){
                                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                                            finData [5] = uploadTemp [readPosition], readPosition++; //--3
                                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4
                                                            finData [7] = uploadTemp [readPosition], readPosition++;
                                                            finData [8] = uploadTemp [readPosition], readPosition++;
                                                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                                            finData [12] = uploadTemp [readPosition], readPosition++; //--6
                                                            
                                                            finData [1] = finData [0]*256+finData [1];
                                                            finData [3] = finData [2]*256+finData [3];
                                                            finData [5] = finData [4]*256+finData [5];
                                                            finData [9] = finData [7]*65536+finData [8]*256+finData [9];
                                                            finData [12] = finData [10]*65536+finData [11]*256+finData [12];
                                                            
                                                            if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                                                            else{
                                                                
                                                                cellAmendTemp [cellAmendTempCount] = finData [1], cellAmendTempCount++;
                                                                cellAmendTemp [cellAmendTempCount] = finData [3], cellAmendTempCount++;
                                                                cellAmendTemp [cellAmendTempCount] = finData [5], cellAmendTempCount++;
                                                                cellAmendTemp [cellAmendTempCount] = finData [6], cellAmendTempCount++;
                                                                cellAmendTemp [cellAmendTempCount] = finData [9], cellAmendTempCount++;
                                                                cellAmendTemp [cellAmendTempCount] = finData [12], cellAmendTempCount++;
                                                            }
                                                        }
                                                        
                                                    } while (stepCount != 3);
                                                    
                                                    delete [] uploadTemp;
                                                    
                                                    amendTimeList [amendTimeListCount] = cellAmendTemp [0], amendTimeListCount++;
                                                    amendTimeList [amendTimeListCount] = atoi(entry.substr(1).c_str()), amendTimeListCount++;
                                                    amendTimeList [amendTimeListCount] = atoi(entry2.substr(1).c_str()), amendTimeListCount++;
                                                    
                                                    delete [] cellAmendTemp;
                                                }
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    else commonDataUploadCheck = 1;
                    
                    if (commonDataUploadCheck == 0){
                        //==========Connect folder process==========
                        imageSizeTreat= 0;
                        
                        for (int counter3 = 0; counter3 < imageSizeListCount/2; counter3++){
                            if (arrayImageSizeList [counter3*2] == treatmentNameClear){
                                imageSizeTreat = atoi(arrayImageSizeList [counter3*2+1].c_str());
                                break;
                            }
                        }
                        
                        revisedMapTemp = new int *[imageSizeTreat+1];
                        
                        for (int counter3 = 0; counter3 < imageSizeTreat+1; counter3++){
                            revisedMapTemp [counter3] = new int [imageSizeTreat+1];
                        }
                        
                        totalMapSizeTemp = imageSizeTreat*imageSizeTreat*4;
                        
                        dataHoldMap = new char [imageSizeTreat*imageSizeTreat*4];
                        
                        progressValue = ((treatmentStatusCount/9)*4+1)/(double)(imageEndClean-imageTimeOneClean);
                        increment2 = ((treatmentStatusCount/9)*4+1)/(double)(imageEndClean-imageTimeOneClean);
                        progressTiming = 3;
                        
                        usleep(1000);
                        
                        for (int counter2 = imageTimeOneClean; counter2 <= imageEndClean; counter2++){
                            progressValue = progressValue+increment2;
                            progressTiming = 3;
                            
                            usleep(1000);
                            
                            extension = to_string (counter2);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            lineageFilePath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameClear+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter3 = 0; counter3 < 6; counter3++){
                                sizeForCopy = 0;
                                
                                if (stat(lineageFilePath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter3 == 0) size1 = sizeForCopy;
                                    else if (counter3 == 1) size2 = sizeForCopy;
                                    else if (counter3 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter3 == 3) size1 = sizeForCopy;
                                    else if (counter3 == 4) size2 = sizeForCopy;
                                    else if (counter3 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (checkFlag == 1){
                                //-----MasterData Read-----
                                masterDataClean = new int [sizeForCopy+50];
                                masterDataCleanCount = 0;
                                masterGCenterClean = new int [sizeForCopy+50];
                                masterGCenterCleanCount = 0;
                                masterAssClean = new int [sizeForCopy+50];
                                masterAssCleanCount = 0;
                                
                                uploadCheckFlag = 0;
                                
                                fin.open(lineageFilePath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                uploadCheckFlag = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (uploadCheckFlag == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++;
                                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                else{
                                                    
                                                    masterDataClean [masterDataCleanCount] = finData [1], masterDataCleanCount++;
                                                    masterDataClean [masterDataCleanCount] = finData [3], masterDataCleanCount++;
                                                    masterDataClean [masterDataCleanCount] = finData [4], masterDataCleanCount++;
                                                    masterDataClean [masterDataCleanCount] = finData [7], masterDataCleanCount++;
                                                    masterDataClean [masterDataCleanCount] = finData [12], masterDataCleanCount++;
                                                    masterDataClean [masterDataCleanCount] = finData [13], masterDataCleanCount++;
                                                    masterDataClean [masterDataCleanCount] = finData [16], masterDataCleanCount++;
                                                }
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData [9] = finData [8]*256+finData [9];
                                                
                                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                                else{
                                                    
                                                    masterAssClean [masterAssCleanCount] = finData [2], masterAssCleanCount++;
                                                    masterAssClean [masterAssCleanCount] = finData [3], masterAssCleanCount++;
                                                    masterAssClean [masterAssCleanCount] = finData [4], masterAssCleanCount++;
                                                    masterAssClean [masterAssCleanCount] = finData [7], masterAssCleanCount++;
                                                    masterAssClean [masterAssCleanCount] = finData [9], masterAssCleanCount++;
                                                    masterAssClean [masterAssCleanCount] = finData [10], masterAssCleanCount++;
                                                }
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                                else{
                                                    
                                                    masterGCenterClean [masterGCenterCleanCount] = finData [1], masterGCenterCleanCount++;
                                                    masterGCenterClean [masterGCenterCleanCount] = finData [3], masterGCenterCleanCount++;
                                                    masterGCenterClean [masterGCenterCleanCount] = finData [6], masterGCenterCleanCount++;
                                                    masterGCenterClean [masterGCenterCleanCount] = finData [7], masterGCenterCleanCount++;
                                                    masterGCenterClean [masterGCenterCleanCount] = finData [10], masterGCenterCleanCount++;
                                                    masterGCenterClean [masterGCenterCleanCount] = finData [11], masterGCenterCleanCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                    }
                                    else commonDataUploadCheck = 1;
                                    
                                    delete [] uploadTemp;
                                }
                                else commonDataUploadCheck = 1;
                                
                                //for (int counterA = 0; counterA < masterDataCleanCount/7; counterA++){
                                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterDataClean [counterA*7+counterB];
                                //	cout<<" masterDataClean "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < masterAssCleanCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<masterAssClean [counterA*6+counterB];
                                //	cout<<" masterAssClean "<<counterA<<endl;
                                //}
                                
                                //-----Status Read-----
                                connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameClear+"_Status";
                                
                                masterStatusClean = new int [50];
                                
                                if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    delete [] masterStatusClean;
                                    masterStatusClean = new int [sizeForCopy+50];
                                    masterStatusCleanCount = 0;
                                    
                                    fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        fin.close();
                                        
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                                                finData [7] = uploadTemp [readPosition], readPosition++;
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                                                finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                                                finData [13] = uploadTemp [readPosition], readPosition++;
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                                                finData [16] = uploadTemp [readPosition], readPosition++;
                                                finData [17] = uploadTemp [readPosition], readPosition++;
                                                finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                                
                                                finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [8] = finData [7]*256+finData [8];
                                                finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                                finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                                
                                                if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                                else{
                                                    
                                                    masterStatusClean [masterStatusCleanCount] = finData [0], masterStatusCleanCount++; //-----Selected, removed, eliminated status-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [3], masterStatusCleanCount++; //-----When new line is created, enter line number which creates-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [6], masterStatusCleanCount++; //-----PositionRevise Start-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [8], masterStatusCleanCount++; //-----Cut line number-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [9], masterStatusCleanCount++; //-----X Start-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [10], masterStatusCleanCount++; //-----X End-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [11], masterStatusCleanCount++; //-----Y Start-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [12], masterStatusCleanCount++; //-----Y End-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [15], masterStatusCleanCount++; //-----Connect-----
                                                    masterStatusClean [masterStatusCleanCount] = finData [18], masterStatusCleanCount++; //-----Lineage-----
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        delete [] uploadTemp;
                                    }
                                    else commonDataUploadCheck = 1;
                                }
                                else commonDataUploadCheck = 1;
                                
                                //time21 = clock();
                                //cout<<time21-time20<< " t21"<<endl;
                                
                                //for (int counterA = 0; counterA < masterStatusCleanCount/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<masterStatusClean [counterA*10+counterB];
                                //    cout<<" masterStatusClean "<<counterA<<endl;
                                //}
                                
                                //-----Rel Read-----
                                connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameClear+"_ConnectLineageRel";
                                
                                masterRelClean = new int [50];
                                
                                sizeForCopy = 0;
                                
                                if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    delete [] masterRelClean;
                                    masterRelClean = new int [sizeForCopy+50];
                                    masterRelCleanCount = 0;
                                    
                                    fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        fin.close();
                                        
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                                finData [3] = uploadTemp [readPosition], readPosition++;
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                finData [7] = finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                else{
                                                    
                                                    masterRelClean [masterRelCleanCount] = finData [2], masterRelCleanCount++;
                                                    masterRelClean [masterRelCleanCount] = finData [5], masterRelCleanCount++;
                                                    masterRelClean [masterRelCleanCount] = finData [7], masterRelCleanCount++;
                                                    masterRelClean [masterRelCleanCount] = finData [12], masterRelCleanCount++;
                                                    masterRelClean [masterRelCleanCount] = finData [13], masterRelCleanCount++;
                                                    masterRelClean [masterRelCleanCount] = finData [14], masterRelCleanCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                        
                                        delete [] uploadTemp;
                                    }
                                    else commonDataUploadCheck = 1;
                                }
                                
                                //time22 = clock();
                                //cout<<time22-time21<< " t22"<<endl;
                                
                                //-----Map path-----
                                connectMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameClear+"_RevisedMap";
                                
                                //-----Connect no reference create-----
                                connectNoRef = new int [masterStatusClean [(masterStatusCleanCount/10-1)*10+8]*2+10];
                                
                                for (int counter3 = 0; counter3 <= masterStatusClean [(masterStatusCleanCount/10-1)*10+8]*2+1; counter3++) connectNoRef [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < masterStatusCleanCount/10; counter3++){
                                    if (masterStatusClean [counter3*10] == 3 || masterStatusClean [counter3*10] == 4) connectNoRef [masterStatusClean [counter3*10+8]*2] = 0;
                                    else connectNoRef [masterStatusClean [counter3*10+8]*2] = masterStatusClean [counter3*10+8];
                                }
                                
                                //for (int counterA = 1; counterA <= maxConnectNo; counterA++){
                                //	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<connectNoRef [counterA*2+counterB];
                                //	cout<<" connectNoRef "<<counterA<<endl;
                                //}
                                
                                connectNoRevise = 0;
                                
                                for (int counter3 = 1; counter3 <= masterStatusClean [(masterStatusCleanCount/10-1)*10+8]; counter3++){
                                    if (connectNoRef [counter3*2] != 0){
                                        connectNoRevise++;
                                        connectNoRef [counter3*2+1] = connectNoRevise;
                                    }
                                }
                                
                                //for (int counterA = 1; counterA <= masterStatusClean [(masterStatusCleanCount/10-1)*10+8]; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<connectNoRef [counterA*2+counterB];
                                //    cout<<" connectNoRef "<<counterA<<endl;
                                //}
                                
                                //-----Master UpDate-----
                                //-----Master, 1. X position, 2. Y position, 3. value, 4. Connect no, 5. cell No, 6. Status, 7. Lineage no-----
                                masterDataCleanTemp = new int [masterDataCleanCount+50];
                                masterDataCleanTempCount = 0;
                                masterGCenterCleanTemp = new int [masterGCenterCleanCount+50];
                                masterGCenterCleanTempCount = 0;
                                masterAssCleanTemp = new int [masterAssCleanCount+50];
                                masterAssCleanTempCount = 0;
                                
                                //for (int counterA = 1; counterA <= maxLineageNo; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<lineageNoRef [counterA*2+counterB];
                                //    cout<<" lineageNoRef "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < masterDataCleanCount/7; counter3++){
                                    if (connectNoRef [masterDataClean [counter3*7+3]*2] != 0){
                                        masterDataCleanTemp [masterDataCleanTempCount] = masterDataClean [counter3*7], masterDataCleanTempCount++;
                                        masterDataCleanTemp [masterDataCleanTempCount] = masterDataClean [counter3*7+1], masterDataCleanTempCount++;
                                        masterDataCleanTemp [masterDataCleanTempCount] = masterDataClean [counter3*7+2], masterDataCleanTempCount++;
                                        masterDataCleanTemp [masterDataCleanTempCount] = connectNoRef [masterDataClean [counter3*7+3]*2+1], masterDataCleanTempCount++; //--connect--
                                        masterDataCleanTemp [masterDataCleanTempCount] = masterDataClean [counter3*7+4], masterDataCleanTempCount++;
                                        
                                        if (masterDataClean [counter3*7+6] != 0){
                                            masterDataCleanTemp [masterDataCleanTempCount] = masterDataClean [counter3*7+5], masterDataCleanTempCount++;
                                            masterDataCleanTemp [masterDataCleanTempCount] = lineageNoRef [masterDataClean [counter3*7+6]*2+1], masterDataCleanTempCount++; //-----Lineage no-----
                                        }
                                        else{
                                            
                                            masterDataCleanTemp [masterDataCleanTempCount] = 0, masterDataCleanTempCount++;
                                            masterDataCleanTemp [masterDataCleanTempCount] = 0, masterDataCleanTempCount++;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < masterDataCleanCount/7; counterA++){
                                //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterDataClean [counterA*7+counterB];
                                //	cout<<" masterDataClean "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 1; counterA <= maxConnectNo; counterA++){
                                //	for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<connectNoRef [counterA*2+counterB];
                                //	cout<<" connectNoRef "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < masterGCenterCleanCount/6; counter3++){
                                    if (connectNoRef [masterGCenterClean [counter3*6+4]*2] != 0){
                                        masterGCenterCleanTemp [masterGCenterCleanTempCount] = masterGCenterClean [counter3*6], masterGCenterCleanTempCount++;
                                        masterGCenterCleanTemp [masterGCenterCleanTempCount] = masterGCenterClean [counter3*6+1], masterGCenterCleanTempCount++;
                                        masterGCenterCleanTemp [masterGCenterCleanTempCount] = masterGCenterClean [counter3*6+2], masterGCenterCleanTempCount++;
                                        masterGCenterCleanTemp [masterGCenterCleanTempCount] = masterGCenterClean [counter3*6+3], masterGCenterCleanTempCount++;
                                        masterGCenterCleanTemp [masterGCenterCleanTempCount] = connectNoRef [masterGCenterClean [counter3*6+4]*2+1], masterGCenterCleanTempCount++;
                                        masterGCenterCleanTemp [masterGCenterCleanTempCount] = masterGCenterClean [counter3*6+5], masterGCenterCleanTempCount++;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < masterAssCleanCount/6; counter3++){
                                    if (connectNoRef [masterAssClean [counter3*6]*2] != 0){
                                        masterAssCleanTemp [masterAssCleanTempCount] = connectNoRef [masterAssClean [counter3*6]*2+1], masterAssCleanTempCount++;
                                        masterAssCleanTemp [masterAssCleanTempCount] = masterAssClean [counter3*6+1], masterAssCleanTempCount++;
                                        masterAssCleanTemp [masterAssCleanTempCount] = masterAssClean [counter3*6+2], masterAssCleanTempCount++;
                                        masterAssCleanTemp [masterAssCleanTempCount] = masterAssClean [counter3*6+3], masterAssCleanTempCount++;
                                        masterAssCleanTemp [masterAssCleanTempCount] = masterAssClean [counter3*6+4], masterAssCleanTempCount++;
                                        masterAssCleanTemp [masterAssCleanTempCount] = masterAssClean [counter3*6+5], masterAssCleanTempCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < masterAssCleanTempCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<masterAssCleanTemp [counterA*6+counterB];
                                //	cout<<" masterAssCleanTemp "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < masterAssCleanCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<masterAssClean [counterA*6+counterB];
                                //	cout<<" masterAssClean "<<counterA<<endl;
                                //}
                                
                                indexCount = 0;
                                
                                writingArray = new char [(masterDataCleanTempCount/7+masterAssCleanTempCount/6+masterGCenterCleanTempCount/6)*17+50];
                                
                                for (int counter3 = 0; counter3 < masterDataCleanTempCount/7; counter3++){
                                    dataTemp = masterDataCleanTemp [counter3*7];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = masterDataCleanTemp [counter3*7+1];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterDataCleanTemp [counter3*7+2], indexCount++;
                                    
                                    dataTemp = masterDataCleanTemp [counter3*7+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterDataCleanTemp [counter3*7+4];
                                    
                                    if (dataTemp < 0) dataTemp = dataTemp*-1, writingArray [indexCount] = 1, indexCount++;
                                    else writingArray [indexCount] = 0, indexCount++;
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterDataCleanTemp [counter3*7+5], indexCount++;
                                    
                                    dataTemp = masterDataCleanTemp [counter3*7+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 17; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                for (int counter3 = 0; counter3 < masterAssCleanTempCount/6; counter3++){
                                    dataTemp = masterAssCleanTemp [counter3*6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterAssCleanTemp [counter3*6+1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterAssCleanTemp [counter3*6+2], indexCount++;
                                    
                                    dataTemp = masterAssCleanTemp [counter3*6+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterAssCleanTemp [counter3*6+4];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterAssCleanTemp [counter3*6+5], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 11; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                for (int counter3 = 0; counter3 < masterGCenterCleanTempCount/6; counter3++){
                                    dataTemp = masterGCenterCleanTemp [counter3*6];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = masterGCenterCleanTemp [counter3*6+1];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = masterGCenterCleanTemp [counter3*6+2];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterGCenterCleanTemp [counter3*6+3], indexCount++;
                                    
                                    dataTemp = masterGCenterCleanTemp [counter3*6+4];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterGCenterCleanTemp [counter3*6+5], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 11; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile (lineageFilePath.c_str(), ofstream::binary);
                                
                                if (outfile.is_open()){
                                    outfile.write ((char*)writingArray, indexCount);
                                    outfile.close();
                                }
                                else commonDataUploadCheck = 1;
                                
                                delete [] writingArray;
                                
                                //for (int counterA = 0; counterA < masterStatusCleanCount/10; counterA++){
                                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<masterStatusClean [counterA*10+counterB];
                                //	cout<<" masterStatusClean "<<counterA<<endl;
                                //}
                                
                                //-----Status UpDate-----
                                masterStatusCleanTemp = new int [masterStatusCleanCount+50];
                                masterStatusCleanTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < masterStatusCleanCount/10; counter3++){
                                    if (connectNoRef [masterStatusClean [counter3*10+8]*2] != 0){
                                        if (masterStatusClean [counter3*10+9] != 0 || masterStatusClean [counter3*10] == 2){
                                            masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10], masterStatusCleanTempCount++;
                                        }
                                        else masterStatusCleanTemp [masterStatusCleanTempCount] = 0, masterStatusCleanTempCount++;
                                        
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+1], masterStatusCleanTempCount++;
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+2], masterStatusCleanTempCount++;
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+3], masterStatusCleanTempCount++; //-----connect-----
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+4], masterStatusCleanTempCount++;
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+5], masterStatusCleanTempCount++;
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+6], masterStatusCleanTempCount++;
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = masterStatusClean [counter3*10+7], masterStatusCleanTempCount++;
                                        masterStatusCleanTemp [masterStatusCleanTempCount] = connectNoRef [masterStatusClean [counter3*10+8]*2+1], masterStatusCleanTempCount++;
                                        
                                        if (masterStatusClean [counter3*10+9] != 0){
                                            masterStatusCleanTemp [masterStatusCleanTempCount] = lineageNoRef [masterStatusClean [counter3*10+9]*2+1], masterStatusCleanTempCount++; //-----Lineage no-----
                                        }
                                        else masterStatusCleanTemp [masterStatusCleanTempCount] = 0, masterStatusCleanTempCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < masterStatusCleanTempCount/10; counterA++){
                                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<masterStatusCleanTemp [counterA*10+counterB];
                                //	cout<<" masterStatusCleanTemp "<<counterA<<endl;
                                //}
                                
                                connectNoTemp = 0;
                                
                                for (int counter3 = 0; counter3 < masterDataCleanTempCount/7; counter3++){
                                    if (masterDataCleanTemp [counter3*7+3] != connectNoTemp){
                                        connectNoTemp = masterDataCleanTemp [counter3*7+3];
                                        masterStatusCleanTemp [(connectNoTemp-1)*10+2] = counter3;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < masterStatusCleanCount/10; counter3++){
                                    if (masterStatusCleanTemp [counter3*10] != 1 && masterStatusCleanTemp [counter3*10] != 7 && masterStatusCleanTemp [counter3*10+9] != 0){
                                        masterStatusCleanTemp [counter3*10+9] = 0;
                                    }
                                }
                                
                                writingArray = new char [masterStatusCleanTempCount/10*19+20];
                                
                                indexCount = 0;
                                
                                for (int counter3 = 0; counter3 < masterStatusCleanTempCount/10; counter3++){
                                    writingArray [indexCount] = (char)masterStatusCleanTemp [counter3*10], indexCount++;
                                    
                                    dataTemp = masterStatusCleanTemp [counter3*10+1];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterStatusCleanTemp [counter3*10+2];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterStatusCleanTemp [counter3*10+3];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterStatusCleanTemp [counter3*10+4], indexCount++;
                                    writingArray [indexCount] = (char)masterStatusCleanTemp [counter3*10+5], indexCount++;
                                    writingArray [indexCount] = (char)masterStatusCleanTemp [counter3*10+6], indexCount++;
                                    writingArray [indexCount] = (char)masterStatusCleanTemp [counter3*10+7], indexCount++;
                                    
                                    dataTemp = masterStatusCleanTemp [counter3*10+8];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterStatusCleanTemp [counter3*10+9];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 19; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile2 (connectStatusDataPath.c_str(), ofstream::binary);
                                
                                if (outfile2.is_open()){
                                    outfile2.write ((char*) writingArray, indexCount);
                                    outfile2.close();
                                }
                                else commonDataUploadCheck = 1;
                                
                                delete [] writingArray;
                                
                                //for (int counterA = 0; counterA < masterStatusCleanTempCount/10; counterA++){
                                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<masterStatusCleanTemp [counterA*10+counterB];
                                //	cout<<" masterStatusCleanTemp "<<counterA<<endl;
                                //}
                                
                                delete [] masterDataClean;
                                delete [] masterDataCleanTemp;
                                delete [] masterGCenterClean;
                                delete [] masterGCenterCleanTemp;
                                delete [] masterAssClean;
                                delete [] masterAssCleanTemp;
                                delete [] masterStatusClean;
                                delete [] masterStatusCleanTemp;
                                
                                //-----Rel UpDate-----
                                //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target, 2: removed, 3: added), 6. reserve=========
                                masterRelCleanTemp = new int [masterRelCleanCount+50];
                                masterRelCleanTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < masterRelCleanCount/6; counter3++){
                                    masterRelCleanTemp [masterRelCleanTempCount] = lineageNoRef [masterRelClean [counter3*6]*2+1], masterRelCleanTempCount++;
                                    masterRelCleanTemp [masterRelCleanTempCount] = connectNoRef [masterRelClean [counter3*6+1]*2+1], masterRelCleanTempCount++;
                                    masterRelCleanTemp [masterRelCleanTempCount] = masterRelClean [counter3*6+2], masterRelCleanTempCount++;
                                    masterRelCleanTemp [masterRelCleanTempCount] = masterRelClean [counter3*6+3], masterRelCleanTempCount++;
                                    masterRelCleanTemp [masterRelCleanTempCount] = masterRelClean [counter3*6+4], masterRelCleanTempCount++;
                                    masterRelCleanTemp [masterRelCleanTempCount] = masterRelClean [counter3*6+5], masterRelCleanTempCount++;
                                }
                                
                                //for (int counterA = 0; counterA < masterStatusCleanTempCount/10; counterA++){
                                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<masterStatusCleanTemp [counterA*10+counterB];
                                //	cout<<" masterStatusCleanTemp "<<counterA<<endl;
                                //}
                                
                                writingArray = new char [masterRelCleanTempCount/6*16+16];
                                
                                indexCount = 0;
                                
                                for (int counter3 = 0; counter3 < masterRelCleanTempCount/6; counter3++){
                                    dataTemp = masterRelCleanTemp [counter3*6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterRelCleanTemp [counter3*6+1];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = masterRelCleanTemp [counter3*6+2];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    if (masterRelCleanTemp [counter3*6+3] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = masterRelCleanTemp [counter3*6+3]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = masterRelCleanTemp [counter3*6+3];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterRelCleanTemp [counter3*6+4], indexCount++;
                                    
                                    writingArray [indexCount] = (char)masterRelCleanTemp [counter3*6+5], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 15; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                
                                if (outfile3.is_open()){
                                    outfile3.write ((char*) writingArray, indexCount);
                                    outfile3.close();
                                }
                                else commonDataUploadCheck = 1;
                                
                                delete [] writingArray;
                                
                                //for (int counterA = 0; counterA < masterRelCleanTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<masterRelCleanTemp [counterA*6+counterB];
                                //    cout<<" masterRelCleanTemp "<<counterA<<endl;
                                //}
                                
                                delete [] masterRelClean;
                                
                                for (int counter3 = 0; counter3 < amendTimeListCount/3; counter3++){
                                    if (amendTimeList [counter3*3] == counter2){
                                        clearLineage = to_string(amendTimeList [counter3*3+1]);
                                        
                                        if (clearLineage.length() == 1) clearLineage = "L0000"+clearLineage;
                                        else if (clearLineage.length() == 2) clearLineage = "L000"+clearLineage;
                                        else if (clearLineage.length() == 3) clearLineage = "L00"+clearLineage;
                                        else if (clearLineage.length() == 4) clearLineage = "L0"+clearLineage;
                                        else if (clearLineage.length() == 5) clearLineage = "L"+clearLineage;
                                        
                                        cellNumberString = to_string(amendTimeList [counter3*3+2]);
                                        
                                        if (amendTimeList [counter3*3+2] >= 0){
                                            if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                                            else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                                            else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                                            else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                                            else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                                            else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                                            else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                                            else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                                            else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                                        }
                                        else{
                                            
                                            cellNumberString = cellNumberString.substr(1);
                                            
                                            if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                                            else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                                            else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                                            else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                                            else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                                            else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                                            else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                                            else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                                            else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                                        }
                                        
                                        folderPath3 = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameClear+"_Treat/"+clearLineage+"/"+cellNumberString+"/"+analysisID+"_"+clearLineage+"_lineDataAmend";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(folderPath3.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                            
                                            fin.open(folderPath3.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                uploadTemp = new uint8_t [sizeForCopy+50];
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                fin.close();
                                                
                                                cellAmendTemp = new int [sizeForCopy+50];
                                                cellAmendTempCount = 0;
                                                
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                                        finData [5] = uploadTemp [readPosition], readPosition++; //--3
                                                        finData [6] = uploadTemp [readPosition], readPosition++; //--4
                                                        finData [7] = uploadTemp [readPosition], readPosition++;
                                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--6
                                                        
                                                        finData [1] = finData [0]*256+finData [1];
                                                        finData [3] = finData [2]*256+finData [3];
                                                        finData [5] = finData [4]*256+finData [5];
                                                        finData [9] = finData [7]*65536+finData [8]*256+finData [9];
                                                        finData [12] = finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            cellAmendTemp [cellAmendTempCount] = finData [1], cellAmendTempCount++;
                                                            cellAmendTemp [cellAmendTempCount] = finData [3], cellAmendTempCount++;
                                                            cellAmendTemp [cellAmendTempCount] = finData [5], cellAmendTempCount++;
                                                            cellAmendTemp [cellAmendTempCount] = finData [6], cellAmendTempCount++;
                                                            cellAmendTemp [cellAmendTempCount] = finData [9], cellAmendTempCount++;
                                                            cellAmendTemp [cellAmendTempCount] = finData [12], cellAmendTempCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                delete [] uploadTemp;
                                                
                                                //for (int counterA = 0; counterA < cellAmendTempCount/6; counterA++){
                                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<cellAmendTemp [counterA*6+counterB];
                                                //    cout<<" cellAmendTemp "<<counterA<<endl;
                                                //}
                                                
                                                newConnectNo = 0;
                                                
                                                for (int counter4 = 0; counter4 < masterRelCleanTempCount/6; counter4++){
                                                    if (masterRelCleanTemp [counter4*6] == amendTimeList [counter3*3+1] && masterRelCleanTemp [counter4*6+3] == amendTimeList [counter3*3+2]){
                                                        newConnectNo = masterRelCleanTemp [counter4*6+1];
                                                        break;
                                                    }
                                                }
                                                
                                                //-----1. Image No, 2, X position, 3 Y position, 4. Value, 5. Connect No, 6. Lineage NO-----
                                                for (int counter4 = 0; counter4 < cellAmendTempCount/6; counter4++){
                                                    if (cellAmendTemp [counter4*6] == counter2){
                                                        cellAmendTemp [counter4*6+4] = newConnectNo;
                                                        cellAmendTemp [counter4*6+5] = atoi(clearLineage.substr(1).c_str());
                                                    }
                                                }
                                                
                                                //for (int counterA = 0; counterA < cellAmendTempCount/6; counterA++){
                                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<cellAmendTemp [counterA*6+counterB];
                                                //    cout<<" cellAmendTemp "<<counterA<<endl;
                                                //}
                                                
                                                indexCount = 0;
                                                
                                                writingArray = new char [cellAmendTempCount/6*13+20];
                                                
                                                for (int counter4 = 0; counter4 < cellAmendTempCount/6; counter4++){
                                                    dataTemp = cellAmendTemp [counter4*6];
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    dataTemp = cellAmendTemp [counter4*6+1];
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    dataTemp = cellAmendTemp [counter4*6+2];
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    writingArray [indexCount] = (char)cellAmendTemp [counter4*6+3], indexCount++;
                                                    
                                                    dataTemp = cellAmendTemp [counter4*6+4];
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                    
                                                    dataTemp = cellAmendTemp [counter4*6+5];
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                }
                                                
                                                for (int counter4 = 0; counter4 < 13; counter4++) writingArray [indexCount] = 0, indexCount++;
                                                
                                                ofstream outfile4 (folderPath3.c_str(), ofstream::binary);
                                                
                                                if (outfile4.is_open()){
                                                    outfile4.write ((char*)writingArray, indexCount);
                                                    outfile4.close();
                                                }
                                                else commonDataUploadCheck = 1;
                                                
                                                delete [] writingArray;
                                                delete [] cellAmendTemp;
                                            }
                                            else commonDataUploadCheck = 1;
                                        }
                                    }
                                }
                                
                                fin.open(connectMapPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    upload2 = new uint8_t [totalMapSizeTemp+50];
                                    
                                    fin.read((char*)upload2, totalMapSizeTemp+50);
                                    fin.close();
                                    
                                    yDimensionCount = 0;
                                    xDimensionCount = 0;
                                    readCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < totalMapSizeTemp; counter3++){
                                        finData2 = upload2[counter3];
                                        
                                        if (readCount == 0) readBit [0] = finData2, readCount++;
                                        else if (readCount == 1) readBit [1] = finData2, readCount++;
                                        else if (readCount == 2) readBit [2] = finData2, readCount++;
                                        else if (readCount == 3){
                                            readBit [3] = finData2, readCount = 0;
                                            
                                            for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                                revisedMapTemp [yDimensionCount][xDimensionCount] = readBit [0]*65536+readBit [1]*256+readBit [2], xDimensionCount++;
                                            }
                                            
                                            if (xDimensionCount == imageSizeTreat) xDimensionCount = 0, yDimensionCount++;
                                            
                                            if (yDimensionCount == imageSizeTreat){
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] upload2;
                                }
                                else commonDataUploadCheck = 1;
                                
                                delete [] masterRelCleanTemp;
                                
                                for (int counterY = 0; counterY < imageSizeTreat; counterY++){
                                    for (int counterX = 0; counterX < imageSizeTreat; counterX++){
                                        if (revisedMapTemp [counterY][counterX] != 0){
                                            revisedMapTemp [counterY][counterX] = connectNoRef [revisedMapTemp [counterY][counterX]*2+1];
                                        }
                                    }
                                }
                                
                                indexCount = 0;
                                dataTemp2 = 0;
                                entryCount = 0;
                                
                                for (int counterX = 0; counterX < imageSizeTreat; counterX++){
                                    for (int counterY = 0; counterY < imageSizeTreat; counterY++){
                                        dataTemp = revisedMapTemp [counterX][counterY];
                                        
                                        if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                                        else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageSizeTreat-1){
                                            readBit [0] = dataTemp2/65536;
                                            dataTemp2 = dataTemp2%65536;
                                            readBit [1] = dataTemp2/256;
                                            dataTemp2 = dataTemp2%256;
                                            readBit [2] = dataTemp2;
                                            
                                            if (counterY == imageSizeTreat-1){
                                                if (dataTemp != dataTemp2){
                                                    dataHoldMap [indexCount] = (char)readBit [0], indexCount++;
                                                    dataHoldMap [indexCount] = (char)readBit [1], indexCount++;
                                                    dataHoldMap [indexCount] = (char)readBit [2], indexCount++;
                                                    dataHoldMap [indexCount] = (char)entryCount, indexCount++;
                                                    
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    entryCount = 1;
                                                    
                                                    dataHoldMap [indexCount] = (char)readBit [0], indexCount++;
                                                    dataHoldMap [indexCount] = (char)readBit [1], indexCount++;
                                                    dataHoldMap [indexCount] = (char)readBit [2], indexCount++;
                                                    dataHoldMap [indexCount] = (char)entryCount, indexCount++;
                                                }
                                                else{
                                                    
                                                    entryCount++;
                                                    
                                                    dataHoldMap [indexCount] = (char)readBit [0], indexCount++;
                                                    dataHoldMap [indexCount] = (char)readBit [1], indexCount++;
                                                    dataHoldMap [indexCount] = (char)readBit [2], indexCount++;
                                                    dataHoldMap [indexCount] = (char)entryCount, indexCount++;
                                                }
                                            }
                                            else{
                                                
                                                dataHoldMap [indexCount] = (char)readBit [0], indexCount++;
                                                dataHoldMap [indexCount] = (char)readBit [1], indexCount++;
                                                dataHoldMap [indexCount] = (char)readBit [2], indexCount++;
                                                dataHoldMap [indexCount] = (char)entryCount, indexCount++;
                                            }
                                            
                                            if (counterY == imageSizeTreat-1) entryCount = 0;
                                            else{
                                                
                                                entryCount = 1;
                                                dataTemp2 = dataTemp;
                                            }
                                        }
                                        else entryCount++;
                                    }
                                }
                                
                                ofstream outfile4 (connectMapPath.c_str(), ofstream::binary);
                                
                                if (commonDataUploadCheck == 0 && outfile4.is_open()){
                                    outfile4.write(dataHoldMap, indexCount);
                                    outfile4.close();
                                }
                                else commonDataUploadCheck = 1;
                                
                                //======Fluorescent=======
                                folderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameClear+"_ExtendLineData";
                                
                                size1 = 0;
                                size2 = 0;
                                checkFlag = 0;
                                
                                for (int counter3 = 0; counter3 < 6; counter3++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(folderPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter3 == 0) size1 = sizeForCopy;
                                        else if (counter3 == 1) size2 = sizeForCopy;
                                        else if (counter3 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter3 == 3) size1 = sizeForCopy;
                                        else if (counter3 == 4) size2 = sizeForCopy;
                                        else if (counter3 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                if (stat(folderPath.c_str(), &sizeOfFile) == 0 && checkFlag == 0) commonDataUploadCheck = 1;
                                else if (checkFlag == 1){
                                    uploadCheckFlag = 0;
                                    
                                    arrayExpandTemp2 = new int [sizeForCopy+50];
                                    expandTempCount2 = 0;
                                    
                                    fin.open(folderPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        uploadTemp2 = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp2, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp2 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-8]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp2, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp2 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-8]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp2, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp2 [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp2 [sizeForCopy-8]) != 0){
                                                    uploadCheckFlag = 1;
                                                }
                                            }
                                        }
                                        
                                        fin.close();
                                        
                                        if (uploadCheckFlag == 0){
                                            readPosition2 = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [1] = uploadTemp2 [readPosition2], readPosition2++; //--1 X Position
                                                    finData [2] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [3] = uploadTemp2 [readPosition2], readPosition2++; //--2 Y Position
                                                    finData [4] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [5] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [6] = uploadTemp2 [readPosition2], readPosition2++; //--4 Connect No
                                                    finData [7] = uploadTemp2 [readPosition2], readPosition2++; //--7 Channel No
                                                    
                                                    finData [1] = finData [0]*256+finData [1];
                                                    finData [3] = finData [2]*256+finData [3];
                                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                    
                                                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayExpandTemp2 [expandTempCount2] = finData [1], expandTempCount2++;
                                                        arrayExpandTemp2 [expandTempCount2] = finData [3], expandTempCount2++;
                                                        arrayExpandTemp2 [expandTempCount2] = finData [6], expandTempCount2++;
                                                        arrayExpandTemp2 [expandTempCount2] = finData [7], expandTempCount2++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                        }
                                        else commonDataUploadCheck = 1;
                                        
                                        delete [] uploadTemp2;
                                    }
                                    else commonDataUploadCheck = 1;
                                    
                                    for (int counter3 = 0; counter3 < expandTempCount2/4; counter3++){
                                        arrayExpandTemp2 [counter3*4+2] = connectNoRef [arrayExpandTemp2 [counter3*4+2]*2+1];
                                    }
                                    
                                    indexCount = 0;
                                    
                                    writingArray = new char [expandTempCount2*2+200];
                                    
                                    for (int counter3 = 0; counter3 < expandTempCount2/4; counter3++){
                                        dataTemp = arrayExpandTemp2 [counter3*4];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        dataTemp = arrayExpandTemp2 [counter3*4+1];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        dataTemp = arrayExpandTemp2 [counter3*4+2];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)arrayExpandTemp2 [counter3*4+3], indexCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile5 (folderPath.c_str(), ofstream::binary);
                                    
                                    if (commonDataUploadCheck == 0 && outfile5.is_open()){
                                        outfile5.write ((char*)writingArray, indexCount);
                                        outfile5.close();
                                    }
                                    else commonDataUploadCheck = 1;
                                    
                                    delete [] writingArray;
                                    delete [] arrayExpandTemp2;
                                    
                                    folderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameClear+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameClear+"_ExtendAreaData";
                                    
                                    sizeForCopy = 0;
                                    
                                    if (stat(folderPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        arrayExpandDataTemp = new int [sizeForCopy+50];
                                        int expandDataTempCount = 0;
                                        
                                        fin.open(folderPath.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            uploadTemp2 = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp2, sizeForCopy+50);
                                            fin.close();
                                            
                                            readPosition2 = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [1] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [2] = uploadTemp2 [readPosition2], readPosition2++; //--1 Connect No
                                                    finData [3] = uploadTemp2 [readPosition2], readPosition2++; //--2 Channel No
                                                    finData [4] = uploadTemp2 [readPosition2], readPosition2++; //--3 Average Value
                                                    finData [5] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [6] = uploadTemp2 [readPosition2], readPosition2++;
                                                    finData [7] = uploadTemp2 [readPosition2], readPosition2++; //--4 Total pixel
                                                    
                                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                    
                                                    if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [2], expandDataTempCount++;
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [3], expandDataTempCount++;
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [4], expandDataTempCount++;
                                                        arrayExpandDataTemp [expandDataTempCount] = finData [7], expandDataTempCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                            
                                            delete [] uploadTemp2;
                                        }
                                        else commonDataUploadCheck = 1;
                                        
                                        //for (int counterA = 0; counterA < expandDataTempCount/4; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandDataTemp [counterA*4+counterB];
                                        //    cout<<" arrayExpandDataTemp "<<counterA<<endl;
                                        //}
                                        
                                        for (int counter3 = 0; counter3 < expandDataTempCount/4; counter3++){
                                            arrayExpandDataTemp [counter3*4] = connectNoRef [arrayExpandDataTemp [counter3*4]*2+1];
                                        }
                                        
                                        indexCount = 0;
                                        
                                        writingArray = new char [expandDataTempCount*2+20];
                                        
                                        for (int counter3 = 0; counter3 < expandDataTempCount/4; counter3++){
                                            dataTemp = arrayExpandDataTemp [counter3*4];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            writingArray [indexCount] = (char)arrayExpandDataTemp [counter3*4+1], indexCount++;
                                            writingArray [indexCount] = (char)arrayExpandDataTemp [counter3*4+2], indexCount++;
                                            
                                            dataTemp = arrayExpandDataTemp [counter3*4+3];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile6 (folderPath.c_str(), ofstream::binary);
                                        
                                        if (commonDataUploadCheck == 0 && outfile6.is_open()){
                                            outfile6.write ((char*)writingArray, indexCount);
                                            outfile6.close();
                                        }
                                        else commonDataUploadCheck = 1;
                                        
                                        delete [] writingArray;
                                        delete [] arrayExpandDataTemp;
                                    }
                                    else commonDataUploadCheck = 1;
                                }
                                
                                delete [] connectNoRef;
                            }
                            
                            if (commonDataUploadCheck == 1){
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < imageSizeTreat+1; counter3++) delete [] revisedMapTemp [counter3];
                        delete [] revisedMapTemp;
                        
                        delete [] dataHoldMap;
                        
                        //**********Lineage data update*********
                        for (int counter2 = 0; counter2 < lineageCleanCount/8; counter2++){
                            lineageClean [counter2*8+6] = lineageNoRef [lineageClean [counter2*8+6]*2+1];
                            
                            if (lineageClean [counter2*8+7] != 0) lineageClean [counter2*8+7] = lineageNoRef [lineageClean [counter2*8+7]*2+1];
                        }
                        
                        //for (int counterA = 0; counterA < lineageCleanCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageClean [counterA*8+counterB];
                        //    cout<<" lineageClean "<<counterA<<endl;
                        //}
                        
                        writingArray = new char [lineageCleanCount/8*25+25];
                        
                        indexCount = 0;
                        
                        for (int counter2 = 0; counter2 < lineageCleanCount/8; counter2++){
                            if (lineageClean [counter2*8] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageClean [counter2*8]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageClean [counter2*8];
                            }
                            
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            if (lineageClean [counter2*8+1] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageClean [counter2*8+1]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageClean [counter2*8+1];
                            }
                            
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = lineageClean [counter2*8+2];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)lineageClean [counter2*8+3], indexCount++;
                            
                            if (lineageClean [counter2*8+4] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageClean [counter2*8+4]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageClean [counter2*8+4];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            if (lineageClean [counter2*8+5] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageClean [counter2*8+5]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageClean [counter2*8+5];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            dataTemp = lineageClean [counter2*8+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = lineageClean [counter2*8+7];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter2 = 0; counter2 < 25; counter2++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile (lingDataPath.c_str(), ofstream::binary);
                        
                        if (outfile.is_open()){
                            outfile.write ((char*) writingArray, indexCount);
                            outfile.close();
                        }
                        else commonDataUploadCheck = 1;
                        
                        delete [] writingArray;
                        
                        //for (int counterA = 0; counterA < lineageCleanCount/8; counterA++){
                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageClean [counterA*8+counterB];
                        //	cout<<" lineageClean "<<counterA<<endl;
                        //}
                        
                        //**********Lineage Start end, 1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end**********
                        for (int counter2 = 0; counter2 < lineageStartEndCleanCount/8; counter2++){
                            lineageStartEndClean [counter2*8] = lineageNoRef [lineageStartEndClean [counter2*8]*2+1];
                        }
                        
                        mainDataEntry = new char [lineageStartEndCleanCount*7+10];
                        totalEntryCount = 0;
                        
                        for (int counter2 = 0; counter2 < lineageStartEndCleanCount; counter2++){
                            extension = to_string (lineageStartEndClean [counter2]);
                            
                            for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile3 (connectStartEndPath.c_str(), ofstream::binary);
                        
                        if (outfile3.is_open()){
                            outfile3.write (mainDataEntry, totalEntryCount);
                            outfile3.close();
                        }
                        else commonDataUploadCheck = 1;
                        
                        delete [] mainDataEntry;
                        
                        //**********Lineage Status data update: Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage**********
                        for (int counter2 = 0; counter2 < lineageStatusCleanCount/3; counter2++){
                            lineageStatusClean [counter2*3] = lineageNoRef [lineageStatusClean [counter2*3]*2+1];
                        }
                        
                        mainDataEntry = new char [lineageStatusCleanCount*6+10];
                        totalEntryCount = 0;
                        
                        for (int counter2 = 0; counter2 < lineageStatusCleanCount; counter2++){
                            extension = to_string (lineageStatusClean [counter2]);
                            
                            for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile2 (lingStatusPath.c_str(), ofstream::binary);
                        
                        if (outfile2.is_open()){
                            outfile2.write (mainDataEntry, totalEntryCount);
                            outfile2.close();
                        }
                        else commonDataUploadCheck = 1;
                        
                        delete [] mainDataEntry;
                        
                        //for (int counterA = 0; counterA < lineageStatusCleanCount/3; counterA++){
                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<lineageStatusClean [counterA*3+counterB];
                        //	cout<<" lineageStatusClean "<<counterA<<endl;
                        //}
                        
                        //=======Mitosis Data Save=======
                        if (mitosisTempCount != 0){
                            arrayMitosisTemp2 = new int [mitosisTempCount+50];
                            mitosisTempCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                                if (lineageNoRef [arrayMitosisTemp [counter2*4]*2+1] != 0){
                                    arrayMitosisTemp2 [mitosisTempCount2] = lineageNoRef [arrayMitosisTemp [counter2*4]*2+1], mitosisTempCount2++;
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+1], mitosisTempCount2++;
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+2], mitosisTempCount2++;
                                    arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter2*4+3], mitosisTempCount2++;
                                }
                            }
                            
                            if (mitosisTempCount2 != 0){
                                oin.open(mitosisDataPath.c_str(), ios::out);
                                
                                if (oin.is_open()){
                                    for (int counter2 = 0; counter2 < mitosisTempCount2; counter2++) oin<<arrayMitosisTemp2 [counter2]<<endl;
                                    
                                    oin.close();
                                }
                            }
                            
                            delete [] arrayMitosisTemp2;
                        }
                        
                        //=======Lineage Partner========
                        if (lineagePartnerInfoTempCount != 0){
                            arrayLineagePartnerInfoTemp2 = new string [lineagePartnerInfoTempCount+50];
                            lineagePartnerInfoTempCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < lineagePartnerInfoTempCount/6; counter2++){
                                if (atoi(arrayLineagePartnerInfoTemp [counter2*6+1].c_str()) <= maxLineageNo && lineageNoRef [atoi(arrayLineagePartnerInfoTemp [counter2*6+1].c_str())*2+1] != 0 && atoi(arrayLineagePartnerInfoTemp [counter2*6+4].c_str()) <= maxLineageNo && lineageNoRef [atoi(arrayLineagePartnerInfoTemp [counter2*6+4].c_str())*2+1] != 0){
                                    extension = to_string (lineageNoRef [atoi(arrayLineagePartnerInfoTemp [counter2*6+1].c_str())*2+1]);
                                    extension2 = to_string (lineageNoRef [atoi(arrayLineagePartnerInfoTemp [counter2*6+4].c_str())*2+1]);
                                    
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = extension, lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+2], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+3], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = extension2, lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+5], lineagePartnerInfoTempCount2++;
                                }
                            }
                            
                            if (lineagePartnerInfoTempCount2 != 0){
                                oin.open(fusionPartnerPath.c_str(), ios::out);
                                
                                if (oin.is_open()){
                                    for (int counter2 = 0; counter2 < lineagePartnerInfoTempCount2; counter2++) oin<<arrayLineagePartnerInfoTemp2 [counter2]<<endl;
                                    
                                    oin.close();
                                }
                                else commonDataUploadCheck = 1;
                            }
                            
                            delete [] arrayLineagePartnerInfoTemp2;
                        }
                        
                        //=======Auto data save========
                        if (autoCheckCleanTempCount != 0){
                            oin.open(autoCheckPath.c_str(), ios::out);
                            
                            if (oin.is_open()){
                                for (int counter2 = 0; counter2 < autoCheckCleanTempCount/8; counter2++){
                                    oin<<lineageNoRef [autoCheckCleanTemp [counter2*8]]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+1]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+2]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+3]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+4]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+5]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+6]<<endl;
                                    oin<<autoCheckCleanTemp [counter2*8+7]<<endl;
                                }
                                
                                oin.close();
                            }
                        }
                        
                        //-----Queue data update-----
                        //-----1. Treatment name, 2. Lineage No, 3. Cell number, 4. Image number, 5. Status, 6. Processing status-----
                        for (int counter2 = 0; counter2 < queueListCleanCount/6; counter2++){
                            if (queueListClean [counter2*6] == treatmentNameClear){
                                lineageDataExtract = queueListClean [counter2*6+1].substr(1);
                                
                                if (atoi(lineageDataExtract.c_str()) <= maxLineageNo && lineageNoRef [atoi(lineageDataExtract.c_str())*2+1] != 0){
                                    clearLineage = to_string (lineageNoRef [atoi(lineageDataExtract.c_str())*2+1]);
                                    
                                    if (clearLineage.length() == 1) clearLineage = "L0000"+clearLineage;
                                    else if (clearLineage.length() == 2) clearLineage = "L000"+clearLineage;
                                    else if (clearLineage.length() == 3) clearLineage = "L00"+clearLineage;
                                    else if (clearLineage.length() == 4) clearLineage = "L0"+clearLineage;
                                    else if (clearLineage.length() == 5) clearLineage = "L"+clearLineage;
                                    
                                    queueListClean [counter2*6+1] = clearLineage;
                                }
                                else queueListClean [counter2*6+1] = "0";
                            }
                        }
                        
                        //for (int counterA = 0; counterA < queueListCleanCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<queueListClean [counterA*6+counterB];
                        //	cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //	cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < doneListCleanCount/5; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<doneListClean [counterA*5+counterB];
                        //	cout<<" doneListClean "<<counterA<<endl;
                        //}
                        
                        //=========Done List UpDate==========
                        for (int counter2 = 0; counter2 < doneListCleanCount/5; counter2++){
                            if (doneListClean [counter2*5] == treatmentNameClear){
                                lineageDataExtract = doneListClean [counter2*5+1].substr(1);
                                
                                if (atoi(lineageDataExtract.c_str()) <= maxLineageNo && lineageNoRef [atoi(lineageDataExtract.c_str())*2+1] != 0){
                                    clearLineage = to_string (lineageNoRef [atoi(lineageDataExtract.c_str())*2+1]);
                                    
                                    if (clearLineage.length() == 1) clearLineage = "L0000"+clearLineage;
                                    else if (clearLineage.length() == 2) clearLineage = "L000"+clearLineage;
                                    else if (clearLineage.length() == 3) clearLineage = "L00"+clearLineage;
                                    else if (clearLineage.length() == 4) clearLineage = "L0"+clearLineage;
                                    else if (clearLineage.length() == 5) clearLineage = "L"+clearLineage;
                                    
                                    doneListClean [counter2*5+1] = clearLineage;
                                }
                                else doneListClean [counter2*5+1] = "0";
                            }
                        }
                        
                        //for (int counterA = 0; counterA < doneListCleanCount/5; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<doneListClean [counterA*5+counterB];
                        //	cout<<" doneListClean "<<counterA<<endl;
                        //}
                        
                        indicatorCount++;
                        
                        progressValue = indicatorCount;
                        progressTiming = 3;
                        
                        usleep(1000);
                        
                        //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                        //	cout<<" arrayDoneList "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //  for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //  cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        // time9 = clock();
                        // cout<<time9-time8<< "t9"<<endl;
                        
                        indicatorCount++;
                        
                        progressValue = indicatorCount;
                        progressTiming = 3;
                        
                        usleep(1000);
                    }
                    
                    delete [] amendTimeList;
                }
                else if (stat(lingDataPath.c_str(), &sizeOfFile) == 0) commonDataUploadCheck = 1;
                
                delete [] lineageNoRef;
                delete [] lineageFolderList;
            }
            
            delete [] lineageClean;
            delete [] lineageStatusClean;
            delete [] lineageStartEndClean;
            delete [] arrayMitosisTemp;
            delete [] arrayLineagePartnerInfoTemp;
            delete [] autoCheckCleanTemp;
            
            if (commonDataUploadCheck == 1){
                break;
            }
        }
        
        if (commonDataUploadCheck == 0){
            //-----Queue List UpDate-----
            if (queueListCleanCount > queueListLimit){
                delete [] arrayQueueList;
                arrayQueueList = new string [queueListCleanCount+5000];
                queueListLimit = queueListCleanCount+5000;
            }
            
            queueListCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCleanCount/6; counter1++){
                if (queueListClean [counter1*6+1] != "0"){
                    arrayQueueList [queueListCount] = queueListClean [counter1*6], queueListCount++;
                    arrayQueueList [queueListCount] = queueListClean [counter1*6+1], queueListCount++;
                    arrayQueueList [queueListCount] = queueListClean [counter1*6+2], queueListCount++;
                    arrayQueueList [queueListCount] = queueListClean [counter1*6+3], queueListCount++;
                    arrayQueueList [queueListCount] = queueListClean [counter1*6+4], queueListCount++;
                    arrayQueueList [queueListCount] = queueListClean [counter1*6+5], queueListCount++;
                }
            }
            
            if (queueListCount != 0){
                mainDataEntry = new char [queueListCount*12+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile5 (queueListPath.c_str(), ofstream::binary);
                
                if (outfile5.is_open()){
                    outfile5.write (mainDataEntry, totalEntryCount);
                    outfile5.close();
                }
                
                delete [] mainDataEntry;
            }
            
            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
            //    cout<<" arrayQueueList "<<counterA<<endl;
            //}
            
            //-----Done List UpDate-----
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                for (int counter2 = 0; counter2 < doneListCleanCount/5; counter2++){
                    if (arrayQueueList [counter1*6] == doneListClean [counter2*5] && arrayQueueList [counter1*6+1] == doneListClean [counter2*5+1] && arrayQueueList [counter1*6+2] == doneListClean [counter2*5+2]){
                        doneListClean [counter2*5+1] = "0";
                    }
                }
            }
            
            if (doneListCleanCount > doneListLimit){
                delete [] arrayDoneList;
                arrayDoneList = new string [doneListCleanCount+500];
                doneListLimit = doneListCleanCount+500;
            }
            
            doneListCount = 0;
            
            for (int counter1 = 0; counter1 < doneListCleanCount/5; counter1++){
                if (doneListClean [counter1*5+1] != "0"){
                    arrayDoneList [doneListCount] = doneListClean [counter1*5], doneListCount++;
                    arrayDoneList [doneListCount] = doneListClean [counter1*5+1], doneListCount++;
                    arrayDoneList [doneListCount] = doneListClean [counter1*5+2], doneListCount++;
                    arrayDoneList [doneListCount] = doneListClean [counter1*5+3], doneListCount++;
                    arrayDoneList [doneListCount] = doneListClean [counter1*5+4], doneListCount++;
                }
            }
            
            if (doneListCount != 0){
                mainDataEntry = new char [doneListCount*10+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < doneListCount; counter1++){
                    extension = arrayDoneList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                
                if (outfile2.is_open()){
                    outfile2.write (mainDataEntry, totalEntryCount);
                    outfile2.close();
                }
                
                delete [] mainDataEntry;
            }
            
            //for (int counterA = 0; counterA < doneListCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
            //    cout<<" arrayDoneList "<<counterA<<endl;
            //}
            
            progressTiming = 5;
            
            usleep(1000);
            
            setStatus2 = 2;
            
            if (queueRestartFlag == 10) queueRestartFlag = 11;
            if (cleaningManualProgress == 6) cleaningManualProgress = 7;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            if (progressTiming != 0) progressTiming = 5;
            
            errorNoHold = 1;
        }
        
        delete [] queueListClean;
        delete [] doneListClean;
        
        cleaningProgress = 0;
    });
}

@end
