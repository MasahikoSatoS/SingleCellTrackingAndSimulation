//
//  SearchOperations.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-12-02.
//
//

#ifndef SEARCHOPERATIONS_H
#define SEARCHOPERATIONS_H
#import "Controller.h" 
#endif

@interface SearchOperations : NSObject  <NSTableViewDataSource>{
    int tableRowHoldSearch; //Hold table row position
    
    int lineageNoSelect; //Lineage no select
    int searchFlag; //Search flag
    int logicStatus1; //Logic 1
    int logicStatus2; //Logic 2
    int logicStatus3; //Logic 3
    int lingNoSearchHold; //Lineage no search
    int lingSearchPosition; //Lineage search position
    int searchType; //Search type
    
    IBOutlet NSTextField *treatmentSL;
    IBOutlet NSTextField *lineageSL;
    IBOutlet NSTextField *eventSL1;
    IBOutlet NSTextField *eventSL2;
    IBOutlet NSTextField *eventSL3;
    IBOutlet NSTextField *eventSL4;
    IBOutlet NSTextField *logicSL1;
    IBOutlet NSTextField *logicSL2;
    IBOutlet NSTextField *logicSL3;
    IBOutlet NSTextField *lingInfoSL;
    IBOutlet NSTextField *lingInfoCellNoSL;
    IBOutlet NSTextField *lingInfoStatusSL;
    IBOutlet NSTextField *cellInfoSL;
    IBOutlet NSTextField *cellInfoSTtimeSL;
    IBOutlet NSTextField *cellInfoEDtimeSL;
    IBOutlet NSTextField *cellInfoSTStatusSL;
    IBOutlet NSTextField *cellInfoEDStatusSL;
    IBOutlet NSTextField *cellInfoFUMKSL;
    IBOutlet NSTextField *mainLabel;
    
    IBOutlet NSBrowser *searchListBrowser;
    IBOutlet NSTableView *timeViewSearch;
    
    id addDelete;
    id dataSaveRead;
}

-(id)init;
-(void)dealloc;
-(int)lineageDataReadSearch;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)completeSelect:(id)sender;
-(IBAction)logicSet1:(id)sender;
-(IBAction)logicSet2:(id)sender;
-(IBAction)logicSet3:(id)sender;
-(IBAction)clear1:(id)sender;
-(IBAction)clear2:(id)sender;
-(IBAction)clear3:(id)sender;
-(IBAction)clear4:(id)sender;
-(IBAction)search:(id)sender;
-(IBAction)lineageSelect:(id)sender;
-(IBAction)fusionPartner:(id)sender;
-(IBAction)setIN:(id)sender;
-(IBAction)setDD:(id)sender;
-(IBAction)setTD:(id)sender;
-(IBAction)setHD:(id)sender;
-(IBAction)setOF:(id)sender;
-(IBAction)setCD:(id)sender;
-(IBAction)setIP:(id)sender;
-(IBAction)setMI:(id)sender;
-(IBAction)setCF:(id)sender;
-(IBAction)setFM:(id)sender;

@end
