//
//  DataSaveRead.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-04-05.
//

#ifndef DATASAVEREAD_H
#define DATASAVEREAD_H
#import "Controller.h"
#endif

@interface DataSaveRead : NSObject{
    id lineSet;
    id fileUpdate;
}

-(int)lineageDataRead;
-(void)saveTrackingCurrent;
-(void)saveParameters;
-(void)reviseLineClear;

@end
