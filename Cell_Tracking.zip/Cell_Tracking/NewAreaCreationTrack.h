//
// NewAreaCreationTrack.h
// Cell_Tracking
//
// Created by Masahiko Sato on 13/10/11.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef NEWAREACREATIONTRACK_H
#define NEWAREACREATIONTRACK_H
#import "Controller.h"
#endif

@interface NewAreaCreationTrack : NSObject {
    id expandLine;
    id fileUpdate;
}

-(int)newAreaLineCut;

@end
