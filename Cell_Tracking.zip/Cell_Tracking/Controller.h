//
// Controller.h
// Cell_Tracking
//
// Created by Masahiko Sato on 08/01/10.
// Copyright Masahiko Sato 2010 All rights reserved.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "Controller2.h"
#import "FileUpdate.h"
#import "DataSaveRead.h"
#import "TiffFileRead.h"
#import "ImageList.h"
#import "ImageListTable.h"
#import "analysisLoad.h"
#import "TimeOne.h"
#import "CleaningSet.h"
#import "Cleaning.h"
#import "FolderCopy.h"
#import "ActiveProcessMonitor.h"
#import "Communication.h"
#import "ASCIIconversion.h"
#import "QueueSort.h"
#import "DoneOthersSort.h"

#import "TrackingController.h"
#import "TrackingWindow.h"
#import "DisplayWindow.h"
#import "DisplayController.h"
#import "ListWindow.h"
#import "TrackRecord.h"
#import "TrackRecordAuto.h"
#import "TrackingSet.h"
#import "TrackingDataSave.h"
#import "EventSet.h"
#import "MitosisSD.h"
#import "ParameterSet.h"
#import "ParameterSetOperation.h"

#import "SnapShot.h"
#import "Merge.h"
#import "ExpandLine.h"
#import "DicExpandAll.h"
#import "LineSet.h"
#import "GapFill.h"
#import "NewAreaCreation.h"
#import "NewAreaCreationTrack.h"
#import "AreaCircleCut.h"
#import "AreaCircleCutTrack.h"
#import "AreaSetFluorescent.h"

#import "AddDelete.h"
#import "AddDeleteAuto.h"
#import "TargetFind.h"
#import "TargetFind2.h"
#import "SearchController.h"
#import "SearchOperations.h"
#import "OptionsController.h"
#import "OptionsOperation.h"

#import "FluorescentQuantitationController.h"
#import "FluorescentQuantitationTable.h"

#import "ExportController.h"
#import "ExportDisplay.h"

#import "DatabaseRepairController.h"
#import "DataRepair1.h"
#import "DataRepair2.h"
#import "DataRepair3.h"
#import "DataRepairProcess.h"
#import "DatabaseRepairImport.h"
#import "DatabaseRepairOperation.h"
#import "DatabaseLineListTable.h"
#import "DatabaseList.h"
#import "DataRepairReadWrite.h"

#import "ImageSequenceDisplayController.h"
#import "ImageDisplay1.h"
#import "ImageDisplay2.h"
#import "ImageDisplay3.h"
#import "ImageDisplay4.h"
#import "ImageDisplay5.h"
#import "ImageDisplay6.h"
#import "ImageDisplay7.h"
#import "ImageDisplay8.h"
#import "ImageDisplay9.h"
#import "ImageDisplay10.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <iomanip>
#include <ctime>
#endif

using namespace std;

extern NSString *notificationToImageList;
extern NSString *notificationToImageListTable;
extern NSString *notificationToAnalysisLoad;
extern NSString *notificationToTimeOne;
extern NSString *notificationToCommunication;
extern NSString *notificationToActiveProcess;

extern NSString *notificationToTrackingController;
extern NSString *notificationToTrackingWindow;
extern NSString *notificationToNavigationWindow;
extern NSString *notificationToDisplayController;
extern NSString *notificationToListWindow;
extern NSString *notificationToParameterSet;
extern NSString *notificationToParameterSetOperations;

extern NSString *notificationToDicExpand;

extern NSString *notificationToSearchController;
extern NSString *notificationToSearchOperations;
extern NSString *notificationToOptionController;
extern NSString *notificationToOptionOperations;

extern NSString *notificationToFluoresentQuantOptions;
extern NSString *notificationToFluorescentQuantitationTable;

extern NSString *notificationToExportController;
extern NSString *notificationToExportDisplay;

extern NSString *notificationToDatabaseRepairController;
extern NSString *notificationToDatabaseRepairOperation;
extern NSString *notificationToDatabaseVerificationTable;
extern NSString *notificationToDatabaseListTable;

extern NSString *notificationToImageSequenceDisplayController;
extern NSString *notificationToImageDisplay1;
extern NSString *notificationToImageDisplay2;
extern NSString *notificationToImageDisplay3;
extern NSString *notificationToImageDisplay4;
extern NSString *notificationToImageDisplay5;
extern NSString *notificationToImageDisplay6;
extern NSString *notificationToImageDisplay7;
extern NSString *notificationToImageDisplay8;
extern NSString *notificationToImageDisplay9;
extern NSString *notificationToImageDisplay10;

//-----Main Controller related-----
extern int initialSetOperation; //Initial Set Display Status
extern int analysisLoadOperation; //Analysis Load Display status
extern int trackingTableOperation; //Tracking Window Display Status
extern int navigationOperation; //Navigation Window Table Display Status
extern int listWindowOperation; //List Window Display status
extern int searchWindowOperation; //Search Window Display status
extern int maxTimePoint; //Max time point
extern int timeOneHold; //Time One Point
extern int timeEndHold; //Time End Point
extern int ifStartHold; //IF start
extern int imageEndHold; //Image end hold
extern int setStatus1; //Initial Set or Analysis Load SET status: ON when it has done
extern int setStatus2; //Initial Set or Analysis Load SET status: ON when it has done
extern int setStatus3; //Initial Set or Analysis Load SET status: ON when it has done
extern int setStatus4; //Initial Set or Analysis Load SET status: ON when it has done
extern int setStatus5; //Initial Set or Analysis Load SET status: ON when it has done
extern int setStatus6; //Browser "reload" display control
extern int setStatus7; //Initial Set or Analysis Load SET status: ON when it has done
extern int setStatus8; //List browser block
extern int addDelInsert; //Add, Del, Insert Done
extern int clearBack; //Back to the set point, image position hold
extern int queueHoldingStatus; //Hold Queue control status
extern int autoExpand; //Set Fluorescent autoExpand status (set fluorescent expand lines (three channels) and create area information)
extern int autoExpandLine; //Set Line (DIC) autoExpand status, if it is ON, Merge extendTrack will be activated: Set outline with a standard method (area set), then expand and area set again
extern int listCrickMonitor; //When list is Cricked, set Flag, allow to up-load relevant image data
extern int imageNumber; //Image NO
extern int imageLoadMonitor; //Hold Time One until images are loaded
extern int trackingTableSetDone; //Call when Tracking is pressed to set Table View
extern int lineageCellSwitch; //Select Table: Lineage or Cell
extern int trackingImageLock; //Image lock for tracking
extern int tableTrackingProcessing; //Table view for Tracking
extern int overTimeRemoveFlag; //When CD, OF, BD, TD, HD, CF are set, this flag is set to remove temp data over the current time point
extern int divisionFusionCancelFlag; //Set when Division or Fusion are cancelled
extern int autoRefStatus; //Set when auto shape set is ON
extern int imageReadTiming; //Image reading timing for tracking window
extern int imageReadTimingNavigation; //Image reading timing for navigation window
extern int displaySetDICFlag; //Fluorescent cut off display flag
extern int displaySetFluorescentFlag; //Fluorescent cut off display flag
extern int displaySetCutFlag1; //Fluorescent cut off display flag
extern int displaySetCutFlag2; //Fluorescent cut off display flag
extern int displaySetCutFlag3; //Fluorescent cut off display flag
extern int displaySetCutFlag4; //Fluorescent cut off display flag
extern int displaySetCutFlag5; //Fluorescent cut off display flag
extern int displaySetCutFlag6; //Fluorescent cut off display flag
extern int displaySetCutFlag7; //Fluorescent cut off display flag
extern int imageDimension; //Image dimension, Has to be square
extern int trackingCheckInterval; //Hold Tracking Check Interval data
extern int quickLineageConnect; //Hold quick lineage connect data
extern int cellJumpFirstLast; //Hold Jump status: cell First time point or Last
extern int mitosisSaveCount; //Activate mitosis clean when the pattern was saved 15 times
extern string errorInfoFlag; //Control error info display
extern int queueDisplayOptions; //Hold queue display status
extern int doneDisplayOptions; //Hold done display status
extern int imageReturnPosition; //Hold Image Return options (0: Last, 1: Check)
extern int imageReturnPositionSet; //Flag to display
extern int autoTrackingLimitHold; //Tracking limit
extern int analysisSavingInProgress; //Flag for analysis saving
extern int mainSavingInProgress; //Flag for main saving
extern int cleaningProgress; //Flag for cleaning
extern double progressValue; //Hold Progress indicator value
extern int progressTiming; //Hold Progress indicator timing
extern int progressTimingB; //Hold Progress indicator timing
extern int progressTimingC; //Hold Progress indicator timing
extern double lineWidth; //Display line width
extern int lineTypeSet; //Display line type
extern int cleaningManualProgress; //Manual cleaning control
extern int dataEntryStatus; //Connect folder data entry status hold
extern int autoTrackFirstSave; //Set 1 when the firs backup has been done
extern string saveInfo; //Set info required to save write
extern int errorNoHold; //Error no

extern int tableRowHold; //Hold table row position
extern int tableCallCount; //Hold table scan count
extern int tableCurrentRowHold; //Hold table current row position
extern int tableNewRowHold; //For Table View, prevent multiple processing

extern int cellLineageInfoListCreationCall; //Call cell lineage list creation
extern int cellNumberInfoListCreationCall; //Call cell number list creation
extern int displayWindowCall; //Call Display Window
extern int listSwitchCall; //List Call
extern int listSwitchCallStatus; //List Call status
extern int quickLineSetCall; //Call line set
extern int quickLineageCall; //Call lineage set
extern int quickConnectCall; //Call Connect set
extern int inputNumber; //Jump data hold
extern int inputNumberCall; //Jump data call

extern int *arrayCellLineageInfo; //Cell Lineage Status array
extern int cellLineageInfoCount;
extern int cellLineageInfoLimit;
extern int cellLineageInfoStatus;
extern int *arrayCellNumberInfo; //Cell Information Hold array
extern int cellNumberInfoCount;
extern int cellNumberInfoLimit;
extern int cellNumberInfoStatus;
extern int *arrayLineageData;  //Lineage data array
extern int lineageDataCount;
extern int lineageDataLimit;
extern int lineageDataAddition;
extern int lineageDataStatus;
extern string *arrayQueueList; //Queue List Hold array
extern int queueListCount;
extern int queueListLimit;
extern string *arrayQueueListDisplay; //Queue List Hold Display array
extern int queueListDisplayCount;
extern int queueListDisplayLimit;
extern string *arrayDoneList; //Done List Hold array
extern int doneListCount;
extern int doneListLimit;
extern string *arrayDoneListDisplay; //Done List Hold Display array
extern int doneListDisplayCount;
extern int doneListDisplayLimit;
extern string *arrayTreatmentStatus; //Hold status of treatment
extern int treatmentStatusCount;
extern string *arrayGetList; //Hold info to browser
extern int getListCount;
extern int getListLimit;
extern string *arrayImageSizeList; //Hold Image size info
extern int imageSizeListCount;
extern string *arrayFileDelete; //Array for directory file name
extern int fileDeleteCount;
extern int fileDeleteLimit;
extern string *arrayLineagePartnerInfo; //Array holding fusion partner info and fusion marks
extern int lineagePartnerInfoCount;
extern int lineagePartnerInfoStatus;
extern int *arrayMergeSelect; //Hold connect info related to Merge of selected groups
extern int mergeSelectCount;
extern int *arrayTimePointSaveList; //Hold Modified time points
extern int timePointListMax;
extern int timePointListSaveStatus;
extern int restoreDataFlag; //Set when previous data restore is started
extern int autoCheckFlag; //Set when auto. data was read
extern int *autoCheckTemp; //Temp array for auto check
extern int autoCheckTempCount;
extern int autoCheckTempLimit;
extern int autoCheckTempStatus;
extern int phaseStatus; //Phase DIC status

extern string pathNameString; //Path Name
extern string analysisImageName; //Analysis Name
extern string analysisImageNameSelect; //Analysis Name (temp)
extern string analysisID; //Analysis ID
extern string analysisIDSelect; //Analysis ID (temp)
extern string treatmentNameHold; //Treatment Name
extern string treatmentNameKeep; //Treatment Name Keep
extern string cellLineageNoHold; //Cell Lineage No
extern string cellNoHold; //Cell No

extern uint8_t *fileReadArray;//Array holding image data
extern string exType; //Extension type tif or bmp
extern string exTypeIF; //Extension type tif or bmp
extern int tifImageColorGray; //Tif image color type

//-----Initial Set and Analysis-----
extern int saveDataStatus; //At once Tracking is started, this flag blocks to perform Initial setting
extern int listTableCall; //List Table call
extern string *arrayDirectoryInfo; //Array holding file names in a directory for Analysis; for browser
extern int directoryInfoCount;
extern int directoryInfoLimit;
extern string *arrayDirectoryInitialInfo; //Array holding file names in a directory for Initial setting; for browser
extern int directoryInitialInfoCount;
extern int directoryInitialInfoLimit;
extern string *arraySelectedTreatmentProc; //Array for information of selected processes
extern int selectedTreatmentProcCount;
extern string *arrayTrackingList; //Array holding Tracked data list
extern int trackingListCount;
extern int trackingListLimit;
extern string destinationName; //Name for folder copy destination
extern string destinationAnalysisPath; //Path for folder copy destination
extern string sourceAnalysisPath; //Path for folder copy source

//-----Tracking controller-----
extern int cellDivisionSetCount; //Count Number of cell division Set
extern int divisionTypeHold; //Hold division type
extern int divisionWarningType; //Cell event warning type
extern int fusionOperation; //Fusion operation variables
extern int fusionPartnerLin; //Fusion partner lineage no
extern int fusionPartnerCellNo; //Fusion partner cell no
extern int fusionMarkImage; //Fusion mark image no
extern int fusionStatusFollow; //Set when fusion partner data is set
extern int saveShortCutNumber; //Short cut processing no hold
extern int listOnOffFlag; //List On OFF flag
extern string *arrayListHold; //Queue or Done list, copy hold, used for display
extern int listHoldCount;
extern int listHoldProcessFlag;
extern int forceSetAutoFlag; //When force set was performed, set this flag On. When press Forward, perform force set
extern int lineageWritingCheck; //Lineage writing check

extern int trackJump; //Image jump
extern int displayJump; //Display image jump
extern int removeAll; //Remove all point in an area
extern int xCellPosition; //Target cell X position
extern int yCellPosition; //Target Cell Y position
extern int displayPositionType; //Window display position: 1: one of window exceed screen limit
extern int trackingOn; //Tracking Status
extern int trackingOnInfoDisplay; //Display Flag for Tracking Info
extern int windowLock; //Window Lock
extern int areaSelectStatus; //Area select
extern int lineDraw; //Window Lock
extern int doubleClick; //Double click status
extern int doubleClickStatusHold; //Hold the status (Line) at the moment of click
extern int tableListSwitch; //Switch Table List
extern int trackingPermit; //If this is "1", allow to do tracking image modification, it become "1", when cut line is set
extern int trackingLowerLimit; //Tracking Range lower Limit
extern int trackingUpperLimit; //Tracking Range Upper Limit
extern int upperLimitMap; //Tracking limit Map Upper
extern int firstModificationPoint; //Hold First Image No, which was modified
extern int lineModificationFlag; //When line is modified, Flag ON
extern int cutBase; //Determine whether keep entry temp files or not, if there were files upon entry, keep it.
extern int lineModificationRecord; //Set when line modification was first set
extern int characterDisplayFlag; //Hold ch display option
extern int characterDisplayNavFlag; //Hold ch display option for the navigation
extern int cutOff1; //Hold cut off value 1
extern int cutOff2; //Hold cut off value 2
extern int cutOff3; //Hold cut off value 3
extern int cutOff4; //Hold cut off value 4
extern int cutOff5; //Hold cut off value 5
extern int cutOff6; //Hold cut off value 6
extern int cutOff7; //Hold cut off value 7
extern int cutStatusDic; //Hold DIC cut off value
extern int cutStatusFluorescent; //Hold Fluorescent cut off value
extern int cutDisplay; //Cut off display value
extern int backForwardMode; //Review back forward mode
extern int mergeAllFlag; //Merge all connect flag

extern int lineSetWindowCallTrack; //Call from line set
extern int lineSetWindowCallDisplay; //Call from line set
extern int lineAreaCall; //Call from Line/Area setting for Window display
extern string gravityCenterNotRecorded; //GC center record failed, hold image no

extern int gravityCenterXHold1; //Gravity Center X1
extern int gravityCenterYHold1; //Gravity Center Y1
extern int gravityAverageHold1; //Gravity Center Area1
extern int gravityCellNo1; //Gravity Center Cell no 1
extern int gravityCenterXHold2; //Gravity Center X2
extern int gravityCenterYHold2; //Gravity Center Y2
extern int gravityAverageHold2; //Gravity Center Area2
extern int gravityCellNo2; //Gravity Center Cell no 2
extern int gravityCenterXHold3; //Gravity Center X3
extern int gravityCenterYHold3; //Gravity Center Y3
extern int gravityAverageHold3; //Gravity Center Area3
extern int gravityCellNo3; //Gravity Center Cell no 3
extern int gravityCenterXHold4; //Gravity Center X4
extern int gravityCenterYHold4; //Gravity Center Y4
extern int gravityAverageHold4; //Gravity Center Area4
extern int gravityCellNo4; //Gravity Center Cell no 4

//-----Tracking controller arrays-----
extern int *arrayConnectLineListLocal; //Hold connect line data created by Cell Carving
extern int connectLineListLocalCount;
extern int connectLineListLocalLimit;
extern int connectLineListLocalStatus;
extern int *arrayLineageGRCurrent; //Target XY data hold during the Tracking
extern int lineageGRCurrentCount;
extern int lineageGRCurrentLimit;
extern int *arrayReferenceLine; //Reference Line to Set Next Connect
extern int referenceLineCount;
extern int referenceLineLimit;
extern int *arrayLineageStartEnd; //Lineage Start/end point
extern int lineageStartEndCount;
extern int lineageStartEndLimit;
extern int lineageStartEndStatus;
extern int *arrayXYPositionList; //XY position hold
extern int xyPositionListCount;
extern int xyPositionListStatus;
extern int *arrayMasterLineForTracking; //Master Data Line data, for Tracking window
extern int masterLineForTrackingCount;
extern int masterLineForTrackingStatus;
extern int *arrayMasterLineForDisplay; //Master Data Line data, for Display window
extern int masterLineForDisplayCount;
extern int masterLineForDisplayStatus;
extern int *arrayMasterLineGravityCenter; //Master Data Line data, Gravity Center
extern int masterLineGravityCenterCount;
extern int masterLineGravityCenterLimit;
extern int masterLineGravityCenterStatus;
extern int *arrayMasterLineSelected; //Master Data Line data, Connect Info
extern int masterLineSelectedCount;
extern int masterLineSelectedLimit;
extern int masterLineSelectedAddition;
extern int masterLineSelectedStatus;
extern int *arrayPositionRevise; //Line Data, hold
extern int positionReviseCount;
extern int positionReviseLimit;
extern int positionReviseAddition;
extern int positionReviseStatus;
extern int *arrayTargetHold; //Cut Line data hold
extern int targetHoldCount;
extern int targetHoldLimit;
extern int targetHoldStatus;
extern int *arrayTargetHoldInfo; //Cut line information hold
extern int targetHoldInfoCount;
extern int targetHoldInfoLimit;
extern int *arrayConnectLineageRel; //Connect No-LineageNo relation Table
extern int connectLineageRelCount;
extern int connectLineageRelLimit;
extern int connectLineageRelStatus;
extern int *arrayEventSequence; //Event sequence
extern int eventSequenceCount;
extern int eventSequenceLimit;
extern int *arrayEventSequenceHold; //Event sequence current hold
extern int eventSequenceHoldCount;
extern int *arrayLineageGravityCenterCurrentHold; //Gravity Center current hold
extern int lineageGravityCenterCurrentHoldCount;
extern int *arrayLineageExtraction; //Amend line construct for save
extern int lineageExtractionCount;
extern int lineageExtractionLimit;
extern int *arrayMasterLineSelectedDisplay; //Master Data array for Display window
extern int masterLineSelectedDisplayCount;
extern int masterLineSelectedDisplayStatus;
extern int masterLineSelectedDisplayLimit;
extern int masterLineSelectedDisplayAddition;
extern int *arrayMasterLineGravityCenterDisplay; //Gravity Center array for Display window
extern int masterLineGCDisplayCount;
extern int masterLineGCDisplayStatus;
extern int masterLineGCDisplayLimit;
extern int *lineageProcessList; //Array for cell Time One cell lineage re-set/send to info to AddDel
extern int *arrayTarget; //Cut line data from image
extern int targetCount;
extern int targetLimit;
extern int targetStatus;
extern int *arrayTargetPrevHold; //Cut line data from image Previous line
extern int targetPrevHoldCount;
extern int targetPrevHoldLimit;
extern int targetPrevHoldStatus;
extern int *arrayGapData; //For cut line, get gap XY data
extern int gapDataCount;
extern int gapDataLimit;
extern int *arrayLineDataProcessing; //Hold line Data to area creation
extern int lineDataProcessingCount;
extern int *arrayGravityCenterRev; //Hold Gravity Center Data
extern int gravityCenterRevCount;
extern int gravityCenterRevLimit;
extern int gravityCenterRevStatus;
extern int *arrayTimeSelected; //Hold Info of Line Data
extern int timeSelectedCount;
extern int timeSelectedLimit;
extern int timeSelectedStatus;
extern int *arrayTimeSelectedHold; //Hold Info of Line Data (hold Original)
extern int timeSelectedHoldCount;
extern int timeSelectedHoldStatus;
extern int *arrayAssociateData; //Associated Data
extern int associateDataCount;
extern int associateDataLimit;
extern int associateDataStatus;
extern int *attachedNumberList; //Hold attached connect no. list
extern int attachedNumberListCount;
extern int attachedNumberListStatus;
extern int *groupNumberList; //Hold Group no list
extern int groupNumberListCount;
extern int groupNumberListStatus;
extern int *cellEndHold; //Hold cell End Time
extern int cellEndHoldCount;
extern int cellEndHoldLimit;
extern int cellEndHoldStatus;

extern int **sourceImage; //Source (DIC) image
extern int sourceImageStatus;
extern int **revisedMap; //Hold connect no map
extern int revisedMapStatus;
extern int **revisedWorkingMap; //Hold connect no map-working map
extern int revisedWorkingMapStatus;
extern int **revisedWorkingMap2; //Map for non Time One or Tracking
extern int revisedWorkingMapTime2;
extern int revisedWorkingMapSize2;
extern int revisedWorkingMapStatus2;
extern string revisedWorkingMapName2; //Temp hold treatment name

extern int **internalZeroMap; //Internal Zero
extern int **targetMap; //ConnectivityMap for Cut
extern int *arrayListPattern; //Cell list pattern
extern int listPatternCount;
extern int listPatternStatus;

extern string cellNoHoldDiv1; //Division cell no hold
extern string cellNoHoldDiv2; //Division cell no hold
extern string cellNoHoldDiv3; //Division cell no hold
extern string cellNoHoldDiv4; //Division cell no hold
extern string divisionWarning; //Cell event warning
extern string targetLostMark; //When target is lost, set this mark
extern int cutLimitValueHold; //DIC Fluorescent cut level set
extern int cutDisplayValueHold; //DIC Fluorescent cut level value
extern int forceSetStatus; //Set when force set perform

extern int fluorescentDisplayMode; //Fluorescent image display value or div into range
extern int fluorescentDisplayRange; //Range hold, 2, 3 or 4
extern int fluorescentDisplayMax; //Fluorescent Max value

//-----Paths-----
extern string imageFolderPath; //Image Folder path
extern string displayImagePath; //Path for images to be displayed: used by Window display routines
extern string trackDataFolderPath; //Tracking Data Folder Path
extern string masterDataFolderPath; //Master data path
extern string backUpTempPath; //Backup data path

//-----Tracking Window-----
extern int imageWidthTrack; //Image width hold
extern int imageHeightTrack; //Image Height
extern int magnificationTrack; //Magnification fold
extern int imageNumberTrackForDisplay; //Image NO
extern int keyLockON; //Key Lock
extern double xPositionTrack; //X Position Image Origin
extern double yPositionTrack; //Y Position Image Origin
extern double windowWidthTrack; //Window/Image position adjust
extern double windowHeightTrack; //Window/Image position adjust

//-----Display Window-----
extern int imageWidthDisplay; //Image width hold
extern int imageHeightDisplay; //Image Height
extern int magnificationDisplay; //Magnification fold
extern int imageNumberDisplayForDisplay; //Image NO Display
extern double xPositionDisplay; //X Position Image Origin
extern double yPositionDisplay; //Y Position Image Origin
extern int synchroOn; //Synchronize display position
extern double windowWidthDisplay; //Window/Image position adjust
extern double windowHeightDisplay; //Window/Image position adjust

//-----List Window-----
extern int listDisplaySelection; //Status cell pattern or mitosis
extern int listToTrackCall; //Call Tracking display
extern int currentPageNoCell; //Current page no
extern int currentPageNoMitosis; //Hold current page number
extern int boxImageNumber; //Hold box image position
extern string listLingNoHold; //Hold box Lineage No for List
extern string listCellNoHold; //Hold box Cell No for List
extern string listLingRecent; //Hold box Lineage No for List
extern string listCellRecent; //Hold box Cell No for List
extern string listLingCurrent; //Hold box Lineage No for List
extern string listCellCurrent; //Hold box Cell No for List
extern int listLoadingProcessing; //List lading processing status

//-----Time One-----
extern int timeOneStatus; //Time One
extern int tableDataSetDone; //Call table View when Time One set has done
extern int timeOneX; //X position, Time One display
extern int timeOneY; //Y position, Time One display
extern int timeOneQuickSet; //Time one short cuts
extern int currentConnectNo; //Current connect no
extern int currentPositionSet; //For Cell position go through
extern int timeOneLaunch; //Time one launch
extern string timeOneConnectStatus; //Time one status

extern int **connectMap200; //Connect map 200
extern int **connectMap220; //Connect map 220
extern int **connectMap240; //Connect map 240
extern int **connectMapA; //Connect map Th1
extern int **connectMapB; //Connect map Th2
extern int **connectMapC; //Connect map Th3
extern int **connectMapD; //Connect map Th4
extern int **connectivityMap;  //Connect map
extern int dicAllStartFlag; //DIC expand control

//-----Communication related-----
extern int connectionSend1; //Communication step Control
extern int *fusionPartnerInfo; //Hold Info for fusion partner
extern int fusionPartnerInfoCount;
extern int fusionPartnerInfoLimit;
extern string treatmentNameAuto; //Treatment name auto
extern string lineageNoAuto; //Lineage no auto
extern string cellNoAuto; //Cell no auto
extern string checkStatusAuto; //Check status auto
extern string cellNoAuto; //Cell no auto
extern string imageNoAuto; //Image no auto
extern string additionalInfoAuto; //Cell information for auto record
extern string instructionCCPath; //Instruction path
extern string instructionRRPath; //Instruction path
extern int queueRestartFlag; //Queue restart timing
extern int multipleLaunchBlock; //Multiple launch block
extern int firstTrackStart; //Folder copy control
extern int reviseTimingCount; //Count update timing of image end and queue check
extern int upDateCompleteFlag; //Update completion flag

//-----Activity monitor-----
extern int runStatusCellCurving; //Run status
extern int cellCurvingRunningFlag; //Run status flag
extern int subCompleteFlag; //Track auto record completion check

//-----Fluorescent-----
extern int fluorescentNo1; //Fluorescent color No
extern int fluorescentNo2; //Fluorescent color No
extern int fluorescentNo3; //Fluorescent color No
extern int fluorescentNo4; //Fluorescent color No
extern int fluorescentNo5; //Fluorescent color No
extern int fluorescentNo6; //Fluorescent color No
extern int fluorescentEntryCount; //Fluorescent Entry No
extern int fluorescentDetection; //Find Fluorescent files
extern int fluorescentDisplayNo; //Fluorescent display no
extern int fluorescentDetectionDisplay; //Find Fluorescent display
extern int fluorescentCutOff1; //Fluorescent cut off value
extern int fluorescentCutOff2; //Fluorescent cut off value
extern int fluorescentCutOff3; //Fluorescent cut off value
extern int fluorescentCutOff4; //Fluorescent cut off value
extern int fluorescentCutOff5; //Fluorescent cut off value
extern int fluorescentCutOff6; //Fluorescent cut off value
extern int fluorescentValueDisplayControl; //Fluorescent display
extern int sliderBarSet; //Fluorescent slider bar

extern int **fluorescentMap1; //Fluorescent Maps
extern int fluorescentMapStatus1;
extern int fluorescentMapFind1;
extern int **fluorescentMap2; //Fluorescent Maps
extern int fluorescentMapStatus2;
extern int fluorescentMapFind2;
extern int **fluorescentMap3; //Fluorescent Maps
extern int fluorescentMapStatus3;
extern int fluorescentMapFind3;
extern int **fluorescentMap4; //Fluorescent Maps
extern int fluorescentMapStatus4;
extern int fluorescentMapFind4;
extern int **fluorescentMap5; //Fluorescent Maps
extern int fluorescentMapStatus5;
extern int fluorescentMapFind5;
extern int **fluorescentMap6; //Fluorescent Maps
extern int fluorescentMapStatus6;
extern int fluorescentMapFind6;
extern int *expandFluorescentOutline; //Fluorescent line expand
extern int expandFluorescentOutlineCount;
extern int expandFluorescentOutlineLimit;
extern int expandFluorescentOutlineStatus;
extern int *expandFluorescentData; //Fluorescent Data expand
extern int expandFluorescentDataCount;
extern int expandFluorescentDataLimit;
extern int expandFluorescentDataStatus;
extern int *connectDataExchange; //Connect data for expansion
extern int connectDataExchangeStatus;
extern int *arrayFluorescentCutOff; //Fluorescent cut off data array
extern int fluorescentCutOffCount;
extern int fluorescentCutOffStatus;

extern string fluorescentName1; //Fluorescent Name
extern string fluorescentName2; //Fluorescent Name
extern string fluorescentName3; //Fluorescent Name
extern string fluorescentName4; //Fluorescent Name
extern string fluorescentName5; //Fluorescent Name
extern string fluorescentName6; //Fluorescent Name
extern string fluorescentColorNameTemp1; //Fluorescent color Name
extern string fluorescentColorNameTemp2; //Fluorescent color Name
extern string fluorescentColorNameTemp3; //Fluorescent color Name
extern string fluorescentColorNameTemp4; //Fluorescent color Name
extern string fluorescentColorNameTemp5; //Fluorescent color Name
extern string fluorescentColorNameTemp6; //Fluorescent color Name

//-----Fluorescent IF option-----
extern int ifEntry; //IF entry flag
extern int fluorescentNoHold1; //Fluorescent color No for IF entry
extern int fluorescentNoHold2; //Fluorescent color No for IF entry
extern int fluorescentNoHold3; //Fluorescent color No for IF entry
extern int fluorescentNoHold4; //Fluorescent color No for IF entry
extern int fluorescentNoHold5; //Fluorescent color No for IF entry
extern int fluorescentNoHold6; //Fluorescent color No for IF entry
extern int fluorescentEntryCountHold; //Fluorescent Entry No
extern string fluorescentNameHold1; //Fluorescent color Name for IF entry
extern string fluorescentNameHold2; //Fluorescent color Name for IF entry
extern string fluorescentNameHold3; //Fluorescent color Name for IF entry
extern string fluorescentNameHold4; //Fluorescent color Name for IF entry
extern string fluorescentNameHold5; //Fluorescent color Name for IF entry
extern string fluorescentNameHold6; //Fluorescent color Name for IF entry
extern string fluorescentRoundNo; //Fluorescent round no
extern string *arrayIFDataHold; //IF data array
extern int ifConnectNoUpDate; //Connect No ifStartHold-1: Following original
extern int ifConnectNoCurrent; //Connect No ifStartHold-1: Current

//-----Search List-----
extern string treatmentNameSearch; //Treatment name for search
extern string treatmentNameSearchSelect; //Treatment name for search select
extern string searchStatus1; //Search select
extern string searchStatus2; //Search select
extern string searchStatus3; //Search select
extern string searchStatus4; //Search select
extern int tableCallSearchCount; //Table Operation count
extern int tableCurrentRowHoldSearch; //Table search operation
extern int tableNewRowHoldSearch; //For Table View, prevent multiple processing
extern int *arrayLineageSearchData; //Lineage data for Search
extern int lineageDataSearchCount;
extern int lineageDataSearchStatus;
extern int *arrayLineageStartEndSearch; //Lineage Start End for Search
extern int lineageStartEndSearchCount;
extern int lineageStartEndSearchStatus;
extern int *arrayLineageList; //Lineage list for Search
extern int lineageListCount;
extern int lineageListStatus;
extern int *arraySearchCellList; //Cell list for Search
extern int searchCellListCount;
extern int searchCellListStatus;

//-----Option Operation-----
extern string selectedTreatName; //Selected treatment name
extern int optionCall; //Option call
extern int optionDisplayCall; //Option Display call
extern int optionWindowOperation; //Option window operation
extern int tableRowHoldOperation; //Hold table row position
extern int tableCallOperationCount; //Option table count
extern int tableCurrentRowHoldOperation; //Option table row count
extern int tableNewRowHoldOperation; //For Table View, prevent multiple processing
extern int *arrayOperationData; //Operation data array
extern int operationDataStatus;

//-----Parameter Set-----
extern int parameterSethWindowOperation; //Parameter set controls
extern double mitosisSDHold; //Hold mitosis SD
extern int mitosisValueHold; //Hold mitosis Value
extern int divisionDistanceHold; //Division distance
extern double *arrayMitosisSDInfo; //Hold mitosis SD info
extern int *arrayMitosisValueInfo; //Hold mitosis value info
extern int mitosisInfoSetCount;
extern int mitosisInfoRemoveCount;
extern int mitosisAreaHold; //Mitosis area data hold
extern double mitosisRelativeLowHold; //Area relative to the parent, lower limit
extern double mitosisRelativeHighHold; //Area relative to the parent, higher limit
extern double *arrayForAreaSize; //Hold area size data
extern int forAreaSizeCount;
extern int displayMode; //Display mode hold
extern int jumpAllFlag; //Hold status for connect jump
extern int connectExpandFlag; //Hold status for connect expand, 0: non, 1: only the first connect, 2: first+second connect
extern int mapMergeStatus; //Hold flag for map merges
extern int percentOverlap; //Hold percent overlap value for next target, second, third... connect merge
extern int gravityCenterMoveLimitFlag; //GC Center moving limit status hold
extern int autoCheckDistanceHold; //Hold auto-check distance
extern int autoCheckAreaHold; //Hold auto-check area
extern int autoCheckDivisionHold; //Hold auto-check division
extern int autoCheckDistanceFoldHold; //Hold auto-check distance fold
extern int autoCheckIntensityHold; //Hold auto-check intensity
extern int optionalShiftPercent; //Hold auto-check intensity
extern int mitosisOffFlag; //Mitosis set On Off
extern int fusionMarkSetFlag; //Fusion Mark set On Off

//-----Verification repair-----
extern int repairWindowOperation; //Verification window operation
extern int *checkList; //Hold Check list
extern int checkListCount;
extern int checkListLimit;
extern int checkListStatus;
extern int *checkErrorTimeList; //Hold time that errors were found
extern int checkErrorTimeListCount;
extern int checkErrorTimeListStatus;
extern int repairOperationTableCurrentRow; //Table row current hold
extern int *checkResults; //Check Results hold
extern int checkResultsCount;
extern int checkResultsLimit;
extern int checkResultsStatus;
extern int connectForVerifyHold; //Connect No. hold
extern int dataTypeSend; //Display data type
extern int *arrayLineageRepairData; //Lineage data array for repair
extern int lineageDataRepairCount;
extern string lineageDataPath; //Lineage data path for repair
extern int *arrayPositionReviseVer; //Position data for repair
extern int positionReviseVerCount;
extern int *arrayGravityCenterVerRev; //Gravity center data for repair
extern int gravityCenterRevVerCount;
extern int *arrayRepairDataHoldVerRev; //Array associated data for repair
extern int repairDataHoldVerCount;
extern string masterDataRevPath; //Master data path for repair
extern string *arrayListString; //Array List data hold
extern int listStringCount;
extern int listStringLimit;
extern int listStringStatus;
extern int listArrayStatusHold; //List status
extern int repairListTableCurrentRow; //List Row current
extern int treatmentMainDisplayCall; //Treatment name display call for repair
extern int secondLineDisplayCall; //Second line display call
extern int secondLineDisplayRemoveCall; //Second line display remove call
extern string treatVerNameHold; //Treatment name for repair hold
extern int verificationPositionCall; //Verification time point hold
extern int xPositionVer; //X Position for verification
extern int yPositionVer; //Y Position for verification
extern int connectVer; //Connect no for verification
extern int errorNumberHold; //Error no
extern int errorTimeModeHold; //Error time
extern string nameStringRep; //Name string for repair
extern string treatSetNameHold; //Treatment name for repair
extern int progressControl; //Progress monitor
extern int checkOverrideFlag; //Check override

//-----Image sequence operation-----
extern int imageSeqOperation; //Image sequence window control
extern int seqImageClick; //Sequence image click
extern int seqImageFirst; //Sequence image first
extern int seqImageLast; //Sequence image last
extern int seqImageCheck; //Sequence image CK
extern int seqImageMitosis; // Sequence image mitosis
extern int seqImageFusionMark; //Sequence image Mark
extern int seqImageTop; //Sequence image top
extern int seqOpenFlag; //Sequence image open flag
extern int seqImageNoSet1; //Sequence image 1
extern int seqImageNoSet2; //Sequence image 2
extern int seqImageNoSet3; //Sequence image 3
extern int seqImageNoSet4; //Sequence image 4
extern int seqImageNoSet5; //Sequence image 5
extern int seqImageNoSet6; //Sequence image 6
extern int seqImageNoSet7; //Sequence image 7
extern int seqImageNoSet8; //Sequence image 8
extern int seqImageNoSet9; //Sequence image 9
extern int seqImageNoSet10; //Sequence image 10
extern int noOfSeqDisplay; //Sequence no display
extern int imageWidthSeq; //Sequence image width
extern int seqWindowFront; //Sequence image bring front
extern int trackForwardControl; //Bring Tracking window front Press 0

//-----Fluorescent quantitation option-----
extern int fluorescentDivisionNo; //Fluorescent quant Div no, Key4; 0, key5; 100/Key4; 0, key5; 50, key6; 100/Key4; 0, key5; 33, key6; 66, key7; 100/Key4; 0, key5; 25, key6; 50, key7; 75, key8; 100
extern int fluorescentDivisionTime; //Fluorescent quantitation image no
extern int fluorescentDivisionCh; //Fluorescent channel to divide, Live 1-6, IF 7-12
extern int fluorescentDivisionStatus; //Fluorescent quantitation On Off
extern int fluorescentOptionOperation; //Fluorescent quantitation option control
extern int fluorescentOpOperationTableCurrentRow; //Fluorescent option table row
extern int *fluorescentOpInformationHold; //Fluorescent option information
extern int fluorescentOpInformationCount;
extern int fluorescentOpInformationStatus;
extern int *fluorescentLevelDataHold; //Fluorescent level quantitation data hold
extern int fluorescentLevelDataCount;
extern int fluorescentLevelDataStatus;
extern int fluorescentLevelDataLimit;
extern int fluorescentSaveCount; //Fluorescent save count
extern string fluorescentSavePath; //Fluorescent quantitation data save path
extern int fluorescentLevelValueHold; //Fluorescent level value hold

//-----Image export-----
extern int exportOperation; //Image export Window Display status
extern int *arrayPositionExport; //Position data for Export
extern int positionExportCount;
extern int positionExportStatus;
extern int *arrayGravityCenterExport; //Gravity Center data for Export
extern int gravityCenterExportCount;
extern int gravityCenterExportStatus;
extern int *arrayTimeSelectedExport; //Time select data for Export
extern int timeSelectedExportCount;
extern int timeSelectedExportStatus;
extern int imageHeightExport; //Image Height
extern CGFloat *colorList; //Color list
extern int colorListCount;
extern int colorListStatus;
extern double *cellNoHoldExport; //Cell no hold
extern int channelNoExport; //Export channel set
extern int outlineWidthExport; //Export outline width
extern int nonTargetWidthExport; //NonTarget width export
extern int nonTargetLengthExport; //NonTarget Length export
extern int nonTargetFontExport; //NonTarget Font export
extern int targetWidthExport; //Target width export
extern int targetLengthExport; //Target length export
extern int targetFontExport; //Target Font export
extern int titleFontExport; //Title font export
extern int titleNameExport; //Title name export
extern string titleNameExportHold; //Title Name string
extern string pathExtension; //Path to send to draw
extern string displayImageLoadPath; //Display path
extern string displayImageSavePath; //Save path
extern string displayImageAllPath; //Display image path
extern int timingEx; //Processing timing
extern int startExport; //Export start
extern int endExport; //Export end
extern int windowLockEX; //Window lock
extern double boxStartImageX; //Box start X display
extern double boxStartImageY; //Box start Y display
extern double boxEndImageX; //Box end X display
extern double boxEndImageY; //Box end Y display
extern int *noOfCellsInArea; //No of cells in an area
extern int noOfCellsInAreaCount;
extern int noOfCellsInAreaStatus;
extern int densityDiameterHold; //Density diameter
extern int densityValueMaxHold; //Density value hold
extern int densityModeHold; //Density mode
extern int **circleAreaHold; //Circle area hold
extern int circleAreaHoldStatus;
extern CGFloat *arrayColorRange; //Color range
extern int lineageFontColorExport; //Lineage font color
extern string ascIIstring; //ASCI II
extern int lineageLimitHold; //Lineage limit
extern int *arrayMotilityBasicInfo; //Motility info array
extern int motilityBasicInfoStatus;
extern int motilityBasicInfoCount;
extern int thresholdCutHold; //TH cut hold
extern int areaSizeMinHold; //Area size min hold
extern int areaSizeMaxHold; //Area size max hold
extern int thresholdStatusHold; //TH status hold
extern int *particleCountingDataHold; //Particle count
extern int particleCountingDataHoldCount;
extern int particleCountingDataHoldStatus;
extern int xyPositionCall; //XY position call
extern int xPositionExHold; //X position export hold
extern int yPositionExHold; //Y position export hold
extern int displayOutlineSet; //On Off Outline display
extern int displayNonTargetSet; //On Off Target display
extern double displayTargetFontSizeSet; //On Off Target display
extern string *arrayLineTrace; //Array holding XY1-XY2 line data
extern int lineTraceCount;
extern int lineTraceLimit;
extern int lineTraceStatus;
extern int lineTraceOnOff; //Status of Line trace function
extern int lineTraceStartX; //Trace Start X
extern int lineTraceStartY; //Trace Start Y
extern int lineTraceStartTimePoint; //Trace Start Time
extern int lineTraceEndX; //Trace End X
extern int lineTraceEndY; //Trace End Y
extern int lineTraceEndTimePoint; //Trace End Time
extern int lineTraceActive; //Set when line trace Start is On
extern int lineTraceDeleteOn; //Set when line trace Delete is On
extern int lineExportColor; //Hold line color for export
extern int lineExportWidth; //Hold line width for export

//==========Array Summary==========
//**********arrayTimeSelected**********
//1. Status:[0: Non-Track, 1: Track, 3: Non-Track-Deleted (Delete "0", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning),
//4: Track-Deleted (Delete "1 or 7", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning), 7: Cell-Confirmed, 2: Noise, 5: Only for Time One (Area) Non-Track-Deleted, 6: Only for Time One (Area) Track-Deleted]
//2. Previous Connect No: When Cut line is set, Hold cut line no that created the connect; When data is saved this information is cleared;
//3. Starting position of MasterData
//4. Cut Line number hold: when cut line is set, the line number is entered; When data is saved this information is cleared;
//5. OPEN;
//6. OPEN;
//7. OPEN;
//8. OPEN;
//9. Connect no.
//10. Lineage no.

//*********Amend line********
//1. Image No;
//2. X position;
//3. Y position;
//4. Event Type (type for upper end)
//5. Connect No;
//6. Lineage No;

//*********arrayGravityCenterRev (GR Center)**********
//1. X Position;
//2. Y Position;
//3. Total Area;
//4. Average;
//5. Connect No.
//6. Target Hit;

//*********arrayAssociateData (not used)--Cell Carving is using this assay, so keep it**********
//1. Connect No;
//2. Process type;
//3. Cut type;
//4. Pair no;
//5. Cell dimension
//6. Reserve;

//**********ConnectLineageRel**********
//1. Lineage No;
//2. Connect No;
//3. Image number;
//4. Cell no;
//5. Target (0: non-target, 1: target);
//6. Reserve;

//**********Position Revise (main line data array)**********
//1. X position;
//2. Y position;
//3. Average:
//4. Connect No;
//5. Cell No;
//6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
//7. Lineage no;

//**********Start/End assay*********
//1. Lineage no;
//2. Cell no;
//3. X position;
//4. Y position;
//5. Start;
//6. Image start;
//7. End;
//8. Image end

//Insert: 0-one before the insert point: Lineage No, -1, -1, -1, start, image start, end, image end;
//Insert: Then insert data start

//*********Done List**********
//1. Treatment name;
//2. Lineage No;
//3. Cell number;
//4. Image number (End);
//5. Check status;
//WO Mark(TD, HD, MD, NS, IP, MC, AC, DB, RC, SC, CM, CN, FM, TL, FE, FO, MF, NM, DL, OF, FC, ME, CF, XS, AM, CL, OK. OK/e)
//W Mark(TD/m, HD/m, MD/m, NS/m, IP/m, MC/m, AC/m, DB/m, RC/m, SC/m, CM/m, CN/m, FM/m, TL/m, FE/m, FO/m, MF/m, NM/m, DL/m, OF/m, FC/m, ME/m, CF/m, XS/m, AM/m, CL/m, OK/m, OK/me)

//*********Queue List**********
//1. Treatment name; 30
//2. Lineage No; 6
//3. Cell number; 11
//4. Image number (at the point of Amend); 4
//5. Status (None (N), /m (m)) 5
//6. Processing status 4
//[Wait: Waiting, Proc: Processing: Redo: Will re-do]

//**********arrayLineageData**********
//1. X position
//2. Y position
//3. Time Point
//4. Event Type
//[1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92]
//[FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One]
//5. Parent Cell Number/Fusion: Hold cell number of fusion partner
//6. Cell Number
//7. Cell Lineage No
//8. For Fusion, Hold cell lineage No of fusion partner

//Insert Dummy: -1, -1, time point, event type: 13, 0, -1, ing no, 0

//*********Fluorescent Line**********
//1. X Position
//2. Y position
//3. Connect No
//4. Channel No (1, 2, 3, 4, 5, 6 Live, 7, 8, 9, 10, 11, 12 IF)

//*********Fluorescent Data**********
//1. Connect No
//2. Channel No (1, 2, 3, 4, 5, 6 Live, 7, 8, 9, 10, 11, 12 IF)
//3. CH Value
//4. CH Area

//*********arrayTreatmentStatus*********
//1. TreatName
//2. Lineage Data check (0: not fined, 1: find)
//3. Status Data check (0: not fined, 1: find)
//4. Other Map Data check (0: not fined, 1: find)
//5. Time One-DIC start
//6. Time End-DIC end
//7. Time Max-DIC end
//8. IF Start-IF start
//9. Image End-Last image no

//*********arrayIFDataHold*********
//Can hold data up to 30 rounds of data
//1. IF No 0 0
//2. IF Fluorescent name1 1 1
//3. IF Fluorescent name2 2 2
//4. IF Fluorescent name3 3 3
//5. IF Fluorescent name4   4
//6. IF Fluorescent name5   5
//7. IF Fluorescent name6   6
//8. IF Fluorescent No1 4 7
//9. IF Fluorescent No2 5 8
//10. IF Fluorescent No3 6 9
//11. IF Fluorescent No4   10
//12. IF Fluorescent No5   11
//13. IF Fluorescent No6   12
//14. IF Fluorescent Count 7 13
//15. Image no 8 14

//*********arrayCellNumberInfo**********
//1. Cell Number
//2. Starting time
//3. End Time (if OP, -1) [Display, OP, CL]
//4, Starting Status (0: no entry, 1:I, 2:M, 3:BD, 4:TD, 5:HD, 6:CD, 7:FU, 8:IP, 9:OF, 10:EF) [Display, IN, BD, TD, HD, FU]
//5. End status (0: no entry, 1:I, 2:M, 3:BD, 4:TD, 5:HD, 6:CD, 7:FU, 8:IP, 9:OF, 10:EF) [Display OP, BD, TD, HD, CD, FU, OF, EF]
//6. Check results
//WO Mark(21: TD, 22: HD, 23: MD, 24: NS, 25: IP, 26: MC, 27: AC, 28: DB, 29: RC, 30: SC, 31: CM, 32: CN, 33: FM, 34: TL, 35: FE, 36: FO, 37: MF, 38: NM, 39: DL, 40: OF, 41: FC, 42: ME, 43: CF, 44: XS, 45: AM, 46: CL)
//W Mark(51: TD/m, 52: HD/m, 53: MD/m, 54: NS/m, 55: IP/m, 56: MC/m, 57: AC/m, 58: DB/m, 59: RC/m, 60: SC/m, 61: CM/m, 62: CN/m, 63: FM/m, 64: TL/m, 65: FE/m, 66: FO/m, 67: MF/m, 68: NM/m, 69: DL/m, 70: OF/m, 71: FC/m, 72: ME/m, 73: CF/m, 74: XS/m, 75 AM/m, 76: CL/m, 77: /m)
//7. Lineage No

//*********arrayFluorescentCutOff**********
//1. Image No
//2. Cut off 1
//3. Cut off 2
//4. Cut off 3
//5. Cut off 4
//6. Cut off 5
//7. Cut off 6

//*********arrayCellLineageInfo**********
//1. Cell Lineage NO
//2. Status, 1: Done, 0: Open; Garbage 3: Done, 2: Open;
//3. Number of cells in the lineage

//********arrayImageSizeList*********
//1.TreatName
//2.Image size

//********arrayLineagePartnerInfo*********
//1.TreatName
//2.Lineage No
//3.Cell no
//4.W-image position
//5.Partner Lineage No
//6.Partner Cell No

//********arrayMitosisStatus*********
//1.Lineage No
//2.Cell no
//3.Image No
//4.Status data (10: Mitosis, 1,2,6: Mitosis status, 3,4: cell death status)

//********TargetHold (hold cut line info)*********
//1.X position
//2.Y position
//3.Linear; 0, circular; 1
//4.Line No

//*********Search array*********
//1. Lineage no
//2. cell no
//3. open/close (0, open, 1. close)
//4. garbage
//5. marker

//**********Option operation array********
//1. Setting condition (0: None, 1:Auto, 2:TLRmv (remove))
//2. Remove Status (0: nil, 1:Not Ready, 2: Ready, 5. Done
//3. Redo Status (0: nil, 1:Proceed-redo, 2:Proceed (when this is set, remove TL when auto Processing starts), 3:Cancel, 4:Done)
//4. 1:Allow, 2:Not Allow

//====Remove/Save Mode======
//1. If an end exists, no removal--to remove, cancel end
//2. If an end is BD etc, no removal--to remove cancel M, remove from the point of M

//********fluorescentOpInformationHold*********
//1. Time
//2. Channel
//3. No of Level no
//4. Merged

//Save data file name: Id_Treat_IFLevelData~(time)_(ch)_Lev
//ch:1,2,3,4,5,6, 9: Original saved

//********Cell numbering rule**********
//0: progenitor
//100000000:G1
//-100000000:G1
//+10000000:G2
//-10000000:G2
//till G9, e.g. 111111111;
//1111111111: G10, 400001700, 400001300, / 400001600 / 400001400
//81111111 G10, 300001700, 300001300, / 300001600 / 300001400
//400001711: G13, 600001700, 600001300, / 600001600 / 600001400
//300001711 G13, 500001700, 500001300, / 500001600 / 500001400
//600001711: G15 2e15 = 32768 cells
//500001711 G15

//5 00000 700, 5: generation mark, 00000: cell count, 700: cell number, 700, 710, 711.

//conversion to cell number: till G9; 111111111000000, till G12; 400001700 > 700 > 700-500 = 200 > 200*1000 = 200000 > 111111111000000-200000 = 1111111110800000
//conversion to cell number: till G15; 1111111110800000, 600001700 > 700 > 700-500 = 200 > 1111111110800000-200 = 1111111110799800

@interface Controller : NSObject <NSTextFieldDelegate, NSTableViewDataSource, NSToolbarItemValidation> {
    int treatmentDisplayFirstSet; //Set flag when the treatment name is set
    int firstCleaningFlag; //Flag for backup take at the first cleaning
    
    IBOutlet NSTextField *analysisSeriesDisplay;
    IBOutlet NSTextField *analysisIDDisplay;
    IBOutlet NSTextField *treatmentDisplay;
    IBOutlet NSTextField *cellLineageNoDisplay;
    IBOutlet NSTextField *cellNoDisplay;
    IBOutlet NSTextField *timeOneDisplay;
    IBOutlet NSTextField *timeEndDisplay;
    IBOutlet NSTextField *timeMaxDisplay;
    IBOutlet NSTextField *ifStartDisplay;
    IBOutlet NSTextField *imageEndDisplay;
    IBOutlet NSTextField *relatedInfoDisplay;
    IBOutlet NSTextField *inputNoSet;
    IBOutlet NSTextField *listName;
    IBOutlet NSTextField *statusDisplay;
    IBOutlet NSTextField *contentInLineage;
    IBOutlet NSTextField *lineageStatus;
    IBOutlet NSTextField *lineageCurrentNumber;
    IBOutlet NSTextField *cellCurrentNumber;
    IBOutlet NSTextField *cellCurrentStTime;
    IBOutlet NSTextField *cellCurrentEndTime;
    IBOutlet NSTextField *cellCurrentStStatus;
    IBOutlet NSTextField *cellCurrentEndStatus;
    IBOutlet NSTextField *listTreatmentDisplay;
    IBOutlet NSTextField *lowerLimitTrack;
    IBOutlet NSTextField *upperLimitTrack;
    IBOutlet NSTextField *queueHoldingDisplay;
    IBOutlet NSTextField *ch2Label;
    IBOutlet NSTextField *ch3Label;
    IBOutlet NSTextField *ch4Label;
    IBOutlet NSTextField *ch5Label;
    IBOutlet NSTextField *ch6Label;
    IBOutlet NSTextField *ch7Label;
    IBOutlet NSTextField *ch2Display;
    IBOutlet NSTextField *ch3Display;
    IBOutlet NSTextField *ch4Display;
    IBOutlet NSTextField *ch5Display;
    IBOutlet NSTextField *ch6Display;
    IBOutlet NSTextField *ch7Display;
    IBOutlet NSTextField *fluorescentValue;
    IBOutlet NSTextField *autoExpandDisplay;
    IBOutlet NSTextField *autoExpandLineDisplay;
    IBOutlet NSTextField *errorExplanationDisplay;
    IBOutlet NSTextField *trackingIntervalDisplay;
    IBOutlet NSTextField *limitIntervalDisplay;
    IBOutlet NSTextField *optionCheck;
    IBOutlet NSTextField *queueOptionCheck;
    IBOutlet NSTextField *doneOptionCheck;
    IBOutlet NSTextField *returnOptionCheck;
    IBOutlet NSTextField *fluorescentQuantDivNoDisplay;
    IBOutlet NSTextField *fluorescentQuantStatusDisplay;
    IBOutlet NSTextField *fluorescentQuantTimeDisplay;
    IBOutlet NSTextField *fluorescentQuantChDisplay;
    
    IBOutlet NSStepper *stepperInterval;
    IBOutlet NSStepper *stepperLimitInterval;
    IBOutlet NSStepper *stepperFluorescentSetCount;
    
    IBOutlet NSWindow *controller;
    IBOutlet NSBrowser *listBrowser;
    IBOutlet NSTableView *tableViewList;
    IBOutlet NSProgressIndicator *progressIndicator;
    IBOutlet NSProgressIndicator *backSave;
    IBOutlet NSProgressIndicator *queueCheck;
    IBOutlet NSProgressIndicator *doneCheck;
    IBOutlet NSSlider *sliderFluorescent;
    
    IBOutlet NSCell *sliderFluorescentKnob;
    
    NSTimer *controllerTimer;
    
    id lineSet;
    id addDelete;
    id addDeleteAuto;
    id communication;
    id cleaning;
    id folderCopy;
    id fileUpdate;
    id dataSaveRead;
    id tiffFileRead;
}

-(id)init;
-(void)statusCheck;
-(void)initialConditionSet;
-(void)lineageQuickSet;
-(void)cellJumpTopLast;
-(void)connectQuickSet;
-(void)listProcessQueueDone:(int)lineNumberList;
-(void)queueHoldControlMain;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)toolBarInitial:(id)sender;
-(IBAction)toolBarAnalysisLoad:(id)sender;
-(IBAction)toolBarTracking:(id)sender;
-(IBAction)toolBarTimeOne:(id)sender;
-(IBAction)toolBarList:(id)sender;
-(IBAction)toolBarNavigation:(id)sender;
-(IBAction)toolBarListSearch:(id)sender;
-(IBAction)toolBarOption:(id)sender;

-(IBAction)addLineage:(id)sender;
-(IBAction)delLineage:(id)sender;
-(IBAction)insertLineage:(id)sender;
-(IBAction)quitAnalysis:(id)sender;
-(IBAction)queueHoldControl:(id)sender;
-(IBAction)endOfImageSet:(id)sender;
-(IBAction)sliderAction:(id)sender;
-(IBAction)stepperActionInterval:(id)sender;
-(IBAction)stepperLimitInterval:(id)sender;

-(IBAction)browserDoubleClick:(id)browser;

-(BOOL)validateToolbarItem:(NSToolbarItem *)item;

@end
