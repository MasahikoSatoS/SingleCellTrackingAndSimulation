//
// TimeOne.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 13/08/15.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TimeOne.h"

NSString *notificationToTimeOne = @"notificationExecuteTimeOne";

@implementation TimeOne

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTimeOne object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    int upLoadCheck = 0;
    int firstRead = 0;
    cellLineageNoHold = "";
    cellNoHold = "";
    
    arrayTarget = new int [1000];
    targetCount = 0;
    targetLimit = 1000;
    targetStatus = 1;
    
    string extension = to_string(timeOneHold);
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    ifstream fin;
    
    string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
    string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    int readingError = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        
        sizeForCopy = 0;
        
        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    if (checkFlag == 1){
        arrayPositionRevise = new int [sizeForCopy+50];
        positionReviseCount = 0;
        positionReviseLimit = (int)sizeForCopy+50;
        
        long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
        arrayGravityCenterRev = new int [sizeForCopy2+50];
        gravityCenterRevCount = 0;
        gravityCenterRevLimit = (int)sizeForCopy2+50;
        
        sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
        arrayAssociateData = new int [sizeForCopy2+50];
        associateDataCount = 0;
        associateDataLimit = (int)sizeForCopy2+50;
        
        //-----Master Data upLoad-----
        readingError = 0;
        
        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            int finData [17];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        readingError = 1;
                    }
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                firstRead = 0;
                upLoadCheck++;
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++;
                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                        else{
                            
                            arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                            arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                        }
                    }
                    else if (stepCount == 1){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        finData [9] = finData [8]*256+finData [9];
                        
                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        else{
                            
                            if (associateDataCount+12 > associateDataLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate associateDataUpDate];
                            }
                            
                            arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                            arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                            arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                            arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                            arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                            arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                        }
                    }
                    else if (stepCount == 2){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                        else{
                            
                            if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate gravityCenterRevUpDate];
                            }
                            
                            arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                            arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                            arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                            arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                            arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                            arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTemp;
        }
        else{
            
            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [11];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    upLoadCheck++;
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--2
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--1
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--3
                            finData [8] = uploadTemp [readPosition], readPosition++; //--1
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //-----X Position-----
                                arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //-----Y Position-----
                                arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //-----Value-----
                                arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //-----Connect No-----
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Cell No-----
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Status-----
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Lineage no-----
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            else{
                                
                                if (associateDataCount+12 > associateDataLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate associateDataUpDate];
                                }
                                
                                arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                            }
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate gravityCenterRevUpDate];
                                }
                                
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
        }
        
        //for (int counterA = 0; counterA < associateDataCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociateData [counterA*6+counterB];
        //	cout<<" arrayAssociateData "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //	cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        if (readingError == 0){
            //-----Master Data Status UpLoad-----
            string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
            
            sizeForCopy = 0;
            
            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy < gravityCenterRevCount) sizeForCopy = gravityCenterRevCount*2;
            
            arrayTimeSelected = new int [sizeForCopy+50];
            timeSelectedCount = 0;
            timeSelectedLimit = (int)sizeForCopy+50;
            arrayTimeSelectedHold = new int [sizeForCopy+50];
            timeSelectedHoldCount = 0;
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                int finData [19];
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                            arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                            arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                            arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                            arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                            arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                            arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [0], timeSelectedHoldCount++; //-----Selected, removed, eliminated status-----
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [3], timeSelectedHoldCount++; //-----Line process, group-----
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [6], timeSelectedHoldCount++; //-----reserve-----
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [8], timeSelectedHoldCount++; //-----Cut line number-----
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [9], timeSelectedHoldCount++;
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [10], timeSelectedHoldCount++;
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [11], timeSelectedHoldCount++;
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [12], timeSelectedHoldCount++;
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [15], timeSelectedHoldCount++;
                            arrayTimeSelectedHold [timeSelectedHoldCount] = finData [18], timeSelectedHoldCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
            else{
                
                firstRead = 1;
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                    arrayTimeSelected [timeSelectedCount] = 1, timeSelectedCount++; //-----Selected, removed, eliminated status-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----PositionRevise Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Cut line number-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X End-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y End-----
                    arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //-----Connect-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Lineage-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 1, timeSelectedHoldCount++; //-----Selected, removed, eliminated status-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Line process, group-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----reserve-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Cut line number-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = counter1+1, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                }
            }
            
            //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
            //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
            //	cout<<" arrayTimeSelected "<<counterA<<endl;
            //}
            
            //-----Cut Line array initialization-----
            arrayTargetHold = new int [5000];
            targetHoldCount = 0;
            targetHoldLimit = 5000;
            arrayTargetHoldInfo = new int [500];
            targetHoldInfoCount = 0;
            targetHoldInfoLimit = 500;
            arrayReferenceLine = new int [5000];
            referenceLineCount = 0;
            referenceLineLimit = 5000;
            
            string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
            string mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
            string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
            
            for (int counter1 = 0; counter1 < imageSizeListCount/2; counter1++){
                if (arrayImageSizeList [counter1*2] == treatmentNameHold){
                    imageDimension = atoi(arrayImageSizeList [counter1*2+1].c_str());
                    break;
                }
            }
            
            sourceImage = new int *[imageDimension+1];
            revisedMap = new int *[imageDimension+1];
            revisedWorkingMap = new int *[imageDimension+1];
            connectMap200 = new int *[imageDimension+1];
            connectMap220 = new int *[imageDimension+1];
            connectMap240 = new int *[imageDimension+1];
            connectMapA = new int *[imageDimension+1];
            connectMapB = new int *[imageDimension+1];
            connectMapC = new int *[imageDimension+1];
            connectMapD = new int *[imageDimension+1];
            
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++){
                sourceImage [counter1] = new int [imageDimension+1];
                revisedMap [counter1] = new int [imageDimension+1];
                revisedWorkingMap [counter1] = new int [imageDimension+1];
                connectMap200 [counter1] = new int [imageDimension+1];
                connectMap220 [counter1] = new int [imageDimension+1];
                connectMap240 [counter1] = new int [imageDimension+1];
                connectMapA [counter1] = new int [imageDimension+1];
                connectMapB [counter1] = new int [imageDimension+1];
                connectMapC [counter1] = new int [imageDimension+1];
                connectMapD [counter1] = new int [imageDimension+1];
            }
            
            //-----Source upload-----
            int readBit [4];
            int yDimensionCount;
            int xDimensionCount;
            int pixData;
            
            if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        upLoadCheck++;
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                sourceImage [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                sourceImage [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        upLoadCheck++;
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                sourceImage [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            //-----Map Data set-----
            int *connectAnalysisX = new int [imageDimension*4];
            int *connectAnalysisY = new int [imageDimension*4];
            int *connectAnalysisTempX = new int [imageDimension*4];
            int *connectAnalysisTempY = new int [imageDimension*4];
            
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int connectTemp = 0;
            int cutOffSet = 0;
            
            for (int counter1 = 1; counter1 <= 7; counter1++){
                if (counter1 == 1) cutOffSet = cutOff1;
                else if (counter1 == 2) cutOffSet = cutOff2;
                else if (counter1 == 3) cutOffSet = cutOff3;
                else if (counter1 == 4) cutOffSet = cutOff4;
                else if (counter1 == 5) cutOffSet = cutOff5;
                else if (counter1 == 6) cutOffSet = cutOff6;
                else if (counter1 == 7) cutOffSet = cutOff7;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){ //-----revisedMap, temporary used-----
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (sourceImage [counterY][counterX] == 100) revisedMap [counterY][counterX] = 0;
                        else if (sourceImage [counterY][counterX] < cutOffSet) revisedMap [counterY][counterX] = 0;
                        else revisedMap [counterY][counterX] = -150;
                    }
                }
                
                connectivityNumber = 0;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (revisedMap [counterY][counterX] == -150){
                            connectivityNumber++;
                            revisedMap [counterY][counterX] = connectivityNumber;
                            connectAnalysisCount = 0;
                            
                            if (counterY-1 >= 0 && counterX-1 >= 0 && revisedMap [counterY-1][counterX-1] == -150){
                                revisedMap [counterY-1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && revisedMap [counterY-1][counterX] == -150){
                                revisedMap [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterY-1 >= 0 && counterX+1 < imageDimension && revisedMap [counterY-1][counterX+1] == -150){
                                revisedMap [counterY-1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < imageDimension && revisedMap [counterY][counterX+1] == -150){
                                revisedMap [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimension && counterX+1 < imageDimension && revisedMap [counterY+1][counterX+1] == -150){
                                revisedMap [counterY+1][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimension && revisedMap [counterY+1][counterX] == -150){
                                revisedMap [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterY+1 < imageDimension && counterX-1 >= 0 && revisedMap [counterY+1][counterX-1] == -150){
                                revisedMap [counterY+1][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && revisedMap [counterY][counterX-1] == -150){
                                revisedMap [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                        xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                        
                                        if (ySource-1 >= 0 && xSource-1 >= 0 && revisedMap [ySource-1][xSource-1] == -150){
                                            revisedMap [ySource-1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && revisedMap [ySource-1][xSource] == -150){
                                            revisedMap [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (ySource-1 >= 0 && xSource+1 < imageDimension && revisedMap [ySource-1][xSource+1] == -150){
                                            revisedMap [ySource-1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < imageDimension && revisedMap [ySource][xSource+1] == -150){
                                            revisedMap [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 > imageDimension && xSource+1 < imageDimension && revisedMap [ySource+1][xSource+1] == -150){
                                            revisedMap [ySource+1][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < imageDimension && revisedMap [ySource+1][xSource] == -150){
                                            revisedMap [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < imageDimension && xSource-1 >= 0 && revisedMap [ySource+1][xSource-1] == -150){
                                            revisedMap [ySource+1][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && revisedMap [ySource][xSource-1] == -150){
                                            revisedMap [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                        connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                //-----Determine number of pixels-----
                int *connectedPix = new int [connectivityNumber+50];
                
                for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (revisedMap [counterY][counterX] != 0) connectedPix [revisedMap [counterY][counterX]]++;
                    }
                }
                
                //-----Map up-date-----
                connectTemp = 1;
                
                for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                    if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
                    else{
                        
                        connectedPix [counter2] = connectTemp;
                        connectTemp++;
                    }
                }
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if ((connectTemp = revisedMap [counterY][counterX]) != 0) revisedMap [counterY][counterX] = connectedPix [connectTemp];
                        else revisedMap [counterY][counterX] = 0;
                        
                        if (counter1 == 1){
                            connectMap240 [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                        else if (counter1 == 2){
                            connectMap220 [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                        else if (counter1 == 3){
                            connectMap200 [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                        else if (counter1 == 4){
                            connectMapA [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                        else if (counter1 == 5){
                            connectMapB [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                        else if (counter1 == 6){
                            connectMapC [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                        else if (counter1 == 7){
                            connectMapD [counterY][counterX] = revisedMap [counterY][counterX];
                        }
                    }
                }
                
                delete [] connectedPix;
            }
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            int totalSize = imageDimension*imageDimension*4;
            
            //-----Map-----
            uint8_t *upload2 = new uint8_t [totalSize+50];
            
            //-----Revised Map-----
            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                fin.read((char*)upload2, totalSize+1);
                fin.close();
                
                yDimensionCount = 0;
                xDimensionCount = 0;
                
                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                    readBit [0] = upload2[counter1];
                    readBit [1] = upload2[counter1+1];
                    readBit [2] = upload2[counter1+2];
                    readBit [3] = upload2[counter1+3];
                    
                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                    
                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                        revisedMap [yDimensionCount][xDimensionCount] = pixData;
                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                    }
                    
                    if (xDimensionCount == imageDimension){
                        xDimensionCount = 0;
                        yDimensionCount++;
                        
                        if (yDimensionCount == imageDimension){
                            break;
                        }
                    }
                }
            }
            else{
                
                fin.open(mapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)upload2, totalSize+1);
                    fin.close();
                    
                    yDimensionCount = 0;
                    xDimensionCount = 0;
                    
                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                        readBit [0] = upload2[counter1];
                        readBit [1] = upload2[counter1+1];
                        readBit [2] = upload2[counter1+2];
                        readBit [3] = upload2[counter1+3];
                        
                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                            revisedMap [yDimensionCount][xDimensionCount] = pixData;
                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageDimension){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageDimension){
                                break;
                            }
                        }
                    }
                }
            }
            
            delete [] upload2;
            
            //for (int counterA = 0; counterA < imageDimension; counterA++){
            //	for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<connectMapA [counterA][counterB];
            //	cout<<" connectMapA "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < imageDimension; counterA++){
            //	for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<revisedMap [counterA][counterB];
            //	cout<<" revisedMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < imageDimension; counterA++){
            //	for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<connectMapC [counterA][counterB];
            //	cout<<" connectMapC "<<counterA<<endl;
            //}
            
            fluorescentDetection = 0;
            
            if (fluorescentMapStatus1 == 0){
                fluorescentMap1 = new int *[imageDimension+1];
                fluorescentMapStatus1 = 1;
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap1 [counter1] = new int [imageDimension+1];
            }
            
            if (fluorescentMapStatus2 == 0){
                fluorescentMap2 = new int *[imageDimension+1];
                fluorescentMapStatus2 = 1;
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap2 [counter1] = new int [imageDimension+1];
            }
            
            if (fluorescentMapStatus3 == 0){
                fluorescentMap3 = new int *[imageDimension+1];
                fluorescentMapStatus3 = 1;
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap3 [counter1] = new int [imageDimension+1];
            }
            
            if (fluorescentMapStatus4 == 0){
                fluorescentMap4 = new int *[imageDimension+1];
                fluorescentMapStatus4 = 1;
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap4 [counter1] = new int [imageDimension+1];
            }
            
            if (fluorescentMapStatus5 == 0){
                fluorescentMap5 = new int *[imageDimension+1];
                fluorescentMapStatus5 = 1;
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap5 [counter1] = new int [imageDimension+1];
            }
            
            if (fluorescentMapStatus6 == 0){
                fluorescentMap6 = new int *[imageDimension+1];
                fluorescentMapStatus6 = 1;
                for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap6 [counter1] = new int [imageDimension+1];
            }
            
            fluorescentMapFind1 = 0;
            fluorescentMapFind2 = 0;
            fluorescentMapFind3 = 0;
            fluorescentMapFind4 = 0;
            fluorescentMapFind5 = 0;
            fluorescentMapFind6 = 0;
            
            string extension2;
            
            if (fluorescentEntryCount >= 1){
                extension2 = to_string(fluorescentNo1);
                
                string fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                
                if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fluorescentDetection = 1;
                    fluorescentMapFind1 = 1;
                    
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 2){
                extension2 = to_string(fluorescentNo2);
                
                string fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exType;
                
                if (stat(fluorescentProcessPath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fluorescentDetection = 1;
                    fluorescentMapFind2 = 1;
                    
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 3){
                extension2 = to_string(fluorescentNo3);
                
                string fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exType;
                
                if (stat(fluorescentProcessPath3.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fluorescentDetection = 1;
                    fluorescentMapFind3 = 1;
                    
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 4){
                extension2 = to_string(fluorescentNo4);
                
                string fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exType;
                
                if (stat(fluorescentProcessPath4.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fluorescentDetection = 1;
                    fluorescentMapFind4 = 1;
                    
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 5){
                extension2 = to_string(fluorescentNo5);
                
                string fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exType;
                
                if (stat(fluorescentProcessPath5.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fluorescentDetection = 1;
                    fluorescentMapFind5 = 1;
                    
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentEntryCount >= 6){
                extension2 = to_string(fluorescentNo6);
                
                string fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exType;
                
                if (stat(fluorescentProcessPath6.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    fluorescentDetection = 1;
                    fluorescentMapFind6 = 1;
                    
                    if (exType == ".tif" || exTypeIF == ".TIF"){
                        int dataConversion [4];
                        int endianType = 0;
                        int imageWidthEntry = 0;
                        int value0 = 0;
                        int value1 = 0;
                        int value2 = 0;
                        int imageDimensionReadCount = 0;
                        
                        unsigned long headPosition = 0;
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            dataConversion [0] = uploadTemp [0];
                            dataConversion [1] = uploadTemp [1];
                            
                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                            else endianType = 0;
                            
                            headPosition = 0;
                            
                            if (endianType == 1){
                                dataConversion [0] = uploadTemp [7];
                                dataConversion [1] = uploadTemp [6];
                                dataConversion [2] = uploadTemp [5];
                                dataConversion [3] = uploadTemp [4];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            else if (endianType == 0){
                                dataConversion [0] = uploadTemp [4];
                                dataConversion [1] = uploadTemp [5];
                                dataConversion [2] = uploadTemp [6];
                                dataConversion [3] = uploadTemp [7];
                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                            }
                            
                            imageDimensionReadCount = 0;
                            imageWidthEntry = 0;
                            
                            if (tifImageColorGray == 0){
                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                    fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                            else if (tifImageColorGray == 1){
                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                    value0 = uploadTemp [counter3];
                                    value1 = uploadTemp [counter3+1];
                                    value2 = uploadTemp [counter3+2];
                                    
                                    fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                    
                                    if (imageWidthEntry == imageDimension){
                                        imageWidthEntry = 0;
                                        imageDimensionReadCount++;
                                    }
                                }
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            int imageDimensionReadCount = 0;
                            
                            for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                                for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                    fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                                }
                                
                                imageDimensionReadCount++;
                            }
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (fluorescentDetection == 1){
                string expandData = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(expandData.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 1){
                    readingError = 0;
                    
                    if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                    expandFluorescentOutline = new int [sizeForCopy+50];
                    expandFluorescentOutlineCount = 0;
                    expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                    expandFluorescentOutlineStatus = 1;
                    
                    fin.open(expandData.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 1){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                    else{
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        else{
                            
                            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                            expandFluorescentOutlineCount = 0;
                            expandFluorescentOutlineLimit = 0;
                            expandFluorescentOutlineStatus = 0;
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Fluorescent Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                    expandFluorescentOutlineCount = 0;
                    expandFluorescentOutlineLimit = 0;
                    expandFluorescentOutlineStatus = 0;
                }
                
                expandData = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                
                if (stat(expandData.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                    expandFluorescentData = new int [sizeForCopy+50];
                    expandFluorescentDataCount = 0;
                    expandFluorescentDataLimit = (int)sizeForCopy+50;
                    expandFluorescentDataStatus = 1;
                    
                    fin.open(expandData.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [8];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
                else{
                    
                    if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                    expandFluorescentDataCount = 0;
                    expandFluorescentDataLimit = 0;
                    expandFluorescentDataStatus = 0;
                }
            }
            else{
                
                if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = 0;
                expandFluorescentOutlineStatus = 0;
                
                if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = 0;
                expandFluorescentDataStatus = 0;
            }
            
            //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutline [counterA*4+counterB];
            //    cout<<" expandFluorescentOutline "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
            //    cout<<" expandFluorescentData "<<counterA<<endl;
            //}
            
            if (upLoadCheck == 2){
                timeOneStatus = 2;
                tableDataSetDone = 1;
                trackingTableSetDone = 0;
                tableTrackingProcessing = 0;
                
                if (firstRead == 1){
                    targetFind = [[TargetFind alloc] init];
                    [targetFind interpretationFirst];
                    
                    int valueTemp = 0;
                    
                    for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                        if (arrayPositionRevise [counter1*7+3] != valueTemp){
                            valueTemp = arrayPositionRevise [counter1*7+3];
                            arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                            arrayTimeSelectedHold [(valueTemp-1)*10+2] = counter1;
                            
                            if (arrayPositionRevise [counter1*7+5] == 0){
                                arrayTimeSelected [(valueTemp-1)*10] = 0;
                                arrayTimeSelectedHold [(valueTemp-1)*10] = 0;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                    //    cout<<" arrayTimeSelected "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
                    //    cout<<" arrayPositionRevise "<<counterA<<endl;
                    //}
                }
                else{
                    
                    int typeSet = 1;
                    
                    targetFind2 = [[TargetFind2 alloc] init];
                    [targetFind2 interpretationFirst:typeSet];
                }
                
                for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                    if (arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                        currentConnectNo = arrayTimeSelected [counter1*10+8];
                        break;
                    }
                }
                
                timeOneLaunch = 1;
                verificationPositionCall = 0;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToNavigationWindow object:self];
            }
            else timeOneStatus = 4;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Read Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTimeOne object:nil];
}

@end
