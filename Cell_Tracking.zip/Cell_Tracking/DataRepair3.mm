//
//  DataRepair3.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#import "DataRepair3.h"

@implementation DataRepair3

-(IBAction)dataRepair12:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkListCount == 0 && treatmentNameHold != ""){
            nameStringRep = treatmentNameHold;
        }
        else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        int *imageFileCheck = new int [imageEndHold*3];
        
        for (int counter1 = 1; counter1 <= imageEndHold; counter1++){
            imageFileCheck [counter1] = 0;
        }
        
        string imageFolderSTPath = imageFolderPath+"/"+analysisImageName+"_Image/"+nameStringRep+"_Stitch";
        string entry;
        
        DIR *dir = opendir(imageFolderSTPath.c_str());
        struct dirent *dent;
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("STimage") != -1){
                        if (fileDeleteCount+5 > fileDeleteLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate fileDeleteUpDate];
                        }
                        
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort-----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            if (fluorescentName1 != "" && (int)arrayFileDelete [counter1].find(fluorescentName1) != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
            if (fluorescentName2 != "" && (int)arrayFileDelete [counter1].find(fluorescentName2) != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
            if (fluorescentName3 != "" && (int)arrayFileDelete [counter1].find(fluorescentName3) != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
            if (fluorescentName4 != "" && (int)arrayFileDelete [counter1].find(fluorescentName4) != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
            if (fluorescentName5 != "" && (int)arrayFileDelete [counter1].find(fluorescentName5) != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
            if (fluorescentName6 != "" && (int)arrayFileDelete [counter1].find(fluorescentName6) != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
            if ((int)arrayFileDelete [counter1].find("BMP") != -1 || (int)arrayFileDelete [counter1].find("TIF") != -1){
                imageFileCheck [atoi(arrayFileDelete [counter1].substr(8, 4).c_str())] = 1;
            }
        }
        
        imageFolderSTPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect";
        
        fileDeleteCount = 0;
        
        dir = opendir(imageFolderSTPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_ExtendAreaData") != -1 || (int)entry.find("_ExtendLineData") != -1 || (int)entry.find("_RevisedMap") != -1){
                        if (fileDeleteCount+5 > fileDeleteLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate fileDeleteUpDate];
                        }
                        
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //-----Directory Sort-----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        string fluorescentImageFileName;
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            if ((int)arrayFileDelete [counter1].find("_ExtendAreaData") != -1 || (int)arrayFileDelete [counter1].find("_ExtendLineData") != -1){
                if (imageFileCheck [atoi(arrayFileDelete [counter1].substr(0, 4).c_str())] == 0){
                    fluorescentImageFileName = imageFolderSTPath+"/"+arrayFileDelete [counter1];
                    remove (fluorescentImageFileName.c_str());
                }
            }
        }
        
        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
        
        struct stat sizeOfFile;
        
        int *arrayFluorescentCutOffTemp = new int [imageEndHold*8+20];
        int fluorescentCutOffCountTemp = 0;
        int entryCount = 0;
        
        if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
            string getString;
            
            ifstream fin;
            
            fin.open (cutOffPath.c_str(), ios::in);
            
            if (fin.is_open()){
                for (int counter1 = 0; counter1 < imageEndHold; counter1++){
                    getline(fin, getString);
                    
                    if (getString != "End"){
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        getline(fin, getString);
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = atoi(getString.c_str()), fluorescentCutOffCountTemp++;
                        arrayFluorescentCutOffTemp [fluorescentCutOffCountTemp] = entryCount, fluorescentCutOffCountTemp++;
                        entryCount++;
                    }
                    else{
                        
                        break;
                    }
                }
                
                fin.close();
            }
        }
        
        int maxEntryCount = 0;
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            if ((int)arrayFileDelete [counter1].find("_RevisedMap") != -1 && atoi(arrayFileDelete [counter1].substr(0, 4).c_str()) > maxEntryCount){
                maxEntryCount = atoi(arrayFileDelete [counter1].substr(0, 4).c_str());
            }
        }
        
        int *arrayFluorescentCutOffTemp2 = new int [imageEndHold*8+20];
        int fluorescentCutOffCountTemp2 = 0;
        
        int findFlag = 0;
        
        for (int counter1 = 1; counter1 <= maxEntryCount; counter1++){ //================================================CHECK
            if (imageFileCheck [counter1] == 1){
                findFlag = -1;
                
                for (int counter2 = 0; counter2 < fluorescentCutOffCountTemp/7; counter2++){
                    if (arrayFluorescentCutOffTemp [counter2*7+6] == counter1){
                        findFlag = counter2;
                        break;
                    }
                }
                
                if (findFlag != -1){
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = counter1, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = arrayFluorescentCutOffTemp [findFlag*7+1], fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = arrayFluorescentCutOffTemp [findFlag*7+2], fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = arrayFluorescentCutOffTemp [findFlag*7+3], fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = arrayFluorescentCutOffTemp [findFlag*7+4], fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = arrayFluorescentCutOffTemp [findFlag*7+5], fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = arrayFluorescentCutOffTemp [findFlag*7+6], fluorescentCutOffCountTemp2++;
                }
                else{
                    
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = counter1, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = 150, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = 150, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = 150, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = 150, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = 150, fluorescentCutOffCountTemp2++;
                    arrayFluorescentCutOffTemp2 [fluorescentCutOffCountTemp2] = 150, fluorescentCutOffCountTemp2++;
                }
            }
        }
        
        if (fluorescentCutOffStatus == 0){
            arrayFluorescentCutOff = new int [imageEndHold*7];
            fluorescentCutOffStatus = 1;
        }
        
        fluorescentCutOffCount = 0;
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCountTemp2; counter1++) arrayFluorescentCutOff [fluorescentCutOffCount] = arrayFluorescentCutOffTemp2 [counter1], fluorescentCutOffCount++;
        
        ofstream oin;
        oin.open(cutOffPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
        
        oin<<"End"<<endl;
        oin.close();
        
        delete [] arrayFluorescentCutOffTemp2;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        delete [] imageFileCheck;
        delete [] arrayFluorescentCutOffTemp;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair13:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkListCount == 0 && treatmentNameHold != "") nameStringRep = treatmentNameHold;
        else nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        //********arrayLineagePartnerInfo*********
        //1.TreatName
        //2.Lineage No
        //3.Cell no
        //4.W-image position
        //5.Partner Lineage No
        //6.Partner Cell No
        
        //=======Lineage partner line=======
        string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+nameStringRep+"_FusionPartner";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
            int lineagePartnerInfoTempCount = 0;
            
            string *arrayLineagePartnerInfoTemp2 = new string [sizeForCopy+50];
            int lineagePartnerInfoTempCount2 = 0;
            
            ifstream fin;
            
            fin.open(cellFusionPartnerPath.c_str(), ios::in);
            
            if (fin.is_open()){
                string treatmentNameGet;
                string lineageNoGet;
                string cellNoGet;
                string imageNoGet;
                string partnerLingNoGet;
                string partnerCellNoGet;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    getline(fin, treatmentNameGet);
                    
                    if (treatmentNameGet == "") terminationFlag = 0;
                    else{
                        
                        getline(fin, lineageNoGet);
                        getline(fin, cellNoGet);
                        getline(fin, imageNoGet);
                        getline(fin, partnerLingNoGet);
                        getline(fin, partnerCellNoGet);
                        
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                        arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                    }
                    
                } while (terminationFlag == 1);
                
                fin.close();
            }
            
            for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount/6; counter1++){
                if (arrayLineagePartnerInfoTemp [counter1*6] != nameStringRep){
                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6], lineagePartnerInfoTempCount2++;
                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+1], lineagePartnerInfoTempCount2++;
                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+2], lineagePartnerInfoTempCount2++;
                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+3], lineagePartnerInfoTempCount2++;
                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+4], lineagePartnerInfoTempCount2++;
                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter1*6+5], lineagePartnerInfoTempCount2++;
                }
            }
            
            if (lineagePartnerInfoTempCount2 != 0){
                ofstream oin;
                oin.open(cellFusionPartnerPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) oin<<arrayLineagePartnerInfoTemp2 [counter1]<<endl;
                
                oin.close();
            }
            else remove (cellFusionPartnerPath.c_str());
            
            delete [] arrayLineagePartnerInfoTemp;
            delete [] arrayLineagePartnerInfoTemp2;
        }
        
        //-----Lineage data upload-----
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        
        for (int counter4 = 0; counter4 < 6; counter4++){
            sizeForCopy = 0;
            
            if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter4 == 0) size1 = sizeForCopy;
                else if (counter4 == 1) size2 = sizeForCopy;
                else if (counter4 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter4 == 3) size1 = sizeForCopy;
                else if (counter4 == 4) size2 = sizeForCopy;
                else if (counter4 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        arrayLineageRepairData = new int [sizeForCopy+50];
        lineageDataRepairCount = 0;
        
        int returnValue2 = 0;
        
        if (checkFlag == 1){
            int processType2 = -1;
            
            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
            
            for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
                if (arrayLineageRepairData [counter1*8+3] == 10) arrayLineageRepairData [counter1*8+3] = 2;
            }
            
            if (returnValue2 == 0){
                //-----Lineage Data Save-----
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                [dataRepairReadWrite lineageDataSave];
            }
        }
        
        if (returnValue2 == 0){
            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
            [dataRepairReadWrite lineageRelDataSet];
        }
        
        delete [] arrayLineageRepairData;
        
        if (returnValue2 == -1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Read Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair14:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            NSString *fromNSString = [replaceFromTextDisplay stringValue];
            string fromString = [fromNSString UTF8String];
            
            NSString *toNSString = [replaceToTextDisplay stringValue];
            string toString = [toNSString UTF8String];
            string toStringHold = [toNSString UTF8String];
            
            int lineFrom = [replaceLineFromDisplay integerValue];
            int lineTo = [replaceLineToDisplay integerValue];
            
            if (lineTo > 0 && lineTo <= listStringCount && lineFrom > 0 && lineFrom <= listStringCount && lineTo >= lineFrom && (int)fromString.find("//") != -1 && (int)toString.find("//") != -1 && (int)fromString.find("~~") != -1 && (int)toString.find("~~") != -1 && (int)fromString.find("^^") != -1 && (int)toString.find("^^") != -1 && (int)fromString.find("&&") != -1 && (int)toString.find("&&") != -1){
                
                if (fromString != toString){
                    int numberOfDivFromCount = 0;
                    int numberOfDivToCount = 0;
                    
                    fromString = fromString.substr(fromString.find("//")+2);
                    toString = toString.substr(toString.find("//")+2);
                    
                    string tempFromString = fromString;
                    
                    for (int counter1 = 0; counter1 < 20; counter1++){
                        if ((int)tempFromString.find("/") != -1){
                            tempFromString = tempFromString.substr(tempFromString.find("/")+1);
                            numberOfDivFromCount++;
                        }
                        else{
                            
                            break;
                        }
                    }
                    
                    string tempToString = toString;
                    
                    for (int counter1 = 0; counter1 < 20; counter1++){
                        if ((int)tempToString.find("/") != -1){
                            tempToString = tempToString.substr(tempToString.find("/")+1);
                            numberOfDivToCount++;
                        }
                        else{
                            
                            break;
                        }
                    }
                    
                    if (numberOfDivFromCount == numberOfDivToCount){
                        string *modifiedString = new string [20];
                        
                        for (int counter1 = 0; counter1 < 20; counter1++){
                            modifiedString [counter1] = "nil";
                        }
                        
                        tempFromString = fromString;
                        tempToString = toString;
                        
                        string tempExtractFrom;
                        string tempExtractTo;
                        
                        for (int counter1 = 0; counter1 < numberOfDivToCount; counter1++){
                            if ((int)tempFromString.find("/") != -1){
                                tempExtractFrom = tempFromString.substr(0, tempFromString.find("/"));
                                tempFromString = tempFromString.substr(tempFromString.find("/")+1);
                            }
                            
                            if ((int)tempToString.find("/") != -1){
                                tempExtractTo = tempToString.substr(0, tempToString.find("/"));
                                tempToString = tempToString.substr(tempToString.find("/")+1);
                            }
                            
                            if (tempExtractFrom != tempExtractTo){
                                modifiedString [counter1*2] = tempExtractFrom;
                                modifiedString [counter1*2+1] = tempExtractTo;
                            }
                            
                            if (counter1 == numberOfDivToCount-1){
                                tempExtractFrom = tempFromString.substr(0, tempFromString.find("~~"));
                                tempExtractTo = tempToString.substr(0, tempToString.find("~~"));
                                
                                if (tempExtractFrom != tempExtractTo){
                                    modifiedString [counter1*2] = tempExtractFrom;
                                    modifiedString [counter1*2+1] = tempToString;
                                }
                            }
                        }
                        
                        int differenceFind = 0;
                        int differenceError = 0;
                        
                        for (int counter1 = 0; counter1 < numberOfDivToCount; counter1++){
                            if (modifiedString [counter1*2] != modifiedString [counter1*2+1]){
                                if (modifiedString [counter1*2] != "nil" && modifiedString [counter1*2+1] != "nil" && modifiedString [counter1*2] != "" && modifiedString [counter1*2+1] != ""){
                                    differenceFind = 1;
                                }
                                else differenceError = 1;
                            }
                        }
                        
                        if (differenceFind == 1 && differenceError == 0){
                            int divisionError = 0;
                            
                            if (listArrayStatusHold == 1 && numberOfDivToCount != 7) divisionError = 1;
                            else if (listArrayStatusHold == 2 && numberOfDivToCount != 6) divisionError = 1;
                            else if (listArrayStatusHold == 3 && numberOfDivToCount != 9) divisionError = 1;
                            else if (listArrayStatusHold == 4 && numberOfDivToCount != 5) divisionError = 1;
                            else if (listArrayStatusHold == 5 && numberOfDivToCount != 5) divisionError = 1;
                            else if (listArrayStatusHold == 6 && numberOfDivToCount != 5) divisionError = 1;
                            else if (listArrayStatusHold == 7 && numberOfDivToCount != 1) divisionError = 1;
                            else if (listArrayStatusHold == 8 && numberOfDivToCount != 3) divisionError = 1;
                            else if (listArrayStatusHold == 9 && numberOfDivToCount != 3) divisionError = 1;
                            else if (listArrayStatusHold == 10 && numberOfDivToCount != 3) divisionError = 1;
                            
                            if (divisionError == 0){
                                if (listArrayStatusHold == 1){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    
                                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    long size1 = 0;
                                    long size2 = 0;
                                    int checkFlag = 0;
                                    
                                    for (int counter4 = 0; counter4 < 6; counter4++){
                                        sizeForCopy = 0;
                                        
                                        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        if (sizeForCopy != 0){
                                            if (counter4 == 0) size1 = sizeForCopy;
                                            else if (counter4 == 1) size2 = sizeForCopy;
                                            else if (counter4 == 2){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                    break;
                                                }
                                                else{
                                                    
                                                    size1 = 0;
                                                    size2 = 0;
                                                    usleep (50000);
                                                }
                                            }
                                            else if (counter4 == 3) size1 = sizeForCopy;
                                            else if (counter4 == 4) size2 = sizeForCopy;
                                            else if (counter4 == 5){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    //-----Lineage data upload-----
                                    arrayLineageRepairData = new int [sizeForCopy+50];
                                    lineageDataRepairCount = 0;
                                    
                                    int returnValue2 = 0;
                                    
                                    if (checkFlag == 1){
                                        int processType2 = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
                                        
                                        if (returnValue2 == 0){
                                            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                            [dataRepairReadWrite lineageDataSave];
                                        }
                                    }
                                    
                                    delete [] arrayLineageRepairData;
                                    
                                    if (returnValue2 == 0){
                                        int returnStatus = 0;
                                        
                                        dataRepairProcess = [[DataRepairProcess alloc] init];
                                        returnStatus = [dataRepairProcess lineageProcessMain];
                                        
                                        if (returnStatus == -1){
                                            NSAlert *alert = [[NSAlert alloc] init];
                                            
                                            [alert addButtonWithTitle:@"OK"];
                                            [alert setMessageText:@"Lineage Read Error"];
                                            [alert setAlertStyle:NSAlertStyleWarning];
                                            [alert runModal];
                                            
                                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                                            [sound play];
                                        }
                                        else{
                                            
                                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                                            [sound play];
                                        }
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Lineage Read Error"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                }
                                else if (listArrayStatusHold == 2 || listArrayStatusHold == 4 || listArrayStatusHold == 6){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    long size1 = 0;
                                    long size2 = 0;
                                    int checkFlag = 0;
                                    
                                    for (int counter4 = 0; counter4 < 6; counter4++){
                                        sizeForCopy = 0;
                                        
                                        if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        if (sizeForCopy != 0){
                                            if (counter4 == 0) size1 = sizeForCopy;
                                            else if (counter4 == 1) size2 = sizeForCopy;
                                            else if (counter4 == 2){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                    break;
                                                }
                                                else{
                                                    
                                                    size1 = 0;
                                                    size2 = 0;
                                                    usleep (50000);
                                                }
                                            }
                                            else if (counter4 == 3) size1 = sizeForCopy;
                                            else if (counter4 == 4) size2 = sizeForCopy;
                                            else if (counter4 == 5){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    arrayPositionReviseVer = new int [sizeForCopy+50];
                                    positionReviseVerCount = 0;
                                    
                                    arrayGravityCenterVerRev = new int [sizeForCopy+50];
                                    gravityCenterRevVerCount = 0;
                                    
                                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                                    repairDataHoldVerCount = 0;
                                    
                                    int returnValue2 = 0;
                                    
                                    if (checkFlag == 1){
                                        int processType2 = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        returnValue2 = [dataRepairReadWrite masterDataSetList:sizeForCopy:processType2:listArrayStatusHold];
                                        
                                        if (returnValue2 == 0){
                                            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                            [dataRepairReadWrite masterDataSave];
                                        }
                                    }
                                    
                                    delete [] arrayPositionReviseVer;
                                    delete [] arrayGravityCenterVerRev;
                                    delete [] arrayRepairDataHoldVerRev;
                                    
                                    if (returnValue2 == -1){
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Master Data Read Error"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                    else{
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                    }
                                }
                                else if (listArrayStatusHold == 3){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    
                                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                                    repairDataHoldVerCount = 0;
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        int processType = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        [dataRepairReadWrite timeSelectedList:sizeForCopy:processType];
                                    }
                                    
                                    delete [] arrayRepairDataHoldVerRev;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else if (listArrayStatusHold == 5){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    
                                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                                    repairDataHoldVerCount = 0;
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        int processType = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        [dataRepairReadWrite connectRLList:sizeForCopy:processType];
                                    }
                                    
                                    delete [] arrayRepairDataHoldVerRev;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else if (listArrayStatusHold == 7){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
                                    
                                    int imageSize = 0;
                                    
                                    for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                                        if (arrayImageSizeList [counter2*2] == nameStringRep){
                                            imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                                            break;
                                        }
                                    }
                                    
                                    int **revisedMapVer = new int *[imageSize+1];
                                    for (int counter2 = 0; counter2 < imageSize+1; counter2++) revisedMapVer [counter2] = new int [imageSize+1];
                                    
                                    int totalSize = imageSize*imageSize*4;
                                    
                                    ifstream fin;
                                    
                                    fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        uint8_t *upload2 = new uint8_t [totalSize+50];
                                        fin.read((char*)upload2, totalSize+1);
                                        fin.close();
                                        
                                        int yDimensionCount = 0;
                                        int xDimensionCount = 0;
                                        int pixData = 0;
                                        int readBit [4];
                                        
                                        for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                                            readBit [0] = upload2[counter3];
                                            readBit [1] = upload2[counter3+1];
                                            readBit [2] = upload2[counter3+2];
                                            readBit [3] = upload2[counter3+3];
                                            
                                            pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                            
                                            for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                                revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                            }
                                            
                                            if (xDimensionCount == imageSize){
                                                xDimensionCount = 0;
                                                yDimensionCount++;
                                                
                                                if (yDimensionCount == imageSize){
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        delete [] upload2;
                                    }
                                    
                                    string connectFromNoMap = fromString.substr(fromString.find("//")+2);
                                    connectFromNoMap = connectFromNoMap.substr(0, connectFromNoMap.find("/"));
                                    string connectToNoMap = toString.substr(toString.find("//")+2);
                                    connectToNoMap = connectToNoMap.substr(0, connectToNoMap.find("/"));
                                    
                                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                                            if (revisedMapVer [counter3][counter4] == atoi(connectFromNoMap.c_str())){
                                                revisedMapVer [counter3][counter4] = atoi(connectToNoMap.c_str());
                                            }
                                        }
                                    }
                                    
                                    char *dataHold = new char [totalSize];
                                    int indexCount = 0;
                                    int dataTemp2 = 0;
                                    int entryCount = 0;
                                    int readBit2 [4];
                                    int dataTemp = 0;
                                    
                                    for (int counterX = 0; counterX < imageSize; counterX++){
                                        for (int counterY = 0; counterY < imageSize; counterY++){
                                            dataTemp = revisedMapVer [counterX][counterY];
                                            
                                            if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                                            else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageSize-1){
                                                readBit2 [0] = dataTemp2/65536;
                                                dataTemp2 = dataTemp2%65536;
                                                readBit2 [1] = dataTemp2/256;
                                                dataTemp2 = dataTemp2%256;
                                                readBit2 [2] = dataTemp2;
                                                
                                                if (counterY == imageSize-1){
                                                    if (dataTemp != dataTemp2){
                                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                                        
                                                        readBit2 [0] = dataTemp/65536;
                                                        dataTemp = dataTemp%65536;
                                                        readBit2 [1] = dataTemp/256;
                                                        dataTemp = dataTemp%256;
                                                        readBit2 [2] = dataTemp;
                                                        
                                                        entryCount = 1;
                                                        
                                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                                    }
                                                    else{
                                                        
                                                        entryCount++;
                                                        
                                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                                    }
                                                }
                                                else{
                                                    
                                                    dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                                    dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                                }
                                                
                                                if (counterY == imageSize-1) entryCount = 0;
                                                else entryCount = 1, dataTemp2 = dataTemp;
                                            }
                                            else entryCount++;
                                        }
                                    }
                                    
                                    ofstream outfile5 (revisedMapPath.c_str(), ofstream::binary);
                                    outfile5.write(dataHold, indexCount);
                                    outfile5.close();
                                    
                                    delete [] dataHold;
                                    
                                    for (int counter2 = 0; counter2 < imageSize+1; counter2++) delete [] revisedMapVer [counter2];
                                    
                                    delete [] revisedMapVer;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else if (listArrayStatusHold == 8){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendLineData";
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    long size1 = 0;
                                    long size2 = 0;
                                    int checkFlag = 0;
                                    
                                    for (int counter1 = 0; counter1 < 6; counter1++){
                                        sizeForCopy = 0;
                                        
                                        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        if (sizeForCopy != 0){
                                            if (counter1 == 0) size1 = sizeForCopy;
                                            else if (counter1 == 1) size2 = sizeForCopy;
                                            else if (counter1 == 2){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                    break;
                                                }
                                                else{
                                                    
                                                    size1 = 0;
                                                    size2 = 0;
                                                    usleep (50000);
                                                }
                                            }
                                            else if (counter1 == 3) size1 = sizeForCopy;
                                            else if (counter1 == 4) size2 = sizeForCopy;
                                            else if (counter1 == 5){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                                    repairDataHoldVerCount = 0;
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    int returnValue2 = 0;
                                    
                                    if (checkFlag == 1){
                                        int processType = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        returnValue2 = [dataRepairReadWrite fluorescentLineList:sizeForCopy:processType];
                                    }
                                    
                                    delete [] arrayRepairDataHoldVerRev;
                                    
                                    if (returnValue2 == -1){
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Fluorescent Line Data Read Error"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                    else{
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                    }
                                }
                                else if (listArrayStatusHold == 9){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendAreaData";
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    
                                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                                    repairDataHoldVerCount = 0;
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        int processType = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        [dataRepairReadWrite fluorescentAreaList:sizeForCopy:processType];
                                    }
                                    
                                    delete [] arrayRepairDataHoldVerRev;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else if (listArrayStatusHold == 10){
                                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                                    
                                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+treatmentNameHold+"_CutOffData";
                                    
                                    struct stat sizeOfFile;
                                    long sizeForCopy = 0;
                                    
                                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    arrayRepairDataHoldVerRev = new int [imageEndHold*5+20];
                                    repairDataHoldVerCount = 0;
                                    
                                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                                        arrayListString [counter1] = toStringHold.substr(0, toStringHold.find("~~"))+arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        int processType = 0;
                                        
                                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                        [dataRepairReadWrite fluorescentCutList:processType];
                                    }
                                    
                                    delete [] arrayRepairDataHoldVerRev;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                
                                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                [dataRepairReadWrite lineageRelDataSet];
                                
                                listStringCount = 0;
                                listArrayStatusHold = 8;
                                
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Data format error"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        
                        //1:"Lineage:Line No//Xposition/Yposition/Time/Event/Parent-fusion partner cell no/Cell no/Lineage. no/Fusion-partner Lineage no";
                        //2:"PR:Line No//Xposition/Yposition/Average/Connect no/Cell no/Status/Lineage. no";
                        //3:"ST:Line No//Status/Zero/PR Starting/Zero/Zero/Zero/Zero/Zero/Connect no/Lineage. no";
                        //4:"GC:Line No//Xposition/Yposition/Total area/Average/Connect no/Target hit";
                        //5:"RL:Line No//Lineage no/Connect no/Time/Cell no/Target/Zero";
                        //6:"AD:Line No//Connect No/Process type/Cut type/Pair no/Cell dim/Zero";
                        //7:"Map:Line No//Connect No/Number of Pix";
                        //8:"Fluorescent-Line:Line No//Xposition/Yposition/connect no/CH no";
                        //9:"Fluorescent-Area:Line No//connect no/CH no/CH value/CH area";
                        //10:"Fluorescent-CutOff:Line No//Time/CH1 Cut/CH2 cut/CH3 cut";
                        
                        delete [] modifiedString;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Data format error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Missing Line Markers"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data format error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataRepair15:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            int lineFrom = [removeLineFromDisplay integerValue];
            int lineTo = [removeLineToDisplay integerValue];
            
            if (lineTo > 0 && lineTo <= listStringCount && lineFrom > 0 && lineFrom <= listStringCount && lineTo >= lineFrom){
                if (listArrayStatusHold == 1){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    //-----Lineage data upload-----
                    arrayLineageRepairData = new int [sizeForCopy+50];
                    lineageDataRepairCount = 0;
                    
                    int returnValue2 = 0;
                    
                    if (checkFlag == 1){
                        int processType2 = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
                        
                        if (returnValue2 == 0){
                            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                            [dataRepairReadWrite lineageDataSave];
                        }
                    }
                    
                    delete [] arrayLineageRepairData;
                    
                    if (returnValue2 == 0){
                        int returnStatus = 0;
                        
                        dataRepairProcess = [[DataRepairProcess alloc] init];
                        returnStatus = [dataRepairProcess lineageProcessMain];
                        
                        if (returnStatus == -1){
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Lineage Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Lineage Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 2 || listArrayStatusHold == 4 || listArrayStatusHold == 6){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                    
                    masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    arrayPositionReviseVer = new int [sizeForCopy+50];
                    positionReviseVerCount = 0;
                    
                    arrayGravityCenterVerRev = new int [sizeForCopy+50];
                    gravityCenterRevVerCount = 0;
                    
                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                    repairDataHoldVerCount = 0;
                    
                    int returnValue2 = 0;
                    
                    if (checkFlag == 1){
                        int processType2 = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        returnValue2 = [dataRepairReadWrite masterDataSetList:sizeForCopy:processType2:listArrayStatusHold];
                        
                        if (returnValue2 == 0){
                            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                            [dataRepairReadWrite masterDataSave];
                        }
                    }
                    
                    delete [] arrayPositionReviseVer;
                    delete [] arrayGravityCenterVerRev;
                    delete [] arrayRepairDataHoldVerRev;
                    
                    if (returnValue2 == -1){
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Master Data Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 3){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                    
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    
                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                    repairDataHoldVerCount = 0;
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    if (sizeForCopy != 0){
                        int processType = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        [dataRepairReadWrite timeSelectedList:sizeForCopy:processType];
                    }
                    
                    delete [] arrayRepairDataHoldVerRev;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                }
                else if (listArrayStatusHold == 5){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                    
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    
                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                    repairDataHoldVerCount = 0;
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    if (sizeForCopy != 0){
                        int processType = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        [dataRepairReadWrite connectRLList:sizeForCopy:processType];
                    }
                    
                    delete [] arrayRepairDataHoldVerRev;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 8){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                    
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendLineData";
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        sizeForCopy = 0;
                        
                        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter1 == 0) size1 = sizeForCopy;
                            else if (counter1 == 1) size2 = sizeForCopy;
                            else if (counter1 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter1 == 3) size1 = sizeForCopy;
                            else if (counter1 == 4) size2 = sizeForCopy;
                            else if (counter1 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                    repairDataHoldVerCount = 0;
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    int returnValue2 = 0;
                    
                    if (checkFlag == 1){
                        int processType = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        returnValue2 = [dataRepairReadWrite fluorescentLineList:sizeForCopy:processType];
                    }
                    
                    delete [] arrayRepairDataHoldVerRev;
                    
                    if (returnValue2 == -1){
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Fluorescent Line Data Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 9){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                    
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendAreaData";
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    
                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                    repairDataHoldVerCount = 0;
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    if (sizeForCopy != 0){
                        int processType = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        [dataRepairReadWrite fluorescentAreaList:sizeForCopy:processType];
                    }
                    
                    delete [] arrayRepairDataHoldVerRev;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 10){
                    nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                    string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                    
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+analysisID+"_"+treatmentNameHold+"_CutOffData";
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    
                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    arrayRepairDataHoldVerRev = new int [imageEndHold*5+20];
                    repairDataHoldVerCount = 0;
                    
                    for (int counter1 = lineFrom-1; counter1 <= lineTo-1; counter1++){
                        arrayListString [counter1] = arrayListString [counter1].substr(arrayListString [counter1].find("~~"))+"R";
                    }
                    
                    if (sizeForCopy != 0){
                        int processType = 1;
                        
                        dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        [dataRepairReadWrite fluorescentCutList:processType];
                    }
                    
                    delete [] arrayRepairDataHoldVerRev;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (listArrayStatusHold == 7){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert addButtonWithTitle:@"Cancel"];
                    [alert setMessageText:@"Clear Selected Connect or Time Data"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    
                    if ([alert runModal] == NSAlertFirstButtonReturn){
                        nameStringRep = arrayListString [0].substr(arrayListString [0].find ("++")+2, arrayListString [0].find ("^^")-(arrayListString [0].find ("++")+2));
                        string extension = arrayListString [0].substr(arrayListString [0].find ("^^")+2, arrayListString [0].find ("&&")-(arrayListString [0].find ("^^")+2));
                        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
                        
                        int imageSize = 0;
                        
                        for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                            if (arrayImageSizeList [counter2*2] == nameStringRep){
                                imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                                break;
                            }
                        }
                        
                        int **revisedMapVer = new int *[imageSize+1];
                        
                        for (int counter2 = 0; counter2 < imageSize+1; counter2++){
                            revisedMapVer [counter2] = new int [imageSize+1];
                        }
                        
                        for (int counter3 = 0; counter3 < imageSize; counter3++){
                            for (int counter4 = 0; counter4 < imageSize; counter4++){
                                revisedMapVer [counter3][counter4] = 0;
                            }
                        }
                        
                        ifstream fin;
                        
                        int totalSize = imageSize*imageSize*4;
                        int readBit [4];
                        int pixData = 0;
                        
                        fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *upload2 = new uint8_t [totalSize+50];
                            fin.read((char*)upload2, totalSize+1);
                            fin.close();
                            
                            int yDimensionCount = 0;
                            int xDimensionCount = 0;
                            
                            for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                                readBit [0] = upload2[counter3];
                                readBit [1] = upload2[counter3+1];
                                readBit [2] = upload2[counter3+2];
                                readBit [3] = upload2[counter3+3];
                                
                                pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                
                                for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                    revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                }
                                
                                if (xDimensionCount == imageSize){
                                    xDimensionCount = 0;
                                    yDimensionCount++;
                                    
                                    if (yDimensionCount == imageSize){
                                        break;
                                    }
                                }
                            }
                            
                            delete [] upload2;
                        }
                        
                        string connectFromNoMap = arrayListString [lineFrom-1].substr(arrayListString [lineFrom-1].find("//")+2);
                        connectFromNoMap = connectFromNoMap.substr(0, connectFromNoMap.find("/"));
                        
                        for (int counter3 = 0; counter3 < imageSize; counter3++){
                            for (int counter4 = 0; counter4 < imageSize; counter4++){
                                if (revisedMapVer [counter3][counter4] == atoi(connectFromNoMap.c_str())){
                                    revisedMapVer [counter3][counter4] = 0;
                                }
                            }
                        }
                        
                        char *dataHold = new char [totalSize];
                        int indexCount = 0;
                        int dataTemp2 = 0;
                        int entryCount = 0;
                        int readBit2 [4];
                        int dataTemp = 0;
                        
                        for (int counterX = 0; counterX < imageSize; counterX++){
                            for (int counterY = 0; counterY < imageSize; counterY++){
                                dataTemp = revisedMapVer [counterX][counterY];
                                
                                if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                                else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageSize-1){
                                    readBit2 [0] = dataTemp2/65536;
                                    dataTemp2 = dataTemp2%65536;
                                    readBit2 [1] = dataTemp2/256;
                                    dataTemp2 = dataTemp2%256;
                                    readBit2 [2] = dataTemp2;
                                    
                                    if (counterY == imageSize-1){
                                        if (dataTemp != dataTemp2){
                                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                            dataHold [indexCount] = (char)entryCount, indexCount++;
                                            
                                            readBit2 [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit2 [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit2 [2] = dataTemp;
                                            
                                            entryCount = 1;
                                            
                                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                            dataHold [indexCount] = (char)entryCount, indexCount++;
                                        }
                                        else{
                                            
                                            entryCount++;
                                            
                                            dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                            dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                            dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                            dataHold [indexCount] = (char)entryCount, indexCount++;
                                        }
                                    }
                                    else{
                                        
                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                    
                                    if (counterY == imageSize-1) entryCount = 0;
                                    else entryCount = 1, dataTemp2 = dataTemp;
                                }
                                else entryCount++;
                            }
                        }
                        
                        ofstream outfile5 (revisedMapPath.c_str(), ofstream::binary);
                        outfile5.write(dataHold, indexCount);
                        outfile5.close();
                        
                        delete [] dataHold;
                        
                        for (int counter2 = 0; counter2 < imageSize+1; counter2++) delete [] revisedMapVer [counter2];
                        
                        delete [] revisedMapVer;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                [dataRepairReadWrite lineageRelDataSet];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Line Number Fault"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            string lineageStringExtract = arrayListString [repairListTableCurrentRow];
            
            [replaceFromTextDisplay setStringValue:@(lineageStringExtract.c_str())];
            [replaceToTextDisplay setStringValue:@(lineageStringExtract.c_str())];
            
            lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("//"));
            
            int lingExtractTemp = atoi(lineageStringExtract.c_str());
            lineageStringExtract = to_string(lingExtractTemp);
            
            [replaceLineFromDisplay setStringValue:@(lineageStringExtract.c_str())];
            [replaceLineToDisplay setStringValue:@(lineageStringExtract.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            [replaceFromTextDisplay setStringValue:@""];
            [replaceToTextDisplay setStringValue:@""];
            [replaceLineFromDisplay setStringValue:@""];
            [replaceLineToDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//1:"Lineage:Line No//Xposition/Yposition/Time/Event/Parent-fusion partner cell no/Cell no/Lineage. no/Fusion-partner Lineage no";
//2:"PR:Line No//Xposition/Yposition/Average/Connect no/Cell no/Status/Lineage. no";
//3:"ST:Line No//Status/Zero/PR Starting/Zero/Zero/Zero/Zero/Zero/Connect no/Lineage. no";
//4:"GC:Line No//Xposition/Yposition/Total area/Average/Connect no/Target hit";
//5:"RL:Line No//Lineage no/Connect no/Time/Cell no/Target/Zero";
//6:"AD:Line No//Connect No/Process type/Cut type/Pair no/Cell dim/Zero";
//7:"Map:Line No//Connect No/Number of Pix";
//8:"Fluorescent-Line:Line No//Xposition/Yposition/connect no/CH no";
//9:"Fluorescent-Area:Line No//connect no/CH no/CH value/CH area";
//10:"Fluorescent-CutOff:Line No//Time/CH1 Cut/CH2 cut/CH3 cut";

-(IBAction)replaceLingSelfSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1 || listArrayStatusHold == 2 || listArrayStatusHold == 3 || listArrayStatusHold == 5){
                if (listArrayStatusHold == 1){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 8; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("/")-2);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-2);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *lingNSString = [lingNoSetDisplay stringValue];
                        string lingString = [lingNSString UTF8String];
                        
                        if (atoi(lingString.c_str()) > 0){
                            //-----Lineage-----
                            string countLengthString = " ";
                            int countLengthAdd = 5-(int)(lingString.length());
                            countLengthString = countLengthString+"L";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+lingString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 2){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 9; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(2);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-2);
                        string afterString = fromString.substr(fromString.find("~~"));
                        
                        NSString *lingNSString = [lingNoSetDisplay stringValue];
                        string lingString = [lingNSString UTF8String];
                        
                        if (atoi(lingString.c_str()) > 0){
                            //-----Lineage-----
                            string countLengthString = " ";
                            int countLengthAdd = 5-(int)(lingString.length());
                            countLengthString = countLengthString+"L";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+lingString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 3){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 11; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(2);
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-2);
                        string afterString = fromString.substr(fromString.find("~~"));
                        
                        NSString *lingNSString = [lingNoSetDisplay stringValue];
                        string lingString = [lingNSString UTF8String];
                        
                        if (atoi(lingString.c_str()) > 0){
                            //-----Lineage-----
                            string countLengthString = " ";
                            int countLengthAdd = 5-(int)(lingString.length());
                            countLengthString = countLengthString+"L";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+lingString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 5){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 2; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(2, lineageStringExtract.find("/")-2);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-2);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *lingNSString = [lingNoSetDisplay stringValue];
                        string lingString = [lingNSString UTF8String];
                        
                        if (atoi(lingString.c_str()) > 0){
                            //-----Lineage-----
                            string countLengthString = " ";
                            int countLengthAdd = 5-(int)(lingString.length());
                            countLengthString = countLengthString+"L";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+lingString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceLingPartnerSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1){
                NSString *fromNSString = [replaceFromTextDisplay stringValue];
                string fromString = [fromNSString UTF8String];
                
                if (fromString != ""){
                    string lineageStringExtract = fromString;
                    
                    for (int counter1 = 0; counter1 < 9; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(2);
                    
                    string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-2);
                    string afterString = fromString.substr(fromString.find("~~"));
                    
                    NSString *lingNSString = [lingNoSetDisplay stringValue];
                    string lingString = [lingNSString UTF8String];
                    
                    if (atoi(lingString.c_str()) > 0){
                        //-----Lineage-----
                        string countLengthString = " ";
                        int countLengthAdd = 5-(int)(lingString.length());
                        countLengthString = countLengthString+"l";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+lingString;
                        beforeString = beforeString+countLengthString+afterString;
                        
                        [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceCellSelfSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1 || listArrayStatusHold == 2 || listArrayStatusHold == 5){
                if (listArrayStatusHold == 1){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 7; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("C")+1);
                        
                        string beforeString;
                        
                        if ((int)fromString.find("/  C") != -1) {
                            beforeString = fromString.substr(0, fromString.find("/  C")+1);
                        }
                        else if ((int)fromString.find("/ C") != -1) {
                            beforeString = fromString.substr(0, fromString.find("/ C")+1);
                        }
                        
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *cellNSString = [cellNoSetDisplay stringValue];
                        string cellString = [cellNSString UTF8String];
                        
                        //-----Cell-----
                        string countLengthString = " ";
                        
                        if (atoi(cellString.c_str()) == 0) countLengthString = countLengthString+" C000000000";
                        else if (atoi(cellString.c_str()) < 0){
                            cellString = cellString.substr(1);
                            int countLengthAdd = 9-(int)(cellString.length());
                            countLengthString = countLengthString+"C-";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+cellString;
                        }
                        else if (atoi(cellString.c_str()) > 0){
                            int countLengthAdd = 9-(int)(cellString.length());
                            countLengthString = countLengthString+" C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+cellString;
                        }
                        
                        beforeString = beforeString+countLengthString+afterString;
                        
                        [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 2){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 6; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("C")+1);
                        
                        string beforeString;
                        
                        if ((int)fromString.find("/  C") != -1) {
                            beforeString = fromString.substr(0, fromString.find("/  C")+1);
                        }
                        else if ((int)fromString.find("/ C") != -1) {
                            beforeString = fromString.substr(0, fromString.find("/ C")+1);
                        }
                        
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *cellNSString = [cellNoSetDisplay stringValue];
                        string cellString = [cellNSString UTF8String];
                        
                        //-----Cell-----
                        string countLengthString = " ";
                        
                        if (atoi(cellString.c_str()) == 0) countLengthString = countLengthString+" C000000000";
                        else if (atoi(cellString.c_str()) < 0){
                            cellString = cellString.substr(1);
                            int countLengthAdd = 9-(int)(cellString.length());
                            countLengthString = countLengthString+"C-";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+cellString;
                        }
                        else if (atoi(cellString.c_str()) > 0){
                            int countLengthAdd = 9-(int)(cellString.length());
                            countLengthString = countLengthString+" C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+cellString;
                        }
                        
                        beforeString = beforeString+countLengthString+afterString;
                        
                        [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 5){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 5; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("C")+1);
                        
                        string beforeString;
                        
                        if ((int)fromString.find("/  C") != -1) {
                            beforeString = fromString.substr(0, fromString.find("/  C")+1);
                        }
                        else if ((int)fromString.find("/ C") != -1) {
                            beforeString = fromString.substr(0, fromString.find("/ C")+1);
                        }
                        
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *cellNSString = [cellNoSetDisplay stringValue];
                        string cellString = [cellNSString UTF8String];
                        
                        //-----Cell-----
                        string countLengthString = " ";
                        
                        if (atoi(cellString.c_str()) == 0) countLengthString = countLengthString+" C000000000";
                        else if (atoi(cellString.c_str()) < 0){
                            cellString = cellString.substr(1);
                            int countLengthAdd = 9-(int)(cellString.length());
                            countLengthString = countLengthString+"C-";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+cellString;
                        }
                        else if (atoi(cellString.c_str()) > 0){
                            int countLengthAdd = 9-(int)(cellString.length());
                            countLengthString = countLengthString+" C";
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+cellString;
                        }
                        
                        beforeString = beforeString+countLengthString+afterString;
                        
                        [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceCellPartnerSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold == 1){
                NSString *fromNSString = [replaceFromTextDisplay stringValue];
                string fromString = [fromNSString UTF8String];
                
                if (fromString != ""){
                    string lineageStringExtract = fromString;
                    
                    for (int counter1 = 0; counter1 < 6; counter1++){
                        lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                    }
                    
                    lineageStringExtract = lineageStringExtract.substr(0, lineageStringExtract.find("/"));
                    lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("c")+1);
                    
                    string beforeString;
                    
                    if ((int)fromString.find("/  c") != -1) {
                        beforeString = fromString.substr(0, fromString.find("/  c")+1);
                    }
                    else if ((int)fromString.find("/ c") != -1) {
                        beforeString = fromString.substr(0, fromString.find("/ c")+1);
                    }
                    
                    string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                    
                    NSString *cellNSString = [cellNoSetDisplay stringValue];
                    string cellString = [cellNSString UTF8String];
                    
                    //-----Cell-----
                    string countLengthString = " ";
                    
                    if (atoi(cellString.c_str()) == 0) countLengthString = countLengthString+" c000000000";
                    else if (atoi(cellString.c_str()) < 0){
                        cellString = cellString.substr(1);
                        int countLengthAdd = 9-(int)(cellString.length());
                        countLengthString = countLengthString+"c-";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+cellString;
                    }
                    else if (atoi(cellString.c_str()) > 0){
                        int countLengthAdd = 9-(int)(cellString.length());
                        countLengthString = countLengthString+" c";
                        
                        for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                            countLengthString = countLengthString+"0";
                        }
                        
                        countLengthString = countLengthString+cellString;
                    }
                    
                    beforeString = beforeString+countLengthString+afterString;
                    
                    [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceConnectSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            if (listArrayStatusHold >= 2 && listArrayStatusHold <= 9){
                if (listArrayStatusHold == 2){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 5; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 3){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 10; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find("~~"));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 4){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 6; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 5){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 3; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 6){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 2; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 7){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 2; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 8){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 4; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (listArrayStatusHold == 9){
                    NSString *fromNSString = [replaceFromTextDisplay stringValue];
                    string fromString = [fromNSString UTF8String];
                    
                    if (fromString != ""){
                        string lineageStringExtract = fromString;
                        
                        for (int counter1 = 0; counter1 < 2; counter1++){
                            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find("/")+1);
                        }
                        
                        lineageStringExtract = lineageStringExtract.substr(1, lineageStringExtract.find("/")-1);
                        
                        string beforeString = fromString.substr(0, fromString.find(lineageStringExtract)-1);
                        string afterString = fromString.substr(fromString.find(lineageStringExtract)+lineageStringExtract.length(), fromString.length()-(fromString.find(lineageStringExtract)+lineageStringExtract.length()));
                        
                        NSString *connectNSString = [connectNoSetDisplay stringValue];
                        string connectString = [connectNSString UTF8String];
                        
                        if (atoi(connectString.c_str()) > 0){
                            //-----Connect-----
                            int connectLength = (int)(lineageStringExtract.length());
                            
                            string countLengthString = " ";
                            int countLengthAdd = connectLength-(int)(connectString.length());
                            
                            for (int counter2 = 0; counter2 < countLengthAdd; counter2++){
                                countLengthString = countLengthString+"0";
                            }
                            
                            countLengthString = countLengthString+connectString;
                            beforeString = beforeString+countLengthString+afterString;
                            
                            [replaceToTextDisplay setStringValue:@(beforeString.c_str())];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)replaceSwitchSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSString *toNSString = [replaceToTextDisplay stringValue];
        string toString = [toNSString UTF8String];
        
        [replaceFromTextDisplay setStringValue:@(toString.c_str())];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeSet:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (listStringStatus != 0){
            string lineageStringExtract = arrayListString [repairListTableCurrentRow];
            lineageStringExtract = lineageStringExtract.substr(lineageStringExtract.find(":")+1, lineageStringExtract.find("/")-lineageStringExtract.find(":")-1);
            
            int lingExtractTemp = atoi(lineageStringExtract.c_str());
            lineageStringExtract = to_string(lingExtractTemp);
            
            [removeLineFromDisplay setStringValue:@(lineageStringExtract.c_str())];
            [removeLineToDisplay setStringValue:@(lineageStringExtract.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)removeClear:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (listStringStatus != 0){
            [removeLineFromDisplay setStringValue:@""];
            [removeLineToDisplay setStringValue:@""];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"List Entry Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
