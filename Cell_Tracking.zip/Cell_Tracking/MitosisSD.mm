//
//  MitosisSD.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2016-02-20.
//
//

#import "MitosisSD.h"

@implementation MitosisSD

-(double)mitosisSDReturn:(int)imageNo :(int)processType{
    double returnSD = 1000;
    
    int **referenceMap = new int *[101];
    int **targetMitosisMap = new int *[101];
    
    for (int counter1 = 0; counter1 < 101; counter1++){
        referenceMap [counter1] = new int [101];
        targetMitosisMap[counter1] = new int [101];
    }
    
    for (int counter1 = 0; counter1 < 101; counter1++){
        for (int counter2 = 0; counter2 < 101; counter2++){
            referenceMap[counter1][counter2] = 0;
            targetMitosisMap[counter1][counter2] = 0;
        }
    }
    
    int *snapData = new int [1000];
    int snapDataCount = 0;
    int snapDataLimit = 1000;
    int *arrayMitosisRefData = new int [1000];
    int mitosisRefDataCount = 0;
    
    string cellLineageExtract = cellLineageNoHold.substr(1);
    string cellNumberExtract = cellNoHold.substr(1);
    
    int cellLineageTempInt = atoi(cellLineageExtract.c_str());
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    
    int endPoint = 0;
    int findFlag = 0;
    
    if (processType == 1){
        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
            if (arrayTimeSelected [counter1*10] == 0 || arrayTimeSelected [counter1*10] == 1 || arrayTimeSelected [counter1*10] == 7){
                if (counter1+1 < timeSelectedCount/10) endPoint = arrayTimeSelected [(counter1+1)*10+2]-1;
                else endPoint = positionReviseCount/7-1;
                
                if (cellLineageTempInt == arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+6] && cellNumberTempInt == arrayPositionRevise [arrayTimeSelected [counter1*10+2]*7+4]){
                    if ((endPoint-arrayTimeSelected [counter1*10+2])*2+500 > snapDataLimit){
                        int *arrayUpDate = new int [snapDataCount+10];
                        
                        for (int counter2 = 0; counter2 < snapDataCount; counter2++) arrayUpDate [counter2] = snapData [counter2];
                        
                        delete [] snapData;
                        snapData = new int [(endPoint-arrayTimeSelected [counter1*10+2])*2+500];
                        snapDataLimit = (endPoint-arrayTimeSelected [counter1*10+2])*2+500;
                        
                        for (int counter2 = 0; counter2 < snapDataCount; counter2++) snapData [counter2] = arrayUpDate [counter2];
                        delete [] arrayUpDate;
                    }
                    
                    snapDataCount = 0;
                    findFlag = 1;
                    
                    for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 <= endPoint; counter2++){
                        snapData [snapDataCount] = arrayPositionRevise [counter2*7], snapDataCount++;
                        snapData [snapDataCount] = arrayPositionRevise [counter2*7+1], snapDataCount++;
                    }
                    
                    if (findFlag == 1){
                        break;
                    }
                }
            }
        }
    }
    
    if (processType == 2){
        ifstream fin;
        
        string extension = to_string(imageNo);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string masterDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
        string masterDataRevisePath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        string masterDataPath;
        string connectStatusDataPath;
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter3 = 0; counter3 < 6; counter3++){
            sizeForCopy = 0;
            
            if (stat(masterDataTempPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(masterDataRevisePath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter3 == 0) size1 = sizeForCopy;
                else if (counter3 == 1) size2 = sizeForCopy;
                else if (counter3 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter3 == 3) size1 = sizeForCopy;
                else if (counter3 == 4) size2 = sizeForCopy;
                else if (counter3 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (stat(masterDataTempPath.c_str(), &sizeOfFile) == 0 && stat(masterDataRevisePath.c_str(), &sizeOfFile) == 0){
            masterDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
            connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
        }
        else if (stat(masterDataTempPath.c_str(), &sizeOfFile) == -1 && stat(masterDataRevisePath.c_str(), &sizeOfFile) == 0){
            masterDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
            connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        }
        else if (stat(masterDataTempPath.c_str(), &sizeOfFile) == 0 && stat(masterDataRevisePath.c_str(), &sizeOfFile) == -1){
            masterDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
            connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
        }
        
        if (checkFlag == 1){
            //-----MasterData Read-----
            int *masterDataSnap = new int [sizeForCopy+50];
            int masterDataSnapCount = 0;
            
            fin.open(masterDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [17];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                masterDataSnap [masterDataSnapCount] = finData [1], masterDataSnapCount++;
                                masterDataSnap [masterDataSnapCount] = finData [3], masterDataSnapCount++;
                                masterDataSnap [masterDataSnapCount] = finData [4], masterDataSnapCount++;
                                masterDataSnap [masterDataSnapCount] = finData [7], masterDataSnapCount++;
                                masterDataSnap [masterDataSnapCount] = finData [12], masterDataSnapCount++;
                                masterDataSnap [masterDataSnapCount] = finData [13], masterDataSnapCount++;
                                masterDataSnap [masterDataSnapCount] = finData [16], masterDataSnapCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
            
            //-----Status Read-----
            sizeForCopy = 0;
            
            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *masterStatusSave = new int [sizeForCopy+50];
            int masterStatusSaveCount = 0;
            
            if (sizeForCopy != 0){
                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                int finData [19];
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            masterStatusSave [masterStatusSaveCount] = finData [0], masterStatusSaveCount++; //-----Selected, removed, eliminated status-----
                            masterStatusSave [masterStatusSaveCount] = finData [3], masterStatusSaveCount++; //-----When new line is created, enter line number which creates-----
                            masterStatusSave [masterStatusSaveCount] = finData [6], masterStatusSaveCount++; //-----PositionRevise Start-----
                            masterStatusSave [masterStatusSaveCount] = finData [8], masterStatusSaveCount++; //-----Cut line number-----
                            masterStatusSave [masterStatusSaveCount] = finData [9], masterStatusSaveCount++; //-----X Start-----
                            masterStatusSave [masterStatusSaveCount] = finData [10], masterStatusSaveCount++; //-----X End-----
                            masterStatusSave [masterStatusSaveCount] = finData [11], masterStatusSaveCount++; //-----Y Start-----
                            masterStatusSave [masterStatusSaveCount] = finData [12], masterStatusSaveCount++; //-----Y End-----
                            masterStatusSave [masterStatusSaveCount] = finData [15], masterStatusSaveCount++; //-----Connect-----
                            masterStatusSave [masterStatusSaveCount] = finData [18], masterStatusSaveCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
            
            for (int counter1 = 0; counter1 < masterStatusSaveCount/10; counter1++){
                if (masterStatusSave [counter1*10] == 0 || masterStatusSave [counter1*10] == 1 || masterStatusSave [counter1*10] == 7){
                    if (counter1+1 < masterStatusSaveCount/10) endPoint = masterStatusSave [(counter1+1)*10+2]-1;
                    else endPoint = masterDataSnapCount/7-1;
                    
                    if (cellLineageTempInt == masterDataSnap [masterStatusSave [counter1*10+2]*7+6] && cellNumberTempInt == masterDataSnap [masterStatusSave [counter1*10+2]*7+4]){
                        if ((endPoint-masterStatusSave [counter1*10+2])*2+500 > snapDataLimit){
                            int *arrayUpDate = new int [snapDataCount+10];
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) arrayUpDate [counter2] = snapData [counter2];
                            
                            delete [] snapData;
                            snapData = new int [(endPoint-masterStatusSave [counter1*10+2])*2+500];
                            snapDataLimit = (endPoint-masterStatusSave [counter1*10+2])*2+500;
                            
                            for (int counter2 = 0; counter2 < snapDataCount; counter2++) snapData [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                        
                        snapDataCount = 0;
                        findFlag = 1;
                        
                        for (int counter2 = masterStatusSave [counter1*10+2]; counter2 <= endPoint; counter2++){
                            snapData [snapDataCount] = masterDataSnap [counter2*7], snapDataCount++;
                            snapData [snapDataCount] = masterDataSnap [counter2*7+1], snapDataCount++;
                        }
                        
                        if (findFlag == 1){
                            break;
                        }
                    }
                }
            }
            
            delete [] masterDataSnap;
            delete [] masterStatusSave;
        }
    }
    
    int maxPointDimX = 0;
    int maxPointDimY = 0;
    int minPointDimX = 1000000;
    int minPointDimY = 1000000;
    
    for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
        if (maxPointDimX < snapData [counter1*2]) maxPointDimX = snapData [counter1*2];
        if (minPointDimX > snapData [counter1*2]) minPointDimX = snapData [counter1*2];
        if (maxPointDimY < snapData [counter1*2+1]) maxPointDimY = snapData [counter1*2+1];
        if (minPointDimY > snapData [counter1*2+1]) minPointDimY = snapData [counter1*2+1];
    }
    
    int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
    int verticalLength = (maxPointDimY-minPointDimY)/2*2;
    int dimension = 0;
    
    if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
    if (horizontalLength < verticalLength) dimension = verticalLength+30;
    
    dimension = (dimension/2)*2;
    
    if (dimension > 0){
        int horizontalStart2 = minPointDimX-(dimension-horizontalLength)/2;
        int verticalStart2 = minPointDimY-(dimension-verticalLength)/2;
        
        int **connectivitySourceTemp = new int *[dimension+4];
        int **connectivityMapCut7 = new int *[dimension+4];
        int **connectivityMapCut6 = new int *[dimension+4];
        int **connectivityMapCut5 = new int *[dimension+4];
        int **connectivityMapCut4 = new int *[dimension+4];
        int **connectivityUpdate5 = new int *[dimension+4];
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            connectivitySourceTemp [counter1] = new int [dimension+4];
            connectivityMapCut7 [counter1] = new int [dimension+4];
            connectivityMapCut6 [counter1] = new int [dimension+4];
            connectivityMapCut5 [counter1] = new int [dimension+4];
            connectivityMapCut4 [counter1] = new int [dimension+4];
            connectivityUpdate5 [counter1] = new int [dimension+4];
        }
        
        for (int counterY = 0; counterY < dimension+4; counterY++){
            for (int counterX = 0; counterX < dimension+4; counterX++){
                connectivitySourceTemp [counterY][counterX] = 0;
                connectivityMapCut7 [counterY][counterX] = 0;
                connectivityMapCut6 [counterY][counterX] = 0;
                connectivityMapCut5 [counterY][counterX] = 0;
                connectivityMapCut4 [counterY][counterX] = 0;
            }
        }
        
        for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
            connectivitySourceTemp [snapData [counter1*2+1]-verticalStart2][snapData [counter1*2]-horizontalStart2] = 1;
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp [counterA][counterB];
        //    cout<<" connectivitySourceTemp "<<counterA<<endl;
        //}
        
        //-----Connectivity analysis, For Zero-----
        int *connectAnalysisX = new int [(dimension+2)*4];
        int *connectAnalysisY = new int [(dimension+2)*4];
        int *connectAnalysisTempX = new int [(dimension+2)*4];
        int *connectAnalysisTempY = new int [(dimension+2)*4];
        
        int connectivityNumber = -3;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivitySourceTemp [counterY][counterX] == 0){
                    connectivityNumber = connectivityNumber+2;
                    connectivitySourceTemp [counterY][counterX] = connectivityNumber;
                    
                    connectAnalysisCount = 0;
                    
                    if (counterY-1 >= 0 && connectivitySourceTemp [counterY-1][counterX] == 0){
                        connectivitySourceTemp [counterY-1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                    }
                    if (counterX+1 < dimension && connectivitySourceTemp [counterY][counterX+1] == 0){
                        connectivitySourceTemp [counterY][counterX+1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    if (counterY+1 < dimension && connectivitySourceTemp [counterY+1][counterX] == 0){
                        connectivitySourceTemp [counterY+1][counterX] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                    }
                    if (counterX-1 >= 0 && connectivitySourceTemp [counterY][counterX-1] == 0){
                        connectivitySourceTemp [counterY][counterX-1] = connectivityNumber;
                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                    }
                    
                    if (connectAnalysisCount != 0){
                        do{
                            
                            terminationFlag = 1;
                            connectAnalysisTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                
                                if (ySource-1 >= 0 && connectivitySourceTemp [ySource-1][xSource] == 0){
                                    connectivitySourceTemp [ySource-1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                }
                                if (xSource+1 < dimension && connectivitySourceTemp [ySource][xSource+1] == 0){
                                    connectivitySourceTemp [ySource][xSource+1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                                if (ySource+1 < dimension && connectivitySourceTemp [ySource+1][xSource] == 0){
                                    connectivitySourceTemp [ySource+1][xSource] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                }
                                if (xSource-1 >= 0 && connectivitySourceTemp [ySource][xSource-1] == 0){
                                    connectivitySourceTemp [ySource][xSource-1] = connectivityNumber;
                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                }
                            }
                            
                            for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                            }
                            
                            connectAnalysisCount = connectAnalysisTempCount;
                            
                            if (connectAnalysisCount == 0) terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                    }
                }
            }
        }
        
        //-----Remove connectivity groups, which attach edge, extract inner part of Linked Line-----
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivitySourceTemp [counterY][counterX] == -1) connectivitySourceTemp [counterY][counterX] = 0;
            }
        }
        
        //for (int counterA = 0; counterA < dimension; counterA++){
        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivitySourceTemp  [counterA][counterB];
        //    cout<<"connectivitySourceTemp  "<<counterA<<endl;
        //}
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (counterY+verticalStart2 >= 0 && counterY+verticalStart2 < imageDimension && counterX+horizontalStart2 >= 0 && counterX+horizontalStart2 < imageDimension){
                    if (sourceImage [counterY+verticalStart2][counterX+horizontalStart2] > cutOff7 && sourceImage [counterY+verticalStart2][counterX+horizontalStart2] != 100) connectivityMapCut7 [counterY][counterX] = 1;
                    else connectivityMapCut7 [counterY][counterX] = 0;
                    
                    if (sourceImage [counterY+verticalStart2][counterX+horizontalStart2] > cutOff6 && sourceImage [counterY+verticalStart2][counterX+horizontalStart2] != 100) connectivityMapCut6 [counterY][counterX] = 1;
                    else connectivityMapCut6 [counterY][counterX] = 0;
                    
                    if (sourceImage [counterY+verticalStart2][counterX+horizontalStart2] > cutOff5 && sourceImage [counterY+verticalStart2][counterX+horizontalStart2] != 100) connectivityMapCut5 [counterY][counterX] = 1;
                    else connectivityMapCut5 [counterY][counterX] = 0;
                    
                    if (sourceImage [counterY+verticalStart2][counterX+horizontalStart2] > cutOff4 && sourceImage [counterY+verticalStart2][counterX+horizontalStart2] != 100) connectivityMapCut4 [counterY][counterX] = 1;
                    else connectivityMapCut4 [counterY][counterX] = 0;
                }
            }
        }
        
        int totalCount7 = 0;
        int totalCount6 = 0;
        int totalCount5 = 0;
        int totalCount4 = 0;
        
        for (int counterY = 0; counterY < dimension; counterY++){
            for (int counterX = 0; counterX < dimension; counterX++){
                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut7 [counterY][counterX] != 0) totalCount7++;
                else connectivityMapCut7 [counterY][counterX] = 0;
                
                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut6 [counterY][counterX] != 0) totalCount6++;
                else connectivityMapCut6 [counterY][counterX] = 0;
                
                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut5 [counterY][counterX] != 0) totalCount5++;
                else connectivityMapCut5 [counterY][counterX] = 0;
                
                if (connectivitySourceTemp [counterY][counterX] == 1 && connectivityMapCut4 [counterY][counterX] != 0) totalCount4++;
                else connectivityMapCut4 [counterY][counterX] = 0;
            }
        }
        
        int lineTaken = 0;
        
        if (totalCount7 == 0){
            if (totalCount6 == 0){
                if (totalCount5 == 0){
                    if (totalCount4 == 0) lineTaken = 0;
                    else lineTaken = 4;
                }
                else if (totalCount4 > totalCount5*0.8) lineTaken = 4;
                else lineTaken = 5;
            }
            else if (totalCount5 > totalCount6*0.8) lineTaken = 5;
            else lineTaken = 6;
        }
        else if (totalCount6 > totalCount7*0.8) lineTaken = 7;
        else lineTaken = 6;
        
        if (lineTaken == 7){
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    connectivityMapCut6 [counterY][counterX] = connectivityMapCut7 [counterY][counterX];
                }
            }
        }
        else if (lineTaken == 5){
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    connectivityMapCut6 [counterY][counterX] = connectivityMapCut5 [counterY][counterX];
                }
            }
        }
        else if (lineTaken == 4){
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    connectivityMapCut6 [counterY][counterX] = connectivityMapCut4 [counterY][counterX];
                }
            }
        }
        
        int sourceAreaSize = 0;
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] connectivitySourceTemp [counter1];
        delete [] connectivitySourceTemp;
        
        if (lineTaken != 0){
            //-----Fill zero-----
            for (int counterX = 0; counterX < dimension+2; counterX++){
                for (int counterY = 0; counterY < dimension+2; counterY++) connectivityUpdate5 [counterY][counterX] = 0;
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    connectivityUpdate5 [counterY+1][counterX+1] = connectivityMapCut6 [counterY][counterX];
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                    if (connectivityUpdate5 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityUpdate5 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] == 0){
                            connectivityUpdate5 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                            connectivityUpdate5 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                            connectivityUpdate5 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                            connectivityUpdate5 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityUpdate5 [ySource-1][xSource] == 0){
                                        connectivityUpdate5 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension+2 && connectivityUpdate5 [ySource][xSource+1] == 0){
                                        connectivityUpdate5 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension+2 && connectivityUpdate5 [ySource+1][xSource] == 0){
                                        connectivityUpdate5 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityUpdate5 [ySource][xSource-1] == 0){
                                        connectivityUpdate5 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension+2; counterA++){
            //    for (int counterB = 0; counterB < dimension+2; counterB++) cout<<" "<<connectivityUpdate5 [counterA][counterB];
            //    cout<<" connectivityUpdate5 "<<counterA<<endl;
            //}
            
            int connectTemp2 = 0;
            
            if (connectivityNumber < -1){
                int *connectCheckArray = new int [connectivityNumber*-1*2+5];
                
                for (int counter1 = 0; counter1 < connectivityNumber*-1*2+5; counter1++) connectCheckArray [counter1] = 0;
                
                for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                        connectTemp2 = connectivityUpdate5 [counterY2][counterX2];
                        
                        if (connectTemp2 < -1){
                            connectTemp2 = connectTemp2*-1;
                            
                            if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && connectivityUpdate5 [counterY2-1][counterX2] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2-1 >= 0 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2-1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2-1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2-1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2][counterX2+1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2+1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2+1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2+1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && connectivityUpdate5 [counterY2+1][counterX2] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterY2+1 < dimension+2 && counterX2-1 >= 0 && connectivityUpdate5 [counterY2+1][counterX2-1] > 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2+1][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2+1][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                            if (counterX2-1 >= 0 && connectivityUpdate5 [counterY2][counterX2-1] == 0){
                                if (connectCheckArray [connectTemp2*2] == 0) connectCheckArray [connectTemp2*2] = connectivityUpdate5 [counterY2][counterX2-1];
                                else if (connectCheckArray [connectTemp2*2] != 0 && connectCheckArray [connectTemp2*2] != connectivityUpdate5 [counterY2][counterX2-1]) connectCheckArray [connectTemp2*2+1] = 1;
                            }
                        }
                    }
                }
                
                int zeroFillFlag = 0;
                
                for (int counter1 = 2; counter1 <= connectivityNumber*-1; counter1++){
                    if (connectCheckArray [counter1*2] != 0 && connectCheckArray [counter1*2+1] == 0) zeroFillFlag = 1;
                }
                
                if (zeroFillFlag == 1){
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            connectTemp2 = connectivityUpdate5 [counterY2][counterX2]*-1;
                            
                            if (connectTemp2 > 0 && connectCheckArray [connectTemp2*2+1] == 0) connectivityUpdate5 [counterY2][counterX2] = connectCheckArray [connectTemp2*2];
                        }
                    }
                    
                    for (int counterY2 = 0; counterY2 < dimension+2; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension+2; counterX2++){
                            if (connectivityUpdate5 [counterY2][counterX2] > 0) connectivityMapCut6 [counterY2-1][counterX2-1] = connectivityUpdate5 [counterY2][counterX2];
                        }
                    }
                }
                
                delete [] connectCheckArray;
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut6 [counterY][counterX] != 0){
                        if (counterX+1 < dimension && connectivityMapCut6 [counterY][counterX+1] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                        else if (counterY+1 < dimension && connectivityMapCut6 [counterY+1][counterX] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                        else if (counterX-1 >= 0 && connectivityMapCut6 [counterY][counterX-1] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                        else if (counterY-1 >= 0 && connectivityMapCut6 [counterY-1][counterX] == 0) connectivityMapCut6 [counterY][counterX] = -1;
                    }
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMapCut6 [counterY][counterX] > 0) connectivityMapCut6 [counterY][counterX] = 0;
                    if (connectivityMapCut6 [counterY][counterX] < 0) connectivityMapCut6 [counterY][counterX] = 1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapCut6 [counterY2][counterX2] == 0){
                        connectivityNumber--;
                        connectAnalysisCount = 0;
                        
                        connectivityMapCut6 [counterY2][counterX2] = connectivityNumber;
                        
                        if (counterY2-1 >= 0 && connectivityMapCut6 [counterY2-1][counterX2] == 0){
                            connectivityMapCut6 [counterY2-1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                        }
                        if (counterX2+1 < dimension && connectivityMapCut6 [counterY2][counterX2+1] == 0){
                            connectivityMapCut6 [counterY2][counterX2+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        if (counterY2+1 < dimension && connectivityMapCut6 [counterY2+1][counterX2] == 0){
                            connectivityMapCut6 [counterY2+1][counterX2] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                        }
                        if (counterX2-1 >= 0 && connectivityMapCut6 [counterY2][counterX2-1] == 0){
                            connectivityMapCut6 [counterY2][counterX2-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                    xSource = connectAnalysisX [counter1], ySource = connectAnalysisY [counter1];
                                    
                                    if (ySource-1 >= 0 && connectivityMapCut6 [ySource-1][xSource] == 0){
                                        connectivityMapCut6 [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMapCut6 [ySource][xSource+1] == 0){
                                        connectivityMapCut6 [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMapCut6 [ySource+1][xSource] == 0){
                                        connectivityMapCut6 [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMapCut6 [ySource][xSource-1] == 0){
                                        connectivityMapCut6 [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                    connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //-----Determine number of pixels-----
            connectivityNumber = connectivityNumber*-1;
            
            int *connectedPix = new int [connectivityNumber+50];
            
            for (int counter1 = 0; counter1 < connectivityNumber+50; counter1++) connectedPix [counter1] = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapCut6 [counterY2][counterX2] < -1){
                        connectTemp2 = connectTemp2*-1;
                        connectedPix [connectivityMapCut6 [counterY2][counterX2]*-1]++;
                    }
                }
            }
            
            int **newConnectivityMapTemp = new int *[dimension+4];
            for (int counter1 = 0; counter1 < dimension+4; counter1++) newConnectivityMapTemp [counter1] = new int [dimension+4];
            
            for (int counterY = 0; counterY < dimension+4; counterY++){
                for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
            }
            
            int largestConnect = 0;
            int largestConnectNo = 0;
            
            for (int counter1 = 2; counter1 <= connectivityNumber; counter1++){
                if (connectedPix [counter1] > largestConnect){
                    largestConnect = connectedPix [counter1];
                    largestConnectNo = counter1;
                }
            }
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (connectivityMapCut6 [counterY2][counterX2] == largestConnectNo*-1){
                        if (counterY2-1 >= 0 && counterX2-1 >= 0 && connectivityMapCut6 [counterY2-1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                            connectivityMapCut6 [counterY2-1][counterX2-1] = 0;
                        }
                        if (counterY2-1 >= 0 && connectivityMapCut6 [counterY2-1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                            connectivityMapCut6 [counterY2-1][counterX2] = 0;
                        }
                        if (counterY2-1 >= 0 && counterX2+1 < dimension && connectivityMapCut6 [counterY2-1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                            connectivityMapCut6 [counterY2-1][counterX2+1] = 0;
                        }
                        if (counterX2+1 < dimension && connectivityMapCut6 [counterY2][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                            connectivityMapCut6 [counterY2][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2+1 < dimension && connectivityMapCut6 [counterY2+1][counterX2+1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                            connectivityMapCut6 [counterY2+1][counterX2+1] = 0;
                        }
                        if (counterY2+1 < dimension && connectivityMapCut6 [counterY2+1][counterX2] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                            connectivityMapCut6 [counterY2+1][counterX2] = 0;
                        }
                        if (counterY2+1 < dimension && counterX2-1 >= 0 && connectivityMapCut6 [counterY2+1][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                            connectivityMapCut6 [counterY2+1][counterX2-1] = 0;
                        }
                        if (counterX2-1 >= 0 && connectivityMapCut6 [counterY2][counterX2-1] == 1){
                            newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                            connectivityMapCut6 [counterY2][counterX2-1] = 0;
                        }
                    }
                }
            }
            
            delete [] connectedPix;
            
            int xPositionTempStart = 0;
            int yPositionTempStart = 0;
            int lineSize = 0;
            
            for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                    if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                        connectivityMapCut6 [counterY2][counterX2] = 1;
                        xPositionTempStart = counterX2;
                        yPositionTempStart = counterY2;
                        lineSize++;
                    }
                    else connectivityMapCut6 [counterY2][counterX2] = 0;
                }
            }
            
            for (int counter1 = 0; counter1 < dimension+4; counter1++) delete [] newConnectivityMapTemp [counter1];
            delete [] newConnectivityMapTemp;
            
            int constructedLineCount = 0;
            
            int *arrayNewLines = new int [lineSize*2+50];
            
            connectivityMapCut6 [yPositionTempStart][xPositionTempStart] = -1;
            arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
            arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
            
            do{
                
                findFlag = 0;
                terminationFlag = 0;
                
                if (xPositionTempStart+1 < dimension){
                    if (connectivityMapCut6 [yPositionTempStart][xPositionTempStart+1] == 1){
                        connectivityMapCut6 [yPositionTempStart][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                        connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart] == 1){
                        connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                        connectivityMapCut6 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart][xPositionTempStart-1] == 1){
                        connectivityMapCut6 [yPositionTempStart][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                        connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart-1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart] == 1){
                        connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                        yPositionTempStart = yPositionTempStart-1, terminationFlag = 1, findFlag = 1;
                    }
                }
                if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                    if (connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                        connectivityMapCut6 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart+1+horizontalStart2, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart-1+verticalStart2, constructedLineCount++;
                        xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag = 1;
                    }
                }
                
            } while (terminationFlag == 1);
            
            if (constructedLineCount >= 16){
                for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                    for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                        if (connectivityMapCut6 [counterY2][counterX2] < 0) connectivityMapCut6 [counterY2][counterX2] = 1;
                    }
                }
                
                connectivityNumber = -3;
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut6 [counterY][counterX] == 0){
                            connectivityNumber = connectivityNumber+2;
                            connectAnalysisCount = 0;
                            
                            if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapCut6 [counterY][counterX] = connectivityNumber;
                            
                            if (counterY-1 >= 0 && connectivityMapCut6 [counterY-1][counterX] == 0){
                                connectivityMapCut6 [counterY-1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                            }
                            if (counterX+1 < dimension && connectivityMapCut6 [counterY][counterX+1] == 0){
                                connectivityMapCut6 [counterY][counterX+1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            if (counterY+1 < dimension && connectivityMapCut6 [counterY+1][counterX] == 0){
                                connectivityMapCut6 [counterY+1][counterX] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                            }
                            if (counterX-1 >= 0 && connectivityMapCut6 [counterY][counterX-1] == 0){
                                connectivityMapCut6 [counterY][counterX-1] = connectivityNumber;
                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                            }
                            
                            if (connectAnalysisCount != 0){
                                do{
                                    
                                    terminationFlag = 1;
                                    connectAnalysisTempCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisCount; counter1++){
                                        xSource = connectAnalysisX [counter1];
                                        ySource = connectAnalysisY [counter1];
                                        
                                        if (ySource-1 >= 0 && connectivityMapCut6 [ySource-1][xSource] == 0){
                                            connectivityMapCut6 [ySource-1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                        }
                                        if (xSource+1 < dimension && connectivityMapCut6 [ySource][xSource+1] == 0){
                                            connectivityMapCut6 [ySource][xSource+1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                        if (ySource+1 < dimension && connectivityMapCut6 [ySource+1][xSource] == 0){
                                            connectivityMapCut6 [ySource+1][xSource] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                        }
                                        if (xSource-1 >= 0 && connectivityMapCut6 [ySource][xSource-1] == 0){
                                            connectivityMapCut6 [ySource][xSource-1] = connectivityNumber;
                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < connectAnalysisTempCount; counter1++){
                                        connectAnalysisX [counter1] = connectAnalysisTempX [counter1], connectAnalysisY [counter1] = connectAnalysisTempY [counter1];
                                    }
                                    
                                    connectAnalysisCount = connectAnalysisTempCount;
                                    
                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                    
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                }
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut6 [counterY][counterX] == -1) connectivityMapCut6 [counterY][counterX] = 0;
                        else connectivityMapCut6 [counterY][counterX] = 1;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapCut6 [counterA][counterB];
                //    cout<<" connectivityMapCut6 "<<counterA<<endl;
                //}
                
                int gravityCenter [3] = {0,0,0};
                
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMapCut6 [counterY][counterX] == 1){
                            gravityCenter [0] = gravityCenter [0]+counterX;
                            gravityCenter [1] = gravityCenter [1]+counterY;
                            gravityCenter [2]++;
                        }
                    }
                }
                
                int gravityX = (int)(gravityCenter [0]/(double)gravityCenter [2])+horizontalStart2;
                int gravityY = (int)(gravityCenter [1]/(double)gravityCenter [2])+verticalStart2;
                
                int targetDiffX = 50-gravityX;
                int targetDiffY = 50-gravityY;
                
                snapDataCount = 0;
                
                for (int counter1 = 0; counter1 < constructedLineCount/2; counter1++){
                    snapData [snapDataCount] = gravityX+(arrayNewLines [counter1*2]-gravityX)+targetDiffX, snapDataCount++;
                    snapData [snapDataCount] = gravityY+(arrayNewLines [counter1*2+1]-gravityY)+targetDiffY, snapDataCount++;
                }
                
                sourceAreaSize = gravityCenter [2];
                
                if (snapDataCount != 0){
                    int dataTempX = 0;
                    int dataTempY = 0;
                    int longestX = 0;
                    int longestY = 0;
                    double referenceLine = 0;
                    double maxRatio = 1;
                    double ratio = 1;
                    double longestLine = 0;
                    double constTempA = 0;
                    double constTempB = 0;
                    
                    for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                        dataTempX = snapData [counter1*2];
                        dataTempY = snapData [counter1*2+1];
                        
                        if (dataTempX < 2 || dataTempX > 98 || dataTempY < 2 || dataTempY > 98){
                            longestLine = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                            
                            if (dataTempX < 0 && dataTempY == 50){
                                referenceLine = 48;
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX < 0 && dataTempY > 0 && dataTempY < 50){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = 2;
                                longestY = (int)(constTempA*2+constTempB);
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX < 0 && dataTempY < 0){
                                longestX = 2;
                                longestY = 2;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 0 && dataTempX < 50 && dataTempY < 0){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = (int)((2-constTempB)/(double)constTempA);
                                longestY = 2;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX == 50 && dataTempY < 0){
                                referenceLine = 48;
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 50 && dataTempX < 100 && dataTempY < 0){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = (int)((2-constTempB)/(double)constTempA);
                                longestY = 2;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 100 && dataTempY < 0){
                                longestX = 98;
                                longestY = 2;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 100 && dataTempY > 0 && dataTempY < 50){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = 98;
                                longestY = (int)(constTempA*98+constTempB);
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX == 50 && dataTempY > 100){
                                referenceLine = 48;
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 100 && dataTempY > 50 && dataTempY < 100){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = 98;
                                longestY = (int)(constTempA*98+constTempB);
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 100 && dataTempY > 100){
                                longestX = 98;
                                longestY = 98;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 50 && dataTempX < 100 && dataTempY > 100){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = (int)((98-constTempB)/(double)constTempA);
                                longestY = 98;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX == 50 && dataTempY > 100){
                                referenceLine = 48;
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX > 0 && dataTempX < 50 && dataTempY > 100){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = (int)((98-constTempB)/(double)constTempA);
                                longestY = 98;
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX < 0 && dataTempY > 100){
                                referenceLine = 48;
                                ratio = longestLine/(double)referenceLine;
                            }
                            else if (dataTempX < 0 && dataTempY > 50 && dataTempY < 100){
                                constTempA = (50-dataTempY)/(double)(50-dataTempX);
                                constTempB = 50-constTempA*50;
                                longestX = 2;
                                longestY = (int)(2*constTempA+constTempB);
                                referenceLine = sqrt((50-longestX)*(50-longestX)+(50-longestY)*(50-longestY));
                                ratio = longestLine/(double)referenceLine;
                            }
                            
                            if (maxRatio < ratio) maxRatio = ratio;
                        }
                    }
                    
                    int *snapDataRevised = new int [snapDataCount+100];
                    int snapDataRevisedCount = 0;
                    
                    if (maxRatio > 1){
                        for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                            dataTempX = snapData [counter1*2];
                            dataTempY = snapData [counter1*2+1];
                            
                            if (dataTempX < 50 && dataTempY == 50){
                                dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                                dataTempY = 50;
                            }
                            if (dataTempX < 50 && dataTempY < 50){
                                dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                                dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                            }
                            if (dataTempX == 50 && dataTempY < 50){
                                dataTempX = 50;
                                dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                            }
                            if (dataTempX > 50 && dataTempY < 50){
                                dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                                dataTempY = 50-(int)((50-dataTempY)/(double)maxRatio);
                            }
                            if (dataTempX == 50 && dataTempY > 50){
                                dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                                dataTempY = 50;
                            }
                            if (dataTempX > 50 && dataTempY > 50){
                                dataTempX = 50+(int)((dataTempX-50)/(double)maxRatio);
                                dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                            }
                            if (dataTempX > 50 && dataTempY == 50){
                                dataTempX = 50;
                                dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                            }
                            if (dataTempX < 50 && dataTempY > 50){
                                dataTempX = 50-(int)((50-dataTempX)/(double)maxRatio);
                                dataTempY = 50+(int)((dataTempY-50)/(double)maxRatio);
                            }
                            
                            snapDataRevised [snapDataRevisedCount] = dataTempX, snapDataRevisedCount++;
                            snapDataRevised [snapDataRevisedCount] = dataTempY, snapDataRevisedCount++;
                        }
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < snapDataCount/2; counter1++){
                            snapDataRevised [snapDataRevisedCount] = snapData [counter1*2], snapDataRevisedCount++;
                            snapDataRevised [snapDataRevisedCount] = snapData [counter1*2+1], snapDataRevisedCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < snapDataRevisedCount/2; counterA++){
                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<snapDataRevised [counterA*2+counterB];
                    //    cout<<" snapDataRevise "<<counterA<<endl;
                    //}
                    
                    int **duplicateRemoveMap = new int *[101];
                    for (int counter1 = 0; counter1 < 101; counter1++) duplicateRemoveMap [counter1] = new int [101];
                    
                    for (int counterY = 0; counterY < 101; counterY++){
                        for (int counterX = 0; counterX < 101; counterX++) duplicateRemoveMap [counterY][counterX] = 0;
                    }
                    
                    int tempX = 0;
                    int tempY = 0;
                    
                    for (int counter1 = 0; counter1 < snapDataRevisedCount/2; counter1++){
                        tempX = snapDataRevised [counter1*2];
                        tempY = snapDataRevised [counter1*2+1];
                        
                        if (tempX < 0) tempX = 0;
                        if (tempX > 100) tempX = 100;
                        if (tempY < 0) tempY = 0;
                        if (tempY > 100) tempY = 100;
                        
                        duplicateRemoveMap [tempY][tempX] = 1;
                    }
                    
                    //for (int counterA = 0; counterA < 100; counterA++){
                    //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<duplicateRemoveMap [counterA][counterB];
                    //    cout<<" duplicateRemoveMap "<<counterA<<endl;
                    //}
                    
                    if (snapDataRevisedCount+50 > 1000){
                        delete [] arrayMitosisRefData;
                        arrayMitosisRefData = new int [snapDataRevisedCount+50];
                    }
                    
                    for (int counterY = 0; counterY < 101; counterY++){
                        for (int counterX = 0; counterX < 101; counterX++){
                            if (duplicateRemoveMap [counterY][counterX] == 1){
                                arrayMitosisRefData [mitosisRefDataCount] = counterX, mitosisRefDataCount++;
                                arrayMitosisRefData [mitosisRefDataCount] = counterY, mitosisRefDataCount++;
                            }
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < 101; counter1++) delete [] duplicateRemoveMap [counter1];
                    delete [] duplicateRemoveMap;
                    
                    delete [] snapDataRevised;
                }
            }
            
            delete [] arrayNewLines;
        }
        
        delete [] connectAnalysisX;
        delete [] connectAnalysisY;
        delete [] connectAnalysisTempX;
        delete [] connectAnalysisTempY;
        
        for (int counter1 = 0; counter1 < dimension+4; counter1++){
            delete [] connectivityMapCut7 [counter1];
            delete [] connectivityMapCut6 [counter1];
            delete [] connectivityMapCut5 [counter1];
            delete [] connectivityMapCut4 [counter1];
            delete [] connectivityUpdate5 [counter1];
        }
        
        delete [] connectivityMapCut7;
        delete [] connectivityMapCut6;
        delete [] connectivityMapCut5;
        delete [] connectivityMapCut4;
        delete [] connectivityUpdate5;
        
        int numberOfEntry = 0;
        
        if (mitosisRefDataCount != 0){
            numberOfEntry = mitosisRefDataCount/2;
            
            for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                targetMitosisMap[arrayMitosisRefData [counter1*2+1]][arrayMitosisRefData [counter1*2]] = 1;
            }
            
            //for (int counterA = 0; counterA < 100; counterA++){
            //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<targetMitosisMap [counterA][counterB];
            //    cout<<" targetMitosisMap "<<counterA<<endl;
            //}
            
            double *constA = new double [numberOfEntry+5];
            double *constB = new double [numberOfEntry+5];
            double *distanceTarget = new double [numberOfEntry+5];
            int *xDirection = new int [numberOfEntry+5];
            int *yDirection = new int [numberOfEntry+5];
            int *xDistance = new int [numberOfEntry+5];
            int *yDistance = new int [numberOfEntry+5];
            
            for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                constA [counter1] = 0;
                constB [counter1] = 0;
                xDirection [counter1] = 0;
                yDirection [counter1] = 0;
                distanceTarget [counter1] = 0;
                xDistance [counter1] = 0;
                yDistance [counter1] = 0;
            }
            
            int dataTempX = 0;
            int dataTempY = 0;
            
            double constTempA = 0;
            double constTempB = 0;
            
            for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
                dataTempX = arrayMitosisRefData [counter1*2];
                dataTempY = arrayMitosisRefData [counter1*2+1];
                distanceTarget [counter1] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                
                if (dataTempX != 50){
                    constTempA = (50-dataTempY)/(double)(50-dataTempX);
                    constTempB = 50-constTempA*50;
                    constA [counter1] = constTempA;
                    constB [counter1] = constTempB;
                    
                    if (constTempB == 50 && dataTempX > 50){
                        xDirection [counter1] = 1;
                        yDirection [counter1] = 0;
                        xDistance [counter1] = dataTempX-50;
                        yDistance [counter1] = 0;
                    }
                    else if (constTempB == 50 && dataTempX < 50){
                        xDirection [counter1] = -1;
                        yDirection [counter1] = 0;
                        xDistance [counter1] = 50-dataTempX;
                        yDistance [counter1] = 0;
                    }
                    else if (constTempB != 50 && dataTempX > 50 && dataTempY > 50){
                        xDirection [counter1] = 1;
                        yDirection [counter1] = 1;
                        xDistance [counter1] = dataTempX-50;
                        yDistance [counter1] = dataTempY-50;
                    }
                    else if (constTempB != 50 && dataTempX < 50 && dataTempY > 50){
                        xDirection [counter1] = -1;
                        yDirection [counter1] = 1;
                        xDistance [counter1] = 50-dataTempX;
                        yDistance [counter1] = dataTempY-50;
                    }
                    else if (constTempB != 50 && dataTempX > 50 && dataTempY < 50){
                        xDirection [counter1] = 1;
                        yDirection [counter1] = -1;
                        xDistance [counter1] = dataTempX-50;
                        yDistance [counter1] = 50-dataTempY;
                    }
                    else if (constTempB != 50 && dataTempX < 50 && dataTempY < 50){
                        xDirection [counter1] = -1;
                        yDirection [counter1] = -1;
                        xDistance [counter1] = 50-dataTempX;
                        yDistance [counter1] = 50-dataTempY;
                    }
                }
                else{
                    
                    if (dataTempY < 50){
                        xDirection [counter1] = 0;
                        yDirection [counter1] = -1;
                        xDistance [counter1] = 0;
                        yDistance [counter1] = 50-dataTempY;
                    }
                    else if (dataTempY > 50){
                        xDirection [counter1] = 0;
                        yDirection [counter1] = 1;
                        xDistance [counter1] = 0;
                        yDistance [counter1] = dataTempY-50;
                    }
                }
            }
            
            //for (int counter1 = 0; counter1 < numberOfEntry; counter1++){
            //    cout<<counter1<<" Dis "<<distanceTarget [counter1]<<" CA "<<constA [counter1]<<" CB "<<constB [counter1]<<endl;
            //    cout<<" xDir "<<xDirection [counter1]<<" yDir "<<yDirection [counter1]<<" xDis "<<xDistance [counter1]<<" yDis "<<yDistance [counter1]<<endl;
            //}
            
            //-----Mitosis Pattern Data Read-----
            string mitosisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/"+"Mitosis.dat";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(mitosisPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            ifstream fin;
            
            int *arrayMitosisPattern = new int [sizeForCopy+50];
            int mitosisPatternCount = 0;
            int lastPatternNumber = 0;
            
            fin.open(mitosisPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                int finData [8];
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--2. Entry No
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--5. X Position
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [5] = finData [4]*256+finData [5];
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                        else{
                            
                            arrayMitosisPattern [mitosisPatternCount] = finData [1], mitosisPatternCount++;
                            arrayMitosisPattern [mitosisPatternCount] = finData [3], mitosisPatternCount++;
                            arrayMitosisPattern [mitosisPatternCount] = finData [5], mitosisPatternCount++;
                            arrayMitosisPattern [mitosisPatternCount] = finData [7], mitosisPatternCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                lastPatternNumber = arrayMitosisPattern [(mitosisPatternCount/4-1)*4];
                
                delete [] uploadTemp;
            }
            
            double *distanceReference = new double [numberOfEntry+5];
            double *matchTagSD = new double [lastPatternNumber+1];
            double *matchRefSD = new double [lastPatternNumber+1];
            double *averageTag = new double [lastPatternNumber+1];
            double *averageRef = new double [lastPatternNumber+1];
            double *areaHold = new double [lastPatternNumber+1];
            
            for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                matchTagSD [counter1] = 0;
                matchRefSD [counter1] = 0;
                averageTag [counter1] = 0;
                averageRef [counter1] = 0;
            }
            
            int refEntryNumber = 0;
            int areaSize = 0;
            int entryRefCount = 0;
            double totalValue = 0;
            double totalForSD = 0;
            double constTempRefA = 0;
            double constTempRefB = 0;
            double distanceReferenceTemp = 0;
            double averageTagTemp = 0;
            double matchTagSDTemp = 0;
            double distanceEachToTargetTemp = 0;
            double averageRefTemp = 0;
            double matchRefSDTemp = 0;
            
            //-----SD determination-----
            for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                for (int counterX = 0; counterX < 100; counterX++){
                    for (int counterY = 0; counterY < 100; counterY++) referenceMap[counterX][counterY] = 0;
                }
                
                refEntryNumber = 0;
                areaSize = 0;
                
                for (int counter2 = 0; counter2 < mitosisPatternCount/4; counter2++){
                    if (counter1 == arrayMitosisPattern [counter2*4]){
                        referenceMap[arrayMitosisPattern [counter2*4+2]][arrayMitosisPattern [counter2*4+1]] = 1;
                        refEntryNumber++;
                        
                        areaSize = arrayMitosisPattern [counter2*4+3];
                    }
                }
                
                areaHold [counter1] = areaSize;
                
                //for (int counterA = 0; counterA < 100; counterA++){
                //    for (int counterB = 0; counterB < 100; counterB++) cout<<" "<<referenceMap [counterA][counterB];
                //    cout<<" referenceMap "<<counterA<<endl;
                //}
                
                //-----TARG to REF-----
                for (int counter2 = 0; counter2 < numberOfEntry; counter2++) distanceReference [counter2] = 0;
                
                for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                    findFlag = 0;
                    
                    if (xDirection [counter2] == 0 && yDirection [counter2] == 1){
                        for (int counter3 = 51; counter3 < 99; counter3++){
                            if (referenceMap[counter3][50] == 1){
                                distanceReference [counter2] = counter3-50;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (referenceMap[counter3][49] == 1) findFlag = 1;
                                else if (referenceMap[counter3][51] == 1) findFlag = 1;
                                else if (referenceMap[counter3+1][50] == 1) findFlag = 1;
                                else if (referenceMap[counter3-1][50] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceReference [counter2] = counter3-50;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceReference [counter2] = 50;
                    }
                    else if (xDirection [counter2] == 0 && yDirection [counter2] == -1){
                        for (int counter3 = 49; counter3 > 0; counter3--){
                            if (referenceMap[counter3][50] == 1){
                                distanceReference [counter2] = 50-counter3;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (referenceMap[counter3][49] == 1) findFlag = 1;
                                else if (referenceMap[counter3][51] == 1) findFlag = 1;
                                else if (referenceMap[counter3-1][50] == 1) findFlag = 1;
                                else if (referenceMap[counter3+1][50] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceReference [counter2] = 50-counter3;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceReference [counter2] = 50;
                    }
                    else if (xDirection [counter2] == 1 && yDirection [counter2] == 0){
                        for (int counter3 = 51; counter3 < 99; counter3++){
                            if (referenceMap[50][counter3] == 1){
                                distanceReference [counter2] = counter3-50;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (referenceMap[49][counter3] == 1) findFlag = 1;
                                else if (referenceMap[51][counter3] == 1) findFlag = 1;
                                else if (referenceMap[50][counter3-1] == 1) findFlag = 1;
                                else if (referenceMap[50][counter3+1] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceReference [counter2] = counter3-50;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceReference [counter2] = 50;
                    }
                    else if (xDirection [counter2] == -1 && yDirection [counter2] == 0){
                        for (int counter3 = 49; counter3 > 0; counter3--){
                            if (referenceMap[50][counter3] == 1){
                                distanceReference [counter2] = 50-counter3;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (referenceMap[49][counter3] == 1) findFlag = 1;
                                else if (referenceMap[51][counter3] == 1) findFlag = 1;
                                else if (referenceMap[50][counter3-1] == 1) findFlag = 1;
                                else if (referenceMap[50][counter3+1] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceReference [counter2] = 50-counter3;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceReference [counter2] = 50;
                    }
                    else if (xDirection [counter2] == 1 && yDirection [counter2] == 1){
                        constTempA = constA [counter2];
                        constTempB = constB [counter2];
                        
                        if (xDistance [counter2] > yDistance [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempA*dataTempX+constTempB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" ++XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS1++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" ++XY-A  "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS2++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        
                        if (xDistance [counter2] <= yDistance [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" ++XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS3++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" ++XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS4++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                    }
                    else if (xDirection [counter2] == 1 && yDirection [counter2] == -1){
                        constTempA = constA [counter2];
                        constTempB = constB [counter2];
                        
                        //cout<<constTempA<<" "<<constTempB<<" CONSTAB+- "<<xDistance [counter2]<<" "<<yDistance [counter2]<<endl;
                        
                        if (xDistance [counter2] > yDistance [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempA*dataTempX+constTempB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS5++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS6++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        
                        if (xDistance [counter2] <= yDistance [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                
                                //cout<<counter3<<" "<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS7++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS8++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                    }
                    else if (xDirection [counter2] == -1 && yDirection [counter2] == 1){
                        constTempA = constA [counter2];
                        constTempB = constB [counter2];
                        
                        //cout<<constTempA<<" "<<constTempB<<" CONSTAB-+ "<<xDistance [counter2]<<" "<<yDistance [counter2]<<endl;
                        
                        if (xDistance [counter2] > yDistance [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempA*dataTempX+constTempB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" -+XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS9++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                
                                //cout<<"redo-+"<<endl;
                                
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS10++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        
                        if (xDistance [counter2] <= yDistance [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" -+XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS11++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            //cout<<findFlag<<" findFlag"<<endl;
                            
                            if (findFlag == 0){
                                
                                //cout<<"redo-+"<<endl;
                                
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS12++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                    }
                    else if (xDirection [counter2] == -1 && yDirection [counter2] == -1){
                        constTempA = constA [counter2];
                        constTempB = constB [counter2];
                        
                        //cout<<constTempA<<" "<<constTempB<<" CONSTAB-- "<<xDistance [counter2]<<" "<<yDistance [counter2]<<endl;
                        
                        if (xDistance [counter2] > yDistance [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempA*dataTempX+constTempB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" --XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS13++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempA*dataTempX+constTempB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS14++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                        
                        if (xDistance [counter2] <= yDistance [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" --XY-B "<<referenceMap[dataTempY][dataTempX]<<endl;
                                
                                if (referenceMap[dataTempY][dataTempX] == 1){
                                    distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS15++ "<<distanceReference [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempB)/(double)constTempA);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<referenceMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (referenceMap[dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (referenceMap[dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    //cout<<referenceMap[dataTempY-1][dataTempX]<<" "<<referenceMap[dataTempY+1][dataTempX]<<" "<<referenceMap[dataTempY][dataTempX-1]<<" "<<referenceMap[dataTempY][dataTempX+1]<<" nnnn--"<<endl;
                                    
                                    if (findFlag == 1){
                                        distanceReference [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS16++ "<<distanceReference [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceReference [counter2] = 50;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < numberOfEntry; counterA++){
                //	cout<<counterA<<" DisRef "<<distanceReference [counterA]<<" disTarg "<<distanceTarget [counterA]<<endl;
                //}
                
                for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                    if (distanceTarget [counter2] != 0){
                        distanceReferenceTemp = distanceReference [counter2]/(double)distanceTarget [counter2];
                        distanceReference [counter2] = distanceReferenceTemp;
                    }
                    
                    //cout<<counter2<<" DisRef "<<distanceReference [counter2]<<endl;
                }
                
                totalValue = 0;
                totalForSD = 0;
                
                for (int counter2 = 0; counter2 < numberOfEntry; counter2++) totalValue = totalValue+distanceReference [counter2];
                
                averageTagTemp = totalValue/(double)numberOfEntry;
                averageTag [counter1] = averageTagTemp;
                
                //cout<<"average "<<averageTag [counter1]<<" "<<numberOfEntry<<endl;
                
                for (int counter2 = 0; counter2 < numberOfEntry; counter2++){
                    totalForSD = totalForSD+(averageTag [counter1]-distanceReference [counter2])*(averageTag [counter1]-distanceReference [counter2]);
                }
                
                matchTagSDTemp = sqrt(totalForSD/((double)(numberOfEntry-1)));
                matchTagSD [counter1] = matchTagSDTemp;
                
                //cout<<sqrt(totalForSD/((double)(numberOfEntry-1)))<<" "<<counter1<<" SD"<<endl;
                
                //-----REF TO TARG-----
                double *constRefA = new double [refEntryNumber+1];
                double *constRefB = new double [refEntryNumber+1];
                double *distanceEachRef = new double [refEntryNumber+1];
                int *xDirectionRef = new int [refEntryNumber+1];
                int *yDirectionRef = new int [refEntryNumber+1];
                int *xDistanceRef = new int [refEntryNumber+1];
                int *yDistanceRef = new int [refEntryNumber+1];
                
                for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    constRefA [counter2] = 0;
                    constRefB [counter2] = 0;
                    xDirectionRef [counter2] = 0;
                    yDirectionRef [counter2] = 0;
                    distanceEachRef [counter2] = 0;
                    xDistanceRef [counter2] = 0;
                    yDistanceRef [counter2] = 0;
                }
                
                entryRefCount = 0;
                
                for (int counter2 = 0; counter2 < mitosisPatternCount/4; counter2++){
                    if (counter1 == arrayMitosisPattern [counter2*4]){
                        dataTempX = arrayMitosisPattern [counter2*4+1];
                        dataTempY = arrayMitosisPattern [counter2*4+2];
                        distanceEachRef [entryRefCount] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                        
                        if (dataTempX != 50){
                            constTempRefA = (50-dataTempY)/(double)(50-dataTempX);
                            constTempRefB = 50-constTempRefA*50;
                            constRefA [entryRefCount] = constTempRefA;
                            constRefB [entryRefCount] = constTempRefB;
                            
                            if (constTempRefB == 50 && dataTempX > 50){
                                xDirectionRef [entryRefCount] = 1;
                                yDirectionRef [entryRefCount] = 0;
                                xDistanceRef [entryRefCount] = dataTempX-50;
                                yDistanceRef [entryRefCount] = 0;
                            }
                            if (constTempRefB == 50 && dataTempX < 50){
                                xDirectionRef [entryRefCount] = -1;
                                yDirectionRef [entryRefCount] = 0;
                                xDistanceRef [entryRefCount] = 50-dataTempX;
                                yDistanceRef [entryRefCount] = 0;
                            }
                            if (constTempRefB != 50 && dataTempX > 50 && dataTempY > 50){
                                xDirectionRef [entryRefCount] = 1;
                                yDirectionRef [entryRefCount] = 1;
                                xDistanceRef [entryRefCount] = dataTempX-50;
                                yDistanceRef [entryRefCount] = dataTempY-50;
                            }
                            if (constTempRefB != 50 && dataTempX < 50 && dataTempY > 50){
                                xDirectionRef [entryRefCount] = -1;
                                yDirectionRef [entryRefCount] = 1;
                                xDistanceRef [entryRefCount] = 50-dataTempX;
                                yDistanceRef [entryRefCount] = dataTempY-50;
                            }
                            if (constTempRefB != 50 && dataTempX > 50 && dataTempY < 50){
                                xDirectionRef [entryRefCount] = 1;
                                yDirectionRef [entryRefCount] = -1;
                                xDistanceRef [entryRefCount] = dataTempX-50;
                                yDistanceRef [entryRefCount] = 50-dataTempY;
                            }
                            if (constTempRefB != 50 && dataTempX < 50 && dataTempY < 50){
                                xDirectionRef [entryRefCount] = -1;
                                yDirectionRef [entryRefCount] = -1;
                                xDistanceRef [entryRefCount] = 50-dataTempX;
                                yDistanceRef [entryRefCount] = 50-dataTempY;
                            }
                        }
                        else{
                            
                            if (dataTempY < 50){
                                xDirectionRef [entryRefCount] = 0;
                                yDirectionRef [entryRefCount] = -1;
                                xDistanceRef [entryRefCount] = 0;
                                yDistanceRef [entryRefCount] = 50-dataTempY;
                            }
                            if (dataTempY > 50){
                                xDirectionRef [entryRefCount] = 0;
                                yDirectionRef [entryRefCount] = 1;
                                xDistanceRef [entryRefCount] = 0;
                                yDistanceRef [entryRefCount] = dataTempY-50;
                            }
                        }
                        
                        entryRefCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < refEntryNumber; counterA++){
                //	cout<<counterA<<" DisRef "<<distanceEachRef [counterA]<<" CA "<<constRefA [counterA]<<" cB "<<constRefB [counterA]<<" xDir "<<xDirectionRef [counterA]<<" yDir "<<yDirectionRef [counterA] <<" xDis "<<xDistanceRef [counterA]<<" yDis "<<yDistanceRef [counterA]<<endl;
                //}
                
                double *distanceEachToTarget = new double [refEntryNumber+5];
                
                for (int counter2 = 0; counter2 < refEntryNumber; counter2++) distanceEachToTarget [counter2] = 0;
                
                for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    findFlag = 0;
                    
                    if (xDirectionRef [counter2] == 0 && yDirectionRef [counter2] == 1){
                        for (int counter3 = 51; counter3 < 99; counter3++){
                            if (targetMitosisMap [counter3][50] == 1){
                                distanceEachToTarget [counter2] = counter3-50;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (targetMitosisMap [counter3][49] == 1) findFlag = 1;
                                else if (targetMitosisMap [counter3][51] == 1) findFlag = 1;
                                else if (targetMitosisMap [counter3+1][50] == 1) findFlag = 1;
                                else if (targetMitosisMap [counter3-1][50] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceEachToTarget [counter2] = counter3-50;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                    }
                    else if (xDirectionRef [counter2] == 0 && yDirectionRef [counter2] == -1){
                        for (int counter3 = 49; counter3 > 0; counter3--){
                            if (targetMitosisMap [counter3][50] == 1){
                                distanceEachToTarget [counter2] = 50-counter3;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (targetMitosisMap [counter3][49] == 1) findFlag = 1;
                                else if (targetMitosisMap [counter3][51] == 1) findFlag = 1;
                                else if (targetMitosisMap [counter3-1][50] == 1) findFlag = 1;
                                else if (targetMitosisMap [counter3+1][50] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceEachToTarget [counter2] = 50-counter3;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                    }
                    else if (xDirectionRef [counter2] == 1 && yDirectionRef [counter2] == 0){
                        for (int counter3 = 51; counter3 < 99; counter3++){
                            if (targetMitosisMap [50][counter3] == 1){
                                distanceEachToTarget [counter2] = counter3-50;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                if (targetMitosisMap [49][counter3] == 1) findFlag = 1;
                                else if (targetMitosisMap [51][counter3] == 1) findFlag = 1;
                                else if (targetMitosisMap [50][counter3-1] == 1) findFlag = 1;
                                else if (targetMitosisMap [50][counter3+1] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceEachToTarget [counter2] = counter3-50;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                    }
                    else if (xDirectionRef [counter2] == -1 && yDirectionRef [counter2] == 0){
                        for (int counter3 = 49; counter3 > 0; counter3--){
                            if (targetMitosisMap [50][counter3] == 1){
                                distanceEachToTarget [counter2] = 50-counter3;
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 0){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                if (targetMitosisMap [49][counter3] == 1) findFlag = 1;
                                else if (targetMitosisMap [51][counter3] == 1) findFlag = 1;
                                else if (targetMitosisMap [50][counter3-1] == 1) findFlag = 1;
                                else if (targetMitosisMap [50][counter3+1] == 1) findFlag = 1;
                                
                                if (findFlag == 1){
                                    distanceEachToTarget [counter2] = 50-counter3;
                                    break;
                                }
                            }
                        }
                        
                        if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                    }
                    else if (xDirectionRef [counter2] == 1 && yDirectionRef [counter2] == 1){
                        constTempRefA = constRefA [counter2];
                        constTempRefB = constRefB [counter2];
                        
                        if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" ++XY-A "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS1++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS2++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        
                        if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" ++XY-B "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS3++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS4++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                    }
                    else if (xDirectionRef [counter2] == 1 && yDirectionRef [counter2] == -1){
                        constTempRefA = constRefA [counter2];
                        constTempRefB = constRefB [counter2];
                        
                        //cout<<constTempRefA<<" "<<constTempRefB<<" CONSTAB+- "<<xDistanceRef [counter2]<<" "<<yDistanceRef [counter2]<<endl;
                        
                        if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" +-XY-A "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS5++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    //cout<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS6++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        
                        if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" +-XY-B "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS7++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS8++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                    }
                    else if (xDirectionRef [counter2] == -1 && yDirectionRef [counter2] == 1){
                        constTempRefA = constRefA [counter2];
                        constTempRefB = constRefB [counter2];
                        
                        //cout<<constTempRefA<<" "<<constTempRefB<<" CONSTAB-+ "<<xDistanceRef [counter2]<<" "<<yDistanceRef [counter2]<<endl;
                        
                        if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" -+XY-A "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS9++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                
                                //cout<<"redo-+"<<endl;
                                
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS10++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        
                        if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                            for (int counter3 = 51; counter3 < 99; counter3++){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" -+XY-B "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS11++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            //cout<<findFlag<<" findFlag"<<endl;
                            
                            if (findFlag == 0){
                                
                                //cout<<"redo-+"<<endl;
                                
                                for (int counter3 = 51; counter3 < 99; counter3++){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS12++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                    }
                    else if (xDirectionRef [counter2] == -1 && yDirectionRef [counter2] == -1){
                        constTempRefA = constRefA [counter2];
                        constTempRefB = constRefB [counter2];
                        
                        //cout<<constTempRefA<<" "<<constTempRefB<<" CONSTAB-- "<<xDistanceRef [counter2]<<" "<<yDistanceRef [counter2]<<endl;
                        
                        if (xDistanceRef [counter2] > yDistanceRef [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempX = counter3;
                                dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" --XY-A "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS13++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempX = counter3;
                                    dataTempY = (int)(constTempRefA*dataTempX+constTempRefB);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS14++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                        
                        if (xDistanceRef [counter2] <= yDistanceRef [counter2]){
                            for (int counter3 = 49; counter3 > 0; counter3--){
                                dataTempY = counter3;
                                dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                
                                //cout<<dataTempX<<" "<<dataTempY<<" --XY-B "<<targetMitosisMap[dataTempY][dataTempX]<<endl;
                                
                                if (targetMitosisMap [dataTempY][dataTempX] == 1){
                                    distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                    findFlag = 1;
                                    
                                    //cout<<"DIS15++ "<<distanceEachToTarget [counter2]<<endl;
                                    
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                for (int counter3 = 49; counter3 > 0; counter3--){
                                    dataTempY = counter3;
                                    dataTempX = (int)((dataTempY-constTempRefB)/(double)constTempRefA);
                                    
                                    if (targetMitosisMap [dataTempY-1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY+1][dataTempX] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX-1] == 1) findFlag = 1;
                                    else if (targetMitosisMap [dataTempY][dataTempX+1] == 1) findFlag = 1;
                                    
                                    if (findFlag == 1){
                                        distanceEachToTarget [counter2] = sqrt((50-dataTempX)*(50-dataTempX)+(50-dataTempY)*(50-dataTempY));
                                        
                                        //cout<<"DIS16++ "<<distanceEachToTarget [counter2]<<endl;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (findFlag == 0) distanceEachToTarget [counter2] = 50;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < refEntryNumber; counterA++){
                //	cout<<counterA<<" DisRef2 "<<distanceEachRef [counterA]<<" disToTarg "<<distanceEachToTarget [counterA]<<endl;
                //}
                
                for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    if (distanceEachRef [counter2] != 0){
                        distanceEachToTargetTemp = distanceEachToTarget [counter2]/(double)distanceEachRef [counter2];
                        distanceEachToTarget [counter2] = distanceEachToTargetTemp;
                        
                        //cout<<counter2<<" DisRef3 "<<distanceEachToTarget [counter2]<<endl;
                    }
                }
                
                totalValue = 0;
                totalForSD = 0;
                
                for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    totalValue = totalValue+distanceEachToTarget [counter2];
                    
                    //cout<<counter2<<" totalValTarg "<<totalValue<<endl;
                }
                
                averageRefTemp = totalValue/(double)refEntryNumber;
                averageRef [counter1] = averageRefTemp;
                
                //cout<<"averageRef "<<averageRef[counter1]<<endl;
                
                for (int counter2 = 0; counter2 < refEntryNumber; counter2++){
                    totalForSD = totalForSD+(averageRef[counter1]-distanceEachToTarget [counter2])*(averageRef[counter1]-distanceEachToTarget [counter2]);
                }
                
                matchRefSDTemp = sqrt(totalForSD/((double)(refEntryNumber-1)));
                matchRefSD [counter1] = matchRefSDTemp;
                
                //cout<<"matchRefSD "<<sqrt(totalForSD/((double)(refEntryNumber-1)))<<endl;
                
                delete [] distanceEachToTarget;
                delete [] constRefA;
                delete [] constRefB;
                delete [] distanceEachRef;
                delete [] xDirectionRef;
                delete [] yDirectionRef;
                delete [] xDistanceRef;
                delete [] yDistanceRef;
            }
            
            delete [] constA;
            delete [] constB;
            delete [] distanceTarget;
            delete [] xDirection;
            delete [] yDirection;
            delete [] xDistance;
            delete [] yDistance;
            
            delete [] arrayMitosisPattern;
            
            //-----Return SD determination-----
            double *resultsSD = new double [lastPatternNumber+1];
            double *resultsAverage = new double [lastPatternNumber+1];
            
            for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                resultsSD [counter1] = 0;
                resultsAverage [counter1] = 0;
            }
            
            for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                //cout<<counter1<<" "<<matchRefSD [counter1]<<" "<<matchTagSD [counter1]<<" "<<averageRef [counter1]<<" "<<averageTag [counter1]<<" avSDResult"<<endl;
                
                if (matchRefSD [counter1] != 0 && matchTagSD [counter1] != 0){
                    if (matchRefSD [counter1] < matchTagSD [counter1]){
                        resultsSD [counter1] = matchRefSD [counter1];
                        resultsAverage [counter1] = averageRef [counter1];
                    }
                    else{
                        
                        resultsSD [counter1] = matchTagSD [counter1];
                        resultsAverage [counter1] = averageTag [counter1];
                    }
                }
            }
            
            double resultsSDWithArea = 1000;
            
            for (int counter1 = 1; counter1 < lastPatternNumber+1; counter1++){
                //cout<<sourceAreaSize<<" "<<areaHold [counter1]<<" "<<areaHold [counter1]*1.5<<" "<<areaHold [counter1]*0.75<<" finalA"<<endl;
                //cout<<resultsAverage [counter1]<<" "<<resultsSD [counter1]<<" final"<<endl;
                
                if (sourceAreaSize < areaHold [counter1]*2 && sourceAreaSize > areaHold [counter1]*0.5){
                    if (resultsAverage [counter1] < 1.25 && resultsAverage [counter1] > 0.75){
                        if (resultsSD [counter1] < resultsSDWithArea) resultsSDWithArea = resultsSD [counter1];
                    }
                }
            }
            
            if (resultsSDWithArea == 1000) returnSD = 1000;
            else returnSD = resultsSDWithArea;
            
            //cout<<returnSD<<" RetSD"<<endl;
            
            delete [] distanceReference;
            delete [] matchTagSD;
            delete [] matchRefSD;
            delete [] averageTag;
            delete [] averageRef;
            delete [] resultsSD;
            delete [] resultsAverage;
            delete [] areaHold;
        }
    }
    
    for (int counter1 = 0; counter1 < 101; counter1++){
        delete [] referenceMap [counter1];
        delete [] targetMitosisMap[counter1];
    }
    
    delete [] referenceMap;
    delete [] targetMitosisMap;
    
    delete [] snapData;
    delete [] arrayMitosisRefData;
    
    return returnSD; //-----Positive, non-cell death, negative cell death-----
}

@end
