//
// LineSet.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 06/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "LineSet.h"

@implementation LineSet

-(void)lineSetProcess:(int)processType{
    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
    //	cout<<" arrayEventSequence "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
    //	cout<<" arrayLineageGRCurrent "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionReviseSet "<<counterA<<endl;
    //}
    
    if (lineDraw == 1){
        int processingFlag = 0;
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            if (arrayQueueList [counter1*6+1] == cellLineageNoHold && arrayQueueList [counter1*6+5] == "Proc"){
                processingFlag = 1;
                break;
            }
        }
        
        if (processingFlag == 0){
            int counterMax = 0;
            
            if (processType == 1) counterMax = targetCount/2;
            else if (processType == 2 || processType == 3 || processType == 4) counterMax = referenceLineCount/2;
            
            //-----Duplicate remove-----
            int *duplicateFind = new int [counterMax+1];
            int *arrayTargetTemp1 = new int [counterMax*2+1];
            
            for (int counter1 = 0; counter1 < counterMax; counter1++) duplicateFind [counter1] = 0;
            
            int targetTempCount1 = 0;
            int neighborCount = 0;
            
            if (processType == 1){
                int xPosition;
                int yPosition;
                
                for (int counter1 = 0; counter1 < counterMax-1; counter1++){
                    if (duplicateFind [counter1] == 0){
                        xPosition = arrayTarget [counter1*2];
                        yPosition = arrayTarget [counter1*2+1];
                    }
                    
                    for (int counter2 = counter1+1; counter2 < counterMax; counter2++){
                        if (xPosition == arrayTarget [counter2*2] && yPosition == arrayTarget [counter2*2+1]) duplicateFind [counter2] = 1;
                    }
                }
                
                targetTempCount1 = 0;
                
                for (int counter1 = 0; counter1 < counterMax; counter1++){
                    if (duplicateFind [counter1] == 0){
                        arrayTargetTemp1 [targetTempCount1] = arrayTarget [counter1*2], targetTempCount1++;
                        arrayTargetTemp1 [targetTempCount1] = arrayTarget [counter1*2+1], targetTempCount1++;
                    }
                }
            }
            
            if (processType == 2 || processType == 3 || processType == 4){
                targetTempCount1 = 0;
                
                for (int counter1 = 0; counter1 < counterMax; counter1++){
                    arrayTargetTemp1 [targetTempCount1] = arrayReferenceLine [counter1*2], targetTempCount1++;
                    arrayTargetTemp1 [targetTempCount1] = arrayReferenceLine [counter1*2+1], targetTempCount1++;
                }
            }
            
            delete [] duplicateFind;
            
            //for (int counterA = 0; counterA < targetTempCount1/2; counterA++){
            //    cout<<arrayTargetTemp1 [counterA*2]<<" "<<arrayTargetTemp1 [counterA*2+1]<<" DuplicateRemove"<<endl;
            //}
            
            if (targetTempCount1/2 > 5){ //-----Remove less than 5 points-----
                int firstSet = 0;
                
                targetGapFill = new int [targetTempCount1*2+1];
                targetGapFillCount = 0;
                targetGapFillLimit = targetTempCount1*2+1;
                
                //-----Gap Fill-----
                int xPosition = 0;
                int yPosition = 0;
                int xPositionNext = 0;
                int yPositionNext = 0;
                
                for (int counter1 = 0; counter1 < targetTempCount1/2-1; counter1++){
                    if (firstSet == 0 && arrayTargetTemp1 [counter1*2] >= 0 && arrayTargetTemp1 [counter1*2] < imageDimension && arrayTargetTemp1 [counter1*2+1] >= 0 && arrayTargetTemp1 [counter1*2+1] < imageDimension){
                        targetGapFill [targetGapFillCount] = arrayTargetTemp1 [counter1*2], targetGapFillCount++;
                        targetGapFill [targetGapFillCount] = arrayTargetTemp1 [counter1*2+1], targetGapFillCount++;
                        firstSet = 1;
                    }
                    
                    if (firstSet == 1){
                        xPosition = arrayTargetTemp1 [counter1*2];
                        yPosition = arrayTargetTemp1 [counter1*2+1];
                        xPositionNext = arrayTargetTemp1 [(counter1+1)*2];
                        yPositionNext = arrayTargetTemp1 [(counter1+1)*2+1];
                        
                        if (xPositionNext < 0 || xPositionNext >= imageDimension || yPositionNext < 0 || yPositionNext >= imageDimension){
                            break;
                        }
                        
                        neighborCount = 0;
                        
                        if (xPosition-1 == xPositionNext && yPosition-1 == yPositionNext) neighborCount++;
                        else if (xPosition == xPositionNext && yPosition-1 == yPositionNext) neighborCount++;
                        else if (xPosition+1 == xPositionNext && yPosition-1 == yPositionNext) neighborCount++;
                        else if (xPosition+1 == xPositionNext && yPosition == yPositionNext) neighborCount++;
                        else if (xPosition+1 == xPositionNext && yPosition+1 == yPositionNext) neighborCount++;
                        else if (xPosition == xPositionNext && yPosition+1 == yPositionNext) neighborCount++;
                        else if (xPosition-1 == xPositionNext && yPosition+1 == yPositionNext) neighborCount++;
                        else if (xPosition-1 == xPositionNext && yPosition == yPositionNext) neighborCount++;
                        
                        if (neighborCount == 0){
                            arrayGapData = new int [500];
                            gapDataCount = 0;
                            gapDataLimit = 0;
                            
                            id gapFill = [[GapFill alloc] init];
                            [gapFill gapFilling:xPosition:yPosition:xPositionNext:yPositionNext];
                            
                            if (targetGapFillCount+gapDataCount+2 > targetGapFillLimit) targetGapFillAddition = gapDataCount+2, [self gapFillUpdate];
                            
                            for (int counter2 = 0; counter2 < gapDataCount/2; counter2++){
                                targetGapFill [targetGapFillCount] = arrayGapData [counter2*2], targetGapFillCount++;
                                targetGapFill [targetGapFillCount] = arrayGapData [counter2*2+1], targetGapFillCount++;
                            }
                            
                            delete [] arrayGapData;
                            
                            targetGapFill [targetGapFillCount] = xPositionNext, targetGapFillCount++;
                            targetGapFill [targetGapFillCount] = yPositionNext, targetGapFillCount++;
                        }
                        else{
                            
                            if (targetGapFillCount+2 > targetGapFillLimit){
                                targetGapFillAddition = 2;
                                [self gapFillUpdate];
                            }
                            
                            targetGapFill [targetGapFillCount] = xPositionNext, targetGapFillCount++;
                            targetGapFill [targetGapFillCount] = yPositionNext, targetGapFillCount++;
                        }
                    }
                }
                
                int targetTempCount2 = 0;
                int *arrayTargetTemp2 = new int [targetGapFillCount+1];
                
                //for (int counterA = 0; counterA < counterMax; counterA++){
                //    cout<<targetGapFill [counterA*2]<<" "<<targetGapFill [counterA*2+1]<<" GapFilled"<<endl;
                //}
                
                //-----Cross point find, at least 15 apart-----
                if (targetGapFillCount/2 > 15){
                    neighborCount = 0;
                    int positionCountStart = 0;
                    int positionCountEnd = 0;
                    
                    for (int counter1 = 0; counter1 < targetGapFillCount/2-10; counter1++){
                        xPosition = targetGapFill [counter1*2];
                        yPosition = targetGapFill [counter1*2+1];
                        
                        for (int counter2 = counter1+10; counter2 < targetGapFillCount/2; counter2++){
                            xPositionNext = targetGapFill [counter2*2];
                            yPositionNext = targetGapFill [counter2*2+1];
                            
                            if (xPosition-1 == xPositionNext && yPosition-1 == yPositionNext) neighborCount++;
                            else if (xPosition == xPositionNext && yPosition-1 == yPositionNext) neighborCount++;
                            else if (xPosition+1 == xPositionNext && yPosition-1 == yPositionNext) neighborCount++;
                            else if (xPosition+1 == xPositionNext && yPosition == yPositionNext) neighborCount++;
                            else if (xPosition+1 == xPositionNext && yPosition+1 == yPositionNext) neighborCount++;
                            else if (xPosition == xPositionNext && yPosition+1 == yPositionNext) neighborCount++;
                            else if (xPosition-1 == xPositionNext && yPosition+1 == yPositionNext) neighborCount++;
                            else if (xPosition-1 == xPositionNext && yPosition == yPositionNext) neighborCount++;
                            
                            if (neighborCount > 0){
                                positionCountStart = counter1;
                                positionCountEnd = counter2;
                                break;
                            }
                        }
                        
                        if (neighborCount > 0){
                            break;
                        }
                    }
                    
                    if (neighborCount > 0){
                        if (targetGapFillCount+(positionCountEnd-positionCountStart)*2+2 > targetGapFillLimit){
                            targetGapFillAddition = (positionCountEnd-positionCountStart)*2+2+2;
                            [self gapFillUpdate];
                        }
                        
                        for (int counter1 = positionCountStart; counter1 <= positionCountEnd; counter1++){
                            arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2], targetTempCount2++;
                            arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2+1], targetTempCount2++;
                        }
                    }
                    else{
                        
                        if (targetGapFillCount+targetGapFillCount+2 > targetGapFillLimit){
                            targetGapFillAddition = targetGapFillCount+2;
                            [self gapFillUpdate];
                        }
                        
                        for (int counter1 = 0; counter1 < targetGapFillCount/2; counter1++){
                            arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2], targetTempCount2++;
                            arrayTargetTemp2 [targetTempCount2] = targetGapFill [counter1*2+1], targetTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < targetTempCount2/2; counterA++){
                    //    cout<<arrayTargetTemp2 [counterA*2]<<" "<<arrayTargetTemp2 [counterA*2+1]<<" GapFilled2"<<endl;
                    //}
                    
                    int linePointCount = targetTempCount2/2;
                    arrayLineDataProcessing = new int [targetTempCount2+50];
                    lineDataProcessingCount = 0;
                    
                    //-----Circle-----
                    if (neighborCount != 0 && linePointCount > 11){
                        int *lineTrimmingValue = new int [linePointCount+10];
                        int *lineTrimmingXY = new int [linePointCount*2+10];
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            lineTrimmingValue [counter1] = 0;
                            lineTrimmingXY [counter1*2] = arrayTargetTemp2 [counter1*2];
                            lineTrimmingXY [counter1*2+1] = arrayTargetTemp2 [counter1*2+1];
                        }
                        
                        int lineTrimmingX = 0;
                        int lineTrimmingY = 0;
                        int attachPoint = 0;
                        int countSave = 0;
                        int lineTrimmingX2 = 0;
                        int lineTrimmingY2 = 0;
                        
                        for (int counter1 = 0; counter1 < linePointCount-4; counter1++){
                            lineTrimmingX = lineTrimmingXY [counter1*2];
                            lineTrimmingY = lineTrimmingXY [counter1*2+1];
                            lineTrimmingXY [counter1*2] = -1;
                            lineTrimmingXY [counter1*2+1] = -1;
                            
                            if (lineTrimmingX != -1){
                                attachPoint = 0;
                                countSave = 0;
                                
                                for (int counter2 = counter1+1; counter2 < linePointCount-3; counter2++){
                                    lineTrimmingX2 = lineTrimmingXY [counter2*2];
                                    lineTrimmingY2 = lineTrimmingXY [counter2*2+1];
                                    
                                    for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                        for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                            if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                                attachPoint++;
                                                
                                                if (attachPoint == 1) countSave = counter2;
                                                if (attachPoint > 1){
                                                    for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                        lineTrimmingXY [counter3*2] = -1;
                                                        lineTrimmingXY [counter3*2+1] = -1;
                                                        lineTrimmingValue [counter3] = -1;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < targetTempCount2/2; counterA++){
                        //    cout<<arrayTargetTemp2 [counterA*2]<<" "<<arrayTargetTemp2 [counterA*2+1]<<" GapFilled3"<<endl;
                        //}
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            if (lineTrimmingValue [counter1] != -1){
                                arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2], lineDataProcessingCount++;
                                arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2+1], lineDataProcessingCount++;
                            }
                        }
                        
                        if (lineDataProcessingCount/2 > 11){
                            //-----Line Reorder-----
                            targetTempCount2 = 0;
                            
                            linePointCount = lineDataProcessingCount/2;
                            
                            for (int counter1 = linePointCount/2; counter1 < linePointCount; counter1++){
                                arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2], targetTempCount2++;
                                arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2+1], targetTempCount2++;
                            }
                            
                            for (int counter1 = 0; counter1 < linePointCount/2; counter1++){
                                arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2], targetTempCount2++;
                                arrayTargetTemp2 [targetTempCount2] = arrayLineDataProcessing [counter1*2+1], targetTempCount2++;
                            }
                            
                            //for (int counterA = 0; counterA < targetTempCount2/2; counterA++){
                            //	cout<<counterA<<" "<<arrayTargetTemp2 [counterA*2]<<" "<<arrayTargetTemp2 [counterA*2+1]<<" Target"<<endl;
                            //}
                            
                            //-----Second line cleaning-----
                            for (int counter1 = 0; counter1 < linePointCount; counter1++){
                                lineTrimmingValue [counter1] = 0;
                                lineTrimmingXY [counter1*2] = arrayTargetTemp2 [counter1*2];
                                lineTrimmingXY [counter1*2+1] = arrayTargetTemp2 [counter1*2+1];
                            }
                            
                            for (int counter1 = 0; counter1 < linePointCount-4; counter1++){
                                lineTrimmingX = lineTrimmingXY [counter1*2];
                                lineTrimmingY = lineTrimmingXY [counter1*2+1];
                                lineTrimmingXY [counter1*2] = -1;
                                lineTrimmingXY [counter1*2+1] = -1;
                                
                                if (lineTrimmingX != -1){
                                    attachPoint = 0;
                                    countSave = 0;
                                    
                                    for (int counter2 = counter1+1; counter2 < linePointCount-3; counter2++){
                                        lineTrimmingX2 = lineTrimmingXY [counter2*2];
                                        lineTrimmingY2 = lineTrimmingXY [counter2*2+1];
                                        
                                        for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                            for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                                if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                                    attachPoint++;
                                                    
                                                    if (attachPoint == 1) countSave = counter2;
                                                    if (attachPoint > 1){
                                                        for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                            lineTrimmingXY [counter3*2] = -1;
                                                            lineTrimmingXY [counter3*2+1] = -1;
                                                            lineTrimmingValue [counter3] = -1;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < targetTempCount2/2; counterA++){
                            //	cout<<counterA<<" "<<arrayTargetTemp2 [counterA*2]<<" "<<arrayTargetTemp2 [counterA*2+1]<<" Target2"<<endl;
                            //}
                            
                            lineDataProcessingCount = 0;
                            
                            for (int counter1 = 0; counter1 < linePointCount; counter1++){
                                if (lineTrimmingValue [counter1] != -1){
                                    arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2], lineDataProcessingCount++;
                                    arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2+1], lineDataProcessingCount++;
                                }
                            }
                        }
                        else{
                            
                            lineDataProcessingCount = 0;
                            targetCount = 0;
                        }
                        
                        delete [] lineTrimmingValue;
                        delete [] lineTrimmingXY;
                    }
                    else targetCount = 0;
                    
                    //-----Circle data hold-----
                    if (processType == 1 && trackingOn == 3){
                        targetPrevHoldCount = 0;
                        
                        if (targetCount != 0){
                            for (int counter1 = 0; counter1 < targetCount/2; counter1++){
                                if (targetPrevHoldCount+10 > targetPrevHoldLimit){
                                    int *arrayTargetUpDate = new int [targetPrevHoldCount+10];
                                    
                                    for (int counter2 = 0; counter2 < targetPrevHoldCount; counter2++) arrayTargetUpDate [counter2] = arrayTargetPrevHold [counter2];
                                    
                                    delete [] arrayTargetPrevHold;
                                    arrayTargetPrevHold = new int [targetPrevHoldLimit+1000];
                                    targetPrevHoldLimit = targetPrevHoldLimit+1000;
                                    
                                    for (int counter2 = 0; counter2 < targetPrevHoldCount; counter2++) arrayTargetPrevHold [counter2] = arrayTargetUpDate [counter2];
                                    delete [] arrayTargetUpDate;
                                }
                                
                                arrayTargetPrevHold [targetPrevHoldCount] = arrayTarget [counter1*2], targetPrevHoldCount++;
                                arrayTargetPrevHold [targetPrevHoldCount] = arrayTarget [counter1*2+1], targetPrevHoldCount++;
                            }
                        }
                    }
                    
                    //-----Linear-----
                    if (neighborCount == 0 && linePointCount > 5 && cellDivisionSetCount == 0){
                        int *lineTrimmingValue = new int [linePointCount+10];
                        int *lineTrimmingXY = new int [linePointCount*2+10];
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            lineTrimmingValue [counter1] = 0;
                            lineTrimmingXY [counter1*2] = arrayTargetTemp2 [counter1*2];
                            lineTrimmingXY [counter1*2+1] = arrayTargetTemp2 [counter1*2+1];
                        }
                        
                        int lineTrimmingX = 0;
                        int lineTrimmingY = 0;
                        int attachPoint = 0;
                        int countSave = 0;
                        int lineTrimmingX2 = 0;
                        int lineTrimmingY2 = 0;
                        
                        for (int counter1 = 0; counter1 < linePointCount-1; counter1++){
                            lineTrimmingX = lineTrimmingXY [counter1*2];
                            lineTrimmingY = lineTrimmingXY [counter1*2+1];
                            lineTrimmingXY [counter1*2] = -1;
                            lineTrimmingXY [counter1*2+1] = -1;
                            
                            if (lineTrimmingX != -1){
                                attachPoint = 0;
                                countSave = 0;
                                
                                for (int counter2 = counter1+1; counter2 < linePointCount; counter2++){
                                    lineTrimmingX2 = lineTrimmingXY [counter2*2];
                                    lineTrimmingY2 = lineTrimmingXY [counter2*2+1];
                                    
                                    for (int counterY = lineTrimmingY-1; counterY <= lineTrimmingY+1; counterY++){
                                        for (int counterX = lineTrimmingX-1; counterX <= lineTrimmingX+1; counterX++){
                                            if (counterX == lineTrimmingX2 && counterY == lineTrimmingY2){
                                                attachPoint++;
                                                
                                                if (attachPoint == 1) countSave = counter2;
                                                if (attachPoint > 1){
                                                    for (int counter3 = countSave; counter3 < counter2; counter3++){
                                                        lineTrimmingXY [counter3*2] = -1;
                                                        lineTrimmingXY [counter3*2+1] = -1;
                                                        lineTrimmingValue [counter3] = -1;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        lineDataProcessingCount = 0;
                        
                        for (int counter1 = 0; counter1 < linePointCount; counter1++){
                            if (lineTrimmingValue [counter1] != -1){
                                arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2], lineDataProcessingCount++;
                                arrayLineDataProcessing [lineDataProcessingCount] = arrayTargetTemp2 [counter1*2+1], lineDataProcessingCount++;
                            }
                        }
                        
                        delete [] lineTrimmingValue;
                        delete [] lineTrimmingXY;
                        
                        //for (int counterA = 0; counterA < lineDataProcessingCount/2; counterA++){
                        //	cout<<counterA<<" "<<arrayLineDataProcessing [counterA*2]<<" "<<arrayLineDataProcessing [counterA*2+1]<<" LineData"<<endl;
                        //}
                        
                        int *arrayLineDataProcessingTemp = new int [lineDataProcessingCount*2+50];
                        int lineDataProcessingTempCount = 0;
                        
                        arrayLineDataProcessingTemp [lineDataProcessingTempCount] = arrayLineDataProcessing [0], lineDataProcessingTempCount++;
                        arrayLineDataProcessingTemp [lineDataProcessingTempCount] = arrayLineDataProcessing [1], lineDataProcessingTempCount++;
                        
                        for (int counter1 = 0; counter1 < lineDataProcessingCount/2-1; counter1++){
                            lineTrimmingX = arrayLineDataProcessing [counter1*2];
                            lineTrimmingY = arrayLineDataProcessing [counter1*2+1];
                            lineTrimmingX2 = arrayLineDataProcessing [(counter1+1)*2];
                            lineTrimmingY2 = arrayLineDataProcessing [(counter1+1)*2+1];
                            
                            if (lineTrimmingX-1 == lineTrimmingX2 && lineTrimmingY-1 == lineTrimmingY2){
                                arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingX, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingY-1, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp[lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                            }
                            else if (lineTrimmingX+1 == lineTrimmingX2 && lineTrimmingY-1 == lineTrimmingY2){
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX+1, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                            }
                            else if (lineTrimmingX+1 == lineTrimmingX2 && lineTrimmingY+1 == lineTrimmingY2){
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY+1, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                            }
                            else if (lineTrimmingX-1 == lineTrimmingX2 && lineTrimmingY+1 == lineTrimmingY2){
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX-1, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                            }
                            else{
                                
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingX2, lineDataProcessingTempCount++;
                                arrayLineDataProcessingTemp [lineDataProcessingTempCount] = lineTrimmingY2, lineDataProcessingTempCount++;
                            }
                        }
                        
                        delete [] arrayLineDataProcessing;
                        lineDataProcessingCount = 0;
                        arrayLineDataProcessing = new int [lineDataProcessingTempCount+50];
                        
                        for (int counter1 = 0; counter1 < lineDataProcessingTempCount; counter1++) arrayLineDataProcessing [lineDataProcessingCount] = arrayLineDataProcessingTemp [counter1], lineDataProcessingCount++;
                        
                        delete [] arrayLineDataProcessingTemp;
                        
                        //for (int counterA = 0; counterA < lineDataProcessingCount/2; counterA++){
                        //	cout<<counterA<<" "<<arrayLineDataProcessing [counterA*2]<<" "<<arrayLineDataProcessing [counterA*2+1]<<" LineData"<<endl;
                        //}
                    }
                    else targetCount = 0;
                    
                    //-----Entry to Target Hold-----
                    int targetHoldAddition = 0;
                    
                    if (removeAll == 0){
                        if ((neighborCount == 0 && lineDataProcessingCount/2 > 5) || (neighborCount == 1 && lineDataProcessingCount/2 > 11)){
                            int results = 0;
                            
                            if (neighborCount == 0 && trackingOn == 2){
                                newAreaCreation = [[NewAreaCreation alloc] init];
                                [newAreaCreation newAreaLine];
                            }
                            
                            if (neighborCount == 1 && trackingOn == 2){
                                areaCircleCut = [[AreaCircleCut alloc] init];
                                results = [areaCircleCut circleCut:processType];
                            }
                            
                            if (neighborCount == 0 && trackingOn == 3 && firstModificationPoint != 10000 && cellDivisionSetCount == 0 && fluorescentDisplayNo == 0 && ifEntry == 0){
                                newAreaCreationTrack = [[NewAreaCreationTrack alloc] init];
                                results = [newAreaCreationTrack newAreaLineCut];
                            }
                            
                            if (neighborCount == 1 && trackingOn == 3 && fluorescentDisplayNo == 0 && ifEntry == 0){
                                areaCircleCutTrack = [[AreaCircleCutTrack alloc] init];
                                results = [areaCircleCutTrack circleCut:processType];
                            }
                            
                            if (neighborCount == 0 && trackingOn == 3 && firstModificationPoint != 10000 && cellDivisionSetCount == 0 && fluorescentDisplayNo != 0){
                                areaSetFluorescent = [[AreaSetFluorescent alloc] init];
                                results = [areaSetFluorescent newFluorescentLineCut];
                            }
                            if (neighborCount == 1 && trackingOn == 3 && fluorescentDisplayNo != 0){
                                areaSetFluorescent = [[AreaSetFluorescent alloc] init];
                                results = [areaSetFluorescent newFluorescentAreaSet];
                            }
                            
                            if ((trackingOn == 3 && results == 0 && ifEntry == 0) || (neighborCount == 1 && trackingOn == 2 && results == 0)){
                                targetCount = 0;
                                
                                if (mergeAllFlag == 0 && forceSetAutoFlag == 0){
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                if (fluorescentDisplayNo == 0){
                                    if (targetLostMark != "" && atoi(targetLostMark.substr(5).c_str()) >= imageNumberTrackForDisplay){
                                        targetLostMark = "";
                                    }
                                    
                                    //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                                    //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                                    //	cout<<" arrayEventSequence "<<counterA<<endl;
                                    //}
                                    
                                    int lineEntryNumber = 0;
                                    
                                    if (targetHoldCount != 0) lineEntryNumber = arrayTargetHold [(targetHoldCount/3-1)*3+2];
                                    else lineEntryNumber = 0;
                                    
                                    lineEntryNumber++;
                                    
                                    if (trackingOn == 3){
                                        lineModificationFlag = 1;
                                        
                                        if (lineModificationFlag == 1 && lineModificationRecord == 0) lineModificationRecord = 1;
                                        
                                        if (firstModificationPoint == 10000) firstModificationPoint = trackingLowerLimit;
                                        
                                        //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
                                        //    cout<<" arrayEventSequenceHold "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
                                        //    cout<<" arrayEventSequence "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
                                        //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
                                        //    cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
                                        //}
                                    }
                                    
                                    if (targetHoldCount+lineDataProcessingCount/2*3 > targetHoldLimit){
                                        targetHoldAddition = lineDataProcessingCount/2*3;
                                        
                                        int *arrayUpDate = new int [targetHoldCount+10];
                                        
                                        for (int counter1 = 0; counter1 < targetHoldCount; counter1++) arrayUpDate [counter1] = arrayTargetHold [counter1];
                                        
                                        delete [] arrayTargetHold;
                                        arrayTargetHold = new int [targetHoldLimit+targetHoldAddition+5000];
                                        targetHoldLimit = targetHoldLimit+targetHoldAddition+5000;
                                        
                                        for (int counter1 = 0; counter1 < targetHoldCount; counter1++) arrayTargetHold [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
                                        arrayTargetHold [targetHoldCount] = arrayLineDataProcessing [counter1*2], targetHoldCount++; //-----X Position-----
                                        arrayTargetHold [targetHoldCount] = arrayLineDataProcessing [counter1*2+1], targetHoldCount++; //-----Y Position-----
                                        arrayTargetHold [targetHoldCount] = lineEntryNumber, targetHoldCount++; //-----Line Number-----
                                        
                                        if (counter1 == 0){
                                            if (targetHoldInfoCount+4 > targetHoldInfoLimit){
                                                int *arrayUpDate = new int [targetHoldInfoCount+10];
                                                
                                                for (int counter2 = 0; counter2 < targetHoldInfoCount; counter2++) arrayUpDate [counter2] = arrayTargetHoldInfo [counter2];
                                                
                                                delete [] arrayTargetHoldInfo;
                                                arrayTargetHoldInfo = new int [targetHoldInfoLimit+5000];
                                                targetHoldInfoLimit = targetHoldInfoLimit+5000;
                                                
                                                for (int counter2 = 0; counter2 < targetHoldInfoCount; counter2++) arrayTargetHoldInfo [counter1] = arrayUpDate [counter2];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            arrayTargetHoldInfo [targetHoldInfoCount] = arrayLineDataProcessing [counter1*2], targetHoldInfoCount++; //-----X position First-----
                                            arrayTargetHoldInfo [targetHoldInfoCount] = arrayLineDataProcessing [counter1*2+1], targetHoldInfoCount++; //-----Y position First-----
                                            
                                            if (neighborCount > 0) arrayTargetHoldInfo [targetHoldInfoCount] = 1, targetHoldInfoCount++; //-----Linear, Circle status: cut-----
                                            else arrayTargetHoldInfo [targetHoldInfoCount] = 0, targetHoldInfoCount++; //-----Linear, Circle status: Line-----
                                            
                                            arrayTargetHoldInfo [targetHoldInfoCount] = lineEntryNumber, targetHoldInfoCount++; //-----Line Number-----
                                        }
                                    }
                                }
                                
                                targetCount = 0;
                            }
                        }
                        else{
                            
                            targetCount = 0;
                            
                            if (mergeAllFlag == 0){
                                if (trackingOn == 3){
                                    for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                        if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
                                    }
                                }
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                    else{
                        
                        int maxPointDimX = 0;
                        int maxPointDimY = 0;
                        int minPointDimX = 1000000;
                        int minPointDimY = 1000000;
                        
                        //-----Find overlap connect-----
                        for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
                            if (maxPointDimX < arrayLineDataProcessing [counter1*2]) maxPointDimX = arrayLineDataProcessing [counter1*2];
                            if (minPointDimX > arrayLineDataProcessing [counter1*2]) minPointDimX = arrayLineDataProcessing [counter1*2];
                            if (maxPointDimY < arrayLineDataProcessing [counter1*2+1]) maxPointDimY = arrayLineDataProcessing [counter1*2+1];
                            if (minPointDimY > arrayLineDataProcessing [counter1*2+1]) minPointDimY = arrayLineDataProcessing [counter1*2+1];
                        }
                        
                        //-----Determine the dimension of cell-----
                        int horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                        int verticalLength = (maxPointDimY-minPointDimY)/2*2;
                        int dimension = 0;
                        
                        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                        if (horizontalLength < verticalLength) dimension = verticalLength+30;
                        
                        dimension = (dimension/2)*2;
                        
                        int horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                        int verticalStart = minPointDimY-(dimension-verticalLength)/2;
                        
                        //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
                        
                        int **connectivityMapTemp = new int *[dimension+1];
                        for (int counter1 = 0; counter1 < dimension+1; counter1++) connectivityMapTemp [counter1] = new int [dimension+1];
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
                        }
                        
                        for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
                            connectivityMapTemp [arrayLineDataProcessing [counter1*2+1]-verticalStart][arrayLineDataProcessing [counter1*2]-horizontalStart] = 1;
                        }
                        
                        //-----Fill inside-----
                        int *connectAnalysisX = new int [dimension*4];
                        int *connectAnalysisY = new int [dimension*4];
                        int *connectAnalysisTempX = new int [dimension*4];
                        int *connectAnalysisTempY = new int [dimension*4];
                        
                        int connectivityNumber = -3;
                        int connectAnalysisCount = 0;
                        int terminationFlag = 0;
                        int connectAnalysisTempCount = 0;
                        int xSource = 0;
                        int ySource = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapTemp [counterY][counterX] == 0){
                                    connectivityNumber = connectivityNumber+2;
                                    connectAnalysisCount = 0;
                                    
                                    if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapTemp [counterY][counterX] = connectivityNumber;
                                    
                                    if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0){
                                        connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0){
                                        connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0){
                                        connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0){
                                        connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                                xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                                
                                                if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                                    connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                                    connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                                    connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                                    connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                                connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        delete [] connectAnalysisX;
                        delete [] connectAnalysisY;
                        delete [] connectAnalysisTempX;
                        delete [] connectAnalysisTempY;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMapTemp [counterY][counterX] == -1) connectivityMapTemp [counterY][counterX] = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                        //	cout<<" connectivityMapTemp "<<counterA<<endl;
                        //}
                        
                        int maxConnectNo = arrayTimeSelected [(timeSelectedCount/10-1)*10+8];
                        
                        int *connectNoDelete = new int [maxConnectNo+10];
                        for (int counter1 = 0; counter1 < maxConnectNo+10; counter1++) connectNoDelete [counter1] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0 && connectivityMapTemp [counterY][counterX] == 1){
                                    connectNoDelete [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]] = 1;
                                }
                            }
                        }
                        
                        int matchFind = 0;
                        
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            matchFind = 0;
                            
                            for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                                if (arrayTimeSelected [counter1*10+8] == counter2 && connectNoDelete [counter2] == 1){
                                    matchFind = 1;
                                    break;
                                }
                            }
                            
                            if (matchFind == 1){
                                arrayTimeSelected [counter1*10] = 2;
                                
                                for (int counter2 = arrayTimeSelected [counter1*10+2]; counter2 < positionReviseCount/7; counter2++){
                                    if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [counter1*10+8]){
                                        arrayPositionRevise [counter2*7+5] = 0;
                                        arrayPositionRevise [counter2*7+6] = 0;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < dimension+1; counter1++) delete [] connectivityMapTemp [counter1];
                        
                        delete [] connectivityMapTemp;
                        delete [] connectNoDelete;
                    }
                    
                    delete [] arrayLineDataProcessing;
                }
                else{
                    
                    targetCount = 0;
                    
                    if (mergeAllFlag == 0){
                        if (trackingOn == 3){
                            for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                                if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
                            }
                        }
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                
                delete [] targetGapFill;
                delete [] arrayTargetTemp2;
            }
            else{
                
                targetCount = 0;
                
                if (mergeAllFlag == 0){
                    if (trackingOn == 3){
                        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
                            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay) arrayEventSequence [counter1*4] = 0;
                        }
                    }
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            
            delete [] arrayTargetTemp1;
            
            if ((neighborCount == 0 && trackingOn == 2) || (neighborCount == 1 && trackingOn == 2)){
                tableDataSetDone = 1;
                lineSetWindowCallTrack = 1;
                lineSetWindowCallDisplay = 1;
                trackingTableSetDone = 0;
                tableTrackingProcessing = 0;
            }
            else if ((neighborCount == 1 && trackingOn == 3) || (neighborCount == 0 && trackingOn == 3)){
                tableTrackingProcessing = 1;
                lineSetWindowCallTrack = 1;
                lineSetWindowCallDisplay = 1;
                tableDataSetDone = 0;
                trackingTableSetDone = 0;
            }
            else{
                
                tableDataSetDone = 0;
                tableTrackingProcessing = 0;
                lineSetWindowCallTrack = 1;
                lineSetWindowCallDisplay = 1;
                trackingTableSetDone = 0;
            }
            
            if (mergeAllFlag == 0) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Selected Lineage: Being Processed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Line Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)dataRead:(int)readImage{
    int lineSetResult = 0;
    
    ifstream fin;
    
    string extension = to_string(readImage);
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
    string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long sizeForCopy2 = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    int readingError = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    if (masterLineForTrackingStatus == 1) delete [] arrayMasterLineForTracking;
    if (masterLineForDisplayStatus == 1) delete [] arrayMasterLineForDisplay;
    if (masterLineGravityCenterStatus == 1) delete [] arrayMasterLineGravityCenter;
    if (masterLineGCDisplayStatus == 1) delete [] arrayMasterLineGravityCenterDisplay;
    
    arrayMasterLineForTracking = new int [sizeForCopy+50];
    masterLineForTrackingCount = 0;
    masterLineForTrackingStatus = 1;
    arrayMasterLineForDisplay = new int [sizeForCopy+50];
    masterLineForDisplayCount = 0;
    masterLineForDisplayStatus = 1;
    
    sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
    arrayMasterLineGravityCenter = new int [sizeForCopy2+50];
    masterLineGravityCenterCount = 0;
    masterLineGravityCenterLimit = (int)sizeForCopy2+50;
    masterLineGravityCenterStatus = 1;
    
    sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
    arrayMasterLineGravityCenterDisplay = new int [sizeForCopy2+50];
    masterLineGCDisplayCount = 0;
    masterLineGCDisplayLimit = (int)sizeForCopy2+50;
    masterLineGCDisplayStatus = 1;
    
    //-----Master Data upLoad-----
    //-----1: X Position, 2: Y Position, 3: Value, 4: Connect Number, 5: Cell number, 6: Status, 0, non-possible target, 2, possible target, 3. removed, 7. Lineage number-----
    
    if (checkFlag == 1){
        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            int finData [17];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        readingError = 1;
                    }
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++;
                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                        else{
                            
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [12], masterLineForTrackingCount++;
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [13], masterLineForTrackingCount++;
                            arrayMasterLineForTracking [masterLineForTrackingCount] = finData [16], masterLineForTrackingCount++;
                            
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [1], masterLineForDisplayCount++;
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [3], masterLineForDisplayCount++;
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [4], masterLineForDisplayCount++;
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [7], masterLineForDisplayCount++;
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [12], masterLineForDisplayCount++;
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [13], masterLineForDisplayCount++;
                            arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [16], masterLineForDisplayCount++;
                        }
                    }
                    else if (stepCount == 1){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        finData [9] = finData [8]*256+finData [9];
                        
                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                    }
                    else if (stepCount == 2){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                        else{
                            
                            if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineGCUpDate];
                            }
                            
                            arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                            arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                            arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                            arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                            arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                            arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [11], masterLineGravityCenterCount++;
                            
                            if (masterLineGCDisplayCount+14 > masterLineGCDisplayLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineGCDisplayUpDate];
                            }
                            
                            arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [1], masterLineGCDisplayCount++;
                            arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [3], masterLineGCDisplayCount++;
                            arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [6], masterLineGCDisplayCount++;
                            arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [7], masterLineGCDisplayCount++;
                            arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [10], masterLineGCDisplayCount++;
                            arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [11], masterLineGCDisplayCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTemp;
            
            //for (int counterA = 0; counterA < masterLineForTrackingCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayMasterLineForTracking [counterA*7+counterB];
            //	cout<<" arrayMasterLineForTracking "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
            //  for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
            //cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
            //}
        }
        else{
            
            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [11];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--2
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--1
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--3
                            finData [8] = uploadTemp [readPosition], readPosition++; //--1
                            finData [9] = uploadTemp [readPosition], readPosition++; //--1
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [1], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [3], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [4], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [7], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = 0, masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = 0, masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = 0, masterLineForDisplayCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate masterLineGCUpDate];
                                }
                                
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = 0, masterLineGravityCenterCount++;
                                
                                if (masterLineGCDisplayCount+14 > masterLineGCDisplayLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate masterLineGCDisplayUpDate];
                                }
                                
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [1], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [3], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [6], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [7], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [10], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = 0, masterLineGCDisplayCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
        }
        
        // for (int counterA = 0; counterA < masterLineForTrackingCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayMasterLineForTracking [counterA*7+counterB];
        //	cout<<" masterLineForTrackingCount "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
        // 	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
        //	cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
        //}
    }
    
    if (checkFlag == 0 || readingError == 1){
        masterLineForTrackingCount = 0;
        masterLineForDisplayCount = 0;
        masterLineGravityCenterCount = 0;
        masterLineGCDisplayCount = 0;
    }
    
    if (checkFlag == 1 && readingError == 0){
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (masterLineSelectedStatus == 1) delete [] arrayMasterLineSelected;
        
        arrayMasterLineSelected = new int [sizeForCopy+50];
        masterLineSelectedCount = 0;
        masterLineSelectedLimit = (int)sizeForCopy+50;
        masterLineSelectedStatus = 1;
        
        readingError = 0;
        
        if (sizeForCopy != 0){
            int finData [19];
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            if (masterLineSelectedCount+10 > masterLineSelectedLimit){
                                masterLineSelectedAddition = 10;
                                
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineSelectedUpDate];
                            }
                            
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [0], masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [3], masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [6], masterLineSelectedCount++; //-----PositionRevise Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [8], masterLineSelectedCount++; //-----Cut line number-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [9], masterLineSelectedCount++; //-----X Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [10], masterLineSelectedCount++; //-----X End-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [11], masterLineSelectedCount++; //-----Y Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [12], masterLineSelectedCount++; //-----Y End-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [15], masterLineSelectedCount++; //-----Connect-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [18], masterLineSelectedCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTemp;
        }
        else{
            
            if (masterLineSelectedCount+masterLineGravityCenterCount/6*10 > masterLineSelectedLimit){
                masterLineSelectedAddition = masterLineGravityCenterCount/6*10;
                
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate masterLineSelectedUpDate];
            }
            
            for (int counter1 = 0; counter1 < masterLineGravityCenterCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Top position of each connect-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Cut line number-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
            }
            
            int valueTemp = 0;
            
            for (int counter1 = 0; counter1 < masterLineForTrackingCount/7; counter1++){
                if (arrayMasterLineForTracking [counter1*7+3] != valueTemp){
                    valueTemp = arrayMasterLineForTracking [counter1*7+3];
                    arrayMasterLineSelected [(valueTemp-1)*10+2] = counter1;
                    
                    if (arrayMasterLineForTracking [counter1*7+5] == 0) arrayMasterLineSelected [(valueTemp-1)*10] = 0;
                }
            }
        }
        
        if (masterLineSelectedDisplayStatus == 1) delete [] arrayMasterLineSelectedDisplay;
        
        arrayMasterLineSelectedDisplay = new int [sizeForCopy+50];
        masterLineSelectedDisplayCount = 0;
        masterLineSelectedDisplayLimit = (int)sizeForCopy+50;
        masterLineSelectedDisplayStatus = 1;
        
        readingError = 0;
        
        if (sizeForCopy != 0){
            int finData [19];
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            if (masterLineSelectedDisplayCount+10 > masterLineSelectedDisplayLimit){
                                masterLineSelectedDisplayAddition = 10;
                                
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineSelectedDisplayUpDate];
                            }
                            
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [0], masterLineSelectedDisplayCount++; //-----Selected, removed, eliminated status-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [3], masterLineSelectedDisplayCount++; //-----When new line is created, enter line number which creates-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [6], masterLineSelectedDisplayCount++; //-----PositionRevise Start-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [8], masterLineSelectedDisplayCount++; //-----Cut line number-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [9], masterLineSelectedDisplayCount++; //-----X Start-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [10], masterLineSelectedDisplayCount++; //-----X End-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [11], masterLineSelectedDisplayCount++; //-----Y Start-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [12], masterLineSelectedDisplayCount++; //-----Y End-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [15], masterLineSelectedDisplayCount++; //-----Connect-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [18], masterLineSelectedDisplayCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTemp;
        }
        else{
            
            if (masterLineSelectedDisplayCount+masterLineGCDisplayCount/6*10 > masterLineSelectedDisplayLimit){
                masterLineSelectedDisplayAddition = masterLineGCDisplayCount/6*10;
                
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate masterLineSelectedDisplayUpDate];
            }
            
            for (int counter1 = 0; counter1 < masterLineGCDisplayCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----Selected, removed, eliminated status-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----When new line is created, enter line number which creates-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----Top position of each connect-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----Cut line number-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = counter1+1, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
            }
            
            int valueTemp = 0;
            
            for (int counter1 = 0; counter1 < masterLineForDisplayCount/7; counter1++){
                if (arrayMasterLineForDisplay [counter1*7+3] != valueTemp){
                    valueTemp = arrayMasterLineForDisplay [counter1*7+3];
                    arrayMasterLineSelectedDisplay [(valueTemp-1)*10+2] = counter1;
                }
            }
        }
        
        //for (int counterA = 0; counterA < masterLineSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayMasterLineSelected [counterA*10+counterB];
        //	cout<<" arrayMasterLineSelected "<<counterA<<endl;
        //}
    }
    
    if (readingError == 1){
        masterLineSelectedCount = 0;
        masterLineSelectedDisplayCount = 0;
    }
    
    if (checkFlag == 0 || readingError == 1){
        lineSetResult = -1;
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Data Read Error"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    
    return lineSetResult;
}

-(void)gapFillUpdate{
    int *arrayGapUpDate = new int [targetGapFillCount+10];
    
    for (int counter1 = 0; counter1 < targetGapFillCount; counter1++) arrayGapUpDate [counter1] = targetGapFill [counter1];
    
    delete [] targetGapFill;
    targetGapFill = new int [targetGapFillLimit+targetGapFillAddition+500];
    targetGapFillLimit = targetGapFillLimit+targetGapFillAddition+500;
    
    for (int counter1 = 0; counter1 < targetGapFillCount; counter1++) targetGapFill [counter1] = arrayGapUpDate [counter1];
    delete [] arrayGapUpDate;
}

@end
