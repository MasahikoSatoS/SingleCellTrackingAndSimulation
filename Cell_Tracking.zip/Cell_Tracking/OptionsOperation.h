//
//  OptionsOperation.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-12-03.
//
//

#ifndef OPTIONOPERATION_H
#define OPTIONOPERATION_H
#import "Controller.h" 
#endif

@interface OptionsOperation : NSObject  <NSTableViewDataSource>{
    IBOutlet NSTextField *treatSelected;
    
    IBOutlet NSTableView *timeViewOperation;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

-(IBAction)autoSet:(id)sender;
-(IBAction)removeTLSet:(id)sender;
-(IBAction)removeTLRedoSet:(id)sender;
-(IBAction)noneSet:(id)sender;
-(IBAction)proceedSet:(id)sender;

@end
