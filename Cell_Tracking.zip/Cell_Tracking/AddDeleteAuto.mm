//
// AddDeleteAuto.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 14/01/27.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "AddDeleteAuto.h"

@implementation AddDeleteAuto

-(int)delLineageMain:(int)connectNoDel :(int)processType :(int)delCellNo :(int)startPointSet{
    ifstream fin;
    
    int returnResults = -1;
    
    //-----Lineage data-----
    string connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageData";
    
    struct stat sizeOfFile;
    long sizeForCopy = 0;
    long size1 = 0;
    long size2 = 0;
    int checkFlag = 0;
    int readingError = 0;
    
    for (int counter1 = 0; counter1 < 6; counter1++){
        sizeForCopy = 0;
        
        if (stat(connectDataLineagePath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy != 0){
            if (counter1 == 0) size1 = sizeForCopy;
            else if (counter1 == 1) size2 = sizeForCopy;
            else if (counter1 == 2){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                    break;
                }
                else{
                    
                    size1 = 0;
                    size2 = 0;
                    usleep (50000);
                }
            }
            else if (counter1 == 3) size1 = sizeForCopy;
            else if (counter1 == 4) size2 = sizeForCopy;
            else if (counter1 == 5){
                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                    checkFlag = 1;
                }
            }
        }
    }
    
    int *lineageAuto = new int [sizeForCopy+50];
    int lineageAutoCount = 0;
    
    if (checkFlag == 1){
        int finData [25];
        
        fin.open(connectDataLineagePath.c_str(), ios::in | ios::binary);
        
        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
        fin.read((char*)uploadTemp, sizeForCopy+50);
        
        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
            usleep(50000);
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                readingError = 1;
            }
        }
        
        fin.close();
        
        if (readingError == 0){
            unsigned long readPosition = 0;
            int stepCount = 0;
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++;
                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                    finData [15] = uploadTemp [readPosition], readPosition++;
                    finData [16] = uploadTemp [readPosition], readPosition++;
                    finData [17] = uploadTemp [readPosition], readPosition++;
                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                    finData [19] = uploadTemp [readPosition], readPosition++;
                    finData [20] = uploadTemp [readPosition], readPosition++;
                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                    finData [22] = uploadTemp [readPosition], readPosition++;
                    finData [23] = uploadTemp [readPosition], readPosition++;
                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                    
                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                    else finData [2] = finData [1]*256+finData [2];
                    
                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                    else finData [5] = finData [4]*256+finData [5];
                    
                    finData [7] = finData [6]*256+finData [7];
                    
                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                    
                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                    
                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                    
                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                    else{
                        
                        lineageAuto [lineageAutoCount] = finData [2], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [5], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [7], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [8], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [13], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [18], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [21], lineageAutoCount++;
                        lineageAuto [lineageAutoCount] = finData [24], lineageAutoCount++;
                    }
                }
                
            } while (stepCount != 3);
        }
        
        delete [] uploadTemp;
    }
    
    //for (int counterA = 0; counterA < lineageAutoCount/8; counterA++){
    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageAuto [counterA*8+counterB];
    //	cout<<" lineageAuto "<<counterA<<endl;
    //}
    
    if (checkFlag == 1 && readingError == 0){
        string connectDataStatus = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStatus";
        
        sizeForCopy = 0;
        
        if (stat(connectDataStatus.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *lineageStatusAuto = new int [sizeForCopy+50];
        int lineageStatusAutoCount = 0;
        
        if (sizeForCopy != 0){
            fin.open(connectDataStatus.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        lineageStatusAuto [lineageStatusAutoCount] = atoi(dataString.c_str()), lineageStatusAutoCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        //for (int counterA = 0; counterA < lineageStatusAutoCount/3; counterA++){
        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<lineageStatusAuto [counterA*3+counterB];
        //	cout<<" lineageStatusAuto "<<counterA<<endl;
        //}
        
        //-----Start/end data-----
        string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStartEnd";
        
        sizeForCopy = 0;
        
        if (stat(connectStartEndPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *lineageStartEndAuto = new int [sizeForCopy+50];
        int lineageStartEndAutoCount = 0;
        int lineageStartEndAutoLimit = (int)sizeForCopy+50;
        
        if (sizeForCopy != 0){
            fin.open(connectStartEndPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        lineageStartEndAuto [lineageStartEndAutoCount] = atoi(dataString.c_str()), lineageStartEndAutoCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        if (connectNoDel > 0 && lineageAutoCount > 1){
            string extension;
            string delLineage = to_string(connectNoDel);
            
            if (delLineage.length() == 1) delLineage = "L0000"+delLineage;
            else if (delLineage.length() == 2) delLineage = "L000"+delLineage;
            else if (delLineage.length() == 3) delLineage = "L00"+delLineage;
            else if (delLineage.length() == 4) delLineage = "L0"+delLineage;
            else if (delLineage.length() == 5) delLineage = "L"+delLineage;
            
            //for (int counterA = 0; counterA < lineageStartEndAutoCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageStartEndAuto [counterA*8 +counterB];
            //	cout<<" lineageStartEndAuto "<<counterA<<endl;
            //}
            
            //-----Remove connectDel or cellDel from lineage-----
            int entryExtractionSize = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndAutoCount/8; counter1++){
                if (lineageStartEndAuto [counter1*8] == connectNoDel) entryExtractionSize = entryExtractionSize+(lineageStartEndAuto [counter1*8+6]-lineageStartEndAuto [counter1*8+4]+1);
            }
            
            int *lineageEntryExtraction = new int [entryExtractionSize*8+50];
            int lineageEntryExtractionCount = 0;
            
            if (processType == 1){
                int *lineageDataTemp = new int [lineageAutoCount+50];
                int lineageDataTempCount = 0;
                
                for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                    if (lineageAuto [counter1*8+6] != connectNoDel){
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8], lineageDataTempCount++; //-----X Position-----
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+1], lineageDataTempCount++; //-----Y Position-----
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+2], lineageDataTempCount++; //-----Time point-----
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+3], lineageDataTempCount++;
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+5], lineageDataTempCount++; //-----Cell Number-----
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                        lineageDataTemp [lineageDataTempCount] = lineageAuto [counter1*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                    }
                    else{
                        
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8], lineageEntryExtractionCount++; //-----X Position-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+1], lineageEntryExtractionCount++; //-----Y Position-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+2], lineageEntryExtractionCount++; //-----Time point-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+3], lineageEntryExtractionCount++;
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+4], lineageEntryExtractionCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+5], lineageEntryExtractionCount++; //-----Cell Number-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+6], lineageEntryExtractionCount++; //-----Cell Lineage Number-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = lineageAuto [counter1*8+7], lineageEntryExtractionCount++; //-----For Fusion, Cell lineage Number-----
                    }
                }
                
                delete [] lineageAuto;
                lineageAuto = new int [lineageDataTempCount+50];
                lineageAutoCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataTempCount; counter1++) lineageAuto [lineageAutoCount] = lineageDataTemp [counter1], lineageAutoCount++;
                
                delete [] lineageDataTemp;
            }
            
            if (processType == 3){
                
                //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
                //	cout<<" lineageEntryExtraction "<<counterA<<endl;
                //}
                
                int *lineageDataTemp = new int [lineageDataCount+50];
                int lineageDataTempCount = 0;
                
                for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                    if (arrayLineageExtraction [counter1*8+5] != delCellNo){
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8], lineageDataTempCount++; //-----X Position-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+1], lineageDataTempCount++; //-----Y Position-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+2], lineageDataTempCount++; //-----Time point-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+3], lineageDataTempCount++;
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+5], lineageDataTempCount++; //-----Cell Number-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                    }
                    else if (arrayLineageExtraction [counter1*8+5] == delCellNo && arrayLineageExtraction [counter1*8+2] < startPointSet){
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8], lineageDataTempCount++; //-----X Position-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+1], lineageDataTempCount++; //-----Y Position-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+2], lineageDataTempCount++; //-----Time point-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+3], lineageDataTempCount++;
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+4], lineageDataTempCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+5], lineageDataTempCount++; //-----Cell Number-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+6], lineageDataTempCount++; //-----Cell Lineage Number-----
                        lineageDataTemp [lineageDataTempCount] = arrayLineageExtraction [counter1*8+7], lineageDataTempCount++; //-----For Fusion, Cell lineage Number-----
                    }
                    else{
                        
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8], lineageEntryExtractionCount++; //-----X Position-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+1], lineageEntryExtractionCount++; //-----Y Position-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+2], lineageEntryExtractionCount++; //-----Time point-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+3], lineageEntryExtractionCount++;
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+4], lineageEntryExtractionCount++; //-----Next Cell number, Fusion: hold cell number of Fusion partner-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+5], lineageEntryExtractionCount++; //-----Cell Number-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+6], lineageEntryExtractionCount++; //-----Cell Lineage Number-----
                        lineageEntryExtraction [lineageEntryExtractionCount] = arrayLineageExtraction [counter1*8+7], lineageEntryExtractionCount++; //-----For Fusion, Cell lineage Number-----
                    }
                }
                
                delete [] arrayLineageExtraction;
                arrayLineageExtraction = new int [lineageDataTempCount+50];
                lineageExtractionCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataTempCount; counter1++) arrayLineageExtraction [lineageExtractionCount] = lineageDataTemp [counter1], lineageExtractionCount++;
                
                //for (int counterA = 0; counterA < lineageDataTempCount/8; counterA++){
                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageDataTemp [counterA*8 +counterB];
                //	cout<<" lineageDataTemp "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
                //	cout<<" lineageEntryExtraction "<<counterA<<endl;
                //}
                
                delete [] lineageDataTemp;
            }
            
            //for (int counterA = 0; counterA < lineageDataTempCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageDataTemp [counterA*8 +counterB];
            //	cout<<" lineageDataTemp "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
            //	cout<<" lineageEntryExtraction "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < lineageAutoCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageAuto [counterA*8 +counterB];
            //	cout<<" lineageAuto "<<counterA<<endl;
            //}
            
            int dataTemp = 0;
            
            if (processType == 1){
                char *writingArray = new char [lineageAutoCount/8*25+25];
                
                unsigned long indexCount = 0;
                int readBit [4];
                
                for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                    if (lineageAuto [counter1*8] < 0){
                        writingArray [indexCount] = 1, indexCount++;
                        dataTemp = lineageAuto [counter1*8]*-1;
                    }
                    else{
                        
                        writingArray [indexCount] = 0, indexCount++;
                        dataTemp = lineageAuto [counter1*8];
                    }
                    
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    if (lineageAuto [counter1*8+1] < 0){
                        writingArray [indexCount] = 1, indexCount++;
                        dataTemp = lineageAuto [counter1*8+1]*-1;
                    }
                    else{
                        
                        writingArray [indexCount] = 0, indexCount++;
                        dataTemp = lineageAuto [counter1*8+1];
                    }
                    
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    dataTemp = lineageAuto [counter1*8+2];
                    readBit [0] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [1] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    
                    writingArray [indexCount] = (char)lineageAuto [counter1*8+3], indexCount++;
                    
                    if (lineageAuto [counter1*8+4] < 0){
                        writingArray [indexCount] = 1, indexCount++;
                        dataTemp = lineageAuto [counter1*8+4]*-1;
                    }
                    else{
                        
                        writingArray [indexCount] = 0, indexCount++;
                        dataTemp = lineageAuto [counter1*8+4];
                    }
                    
                    readBit [0] = dataTemp/16777216;
                    dataTemp = dataTemp%16777216;
                    readBit [1] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [2] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [3] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                    
                    if (lineageAuto [counter1*8+5] < 0){
                        writingArray [indexCount] = 1, indexCount++;
                        dataTemp = lineageAuto [counter1*8+5]*-1;
                    }
                    else{
                        
                        writingArray [indexCount] = 0, indexCount++;
                        dataTemp = lineageAuto [counter1*8+5];
                    }
                    
                    readBit [0] = dataTemp/16777216;
                    dataTemp = dataTemp%16777216;
                    readBit [1] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [2] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [3] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                    
                    dataTemp = lineageAuto [counter1*8+6];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                    
                    dataTemp = lineageAuto [counter1*8+7];
                    readBit [0] = dataTemp/65536;
                    dataTemp = dataTemp%65536;
                    readBit [1] = dataTemp/256;
                    dataTemp = dataTemp%256;
                    readBit [2] = dataTemp;
                    
                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                }
                
                for (int counter1 = 0; counter1 < 25; counter1++) writingArray [indexCount] = 0, indexCount++;
                
                ofstream outfile (connectDataLineagePath.c_str(), ofstream::binary);
                outfile.write ((char*) writingArray, indexCount);
                outfile.close();
                
                delete [] writingArray;
            }
            
            //-----Duplicated image number point remove-----
            if (processType == 1){
                for (int counter1 = 0; counter1 < lineageEntryExtractionCount/8-1; counter1++){
                    if (lineageEntryExtraction [counter1*8+2] != 0){
                        for (int counter2 = counter1+1; counter2 < lineageEntryExtractionCount/8; counter2++){
                            if (lineageEntryExtraction [counter2*8+2] == lineageEntryExtraction [counter1*8+2]) lineageEntryExtraction [counter2*8+2] = 0;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < lineageEntryExtractionCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageEntryExtraction [counterA*8 +counterB];
            //	cout<<" lineageEntryExtraction "<<counterA<<endl;
            //}
            
            //-----Master Rev and Status process-----
            string imagePositionString;
            string connectDataPath;
            string connectStatusDataPath;
            string connectRelationPath;
            
            int connectNoGet = 0;
            int stepCount = 0;
            int modifyStartFlag = 0;
            int modifyDataTempCount = 0;
            int expandTempCount = 0;
            int expandDataTempCount = 0;
            int expandTempCount2 = 0;
            int expandDataTempCount2 = 0;
            int mainDeletionError = 0;
            int readBit [4];
            int finData [19];
            unsigned long readPosition = 0;
            unsigned long indexCount = 0;
            
            for (int counter1 = 0; counter1 < lineageEntryExtractionCount/8; counter1++){
                mainDeletionError = 0;
                
                if (lineageEntryExtraction [counter1*8+2] != 0){
                    imagePositionString = to_string(lineageEntryExtraction [counter1*8+2]);
                    
                    if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                    else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                    else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                    
                    connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
                    
                    connectNoGet = 0;
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    //-----Master Data upLoad-----
                    readingError = 0;
                    
                    if (checkFlag == 1){
                        fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            readPosition = 0;
                            stepCount = 0;
                            modifyStartFlag = -1;
                            
                            do{
                                
                                if (stepCount == 0){
                                    readPosition = readPosition+5;
                                    
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                    
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                    
                                    if (finData [7] == 0 && finData [16] == 0) stepCount = 3;
                                    else{
                                        
                                        if (processType == 1){
                                            if (finData [16] == connectNoDel){
                                                connectNoGet = finData [7];
                                                
                                                uploadTemp [readPosition-1] = 0;
                                                uploadTemp [readPosition-2] = 0;
                                                uploadTemp [readPosition-3] = 0;
                                                uploadTemp [readPosition-4] = 0;
                                                uploadTemp [readPosition-5] = 0;
                                                uploadTemp [readPosition-6] = 0;
                                                uploadTemp [readPosition-7] = 0;
                                                uploadTemp [readPosition-8] = 0;
                                                uploadTemp [readPosition-9] = 0;
                                            }
                                        }
                                        else if (processType == 2 || processType == 3){
                                            if (finData [16] == connectNoDel && finData [12] == delCellNo && modifyStartFlag == -1){
                                                modifyStartFlag = finData [16];
                                                connectNoGet = finData [7];
                                                
                                                uploadTemp [readPosition-1] = 0;
                                                uploadTemp [readPosition-2] = 0;
                                                uploadTemp [readPosition-3] = 0;
                                                uploadTemp [readPosition-4] = 0;
                                                uploadTemp [readPosition-5] = 0;
                                                uploadTemp [readPosition-6] = 0;
                                                uploadTemp [readPosition-7] = 0;
                                                uploadTemp [readPosition-8] = 0;
                                                uploadTemp [readPosition-9] = 0;
                                            }
                                            else if (finData [12] == delCellNo && modifyStartFlag == finData [16]){
                                                uploadTemp [readPosition-1] = 0;
                                                uploadTemp [readPosition-2] = 0;
                                                uploadTemp [readPosition-3] = 0;
                                                uploadTemp [readPosition-4] = 0;
                                                uploadTemp [readPosition-5] = 0;
                                                uploadTemp [readPosition-6] = 0;
                                                uploadTemp [readPosition-7] = 0;
                                                uploadTemp [readPosition-8] = 0;
                                                uploadTemp [readPosition-9] = 0;
                                            }
                                            else if (modifyStartFlag != -1 && modifyStartFlag != finData [16]){
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            ofstream outfile (connectDataPath.c_str(), ofstream::binary);
                            outfile.write ((char*)uploadTemp, sizeForCopy);
                            outfile.close();
                        }
                        
                        delete [] uploadTemp;
                    }
                    
                    if (checkFlag == 0 || readingError == 1) mainDeletionError = 1;
                    
                    //for (int counterA = 0; counterA < modifyDataTempCount4/7; counterA++){
                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<modifyDataTemp4 [counterA*7+counterB];
                    //	cout<<" modifyDataTemp4 "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < modifyDataTempCount2/6; counterA++){
                    //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<modifyDataTemp2 [counterA*6+counterB];
                    //	cout<<" modifyDataTemp2 "<<counterA<<endl;
                    //}
                    
                    connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameAuto+"_Status";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    readingError = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                                readingError = 1;
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    readPosition = readPosition+13;
                                    
                                    finData [13] = uploadTemp [readPosition], readPosition++;
                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                    finData [15] = uploadTemp [readPosition], readPosition++; //--9 Connect no
                                    finData [16] = uploadTemp [readPosition], readPosition++;
                                    finData [17] = uploadTemp [readPosition], readPosition++;
                                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Lineage no
                                    
                                    finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                    finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                    
                                    if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                    else{
                                        
                                        if (processType == 1){
                                            if (finData [18] == connectNoDel){
                                                uploadTemp [readPosition-19] = 0;
                                                uploadTemp [readPosition-1] = 0;
                                                uploadTemp [readPosition-2] = 0;
                                                uploadTemp [readPosition-3] = 0;
                                            }
                                        }
                                        
                                        if (processType == 2 || processType == 3){
                                            if (finData [18] == connectNoDel && finData [15] == connectNoGet){
                                                uploadTemp [readPosition-19] = 0;
                                                uploadTemp [readPosition-1] = 0;
                                                uploadTemp [readPosition-2] = 0;
                                                uploadTemp [readPosition-3] = 0;
                                            }
                                        }
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            ofstream outfile3 (connectStatusDataPath.c_str(), ofstream::binary);
                            outfile3.write ((char*)uploadTemp, sizeForCopy);
                            outfile3.close();
                        }
                        
                        delete [] uploadTemp;
                        
                        //for (int counterA = 0; counterA < modifyDataTempCount/10; counterA++){
                        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<modifyDataTemp [counterA*10+counterB];
                        //	cout<<" modifyDataTemps "<<counterA<<endl;
                        //}
                    }
                    
                    if (readingError == 1) mainDeletionError = 1;
                    
                    //=========1. Lineage No, 2. connect No, 3. image number, 4. cell no, 5. target (0: non-target, 1: target), 6. reserve=========
                    connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameAuto+"_ConnectLineageRel";
                    
                    sizeForCopy = 0;
                    
                    if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    readingError = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                                readingError = 1;
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            int *modifyDataTemp = new int [sizeForCopy+50];
                            modifyDataTempCount = 0;
                            
                            readPosition = 0;
                            stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                    finData [3] = uploadTemp [readPosition], readPosition++;
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                    finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                    finData [7] = finData [6]*256+finData [7];
                                    
                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                    
                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                    else{
                                        
                                        if (processType == 1){
                                            if (finData [2] != connectNoDel){
                                                modifyDataTemp [modifyDataTempCount] = finData [2], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [5], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [7], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [12], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [13], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [14], modifyDataTempCount++;
                                            }
                                        }
                                        else if (processType == 2 || processType == 3){
                                            if (finData [2] != connectNoDel || finData [12] != delCellNo){
                                                modifyDataTemp [modifyDataTempCount] = finData [2], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [5], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [7], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [12], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [13], modifyDataTempCount++;
                                                modifyDataTemp [modifyDataTempCount] = finData [14], modifyDataTempCount++;
                                            }
                                        }
                                    }
                                }
                                
                            } while (stepCount != 3);
                            
                            //for (int counterA = 0; counterA < modifyDataTempCount3/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<modifyDataTemp3 [counterA*6+counterB];
                            //	cout<<" modifyDataTemp3 "<<counterA<<endl;
                            //}
                            
                            char *writingArray = new char [modifyDataTempCount/6*16+16];
                            
                            indexCount = 0;
                            
                            for (int counter2 = 0; counter2 < modifyDataTempCount/6; counter2++){
                                dataTemp = modifyDataTemp [counter2*6];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = modifyDataTemp [counter2*6+1];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                dataTemp = modifyDataTemp [counter2*6+2];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                if (modifyDataTemp [counter2*6+3] < 0){
                                    writingArray [indexCount] = 1, indexCount++;
                                    dataTemp = modifyDataTemp [counter2*6+3]*-1;
                                }
                                else{
                                    
                                    writingArray [indexCount] = 0, indexCount++;
                                    dataTemp = modifyDataTemp [counter2*6+3];
                                }
                                
                                readBit [0] = dataTemp/16777216;
                                dataTemp = dataTemp%16777216;
                                readBit [1] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [2] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [3] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                
                                writingArray [indexCount] = (char)modifyDataTemp [counter2*6+4], indexCount++;
                                writingArray [indexCount] = (char)modifyDataTemp [counter2*6+5], indexCount++;
                            }
                            
                            for (int counter2 = 0; counter2 < 15; counter2++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                            outfile3.write ((char*) writingArray, indexCount);
                            outfile3.close();
                            
                            delete [] writingArray;
                            delete [] modifyDataTemp;
                        }
                        
                        delete [] uploadTemp;
                    }
                    
                    if (readingError == 1) mainDeletionError = 1;
                    
                    //-----Fluorescent deletion-----
                    connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameAuto+"_ExtendLineData";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    readingError = 0;
                    
                    if (checkFlag == 1){
                        int *arrayExpandTemp = new int [sizeForCopy+50];
                        expandTempCount = 0;
                        
                        fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayExpandTemp [expandTempCount] = finData [1], expandTempCount++;
                                            arrayExpandTemp [expandTempCount] = finData [3], expandTempCount++;
                                            arrayExpandTemp [expandTempCount] = finData [6], expandTempCount++;
                                            arrayExpandTemp [expandTempCount] = finData [7], expandTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        int *arrayExpandTemp2 = new int [sizeForCopy+50];
                        expandTempCount2 = 0;
                        
                        for (int counter2 = 0; counter2 < expandTempCount/4; counter2++){
                            if (arrayExpandTemp [counter2*4+2] != connectNoGet){
                                arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter2*4], expandTempCount2++;
                                arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter2*4+1], expandTempCount2++;
                                arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter2*4+2], expandTempCount2++;
                                arrayExpandTemp2 [expandTempCount2] = arrayExpandTemp [counter2*4+3], expandTempCount2++;
                            }
                        }
                        
                        delete [] arrayExpandTemp;
                        
                        if (expandTempCount2 != 0){
                            indexCount = 0;
                            char *writingArray = new char [expandTempCount2*2+200];
                            
                            for (int counter2 = 0; counter2 < expandTempCount2/4; counter2++){
                                dataTemp = arrayExpandTemp2 [counter2*4];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = arrayExpandTemp2 [counter2*4+1];
                                readBit [0] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [1] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                
                                dataTemp = arrayExpandTemp2 [counter2*4+2];
                                readBit [0] = dataTemp/65536;
                                dataTemp = dataTemp%65536;
                                readBit [1] = dataTemp/256;
                                dataTemp = dataTemp%256;
                                readBit [2] = dataTemp;
                                
                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                
                                writingArray [indexCount] = (char)arrayExpandTemp2 [counter2*4+3], indexCount++;
                            }
                            
                            for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                            
                            ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                            outfile3.write ((char*)writingArray, indexCount);
                            outfile3.close();
                            
                            delete [] writingArray;
                        }
                        else remove(connectRelationPath.c_str());
                        
                        delete [] arrayExpandTemp2;
                        
                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+imagePositionString+"_"+analysisID+"_"+treatmentNameAuto+"_ExtendAreaData";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            int *arrayExpandDataTemp = new int [sizeForCopy+50];
                            expandDataTempCount = 0;
                            
                            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayExpandDataTemp [expandDataTempCount] = finData [2], expandDataTempCount++;
                                            arrayExpandDataTemp [expandDataTempCount] = finData [3], expandDataTempCount++;
                                            arrayExpandDataTemp [expandDataTempCount] = finData [4], expandDataTempCount++;
                                            arrayExpandDataTemp [expandDataTempCount] = finData [7], expandDataTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                            
                            int *arrayExpandDataTemp2 = new int [expandDataTempCount+50];
                            expandDataTempCount2 = 0;
                            
                            for (int counter2 = 0; counter2 < expandDataTempCount/4; counter2++){
                                if (arrayExpandDataTemp [counter2*4] != connectNoGet){
                                    arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter2*4], expandDataTempCount2++;
                                    arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter2*4+1], expandDataTempCount2++;
                                    arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter2*4+2], expandDataTempCount2++;
                                    arrayExpandDataTemp2 [expandDataTempCount2] = arrayExpandDataTemp [counter2*4+3], expandDataTempCount2++;
                                }
                            }
                            
                            delete [] arrayExpandDataTemp;
                            
                            if (expandDataTempCount2 != 0){
                                indexCount = 0;
                                char *writingArray = new char [expandDataTempCount2*2+20];
                                
                                for (int counter2 = 0; counter2 < expandDataTempCount2/4; counter2++){
                                    dataTemp = arrayExpandDataTemp2 [counter2*4];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)arrayExpandDataTemp2 [counter2*4+1], indexCount++;
                                    writingArray [indexCount] = (char)arrayExpandDataTemp2 [counter2*4+2], indexCount++;
                                    
                                    dataTemp = arrayExpandDataTemp2 [counter2*4+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile3 (connectRelationPath.c_str(), ofstream::binary);
                                outfile3.write ((char*)writingArray, indexCount);
                                outfile3.close();
                                
                                delete [] writingArray;
                            }
                            else remove(connectRelationPath.c_str());
                            
                            delete [] arrayExpandDataTemp2;
                        }
                    }
                }
                
                if (mainDeletionError == 1){
                    break;
                }
            }
            
            //for (int counterA = 0; counterA < lineageAutoCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageAuto [counterA*8+counterB];
            //	cout<<" lineageAuto "<<counterA<<endl;
            //}
            
            if (mainDeletionError == 0){
                //==========1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
                if (processType == 1){
                    lineageStartEndAutoCount = 0;
                    int cellNumberStart = -1;
                    int lineageNumberStart = 0;
                    int firstEntryFind = 0;
                    
                    for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                        if ((lineageAuto [counter1*8+6] != lineageNumberStart || lineageAuto [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                            lineageNumberStart = lineageAuto [counter1*8+6];
                            cellNumberStart = lineageAuto [counter1*8+5];
                            
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageNumberStart, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = cellNumberStart, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8], lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8+1], lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8+2], lineageStartEndAutoCount++;
                            
                            firstEntryFind = 1;
                        }
                        else if ((lineageAuto [counter1*8+6] != lineageNumberStart || lineageAuto [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                            lineageNumberStart = lineageAuto [counter1*8+6];
                            cellNumberStart = lineageAuto [counter1*8+5];
                            
                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1-1, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [(counter1-1)*8+2], lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageNumberStart, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = cellNumberStart, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8], lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8+1], lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8+2], lineageStartEndAutoCount++;
                        }
                        
                        if (counter1 == lineageAutoCount/8-1){
                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1, lineageStartEndAutoCount++;
                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageAuto [counter1*8+2], lineageStartEndAutoCount++;
                        }
                        
                        if (lineageStartEndAutoCount+24 > lineageStartEndAutoLimit){
                            int *arrayUpDate = new int [lineageStartEndAutoCount+10];
                            
                            for (int counter2 = 0; counter2 < lineageStartEndAutoCount; counter2++) arrayUpDate [counter2] = lineageStartEndAuto [counter2];
                            
                            delete [] lineageStartEndAuto;
                            lineageStartEndAuto = new int [lineageStartEndAutoLimit+5000];
                            lineageStartEndAutoLimit = lineageStartEndAutoLimit+5000;
                            
                            for (int counter2 = 0; counter2 < lineageStartEndAutoCount; counter2++) lineageStartEndAuto [counter2] = arrayUpDate [counter2];
                            delete [] arrayUpDate;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageStartEndAutoCount/8; counterA++){
                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageStartEndAuto [counterA*8 +counterB];
                    //	cout<<" lineageStartEndAuto "<<counterA<<endl;
                    //}
                    
                    if (lineageStartEndAutoCount != 0){
                        char *mainDataEntry = new char [lineageStartEndAutoCount*7+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndAutoCount; counter1++){
                            extension = to_string(lineageStartEndAuto [counter1]);
                            
                            for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
                        outfile2.write (mainDataEntry, totalEntryCount);
                        outfile2.close();
                        
                        delete [] mainDataEntry;
                    }
                }
                
                //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                int *modifyDataTemp = new int [lineageStatusAutoCount+50];
                modifyDataTempCount = 0;
                
                if (processType == 1){
                    for (int counter1 = 0; counter1 < lineageStatusAutoCount/3; counter1++){
                        if (lineageStatusAuto [counter1*3] != connectNoDel){
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3], modifyDataTempCount++;
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3+1], modifyDataTempCount++;
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3+2], modifyDataTempCount++;
                        }
                    }
                }
                
                if (processType == 3){
                    for (int counter1 = 0; counter1 < lineageStatusAutoCount/3; counter1++){
                        if (lineageStatusAuto [counter1*3] != connectNoDel){
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3], modifyDataTempCount++;
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3+1], modifyDataTempCount++;
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3+2], modifyDataTempCount++;
                        }
                        if (lineageStatusAuto [counter1*3] == connectNoDel){
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3], modifyDataTempCount++;
                            
                            if (lineageStatusAuto [counter1*3+1] == 1 || lineageStatusAuto [counter1*3+1] == 0) modifyDataTemp [modifyDataTempCount] = 0, modifyDataTempCount++;
                            else modifyDataTemp [modifyDataTempCount] = 2, modifyDataTempCount++;
                            
                            modifyDataTemp [modifyDataTempCount] = lineageStatusAuto [counter1*3+2], modifyDataTempCount++;
                        }
                    }
                }
                
                lineageStatusAutoCount = 0;
                for (int counter1 = 0; counter1 < modifyDataTempCount; counter1++) lineageStatusAuto [lineageStatusAutoCount] = modifyDataTemp [counter1], lineageStatusAutoCount++;
                
                //for (int counterA = 0; counterA < lineageStatusAutoCount/3; counterA++){
                //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<lineageStatusAuto [counterA*3+counterB];
                //	cout<<" lineageStatusAuto "<<counterA<<endl;
                //}
                
                char *mainDataEntry = new char [modifyDataTempCount*6+10];
                int totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < modifyDataTempCount; counter1++){
                    extension = to_string(modifyDataTemp [counter1]);
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile2 (connectDataStatus.c_str(), ofstream::binary);
                outfile2.write (mainDataEntry, totalEntryCount);
                outfile2.close();
                
                delete [] mainDataEntry;
                delete [] modifyDataTemp;
                
                //=========Queue List creation==========
                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                //	cout<<" arrayQueueList "<<counterA<<endl;
                //}
                
                string cellLineageString = to_string(connectNoDel);
                
                if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
                else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
                else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
                else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
                else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
                
                string cellNumberString = to_string(delCellNo);
                
                if (delCellNo >= 0){
                    if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                    else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                    else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                    else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                    else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                    else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                    else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                    else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                    else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                }
                else{
                    
                    cellNumberString = cellNumberString.substr(1);
                    
                    if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                    else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                    else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                    else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                    else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                    else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                    else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                    else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                    else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                }
                
                string *modifyDataStringTemp = new string [queueListCount+50];
                int modifyDataStringTempCount = 0;
                
                if (processType == 1){
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != cellLineageString){
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+1], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+2], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+3], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+4], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+5], modifyDataStringTempCount++;
                        }
                    }
                }
                
                if (processType == 3){
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != cellLineageString || arrayQueueList [counter1*6+2] != cellNumberString){
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+1], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+2], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+3], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+4], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayQueueList [counter1*6+5], modifyDataStringTempCount++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                //    cout<<" arrayQueueList "<<counterA<<endl;
                //}
                
                queueListCount = 0;
                
                for (int counter1 = 0; counter1 < modifyDataStringTempCount; counter1++) arrayQueueList [queueListCount] = modifyDataStringTemp [counter1], queueListCount++;
                
                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                
                if (queueListCount != 0){
                    mainDataEntry = new char [queueListCount*12+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount; counter1++){
                        extension = arrayQueueList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                    outfile3.write (mainDataEntry, totalEntryCount);
                    outfile3.close();
                    
                    delete [] mainDataEntry;
                }
                
                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                //	cout<<" arrayQueueList "<<counterA<<endl;
                //}
                
                delete [] modifyDataStringTemp;
                
                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                //	cout<<" doneListCount "<<counterA<<endl;
                //}
                
                //=========Done List UpDate==========
                //-----1. Treatment name, 2. Lineage No, 3. Cell number/Whole image, 4. Image number, 5. Check status-----
                //-----Check Status: OK, LST, CFU, CDD, CTD, CHD, UN-----
                
                modifyDataStringTemp = new string [doneListCount+50];
                modifyDataStringTempCount = 0;
                
                if (processType == 1){
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != cellLineageString){
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+1], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+2], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+3], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+4], modifyDataStringTempCount++;
                        }
                    }
                }
                
                if (processType == 3){
                    for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                        if (arrayDoneList [counter1*5] != treatmentNameAuto || arrayDoneList [counter1*5+1] != cellLineageString || arrayDoneList [counter1*5+2] != cellNumberString){
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+1], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+2], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+3], modifyDataStringTempCount++;
                            modifyDataStringTemp [modifyDataStringTempCount] = arrayDoneList [counter1*5+4], modifyDataStringTempCount++;
                        }
                    }
                }
                
                doneListCount = 0;
                for (int counter1 = 0; counter1 < modifyDataStringTempCount; counter1++) arrayDoneList [doneListCount] = modifyDataStringTemp [counter1], doneListCount++;
                
                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                //	cout<<" arrayDoneList "<<counterA<<endl;
                //}
                
                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                
                if (doneListCount != 0){
                    mainDataEntry = new char [doneListCount*10+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < doneListCount; counter1++){
                        extension = arrayDoneList [counter1];
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile9 (doneListPath.c_str(), ofstream::binary);
                    outfile9.write (mainDataEntry, totalEntryCount);
                    outfile9.close();
                    
                    delete [] mainDataEntry;
                }
                
                delete [] modifyDataStringTemp;
                
                //-----Folder deletion-----
                if (processType == 1){
                    string lineageFolderPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+cellLineageString;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    dir = opendir(lineageFolderPath.c_str());
                    fileDeleteCount = 0;
                    
                    if (dir != NULL){
                        string entry;
                        string entry2;
                        string cellFolderPath;
                        string cellFolderPath2;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            cellFolderPath = lineageFolderPath+"/"+entry;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                dir2 = opendir(cellFolderPath.c_str());
                                
                                if (dir2 != NULL){
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate fileDeleteUpDate];
                                        }
                                        
                                        arrayFileDelete [fileDeleteCount] = cellFolderPath+"/"+entry2, fileDeleteCount++;
                                    }
                                    
                                    closedir(dir2);
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                        remove (arrayFileDelete [counter1].c_str());
                    }
                    
                    fileDeleteCount = 0;
                    
                    dir = opendir(lineageFolderPath.c_str());
                    
                    if (dir != NULL){
                        string entry;
                        string cellFolderPath;
                        
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                            cellFolderPath = lineageFolderPath+"/"+arrayFileDelete [counter1];
                            remove (cellFolderPath.c_str());
                            rmdir (cellFolderPath.c_str());
                        }
                        
                        rmdir (lineageFolderPath.c_str());
                    }
                }
                
                if (processType == 3){
                    string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+cellLineageString+"/"+analysisID+"_"+cellLineageString+"_CellStatus";
                    
                    sizeForCopy = 0;
                    
                    if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    int *masterReadForCellInfo = new int [sizeForCopy+50];
                    int masterReadForCellInfoCount = 0;
                    
                    if (sizeForCopy != 0){
                        fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            char *uploadTemp = new char [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            fin.close();
                            
                            string dataString = "";
                            readPosition = 0;
                            
                            do{
                                
                                if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                else if (dataString != "End"){
                                    masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                                    dataString = "";
                                }
                                
                                readPosition++;
                                
                            } while (dataString != "End");
                            
                            delete [] uploadTemp;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                        if (masterReadForCellInfo [counter1*7] == delCellNo){
                            masterReadForCellInfo [counter1*7+2] = -1;
                            masterReadForCellInfo [counter1*7+4] = 0;
                            masterReadForCellInfo [counter1*7+5] = 0;
                            break;
                        }
                    }
                    
                    mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                    totalEntryCount = 0;
                    
                    for (int counter1 = 0; counter1 < masterReadForCellInfoCount; counter1++){
                        extension = to_string(masterReadForCellInfo [counter1]);
                        
                        for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                    
                    ofstream outfile12 (lineageFolderPath2.c_str(), ofstream::binary);
                    outfile12.write (mainDataEntry, totalEntryCount);
                    outfile12.close();
                    
                    delete [] mainDataEntry;
                    delete [] masterReadForCellInfo;
                }
                
                //=======Lineage partner line=======
                string cellFusionPartnerPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_FusionPartner";
                
                sizeForCopy = 0;
                
                if (stat(cellFusionPartnerPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    string *arrayLineagePartnerInfoTemp = new string [sizeForCopy+50];
                    int lineagePartnerInfoTempCount = 0;
                    
                    string *arrayLineagePartnerInfoTemp2 = new string [sizeForCopy+50];
                    int lineagePartnerInfoTempCount2 = 0;
                    
                    fin.open(cellFusionPartnerPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        string treatmentNameGet;
                        string lineageNoGet;
                        string cellNoGet;
                        string imageNoGet;
                        string partnerLingNoGet;
                        string partnerCellNoGet;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            getline(fin, treatmentNameGet);
                            
                            if (treatmentNameGet == "") terminationFlag = 0;
                            else{
                                
                                getline(fin, lineageNoGet);
                                getline(fin, cellNoGet);
                                getline(fin, imageNoGet);
                                getline(fin, partnerLingNoGet);
                                getline(fin, partnerCellNoGet);
                                
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = treatmentNameGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = lineageNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = cellNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = imageNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerLingNoGet, lineagePartnerInfoTempCount++;
                                arrayLineagePartnerInfoTemp [lineagePartnerInfoTempCount] = partnerCellNoGet, lineagePartnerInfoTempCount++;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                    
                    string lingNoTemp;
                    string cellNoTemp;
                    string imageNoTemp;
                    
                    for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                        if (lineageAuto [counter1*8+3] == 10){
                            for (int counter2 = 0; counter2 < lineagePartnerInfoTempCount/6; counter2++){
                                lingNoTemp = arrayLineagePartnerInfoTemp [counter2*6+1];
                                cellNoTemp = arrayLineagePartnerInfoTemp [counter2*6+2];
                                imageNoTemp = arrayLineagePartnerInfoTemp [counter2*6+3];
                                
                                if (arrayLineagePartnerInfoTemp [counter2*6] == treatmentNameAuto && atoi(lingNoTemp.c_str()) == lineageAuto [counter1*8+6] && atoi(cellNoTemp.c_str()) == lineageAuto [counter1*8+5] && atoi(imageNoTemp.c_str()) == lineageAuto [counter1*8+2]){
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+1], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+2], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+3], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+4], lineagePartnerInfoTempCount2++;
                                    arrayLineagePartnerInfoTemp2 [lineagePartnerInfoTempCount2] = arrayLineagePartnerInfoTemp [counter2*6+5], lineagePartnerInfoTempCount2++;
                                }
                            }
                        }
                    }
                    
                    if (lineagePartnerInfoTempCount2 != 0){
                        ofstream oin;
                        oin.open(cellFusionPartnerPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < lineagePartnerInfoTempCount2; counter1++) oin<<arrayLineagePartnerInfoTemp2 [counter1]<<endl;
                        
                        oin.close();
                    }
                    else remove (cellFusionPartnerPath.c_str());
                    
                    delete [] arrayLineagePartnerInfoTemp;
                    delete [] arrayLineagePartnerInfoTemp2;
                }
                
                //=======Mitosis Set array=======
                string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_MitosisData";
                
                size1 = 0;
                size2 = 0;
                checkFlag = 0;
                
                for (int counter4 = 0; counter4 < 6; counter4++){
                    sizeForCopy = 0;
                    
                    if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter4 == 0) size1 = sizeForCopy;
                        else if (counter4 == 1) size2 = sizeForCopy;
                        else if (counter4 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter4 == 3) size1 = sizeForCopy;
                        else if (counter4 == 4) size2 = sizeForCopy;
                        else if (counter4 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                int *arrayMitosisTemp = new int [sizeForCopy+50];
                int mitosisTempCount = 0;
                int *arrayMitosisTemp2 = new int [sizeForCopy+50];
                int mitosisTempCount2 = 0;
                int *arrayMitosisTemp3 = new int [sizeForCopy+50];
                int mitosisTempCount3 = 0;
                
                if (checkFlag == 1){
                    fin.open(mitosisStatusPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        string lineageNoGet;
                        string cellNoGet;
                        string imageNoGet;
                        string setTypeGet;
                        
                        int terminationFlag = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            getline(fin, lineageNoGet);
                            
                            if (lineageNoGet == "") terminationFlag = 0;
                            else{
                                
                                getline(fin, cellNoGet);
                                getline(fin, imageNoGet);
                                getline(fin, setTypeGet);
                                
                                arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                            }
                            
                        } while (terminationFlag == 1);
                        
                        fin.close();
                    }
                    
                    if (processType == 1){
                        for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                            if (arrayMitosisTemp [counter1*4] != connectNoDel){
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                                arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                        //    cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                        //}
                        
                        if (mitosisTempCount2 != 0){
                            ofstream oin;
                            oin.open(mitosisStatusPath.c_str(), ios::out);
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                            
                            oin.close();
                        }
                        else remove (mitosisStatusPath.c_str());
                    }
                }
                
                if (processType == 3){
                    int mitosisSetFind = 0;
                    int lineageFirstPoint = 0;
                    int lineageLastPoint = 0;
                    
                    for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                        if (lineageAuto [counter1*8+6] == connectNoDel && lineageAuto [counter1*8+5] == delCellNo && lineageAuto [counter1*8+2] < startPointSet){
                            if (lineageAuto [counter1*8+3] == 6) mitosisSetFind = lineageAuto [counter1*8+2];
                            if (lineageLastPoint < lineageAuto [counter1*8+2]) lineageLastPoint = lineageAuto [counter1*8+2];
                            if (lineageFirstPoint == 0) lineageFirstPoint = lineageAuto [counter1*8+2];
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < mitosisTempCount/4; counter1++){
                        if (arrayMitosisTemp [counter1*4] != connectNoDel || arrayMitosisTemp [counter1*4+1] != delCellNo){
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+1], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+2], mitosisTempCount2++;
                            arrayMitosisTemp2 [mitosisTempCount2] = arrayMitosisTemp [counter1*4+3], mitosisTempCount2++;
                        }
                        else{
                            
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4], mitosisTempCount3++;
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+1], mitosisTempCount3++;
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+2], mitosisTempCount3++;
                            arrayMitosisTemp3 [mitosisTempCount3] = arrayMitosisTemp [counter1*4+3], mitosisTempCount3++;
                        }
                    }
                    
                    int *arrayMitosisTemp4 = new int [(lineageLastPoint-lineageFirstPoint+1)*4+50];
                    int mitosisTempCount4 = 0;
                    
                    for (int counter1 = lineageFirstPoint; counter1 <= lineageLastPoint; counter1++){
                        arrayMitosisTemp4 [mitosisTempCount4] = connectNoDel, mitosisTempCount4++;
                        arrayMitosisTemp4 [mitosisTempCount4] = delCellNo, mitosisTempCount4++;
                        arrayMitosisTemp4 [mitosisTempCount4] = counter1, mitosisTempCount4++;
                        
                        if (mitosisSetFind != 0 && mitosisSetFind == counter1) arrayMitosisTemp4 [mitosisTempCount4] = 10, mitosisTempCount4++;
                        else arrayMitosisTemp4 [mitosisTempCount4] = 0, mitosisTempCount4++;
                    }
                    
                    if (mitosisSetFind == 0){
                        int prevFirstPoint = 0;
                        int prevLastPoint = 0;
                        
                        for (int counter1 = 0; counter1 < mitosisTempCount3/4; counter1++){
                            if (prevFirstPoint == 0) prevFirstPoint = arrayMitosisTemp3 [counter1*4+2];
                            
                            prevLastPoint = arrayMitosisTemp3 [counter1*4+2];
                        }
                        
                        if (prevFirstPoint < lineageFirstPoint) prevFirstPoint = lineageFirstPoint;
                        if (prevLastPoint > lineageLastPoint) prevLastPoint = lineageLastPoint;
                        if (prevFirstPoint > lineageLastPoint || prevLastPoint < lineageFirstPoint) prevFirstPoint = 0;
                        
                        if (prevFirstPoint != 0){
                            int prevFind = 0;
                            int prevCount = 0;
                            
                            for (int counter1 = 0; counter1 < mitosisTempCount4/4; counter1++){
                                if (prevLastPoint > prevFirstPoint){
                                    if (arrayMitosisTemp4 [counter1*4+2] == prevFirstPoint){
                                        if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        prevFind = 1;
                                        prevCount++;
                                    }
                                    else if (arrayMitosisTemp4 [counter1*4+2] == prevLastPoint){
                                        if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        prevFind = 0;
                                    }
                                    else if (prevFind == 1){
                                        if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                        
                                        arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                        prevCount++;
                                    }
                                }
                                
                                if (arrayMitosisTemp4 [counter1*4] == prevFirstPoint && prevLastPoint == prevFirstPoint){
                                    if (arrayMitosisTemp3 [prevCount*4+3] == 10) arrayMitosisTemp3 [prevCount*4+3] = 0;
                                    
                                    arrayMitosisTemp4 [counter1*4+3] = arrayMitosisTemp3 [prevCount*4+3];
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < mitosisTempCount2/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp2 [counterA*4+counterB];
                        //    cout<<" arrayMitosisTemp2 "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < mitosisTempCount4/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp4 [counterA*4+counterB];
                        //    cout<<" arrayMitosisTemp4 "<<counterA<<endl;
                        //}
                        
                        ofstream oin;
                        oin.open(mitosisStatusPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < mitosisTempCount2; counter1++) oin<<arrayMitosisTemp2 [counter1]<<endl;
                        for (int counter1 = 0; counter1 < mitosisTempCount4; counter1++) oin<<arrayMitosisTemp4 [counter1]<<endl;
                        
                        oin.close();
                        
                        delete [] arrayMitosisTemp4;
                    }
                }
                
                delete [] arrayMitosisTemp;
                delete [] arrayMitosisTemp2;
                delete [] arrayMitosisTemp3;
                
                returnResults = 1;
            }
            
            delete [] lineageEntryExtraction;
        }
        
        delete [] lineageStatusAuto;
        delete [] lineageStartEndAuto;
    }
    
    delete [] lineageAuto;
    
    return returnResults;
}

@end
