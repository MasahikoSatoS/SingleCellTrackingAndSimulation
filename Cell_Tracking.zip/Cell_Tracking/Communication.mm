//
// Communication.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 10/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "Communication.h"

NSString *notificationToCommunication = @"notificationExecuteCommunication";

@implementation Communication

-(id)init{
    self = [super init];
    
    if (self != nil){
        autoProcessTimingCount = 0;
        autoProcessTiming = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCommunication object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    reviseTimingCount = 0;
    communicationTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(communicationMain) userInfo:nil repeats:YES];
}

-(void)communicationMain{
    //-----Cell Carving process, TrackCave3 outgoing, TrackCave4 incoming-----
    if (queueHoldingStatus == 1){
        if (queueListCount != 0){
            ifstream fin;
            
            if (autoProcessTimingCount >= autoProcessTiming){
                autoProcessTimingCount = 0;
                
                if (connectionSend1 == 1){
                    connectionSend1 = 2;
                    cellCurvingRunningFlag = 1;
                    
                    int sendDataFlag = 0;
                    int positionSwitch = 0;
                    int timeOneComm = 0;
                    int treatmentPosition = 0;
                    int endStatusClear = 0;
                    int ifStartInt = 0;
                    int imageNoCommInt = 0;
                    int checkTimePoint = 0;
                    int checkTimePointIF = 0;
                    int setInterval = 0;
                    int nextFileFind = 0;
                    int nextLoad = 0;
                    int queueStringTempCount = 0;
                    int totalEntryCount = 0;
                    int lineageNoCommInt = 0;
                    int cellNoCommInt = 0;
                    int stepCount = 0;
                    int finData [25];
                    int endStatus = 0;
                    int endImageNo = 0;
                    int startImageNo = 0;
                    int mitosisCheckFind = 0;
                    int doneListUpdateTempCount = 0;
                    int masterReadForCellInfoCount = 0;
                    int lineageOpenStatus = 0;
                    int numberOfEntry = 0;
                    int cellNumberStart = 0;
                    int lineageNumberStart = 0;
                    int firstEntryFind = 0;
                    int queueListUpdateTempCount = 0;
                    int masterReadForAmendCount = 0;
                    int masterReadForLineageInfoCount = 0;
                    int lineageAutoCount = 0;
                    int lineageExtractInt = 0;
                    int cellNoExtractInt = 0;
                    int startEndCommCount = 0;
                    int processType = 0;
                    int newImagePosition = 0;
                    int amendLastEvent = 0;
                    int lineageExtractionCount2 = 0;
                    int readBit [4];
                    int dataTemp = 0;
                    int lineageStartEndAutoCount = 0;
                    int entryCount = 0;
                    int counterComplete = 0;
                    int lineageCommTempCount = 0;
                    int checkFlag = 0;
                    int readingError = 0;
                    int addDeleteStatus = 0;
                    
                    unsigned long readPosition = 0;
                    unsigned long indexCount = 0;
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    
                    string treatmentNameComm;
                    string lineageNoComm;
                    string cellNoComm;
                    string imageNoComm;
                    string redoStatus;
                    string timeIFStart;
                    string treatmentNameComm2;
                    string lineageNoComm2;
                    string cellNoComm2;
                    string imageNoComm2;
                    string redoStatus2;
                    string imageNoLimit;
                    string lineageExtract;
                    string cellNoExtract;
                    string mitosisFind;
                    string imageNoCommTemp;
                    string imageNoCommLimitTemp;
                    string endSettingComm;
                    string extension;
                    string extension2;
                    string fluorescentRoundNoTemp;
                    string dataString;
                    string startImageNoComm;
                    string cellNumberExtract;
                    string dataPath;
                    string imageNoTemp;
                    string statusFuseTemp;
                    
                    struct stat sizeOfFile;
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                        //	cout<<" arrayQueueList "<<counterA<<endl;
                        //}
                        
                        treatmentNameComm = arrayQueueList [counter1*6];
                        lineageNoComm = arrayQueueList [counter1*6+1];
                        cellNoComm = arrayQueueList [counter1*6+2];
                        imageNoComm = arrayQueueList [counter1*6+3];
                        
                        if ((int)imageNoComm.find(":") != -1) imageNoComm = imageNoComm.substr(0, imageNoComm.find(":"));
                        
                        imageNoLimit = arrayQueueList [counter1*6+3];
                        
                        if ((int)imageNoLimit.find(":") != -1) imageNoLimit = imageNoLimit.substr(imageNoLimit.find(":")+1);
                        
                        endSettingComm = arrayQueueList [counter1*6+4];
                        
                        if ((int)endSettingComm.find("/m") != -1) endSettingComm = endSettingComm.substr(0, endSettingComm.find("/m"));
                        
                        redoStatus = arrayQueueList [counter1*6+5];
                        
                        treatmentNameComm2 = arrayQueueList [counter1*6];
                        lineageNoComm2 = arrayQueueList [counter1*6+1];
                        cellNoComm2 = arrayQueueList [counter1*6+2];
                        imageNoComm2 = arrayQueueList [counter1*6+3];
                        
                        if ((int)imageNoComm2.find(":") != -1) imageNoComm2 = imageNoComm2.substr(0, imageNoComm2.find(":"));
                        
                        redoStatus2 = arrayQueueList [counter1*6+5];
                        
                        //cout<<treatmentNameComm<<" "<<lineageNoComm <<" "<<cellNoComm<<" "<<imageNoComm<<" InfoA"<<endl;
                        
                        positionSwitch = 0;
                        
                        for (int counter2 = counter1+1; counter2 < queueListCount/6; counter2++){
                            imageNoCommTemp = arrayQueueList [counter2*6+3];
                            if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
                            
                            imageNoCommLimitTemp = arrayQueueList [counter2*6+3];
                            if ((int)imageNoCommLimitTemp.find(":") != -1) imageNoCommLimitTemp = imageNoCommLimitTemp.substr(imageNoCommLimitTemp.find(":")+1);
                            
                            if (treatmentNameComm == arrayQueueList [counter2*6] && atoi(imageNoComm.c_str()) > atoi(imageNoCommTemp.c_str())){
                                treatmentNameComm = arrayQueueList [counter2*6];
                                lineageNoComm = arrayQueueList [counter2*6+1];
                                cellNoComm = arrayQueueList [counter2*6+2];
                                imageNoComm = imageNoCommTemp;
                                imageNoLimit = imageNoCommLimitTemp;
                                
                                endSettingComm = arrayQueueList [counter2*6+4];
                                
                                if ((int)endSettingComm.find("/m") != -1) endSettingComm = endSettingComm.substr(0, endSettingComm.find("/m"));
                                
                                redoStatus = arrayQueueList [counter2*6+5];
                                positionSwitch = 1;
                            }
                        }
                        
                        //cout<<treatmentNameComm<<" "<<lineageNoComm <<" "<<cellNoComm<<" "<<imageNoComm<<" "<<redoStatus<<" "<<endSettingComm<<"  InfoB"<<endl;
                        
                        timeOneComm = 0;
                        treatmentPosition = -1;
                        endStatusClear = 0;
                        
                        for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                            if (arrayTreatmentStatus [counter2*9] == treatmentNameComm){
                                timeOneComm = atoi(arrayTreatmentStatus [counter2*9+4].c_str());
                                treatmentPosition = counter2;
                                timeIFStart = arrayTreatmentStatus [counter2*9+7];
                                break;
                            }
                        }
                        
                        ifStartInt = 0;
                        
                        if (timeIFStart != "nil") ifStartInt = atoi(timeIFStart.c_str());
                        
                        imageNoCommInt = atoi(imageNoComm.c_str());
                        checkTimePointIF = 0;
                        
                        //cout<<ifStartInt<<" "<<imageNoCommInt<<" "<<endSettingComm<<" Setting"<<endl;
                        
                        if (timeOneComm == imageNoCommInt){
                            checkTimePoint = imageNoCommInt+10;
                            setInterval = 10;
                        }
                        else if (ifStartInt != 0 && imageNoCommInt == ifStartInt-1 && endSettingComm != "IF"){
                            checkTimePoint = imageNoCommInt;
                            setInterval = -1; //-----Last Image before IF-----
                        }
                        else if (endSettingComm == "IF"){
                            checkTimePoint = ifStartHold-1;
                            checkTimePointIF = imageNoCommInt+1;
                            setInterval = -2; //-----Last Image before IF-----
                        }
                        else if (endSettingComm == "0"){
                            checkTimePoint = imageNoCommInt+trackingCheckInterval;
                            setInterval = trackingCheckInterval;
                        }
                        else if (imageNoCommInt >= atoi(endSettingComm.c_str())){
                            checkTimePoint = imageNoCommInt+trackingCheckInterval;
                            setInterval = trackingCheckInterval;
                            endStatusClear = 1;
                        }
                        else if (imageNoCommInt+trackingCheckInterval <= atoi(endSettingComm.c_str())){
                            checkTimePoint = imageNoCommInt+trackingCheckInterval;
                            setInterval = trackingCheckInterval;
                        }
                        else{
                            
                            checkTimePoint = imageNoCommInt+1;
                            setInterval = trackingCheckInterval;
                        }
                        
                        //cout<<checkTimePoint <<" "<<setInterval<<" "<<ifStartInt<<" "<<imageNoCommInt<<" "<<endSettingComm<<" Setting2"<<endl;
                        
                        nextFileFind = 0;
                        
                        extension = to_string(checkTimePoint);
                        
                        if (extension.length() == 1) extension = "000"+extension;
                        else if (extension.length() == 2) extension = "00"+extension;
                        else if (extension.length() == 3) extension = "0"+extension;
                        
                        dataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameComm+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameComm+"_MasterData";
                        
                        if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                            nextFileFind = 1;
                        }
                        
                        //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
                        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayOperationData [counterA*4+counterB];
                        //	cout<<" arrayOperationData "<<counterA<<endl;
                        //}
                        
                        //**********Option operation array********
                        //1. Setting condition (0: None, 1:Auto, 2:TLRmv (remove))
                        //2. Remove Status (0: nil, 1:Not Ready, 2: Ready, 5. Done)
                        //3. Redo Status (0: nil, 1:Proceed-redo, 2:Proceed (when this is set, remove TL when auto Processing starts), 3:Cancel, 4:Done)
                        //4. 1:Allow, 2:Not Allow
                        
                        if (treatmentPosition == -1) nextFileFind = 0;
                        else if (arrayOperationData [treatmentPosition*4+1] == 2) nextFileFind = 0;
                        else if (arrayOperationData [treatmentPosition*4+1] == 5 && arrayOperationData [treatmentPosition*4+2] == 1 && redoStatus == "Redo" && atoi(imageNoComm.c_str()) != timeOneComm){
                            nextFileFind = 2;
                        }
                        
                        if (checkTimePointIF != 0){
                            nextLoad = 0;
                            
                            for (int counter2 = 0; counter2 < 450; counter2 = counter2+15){
                                if (atoi(arrayIFDataHold [counter2].c_str()) != 0 && atoi(arrayIFDataHold [counter2+14].c_str()) <= checkTimePointIF){
                                    nextLoad = counter2/15+1;
                                }
                                else if (atoi(arrayIFDataHold [counter2].c_str()) == 0){
                                    break;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < 90/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
                            //    cout<<" arrayIFDataHold "<<counterA<<endl;
                            //}
                            
                            fluorescentRoundNoTemp = "";
                            
                            if (nextLoad > 0){
                                nextLoad--;
                                
                                fluorescentRoundNoTemp = arrayIFDataHold [nextLoad*15];
                            }
                            
                            extension = to_string(checkTimePointIF);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            dataPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNoTemp;
                            
                            if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                nextFileFind = 1;
                            }
                            else nextFileFind = 0;
                        }
                        
                        if (autoTrackingLimitHold > timeOneComm+10){
                            if (autoTrackingLimitHold != 0 && imageNoCommInt > autoTrackingLimitHold) nextFileFind = 0;
                        }
                        
                        if (nextFileFind == 1){
                            string *queueStringTemp = new string [queueListCount+50];
                            queueStringTempCount = 0;
                            
                            for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                if (treatmentNameComm == arrayQueueList [counter2*6] && lineageNoComm == arrayQueueList [counter2*6+1] && cellNoComm == arrayQueueList [counter2*6+2]){
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+1], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+2], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+3], queueStringTempCount++;
                                    
                                    if (endStatusClear == 0){
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+4], queueStringTempCount++;
                                    }
                                    else if ((int)arrayQueueList [counter2*6+4].find("/m") != -1) queueStringTemp [queueStringTempCount] = "/m", queueStringTempCount++;
                                    else queueStringTemp [queueStringTempCount] = "0", queueStringTempCount++;
                                    
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+5], queueStringTempCount++;
                                    break;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                if (treatmentNameComm != arrayQueueList [counter2*6] || lineageNoComm != arrayQueueList [counter2*6+1] || cellNoComm != arrayQueueList [counter2*6+2]){
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+1], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+2], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+3], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+4], queueStringTempCount++;
                                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+5], queueStringTempCount++;
                                }
                            }
                            
                            queueListCount = 0;
                            
                            for (int counter2 = 0; counter2 < queueStringTempCount; counter2++) arrayQueueList [queueListCount] = queueStringTemp [counter2], queueListCount++;
                            
                            delete [] queueStringTemp;
                            
                            dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                            
                            if (queueListCount != 0){
                                char *mainDataEntry = new char [queueListCount*12+10];
                                totalEntryCount = 0;
                                
                                for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                    extension = arrayQueueList [counter3];
                                    
                                    for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                
                                ofstream outfile (dataPath.c_str(), ofstream::binary);
                                outfile.write (mainDataEntry, totalEntryCount);
                                outfile.close();
                                
                                delete [] mainDataEntry;
                            }
                            
                            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                            //	cout<<" arrayQueueList "<<counterA<<endl;
                            //}
                            
                            lineageExtract = lineageNoComm.substr(1);
                            lineageNoCommInt = atoi(lineageExtract.c_str());
                            cellNoExtract = cellNoComm.substr(1);
                            cellNoCommInt = atoi(cellNoExtract.c_str());
                            
                            dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Connect/"+analysisID+"_"+treatmentNameComm+"_LineageData";
                            
                            int *lineageCommTemp = new int [50];
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            readingError = 0;
                            
                            for (int counter2 = 0; counter2 < 6; counter2++){
                                sizeForCopy = 0;
                                
                                if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter2 == 0) size1 = sizeForCopy;
                                    else if (counter2 == 1) size2 = sizeForCopy;
                                    else if (counter2 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter2 == 3) size1 = sizeForCopy;
                                    else if (counter2 == 4) size2 = sizeForCopy;
                                    else if (counter2 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            if (checkFlag == 1){
                                delete [] lineageCommTemp;
                                lineageCommTemp = new int [sizeForCopy+50];
                                lineageCommTempCount = 0;
                                
                                fin.open(dataPath.c_str(), ios::in | ios::binary);
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                            finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++;
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                            finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                            finData [19] = uploadTemp [readPosition], readPosition++;
                                            finData [20] = uploadTemp [readPosition], readPosition++;
                                            finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                            finData [22] = uploadTemp [readPosition], readPosition++;
                                            finData [23] = uploadTemp [readPosition], readPosition++;
                                            finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                            
                                            if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                            else finData [2] = finData [1]*256+finData [2];
                                            
                                            if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                            else finData [5] = finData [4]*256+finData [5];
                                            
                                            finData [7] = finData [6]*256+finData [7];
                                            
                                            if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                            else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                            
                                            if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                            else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                            
                                            finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                            finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                            
                                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                            else{
                                                
                                                lineageCommTemp [lineageCommTempCount] = finData [2], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [5], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [7], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [8], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [13], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [18], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [21], lineageCommTempCount++;
                                                lineageCommTemp [lineageCommTempCount] = finData [24], lineageCommTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageCommTempCount/8; counterA++){
                            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageCommTemp [counterA*8+counterB];
                            //	cout<<" lineageCommTemp "<<counterA<<endl;
                            //}
                            
                            if (checkFlag == 1 && readingError == 0){
                                dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Connect/"+analysisID+"_"+treatmentNameComm+"_LineageStartEnd";
                                
                                if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    int *startEndCommTemp = new int [sizeForCopy+50];
                                    startEndCommCount = 0;
                                    
                                    fin.open(dataPath.c_str(), ios::in | ios::binary);
                                    
                                    if (fin.is_open()){
                                        char *uploadTemp = new char [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        fin.close();
                                        
                                        dataString = "";
                                        readPosition = 0;
                                        
                                        do{
                                            
                                            if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                            else if (dataString != "End"){
                                                startEndCommTemp [startEndCommCount] = atoi(dataString.c_str()), startEndCommCount++;
                                                dataString = "";
                                            }
                                            
                                            readPosition++;
                                            
                                        } while (dataString != "End");
                                        
                                        delete [] uploadTemp;
                                    }
                                    
                                    //for (int counterA = 0; counterA < startEndCommCount/8; counterA++){
                                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<startEndCommTemp [counterA*8+counterB];
                                    //	cout<<" startEndCommTemp "<<counterA<<endl;
                                    //}
                                    
                                    //==========Lineage Start end, 1. lineage no, 2. cell no, 3. X position, 4. Y position, 5. start, 6. image start, 7. end, 8. image end==========
                                    endStatus = 0;
                                    endImageNo = 0;
                                    startImageNo = 0;
                                    mitosisCheckFind = 0;
                                    
                                    for (int counter2 = 0; counter2 < startEndCommCount/8; counter2++){
                                        if (startEndCommTemp [counter2*8] == lineageNoCommInt && startEndCommTemp [counter2*8+1] == cellNoCommInt){
                                            for (int counter3 = startEndCommTemp [counter2*8+4]; counter3 <= startEndCommTemp [counter2*8+6]; counter3++){
                                                endStatus = lineageCommTemp [counter3*8+3];
                                                endImageNo = lineageCommTemp [counter3*8+2];
                                                
                                                if (lineageCommTemp [counter3*8+3] == 10) mitosisCheckFind = 1;
                                                if (startImageNo == 0) startImageNo = lineageCommTemp [counter3*8+2];
                                            }
                                            
                                            break;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < lineageCommTempCount/8; counterA++){
                                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageCommTemp [counterA*8+counterB];
                                    //    cout<<" lineageCommTemp "<<counterA<<endl;
                                    //}
                                    
                                    //cout<<endStatus<<" "<<endImageNo<<" "<<mitosisCheckFind<<" lingInfo"<<endl;
                                    
                                    if ((endStatus == 1 || endStatus == 2 || endStatus == 31 || endStatus == 41 || endStatus == 51 || endStatus == 92 || endStatus == 10 || endStatus == 11 || endStatus == 6) && endImageNo != atoi(imageNoComm.c_str())){
                                        imageNoComm = to_string(endImageNo);
                                        startImageNoComm = to_string(startImageNo);
                                        
                                        endStatus = -1;
                                    }
                                    
                                    if (checkTimePointIF != 0){
                                        imageNoComm = to_string(checkTimePointIF);
                                        endStatus = 2;
                                    }
                                    
                                    if (endStatus == 1 || endStatus == 2 || endStatus == 31 || endStatus == 41 || endStatus == 51 || endStatus == 92 || endStatus == 10 || endStatus == 11 || endStatus == 6){
                                        ofstream oin;
                                        
                                        //cout<<analysisImageName<<" "<<analysisID<<" "<<treatmentNameComm<<" "<<lineageNoComm<<" "<<cellNoComm<<" "<<imageNoComm<<" "<<setInterval<<"  Send"<<endl;
                                        
                                        for (int counter2 = 0; counter2 < 10; counter2++){
                                            oin.open(instructionCCPath.c_str(), ios::out);
                                            
                                            if (oin.is_open()){
                                                oin<<analysisImageName<<endl;
                                                oin<<analysisID<<endl;
                                                oin<<treatmentNameComm<<endl;
                                                oin<<lineageNoComm<<endl;
                                                oin<<cellNoComm<<endl;
                                                oin<<imageNoComm+":"+imageNoLimit<<endl;
                                                oin<<setInterval<<endl;
                                                oin<<trackingCheckInterval<<endl;
                                                oin<<mitosisSDHold<<endl;
                                                oin<<mitosisValueHold<<endl;
                                                oin<<divisionDistanceHold<<endl;
                                                oin<<mitosisAreaHold<<endl;
                                                oin<<mitosisRelativeLowHold<<endl;
                                                oin<<mitosisRelativeHighHold<<endl;
                                                oin<<jumpAllFlag<<endl;
                                                oin<<connectExpandFlag<<endl;
                                                oin<<mapMergeStatus<<endl;
                                                oin<<percentOverlap<<endl;
                                                oin<<gravityCenterMoveLimitFlag<<endl;
                                                oin<<optionalShiftPercent<<endl;
                                                oin<<mitosisOffFlag<<endl;
                                                oin<<fusionMarkSetFlag<<endl;
                                                
                                                //cout<<treatmentNameComm<<" "<<lineageNoComm<<" "<<cellNoComm<<" "<<imageNoComm+":"+imageNoLimit<<" "<<"AA7"<<endl;
                                                
                                                oin.close();
                                                
                                                arrayQueueList [5] = "Proc";
                                                
                                                sendDataFlag = 1;
                                                imageNoAuto = imageNoComm;
                                                readingTrialCount = 0;
                                                
                                                break;
                                            }
                                        }
                                    }
                                    else if (endStatus == 0){
                                        string *doneListUpdateTemp = new string [doneListCount+50];
                                        doneListUpdateTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                                            if (arrayDoneList [counter2*5] != treatmentNameComm || arrayDoneList [counter2*5+1] != lineageNoComm || arrayDoneList [counter2*5+2] != cellNoComm){
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+1], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+2], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+3], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+4], doneListUpdateTempCount++;
                                            }
                                        }
                                        
                                        doneListCount = 0;
                                        for (int counter2 = 0; counter2 < doneListUpdateTempCount; counter2++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter2], doneListCount++;
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                        
                                        if (doneListCount != 0){
                                            char *mainDataEntry = new char [doneListCount*10];
                                            totalEntryCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < doneListCount; counter3++){
                                                extension = arrayDoneList [counter3];
                                                
                                                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                                }
                                                
                                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            
                                            ofstream outfile2 (dataPath.c_str(), ofstream::binary);
                                            outfile2.write (mainDataEntry, totalEntryCount);
                                            outfile2.close();
                                            
                                            delete [] mainDataEntry;
                                        }
                                        
                                        delete [] doneListUpdateTemp;
                                    }
                                    else if (endStatus > 0){
                                        queueStringTemp = new string [queueListCount+50];
                                        queueStringTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                            if (arrayQueueList [counter2*6] != treatmentNameComm || arrayQueueList [counter2*6+1] != lineageNoComm || arrayQueueList [counter2*6+2] != cellNoComm){
                                                queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6], queueStringTempCount++;
                                                queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+1], queueStringTempCount++;
                                                queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+2], queueStringTempCount++;
                                                queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+3], queueStringTempCount++;
                                                queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+4], queueStringTempCount++;
                                                queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+5], queueStringTempCount++;
                                            }
                                        }
                                        
                                        imageNoTemp = "";
                                        statusFuseTemp = "";
                                        
                                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                            if (arrayQueueList [counter2*6] == treatmentNameComm && arrayQueueList [counter2*6+1] == lineageNoComm && arrayQueueList [counter2*6+2] == cellNoComm){
                                                imageNoTemp = arrayQueueList [counter2*6+3];
                                                statusFuseTemp = arrayQueueList [counter2*6+4];
                                            }
                                        }
                                        
                                        queueListCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < queueStringTempCount; counter2++) arrayQueueList [queueListCount] = queueStringTemp [counter2], queueListCount++;
                                        
                                        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                        
                                        if (queueListCount != 0){
                                            char *mainDataEntry = new char [queueListCount*12+10];
                                            totalEntryCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < queueListCount; counter2++){
                                                extension = arrayQueueList [counter2];
                                                
                                                for (int counter3 = 0; counter3 < (int)extension.length(); counter3++){
                                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter3), totalEntryCount++;
                                                }
                                                
                                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            
                                            ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                                            outfile3.write (mainDataEntry, totalEntryCount);
                                            outfile3.close();
                                            
                                            delete [] mainDataEntry;
                                        }
                                        
                                        delete [] queueStringTemp;
                                        
                                        string *doneListUpdateTemp = new string [doneListCount+50];
                                        doneListUpdateTempCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                                            if (arrayDoneList [counter2*5] != treatmentNameComm || arrayDoneList [counter2*5+1] != lineageNoComm || arrayDoneList [counter2*5+2] != cellNoComm){
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+1], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+2], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+3], doneListUpdateTempCount++;
                                                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+4], doneListUpdateTempCount++;
                                            }
                                        }
                                        
                                        doneListUpdateTemp [doneListUpdateTempCount] = treatmentNameComm, doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = lineageNoComm, doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = cellNoComm, doneListUpdateTempCount++;
                                        doneListUpdateTemp [doneListUpdateTempCount] = imageNoTemp, doneListUpdateTempCount++;
                                        
                                        if (mitosisCheckFind == 1) doneListUpdateTemp [doneListUpdateTempCount] = "OK/m", doneListUpdateTempCount++;
                                        else doneListUpdateTemp [doneListUpdateTempCount] = "OK", doneListUpdateTempCount++;
                                        
                                        if (doneListUpdateTempCount > doneListLimit){
                                            delete [] arrayDoneList;
                                            arrayDoneList = new string [doneListUpdateTempCount+500];
                                            doneListLimit = doneListUpdateTempCount+500;
                                        }
                                        
                                        doneListCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < doneListUpdateTempCount; counter2++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter2], doneListCount++;
                                        
                                        //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                                        //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                                        //	cout<<" arrayDoneList "<<counterA<<endl;
                                        //}
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                        
                                        if (doneListCount != 0){
                                            char *mainDataEntry = new char [doneListCount*10+10];
                                            totalEntryCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < doneListCount; counter3++){
                                                extension = arrayDoneList [counter3];
                                                
                                                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                                }
                                                
                                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            
                                            ofstream outfile2 (dataPath.c_str(), ofstream::binary);
                                            outfile2.write (mainDataEntry, totalEntryCount);
                                            outfile2.close();
                                            
                                            delete [] mainDataEntry;
                                        }
                                        
                                        delete [] doneListUpdateTemp;
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Treat/"+lineageNoComm+"/"+analysisID+"_"+lineageNoComm+"_CellStatus";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        int *masterReadForCellInfo = new int [sizeForCopy+50];
                                        masterReadForCellInfoCount = 0;
                                        
                                        if (sizeForCopy != 0){
                                            fin.open(dataPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                char *uploadTemp = new char [sizeForCopy+50];
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                fin.close();
                                                
                                                dataString = "";
                                                readPosition = 0;
                                                
                                                do{
                                                    
                                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                                    else if (dataString != "End"){
                                                        masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                                                        dataString = "";
                                                    }
                                                    
                                                    readPosition++;
                                                    
                                                } while (dataString != "End");
                                                
                                                delete [] uploadTemp;
                                            }
                                        }
                                        
                                        lineageOpenStatus = 0;
                                        
                                        for (int counter2 = 0; counter2 < masterReadForCellInfoCount/7; counter2++){
                                            if (masterReadForCellInfo [counter2*7] == cellNoCommInt && masterReadForCellInfo [counter2*7+6] == lineageNoCommInt){
                                                masterReadForCellInfo [counter2*7+2] = endImageNo;
                                                
                                                if (endStatus == 32) masterReadForCellInfo [counter2*7+4] = 3;
                                                else if (endStatus == 42) masterReadForCellInfo [counter2*7+4] = 4;
                                                else if (endStatus == 52) masterReadForCellInfo [counter2*7+4] = 5;
                                                else if (endStatus == 7) masterReadForCellInfo [counter2*7+4] = 6;
                                                else if (endStatus == 8) masterReadForCellInfo [counter2*7+4] = 9;
                                                else if (endStatus == 91) masterReadForCellInfo [counter2*7+4] = 7;
                                                
                                                if (mitosisCheckFind == 1) masterReadForCellInfo [counter2*7+5] = 77;
                                                else masterReadForCellInfo [counter2*7+5] = 0;
                                            }
                                            
                                            if (masterReadForCellInfo [counter2*7+6] == lineageNoCommInt && masterReadForCellInfo [counter2*7+2] == -1){
                                                lineageOpenStatus = 1;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
                                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
                                        //    cout<<" masterReadForCellInfo "<<counterA<<endl;
                                        //}
                                        
                                        char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
                                        totalEntryCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < masterReadForCellInfoCount; counter3++){
                                            extension = to_string(masterReadForCellInfo [counter3]);
                                            
                                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile12 (dataPath.c_str(), ofstream::binary);
                                        outfile12.write (mainDataEntry, totalEntryCount);
                                        outfile12.close();
                                        
                                        delete [] mainDataEntry;
                                        delete [] masterReadForCellInfo;
                                        
                                        //==========Cell Lineage List: 1. Cell Lineage NO, 2. Status, 1: Done, 0: Open, 3. Number of cells in the lineage==========
                                        numberOfEntry = 0;
                                        
                                        for (int counter2 = 0; counter2 < startEndCommCount/8; counter2++){
                                            if (startEndCommTemp [counter2*8] == lineageNoCommInt) numberOfEntry++;
                                        }
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Connect/"+ analysisID+"_"+treatmentNameComm+"_LineageStatus";
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        int *masterReadForLineageInfo = new int [sizeForCopy+50];
                                        masterReadForLineageInfoCount = 0;
                                        
                                        if (sizeForCopy != 0){
                                            fin.open(dataPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                char *uploadTemp = new char [sizeForCopy+50];
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                fin.close();
                                                
                                                dataString = "";
                                                readPosition = 0;
                                                
                                                do{
                                                    
                                                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                                                    else if (dataString != "End"){
                                                        masterReadForLineageInfo [masterReadForLineageInfoCount] = atoi(dataString.c_str()), masterReadForLineageInfoCount++;
                                                        dataString = "";
                                                    }
                                                    
                                                    readPosition++;
                                                    
                                                } while (dataString != "End");
                                                
                                                delete [] uploadTemp;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < masterReadForLineageInfoCount/3; counter2++){
                                            if (masterReadForLineageInfo [counter2*3] == lineageNoCommInt){
                                                if (lineageOpenStatus == 1) masterReadForLineageInfo [counter2*3+1] = 0;
                                                else masterReadForLineageInfo [counter2*3+1] = 1;
                                                
                                                masterReadForLineageInfo [counter2*3+2] = numberOfEntry;
                                                break;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < masterReadForLineageInfoCount/3; counterA++){
                                        //	for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<masterReadForLineageInfo [counterA*3+counterB];
                                        //	cout<<" arrayCellLineageInfo "<<counterA<<endl;
                                        //}
                                        
                                        mainDataEntry = new char [masterReadForLineageInfoCount*6+10];
                                        totalEntryCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < masterReadForLineageInfoCount; counter3++){
                                            extension = to_string(masterReadForLineageInfo [counter3]);
                                            
                                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile4 (dataPath.c_str(), ofstream::binary);
                                        outfile4.write (mainDataEntry, totalEntryCount);
                                        outfile4.close();
                                        
                                        delete [] mainDataEntry;
                                        delete [] masterReadForLineageInfo;
                                    }
                                    else if (endStatus == -1){
                                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                            if (treatmentNameComm == arrayQueueList [counter2*6] && lineageNoComm == arrayQueueList [counter2*6+1] && cellNoComm == arrayQueueList [counter2*6+2]){
                                                arrayQueueList [counter2*6+3] = imageNoComm+":"+startImageNoComm;
                                                break;
                                            }
                                        }
                                    }
                                    
                                    delete [] startEndCommTemp;
                                }
                            }
                            
                            delete [] lineageCommTemp;
                            
                            break;
                        }
                        else if (nextFileFind == 0){
                            if (positionSwitch == 1){
                                string *queueStringTemp = new string [queueListCount+50];
                                queueStringTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                    if (treatmentNameComm2 != arrayQueueList [counter2*6] || lineageNoComm2 != arrayQueueList [counter2*6+1] || cellNoComm2 != arrayQueueList [counter2*6+2]){
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+1], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+2], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+3], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+4], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+5], queueStringTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                    if (treatmentNameComm2 == arrayQueueList [counter2*6] && lineageNoComm2 == arrayQueueList [counter2*6+1] && cellNoComm2 == arrayQueueList [counter2*6+2]){
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+1], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+2], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+3], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+4], queueStringTempCount++;
                                        queueStringTemp [queueStringTempCount] = arrayQueueList [counter2*6+5], queueStringTempCount++;
                                        break;
                                    }
                                }
                                
                                queueListCount = 0;
                                for (int counter2 = 0; counter2 < queueStringTempCount; counter2++) arrayQueueList [queueListCount] = queueStringTemp [counter2], queueListCount++;
                                
                                delete [] queueStringTemp;
                                
                                dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                
                                if (queueListCount != 0){
                                    char *mainDataEntry = new char [queueListCount*12+10];
                                    totalEntryCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                        extension = arrayQueueList [counter3];
                                        
                                        for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile (dataPath.c_str(), ofstream::binary);
                                    outfile.write (mainDataEntry, totalEntryCount);
                                    outfile.close();
                                    
                                    delete [] mainDataEntry;
                                }
                                
                                break;
                            }
                        }
                        else if (nextFileFind == 2){
                            dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Connect/"+ analysisID+"_"+treatmentNameComm+"_LineageData";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter3 = 0; counter3 < 6; counter3++){
                                sizeForCopy = 0;
                                
                                if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter3 == 0) size1 = sizeForCopy;
                                    else if (counter3 == 1) size2 = sizeForCopy;
                                    else if (counter3 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter3 == 3) size1 = sizeForCopy;
                                    else if (counter3 == 4) size2 = sizeForCopy;
                                    else if (counter3 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            int *lineageAuto = new int [sizeForCopy+50];
                            lineageAutoCount = 0;
                            
                            readingError = 0;
                            
                            if (checkFlag == 1){
                                fin.open(dataPath.c_str(), ios::in | ios::binary);
                                
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                            finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++;
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                            finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                            finData [19] = uploadTemp [readPosition], readPosition++;
                                            finData [20] = uploadTemp [readPosition], readPosition++;
                                            finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                            finData [22] = uploadTemp [readPosition], readPosition++;
                                            finData [23] = uploadTemp [readPosition], readPosition++;
                                            finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                            
                                            if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                            else finData [2] = finData [1]*256+finData [2];
                                            
                                            if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                            else finData [5] = finData [4]*256+finData [5];
                                            
                                            finData [7] = finData [6]*256+finData [7];
                                            
                                            if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                            else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                            
                                            if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                            else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                            
                                            finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                            finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                            
                                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                            else{
                                                
                                                lineageAuto [lineageAutoCount] = finData [2], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [5], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [7], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [8], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [13], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [18], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [21], lineageAutoCount++;
                                                lineageAuto [lineageAutoCount] = finData [24], lineageAutoCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                                
                                if (checkFlag == 1 && readingError == 0){
                                    lineageExtract = lineageNoComm.substr(1);
                                    lineageExtractInt = atoi(lineageExtract.c_str());
                                    cellNumberExtract = cellNoComm.substr(1);
                                    cellNoExtractInt = atoi(cellNumberExtract.c_str());
                                    
                                    arrayLineageExtraction = new int [10000];
                                    lineageExtractionCount = 0;
                                    lineageExtractionLimit = 10000;
                                    
                                    for (int counter2 = 0; counter2 < lineageAutoCount/8; counter2++){
                                        if (lineageAuto [counter2*8+6] == lineageExtractInt){
                                            if (lineageExtractionCount+8 > lineageExtractionLimit){
                                                fileUpdate = [[FileUpdate alloc] init];
                                                [fileUpdate lineageExtractionUpDate];
                                            }
                                            
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+1], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+2], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+3], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+4], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+5], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+6], lineageExtractionCount++;
                                            arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter2*8+7], lineageExtractionCount++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                                    // 	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                                    //	cout<<" arrayLineageExtraction "<<counterA<<endl;
                                    //}
                                    
                                    processType = 3;
                                    newImagePosition = timeOneComm+1;
                                    
                                    treatmentNameAuto = treatmentNameComm;
                                    
                                    addDeleteAuto = [[AddDeleteAuto alloc] init];
                                    addDeleteStatus = [addDeleteAuto delLineageMain:lineageExtractInt:processType:cellNoExtractInt:newImagePosition];
                                    
                                    if (addDeleteStatus == -1){
                                        usleep (50000);
                                        
                                        addDeleteAuto = [[AddDeleteAuto alloc] init];
                                        addDeleteStatus = [addDeleteAuto delLineageMain:lineageExtractInt:processType:cellNoExtractInt:newImagePosition];
                                        
                                        if (addDeleteStatus == -1){
                                            usleep (50000);
                                            
                                            addDeleteAuto = [[AddDeleteAuto alloc] init];
                                            addDeleteStatus = [addDeleteAuto delLineageMain:lineageExtractInt:processType:cellNoExtractInt:newImagePosition];
                                        }
                                    }
                                    
                                    if (addDeleteStatus == 1){
                                        amendLastEvent = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageExtractionCount/8; counter2++){
                                            if (arrayLineageExtraction [counter2*8+6] == lineageExtractInt && arrayLineageExtraction [counter2*8+5] == cellNoExtractInt){
                                                amendLastEvent = arrayLineageExtraction [counter2*8+3];
                                            }
                                        }
                                        
                                        int *arrayLineageExtraction2 = new int [lineageExtractionCount+lineageAutoCount+10000];
                                        lineageExtractionCount2 = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageAutoCount/8; counter2++){
                                            if (lineageAuto [counter2*8+6] != lineageExtractInt){
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+1], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+2], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+3], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+4], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+5], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+6], lineageExtractionCount2++;
                                                arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter2*8+7], lineageExtractionCount2++;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < lineageExtractionCount; counter2++) arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter2], lineageExtractionCount2++;
                                        
                                        //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                                        //	cout<<" arrayLineageExtraction "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
                                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction2 [counterA*8+counterB];
                                        //	cout<<" arrayLineageExtraction2 "<<counterA<<endl;
                                        //}
                                        
                                        //-----Lineage Data Save-----
                                        char *writingArray = new char [lineageExtractionCount2/8*25+25];
                                        
                                        indexCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageExtractionCount2/8; counter2++){
                                            if (arrayLineageExtraction2 [counter2*8] < 0){
                                                writingArray [indexCount] = 1, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8]*-1;
                                            }
                                            else{
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8];
                                            }
                                            
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            if (arrayLineageExtraction2 [counter2*8+1] < 0){
                                                writingArray [indexCount] = 1, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8+1]*-1;
                                            }
                                            else{
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8+1];
                                            }
                                            
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = arrayLineageExtraction2 [counter2*8+2];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            writingArray [indexCount] = (char)arrayLineageExtraction2 [counter2*8+3], indexCount++;
                                            
                                            if (arrayLineageExtraction2 [counter2*8+4] < 0){
                                                writingArray [indexCount] = 1, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8+4]*-1;
                                            }
                                            else{
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8+4];
                                            }
                                            
                                            readBit [0] = dataTemp/16777216;
                                            dataTemp = dataTemp%16777216;
                                            readBit [1] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [2] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [3] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                                            
                                            if (arrayLineageExtraction2 [counter2*8+5] < 0){
                                                writingArray [indexCount] = 1, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8+5]*-1;
                                            }
                                            else{
                                                
                                                writingArray [indexCount] = 0, indexCount++;
                                                dataTemp = arrayLineageExtraction2 [counter2*8+5];
                                            }
                                            
                                            readBit [0] = dataTemp/16777216;
                                            dataTemp = dataTemp%16777216;
                                            readBit [1] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [2] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [3] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                                            
                                            dataTemp = arrayLineageExtraction2 [counter2*8+6];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            dataTemp = arrayLineageExtraction2 [counter2*8+7];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 25; counter3++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile (dataPath.c_str(), ofstream::binary);
                                        outfile.write ((char*) writingArray, indexCount);
                                        outfile.close();
                                        
                                        delete [] writingArray;
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Connect/"+ analysisID+"_"+treatmentNameComm+"_LineageStartEnd";
                                        
                                        int *lineageStartEndAuto = new int [lineageExtractionCount2+500];
                                        
                                        lineageStartEndAutoCount = 0;
                                        
                                        cellNumberStart = -1;
                                        lineageNumberStart = 0;
                                        firstEntryFind = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageExtractionCount2/8; counter2++){
                                            if ((arrayLineageExtraction2 [counter2*8+6] != lineageNumberStart || arrayLineageExtraction2 [counter2*8+5] != cellNumberStart) && firstEntryFind == 0){
                                                lineageNumberStart = arrayLineageExtraction2 [counter2*8+6];
                                                cellNumberStart = arrayLineageExtraction2 [counter2*8+5];
                                                
                                                lineageStartEndAuto [lineageStartEndAutoCount] = lineageNumberStart, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = cellNumberStart, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8], lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8+1], lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = counter2, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8+2], lineageStartEndAutoCount++;
                                                
                                                firstEntryFind = 1;
                                            }
                                            else if ((arrayLineageExtraction2 [counter2*8+6] != lineageNumberStart || arrayLineageExtraction2 [counter2*8+5] != cellNumberStart) && firstEntryFind == 1){
                                                lineageNumberStart = arrayLineageExtraction2 [counter2*8+6];
                                                cellNumberStart = arrayLineageExtraction2 [counter2*8+5];
                                                
                                                lineageStartEndAuto [lineageStartEndAutoCount] = counter2-1, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [(counter2-1)*8+2], lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = lineageNumberStart, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = cellNumberStart, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8], lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8+1], lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = counter2, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8+2], lineageStartEndAutoCount++;
                                            }
                                            
                                            if (counter2 == lineageExtractionCount2/8-1){
                                                lineageStartEndAuto [lineageStartEndAutoCount] = counter2, lineageStartEndAutoCount++;
                                                lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter2*8+2], lineageStartEndAutoCount++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < lineageStartEndAutoCount/8; counterA++){
                                        //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageStartEndAuto [counterA*8+counterB];
                                        //	cout<<" lineageStartEndAuto "<<counterA<<endl;
                                        //}
                                        
                                        if (lineageStartEndAutoCount != 0){
                                            char *mainDataEntry = new char [lineageStartEndAutoCount*7+10];
                                            totalEntryCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < lineageStartEndAutoCount; counter3++){
                                                extension = to_string(lineageStartEndAuto [counter3]);
                                                
                                                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                                }
                                                
                                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            
                                            ofstream outfile2 (dataPath.c_str(), ofstream::binary);
                                            outfile2.write (mainDataEntry, totalEntryCount);
                                            outfile2.close();
                                            
                                            delete [] mainDataEntry;
                                        }
                                        
                                        delete [] lineageStartEndAuto;
                                        delete [] arrayLineageExtraction2;
                                        
                                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                        //    cout<<" arrayQueueList "<<counterA<<endl;
                                        //}
                                        
                                        extension = to_string(newImagePosition-1);
                                        
                                        string *queueListUpdateTemp = new string [queueListCount+50];
                                        queueListUpdateTempCount = 0;
                                        
                                        queueListUpdateTemp [queueListUpdateTempCount] = treatmentNameComm, queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = lineageNoComm, queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = cellNoComm, queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = extension+":"+extension, queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = "0", queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = "Wait", queueListUpdateTempCount++;
                                        
                                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                            if (arrayQueueList [counter2*6] != treatmentNameComm || arrayQueueList [counter2*6+1] != lineageNoComm || arrayQueueList [counter2*6+2] != cellNoComm){
                                                queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6], queueListUpdateTempCount++;
                                                queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+1], queueListUpdateTempCount++;
                                                queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+2], queueListUpdateTempCount++;
                                                queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+3], queueListUpdateTempCount++;
                                                queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+4], queueListUpdateTempCount++;
                                                queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+5], queueListUpdateTempCount++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                        //    cout<<" arrayQueueList "<<counterA<<endl;
                                        //}
                                        
                                        if (queueListUpdateTempCount > queueListLimit){
                                            delete [] arrayQueueList;
                                            arrayQueueList = new string [queueListUpdateTempCount+5000];
                                            queueListLimit = queueListUpdateTempCount+5000;
                                        }
                                        
                                        queueListCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < queueListUpdateTempCount; counter2++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter2], queueListCount++;
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                        
                                        if (queueListCount != 0){
                                            char *mainDataEntry = new char [queueListCount*12+10];
                                            totalEntryCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                                extension = arrayQueueList [counter3];
                                                
                                                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                                }
                                                
                                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                            
                                            ofstream outfile2 (dataPath.c_str(), ofstream::binary);
                                            outfile2.write (mainDataEntry, totalEntryCount);
                                            outfile2.close();
                                            
                                            delete [] mainDataEntry;
                                        }
                                        
                                        delete [] queueListUpdateTemp;
                                        
                                        extension = to_string(newImagePosition-1);
                                        
                                        if (extension.length() == 1) extension = "000"+extension;
                                        else if (extension.length() == 2) extension = "00"+extension;
                                        else if (extension.length() == 3) extension = "0"+extension;
                                        
                                        dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameComm+"_MasterDataRevise";
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        checkFlag = 0;
                                        
                                        for (int counter3 = 0; counter3 < 6; counter3++){
                                            sizeForCopy = 0;
                                            
                                            if (stat(dataPath.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            if (sizeForCopy != 0){
                                                if (counter3 == 0) size1 = sizeForCopy;
                                                else if (counter3 == 1) size2 = sizeForCopy;
                                                else if (counter3 == 2){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        size1 = 0;
                                                        size2 = 0;
                                                        usleep (50000);
                                                    }
                                                }
                                                else if (counter3 == 3) size1 = sizeForCopy;
                                                else if (counter3 == 4) size2 = sizeForCopy;
                                                else if (counter3 == 5){
                                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                        checkFlag = 1;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        if (checkFlag == 1){
                                            readingError = 0;
                                            
                                            int *masterReadForAmend = new int [sizeForCopy+50];
                                            masterReadForAmendCount = 0;
                                            
                                            fin.open(dataPath.c_str(), ios::in | ios::binary);
                                            uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                    usleep(50000);
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    
                                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                        readingError = 1;
                                                    }
                                                }
                                            }
                                            
                                            fin.close();
                                            
                                            if (readingError == 0){
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                        
                                                        finData [1] = finData [0]*256+finData [1];
                                                        finData [3] = finData [2]*256+finData [3];
                                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                        
                                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                        
                                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                                            masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                                            masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                                            masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                                            masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                                            masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                                            masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                            }
                                            
                                            delete [] uploadTemp;
                                            
                                            //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                                            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                                            //	cout<<" masterReadForAmend "<<counterA<<endl;
                                            //}
                                            
                                            dataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameComm+"_Treat/"+lineageNoComm+"/"+cellNoComm+"/"+analysisID+"_"+lineageNoComm+"_lineDataAmend";
                                            
                                            entryCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < masterReadForAmendCount/7; counter2++){
                                                if (masterReadForAmend [counter2*7+4] == cellNoExtractInt && masterReadForAmend [counter2*7+6] == lineageExtractInt) entryCount++;
                                            }
                                            
                                            indexCount = 0;
                                            
                                            writingArray = new char [entryCount*13+20];
                                            
                                            //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                                            for (int counter2 = 0; counter2 < masterReadForAmendCount/7; counter2++){
                                                if (masterReadForAmend [counter2*7+4] == cellNoExtractInt && masterReadForAmend [counter2*7+6] == lineageExtractInt){
                                                    dataTemp = newImagePosition-1;
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    dataTemp = masterReadForAmend [counter2*7];
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    dataTemp = masterReadForAmend [counter2*7+1];
                                                    readBit [0] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [1] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    
                                                    writingArray [indexCount] = (char)amendLastEvent, indexCount++;
                                                    
                                                    dataTemp = masterReadForAmend [counter2*7+3];
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                    
                                                    dataTemp = masterReadForAmend [counter2*7+6];
                                                    readBit [0] = dataTemp/65536;
                                                    dataTemp = dataTemp%65536;
                                                    readBit [1] = dataTemp/256;
                                                    dataTemp = dataTemp%256;
                                                    readBit [2] = dataTemp;
                                                    
                                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                }
                                            }
                                            
                                            for (int counter2 = 0; counter2 < 13; counter2++) writingArray [indexCount] = 0, indexCount++;
                                            
                                            ofstream outfile3 (dataPath.c_str(), ofstream::binary);
                                            outfile3.write ((char*)writingArray, indexCount);
                                            outfile3.close();
                                            
                                            delete [] writingArray;
                                            delete [] masterReadForAmend;
                                        }
                                    }
                                    
                                    delete [] arrayLineageExtraction;
                                }
                            }
                            
                            delete [] lineageAuto;
                            
                            break;
                        }
                        
                        counterComplete++;
                    }
                    
                    if (sendDataFlag == 0){
                        connectionSend1 = 1;
                        
                        if (counterComplete == queueListCount/6) autoProcessTiming = 500;
                    }
                    else{
                        
                        connectionSend1 = 3;
                        autoProcessTimingCount = 0;
                        autoProcessTiming = 0;
                    }
                }
            }
            else if (connectionSend1 == 1) autoProcessTimingCount++;
            
            if (connectionSend1 == 3){
                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                //    cout<<" arrayQueueList "<<counterA<<endl;
                //}
                
                int instractionRRFlag = 0;
                string getString;
                
                fin.open(instructionRRPath.c_str(), ios::in);
                if (fin.is_open()){
                    instractionRRFlag = 1;
                    fin.close();
                }
                
                if (instractionRRFlag != 0){
                    if (readingTrialCount <= 10){
                        readingTrialCount++;
                        
                        treatmentNameAuto = "";
                        lineageNoAuto = "";
                        cellNoAuto = "";
                        checkStatusAuto = "";
                        additionalInfoAuto = "";
                        
                        string imageNoAutoTemp = "";
                        
                        fin.open(instructionRRPath.c_str(), ios::in);
                        getline(fin, getString);
                        getline(fin, getString);
                        getline(fin, getString), treatmentNameAuto = getString;
                        getline(fin, getString), lineageNoAuto = getString;
                        getline(fin, getString), cellNoAuto = getString;
                        getline(fin, getString), imageNoAutoTemp = getString;
                        getline(fin, getString), checkStatusAuto = getString;
                        getline(fin, getString), additionalInfoAuto = getString;
                        
                        getline(fin, getString);
                        
                        if (getString != "END2" && getString != ""){
                            fusionPartnerInfoCount = 0;
                            
                            getline(fin, getString);
                            fusionPartnerInfo [fusionPartnerInfoCount] = atoi(getString.c_str()), fusionPartnerInfoCount++; //-----Image no-----
                            getline(fin, getString);
                            fusionPartnerInfo [fusionPartnerInfoCount] = atoi(getString.c_str()), fusionPartnerInfoCount++; //-----Lineage no-----
                            getline(fin, getString);
                            fusionPartnerInfo [fusionPartnerInfoCount] = atoi(getString.c_str()), fusionPartnerInfoCount++; //-----Cell no-----
                            
                            int terminationFlag = 0;
                            
                            do{
                                
                                terminationFlag = 1;
                                getline(fin, getString);
                                
                                if (getString == "ENDF" || getString == "") terminationFlag = 0;
                                else{
                                    
                                    if (fusionPartnerInfoCount+3 > fusionPartnerInfoLimit){
                                        int *arrayUpDate = new int [fusionPartnerInfoCount+10];
                                        
                                        for (int counter1 = 0; counter1 < fusionPartnerInfoCount; counter1++) arrayUpDate [counter1] = fusionPartnerInfo [counter1];
                                        
                                        delete [] fusionPartnerInfo;
                                        fusionPartnerInfo = new int [fusionPartnerInfoLimit+30];
                                        fusionPartnerInfoLimit = fusionPartnerInfoLimit+30;
                                        
                                        for (int counter1 = 0; counter1 < fusionPartnerInfoCount; counter1++) fusionPartnerInfo [counter1] = arrayUpDate [counter1];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    getline(fin, getString);
                                    fusionPartnerInfo [fusionPartnerInfoCount] = atoi(getString.c_str()), fusionPartnerInfoCount++; //-----Image no-----
                                    getline(fin, getString);
                                    fusionPartnerInfo [fusionPartnerInfoCount] = atoi(getString.c_str()), fusionPartnerInfoCount++; //-----Lineage no-----
                                    getline(fin, getString);
                                    fusionPartnerInfo [fusionPartnerInfoCount] = atoi(getString.c_str()), fusionPartnerInfoCount++; //-----Cell no-----
                                }
                                
                            } while (terminationFlag == 1);
                            
                            getline(fin, getString);
                        }
                        
                        if (getString == "END2" && treatmentNameAuto != "" && lineageNoAuto != "" && cellNoAuto != "" && imageNoAuto != "" && checkStatusAuto != "" && additionalInfoAuto != ""){
                            if (atoi(imageNoAutoTemp.c_str()) != atoi(imageNoAuto.c_str())) imageNoAuto = imageNoAutoTemp;
                            else if (checkStatusAuto == "MD" || checkStatusAuto == "NS" || checkStatusAuto == "CM" || checkStatusAuto == "CN" || checkStatusAuto == "FM" || checkStatusAuto == "TL" || checkStatusAuto == "FE" || checkStatusAuto == "FO" || checkStatusAuto == "DL" || checkStatusAuto == "OF" || checkStatusAuto == "MF" || checkStatusAuto == "TM"){
                                checkStatusAuto = checkStatusAuto+"/c";
                            }
                            else imageNoAuto = imageNoAutoTemp;
                            
                            if (checkStatusAuto == "EY" && multipleLaunchBlock >= 2){
                                checkStatusAuto = "LE";
                            }
                            
                            if (checkStatusAuto != "EY") multipleLaunchBlock = 0;
                            
                            //cout<<treatmentNameAuto<<" "<<lineageNoAuto<<" "<<cellNoAuto<<" "<<imageNoAuto<<" "<<checkStatusAuto<<" "<<additionalInfoAuto<<" LIngInfo"<<endl;
                            
                            connectionSend1 = 4;
                        }
                        
                        fin.close();
                        
                        //for (int counterA = 0; counterA < fusionPartnerInfoCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<fusionPartnerInfo [counterA*3+counterB];
                        //    cout<<" fusionPartnerInfo "<<counterA<<endl;
                        //}
                        
                        // for (int counterA = 0; counterA < doneListCount/5; counterA++){
                        // 	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                        //     cout<<" arrayDoneList "<<counterA<<endl;
                        //}
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                            if (arrayQueueList [counter1*6+5] == "Proc"){
                                arrayQueueList [counter1*6+5] = "Wait";
                                break;
                            }
                        }
                        
                        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                        
                        if (queueListCount != 0){
                            string extension;
                            
                            char *mainDataEntry = new char [queueListCount*12+10];
                            int totalEntryCount = 0;
                            
                            for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                extension = arrayQueueList [counter3];
                                
                                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                }
                                
                                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                            
                            ofstream outfile (queueListPath.c_str(), ofstream::binary);
                            outfile.write (mainDataEntry, totalEntryCount);
                            outfile.close();
                            
                            delete [] mainDataEntry;
                        }
                        
                        string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
                        string entry;
                        string removeFilePath;
                        
                        fileDeleteCount = 0;
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        dir = opendir(connectClearPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate fileDeleteUpDate];
                                }
                                
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                                entry = arrayFileDelete [counter4];
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                    int findFile2 = (int)entry.find("CutTemp");
                                    int findFile3 = (int)entry.find("GCCurrentTemp");
                                    int findFile4 = (int)entry.find("MasterDataTemp");
                                    int findFile5 = (int)entry.find("RevisedTempMap");
                                    int findFile6 = (int)entry.find("StatusTemp");
                                    int findFile7 = (int)entry.find("LinkDataTemp");
                                    int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                    int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                    int findFile10 = (int)entry.find("EventTemp");
                                    int findFile11 = (int)entry.find("MitosisDataTemp");
                                    int findFile12 = (int)entry.find("GCCenterInfo");
                                    
                                    if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                        removeFilePath = connectClearPath+"/"+entry;
                                        remove (removeFilePath.c_str());
                                    }
                                }
                            }
                        }
                        
                        remove (instructionRRPath.c_str());
                        
                        connectionSend1 = 1;
                    }
                }
            }
            
            if (connectionSend1 == 4){
                connectionSend1 = 40;
                int doneCheck = 0;
                
                //cout<<treatmentNameAuto<<" "<<lineageNoAuto<<" "<<cellNoAuto<<" "<<imageNoAuto<<" "<<checkStatusAuto<<" "<<additionalInfoAuto<<" LIngInfo"<<endl;
                
                if (checkStatusAuto != "EX" && checkStatusAuto != "EY" && checkStatusAuto != "EZ" && checkStatusAuto != "LE" && checkStatusAuto != "MS" && checkStatusAuto != "AM" && checkStatusAuto != "TT" && checkStatusAuto != "CL" && checkStatusAuto != "MD/c" && checkStatusAuto != "NS/c" && checkStatusAuto != "CM/c" && checkStatusAuto != "CN/c" && checkStatusAuto != "FM/c" && checkStatusAuto != "TL/c" && checkStatusAuto != "FE/c" && checkStatusAuto != "FO/c" && checkStatusAuto != "DL/c" && checkStatusAuto != "OF/c" && checkStatusAuto != "ME/c" && checkStatusAuto != "RD" && checkStatusAuto != "RM" && checkStatusAuto != "TM/c"){
                    doneCheck = [self doneProcess];
                    
                    if (doneCheck == 0){
                        remove (instructionRRPath.c_str());
                        connectionSend1 = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Read Error: Check Database"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        cellCurvingRunningFlag = 2;
                        connectionSend1 = 0;
                        autoProcessTimingCount = 0;
                        autoProcessTiming = 0;
                        
                    }
                }
                else if (checkStatusAuto == "AM" || checkStatusAuto == "CL" || checkStatusAuto == "MD/c" || checkStatusAuto == "NS/c" || checkStatusAuto == "CM/c" || checkStatusAuto == "CN/c" || checkStatusAuto == "FM/c" || checkStatusAuto == "FE/c" || checkStatusAuto == "FO/c" || checkStatusAuto == "DL/c" || checkStatusAuto == "OF/c" || checkStatusAuto == "ME/c" || checkStatusAuto == "MF/c"){
                    doneCheck = [self doneProcess];
                    
                    if (doneCheck == 0){
                        remove (instructionRRPath.c_str());
                        connectionSend1 = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Read Error: Check Database"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        cellCurvingRunningFlag = 2;
                        connectionSend1 = 0;
                        autoProcessTimingCount = 0;
                        autoProcessTiming = 0;
                    }
                }
                else if (checkStatusAuto == "EX" || checkStatusAuto == "EY" || checkStatusAuto == "EZ"){
                    string timeEndComm = "";
                    
                    for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                        if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
                            timeEndComm = arrayTreatmentStatus [counter1*9+5];
                            break;
                        }
                    }
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6+5] == "Proc"){
                            arrayQueueList [counter1*6+5] = "Wait";
                            break;
                        }
                    }
                    
                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                    
                    if (queueListCount != 0){
                        string extension;
                        
                        char *mainDataEntry = new char [queueListCount*12+10];
                        int totalEntryCount = 0;
                        
                        for (int counter3 = 0; counter3 < queueListCount; counter3++){
                            extension = arrayQueueList [counter3];
                            
                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile (queueListPath.c_str(), ofstream::binary);
                        outfile.write (mainDataEntry, totalEntryCount);
                        outfile.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
                    string entry;
                    string removeFilePath;
                    
                    fileDeleteCount = 0;
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    dir = opendir(connectClearPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (fileDeleteCount+5 > fileDeleteLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate fileDeleteUpDate];
                            }
                            
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                        
                        closedir(dir);
                        
                        for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                            entry = arrayFileDelete [counter4];
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                int findFile2 = (int)entry.find("CutTemp");
                                int findFile3 = (int)entry.find("GCCurrentTemp");
                                int findFile4 = (int)entry.find("MasterDataTemp");
                                int findFile5 = (int)entry.find("RevisedTempMap");
                                int findFile6 = (int)entry.find("StatusTemp");
                                int findFile7 = (int)entry.find("LinkDataTemp");
                                int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                int findFile10 = (int)entry.find("EventTemp");
                                int findFile11 = (int)entry.find("MitosisDataTemp");
                                int findFile12 = (int)entry.find("GCCenterInfo");
                                
                                if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                    removeFilePath = connectClearPath+"/"+entry;
                                    remove (removeFilePath.c_str());
                                }
                            }
                        }
                    }
                    
                    remove (instructionRRPath.c_str());
                    
                    cellCurvingRunningFlag = 2;
                    connectionSend1 = 0;
                    autoProcessTimingCount = 0;
                    autoProcessTiming = 0;
                    
                    if (checkStatusAuto == "EY") queueRestartFlag = 1;
                    else if (checkStatusAuto == "EZ") queueRestartFlag = 2;
                    else if (checkStatusAuto == "EX") queueRestartFlag = 0;
                }
                else if (checkStatusAuto == "LE"){
                    [self doneProcess];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"File Read Error: Check Database"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    cellCurvingRunningFlag = 2;
                    connectionSend1 = 0;
                    autoProcessTimingCount = 0;
                    autoProcessTiming = 0;
                }
                else if (checkStatusAuto == "MS"){
                    [self doneProcess];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Mitosis Data Missing: Required One Mitosis Data"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                    
                    cellCurvingRunningFlag = 2;
                    connectionSend1 = 0;
                    autoProcessTimingCount = 0;
                    autoProcessTiming = 0;
                }
                else if (checkStatusAuto == "TT"){
                    string timeEndComm = "";
                    string imageNoCommTemp = "";
                    
                    for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                        if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
                            timeEndComm = arrayTreatmentStatus [counter1*9+5];
                            break;
                        }
                    }
                    
                    string *queueStringTemp = new string [queueListCount+50];
                    int queueStringTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                        if (arrayQueueList [counter1*6+5] != "Proc"){
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                        }
                        else{
                            
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                            queueStringTemp [queueStringTempCount] = "Wait", queueStringTempCount++;
                        }
                    }
                    
                    queueListCount = 0;
                    
                    for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
                    
                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                    
                    if (queueListCount != 0){
                        string extension;
                        
                        char *mainDataEntry = new char [queueListCount*12+10];
                        int totalEntryCount = 0;
                        
                        for (int counter3 = 0; counter3 < queueListCount; counter3++){
                            extension = arrayQueueList [counter3];
                            
                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile (queueListPath.c_str(), ofstream::binary);
                        outfile.write (mainDataEntry, totalEntryCount);
                        outfile.close();
                        
                        delete [] mainDataEntry;
                    }
                    
                    delete [] queueStringTemp;
                    
                    remove (instructionRRPath.c_str());
                    
                    connectionSend1 = 1;
                }
                else if (checkStatusAuto == "RD"){
                    doneCheck = [self doneProcess];
                    
                    if (doneCheck == 0){
                        remove (instructionRRPath.c_str());
                        connectionSend1 = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Read Error: Check Database"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        cellCurvingRunningFlag = 2;
                        connectionSend1 = 0;
                        autoProcessTimingCount = 0;
                        autoProcessTiming = 0;
                    }
                }
                else if (checkStatusAuto == "RM"){
                    string connectDataLineagePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageData";
                    
                    struct stat sizeOfFile;
                    long sizeForCopy = 0;
                    long size1 = 0;
                    long size2 = 0;
                    int checkFlag = 0;
                    int readingError = 0;
                    
                    for (int counter3 = 0; counter3 < 6; counter3++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataLineagePath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter3 == 0) size1 = sizeForCopy;
                            else if (counter3 == 1) size2 = sizeForCopy;
                            else if (counter3 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter3 == 3) size1 = sizeForCopy;
                            else if (counter3 == 4) size2 = sizeForCopy;
                            else if (counter3 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    int *lineageAuto = new int [sizeForCopy+50];
                    int lineageAutoCount = 0;
                    
                    if (checkFlag == 1){
                        int finData [25];
                        
                        fin.open(connectDataLineagePath.c_str(), ios::in | ios::binary);
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        if (readingError == 0){
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++;
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++;
                                    finData [17] = uploadTemp [readPosition], readPosition++;
                                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                    finData [19] = uploadTemp [readPosition], readPosition++;
                                    finData [20] = uploadTemp [readPosition], readPosition++;
                                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                    finData [22] = uploadTemp [readPosition], readPosition++;
                                    finData [23] = uploadTemp [readPosition], readPosition++;
                                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                    
                                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                    else finData [2] = finData [1]*256+finData [2];
                                    
                                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                    else finData [5] = finData [4]*256+finData [5];
                                    
                                    finData [7] = finData [6]*256+finData [7];
                                    
                                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                    
                                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                    
                                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                    
                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                    else{
                                        
                                        lineageAuto [lineageAutoCount] = finData [2], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [5], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [7], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [8], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [13], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [18], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [21], lineageAutoCount++;
                                        lineageAuto [lineageAutoCount] = finData [24], lineageAutoCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                        
                        //for (int counterA = 0; counterA < lineageAutoCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageAuto [counterA*8+counterB];
                        //    cout<<" lineageAuto "<<counterA<<endl;
                        //}
                        
                        if (readingError == 0){
                            string lineageExtract = lineageNoAuto.substr(1);
                            int lineageExtractInt = atoi(lineageExtract.c_str());
                            string cellNumberExtract = cellNoAuto.substr(1);
                            int cellNoExtractInt = atoi(cellNumberExtract.c_str());
                            
                            int timePointLast = 0;
                            int newImagePosition = atoi(additionalInfoAuto.c_str());
                            
                            for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                                if (lineageAuto [counter1*8+6] == lineageExtractInt && lineageAuto [counter1*8+5] == cellNoExtractInt){
                                    if (timePointLast < lineageAuto [counter1*8+2]) timePointLast = lineageAuto [counter1*8+2];
                                }
                            }
                            
                            string imageNoTemp = "";
                            
                            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+1] == lineageNoAuto && arrayQueueList [counter1*6+2] == cellNoAuto){
                                    imageNoTemp = arrayQueueList [counter1*6+3];
                                }
                            }
                            
                            if ((int)imageNoTemp.find(":") != -1) imageNoTemp = imageNoTemp.substr(imageNoTemp.find(":")+1);
                            
                            //cout<<imageNoTemp<<" "<< timePointLast<<" "<<timePointLast<<" info"<<endl;
                            
                            string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
                            
                            string entry;
                            string removeFilePath;
                            
                            fileDeleteCount = 0;
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            dir = opendir(connectClearPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate fileDeleteUpDate];
                                    }
                                    
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                                
                                closedir(dir);
                                
                                for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                                    entry = arrayFileDelete [counter4];
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                                        int findFile2 = (int)entry.find("CutTemp");
                                        int findFile3 = (int)entry.find("GCCurrentTemp");
                                        int findFile4 = (int)entry.find("MasterDataTemp");
                                        int findFile5 = (int)entry.find("RevisedTempMap");
                                        int findFile6 = (int)entry.find("StatusTemp");
                                        int findFile7 = (int)entry.find("LinkDataTemp");
                                        int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                                        int findFile9 = (int)entry.find("ExtendLineDataTemp");
                                        int findFile10 = (int)entry.find("EventTemp");
                                        int findFile11 = (int)entry.find("MitosisDataTemp");
                                        int findFile12 = (int)entry.find("GCCenterInfo");
                                        
                                        if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                                            removeFilePath = connectClearPath+"/"+entry;
                                            remove (removeFilePath.c_str());
                                        }
                                    }
                                }
                            }
                            
                            if (newImagePosition == timePointLast){
                                for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                                    if (lineageAuto [counter1*8+6] == lineageExtractInt && lineageAuto [counter1*8+5] == cellNoExtractInt && lineageAuto [counter1*8+2] == newImagePosition){
                                        lineageAuto [counter1*8+3] = 6;
                                    }
                                }
                                
                                //-----Lineage Data Save-----
                                char *writingArray = new char [lineageAutoCount/8*25+25];
                                
                                unsigned long indexCount = 0;
                                int readBit [4];
                                int dataTemp;
                                
                                for (int counter2 = 0; counter2 < lineageAutoCount/8; counter2++){
                                    if (lineageAuto [counter2*8] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageAuto [counter2*8]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageAuto [counter2*8];
                                    }
                                    
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    if (lineageAuto [counter2*8+1] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageAuto [counter2*8+1]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageAuto [counter2*8+1];
                                    }
                                    
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = lineageAuto [counter2*8+2];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)lineageAuto [counter2*8+3], indexCount++;
                                    
                                    if (lineageAuto [counter2*8+4] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageAuto [counter2*8+4]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageAuto [counter2*8+4];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    if (lineageAuto [counter2*8+5] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageAuto [counter2*8+5]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageAuto [counter2*8+5];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    dataTemp = lineageAuto [counter2*8+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = lineageAuto [counter2*8+7];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 25; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile (connectDataLineagePath.c_str(), ofstream::binary);
                                outfile.write ((char*) writingArray, indexCount);
                                outfile.close();
                                
                                delete [] writingArray;
                                
                                string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_MitosisData";
                                
                                size1 = 0;
                                size2 = 0;
                                checkFlag = 0;
                                
                                for (int counter2 = 0; counter2 < 6; counter2++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter2 == 0) size1 = sizeForCopy;
                                        else if (counter2 == 1) size2 = sizeForCopy;
                                        else if (counter2 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter2 == 3) size1 = sizeForCopy;
                                        else if (counter2 == 4) size2 = sizeForCopy;
                                        else if (counter2 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                if (checkFlag == 1){
                                    int *arrayMitosisTemp = new int [sizeForCopy+50];
                                    int mitosisTempCount = 0;
                                    
                                    fin.open(mitosisStatusPath.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        string lineageNoGet;
                                        string cellNoGet;
                                        string imageNoGet;
                                        string setTypeGet;
                                        
                                        int terminationFlag = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            getline(fin, lineageNoGet);
                                            
                                            if (lineageNoGet == "") terminationFlag = 0;
                                            else{
                                                
                                                getline(fin, cellNoGet);
                                                getline(fin, imageNoGet);
                                                getline(fin, setTypeGet);
                                                
                                                arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                                arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                                arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                                arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                            }
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                                        if (arrayMitosisTemp [counter2*4] == lineageExtractInt && arrayMitosisTemp [counter2*4+1] == cellNoExtractInt && arrayMitosisTemp [counter2*4+2] == timePointLast){
                                            arrayMitosisTemp [counter2*4+3] = 10;
                                        }
                                        else if (arrayMitosisTemp [counter2*4] == lineageExtractInt && arrayMitosisTemp [counter2*4+1] == cellNoExtractInt){
                                            arrayMitosisTemp [counter2*4+3] = 0;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < mitosisTempCount/4; counterA++){
                                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp [counterA*4+counterB];
                                    //    cout<<" arrayMitosisTempe "<<counterA<<endl;
                                    //}
                                    
                                    ofstream oin;
                                    oin.open(mitosisStatusPath.c_str(), ios::out);
                                    
                                    for (int counter1 = 0; counter1 < mitosisTempCount; counter1++) oin<<arrayMitosisTemp [counter1]<<endl;
                                    
                                    oin.close();
                                    
                                    delete [] arrayMitosisTemp;
                                }
                                
                                string timeEndComm = "";
                                
                                for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                                    if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
                                        timeEndComm = arrayTreatmentStatus [counter1*9+5];
                                        break;
                                    }
                                }
                                
                                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                    if (arrayQueueList [counter1*6+5] == "Proc"){
                                        arrayQueueList [counter1*6+5] = "Wait";
                                    }
                                }
                                
                                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                
                                if (queueListCount != 0){
                                    string extension;
                                    
                                    char *mainDataEntry = new char [queueListCount*12];
                                    int totalEntryCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                        extension = arrayQueueList [counter3];
                                        
                                        for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile2 (queueListPath.c_str(), ofstream::binary);
                                    outfile2.write (mainDataEntry, totalEntryCount);
                                    outfile2.close();
                                    
                                    delete [] mainDataEntry;
                                }
                            }
                            else if (newImagePosition < timePointLast){
                                arrayLineageExtraction = new int [10000];
                                lineageExtractionCount = 0;
                                lineageExtractionLimit = 10000;
                                
                                for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                                    if (lineageAuto [counter1*8+6] == lineageExtractInt){
                                        if (lineageExtractionCount+8 > lineageExtractionLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate lineageExtractionUpDate];
                                        }
                                        
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+1], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+2], lineageExtractionCount++;
                                        
                                        if (lineageAuto [counter1*8+5] == cellNoExtractInt && lineageAuto [counter1*8+2] == newImagePosition){
                                            arrayLineageExtraction [lineageExtractionCount] = 6, lineageExtractionCount++;
                                        }
                                        else arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+3], lineageExtractionCount++;
                                        
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+4], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+5], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+6], lineageExtractionCount++;
                                        arrayLineageExtraction [lineageExtractionCount] = lineageAuto [counter1*8+7], lineageExtractionCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                                //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                                //	cout<<" arrayLineageExtraction "<<counterA<<endl;
                                //}
                                
                                newImagePosition++;
                                
                                int processType = 3;
                                
                                addDeleteAuto = [[AddDeleteAuto alloc] init];
                                int addDeleteStatus = [addDeleteAuto delLineageMain:lineageExtractInt:processType:cellNoExtractInt:newImagePosition];
                                
                                if (addDeleteStatus == -1){
                                    usleep (50000);
                                    
                                    addDeleteAuto = [[AddDeleteAuto alloc] init];
                                    addDeleteStatus = [addDeleteAuto delLineageMain:lineageExtractInt:processType:cellNoExtractInt:newImagePosition];
                                    
                                    if (addDeleteStatus == -1){
                                        usleep (50000);
                                        
                                        addDeleteAuto = [[AddDeleteAuto alloc] init];
                                        addDeleteStatus = [addDeleteAuto delLineageMain:lineageExtractInt:processType:cellNoExtractInt:newImagePosition];
                                    }
                                }
                                
                                if (addDeleteStatus == 0){
                                    int amendLastEvent = 0;
                                    
                                    for (int counter1 = 0; counter1 < lineageExtractionCount/8; counter1++){
                                        if (arrayLineageExtraction [counter1*8+6] == lineageExtractInt && arrayLineageExtraction [counter1*8+5] == cellNoExtractInt){
                                            amendLastEvent = arrayLineageExtraction [counter1*8+3];
                                        }
                                    }
                                    
                                    int *arrayLineageExtraction2 = new int [lineageExtractionCount+lineageAutoCount+10000];
                                    int lineageExtractionCount2 = 0;
                                    
                                    for (int counter1 = 0; counter1 < lineageAutoCount/8; counter1++){
                                        if (lineageAuto [counter1*8+6] != lineageExtractInt){
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+1], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+2], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+3], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+4], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+5], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+6], lineageExtractionCount2++;
                                            arrayLineageExtraction2 [lineageExtractionCount2] = lineageAuto [counter1*8+7], lineageExtractionCount2++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < lineageExtractionCount; counter1++) arrayLineageExtraction2 [lineageExtractionCount2] = arrayLineageExtraction [counter1], lineageExtractionCount2++;
                                    
                                    //for (int counterA = 0; counterA < lineageExtractionCount/8; counterA++){
                                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction [counterA*8+counterB];
                                    //	cout<<" arrayLineageExtraction "<<counterA<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < lineageExtractionCount2/8; counterA++){
                                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageExtraction2 [counterA*8+counterB];
                                    //	cout<<" arrayLineageExtraction2 "<<counterA<<endl;
                                    //}
                                    
                                    //-----Lineage Data Save-----
                                    char *writingArray = new char [lineageExtractionCount2/8*25+25];
                                    
                                    unsigned long indexCount = 0;
                                    int readBit [4];
                                    int dataTemp;
                                    
                                    for (int counter2 = 0; counter2 < lineageExtractionCount2/8; counter2++){
                                        if (arrayLineageExtraction2 [counter2*8] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8];
                                        }
                                        
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        if (arrayLineageExtraction2 [counter2*8+1] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8+1]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8+1];
                                        }
                                        
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        dataTemp = arrayLineageExtraction2 [counter2*8+2];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        writingArray [indexCount] = (char)arrayLineageExtraction2 [counter2*8+3], indexCount++;
                                        
                                        if (arrayLineageExtraction2 [counter2*8+4] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8+4]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8+4];
                                        }
                                        
                                        readBit [0] = dataTemp/16777216;
                                        dataTemp = dataTemp%16777216;
                                        readBit [1] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [2] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [3] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                                        
                                        if (arrayLineageExtraction2 [counter2*8+5] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8+5]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = arrayLineageExtraction2 [counter2*8+5];
                                        }
                                        
                                        readBit [0] = dataTemp/16777216;
                                        dataTemp = dataTemp%16777216;
                                        readBit [1] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [2] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [3] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                                        
                                        dataTemp = arrayLineageExtraction2 [counter2*8+6];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = arrayLineageExtraction2 [counter2*8+7];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < 25; counter3++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile (connectDataLineagePath.c_str(), ofstream::binary);
                                    outfile.write ((char*) writingArray, indexCount);
                                    outfile.close();
                                    
                                    delete [] writingArray;
                                    
                                    string connectStartEndPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_LineageStartEnd";
                                    
                                    int *lineageStartEndAuto = new int [lineageExtractionCount2+500];
                                    int lineageStartEndAutoCount = 0;
                                    
                                    lineageStartEndAutoCount = 0;
                                    
                                    int cellNumberStart = -1;
                                    int lineageNumberStart = 0;
                                    int firstEntryFind = 0;
                                    
                                    for (int counter1 = 0; counter1 < lineageExtractionCount2/8; counter1++){
                                        if ((arrayLineageExtraction2 [counter1*8+6] != lineageNumberStart || arrayLineageExtraction2 [counter1*8+5] != cellNumberStart) && firstEntryFind == 0){
                                            lineageNumberStart = arrayLineageExtraction2 [counter1*8+6];
                                            cellNumberStart = arrayLineageExtraction2 [counter1*8+5];
                                            
                                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageNumberStart, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = cellNumberStart, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8], lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8+1], lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8+2], lineageStartEndAutoCount++;
                                            
                                            firstEntryFind = 1;
                                        }
                                        else if ((arrayLineageExtraction2 [counter1*8+6] != lineageNumberStart || arrayLineageExtraction2 [counter1*8+5] != cellNumberStart) && firstEntryFind == 1){
                                            lineageNumberStart = arrayLineageExtraction2 [counter1*8+6];
                                            cellNumberStart = arrayLineageExtraction2 [counter1*8+5];
                                            
                                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1-1, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [(counter1-1)*8+2], lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = lineageNumberStart, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = cellNumberStart, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8], lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8+1], lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8+2], lineageStartEndAutoCount++;
                                        }
                                        
                                        if (counter1 == lineageExtractionCount2/8-1){
                                            lineageStartEndAuto [lineageStartEndAutoCount] = counter1, lineageStartEndAutoCount++;
                                            lineageStartEndAuto [lineageStartEndAutoCount] = arrayLineageExtraction2 [counter1*8+2], lineageStartEndAutoCount++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < lineageStartEndAutoCount/8; counterA++){
                                    //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<lineageStartEndAuto [counterA*8+counterB];
                                    //	cout<<" lineageStartEndAuto "<<counterA<<endl;
                                    //}
                                    
                                    if (lineageStartEndAutoCount != 0){
                                        char *mainDataEntry = new char [lineageStartEndAutoCount*7+10];
                                        int totalEntryCount = 0;
                                        string extension;
                                        
                                        for (int counter3 = 0; counter3 < lineageStartEndAutoCount; counter3++){
                                            extension = to_string(lineageStartEndAuto [counter3]);
                                            
                                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile2 (connectStartEndPath.c_str(), ofstream::binary);
                                        outfile2.write (mainDataEntry, totalEntryCount);
                                        outfile2.close();
                                        
                                        delete [] mainDataEntry;
                                    }
                                    
                                    delete [] lineageStartEndAuto;
                                    
                                    string mitosisStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+ analysisID+"_"+treatmentNameAuto+"_MitosisData";
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    checkFlag = 0;
                                    
                                    for (int counter2 = 0; counter2 < 6; counter2++){
                                        sizeForCopy = 0;
                                        
                                        if (stat(mitosisStatusPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        if (sizeForCopy != 0){
                                            if (counter2 == 0) size1 = sizeForCopy;
                                            else if (counter2 == 1) size2 = sizeForCopy;
                                            else if (counter2 == 2){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                    break;
                                                }
                                                else{
                                                    
                                                    size1 = 0;
                                                    size2 = 0;
                                                    usleep (50000);
                                                }
                                            }
                                            else if (counter2 == 3) size1 = sizeForCopy;
                                            else if (counter2 == 4) size2 = sizeForCopy;
                                            else if (counter2 == 5){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int *arrayMitosisTemp = new int [sizeForCopy+50];
                                    int mitosisTempCount = 0;
                                    
                                    if (checkFlag == 1){
                                        fin.open(mitosisStatusPath.c_str(), ios::in);
                                        
                                        if (fin.is_open()){
                                            string lineageNoGet;
                                            string cellNoGet;
                                            string imageNoGet;
                                            string setTypeGet;
                                            
                                            int terminationFlag = 0;
                                            
                                            do{
                                                
                                                terminationFlag = 1;
                                                getline(fin, lineageNoGet);
                                                
                                                if (lineageNoGet == "") terminationFlag = 0;
                                                else{
                                                    
                                                    getline(fin, cellNoGet);
                                                    getline(fin, imageNoGet);
                                                    getline(fin, setTypeGet);
                                                    
                                                    arrayMitosisTemp [mitosisTempCount] = atoi(lineageNoGet.c_str()), mitosisTempCount++;
                                                    arrayMitosisTemp [mitosisTempCount] = atoi(cellNoGet.c_str()), mitosisTempCount++;
                                                    arrayMitosisTemp [mitosisTempCount] = atoi(imageNoGet.c_str()), mitosisTempCount++;
                                                    arrayMitosisTemp [mitosisTempCount] = atoi(setTypeGet.c_str()), mitosisTempCount++;
                                                }
                                                
                                            } while (terminationFlag == 1);
                                            
                                            fin.close();
                                        }
                                        
                                        for (int counter2 = 0; counter2 < mitosisTempCount/4; counter2++){
                                            if (arrayMitosisTemp [counter2*4] == lineageExtractInt && arrayMitosisTemp [counter2*4+1] == cellNoExtractInt && arrayMitosisTemp [counter2*4+2] == newImagePosition-1){
                                                arrayMitosisTemp [counter2*4+3] = 10;
                                            }
                                            else if (arrayMitosisTemp [counter2*4] == lineageExtractInt && arrayMitosisTemp [counter2*4+1] == cellNoExtractInt){
                                                arrayMitosisTemp [counter2*4+3] = 0;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < mitosisTempCount/4; counterA++){
                                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayMitosisTemp [counterA*4+counterB];
                                        //    cout<<" arrayMitosisTempe "<<counterA<<endl;
                                        //}
                                        
                                        ofstream oin;
                                        oin.open(mitosisStatusPath.c_str(), ios::out);
                                        
                                        for (int counter1 = 0; counter1 < mitosisTempCount; counter1++) oin<<arrayMitosisTemp [counter1]<<endl;
                                        
                                        oin.close();
                                    }
                                    
                                    delete [] arrayMitosisTemp;
                                    delete [] arrayLineageExtraction2;
                                    
                                    int checkTimePoint = atoi(imageNoTemp.c_str());
                                    
                                    if (checkTimePoint == newImagePosition-1) checkTimePoint = newImagePosition-1;
                                    
                                    string extension = to_string(newImagePosition-1);
                                    string extension2 = to_string(checkTimePoint);
                                    
                                    string *queueListUpdateTemp = new string [queueListCount+50];
                                    int queueListUpdateTempCount = 0;
                                    
                                    queueListUpdateTemp [queueListUpdateTempCount] = treatmentNameAuto, queueListUpdateTempCount++;
                                    queueListUpdateTemp [queueListUpdateTempCount] = lineageNoAuto, queueListUpdateTempCount++;
                                    queueListUpdateTemp [queueListUpdateTempCount] = cellNoAuto, queueListUpdateTempCount++;
                                    queueListUpdateTemp [queueListUpdateTempCount] = extension+":"+extension2, queueListUpdateTempCount++;
                                    queueListUpdateTemp [queueListUpdateTempCount] = "0", queueListUpdateTempCount++;
                                    queueListUpdateTemp [queueListUpdateTempCount] = "Wait", queueListUpdateTempCount++;
                                    
                                    for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+1], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+2], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+3], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+4], queueListUpdateTempCount++;
                                        queueListUpdateTemp [queueListUpdateTempCount] = arrayQueueList [counter2*6+5], queueListUpdateTempCount++;
                                    }
                                    
                                    if (queueListUpdateTempCount > queueListLimit){
                                        delete [] arrayQueueList;
                                        arrayQueueList = new string [queueListUpdateTempCount+5000];
                                        queueListLimit = queueListUpdateTempCount+5000;
                                    }
                                    
                                    queueListCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < queueListUpdateTempCount; counter1++) arrayQueueList [queueListCount] = queueListUpdateTemp [counter1], queueListCount++;
                                    
                                    //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                    //    cout<<" arrayQueueList "<<counterA<<endl;
                                    //}
                                    
                                    string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                    
                                    if (queueListCount != 0){
                                        char *mainDataEntry = new char [queueListCount*12+10];
                                        int totalEntryCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                            extension = arrayQueueList [counter3];
                                            
                                            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                            }
                                            
                                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                        
                                        ofstream outfile2 (queueListPath.c_str(), ofstream::binary);
                                        outfile2.write (mainDataEntry, totalEntryCount);
                                        outfile2.close();
                                        
                                        delete [] mainDataEntry;
                                    }
                                    
                                    delete [] queueListUpdateTemp;
                                    
                                    extension = to_string(newImagePosition-1);
                                    
                                    if (extension.length() == 1) extension = "000"+extension;
                                    else if (extension.length() == 2) extension = "00"+extension;
                                    else if (extension.length() == 3) extension = "0"+extension;
                                    
                                    string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    checkFlag = 0;
                                    
                                    for (int counter3 = 0; counter3 < 6; counter3++){
                                        sizeForCopy = 0;
                                        
                                        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        if (sizeForCopy != 0){
                                            if (counter3 == 0) size1 = sizeForCopy;
                                            else if (counter3 == 1) size2 = sizeForCopy;
                                            else if (counter3 == 2){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                    break;
                                                }
                                                else{
                                                    
                                                    size1 = 0;
                                                    size2 = 0;
                                                    usleep (50000);
                                                }
                                            }
                                            else if (counter3 == 3) size1 = sizeForCopy;
                                            else if (counter3 == 4) size2 = sizeForCopy;
                                            else if (counter3 == 5){
                                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                    checkFlag = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    int *masterReadForAmend = new int [sizeForCopy+50];
                                    int masterReadForAmendCount = 0;
                                    
                                    if (checkFlag == 1){
                                        readingError = 0;
                                        
                                        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                                        
                                        uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                usleep(50000);
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                
                                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                    readingError = 1;
                                                }
                                            }
                                        }
                                        
                                        fin.close();
                                        
                                        if (readingError == 0){
                                            readPosition = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                    finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                                    finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                    finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                    finData [14] = uploadTemp [readPosition], readPosition++;
                                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                                    finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                    
                                                    finData [1] = finData [0]*256+finData [1];
                                                    finData [3] = finData [2]*256+finData [3];
                                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                    
                                                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                    
                                                    finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                    
                                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        masterReadForAmend [masterReadForAmendCount] = finData [1], masterReadForAmendCount++;
                                                        masterReadForAmend [masterReadForAmendCount] = finData [3], masterReadForAmendCount++;
                                                        masterReadForAmend [masterReadForAmendCount] = finData [4], masterReadForAmendCount++;
                                                        masterReadForAmend [masterReadForAmendCount] = finData [7], masterReadForAmendCount++;
                                                        masterReadForAmend [masterReadForAmendCount] = finData [12], masterReadForAmendCount++;
                                                        masterReadForAmend [masterReadForAmendCount] = finData [13], masterReadForAmendCount++;
                                                        masterReadForAmend [masterReadForAmendCount] = finData [16], masterReadForAmendCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    
                                    //for (int counterA = 0; counterA < masterReadForAmendCount/7; counterA++){
                                    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForAmend [counterA*7+counterB];
                                    //	cout<<" masterReadForAmend "<<counterA<<endl;
                                    //}
                                    
                                    string connectAmendPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_lineDataAmend";
                                    
                                    int entryCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                                        if (masterReadForAmend [counter1*7+4] == cellNoExtractInt && masterReadForAmend [counter1*7+6] == lineageExtractInt) entryCount++;
                                    }
                                    
                                    indexCount = 0;
                                    
                                    writingArray = new char [entryCount*13+20];
                                    
                                    //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                                    for (int counter1 = 0; counter1 < masterReadForAmendCount/7; counter1++){
                                        if (masterReadForAmend [counter1*7+4] == cellNoExtractInt && masterReadForAmend [counter1*7+6] == lineageExtractInt){
                                            dataTemp = newImagePosition-1;
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter1*7];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter1*7+1];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            writingArray [indexCount] = (char)amendLastEvent, indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter1*7+3];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            dataTemp = masterReadForAmend [counter1*7+6];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        }
                                    }
                                    
                                    for (int counter1 = 0; counter1 < 13; counter1++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile3 (connectAmendPath.c_str(), ofstream::binary);
                                    outfile3.write ((char*)writingArray, indexCount);
                                    outfile3.close();
                                    
                                    delete [] writingArray;
                                    delete [] masterReadForAmend;
                                }
                                
                                delete [] arrayLineageExtraction;
                            }
                            
                            remove (instructionRRPath.c_str());
                            connectionSend1 = 1;
                        }
                        else{
                            
                            checkStatusAuto = "LE";
                            
                            [self doneProcess];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"File Read Error: Check Database"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            cellCurvingRunningFlag = 2;
                            connectionSend1 = 0;
                            autoProcessTimingCount = 0;
                            autoProcessTiming = 0;
                        }
                    }
                    else{
                        
                        checkStatusAuto = "LE";
                        
                        [self doneProcess];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Read Error: Check Database"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        cellCurvingRunningFlag = 2;
                        connectionSend1 = 0;
                        autoProcessTimingCount = 0;
                        autoProcessTiming = 0;
                    }
                    
                    delete [] lineageAuto;
                }
                else if (checkStatusAuto == "TL/c" || checkStatusAuto == "TM/c"){
                    doneCheck = [self doneProcess];
                    
                    if (doneCheck == 0){
                        remove (instructionRRPath.c_str());
                        connectionSend1 = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"File Read Error: Check Database"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        cellCurvingRunningFlag = 2;
                        connectionSend1 = 0;
                        autoProcessTimingCount = 0;
                        autoProcessTiming = 0;
                    }
                }
                
                //======Redo status check==========
                int treatmentPosition = 0;
                int timeOneredo = 0;
                
                for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                    if (arrayTreatmentStatus [counter2*9] == treatmentNameAuto){
                        treatmentPosition = counter2;
                        timeOneredo = atoi(arrayTreatmentStatus [counter2*9+4].c_str());
                        break;
                    }
                }
                
                //**********Option operation array********
                //1. Setting condition (0: None, 1:Auto, 2:TLRmv (remove))
                //2. Remove Status (0: nil, 1:Not Ready, 2: Ready, 5. Done
                //3. Redo Status (0: nil, 1:Proceed-redo, 2:Proceed (when this is set, remove TL when auto Processing starts), 3:Cancel, 4:Done)
                //4. 1:Allow, 2:Not Allow
                
                if (arrayOperationData [treatmentPosition*4+3] == 1 && arrayOperationData [treatmentPosition*4] != 0){
                    int nonProcessingFind = 0;
                    
                    if (arrayOperationData [treatmentPosition*4+1] == 1){
                        string imageNoCommTemp;
                        
                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                            imageNoCommTemp = arrayQueueList [counter2*6+3];
                            if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
                            
                            if (treatmentNameAuto == arrayQueueList [counter2*6] && atoi(imageNoCommTemp.c_str()) == timeOneredo){
                                nonProcessingFind = 1;
                                break;
                            }
                        }
                        
                        if (nonProcessingFind == 0){
                            int autoProcessingFlag = 0;
                            
                            if (arrayOperationData [treatmentPosition*4] == 1){
                                arrayOperationData [treatmentPosition*4+1] = 5;
                                arrayOperationData [treatmentPosition*4+2] = 1;
                                autoProcessingFlag = 1;
                            }
                            else if (arrayOperationData [treatmentPosition*4] == 2){
                                arrayOperationData [treatmentPosition*4+1] = 2;
                                optionDisplayCall = 1;
                            }
                            
                            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
                            
                            ofstream oin;
                            oin.open(optionPath.c_str(), ios::out);
                            
                            for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                                oin<<arrayOperationData [counter2*4]<<endl;
                                oin<<arrayOperationData [counter2*4+1]<<endl;
                                oin<<arrayOperationData [counter2*4+2]<<endl;
                                oin<<arrayOperationData [counter2*4+3]<<endl;
                            }
                            
                            oin<<"End"<<endl;
                            oin.close();
                            
                            //=======Auto process=========
                            if (autoProcessingFlag == 1){
                                int processType = 1;
                                string lineageDoneNo;
                                
                                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                                //	cout<<" arrayDoneList "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                //	cout<<" arrayQueueList "<<counterA<<endl;
                                //}
                                
                                string *arrayDoneListTemp2 = new string [doneListCount+50];
                                int doneListTempCount2 = 0;
                                
                                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                    if (arrayDoneList [counter1*5] == treatmentNameAuto && arrayDoneList [counter1*5+4] == "TL"){
                                        arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter1*5], doneListTempCount2++;
                                        arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter1*5+1], doneListTempCount2++;
                                        arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter1*5+2], doneListTempCount2++;
                                        arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter1*5+3], doneListTempCount2++;
                                        arrayDoneListTemp2 [doneListTempCount2] = arrayDoneList [counter1*5+4], doneListTempCount2++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < doneListTempCount2/5; counterA++){
                                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneListTemp2 [counterA*5+counterB];
                                //	cout<<" arrayDoneListTemp2 "<<counterA<<endl;
                                //}
                                
                                int lineageDoneNoInt = 0;
                                int delCellNo = 0;
                                int delStartNo = 0;
                                int addDeleteStatus = 0;
                                
                                for (int counter1 = 0; counter1 < doneListTempCount2/5; counter1++){
                                    lineageDoneNo = arrayDoneListTemp2 [counter1*5+1];
                                    lineageDoneNo = lineageDoneNo.substr(1);
                                    lineageDoneNoInt = atoi(lineageDoneNo.c_str());
                                    delCellNo = 0;
                                    delStartNo = 0;
                                    
                                    addDeleteAuto = [[AddDeleteAuto alloc] init];
                                    addDeleteStatus = [addDeleteAuto delLineageMain:lineageDoneNoInt:processType:delCellNo:delStartNo];
                                    
                                    if (addDeleteStatus == -1){
                                        usleep (50000);
                                        
                                        addDeleteAuto = [[AddDeleteAuto alloc] init];
                                        addDeleteStatus = [addDeleteAuto delLineageMain:lineageDoneNoInt:processType:delCellNo:delStartNo];
                                        
                                        if (addDeleteStatus == -1){
                                            usleep (50000);
                                            
                                            addDeleteAuto = [[AddDeleteAuto alloc] init];
                                            [addDeleteAuto delLineageMain:lineageDoneNoInt:processType:delCellNo:delStartNo];
                                        }
                                    }
                                }
                                
                                string *arrayDoneListTemp = new string [doneListCount+50];
                                int doneListTempCount = 0;
                                
                                string *arrayQueueListTemp = new string [queueListCount+50];
                                int queueListTempCount = 0;
                                
                                string *arrayQueueListTemp2 = new string [queueListCount+50];
                                int queueListTempCount2 = 0;
                                
                                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                //	cout<<" arrayQueueList "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                                // 	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                                // 	cout<<" arrayDoneList "<<counterA<<endl;
                                //}
                                
                                for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                                    if (arrayDoneList [counter1*5] == treatmentNameAuto && arrayDoneList [counter1*5+4] != "CF" && arrayDoneList [counter1*5+4] != "CF/m" && arrayDoneList [counter1*5+4] != "OK" && arrayDoneList [counter1*5+4] != "OK/m" && arrayDoneList [counter1*5+4] != "OK/e" && arrayDoneList [counter1*5+4] != "OK/me"&& arrayDoneList [counter1*5+2] == "C000000000"){
                                        arrayQueueList [queueListCount] = treatmentNameAuto, queueListCount++;
                                        arrayQueueList [queueListCount] = arrayDoneList [counter1*5+1], queueListCount++;
                                        arrayQueueList [queueListCount] = "C000000000", queueListCount++;
                                        arrayQueueList [queueListCount] = arrayDoneList [counter1*5+3], queueListCount++;
                                        arrayQueueList [queueListCount] = "0", queueListCount++;
                                        arrayQueueList [queueListCount] = "Redo", queueListCount++;
                                    }
                                    else{
                                        
                                        arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter1*5], doneListTempCount++;
                                        arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter1*5+1], doneListTempCount++;
                                        arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter1*5+2], doneListTempCount++;
                                        arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter1*5+3], doneListTempCount++;
                                        arrayDoneListTemp [doneListTempCount] = arrayDoneList [counter1*5+4], doneListTempCount++;
                                    }
                                }
                                
                                doneListCount = 0;
                                
                                for (int counter1 = 0; counter1 < doneListTempCount; counter1++) arrayDoneList [doneListCount] = arrayDoneListTemp [counter1], doneListCount++;
                                
                                //for (int counterA = 0; counterA < doneListCount/5; counterA++){
                                //	for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
                                //	cout<<" arrayDoneList "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < queueListCount/6; counterA++){
                                //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
                                //	cout<<" arrayQueueList "<<counterA<<endl;
                                //}
                                
                                delete [] arrayDoneListTemp;
                                delete [] arrayDoneListTemp2;
                                
                                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                                
                                if (doneListCount != 0){
                                    char *mainDataEntry = new char [doneListCount*10+10];
                                    int totalEntryCount = 0;
                                    string extension;
                                    
                                    for (int counter3 = 0; counter3 < doneListCount; counter3++){
                                        extension = arrayDoneList [counter3];
                                        
                                        for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                            mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                                        }
                                        
                                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    }
                                    
                                    mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                                    
                                    ofstream outfile3 (doneListPath.c_str(), ofstream::binary);
                                    outfile3.write (mainDataEntry, totalEntryCount);
                                    outfile3.close();
                                    
                                    delete [] mainDataEntry;
                                }
                                
                                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                    if (arrayQueueList [counter1*6] == treatmentNameAuto){
                                        imageNoCommTemp = arrayQueueList [counter1*6+3];
                                        
                                        if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
                                        
                                        if (arrayQueueList [counter1*6+5] != "Redo" && atoi(imageNoCommTemp.c_str()) <= timeOneredo+10 && arrayQueueList [counter1*6+2] == "C000000000"){
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+1], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+2], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+3], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+4], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = "Redo", queueListTempCount++;
                                        }
                                        else{
                                            
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+1], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+2], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+3], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+4], queueListTempCount++;
                                            arrayQueueListTemp [queueListTempCount] = arrayQueueList [counter1*6+5], queueListTempCount++;
                                        }
                                    }
                                    else{
                                        
                                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6], queueListTempCount2++;
                                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+1], queueListTempCount2++;
                                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+2], queueListTempCount2++;
                                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+3], queueListTempCount2++;
                                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+4], queueListTempCount2++;
                                        arrayQueueListTemp2 [queueListTempCount2] = arrayQueueList [counter1*6+5], queueListTempCount2++;
                                    }
                                }
                                
                                queueListCount = 0;
                                
                                for (int counter1 = 0; counter1 < queueListTempCount; counter1++) arrayQueueList [queueListCount] = arrayQueueListTemp [counter1], queueListCount++;
                                for (int counter1 = 0; counter1 < queueListTempCount2; counter1++) arrayQueueList [queueListCount] = arrayQueueListTemp2 [counter1], queueListCount++;
                                
                                delete [] arrayQueueListTemp;
                                delete [] arrayQueueListTemp2;
                                
                                string lineageCommPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+analysisID+"_"+treatmentNameAuto+"_LineageData";
                                
                                struct stat sizeOfFile;
                                long sizeForCopy = 0;
                                long size1 = 0;
                                long size2 = 0;
                                int checkFlag = 0;
                                int readingError = 0;
                                
                                for (int counter3 = 0; counter3 < 6; counter3++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(lineageCommPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter3 == 0) size1 = sizeForCopy;
                                        else if (counter3 == 1) size2 = sizeForCopy;
                                        else if (counter3 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter3 == 3) size1 = sizeForCopy;
                                        else if (counter3 == 4) size2 = sizeForCopy;
                                        else if (counter3 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                int *lineageCommTemp = new int [sizeForCopy+50];
                                int lineageCommTempCount = 0;
                                
                                if (checkFlag == 1){
                                    readingError = 0;
                                    int finData [25];
                                    
                                    fin.open(lineageCommPath.c_str(), ios::in | ios::binary);
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        unsigned long readPosition = 0;
                                        int stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++;
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                                finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                                finData [15] = uploadTemp [readPosition], readPosition++;
                                                finData [16] = uploadTemp [readPosition], readPosition++;
                                                finData [17] = uploadTemp [readPosition], readPosition++;
                                                finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                                finData [19] = uploadTemp [readPosition], readPosition++;
                                                finData [20] = uploadTemp [readPosition], readPosition++;
                                                finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                                finData [22] = uploadTemp [readPosition], readPosition++;
                                                finData [23] = uploadTemp [readPosition], readPosition++;
                                                finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                                
                                                if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                                else finData [2] = finData [1]*256+finData [2];
                                                
                                                if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                                else finData [5] = finData [4]*256+finData [5];
                                                
                                                finData [7] = finData [6]*256+finData [7];
                                                
                                                if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                                else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                                
                                                if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                                else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                                
                                                finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                                finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                                
                                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                else{
                                                    
                                                    lineageCommTemp [lineageCommTempCount] = finData [2], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [5], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [7], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [8], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [13], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [18], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [21], lineageCommTempCount++;
                                                    lineageCommTemp [lineageCommTempCount] = finData [24], lineageCommTempCount++;
                                                }
                                            }
                                            
                                        } while (stepCount != 3);
                                    }
                                    
                                    delete [] uploadTemp;
                                }
                                
                                string timeOneAuto = "";
                                
                                for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
                                    if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
                                        timeOneAuto = arrayTreatmentStatus [counter1*9+4];
                                        break;
                                    }
                                }
                                
                                string lineageNo;
                                string cellNoRedo;
                                string extension1;
                                int lineageNoInt = 0;
                                int cellNoRedoInt = 0;
                                int timePointLast = 0;
                                int findLineage = 0;
                                
                                for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                                    if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+5] == "Redo"){
                                        lineageNo = arrayQueueList [counter1*6+1];
                                        lineageNo = lineageNo.substr(1);
                                        lineageNoInt = atoi(lineageNo.c_str());
                                        cellNoRedo = arrayQueueList [counter1*6+2];
                                        cellNoRedo = cellNoRedo.substr(1);
                                        cellNoRedoInt = atoi(cellNoRedo.c_str());
                                        
                                        timePointLast = 0;
                                        findLineage = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageCommTempCount/8; counter2++){
                                            if (lineageCommTemp [counter2*8+6] == lineageNoInt && lineageCommTemp [counter2*8+5] == cellNoRedoInt && findLineage == 0){
                                                findLineage = 1;
                                                timePointLast = lineageCommTemp [counter2*8+2];
                                            }
                                            else if (lineageCommTemp [counter2*8+6] == lineageNoInt && lineageCommTemp [counter2*8+5] == cellNoRedoInt && findLineage == 1){
                                                timePointLast = lineageCommTemp [counter2*8+2];
                                            }
                                            else if ((lineageCommTemp [counter2*8+6] != lineageNoInt || lineageCommTemp [counter2*8+5] != cellNoRedoInt) && findLineage == 1){
                                                break;
                                            }
                                        }
                                        
                                        extension1 = to_string(timePointLast);
                                        
                                        arrayQueueList [counter1*6+3] = extension1+":"+timeOneAuto;
                                    }
                                }
                                
                                delete [] lineageCommTemp;
                                
                                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                                
                                if (queueListCount != 0){
                                    char *mainDataEntry2 = new char [queueListCount*12+10];
                                    int totalEntryCount2 = 0;
                                    string extension;
                                    
                                    for (int counter3 = 0; counter3 < queueListCount; counter3++){
                                        extension =arrayQueueList [counter3];
                                        
                                        for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                                            mainDataEntry2 [totalEntryCount2] = (char)extension.at((unsigned long)counter4), totalEntryCount2++;
                                        }
                                        
                                        mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                                    }
                                    
                                    mainDataEntry2 [totalEntryCount2] = 'E', totalEntryCount2++;
                                    mainDataEntry2 [totalEntryCount2] = 'n', totalEntryCount2++;
                                    mainDataEntry2 [totalEntryCount2] = 'd', totalEntryCount2++;
                                    mainDataEntry2 [totalEntryCount2] = 0x0a, totalEntryCount2++;
                                    
                                    ofstream outfile6 (queueListPath.c_str(), ofstream::binary);
                                    outfile6.write (mainDataEntry2, totalEntryCount2);
                                    outfile6.close();
                                    
                                    delete [] mainDataEntry2;
                                }
                            }
                            
                            optionCall = 1;
                        }
                    }
                    else if (arrayOperationData [treatmentPosition*4+1] == 5 && arrayOperationData [treatmentPosition*4+2] == 1){
                        int redoFind = 0;
                        
                        for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                            if (treatmentNameAuto == arrayQueueList [counter2*6] && arrayQueueList [counter2*6+5] == "Redo"){
                                redoFind = 1;
                                break;
                            }
                        }
                        
                        if (redoFind == 0){
                            arrayOperationData [treatmentPosition*4+2] = 4;
                            arrayOperationData [treatmentPosition*4+3] = 2;
                            
                            string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
                            
                            ofstream oin;
                            oin.open(optionPath.c_str(), ios::out);
                            
                            for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                                oin<<arrayOperationData [counter2*4]<<endl;
                                oin<<arrayOperationData [counter2*4+1]<<endl;
                                oin<<arrayOperationData [counter2*4+2]<<endl;
                                oin<<arrayOperationData [counter2*4+3]<<endl;
                            }
                            
                            oin<<"End"<<endl;
                            oin.close();
                            
                            optionCall = 1;
                        }
                    }
                }
                else if (arrayOperationData [treatmentPosition*4+3] == 1 && arrayOperationData [treatmentPosition*4] == 0){
                    int nonProcessingFind = 0;
                    
                    string imageNoCommTemp;
                    
                    for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                        imageNoCommTemp = arrayQueueList [counter2*6+3];
                        
                        if ((int)imageNoCommTemp.find(":") != -1) imageNoCommTemp = imageNoCommTemp.substr(0, imageNoCommTemp.find(":"));
                        
                        if (treatmentNameAuto == arrayQueueList [counter2*6] && atoi(imageNoCommTemp.c_str()) == timeOneredo){
                            nonProcessingFind = 1;
                            break;
                        }
                    }
                    
                    if (nonProcessingFind == 0){
                        if (arrayOperationData [treatmentPosition*4] == 0) arrayOperationData [treatmentPosition*4+3] = 2;
                        
                        string optionPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*Option.dat";
                        
                        ofstream oin;
                        oin.open(optionPath.c_str(), ios::out);
                        
                        for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                            oin<<arrayOperationData [counter2*4]<<endl;
                            oin<<arrayOperationData [counter2*4+1]<<endl;
                            oin<<arrayOperationData [counter2*4+2]<<endl;
                            oin<<arrayOperationData [counter2*4+3]<<endl;
                        }
                        
                        oin<<"End"<<endl;
                        oin.close();
                        
                        optionCall = 1;
                    }
                }
                
                trackingTableSetDone = 1;
                revisedWorkingMapTime2 = 0;
            }
        }
        else{
            
            remove (instructionRRPath.c_str());
            remove (instructionCCPath.c_str());
            
            ofstream oin;
            
            for (int counter1 = 0; counter1 < 10; counter1++){
                oin.open(instructionCCPath.c_str(), ios::out);
                
                if (oin.is_open()){
                    oin<<analysisImageName<<endl;
                    oin<<analysisID<<endl;
                    oin<<"Exit"<<endl;
                    oin<<"Exit"<<endl;
                    oin<<"Exit"<<endl;
                    oin<<"Exit"<<endl;
                    oin<<"Exit"<<endl;
                    
                    oin.close();
                    
                    break;
                }
            }
            
            cellCurvingRunningFlag = 2;
            connectionSend1 = 0;
            autoProcessTimingCount = 0;
            autoProcessTiming = 0;
        }
    }
    else{
        
        autoProcessTimingCount = 0;
        autoProcessTiming = 0;
    }
    
    //-----End Time update-----
    if ((trackingOn == 1 || trackingOn == 3) && runStatusCellCurving == 0){
        if (reviseTimingCount > 600){
            reviseTimingCount = 0;
            
            upDateCompleteFlag = 1;
            [self timeEndRevise];
            upDateCompleteFlag = 0;
        }
        else reviseTimingCount++;
    }
}

-(int)doneProcess{
    int doneComplete = 0;
    
    //-----Return messages-----
    
    //cout<<treatmentNameAuto<<" "<<lineageNoAuto<<" "<<cellNoAuto<<" "<<checkStatusAuto<<" "<<imageNoAuto<<" "<<additionalInfoAuto<<" Extract"<<endl;
    
    if (checkStatusAuto == "BD" || checkStatusAuto == "TD" || checkStatusAuto == "HD" || checkStatusAuto == "PD" || checkStatusAuto == "MD" || checkStatusAuto == "NS" || checkStatusAuto == "CD" || checkStatusAuto == "IP" || checkStatusAuto == "MC" || checkStatusAuto == "AC" || checkStatusAuto == "DB" || checkStatusAuto == "RC" || checkStatusAuto == "SC" || checkStatusAuto == "CM" || checkStatusAuto == "CN" || checkStatusAuto == "FM" || checkStatusAuto == "TL" || checkStatusAuto == "FE" || checkStatusAuto == "FO" || checkStatusAuto == "NX" || checkStatusAuto == "MF" || checkStatusAuto == "NM" || checkStatusAuto == "DL" || checkStatusAuto == "OF" || checkStatusAuto == "FC" || checkStatusAuto == "ME" || checkStatusAuto == "CF" || checkStatusAuto == "IM" || checkStatusAuto == "TM"){
        
        int returnStatus = 0;
        
        trackRecordAuto = [[TrackRecordAuto alloc] init];
        returnStatus = [trackRecordAuto trackDataAutoMain];
        
        do{
        } while (subCompleteFlag == 1);
        
        if (returnStatus == -1){
            string cellLineageExtract = lineageNoAuto.substr(1);
            string cellNoExtract = cellNoAuto.substr(1);
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            int cellAmendTemp = atoi(cellNoExtract.c_str());
            int fusionMarkFind = 0;
            
            string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_CellStatus";
            
            ifstream fin;
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *masterReadForCellInfo = new int [sizeForCopy+50];
            int masterReadForCellInfoCount = 0;
            
            if (sizeForCopy != 0){
                fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    char *uploadTemp = new char [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    string dataString = "";
                    int readPosition = 0;
                    
                    do{
                        
                        if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                        else if (dataString != "End"){
                            masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                            dataString = "";
                        }
                        
                        readPosition++;
                        
                    } while (dataString != "End");
                    
                    delete [] uploadTemp;
                }
            }
            
            //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
            //	cout<<" masterReadForCellInfo "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
                if (masterReadForCellInfo [counter1*7] == cellAmendTemp && masterReadForCellInfo [counter1*7+6] == lineageAmendTemp){
                    if (masterReadForCellInfo [counter1*7+5] >= 21 && masterReadForCellInfo [counter1*7+5] <= 46){
                        masterReadForCellInfo [counter1*7+5] = 44;
                    }
                    else if (masterReadForCellInfo [counter1*7+5] == 0){
                        masterReadForCellInfo [counter1*7+5] = 44;
                    }
                    else if (masterReadForCellInfo [counter1*7+5] >= 51 && masterReadForCellInfo [counter1*7+5] <= 76){
                        masterReadForCellInfo [counter1*7+5] = 75;
                        fusionMarkFind = 1;
                    }
                    else if (masterReadForCellInfo [counter1*7+5] == 77){
                        masterReadForCellInfo [counter1*7+5] = 75;
                        fusionMarkFind = 1;
                    }
                    
                    break;
                }
            }
            
            //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
            //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
            //	cout<<" masterReadForCellInfo "<<counterA<<endl;
            //}
            
            char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
            int totalEntryCount = 0;
            string extension;
            
            for (int counter3 = 0; counter3 < masterReadForCellInfoCount; counter3++){
                extension = to_string(masterReadForCellInfo [counter3]);
                
                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
            outfile2.write (mainDataEntry, totalEntryCount);
            outfile2.close();
            
            delete [] mainDataEntry;
            delete [] masterReadForCellInfo;
            
            string queueTime = "1";
            
            for (int counter2 = 0; counter2 < queueListCount/6; counter2++){
                if (arrayQueueList [counter2*6] == treatmentNameAuto && arrayQueueList [counter2*6+1] == lineageNoAuto && arrayQueueList [counter2*6+2] == cellNoAuto){
                    queueTime = arrayQueueList [counter2*6+3];
                    break;
                }
            }
            
            string *queueStringTemp = new string [queueListCount+50];
            int queueStringTempCount = 0;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != lineageNoAuto || arrayQueueList [counter1*6+2] != cellNoAuto){
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                }
            }
            
            queueListCount = 0;
            
            for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                mainDataEntry = new char [queueListCount*12+10];
                totalEntryCount = 0;
                
                for (int counter1 = 0; counter1 < queueListCount; counter1++){
                    extension = arrayQueueList [counter1];
                    
                    for (int counter2 = 0; counter2 < (int)extension.length(); counter2++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter2), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile3 (queueListPath.c_str(), ofstream::binary);
                outfile3.write (mainDataEntry, totalEntryCount);
                outfile3.close();
                
                delete [] mainDataEntry;
            }
            
            delete [] queueStringTemp;
            
            int findString = (int)queueTime.find(":");
            if (findString != -1) queueTime = queueTime.substr((unsigned long)findString+1);
            
            string *doneListUpdateTemp = new string [doneListCount+50];
            int doneListUpdateTempCount = 0;
            
            for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
                if (arrayDoneList [counter2*5] != treatmentNameAuto || arrayDoneList [counter2*5+1] != lineageNoAuto || arrayDoneList [counter2*5+2] != cellNoAuto){
                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+1], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+2], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+3], doneListUpdateTempCount++;
                    doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+4], doneListUpdateTempCount++;
                }
            }
            
            doneListCount = 0;
            
            for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
            
            if (doneListCount+10 > doneListLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate doneListUpDate];
            }
            
            arrayDoneList [doneListCount] = treatmentNameAuto, doneListCount++;
            arrayDoneList [doneListCount] = lineageNoAuto, doneListCount++;
            arrayDoneList [doneListCount] = cellNoAuto, doneListCount++;
            arrayDoneList [doneListCount] = queueTime+":"+queueTime, doneListCount++;
            
            if (fusionMarkFind == 0) arrayDoneList [doneListCount] = "XS", doneListCount++;
            else arrayDoneList [doneListCount] = "XS/m", doneListCount++;
            
            //for (int counterA = 0; counterA < doneListUpdateTempCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayDoneList [counterA*5+counterB];
            //    cout<<" arrayDoneList "<<counterA<<endl;
            //}
            
            string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
            
            if (doneListCount != 0){
                mainDataEntry = new char [doneListCount*10+10];
                totalEntryCount = 0;
                
                for (int counter3 = 0; counter3 < doneListCount; counter3++){
                    extension = arrayDoneList [counter3];
                    
                    for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile9 (doneListPath.c_str(), ofstream::binary);
                outfile9.write (mainDataEntry, totalEntryCount);
                outfile9.close();
                
                delete [] mainDataEntry;
            }
            
            delete [] doneListUpdateTemp;
        }
        
        string cleaningPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
        
        string entry;
        string cleaningFilePath;
        
        fileDeleteCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(cleaningPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (fileDeleteCount+5 > fileDeleteLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate fileDeleteUpDate];
                }
                
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                entry = arrayFileDelete [counter4];
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    int findString = (int)entry.find("_lineDataAmend");
                    
                    if (findString == -1){
                        cleaningFilePath = cleaningPath+"/"+entry;
                        remove (cleaningFilePath.c_str());
                    }
                }
            }
        }
    }
    else if (checkStatusAuto == "LE" || checkStatusAuto == "MS"){
        string timeEndComm = "";
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
                timeEndComm = arrayTreatmentStatus [counter1*9+5];
                break;
            }
        }
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            if (arrayQueueList [counter1*6+5] == "Proc"){
                arrayQueueList [counter1*6+5] = "Wait";
            }
        }
        
        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
        
        if (queueListCount != 0){
            string extension;
            
            char *mainDataEntry = new char [queueListCount*12+10];
            int totalEntryCount = 0;
            
            for (int counter3 = 0; counter3 < queueListCount; counter3++){
                extension = arrayQueueList [counter3];
                
                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile (queueListPath.c_str(), ofstream::binary);
            outfile.write (mainDataEntry, totalEntryCount);
            outfile.close();
            
            delete [] mainDataEntry;
        }
        
        remove (instructionRRPath.c_str());
        remove (instructionCCPath.c_str());
        
        ofstream oin;
        
        for (int counter1 = 0; counter1 < 10; counter1++){
            oin.open(instructionCCPath.c_str(), ios::out);
            
            if (oin.is_open()){
                oin<<analysisImageName<<endl;
                oin<<analysisID<<endl;
                oin<<"Exit"<<endl;
                oin<<"Exit"<<endl;
                oin<<"Exit"<<endl;
                oin<<"Exit"<<endl;
                oin<<"Exit"<<endl;
                
                oin.close();
                
                break;
            }
        }
        
        string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
        string entry;
        string removeFilePath;
        
        fileDeleteCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(connectClearPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (fileDeleteCount+5 > fileDeleteLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate fileDeleteUpDate];
                }
                
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                entry = arrayFileDelete [counter4];
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                    int findFile2 = (int)entry.find("CutTemp");
                    int findFile3 = (int)entry.find("GCCurrentTemp");
                    int findFile4 = (int)entry.find("MasterDataTemp");
                    int findFile5 = (int)entry.find("RevisedTempMap");
                    int findFile6 = (int)entry.find("StatusTemp");
                    int findFile7 = (int)entry.find("LinkDataTemp");
                    int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                    int findFile9 = (int)entry.find("ExtendLineDataTemp");
                    int findFile10 = (int)entry.find("EventTemp");
                    int findFile11 = (int)entry.find("MitosisDataTemp");
                    int findFile12 = (int)entry.find("GCCenterInfo");
                    
                    if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                        removeFilePath = connectClearPath+"/"+entry;
                        remove (removeFilePath.c_str());
                    }
                }
            }
        }
    }
    else if (checkStatusAuto == "AM" || checkStatusAuto == "CL" || checkStatusAuto == "MD/c" || checkStatusAuto == "NS/c" || checkStatusAuto == "CM/c" || checkStatusAuto == "CN/c" || checkStatusAuto == "FM/c" || checkStatusAuto == "FE/c" || checkStatusAuto == "FO/c" || checkStatusAuto == "DL/c" || checkStatusAuto == "OF/c" || checkStatusAuto == "ME/c" || checkStatusAuto == "TL/c" || checkStatusAuto == "TM/c" || checkStatusAuto == "MF/c"){
        string *queueStringTemp = new string [queueListCount+50];
        int queueStringTempCount = 0;
        
        string queueTime = "";
        
        for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
            if (arrayQueueList [counter1*6+5] != "Proc"){
                queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
            }
            else queueTime = arrayQueueList [counter1*6+3];
        }
        
        queueListCount = 0;
        
        for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
        
        string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
        
        if (queueListCount != 0){
            string extension;
            
            char *mainDataEntry = new char [queueListCount*12+10];
            int totalEntryCount = 0;
            
            for (int counter3 = 0; counter3 < queueListCount; counter3++){
                extension = arrayQueueList [counter3];
                
                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile (queueListPath.c_str(), ofstream::binary);
            outfile.write (mainDataEntry, totalEntryCount);
            outfile.close();
            
            delete [] mainDataEntry;
        }
        
        delete [] queueStringTemp;
        
        string cellLineageExtract = lineageNoAuto.substr(1);
        string cellNoExtract = cellNoAuto.substr(1);
        int lineageAmendTemp = atoi(cellLineageExtract.c_str());
        int cellAmendTemp = atoi(cellNoExtract.c_str());
        int fusionMarkFind = 0;
        
        string lineageFolderPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+analysisID+"_"+lineageNoAuto+"_CellStatus";
        
        ifstream fin;
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(lineageFolderPath2.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *masterReadForCellInfo = new int [sizeForCopy+50];
        int masterReadForCellInfoCount = 0;
        
        if (sizeForCopy != 0){
            fin.open(lineageFolderPath2.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                char *uploadTemp = new char [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                string dataString = "";
                int readPosition = 0;
                
                do{
                    
                    if (uploadTemp [readPosition] != 10) dataString = dataString+uploadTemp [readPosition];
                    else if (dataString != "End"){
                        masterReadForCellInfo [masterReadForCellInfoCount] = atoi(dataString.c_str()), masterReadForCellInfoCount++;
                        dataString = "";
                    }
                    
                    readPosition++;
                    
                } while (dataString != "End");
                
                delete [] uploadTemp;
            }
        }
        
        for (int counter1 = 0; counter1 < masterReadForCellInfoCount/7; counter1++){
            if (masterReadForCellInfo [counter1*7] == cellAmendTemp && masterReadForCellInfo [counter1*7+6] == lineageAmendTemp){
                if (masterReadForCellInfo [counter1*7+5] >= 51 && masterReadForCellInfo [counter1*7+5] <= 77){
                    fusionMarkFind = 1;
                }
                
                if (fusionMarkFind == 0){
                    if (checkStatusAuto == "MD/c") masterReadForCellInfo [counter1*7+5] = 23, checkStatusAuto = "MD";
                    else if (checkStatusAuto == "NS/c") masterReadForCellInfo [counter1*7+5] = 24, checkStatusAuto = "NS";
                    else if (checkStatusAuto == "CM/c") masterReadForCellInfo [counter1*7+5] = 31, checkStatusAuto = "CM";
                    else if (checkStatusAuto == "CN/c") masterReadForCellInfo [counter1*7+5] = 32, checkStatusAuto = "CN";
                    else if (checkStatusAuto == "FM/c") masterReadForCellInfo [counter1*7+5] = 33, checkStatusAuto = "FM";
                    else if (checkStatusAuto == "TL/c" || checkStatusAuto == "TM/c") masterReadForCellInfo [counter1*7+5] = 34, checkStatusAuto = "TL";
                    else if (checkStatusAuto == "FE/c") masterReadForCellInfo [counter1*7+5] = 35, checkStatusAuto = "FE";
                    else if (checkStatusAuto == "FO/c") masterReadForCellInfo [counter1*7+5] = 36, checkStatusAuto = "FO";
                    else if (checkStatusAuto == "DL/c") masterReadForCellInfo [counter1*7+5] = 39, checkStatusAuto = "DL";
                    else if (checkStatusAuto == "OF/c") masterReadForCellInfo [counter1*7+5] = 40, checkStatusAuto = "OF";
                    else if (checkStatusAuto == "ME/c") masterReadForCellInfo [counter1*7+5] = 42, checkStatusAuto = "ME";
                    else if (checkStatusAuto == "AM") masterReadForCellInfo [counter1*7+5] = 45;
                    else if (checkStatusAuto == "CL") masterReadForCellInfo [counter1*7+5] = 46;
                }
                else if (fusionMarkFind == 1){
                    if (checkStatusAuto == "MD/c") masterReadForCellInfo [counter1*7+5] = 53, checkStatusAuto = "MD";
                    else if (checkStatusAuto == "NS/c") masterReadForCellInfo [counter1*7+5] = 54, checkStatusAuto = "NS";
                    else if (checkStatusAuto == "CM/c") masterReadForCellInfo [counter1*7+5] = 61, checkStatusAuto = "CM";
                    else if (checkStatusAuto == "CN/c") masterReadForCellInfo [counter1*7+5] = 62, checkStatusAuto = "CN";
                    else if (checkStatusAuto == "FM/c") masterReadForCellInfo [counter1*7+5] = 63, checkStatusAuto = "FM";
                    else if (checkStatusAuto == "TL/c" || checkStatusAuto == "TM/c") masterReadForCellInfo [counter1*7+5] = 64, checkStatusAuto = "TL";
                    else if (checkStatusAuto == "FE/c") masterReadForCellInfo [counter1*7+5] = 65, checkStatusAuto = "FE";
                    else if (checkStatusAuto == "FO/c") masterReadForCellInfo [counter1*7+5] = 66, checkStatusAuto = "FO";
                    else if (checkStatusAuto == "DL/c") masterReadForCellInfo [counter1*7+5] = 69, checkStatusAuto = "DL";
                    else if (checkStatusAuto == "OF/c") masterReadForCellInfo [counter1*7+5] = 70, checkStatusAuto = "OF";
                    else if (checkStatusAuto == "ME/c") masterReadForCellInfo [counter1*7+5] = 62, checkStatusAuto = "ME";
                    else if (checkStatusAuto == "AM") masterReadForCellInfo [counter1*7+5] = 75;
                    else if (checkStatusAuto == "CL") masterReadForCellInfo [counter1*7+5] = 76;
                }
                
                break;
            }
        }
        
        //for (int counterA = 0; counterA < masterReadForCellInfoCount/7; counterA++){
        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<masterReadForCellInfo [counterA*7+counterB];
        //    cout<<" masterReadForCellInfo "<<counterA<<endl;
        //}
        
        char *mainDataEntry = new char [masterReadForCellInfoCount*7+10];
        int totalEntryCount = 0;
        string extension;
        
        for (int counter3 = 0; counter3 < masterReadForCellInfoCount; counter3++){
            extension = to_string(masterReadForCellInfo [counter3]);
            
            for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
        }
        
        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
        
        ofstream outfile2 (lineageFolderPath2.c_str(), ofstream::binary);
        outfile2.write (mainDataEntry, totalEntryCount);
        outfile2.close();
        
        delete [] mainDataEntry;
        delete [] masterReadForCellInfo;
        
        int findString = (int)queueTime.find(":");
        if (findString != -1) queueTime = queueTime.substr((unsigned long)findString+1);
        
        string *doneListUpdateTemp = new string [doneListCount+50];
        int doneListUpdateTempCount = 0;
        
        for (int counter2 = 0; counter2 < doneListCount/5; counter2++){
            if (arrayDoneList [counter2*5] != treatmentNameAuto || arrayDoneList [counter2*5+1] != lineageNoAuto || arrayDoneList [counter2*5+2] != cellNoAuto){
                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5], doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+1], doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+2], doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+3], doneListUpdateTempCount++;
                doneListUpdateTemp [doneListUpdateTempCount] = arrayDoneList [counter2*5+4], doneListUpdateTempCount++;
            }
        }
        
        doneListCount = 0;
        
        for (int counter1 = 0; counter1 < doneListUpdateTempCount; counter1++) arrayDoneList [doneListCount] = doneListUpdateTemp [counter1], doneListCount++;
        
        if (doneListCount+10 > doneListLimit){
            fileUpdate = [[FileUpdate alloc] init];
            [fileUpdate doneListUpDate];
        }
        
        arrayDoneList [doneListCount] = treatmentNameAuto, doneListCount++;
        arrayDoneList [doneListCount] = lineageNoAuto, doneListCount++;
        arrayDoneList [doneListCount] = cellNoAuto, doneListCount++;
        arrayDoneList [doneListCount] = imageNoAuto+":"+queueTime, doneListCount++;
        
        if (fusionMarkFind == 0) arrayDoneList [doneListCount] = checkStatusAuto, doneListCount++;
        else arrayDoneList [doneListCount] = checkStatusAuto+"/m", doneListCount++;
        
        string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
        
        if (doneListCount != 0){
            mainDataEntry = new char [doneListCount*10+10];
            totalEntryCount = 0;
            
            for (int counter3 = 0; counter3 < doneListCount; counter3++){
                extension = arrayDoneList [counter3];
                
                for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                    mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            }
            
            mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
            
            ofstream outfile3 (doneListPath.c_str(), ofstream::binary);
            outfile3.write (mainDataEntry, totalEntryCount);
            outfile3.close();
            
            delete [] mainDataEntry;
        }
        
        delete [] doneListUpdateTemp;
        
        string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
        string entry;
        string removeFilePath;
        
        fileDeleteCount = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(connectClearPath.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (fileDeleteCount+5 > fileDeleteLimit){
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate fileDeleteUpDate];
                }
                
                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
            }
            
            closedir(dir);
            
            for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                entry = arrayFileDelete [counter4];
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                    int findFile2 = (int)entry.find("CutTemp");
                    int findFile3 = (int)entry.find("GCCurrentTemp");
                    int findFile4 = (int)entry.find("MasterDataTemp");
                    int findFile5 = (int)entry.find("RevisedTempMap");
                    int findFile6 = (int)entry.find("StatusTemp");
                    int findFile7 = (int)entry.find("LinkDataTemp");
                    int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                    int findFile9 = (int)entry.find("ExtendLineDataTemp");
                    int findFile10 = (int)entry.find("EventTemp");
                    int findFile11 = (int)entry.find("MitosisDataTemp");
                    int findFile12 = (int)entry.find("GCCenterInfo");
                    
                    if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                        removeFilePath = connectClearPath+"/"+entry;
                        remove (removeFilePath.c_str());
                    }
                }
            }
        }
    }
    else if (checkStatusAuto == "RD"){
        int timeOneAutoInt = 0;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayTreatmentStatus [counter1*9] == treatmentNameAuto){
                timeOneAutoInt = atoi(arrayTreatmentStatus [counter1*9+4].c_str());
                break;
            }
        }
        
        string cellLineageExtract = lineageNoAuto.substr(1);
        string cellNumberExtract = cellNoAuto.substr(1);
        int cellLineageTempInt = atoi(cellLineageExtract.c_str());
        
        string extension = to_string(timeOneAutoInt);
        
        if (extension.length() == 1) extension = "000"+extension;
        else if (extension.length() == 2) extension = "00"+extension;
        else if (extension.length() == 3) extension = "0"+extension;
        
        string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_ConnectLineageRel";
        
        ifstream fin;
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        int *arrayConnectLineageRelTempTemp = new int [sizeForCopy+50];
        int connectLineageRelTempCount = 0;
        
        if (sizeForCopy != 0){
            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            fin.close();
            
            unsigned long readPosition = 0;
            int stepCount = 0;
            int finData [19];
            
            do{
                
                if (stepCount == 0){
                    finData [0] = uploadTemp [readPosition], readPosition++;
                    finData [1] = uploadTemp [readPosition], readPosition++;
                    finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                    finData [3] = uploadTemp [readPosition], readPosition++;
                    finData [4] = uploadTemp [readPosition], readPosition++;
                    finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                    finData [6] = uploadTemp [readPosition], readPosition++;
                    finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                    finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                    finData [9] = uploadTemp [readPosition], readPosition++;
                    finData [10] = uploadTemp [readPosition], readPosition++;
                    finData [11] = uploadTemp [readPosition], readPosition++;
                    finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                    finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                    finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                    
                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                    finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                    finData [7] = finData [6]*256+finData [7];
                    
                    if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                    else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                    
                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                    else{
                        
                        arrayConnectLineageRelTempTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                        arrayConnectLineageRelTempTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                        arrayConnectLineageRelTempTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                        arrayConnectLineageRelTempTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                        arrayConnectLineageRelTempTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                        arrayConnectLineageRelTempTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                    }
                }
                
            } while (stepCount != 3);
            
            delete [] uploadTemp;
        }
        
        //for (int counterA = 0; counterA < connectLineageRelTempCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelTempTemp [counterA*6+counterB];
        //	cout<<" arrayConnectLineageRelTempTemp "<<counterA<<endl;
        //}
        
        int connectNoMain = 0;
        int connectNoAdd = atoi(additionalInfoAuto.c_str());
        int lineageDelTemp = 0;
        
        for (int counter1 = 0; counter1 < connectLineageRelTempCount/6; counter1++){
            if (arrayConnectLineageRelTempTemp [counter1*6] == cellLineageTempInt && arrayConnectLineageRelTempTemp [counter1*6+3] == 0){
                connectNoMain = arrayConnectLineageRelTempTemp [counter1*6+1];
            }
            
            if (arrayConnectLineageRelTempTemp [counter1*6+1] == connectNoAdd){
                lineageDelTemp = arrayConnectLineageRelTempTemp [counter1*6+1];
            }
        }
        
        delete [] arrayConnectLineageRelTempTemp;
        
        string connectStatusPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameAuto+"_MasterDataRevise";
        
        sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter3 = 0; counter3 < 6; counter3++){
            sizeForCopy = 0;
            
            if (stat(connectStatusPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter3 == 0) size1 = sizeForCopy;
                else if (counter3 == 1) size2 = sizeForCopy;
                else if (counter3 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter3 == 3) size1 = sizeForCopy;
                else if (counter3 == 4) size2 = sizeForCopy;
                else if (counter3 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
        int *arrayGravityCenterRevTemp = new int [sizeForCopy2+50];
        int gravityCenterRevTempCount = 0;
        int gravityCenterRevTempLimit = (int)sizeForCopy2+50;
        
        if (checkFlag == 1){
            readingError = 0;
            int finData [17];
            
            fin.open(connectStatusPath.c_str(), ios::in | ios::binary);
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        readingError = 1;
                    }
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++;
                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                    }
                    else if (stepCount == 1){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                        finData [9] = finData [8]*256+finData [9];
                        
                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                    }
                    else if (stepCount == 2){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                        finData [8] = uploadTemp [readPosition], readPosition++;
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                        
                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                        else{
                            
                            if (gravityCenterRevTempCount+10 > gravityCenterRevTempLimit){
                                int *arrayUpDate = new int [gravityCenterRevTempCount+10];
                                
                                for (int counter1 = 0; counter1 < gravityCenterRevTempCount; counter1++) arrayUpDate [counter1] = arrayGravityCenterRevTemp [counter1];
                                
                                delete [] arrayGravityCenterRevTemp;
                                arrayGravityCenterRevTemp = new int [gravityCenterRevTempLimit+5000];
                                gravityCenterRevTempLimit = gravityCenterRevTempLimit+5000;
                                
                                for (int counter1 = 0; counter1 < gravityCenterRevTempCount; counter1++) arrayGravityCenterRevTemp [counter1] = arrayUpDate [counter1];
                                delete [] arrayUpDate;
                            }
                            
                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                        }
                    }
                    
                } while (stepCount != 3);
            }
            
            delete [] uploadTemp;
        }
        
        //for (int counterA = 0; counterA < gravityCenterRevTempCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< arrayGravityCenterRevTemp [counterA*6+counterB];
        //	cout<<" arrayGravityCenterRevTemp "<<counterA<<endl;
        //}
        
        if (checkFlag == 1 && readingError == 0){
            int connectNoMainArea = 0;
            int connectNoAddArea = 0;
            
            for (int counter1 = 0; counter1 < gravityCenterRevTempCount/6; counter1++){
                if (arrayGravityCenterRevTemp [counter1*6+4] == connectNoMain){
                    connectNoMainArea = arrayGravityCenterRevTemp [counter1*6+2];
                }
                
                if (arrayGravityCenterRevTemp [counter1*6+4] == connectNoAdd){
                    connectNoAddArea = arrayGravityCenterRevTemp [counter1*6+2];
                }
            }
            
            delete [] arrayGravityCenterRevTemp;
            
            int keepLineage = 0;
            int delLineage = 0;
            
            if (connectNoMainArea >= connectNoAddArea){
                keepLineage = cellLineageTempInt;
                delLineage = lineageDelTemp;
            }
            else{
                
                keepLineage = lineageDelTemp;
                delLineage = cellLineageTempInt;
            }
            
            int processType = 1;
            int dymmy = 0;
            
            addDeleteAuto = [[AddDeleteAuto alloc] init];
            int addDeleteStatus = [addDeleteAuto delLineageMain:delLineage:processType:dymmy:dymmy];
            
            if (addDeleteStatus == -1){
                usleep (50000);
                
                addDeleteAuto = [[AddDeleteAuto alloc] init];
                addDeleteStatus = [addDeleteAuto delLineageMain:delLineage:processType:dymmy:dymmy];
                
                if (addDeleteStatus == -1){
                    usleep (50000);
                    
                    
                    addDeleteAuto = [[AddDeleteAuto alloc] init];
                    [addDeleteAuto delLineageMain:delLineage:processType:dymmy:dymmy];
                }
            }
            
            string connectClearPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameAuto+"_Treat/"+lineageNoAuto+"/"+cellNoAuto;
            string entry;
            string removeFilePath;
            
            fileDeleteCount = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(connectClearPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (fileDeleteCount+5 > fileDeleteLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate fileDeleteUpDate];
                    }
                    
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
                
                closedir(dir);
                
                for (int counter4 = 0; counter4 < fileDeleteCount; counter4++){
                    entry = arrayFileDelete [counter4];
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        int findFile1 = (int)entry.find("ConnectLineageRelTemp");
                        int findFile2 = (int)entry.find("CutTemp");
                        int findFile3 = (int)entry.find("GCCurrentTemp");
                        int findFile4 = (int)entry.find("MasterDataTemp");
                        int findFile5 = (int)entry.find("RevisedTempMap");
                        int findFile6 = (int)entry.find("StatusTemp");
                        int findFile7 = (int)entry.find("LinkDataTemp");
                        int findFile8 = (int)entry.find("ExtendAreaDataTemp");
                        int findFile9 = (int)entry.find("ExtendLineDataTemp");
                        int findFile10 = (int)entry.find("EventTemp");
                        int findFile11 = (int)entry.find("MitosisDataTemp");
                        int findFile12 = (int)entry.find("GCCenterInfo");
                        
                        if (findFile1 != -1 || findFile2 != -1 || findFile3 != -1 || findFile4 != -1 || findFile5 != -1 || findFile6 != -1 || findFile7 != -1 || findFile8 != -1 || findFile9 != -1 || findFile10 != -1 || findFile11 != -1 || findFile12 != -1){
                            removeFilePath = connectClearPath+"/"+entry;
                            remove (removeFilePath.c_str());
                        }
                    }
                }
            }
            
            string *queueStringTemp = new string [queueListCount+50];
            int queueStringTempCount = 0;
            
            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
            //    cout<<" arrayQueueList "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6+5] != "Proc"){
                    arrayQueueList [counter1*6+5] = "Wait";
                    break;
                }
            }
            
            string cellLineageString = to_string(keepLineage);
            
            if (cellLineageString.length() == 1) cellLineageString = "L0000"+cellLineageString;
            else if (cellLineageString.length() == 2) cellLineageString = "L000"+cellLineageString;
            else if (cellLineageString.length() == 3) cellLineageString = "L00"+cellLineageString;
            else if (cellLineageString.length() == 4) cellLineageString = "L0"+cellLineageString;
            else if (cellLineageString.length() == 5) cellLineageString = "L"+cellLineageString;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] == treatmentNameAuto && arrayQueueList [counter1*6+1] == cellLineageString && arrayQueueList [counter1*6+2] == "C000000000"){
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (arrayQueueList [counter1*6] != treatmentNameAuto || arrayQueueList [counter1*6+1] != cellLineageString || arrayQueueList [counter1*6+2] != "C000000000"){
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+1], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+2], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+3], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+4], queueStringTempCount++;
                    queueStringTemp [queueStringTempCount] = arrayQueueList [counter1*6+5], queueStringTempCount++;
                }
            }
            
            if (queueStringTempCount > queueListLimit){
                delete [] arrayQueueList;
                arrayQueueList = new string [queueStringTempCount+5000];
                queueListLimit = queueStringTempCount+5000;
            }
            
            queueListCount = 0;
            
            for (int counter1 = 0; counter1 < queueStringTempCount; counter1++) arrayQueueList [queueListCount] = queueStringTemp [counter1], queueListCount++;
            
            //for (int counterA = 0; counterA < queueListCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayQueueList [counterA*6+counterB];
            //    cout<<" arrayQueueList "<<counterA<<endl;
            //}
            
            string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
            
            if (queueListCount != 0){
                char *mainDataEntry = new char [queueListCount*12+10];
                int totalEntryCount = 0;
                
                for (int counter3 = 0; counter3 < queueListCount; counter3++){
                    extension = arrayQueueList [counter3];
                    
                    for (int counter4 = 0; counter4 < (int)extension.length(); counter4++){
                        mainDataEntry [totalEntryCount] = (char)extension.at((unsigned long)counter4), totalEntryCount++;
                    }
                    
                    mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                }
                
                mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                
                ofstream outfile (queueListPath.c_str(), ofstream::binary);
                outfile.write (mainDataEntry, totalEntryCount);
                outfile.close();
                
                delete [] mainDataEntry;
            }
            
            delete [] queueStringTemp;
        }
    }
    
    return doneComplete;
}

-(void)timeEndRevise{
    //*********arrayTreatmentStatus*********
    //1. TreatName
    //2. Lineage Data check (0: not fined, 1: find)
    //3. Status Data check (0: not fined, 1: find)
    //4. Other Map Data check (0: not fined, 1: find)
    //5. Time One
    //6. Time End
    //7. Time Max
    //8. IF Start
    //9. Image End
    
    //*********arrayIFStatus*********
    //1. IF No
    //2. IF fluorescent name1
    //3. IF fluorescent name2
    //4. IF fluorescent name3
    //5. IF fluorescent No1
    //6. IF fluorescent No2
    //7. IF fluorescent No3
    //8. IF fluorescent Count
    //9. Image no
    
    //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
    //	for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
    //	cout<<" arrayTreatmentStatus "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < 90/9; counterA++){
    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
    //    cout<<" arrayIFDataHold "<<counterA<<endl;
    //}
    
    ifstream fin;
    
    string nameString;
    string lineageDataFind;
    string statusDataFind;
    string otherDataFind;
    string timeOneString;
    string timeEndFind;
    string timeMaxFind;
    string ifStartFind;
    string imageEndFind;
    string lineageFilePath;
    string entry;
    string extractString;
    string extractString2;
    string extractString3;
    string extractString4;
    string extension;
    string savedDataPath;
    string trackAnalysisSaveFilePath;
    
    int imageEndInt = 0;
    int latestTimeEnd = 0;
    int latestTimeMax = 0;
    int latestImageEnd = 0;
    int latestIFStart = 0;
    int lastImagePosition = 0;
    int saveFlag = 0;
    int extractInt = 0;
    
    for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
        nameString = arrayTreatmentStatus [counter1*9];
        lineageDataFind = arrayTreatmentStatus [counter1*9+1];
        statusDataFind = arrayTreatmentStatus [counter1*9+2];
        otherDataFind = arrayTreatmentStatus [counter1*9+3];
        timeOneString = arrayTreatmentStatus [counter1*9+4];
        timeEndFind = arrayTreatmentStatus [counter1*9+5];
        timeMaxFind = arrayTreatmentStatus [counter1*9+6];
        ifStartFind = arrayTreatmentStatus [counter1*9+7];
        imageEndFind = arrayTreatmentStatus [counter1*9+8];
        
        imageEndInt = atoi(imageEndFind.c_str());
        latestTimeEnd = 0;
        latestTimeMax = 0;
        latestImageEnd = 0;
        latestIFStart = 0;
        
        if (lineageDataFind == "1" && statusDataFind == "1" && otherDataFind == "1" && timeOneString != "nil"){
            lastImagePosition = 0;
            saveFlag = 0;
            
            lineageFilePath = imageFolderPath+"/"+analysisImageName+"_Image/"+nameString+"_Stitch";
            
            fileDeleteCount = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            dir = opendir(lineageFilePath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (fileDeleteCount+5 > fileDeleteLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate fileDeleteUpDate];
                    }
                    
                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                }
                
                closedir(dir);
                
                //-----Directory Sort-----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                    [unsortedArray addObject:@(arrayFileDelete [counter2].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter2 = 0; counter2 < [unsortedArray count]; counter2++){
                    arrayFileDelete [counter2] = [unsortedArray [counter2] UTF8String];
                }
            }
            
            for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                entry = arrayFileDelete [counter2];
                
                if ((int)entry.find("STimage") != -1){
                    extractString = entry.substr(8, 4);
                    extractInt = atoi(extractString.c_str());
                    
                    if (extractInt >= imageEndInt){
                        if (((int)entry.find("bmp") != -1 || (int)entry.find("tif") != -1) && extractInt > imageEndInt){
                            if (timeEndFind == timeMaxFind){
                                latestTimeEnd = extractInt;
                                latestTimeMax = extractInt;
                                latestImageEnd = extractInt;
                            }
                            else if (timeEndFind != timeMaxFind){
                                latestTimeMax = extractInt;
                                latestImageEnd = extractInt;
                            }
                        }
                        
                        if (((int)entry.find("BMP") != -1 || (int)entry.find("TIF") != -1) && lastImagePosition == 0){ //========CK
                            lastImagePosition = extractInt;
                            
                            if ((int)entry.find("BMP") != -1){
                                extractString2 = entry.substr(13, 1);
                                extractString3 = entry.substr(15, entry.find(".BMP")-15);
                                extractString4 = entry.substr(entry.find(".BMP")+4);
                            }
                            else if ((int)entry.find("TIF") != -1){
                                extractString2 = entry.substr(13, 1);
                                extractString3 = entry.substr(15, entry.find(".TIF")-15);
                                extractString4 = entry.substr(entry.find(".TIF")+4);
                            }
                            
                            for (int counter3 = 0; counter3 < 450; counter3 = counter3+15){
                                if (arrayIFDataHold [counter3] != "nil"){
                                    if (arrayIFDataHold [counter3] == extractString4){
                                        if (arrayIFDataHold [counter3+1] == extractString3 || (arrayIFDataHold [counter3+2] != "nil" && arrayIFDataHold [counter3+2] == extractString3) || (arrayIFDataHold [counter3+3] != "nil" && arrayIFDataHold [counter3+3] == extractString3) || (arrayIFDataHold [counter3+4] != "nil" && arrayIFDataHold [counter3+4] == extractString3) || (arrayIFDataHold [counter3+5] != "nil" && arrayIFDataHold [counter3+5] == extractString3) || arrayIFDataHold [counter3+6] != "nil" || atoi(extractString2.c_str()) == 0){
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+2] == "nil"){
                                            arrayIFDataHold [counter3+2] = extractString3;
                                            arrayIFDataHold [counter3+8] = extractString2;
                                            arrayIFDataHold [counter3+13] = "2";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+3] == "nil"){
                                            arrayIFDataHold [counter3+3] = extractString3;
                                            arrayIFDataHold [counter3+9] = extractString2;
                                            arrayIFDataHold [counter3+13] = "3";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+4] == "nil"){
                                            arrayIFDataHold [counter3+4] = extractString3;
                                            arrayIFDataHold [counter3+10] = extractString2;
                                            arrayIFDataHold [counter3+13] = "4";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+5] == "nil"){
                                            arrayIFDataHold [counter3+5] = extractString3;
                                            arrayIFDataHold [counter3+11] = extractString2;
                                            arrayIFDataHold [counter3+13] = "5";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+6] == "nil"){
                                            arrayIFDataHold [counter3+6] = extractString3;
                                            arrayIFDataHold [counter3+12] = extractString2;
                                            arrayIFDataHold [counter3+13] = "6";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                else{
                                    
                                    arrayIFDataHold [counter3] = extractString4;
                                    arrayIFDataHold [counter3+1] = extractString3;
                                    arrayIFDataHold [counter3+7] = extractString2;
                                    arrayIFDataHold [counter3+13] = "1";
                                    arrayIFDataHold [counter3+14] = extractString;
                                    saveFlag = 1;
                                    break;
                                }
                            }
                            
                            latestImageEnd = extractInt;
                            
                            if (ifStartFind == "nil") latestIFStart = extractInt;
                        }
                        else if (((int)entry.find("BMP") != -1 || (int)entry.find("TIF") != -1) && lastImagePosition == extractInt){
                            if ((int)entry.find("BMP") != -1){
                                extractString2 = entry.substr(13, 1);
                                extractString3 = entry.substr(15, entry.find(".BMP")-15);
                                extractString4 = entry.substr(entry.find(".BMP")+4);
                            }
                            else if ((int)entry.find("TIF") != -1){
                                extractString2 = entry.substr(13, 1);
                                extractString3 = entry.substr(15, entry.find(".TIF")-15);
                                extractString4 = entry.substr(entry.find(".TIF")+4);
                            }
                            
                            for (int counter3 = 0; counter3 < 450; counter3 = counter3+15){
                                if (arrayIFDataHold [counter3] != "nil"){
                                    if (arrayIFDataHold [counter3] == extractString4){
                                        if (arrayIFDataHold [counter3+1] == extractString3 || (arrayIFDataHold [counter3+2] != "nil" && arrayIFDataHold [counter3+2] == extractString3) || (arrayIFDataHold [counter3+3] != "nil" && arrayIFDataHold [counter3+3] == extractString3) || (arrayIFDataHold [counter3+4] != "nil" && arrayIFDataHold [counter3+4] == extractString3) || (arrayIFDataHold [counter3+5] != "nil" && arrayIFDataHold [counter3+5] == extractString3) || arrayIFDataHold [counter3+6] != "nil" || atoi(extractString2.c_str()) == 0){
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+2] == "nil"){
                                            arrayIFDataHold [counter3+2] = extractString3;
                                            arrayIFDataHold [counter3+8] = extractString2;
                                            arrayIFDataHold [counter3+13] = "2";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+3] == "nil"){
                                            arrayIFDataHold [counter3+3] = extractString3;
                                            arrayIFDataHold [counter3+9] = extractString2;
                                            arrayIFDataHold [counter3+13] = "3";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+4] == "nil"){
                                            arrayIFDataHold [counter3+4] = extractString3;
                                            arrayIFDataHold [counter3+10] = extractString2;
                                            arrayIFDataHold [counter3+13] = "4";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+5] == "nil"){
                                            arrayIFDataHold [counter3+5] = extractString3;
                                            arrayIFDataHold [counter3+11] = extractString2;
                                            arrayIFDataHold [counter3+13] = "5";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+6] == "nil"){
                                            arrayIFDataHold [counter3+6] = extractString3;
                                            arrayIFDataHold [counter3+12] = extractString2;
                                            arrayIFDataHold [counter3+13] = "6";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                else{
                                    
                                    arrayIFDataHold [counter3] = extractString4;
                                    arrayIFDataHold [counter3+1] = extractString3;
                                    arrayIFDataHold [counter3+7] = extractString2;
                                    arrayIFDataHold [counter3+13] = "1";
                                    arrayIFDataHold [counter3+14] = extractString;
                                    saveFlag = 1;
                                    break;
                                }
                            }
                            
                            latestImageEnd = extractInt;
                        }
                        else if (((int)entry.find("BMP") != -1 || (int)entry.find("TIF") != -1) && lastImagePosition != extractInt){
                            if ((int)entry.find("BMP") != -1){
                                lastImagePosition = extractInt;
                                extractString2 = entry.substr(13, 1);
                                extractString3 = entry.substr(15, entry.find(".BMP")-15);
                                extractString4 = entry.substr(entry.find(".BMP")+4);
                            }
                            else if ((int)entry.find("TIF") != -1){
                                lastImagePosition = extractInt;
                                extractString2 = entry.substr(13, 1);
                                extractString3 = entry.substr(15, entry.find(".TIF")-15);
                                extractString4 = entry.substr(entry.find(".TIF")+4);
                            }
                            
                            for (int counter3 = 0; counter3 < 450; counter3 = counter3+15){
                                if (arrayIFDataHold [counter3] != "nil"){
                                    if (arrayIFDataHold [counter3] == extractString4){
                                        if (arrayIFDataHold [counter3+1] == extractString3 || (arrayIFDataHold [counter3+2] != "nil" && arrayIFDataHold [counter3+2] == extractString3) || (arrayIFDataHold [counter3+3] != "nil" && arrayIFDataHold [counter3+3] == extractString3) || (arrayIFDataHold [counter3+4] != "nil" && arrayIFDataHold [counter3+4] == extractString3) || (arrayIFDataHold [counter3+5] != "nil" && arrayIFDataHold [counter3+5] == extractString3) || arrayIFDataHold [counter3+6] != "nil" || atoi(extractString2.c_str()) == 0){
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+2] == "nil"){
                                            arrayIFDataHold [counter3+2] = extractString3;
                                            arrayIFDataHold [counter3+8] = extractString2;
                                            arrayIFDataHold [counter3+13] = "2";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+3] == "nil"){
                                            arrayIFDataHold [counter3+3] = extractString3;
                                            arrayIFDataHold [counter3+9] = extractString2;
                                            arrayIFDataHold [counter3+13] = "3";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+4] == "nil"){
                                            arrayIFDataHold [counter3+4] = extractString3;
                                            arrayIFDataHold [counter3+10] = extractString2;
                                            arrayIFDataHold [counter3+13] = "4";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+5] == "nil"){
                                            arrayIFDataHold [counter3+5] = extractString3;
                                            arrayIFDataHold [counter3+11] = extractString2;
                                            arrayIFDataHold [counter3+13] = "5";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else if (arrayIFDataHold [counter3+6] == "nil"){
                                            arrayIFDataHold [counter3+6] = extractString3;
                                            arrayIFDataHold [counter3+12] = extractString2;
                                            arrayIFDataHold [counter3+13] = "6";
                                            saveFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            break;
                                        }
                                    }
                                }
                                else{
                                    
                                    arrayIFDataHold [counter3] = extractString4;
                                    arrayIFDataHold [counter3+1] = extractString3;
                                    arrayIFDataHold [counter3+7] = extractString2;
                                    arrayIFDataHold [counter3+13] = "1";
                                    arrayIFDataHold [counter3+14] = extractString;
                                    saveFlag = 1;
                                    break;
                                }
                            }
                            
                            latestImageEnd = extractInt;
                        }
                    }
                }
            }
            
            if (latestTimeEnd != 0){
                extension = to_string(latestTimeEnd);
                
                arrayTreatmentStatus [counter1*9+5] = extension;
                saveFlag = 1;
            }
            
            if (latestTimeMax != 0){
                extension = to_string(latestTimeMax);
                
                arrayTreatmentStatus [counter1*9+6] = extension;
                saveFlag = 1;
            }
            
            if (latestImageEnd != 0){
                extension = to_string(latestImageEnd);
                
                arrayTreatmentStatus [counter1*9+8] = extension;
                saveFlag = 1;
            }
            
            if (latestIFStart != 0){
                extension = to_string(latestIFStart);
                
                arrayTreatmentStatus [counter1*9+7] = extension;
                saveFlag = 1;
            }
            
            //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
            //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < 90/9; counterA++){
            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
            //    cout<<" arrayIFDataHold "<<counterA<<endl;
            //}
            
            if (saveFlag == 1){
                if (nameString == treatmentNameHold){
                    if (latestTimeMax != 0) maxTimePoint = latestTimeMax;
                    if (latestTimeEnd != 0) timeEndHold = latestTimeEnd;
                    if (latestIFStart != 0) ifStartHold = latestIFStart;
                    if (latestImageEnd != 0) imageEndHold = latestImageEnd;
                }
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveTrackingCurrent];
                
                setStatus4 = 4;
            }
        }
    }
    
    //for (int counterA = 0; counterA < 90/9; counterA++){
    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
    //    cout<<" arrayIFDataHold "<<counterA<<endl;
    //}
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCommunication object:nil];
}

@end
