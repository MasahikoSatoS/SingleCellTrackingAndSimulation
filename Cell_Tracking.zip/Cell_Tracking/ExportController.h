//
//  ExportController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2018-01-23.
//
//

#ifndef EXPORTCONTROLLER_H
#define EXPORTCONTROLLER_H
#import "Controller.h"
#endif

@interface ExportController : NSObject <NSTextFieldDelegate>{
    IBOutlet NSTextField *outLineWidthDisplay;
    IBOutlet NSTextField *nonTargetWidthDisplay;
    IBOutlet NSTextField *nonTargetLengthDisplay;
    IBOutlet NSTextField *nonTargetFontDisplay;
    IBOutlet NSTextField *exportStartDisplay;
    IBOutlet NSTextField *exportEndDisplay;
    
    IBOutlet NSTextField *targetWidthDisplay;
    IBOutlet NSTextField *targetLengthDisplay;
    IBOutlet NSTextField *targetFontDisplay;
    IBOutlet NSTextField *titleFontDisplay;
    IBOutlet NSTextField *titleNameHoldDisplay;
    IBOutlet NSTextField *titleNameDisplay;
    IBOutlet NSTextField *densityDiameterDisplay;
    IBOutlet NSTextField *densityMaxDisplay;
    IBOutlet NSTextField *titleFontColorDisplay;
    IBOutlet NSTextField *lineageLimitDisplay;
    IBOutlet NSTextField *thresholdCutOffDisplay;
    IBOutlet NSTextField *areaSizeMinDisplay;
    IBOutlet NSTextField *areaSizeMaxDisplay;
    IBOutlet NSTextField *xPositionDisplay;
    IBOutlet NSTextField *yPositionDisplay;
    IBOutlet NSTextField *modeForOutlineDisplay;
    IBOutlet NSTextField *modeForNonTargetDisplay;
    IBOutlet NSTextField *modeForFontDisplay;
    IBOutlet NSTextField *lineTraceStatusDisplay;
    IBOutlet NSTextField *traceLineColorDisplay;
    IBOutlet NSTextField *traceLineWidthDisplay;
    
    IBOutlet NSStepper *stepperTraceLineColor;
    
    IBOutlet NSProgressIndicator *backSave;
    
    IBOutlet NSWindow *exportMainWindow;
    
    NSTimer *exportMainTimer;
    NSTimer *exportMainTimer2;
    
    NSWindowController *exportMainWindowController;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)display;

-(IBAction)closeWindow:(id)sender;
-(IBAction)channelNoSet:(id)sender;
-(IBAction)outlineWidthSet:(id)sender;
-(IBAction)nonTargetWidthSet:(id)sender;
-(IBAction)nonTargetLengthSet:(id)sender;
-(IBAction)nonTargetFontSet:(id)sender;
-(IBAction)targetWidthSet:(id)sender;
-(IBAction)targetLengthSet:(id)sender;
-(IBAction)targetFontSet:(id)sender;
-(IBAction)refreshSet:(id)sender;
-(IBAction)exportNoOFCellsInArea:(id)sender;
-(IBAction)linePrintColorSet:(id)sender;
-(IBAction)exportDensityData:(id)sender;
-(IBAction)displayModeForOutline:(id)sender;
-(IBAction)displayModeForNonTarget:(id)sender;
-(IBAction)DisplayModeForTargetFontSize:(id)sender;
-(IBAction)lineTraceFunctionOnOff:(id)sender;
-(IBAction)stepperTraceLineColorSet:(id)sender;
-(IBAction)traceLineWidthSet:(id)sender;
-(IBAction)exportLineTraceData:(id)sender;

@end
