//
// TrackingSet.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 13/09/27.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "TrackingSet.h"

@implementation TrackingSet

-(int)trackingSetMain:(int)processType{
    int upLoadCheck = 0;
    
    ifstream fin;
    
    string extension;
    
    if (processType == 2 || processType == 3 || processType == 6 || processType == 7) extension = to_string(imageNumberTrackForDisplay);
    else if (processType == 4) extension = to_string(imageNumberTrackForDisplay-1);
    else if (processType == 5) extension = to_string(imageNumberDisplayForDisplay);
    
    if (extension.length() == 1) extension = "000"+extension;
    else if (extension.length() == 2) extension = "00"+extension;
    else if (extension.length() == 3) extension = "0"+extension;
    
    if (processType == 2){
        gravityCenterXHold1 = 0;
        gravityCenterYHold1 = 0;
        gravityAverageHold1 = 0;
        gravityCellNo1 = 0;
        gravityCenterXHold2 = 0;
        gravityCenterYHold2 = 0;
        gravityAverageHold2 = 0;
        gravityCellNo2 = 0;
        gravityCenterXHold3 = 0;
        gravityCenterYHold3 = 0;
        gravityAverageHold3 = 0;
        gravityCellNo3 = 0;
        gravityCenterXHold4 = 0;
        gravityCenterYHold4 = 0;
        gravityAverageHold4 = 0;
        gravityCellNo4 = 0;
        
        string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
        string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_MasterDataTemp";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(connectDataTempPath.c_str(), &sizeOfFile) == 0) cutBase = 1; //-----Presence of temp file check, use for Cut operation-----
        else cutBase = 0;
        
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            sizeForCopy = 0;
            
            if (stat(connectDataTempPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter1 == 0) size1 = sizeForCopy;
                else if (counter1 == 1) size2 = sizeForCopy;
                else if (counter1 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter1 == 3) size1 = sizeForCopy;
                else if (counter1 == 4) size2 = sizeForCopy;
                else if (counter1 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (checkFlag == 1){
            if (positionReviseStatus == 1) delete [] arrayPositionRevise;
            arrayPositionRevise = new int [sizeForCopy+50];
            positionReviseCount = 0;
            positionReviseLimit = (int)sizeForCopy+50;
            positionReviseStatus = 1;
            
            long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
            if (gravityCenterRevStatus == 1) delete [] arrayGravityCenterRev;
            arrayGravityCenterRev = new int [sizeForCopy2+50];
            gravityCenterRevCount = 0;
            gravityCenterRevLimit = (int)sizeForCopy2+50;
            gravityCenterRevStatus = 1;
            
            sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
            if (associateDataStatus == 1) delete [] arrayAssociateData;
            arrayAssociateData = new int [sizeForCopy2+50];
            associateDataCount = 0;
            associateDataLimit = (int)sizeForCopy2+50;
            associateDataStatus = 1;
            
            fin.open(connectDataTempPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [17];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            else{
                                
                                if (associateDataCount+12 > associateDataLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate associateDataUpDate];
                                }
                                
                                arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                            }
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate gravityCenterRevUpDate];
                                }
                                
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                else{
                                    
                                    if (associateDataCount+12 > associateDataLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate associateDataUpDate];
                                    }
                                    
                                    arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                                }
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate gravityCenterRevUpDate];
                                    }
                                    
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [11];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //-----X Position-----
                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //-----Y Position-----
                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //-----Value-----
                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //-----Connect No-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Cell No-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Status-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Lineage no-----
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData [9] = finData [8]*256+finData [9];
                                    
                                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    else{
                                        
                                        if (associateDataCount+12 > associateDataLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate associateDataUpDate];
                                        }
                                        
                                        arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                                    }
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate gravityCenterRevUpDate];
                                        }
                                        
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
        }
        
        if (checkFlag == 0 || readingError == 1) upLoadCheck = 1;
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //	cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        //    cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < associateDataCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociateData [counterA*6+counterB];
        //	cout<<" arrayAssociateData "<<counterA<<endl;
        //}
        
        //-----Master Data Status UpLoad-----
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        string connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_StatusTemp";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy < gravityCenterRevCount*2) sizeForCopy = gravityCenterRevCount*2;
        
        if (timeSelectedStatus == 1) delete [] arrayTimeSelected;
        
        arrayTimeSelected = new int [sizeForCopy+50];
        timeSelectedCount = 0;
        timeSelectedLimit = (int)sizeForCopy+50;
        timeSelectedStatus = 1;
        
        if (timeSelectedHoldStatus == 1) delete [] arrayTimeSelectedHold;
        
        arrayTimeSelectedHold = new int [sizeForCopy+50];
        timeSelectedHoldCount = 0;
        timeSelectedHoldStatus = 1;
        
        fin.open(connectStatusTempPath.c_str(), ios::in | ios::binary);
        
        readingError = 0;
        
        if (fin.is_open()){
            int finData [19];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                            arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                            arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                            arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                            arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                            arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                            arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            else upLoadCheck = 1;
            
            delete [] uploadTemp;
        }
        else{
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [19];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                        readingError = 1;
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                                arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                                arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                                arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                                arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                                arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                                arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                                arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                                arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                                arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                                
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [0], timeSelectedHoldCount++; //-----Selected, removed, eliminated status-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [3], timeSelectedHoldCount++; //-----When new line is created, enter line number which creates-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [6], timeSelectedHoldCount++; //-----PositionRevise Start-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [8], timeSelectedHoldCount++; //-----Cut line number-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [9], timeSelectedHoldCount++; //-----X Start-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [10], timeSelectedHoldCount++; //-----X End-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [11], timeSelectedHoldCount++; //-----Y Start-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [12], timeSelectedHoldCount++; //-----Y End-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [15], timeSelectedHoldCount++; //-----Connect-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [18], timeSelectedHoldCount++; //-----Lineage-----
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                else upLoadCheck = 1;
                
                delete [] uploadTemp;
            }
            else{
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Selected, removed, eliminated status-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Top position of each connect-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Cut line number-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X End-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y End-----
                    arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //-----Connect-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Lineage-----
                    
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Selected, removed, eliminated status-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Line process, group-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----reserve-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Cut line number-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = counter1+1, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                }
                
                int valueTemp = 0;
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] != valueTemp){
                        valueTemp = arrayPositionRevise [counter1*7+3];
                        arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                        arrayTimeSelectedHold [(valueTemp-1)*10+2] = counter1;
                        
                        if (arrayPositionRevise [counter1*7+5] == 0){
                            arrayTimeSelected [(valueTemp-1)*10] = 0;
                            arrayTimeSelectedHold [(valueTemp-1)*10] = 0;
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        if (targetHoldStatus == 1){
            delete [] arrayTargetHold;
            delete [] arrayTargetHoldInfo;
        }
        
        arrayTargetHold = new int [5000];
        targetHoldCount = 0;
        targetHoldLimit = 5000;
        targetHoldStatus = 1;
        arrayTargetHoldInfo = new int [500];
        targetHoldInfoCount = 0;
        targetHoldInfoLimit = 500;
        
        string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
        string connectRelationTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
        
        sizeForCopy = 0;
        
        if (stat(connectRelationTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (connectLineageRelStatus == 1){
            delete [] arrayConnectLineageRel;
            connectLineageRelStatus = 0;
        }
        
        if (sizeForCopy == 0){
            arrayConnectLineageRel = new int [timeSelectedCount+500];
            connectLineageRelCount = 0;
            connectLineageRelLimit = timeSelectedCount+500;
            connectLineageRelStatus = 1;
        }
        else{
            
            arrayConnectLineageRel = new int [sizeForCopy+50];
            connectLineageRelCount = 0;
            connectLineageRelLimit = (int)sizeForCopy+50;
            connectLineageRelStatus = 1;
            
            readingError = 0;
            
            fin.open(connectRelationTempPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [19];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                        readingError = 1;
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRel [connectLineageRelCount] = finData [2], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [5], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [7], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [12], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [13], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [14], connectLineageRelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                else upLoadCheck = 1;
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [19];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                            readingError = 1;
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                finData [3] = uploadTemp [readPosition], readPosition++;
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [2], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [5], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [7], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [12], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [13], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [14], connectLineageRelCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    else upLoadCheck = 1;
                    
                    delete [] uploadTemp;
                }
                else connectLineageRelCount = 0;
            }
        }
        
        //-----Event sequence set-----
        string cellLineageExtract = "";
        if (cellLineageNoHold != "") cellLineageExtract = cellLineageNoHold.substr(1);
        
        string cellNoExtract = "";
        if (cellNoHold != "") cellNoExtract = cellNoHold.substr(1);
        
        int lineageAmendTemp = atoi(cellLineageExtract.c_str());
        int cellAmendTemp = atoi(cellNoExtract.c_str());
        
        int findFlag = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                findFlag = 1;
                break;
            }
        }
        
        if (findFlag == 0){
            if (eventSequenceCount+4 > eventSequenceLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate eventSequenceUpDate];
            }
            
            arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++; //-----Image no-----
            arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //-----Event type-----
            arrayEventSequence [eventSequenceCount] = lineageAmendTemp, eventSequenceCount++; //-----Lineage no-----
            arrayEventSequence [eventSequenceCount] = cellAmendTemp, eventSequenceCount++; //-----Cell no-----
        }
        
        eventSequenceHoldCount = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
            }
        }
        
        lineageGravityCenterCurrentHoldCount = 0;
        
        for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
            if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay){
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4], lineageGravityCenterCurrentHoldCount++;
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+1], lineageGravityCenterCurrentHoldCount++;
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+2], lineageGravityCenterCurrentHoldCount++;
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+3], lineageGravityCenterCurrentHoldCount++;
            }
        }
        
        //for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
        //	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
        //	cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
        //	cout<<" arrayConnectLineageRel "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
        //    cout<<" arrayEventSequence "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
        //    cout<<" arrayEventSequenceHold "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
        //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
        //}
        
        string divCellNoPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_LinkDataTemp";
        
        if (stat(divCellNoPath.c_str(), &sizeOfFile) == 0){
            string getString;
            
            cellNoHoldDiv1 = "";
            cellNoHoldDiv2 = "";
            cellNoHoldDiv3 = "";
            cellNoHoldDiv4 = "";
            
            fin.open(divCellNoPath.c_str(), ios::in);
            
            if (fin.is_open()){
                getline(fin, getString);
                
                if (getString != "FU"){
                    getline(fin, getString), cellNoHoldDiv1 = getString;
                    getline(fin, getString), cellNoHoldDiv2 = getString;
                    getline(fin, getString);
                    
                    if (getString != "nil") cellNoHoldDiv3 = getString;
                    
                    getline(fin, getString);
                    
                    if (getString != "nil") cellNoHoldDiv4 = getString;
                }
                else if (getString == "FU"){
                    getline(fin, getString), fusionPartnerLin = atoi(getString.c_str());
                    getline(fin, getString), fusionPartnerCellNo = atoi(getString.c_str());
                    getline(fin, getString), fusionMarkImage = atoi(getString.c_str());
                    getline(fin, getString);
                }
                
                fin.close();
            }
        }
        
        string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exType;
        string mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
        string revisedTempMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_RevisedTempMap";
        
        for (int counter1 = 0; counter1 < imageSizeListCount/2; counter1++){
            if (arrayImageSizeList [counter1*2] == treatmentNameHold){
                imageDimension = atoi(arrayImageSizeList [counter1*2+1].c_str());
                break;
            }
        }
        
        if (sourceImageStatus == 0){
            sourceImage = new int *[imageDimension+1];
            sourceImageStatus = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) sourceImage [counter1] = new int [imageDimension+1];
        }
        
        if (revisedMapStatus == 0){
            revisedMap = new int *[imageDimension+1];
            revisedMapStatus = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedMap [counter1] = new int [imageDimension+1];
        }
        
        if (revisedWorkingMapStatus == 0){
            revisedWorkingMap = new int *[imageDimension+1];
            revisedWorkingMapStatus = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedWorkingMap [counter1] = new int [imageDimension+1];
        }
        
        if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            if (exType == ".tif" || exTypeIF == ".TIF"){
                int dataConversion [4];
                int endianType = 0;
                int imageWidthEntry = 0;
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int imageDimensionReadCount = 0;
                
                unsigned long headPosition = 0;
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    imageDimensionReadCount = 0;
                    imageWidthEntry = 0;
                    
                    if (tifImageColorGray == 0){
                        for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                            sourceImage [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                            
                            if (imageWidthEntry == imageDimension){
                                imageWidthEntry = 0;
                                imageDimensionReadCount++;
                            }
                        }
                    }
                    else if (tifImageColorGray == 1){
                        for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                            value0 = uploadTemp [counter3];
                            value1 = uploadTemp [counter3+1];
                            value2 = uploadTemp [counter3+2];
                            
                            sourceImage [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                            
                            if (imageWidthEntry == imageDimension){
                                imageWidthEntry = 0;
                                imageDimensionReadCount++;
                            }
                        }
                    }
                }
                
                delete [] uploadTemp;
            }
            else if (exType == ".bmp" || exTypeIF == ".BMP"){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    int imageDimensionReadCount = 0;
                    
                    for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageDimension; counter2++){
                            sourceImage [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                        }
                        
                        imageDimensionReadCount++;
                    }
                }
                
                delete [] uploadTemp;
            }
        }
        
        int yDimensionCount;
        int xDimensionCount;
        int readBit [4];
        int pixData;
        int totalSize = imageDimension*imageDimension*4;
        
        fin.open(revisedTempMapPath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            uint8_t *upload2 = new uint8_t [totalSize+50];
            fin.read((char*)upload2, totalSize+1);
            fin.close();
            
            yDimensionCount = 0;
            xDimensionCount = 0;
            
            for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                readBit [0] = upload2[counter1];
                readBit [1] = upload2[counter1+1];
                readBit [2] = upload2[counter1+2];
                readBit [3] = upload2[counter1+3];
                
                pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                
                for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                    revisedMap [yDimensionCount][xDimensionCount] = pixData;
                    revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                }
                
                if (xDimensionCount == imageDimension){
                    xDimensionCount = 0;
                    yDimensionCount++;
                    
                    if (yDimensionCount == imageDimension){
                        break;
                    }
                }
            }
            
            delete [] upload2;
        }
        else{
            
            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *upload2 = new uint8_t [totalSize+50];
                
                fin.read((char*)upload2, totalSize+1);
                fin.close();
                
                yDimensionCount = 0;
                xDimensionCount = 0;
                
                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                    readBit [0] = upload2[counter1];
                    readBit [1] = upload2[counter1+1];
                    readBit [2] = upload2[counter1+2];
                    readBit [3] = upload2[counter1+3];
                    
                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                    
                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                        revisedMap [yDimensionCount][xDimensionCount] = pixData;
                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                    }
                    
                    if (xDimensionCount == imageDimension){
                        xDimensionCount = 0;
                        yDimensionCount++;
                        
                        if (yDimensionCount == imageDimension){
                            break;
                        }
                    }
                }
                
                delete [] upload2;
            }
            else{
                
                fin.open(mapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *upload2 = new uint8_t [totalSize+50];
                    
                    fin.read((char*)upload2, totalSize+1);
                    fin.close();
                    
                    yDimensionCount = 0;
                    xDimensionCount = 0;
                    
                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                        readBit [0] = upload2[counter1];
                        readBit [1] = upload2[counter1+1];
                        readBit [2] = upload2[counter1+2];
                        readBit [3] = upload2[counter1+3];
                        
                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                            revisedMap [yDimensionCount][xDimensionCount] = pixData;
                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageDimension){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageDimension){
                                break;
                            }
                        }
                    }
                    
                    delete [] upload2;
                }
            }
        }
        
        //for (int counterA = 200; counterA < 300; counterA++){
        //	for (int counterB = 1600; counterB < 1650; counterB++) cout<<" "<<revisedMap [counterA][counterB];
        //	cout<<" revisedMap "<<counterA<<endl;
        //}
        
        //for (int counterA = 200; counterA < 300; counterA++){
        //	for (int counterB = 1600; counterB < 1650; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
        //	cout<<" revisedWorkingMap "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < 500; counterA++){
        //	for (int counterB = 0; counterB < 500; counterB++) cout<<" "<<connectMapSelect [counterA][counterB];
        //	cout<<" connectMapSelect "<<counterA<<endl;
        //}
        
        fluorescentDetection = 0;
        
        if (fluorescentMapStatus1 == 0){
            fluorescentMap1 = new int *[imageDimension+1];
            fluorescentMapStatus1 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap1 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus2 == 0){
            fluorescentMap2 = new int *[imageDimension+1];
            fluorescentMapStatus2 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap2 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus3 == 0){
            fluorescentMap3 = new int *[imageDimension+1];
            fluorescentMapStatus3 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap3 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus4 == 0){
            fluorescentMap4 = new int *[imageDimension+1];
            fluorescentMapStatus4 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap4 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus5 == 0){
            fluorescentMap5 = new int *[imageDimension+1];
            fluorescentMapStatus5 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap5 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus6 == 0){
            fluorescentMap6 = new int *[imageDimension+1];
            fluorescentMapStatus6 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap6 [counter1] = new int [imageDimension+1];
        }
        
        fluorescentMapFind1 = 0;
        fluorescentMapFind2 = 0;
        fluorescentMapFind3 = 0;
        fluorescentMapFind4 = 0;
        fluorescentMapFind5 = 0;
        fluorescentMapFind6 = 0;
        
        string extension2;
        
        if (fluorescentEntryCount >= 1){
            extension2 = to_string(fluorescentNo1);
            
            string fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
            
            if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 2){
            extension2 = to_string(fluorescentNo2);
            
            string fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exType;
            
            if (stat(fluorescentProcessPath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 3){
            extension2 = to_string(fluorescentNo3);
            
            string fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exType;
            
            if (stat(fluorescentProcessPath3.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 4){
            extension2 = to_string(fluorescentNo4);
            
            string fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exType;
            
            if (stat(fluorescentProcessPath4.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 5){
            extension2 = to_string(fluorescentNo5);
            
            string fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exType;
            
            if (stat(fluorescentProcessPath5.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 6){
            extension2 = to_string(fluorescentNo6);
            
            string fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exType;
            
            if (stat(fluorescentProcessPath6.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        expandFluorescentOutlineCount = 0;
        expandFluorescentDataCount = 0;
        
        if (fluorescentDetection == 1){
            string expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
            string expandDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTemp";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(expandDataTempPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                else if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
            
            if (stat(expandDataTempPath.c_str(), &sizeOfFile) == -1 && stat(expandDataPath.c_str(), &sizeOfFile) == -1 && checkFlag == 0){
                expandFluorescentOutline = new int [10000];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = 10000;
                expandFluorescentOutlineStatus = 1;
            }
            else if (checkFlag == 1){
                expandFluorescentOutline = new int [sizeForCopy+50];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                expandFluorescentOutlineStatus = 1;
                
                fin.open(expandDataTempPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [8];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                    else{
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                    }
                                }
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            expandDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaDataTemp";
            
            sizeForCopy = 0;
            
            if (stat(expandDataTempPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
            
            if (sizeForCopy == 0){
                expandFluorescentData = new int [10000];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = 10000;
                expandFluorescentDataStatus = 1;
            }
            else{
                
                expandFluorescentData = new int [sizeForCopy+50];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = (int)sizeForCopy+50;
                expandFluorescentDataStatus = 1;
                
                fin.open(expandDataTempPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [8];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [8];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            if (trackingOn == 3 && trackingLowerLimit <= imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay){
                int connectNoTemp = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                    if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                        connectNoTemp = arrayConnectLineageRel [counter1*6+1];
                        break;
                    }
                }
                
                if (connectNoTemp != 0){
                    int lineDataFind = 0;
                    
                    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                        if (expandFluorescentOutline [counter1*4+2] == connectNoTemp){
                            lineDataFind = 1;
                            break;
                        }
                    }
                    
                    if (lineDataFind == 0){
                        int startPosition = 0;
                        
                        for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                            if (connectNoTemp == arrayTimeSelected [counter1*10+8]){
                                startPosition = arrayTimeSelected [counter1*10+2];
                            }
                        }
                        
                        int returnResults = 0;
                        
                        if (autoExpand == 1){
                            expandLine = [[ExpandLine alloc] init];
                            returnResults = [expandLine lineExtendTrackType2:connectNoTemp];
                        }
                        
                        if (autoExpand == 0 || (autoExpand == 1 && returnResults == 1)){
                            for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 1, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                            
                            if (fluorescentEntryCount >= 2){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 2, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 3, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 4, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 5, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 6, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            int pixelValueTemp = 0;
                            int pixelAreaTemp = 0;
                            int pixelValueTemp2 = 0;
                            int pixelAreaTemp2 = 0;
                            int pixelValueTemp3 = 0;
                            int pixelAreaTemp3 = 0;
                            int pixelValueTemp4 = 0;
                            int pixelAreaTemp4 = 0;
                            int pixelValueTemp5 = 0;
                            int pixelAreaTemp5 = 0;
                            int pixelValueTemp6 = 0;
                            int pixelAreaTemp6 = 0;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (revisedWorkingMap [counterY][counterX] == connectNoTemp){
                                        if (fluorescentEntryCount >= 1){
                                            if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY][counterX];
                                            pixelAreaTemp++;
                                        }
                                        if (fluorescentEntryCount >= 2){
                                            if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterY][counterX];
                                            pixelAreaTemp2++;
                                        }
                                        if (fluorescentEntryCount >= 3){
                                            if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterY][counterX];
                                            pixelAreaTemp3++;
                                        }
                                        if (fluorescentEntryCount >= 4){
                                            if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) pixelValueTemp4 = pixelValueTemp3+fluorescentMap4 [counterY][counterX];
                                            pixelAreaTemp4++;
                                        }
                                        if (fluorescentEntryCount >= 5){
                                            if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) pixelValueTemp5 = pixelValueTemp3+fluorescentMap5 [counterY][counterX];
                                            pixelAreaTemp5++;
                                        }
                                        if (fluorescentEntryCount >= 6){
                                            if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) pixelValueTemp6 = pixelValueTemp3+fluorescentMap6 [counterY][counterX];
                                            pixelAreaTemp6++;
                                        }
                                    }
                                }
                            }
                            
                            double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                            
                            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate expandFluorescentDataUpDate];
                            }
                            
                            expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 1, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                            
                            if (fluorescentEntryCount >= 2){
                                averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 2, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 3, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 4, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 5, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 6, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
                            }
                        }
                    }
                }
            }
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        
                        break;
                    }
                }
                
                if (matchFind == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
            else{
                
                fluorescentCutOff1 = 150;
                fluorescentCutOff2 = 150;
                fluorescentCutOff3 = 150;
                fluorescentCutOff4 = 150;
                fluorescentCutOff5 = 150;
                fluorescentCutOff6 = 150;
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
            
            fluorescentValueDisplayControl = 1;
        }
        
        if (lineageStartEndCount != 0){
            if (cellEndHoldStatus == 0){
                cellEndHold = new int [10000];
                cellEndHoldCount = 0;
                cellEndHoldLimit = 10000;
                cellEndHoldStatus = 1;
            }
            else cellEndHoldCount = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8+7] == imageNumberTrackForDisplay){
                    if (cellEndHoldLimit < cellEndHoldCount+10){
                        int *arrayUpDate = new int [cellEndHoldCount+10];
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount; counter2++) arrayUpDate [counter2] = cellEndHold [counter2];
                        
                        delete [] cellEndHold;
                        cellEndHold = new int [cellEndHoldLimit+10000];
                        cellEndHoldLimit = cellEndHoldLimit+10000;
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount; counter2++) cellEndHold [counter2] = arrayUpDate [counter2];
                        delete [] arrayUpDate;
                    }
                    
                    if (arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 2 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 1 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 6 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 31 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 41 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 51 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 92 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 10 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 11){
                        cellEndHold [cellEndHoldCount] = arrayLineageStartEnd [counter1*8], cellEndHoldCount++;
                        cellEndHold [cellEndHoldCount] = arrayLineageStartEnd [counter1*8+1], cellEndHoldCount++;
                    }
                }
            }
        }
        
        if (upLoadCheck == 1){
            trackingOn = 6;
            tableTrackingProcessing = 0;
        }
        else{
            
            cellLineageExtract = cellLineageNoHold.substr(1);
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                    arrayConnectLineageRel [counter1*6+4] = 1;
                    break;
                }
            }
            
            tableTrackingProcessing = 1;
        }
    }
    
    if (processType == 3){
        //-----Line Data Read-----
        string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
        string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            sizeForCopy = 0;
            
            if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter1 == 0) size1 = sizeForCopy;
                else if (counter1 == 1) size2 = sizeForCopy;
                else if (counter1 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter1 == 3) size1 = sizeForCopy;
                else if (counter1 == 4) size2 = sizeForCopy;
                else if (counter1 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (checkFlag == 1){
            if (masterLineForTrackingStatus == 1) delete [] arrayMasterLineForTracking;
            arrayMasterLineForTracking = new int [sizeForCopy+50];
            masterLineForTrackingCount = 0;
            masterLineForTrackingStatus = 1;
            
            if (masterLineGravityCenterStatus == 1) delete [] arrayMasterLineGravityCenter;
            
            long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
            arrayMasterLineGravityCenter = new int [sizeForCopy2+50];
            masterLineGravityCenterCount = 0;
            masterLineGravityCenterLimit = (int)sizeForCopy2+50;
            masterLineGravityCenterStatus = 1;
            
            //-----Master Data upLoad-----
            fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [17];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [12], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [13], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [16], masterLineForTrackingCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate masterLineGCUpDate];
                                }
                                
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [11], masterLineGravityCenterCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                else upLoadCheck = 1;
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [11];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate masterLineGCUpDate];
                                    }
                                    
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = 0, masterLineGravityCenterCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    else upLoadCheck = 1;
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    masterLineForTrackingCount = 0;
                    masterLineGravityCenterCount = 0;
                }
            }
        }
        else if (stat(connectDataRevPath.c_str(), &sizeOfFile) == -1 && stat(connectDataPath.c_str(), &sizeOfFile) == -1 && checkFlag == 0){
            masterLineForTrackingCount = 0;
            masterLineGravityCenterCount = 0;
        }
        else upLoadCheck = 1;
        
        //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
        //	cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
        //}
        
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (masterLineSelectedStatus == 1) delete [] arrayMasterLineSelected;
        arrayMasterLineSelected = new int [sizeForCopy+50];
        masterLineSelectedCount = 0;
        masterLineSelectedLimit = (int)sizeForCopy+50;
        masterLineSelectedStatus = 1;
        
        readingError = 0;
        
        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            int finData [19];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            if (masterLineSelectedCount+10 > masterLineSelectedLimit){
                                masterLineSelectedAddition = 10,
                                
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineSelectedUpDate];
                                
                            }
                            
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [0], masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [3], masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [6], masterLineSelectedCount++; //-----PositionRevise Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [8], masterLineSelectedCount++; //-----Cut line number-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [9], masterLineSelectedCount++; //-----X Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [10], masterLineSelectedCount++; //-----X End-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [11], masterLineSelectedCount++; //-----Y Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [12], masterLineSelectedCount++; //-----Y End-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [15], masterLineSelectedCount++; //-----Connect-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [18], masterLineSelectedCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            else upLoadCheck = 1;
            
            delete [] uploadTemp;
        }
        else{
            
            if (masterLineSelectedCount+masterLineGravityCenterCount/6*10 > masterLineSelectedLimit){
                masterLineSelectedAddition = masterLineGravityCenterCount/6*10;
                
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate masterLineSelectedUpDate];
            }
            
            for (int counter1 = 0; counter1 < masterLineGravityCenterCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Top position of each connect-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Cut line number-----
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = counter1+1, masterLineSelectedCount++;
                arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
            }
            
            int valueTemp = 0;
            
            for (int counter1 = 0; counter1 < masterLineForTrackingCount/7; counter1++){
                if (arrayMasterLineForTracking [counter1*7+3] != valueTemp){
                    valueTemp = arrayMasterLineForTracking [counter1*7+3];
                    arrayMasterLineSelected [(valueTemp-1)*10+2] = counter1;
                    
                    if (arrayMasterLineForTracking [counter1*7+5] == 0) arrayMasterLineSelected [(valueTemp-1)*10] = 0;
                }
            }
        }
        
        expandFluorescentOutlineCount = 0;
        expandFluorescentDataCount = 0;
        
        if (fluorescentDetectionDisplay == 1){
            string expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
            
            if (stat(expandDataPath.c_str(), &sizeOfFile) == -1 && checkFlag == 0){
                expandFluorescentOutline = new int [10000];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = 10000;
                expandFluorescentOutlineStatus = 1;
            }
            else if (checkFlag == 1){
                expandFluorescentOutline = new int [sizeForCopy+50];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                expandFluorescentOutlineStatus = 1;
                
                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [8];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
            }
            
            expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            
            if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
                
                if (sizeForCopy == 0){
                    expandFluorescentData = new int [10000];
                    expandFluorescentDataCount = 0;
                    expandFluorescentDataLimit = 10000;
                    expandFluorescentDataStatus = 1;
                }
                else{
                    
                    expandFluorescentData = new int [sizeForCopy+50];
                    expandFluorescentDataCount = 0;
                    expandFluorescentDataLimit = (int)sizeForCopy+50;
                    expandFluorescentDataStatus = 1;
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [8];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
            }
            else expandFluorescentDataCount = 0;
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        
                        break;
                    }
                }
                
                if (matchFind == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < imageNumberTrackForDisplay){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
            else{
                
                fluorescentCutOff1 = 150;
                fluorescentCutOff2 = 150;
                fluorescentCutOff3 = 150;
                fluorescentCutOff4 = 150;
                fluorescentCutOff5 = 150;
                fluorescentCutOff6 = 150;
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
        }
        
        //for (int counterA = 0; counterA < masterLineSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayMasterLineSelected [counterA*10+counterB];
        //	cout<<" arrayMasterLineSelected "<<counterA<<endl;
        //}
        
        if (lineageStartEndCount != 0){
            if (cellEndHoldStatus == 0){
                cellEndHold = new int [10000];
                cellEndHoldCount = 0;
                cellEndHoldLimit = 10000;
                cellEndHoldStatus = 1;
            }
            else cellEndHoldCount = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8+7] == imageNumberTrackForDisplay){
                    if (cellEndHoldLimit < cellEndHoldCount+10){
                        int *arrayUpDate = new int [cellEndHoldCount+10];
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount; counter2++) arrayUpDate [counter2] = cellEndHold [counter2];
                        
                        delete [] cellEndHold;
                        cellEndHold = new int [cellEndHoldLimit+10000];
                        cellEndHoldLimit = cellEndHoldLimit+10000;
                        
                        for (int counter2 = 0; counter2 < cellEndHoldCount; counter2++) cellEndHold [counter2] = arrayUpDate [counter2];
                        delete [] arrayUpDate;
                    }
                    
                    if (arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 2 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 1 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 6 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 31 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 41 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 51 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 92 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 10 || arrayLineageData [arrayLineageStartEnd [counter1*8+6]*8+3] == 11){
                        cellEndHold [cellEndHoldCount] = arrayLineageStartEnd [counter1*8], cellEndHoldCount++;
                        cellEndHold [cellEndHoldCount] = arrayLineageStartEnd [counter1*8+1], cellEndHoldCount++;
                    }
                }
            }
        }
        
        tableTrackingProcessing = 0;
    }
    
    if (processType == 4){
        string cellLineageExtract = cellLineageNoHold.substr(1);
        string cellNoExtract = cellNoHold.substr(1);
        int cellLineageTempInt = atoi(cellLineageExtract.c_str());
        int cellNumberTempInt = atoi(cellNoExtract.c_str());
        
        string cutLineDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ConnectLineageRelTemp";
        
        referenceLineCount = 0;
        
        struct stat sizeOfFile;
        
        if (stat(cutLineDataPath.c_str(), &sizeOfFile) == 0){
            for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                if (arrayPositionRevise [counter1*7+4] == cellNumberTempInt && arrayPositionRevise [counter1*7+6] == cellLineageTempInt){
                    if (referenceLineCount+4 > referenceLineLimit){
                        fileUpdate = [[FileUpdate alloc] init];
                        [fileUpdate referenceLineCountUpDate];
                    }
                    
                    arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7], referenceLineCount++;
                    arrayReferenceLine [referenceLineCount] = arrayPositionRevise [counter1*7+1], referenceLineCount++;
                }
            }
            
            upLoadCheck = 1;
        }
        else upLoadCheck = 0;
    }
    
    if (processType == 5){
        //-----Line Data Read-----
        string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
        string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            sizeForCopy = 0;
            
            if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter1 == 0) size1 = sizeForCopy;
                else if (counter1 == 1) size2 = sizeForCopy;
                else if (counter1 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter1 == 3) size1 = sizeForCopy;
                else if (counter1 == 4) size2 = sizeForCopy;
                else if (counter1 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (checkFlag == 1){
            if (masterLineForDisplayStatus == 1) delete [] arrayMasterLineForDisplay;
            arrayMasterLineForDisplay = new int [sizeForCopy+50];
            masterLineForDisplayCount = 0;
            masterLineForDisplayStatus = 1;
            
            if (masterLineGCDisplayStatus == 1) delete [] arrayMasterLineGravityCenterDisplay;
            
            long sizeForCopy2 = (int)(sizeForCopy*(double)0.5+50);
            arrayMasterLineGravityCenterDisplay = new int [sizeForCopy2+50];
            masterLineGCDisplayCount = 0;
            masterLineGCDisplayLimit = (int)sizeForCopy2+50;
            masterLineGCDisplayStatus = 1;
            
            //-----Master Data upLoad-----
            fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [17];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [1], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [3], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [4], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [7], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [12], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [13], masterLineForDisplayCount++;
                                arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [16], masterLineForDisplayCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (masterLineGCDisplayCount+14 > masterLineGCDisplayLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate masterLineGCDisplayUpDate];
                                }
                                
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [1], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [3], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [6], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [7], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [10], masterLineGCDisplayCount++;
                                arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [11], masterLineGCDisplayCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [11];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [1], masterLineForDisplayCount++;
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [3], masterLineForDisplayCount++;
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [4], masterLineForDisplayCount++;
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = finData [5], masterLineForDisplayCount++;
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = 0, masterLineForDisplayCount++;
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = 0, masterLineForDisplayCount++;
                                    arrayMasterLineForDisplay [masterLineForDisplayCount] = 0, masterLineForDisplayCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (masterLineGCDisplayCount+14 > masterLineGCDisplayLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate masterLineGCDisplayUpDate];
                                    }
                                    
                                    arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [1], masterLineGCDisplayCount++;
                                    arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [3], masterLineGCDisplayCount++;
                                    arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [6], masterLineGCDisplayCount++;
                                    arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [7], masterLineGCDisplayCount++;
                                    arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = finData [10], masterLineGCDisplayCount++;
                                    arrayMasterLineGravityCenterDisplay [masterLineGCDisplayCount] = 0, masterLineGCDisplayCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (checkFlag == 0 || readingError == 1){
            masterLineForDisplayCount = 0;
            masterLineGCDisplayCount = 0;
            
            upLoadCheck = 1;
        }
        
        //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
        //	cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
        //}
        
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (masterLineSelectedDisplayStatus == 1) delete [] arrayMasterLineSelectedDisplay;
        arrayMasterLineSelectedDisplay = new int [sizeForCopy+50];
        masterLineSelectedDisplayCount = 0;
        masterLineSelectedDisplayLimit = (int)sizeForCopy+50;
        masterLineSelectedDisplayStatus = 1;
        
        fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
        
        readingError = 0;
        
        if (fin.is_open()){
            int finData [19];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            if (masterLineSelectedDisplayCount+10 > masterLineSelectedDisplayLimit){
                                masterLineSelectedDisplayAddition = 10;
                                
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineSelectedDisplayUpDate];
                            }
                            
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [0], masterLineSelectedDisplayCount++; //-----Selected, removed, eliminated status-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [3], masterLineSelectedDisplayCount++; //-----When new line is created, enter line number which creates-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [6], masterLineSelectedDisplayCount++; //-----PositionRevise Start-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [8], masterLineSelectedDisplayCount++; //-----Cut line number-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [9], masterLineSelectedDisplayCount++; //-----X Start-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [10], masterLineSelectedDisplayCount++; //-----X End-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [11], masterLineSelectedDisplayCount++; //-----Y Start-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [12], masterLineSelectedDisplayCount++; //-----Y End-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [15], masterLineSelectedDisplayCount++; //-----Connect-----
                            arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = finData [18], masterLineSelectedDisplayCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            else upLoadCheck = 1;
            
            delete [] uploadTemp;
        }
        else{
            
            if (masterLineSelectedDisplayCount+masterLineGCDisplayCount/6*10 > masterLineSelectedDisplayLimit){
                masterLineSelectedDisplayAddition = masterLineGCDisplayCount/6*10;
                
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate masterLineSelectedDisplayUpDate];
            }
            
            for (int counter1 = 0; counter1 < masterLineGCDisplayCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----Selected, removed, eliminated status-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----When new line is created, enter line number which creates-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----Top position of each connect-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++; //-----Cut line number-----
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = counter1+1, masterLineSelectedDisplayCount++;
                arrayMasterLineSelectedDisplay [masterLineSelectedDisplayCount] = 0, masterLineSelectedDisplayCount++;
            }
            
            int valueTemp = 0;
            
            for (int counter1 = 0; counter1 < masterLineForDisplayCount/7; counter1++){
                if (arrayMasterLineForDisplay [counter1*7+3] != valueTemp){
                    valueTemp = arrayMasterLineForDisplay [counter1*7+3];
                    arrayMasterLineSelectedDisplay [(valueTemp-1)*10+2] = counter1;
                }
            }
        }
    }
    
    if (processType == 6){
        string extension2 = to_string(ifStartHold-1);
        
        if (extension2.length() == 1) extension2 = "000"+extension2;
        else if (extension2.length() == 2) extension2 = "00"+extension2;
        else if (extension2.length() == 3) extension2 = "0"+extension2;
        
        //-----Line Data Read-----
        string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension2+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
        string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        string connectDataRevPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            sizeForCopy = 0;
            
            if (stat(connectDataRevPath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter1 == 0) size1 = sizeForCopy;
                else if (counter1 == 1) size2 = sizeForCopy;
                else if (counter1 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter1 == 3) size1 = sizeForCopy;
                else if (counter1 == 4) size2 = sizeForCopy;
                else if (counter1 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (checkFlag == 1){
            if (masterLineForTrackingStatus == 1) delete [] arrayMasterLineForTracking;
            arrayMasterLineForTracking = new int [sizeForCopy+50];
            masterLineForTrackingCount = 0;
            masterLineForTrackingStatus = 1;
            
            if (masterLineGravityCenterStatus == 1) delete [] arrayMasterLineGravityCenter;
            
            long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
            arrayMasterLineGravityCenter = new int [sizeForCopy2+50];
            masterLineGravityCenterCount = 0;
            masterLineGravityCenterLimit = (int)sizeForCopy2+50;
            masterLineGravityCenterStatus = 1;
            
            //-----Master Data upLoad-----
            fin.open(connectDataRevPath2.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [17];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [12], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [13], masterLineForTrackingCount++;
                                arrayMasterLineForTracking [masterLineForTrackingCount] = finData [16], masterLineForTrackingCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate masterLineGCUpDate];
                                }
                                
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                                arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [11], masterLineGravityCenterCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [12], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [13], masterLineForTrackingCount++;
                                    arrayMasterLineForTracking [masterLineForTrackingCount] = finData [16], masterLineForTrackingCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate masterLineGCUpDate];
                                    }
                                    
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                                    arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [11], masterLineGravityCenterCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [11];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = finData [1], masterLineForTrackingCount++;
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = finData [3], masterLineForTrackingCount++;
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = finData [4], masterLineForTrackingCount++;
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = finData [7], masterLineForTrackingCount++;
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                        arrayMasterLineForTracking [masterLineForTrackingCount] = 0, masterLineForTrackingCount++;
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData [9] = finData [8]*256+finData [9];
                                    
                                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        if (masterLineGravityCenterCount+12 > masterLineGravityCenterLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate masterLineGCUpDate];
                                        }
                                        
                                        arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [1], masterLineGravityCenterCount++;
                                        arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [3], masterLineGravityCenterCount++;
                                        arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [6], masterLineGravityCenterCount++;
                                        arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [7], masterLineGravityCenterCount++;
                                        arrayMasterLineGravityCenter [masterLineGravityCenterCount] = finData [10], masterLineGravityCenterCount++;
                                        arrayMasterLineGravityCenter [masterLineGravityCenterCount] = 0, masterLineGravityCenterCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
        }
        
        if (checkFlag == 0 || readingError == 1){
            masterLineForTrackingCount = 0;
            masterLineGravityCenterCount = 0;
            
            upLoadCheck = 1;
        }
        
        //for (int counterA = 0; counterA < masterLineGravityCenterCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayMasterLineGravityCenter [counterA*6+counterB];
        //	cout<<" arrayMasterLineGravityCenter "<<counterA<<endl;
        //}
        
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        string connectStatusDataPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusDataPath2.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (masterLineSelectedStatus == 1) delete [] arrayMasterLineSelected;
        
        arrayMasterLineSelected = new int [sizeForCopy+50];
        masterLineSelectedCount = 0;
        masterLineSelectedLimit = (int)sizeForCopy+50;
        masterLineSelectedStatus = 1;
        
        fin.open(connectStatusDataPath2.c_str(), ios::in | ios::binary);
        
        readingError = 0;
        
        if (fin.is_open()){
            int finData [19];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            if (masterLineSelectedCount+10 > masterLineSelectedLimit){
                                masterLineSelectedAddition = 10;
                                
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate masterLineSelectedUpDate];
                            }
                            
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [0], masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [3], masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [6], masterLineSelectedCount++; //-----PositionRevise Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [8], masterLineSelectedCount++; //-----Cut line number-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [9], masterLineSelectedCount++; //-----X Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [10], masterLineSelectedCount++; //-----X End-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [11], masterLineSelectedCount++; //-----Y Start-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [12], masterLineSelectedCount++; //-----Y End-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [15], masterLineSelectedCount++; //-----Connect-----
                            arrayMasterLineSelected [masterLineSelectedCount] = finData [18], masterLineSelectedCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            else upLoadCheck = 1;
            
            delete [] uploadTemp;
        }
        else{
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [19];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                        readingError = 1;
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                if (masterLineSelectedCount+10 > masterLineSelectedLimit){
                                    masterLineSelectedAddition = 10;
                                    
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate masterLineSelectedUpDate];
                                }
                                
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [0], masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [3], masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [6], masterLineSelectedCount++; //-----PositionRevise Start-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [8], masterLineSelectedCount++; //-----Cut line number-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [9], masterLineSelectedCount++; //-----X Start-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [10], masterLineSelectedCount++; //-----X End-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [11], masterLineSelectedCount++; //-----Y Start-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [12], masterLineSelectedCount++; //-----Y End-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [15], masterLineSelectedCount++; //-----Connect-----
                                arrayMasterLineSelected [masterLineSelectedCount] = finData [18], masterLineSelectedCount++; //-----Lineage-----
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                else upLoadCheck = 1;
                
                delete [] uploadTemp;
            }
            else{
                
                if (masterLineSelectedCount+masterLineGravityCenterCount/6*10 > masterLineSelectedLimit){
                    masterLineSelectedAddition = masterLineGravityCenterCount/6*10;
                    
                    fileUpdate = [[FileUpdate alloc] init];
                    [fileUpdate masterLineSelectedUpDate];
                }
                
                for (int counter1 = 0; counter1 < masterLineGravityCenterCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Selected, removed, eliminated status-----
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----When new line is created, enter line number which creates-----
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Top position of each connect-----
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++; //-----Cut line number-----
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                    arrayMasterLineSelected [masterLineSelectedCount] = counter1+1, masterLineSelectedCount++;
                    arrayMasterLineSelected [masterLineSelectedCount] = 0, masterLineSelectedCount++;
                }
                
                int valueTemp = 0;
                
                for (int counter1 = 0; counter1 < masterLineForTrackingCount/7; counter1++){
                    if (arrayMasterLineForTracking [counter1*7+3] != valueTemp){
                        valueTemp = arrayMasterLineForTracking [counter1*7+3];
                        arrayMasterLineSelected [(valueTemp-1)*10+2] = counter1;
                        
                        if (arrayMasterLineForTracking [counter1*7+5] == 0) arrayMasterLineSelected [(valueTemp-1)*10] = 0;
                    }
                }
            }
        }
        
        expandFluorescentOutlineCount = 0;
        expandFluorescentDataCount = 0;
        
        if (fluorescentDetectionDisplay == 1){
            string expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
            string expandDataPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(expandDataPath2.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                else if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
            
            if (stat(expandDataPath2.c_str(), &sizeOfFile) == -1 && stat(expandDataPath.c_str(), &sizeOfFile) == -1 && checkFlag == 0){
                expandFluorescentOutline = new int [10000];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = 10000;
                expandFluorescentOutlineStatus = 1;
            }
            else if (checkFlag == 1){
                expandFluorescentOutline = new int [sizeForCopy+50];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                expandFluorescentOutlineStatus = 1;
                
                fin.open(expandDataPath2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [8];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                    else{
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            expandDataPath2 = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            
            sizeForCopy = 0;
            
            if (stat(expandDataPath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
            
            if (sizeForCopy == 0){
                expandFluorescentData = new int [10000];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = 10000;
                expandFluorescentDataStatus = 1;
            }
            else{
                
                expandFluorescentData = new int [sizeForCopy+50];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = (int)sizeForCopy+50;
                expandFluorescentDataStatus = 1;
                
                fin.open(expandDataPath2.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [8];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [8];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < masterLineSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayMasterLineSelected [counterA*10+counterB];
        //	cout<<" arrayMasterLineSelected "<<counterA<<endl;
        //}
        
        tableTrackingProcessing = 0;
    }
    
    if (processType == 7){
        gravityCenterXHold1 = 0;
        gravityCenterYHold1 = 0;
        gravityAverageHold1 = 0;
        gravityCellNo1 = 0;
        gravityCenterXHold2 = 0;
        gravityCenterYHold2 = 0;
        gravityAverageHold2 = 0;
        gravityCellNo2 = 0;
        gravityCenterXHold3 = 0;
        gravityCenterYHold3 = 0;
        gravityAverageHold3 = 0;
        gravityCellNo3 = 0;
        gravityCenterXHold4 = 0;
        gravityCenterYHold4 = 0;
        gravityAverageHold4 = 0;
        gravityCellNo4 = 0;
        
        string extension2 = to_string(ifStartHold-1);
        
        if (extension2.length() == 1) extension2 = "000"+extension2;
        else if (extension2.length() == 2) extension2 = "00"+extension2;
        else if (extension2.length() == 3) extension2 = "0"+extension2;
        
        string cellLineageExtract = "";
        if (cellLineageNoHold != "") cellLineageExtract = cellLineageNoHold.substr(1);
        
        string cellNoExtract = "";
        if (cellNoHold != "") cellNoExtract = cellNoHold.substr(1);
        
        int lineageAmendTemp = atoi(cellLineageExtract.c_str());
        int cellAmendTemp = atoi(cellNoExtract.c_str());
        
        string connectDataPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension2+"_"+analysisImageName+"_"+treatmentNameHold+"_MasterData";
        string connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
        string connectDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension2+"_MasterDataTemp";
        
        struct stat sizeOfFile;
        long sizeForCopy = 0;
        
        if (stat(connectDataTempPath.c_str(), &sizeOfFile) == 0) cutBase = 1; //-----Presence of temp file check, use for Cut operation-----
        else cutBase = 0;
        
        long size1 = 0;
        long size2 = 0;
        int checkFlag = 0;
        int readingError = 0;
        
        for (int counter1 = 0; counter1 < 6; counter1++){
            sizeForCopy = 0;
            
            if (stat(connectDataTempPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (sizeForCopy != 0){
                if (counter1 == 0) size1 = sizeForCopy;
                else if (counter1 == 1) size2 = sizeForCopy;
                else if (counter1 == 2){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                        break;
                    }
                    else{
                        
                        size1 = 0;
                        size2 = 0;
                        usleep (50000);
                    }
                }
                else if (counter1 == 3) size1 = sizeForCopy;
                else if (counter1 == 4) size2 = sizeForCopy;
                else if (counter1 == 5){
                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                        checkFlag = 1;
                    }
                }
            }
        }
        
        if (checkFlag == 1){
            if (positionReviseStatus == 1) delete [] arrayPositionRevise;
            
            arrayPositionRevise = new int [sizeForCopy+50];
            positionReviseCount = 0;
            positionReviseLimit = (int)sizeForCopy+50;
            positionReviseStatus = 1;
            
            long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
            
            if (gravityCenterRevStatus == 1) delete [] arrayGravityCenterRev;
            
            arrayGravityCenterRev = new int [sizeForCopy2+50];
            gravityCenterRevCount = 0;
            gravityCenterRevLimit = (int)sizeForCopy2+50;
            gravityCenterRevStatus = 1;
            
            sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
            
            if (associateDataStatus == 1) delete [] arrayAssociateData;
            
            arrayAssociateData = new int [sizeForCopy2+50];
            associateDataCount = 0;
            associateDataLimit = (int)sizeForCopy2+50;
            associateDataStatus = 1;
            
            fin.open(connectDataTempPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [17];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            readingError = 1;
                        }
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++;
                            finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            else{
                                
                                arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                            }
                        }
                        else if (stepCount == 1){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            finData [9] = finData [8]*256+finData [9];
                            
                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            else{
                                
                                if (associateDataCount+12 > associateDataLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate associateDataUpDate];
                                }
                                
                                arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                            }
                        }
                        else if (stepCount == 2){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                            finData [8] = uploadTemp [readPosition], readPosition++;
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                            
                            if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            else{
                                
                                if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                    fileUpdate = [[FileUpdate alloc] init];
                                    [fileUpdate gravityCenterRevUpDate];
                                }
                                
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [17];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [12], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [13], positionReviseCount++;
                                    arrayPositionRevise [positionReviseCount] = finData [16], positionReviseCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                else{
                                    
                                    if (associateDataCount+12 > associateDataLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate associateDataUpDate];
                                    }
                                    
                                    arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                    arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                                }
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate gravityCenterRevUpDate];
                                    }
                                    
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                    arrayGravityCenterRev [gravityCenterRevCount] = finData [11], gravityCenterRevCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [11];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 ){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    else{
                                        
                                        arrayPositionRevise [positionReviseCount] = finData [1], positionReviseCount++; //-----X Position-----
                                        arrayPositionRevise [positionReviseCount] = finData [3], positionReviseCount++; //-----Y Position-----
                                        arrayPositionRevise [positionReviseCount] = finData [4], positionReviseCount++; //-----Value-----
                                        arrayPositionRevise [positionReviseCount] = finData [7], positionReviseCount++; //-----Connect No-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Cell No-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Status-----
                                        arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++; //-----Lineage no-----
                                    }
                                }
                                else if (stepCount == 1){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                    
                                    finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                    finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                    finData [9] = finData [8]*256+finData [9];
                                    
                                    if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    else{
                                        
                                        if (associateDataCount+12 > associateDataLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate associateDataUpDate];
                                        }
                                        
                                        arrayAssociateData [associateDataCount] = finData [2], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [3], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [4], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [7], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [9], associateDataCount++;
                                        arrayAssociateData [associateDataCount] = finData [10], associateDataCount++;
                                    }
                                }
                                else if (stepCount == 2){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                    finData [8] = uploadTemp [readPosition], readPosition++;
                                    finData [9] = uploadTemp [readPosition], readPosition++;
                                    finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                    else{
                                        
                                        if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate gravityCenterRevUpDate];
                                        }
                                        
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [1], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [3], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [6], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [7], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = finData [10], gravityCenterRevCount++;
                                        arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
        //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
        //	cout<<" arrayPositionRevise "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < gravityCenterRevCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterRev [counterA*6+counterB];
        //	cout<<" arrayGravityCenterRev "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < associateDataCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayAssociateData [counterA*6+counterB];
        //	cout<<" arrayAssociateData "<<counterA<<endl;
        //}
        
        //-----Master Data Status UpLoad-----
        string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_Status";
        string connectStatusTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension2+"_StatusTemp";
        
        sizeForCopy = 0;
        
        if (stat(connectStatusTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (sizeForCopy < gravityCenterRevCount*2) sizeForCopy = gravityCenterRevCount*2;
        
        if (timeSelectedStatus == 1) delete [] arrayTimeSelected;
        
        arrayTimeSelected = new int [sizeForCopy+50];
        timeSelectedCount = 0;
        timeSelectedLimit = (int)sizeForCopy+50;
        timeSelectedStatus = 1;
        
        if (timeSelectedHoldStatus == 1) delete [] arrayTimeSelectedHold;
        
        arrayTimeSelectedHold = new int [sizeForCopy+50];
        timeSelectedHoldCount = 0;
        timeSelectedHoldStatus = 1;
        
        fin.open(connectStatusTempPath.c_str(), ios::in | ios::binary);
        
        readingError = 0;
        
        if (fin.is_open()){
            int finData [19];
            
            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
            fin.read((char*)uploadTemp, sizeForCopy+50);
            
            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                usleep(50000);
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    readingError = 1;
                }
            }
            
            fin.close();
            
            if (readingError == 0){
                unsigned long readPosition = 0;
                int stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                            arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                            arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                            arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                            arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                            arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                            arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                            arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
            }
            else upLoadCheck = 1;
            
            delete [] uploadTemp;
        }
        else{
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [19];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0){
                        readingError = 1;
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelected [timeSelectedCount] = finData [0], timeSelectedCount++; //-----Selected, removed, eliminated status-----
                                arrayTimeSelected [timeSelectedCount] = finData [3], timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                                arrayTimeSelected [timeSelectedCount] = finData [6], timeSelectedCount++; //-----PositionRevise Start-----
                                arrayTimeSelected [timeSelectedCount] = finData [8], timeSelectedCount++; //-----Cut line number-----
                                arrayTimeSelected [timeSelectedCount] = finData [9], timeSelectedCount++; //-----X Start-----
                                arrayTimeSelected [timeSelectedCount] = finData [10], timeSelectedCount++; //-----X End-----
                                arrayTimeSelected [timeSelectedCount] = finData [11], timeSelectedCount++; //-----Y Start-----
                                arrayTimeSelected [timeSelectedCount] = finData [12], timeSelectedCount++; //-----Y End-----
                                arrayTimeSelected [timeSelectedCount] = finData [15], timeSelectedCount++; //-----Connect-----
                                arrayTimeSelected [timeSelectedCount] = finData [18], timeSelectedCount++; //-----Lineage-----
                                
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [0], timeSelectedHoldCount++; //-----Selected, removed, eliminated status-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [3], timeSelectedHoldCount++; //-----When new line is created, enter line number which creates-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [6], timeSelectedHoldCount++; //-----PositionRevise Start-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [8], timeSelectedHoldCount++; //-----Cut line number-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [9], timeSelectedHoldCount++; //-----X Start-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [10], timeSelectedHoldCount++; //-----X End-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [11], timeSelectedHoldCount++; //-----Y Start-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [12], timeSelectedHoldCount++; //-----Y End-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [15], timeSelectedHoldCount++; //-----Connect-----
                                arrayTimeSelectedHold [timeSelectedHoldCount] = finData [18], timeSelectedHoldCount++; //-----Lineage-----
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                else upLoadCheck = 1;
                
                delete [] uploadTemp;
            }
            else{
                
                for (int counter1 = 0; counter1 < gravityCenterRevCount/6; counter1++){ //-----Counter number corresponds to connect No-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Selected, removed, eliminated status-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----When new line is created, enter line number which creates-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Top position of each connect-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Cut line number-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----X End-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y Start-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Y End-----
                    arrayTimeSelected [timeSelectedCount] = counter1+1, timeSelectedCount++; //-----Connect-----
                    arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++; //-----Lineage-----
                    
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Selected, removed, eliminated status-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Line process, group-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----reserve-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++; //-----Cut line number-----
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = counter1+1, timeSelectedHoldCount++;
                    arrayTimeSelectedHold [timeSelectedHoldCount] = 0, timeSelectedHoldCount++;
                }
                
                int valueTemp = 0;
                
                for (int counter1 = 0; counter1 < positionReviseCount/7; counter1++){
                    if (arrayPositionRevise [counter1*7+3] != valueTemp){
                        valueTemp = arrayPositionRevise [counter1*7+3];
                        arrayTimeSelected [(valueTemp-1)*10+2] = counter1;
                        arrayTimeSelectedHold [(valueTemp-1)*10+2] = counter1;
                        
                        if (arrayPositionRevise [counter1*7+5] == 0){
                            arrayTimeSelected [(valueTemp-1)*10] = 0;
                            arrayTimeSelectedHold [(valueTemp-1)*10] = 0;
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
        //	cout<<" arrayTimeSelected "<<counterA<<endl;
        //}
        
        if (targetHoldStatus == 1){
            delete [] arrayTargetHold;
            delete [] arrayTargetHoldInfo;
        }
        
        arrayTargetHold = new int [5000];
        targetHoldCount = 0;
        targetHoldLimit = 5000;
        targetHoldStatus = 1;
        arrayTargetHoldInfo = new int [500];
        targetHoldInfoCount = 0;
        targetHoldInfoLimit = 500;
        
        string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
        string connectRelationTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension2+"_ConnectLineageRelTemp";
        
        sizeForCopy = 0;
        
        if (stat(connectRelationTempPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        else if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
        }
        
        if (connectLineageRelStatus == 1){
            delete [] arrayConnectLineageRel;
            connectLineageRelStatus = 0;
        }
        
        if (sizeForCopy == 0){
            arrayConnectLineageRel = new int [timeSelectedCount+500];
            connectLineageRelCount = 0;
            connectLineageRelLimit = timeSelectedCount+500;
            connectLineageRelStatus = 1;
        }
        else{
            
            arrayConnectLineageRel = new int [sizeForCopy+50];
            connectLineageRelCount = 0;
            connectLineageRelLimit = (int)sizeForCopy+50;
            connectLineageRelStatus = 1;
            
            readingError = 0;
            
            fin.open(connectRelationTempPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                int finData [19];
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                
                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                    usleep(50000);
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                        readingError = 1;
                    }
                }
                
                fin.close();
                
                if (readingError == 0){
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRel [connectLineageRelCount] = finData [2], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [5], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [7], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [12], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [13], connectLineageRelCount++;
                                arrayConnectLineageRel [connectLineageRelCount] = finData [14], connectLineageRelCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                }
                else upLoadCheck = 1;
                
                delete [] uploadTemp;
            }
            else{
                
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [19];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0){
                            readingError = 1;
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                finData [3] = uploadTemp [readPosition], readPosition++;
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                finData [7] = finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                else{
                                    
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [2], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [5], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [7], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [12], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [13], connectLineageRelCount++;
                                    arrayConnectLineageRel [connectLineageRelCount] = finData [14], connectLineageRelCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    else upLoadCheck = 1;
                    
                    delete [] uploadTemp;
                }
                else connectLineageRelCount = 0;
            }
        }
        
        //-----Event sequence set-----
        int findFlag = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                findFlag = 1;
                break;
            }
        }
        
        if (findFlag == 0){
            if (eventSequenceCount+4 > eventSequenceLimit){
                fileUpdate = [[FileUpdate alloc] init];
                [fileUpdate eventSequenceUpDate];
            }
            
            arrayEventSequence [eventSequenceCount] = imageNumberTrackForDisplay, eventSequenceCount++; //-----Image no-----
            arrayEventSequence [eventSequenceCount] = 2, eventSequenceCount++; //-----Event type-----
            arrayEventSequence [eventSequenceCount] = lineageAmendTemp, eventSequenceCount++; //-----Lineage no-----
            arrayEventSequence [eventSequenceCount] = cellAmendTemp, eventSequenceCount++; //-----Cell no-----
        }
        
        eventSequenceHoldCount = 0;
        
        for (int counter1 = 0; counter1 < eventSequenceCount/4; counter1++){
            if (arrayEventSequence [counter1*4] == imageNumberTrackForDisplay){
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+1], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+2], eventSequenceHoldCount++;
                arrayEventSequenceHold [eventSequenceHoldCount] = arrayEventSequence [counter1*4+3], eventSequenceHoldCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
            if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay) arrayLineageGRCurrent [counter1*4] = 0;
        }
        
        if (lineageGRCurrentCount+8 > lineageGRCurrentLimit){
            fileUpdate = [[FileUpdate alloc] init];
            [fileUpdate lineageGRCurrentUpDate];
        }
        
        for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
            if (arrayLineageGRCurrent [counter1*4] == ifStartHold-1){
                arrayLineageGRCurrent [lineageGRCurrentCount] = imageNumberTrackForDisplay, lineageGRCurrentCount++;
                arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGRCurrent [counter1*4+1], lineageGRCurrentCount++;
                arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGRCurrent [counter1*4+2], lineageGRCurrentCount++;
                arrayLineageGRCurrent [lineageGRCurrentCount] = arrayLineageGRCurrent [counter1*4+3], lineageGRCurrentCount++;
                break;
            }
        }
        
        lineageGravityCenterCurrentHoldCount = 0;
        
        for (int counter1 = 0; counter1 < lineageGRCurrentCount/4; counter1++){
            if (arrayLineageGRCurrent [counter1*4] == imageNumberTrackForDisplay){
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4], lineageGravityCenterCurrentHoldCount++;
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+1], lineageGravityCenterCurrentHoldCount++;
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+2], lineageGravityCenterCurrentHoldCount++;
                arrayLineageGravityCenterCurrentHold [lineageGravityCenterCurrentHoldCount] = arrayLineageGRCurrent [counter1*4+3], lineageGravityCenterCurrentHoldCount++;
            }
        }
        
        // for (int counterA = 0; counterA < lineageGravityCenterCurrentHoldCount/4; counterA++){
        //  	for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGravityCenterCurrentHold [counterA*4+counterB];
        //  	cout<<" arrayLineageGravityCenterCurrentHold "<<counterA<<endl;
        // }
        
        //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRel [counterA*6+counterB];
        //	cout<<" arrayConnectLineageRel "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < eventSequenceCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequence [counterA*4+counterB];
        //    cout<<" arrayEventSequence "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < eventSequenceHoldCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayEventSequenceHold [counterA*4+counterB];
        //    cout<<" arrayEventSequenceHold "<<counterA<<endl;
        //}
        
        //for (int counterA = 0; counterA < lineageGRCurrentCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayLineageGRCurrent [counterA*4+counterB];
        //    cout<<" arrayLineageGRCurrent "<<counterA<<endl;
        //}
        
        string sourceImagePath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+exTypeIF+fluorescentRoundNo;
        string mapPath = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Processed/"+extension2+"_"+analysisImageName+"_"+treatmentNameHold+"_Map";
        string revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension2+"_"+analysisID+"_"+treatmentNameHold+"_RevisedMap";
        string revisedTempMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension2+"_RevisedTempMap";
        
        for (int counter1 = 0; counter1 < imageSizeListCount/2; counter1++){
            if (arrayImageSizeList [counter1*2] == treatmentNameHold){
                imageDimension = atoi(arrayImageSizeList [counter1*2+1].c_str());
                break;
            }
        }
        
        if (sourceImageStatus == 0){
            sourceImage = new int *[imageDimension+1];
            sourceImageStatus = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) sourceImage [counter1] = new int [imageDimension+1];
        }
        
        if (revisedMapStatus == 0){
            revisedMap = new int *[imageDimension+1];
            revisedMapStatus = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedMap [counter1] = new int [imageDimension+1];
        }
        
        if (revisedWorkingMapStatus == 0){
            revisedWorkingMap = new int *[imageDimension+1];
            revisedWorkingMapStatus = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) revisedWorkingMap [counter1] = new int [imageDimension+1];
        }
        
        if (stat(sourceImagePath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            if (exType == ".tif" || exTypeIF == ".TIF"){
                int dataConversion [4];
                int endianType = 0;
                int imageWidthEntry = 0;
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int imageDimensionReadCount = 0;
                
                unsigned long headPosition = 0;
                
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    dataConversion [0] = uploadTemp [0];
                    dataConversion [1] = uploadTemp [1];
                    
                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                    else endianType = 0;
                    
                    headPosition = 0;
                    
                    if (endianType == 1){
                        dataConversion [0] = uploadTemp [7];
                        dataConversion [1] = uploadTemp [6];
                        dataConversion [2] = uploadTemp [5];
                        dataConversion [3] = uploadTemp [4];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    else if (endianType == 0){
                        dataConversion [0] = uploadTemp [4];
                        dataConversion [1] = uploadTemp [5];
                        dataConversion [2] = uploadTemp [6];
                        dataConversion [3] = uploadTemp [7];
                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                    }
                    
                    imageDimensionReadCount = 0;
                    imageWidthEntry = 0;
                    
                    if (tifImageColorGray == 0){
                        for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                            sourceImage [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                            
                            if (imageWidthEntry == imageDimension){
                                imageWidthEntry = 0;
                                imageDimensionReadCount++;
                            }
                        }
                    }
                    else if (tifImageColorGray == 1){
                        for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                            value0 = uploadTemp [counter3];
                            value1 = uploadTemp [counter3+1];
                            value2 = uploadTemp [counter3+2];
                            
                            sourceImage [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                            
                            if (imageWidthEntry == imageDimension){
                                imageWidthEntry = 0;
                                imageDimensionReadCount++;
                            }
                        }
                    }
                }
                
                delete [] uploadTemp;
            }
            else if (exType == ".bmp" || exTypeIF == ".BMP"){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.open(sourceImagePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    int imageDimensionReadCount = 0;
                    
                    for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                        for (int counter2 = 0; counter2 < imageDimension; counter2++){
                            sourceImage [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                        }
                        
                        imageDimensionReadCount++;
                    }
                }
                
                delete [] uploadTemp;
            }
        }
        
        int yDimensionCount;
        int xDimensionCount;
        int readBit [4];
        int pixData = 0;
        int totalSize = imageDimension*imageDimension*4;
        
        fin.open(revisedTempMapPath.c_str(), ios::in | ios::binary);
        
        if (fin.is_open()){
            uint8_t *upload2 = new uint8_t [totalSize+50];
            fin.read((char*)upload2, totalSize+1);
            fin.close();
            
            yDimensionCount = 0;
            xDimensionCount = 0;
            
            for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                readBit [0] = upload2[counter1];
                readBit [1] = upload2[counter1+1];
                readBit [2] = upload2[counter1+2];
                readBit [3] = upload2[counter1+3];
                
                pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                
                for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                    revisedMap [yDimensionCount][xDimensionCount] = pixData;
                    revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                }
                
                if (xDimensionCount == imageDimension){
                    xDimensionCount = 0;
                    yDimensionCount++;
                    
                    if (yDimensionCount == imageDimension){
                        break;
                    }
                }
            }
            
            delete [] upload2;
        }
        else{
            
            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *upload2 = new uint8_t [totalSize+50];
                
                fin.read((char*)upload2, totalSize+1);
                fin.close();
                
                yDimensionCount = 0;
                xDimensionCount = 0;
                
                for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                    readBit [0] = upload2[counter1];
                    readBit [1] = upload2[counter1+1];
                    readBit [2] = upload2[counter1+2];
                    readBit [3] = upload2[counter1+3];
                    
                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                    
                    for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                        revisedMap [yDimensionCount][xDimensionCount] = pixData;
                        revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                    }
                    
                    if (xDimensionCount == imageDimension){
                        xDimensionCount = 0;
                        yDimensionCount++;
                        
                        if (yDimensionCount == imageDimension){
                            break;
                        }
                    }
                }
                
                delete [] upload2;
            }
            else{
                
                fin.open(mapPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *upload2 = new uint8_t [totalSize+50];
                    
                    fin.read((char*)upload2, totalSize+1);
                    fin.close();
                    
                    yDimensionCount = 0;
                    xDimensionCount = 0;
                    
                    for (int counter1 = 0; counter1 < totalSize; counter1 = counter1+4){
                        readBit [0] = upload2[counter1];
                        readBit [1] = upload2[counter1+1];
                        readBit [2] = upload2[counter1+2];
                        readBit [3] = upload2[counter1+3];
                        
                        pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                        
                        for (int counter2 = 0; counter2 < readBit [3]; counter2++){
                            revisedMap [yDimensionCount][xDimensionCount] = pixData;
                            revisedWorkingMap [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                        }
                        
                        if (xDimensionCount == imageDimension){
                            xDimensionCount = 0;
                            yDimensionCount++;
                            
                            if (yDimensionCount == imageDimension){
                                break;
                            }
                        }
                    }
                    
                    delete [] upload2;
                }
            }
        }
        
        //for (int counterA = 250; counterA < 300; counterA++){
        //	for (int counterB = 1500; counterB < 1520; counterB++) cout<<" "<<revisedMap [counterA][counterB];
        //	cout<<" revisedMap "<<counterA<<endl;
        //}
        
        //for (int counterA = 250; counterA < 300; counterA++){
        //	for (int counterB = 1500; counterB < 1520; counterB++) cout<<" "<<revisedWorkingMap [counterA][counterB];
        //	cout<<" revisedWorkingMap "<<counterA<<endl;
        //}
        
        fluorescentDetection = 0;
        
        if (fluorescentMapStatus1 == 0){
            fluorescentMap1 = new int *[imageDimension+1];
            fluorescentMapStatus1 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap1 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus2 == 0){
            fluorescentMap2 = new int *[imageDimension+1];
            fluorescentMapStatus2 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap2 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus3 == 0){
            fluorescentMap3 = new int *[imageDimension+1];
            fluorescentMapStatus3 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap3 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus4 == 0){
            fluorescentMap4 = new int *[imageDimension+1];
            fluorescentMapStatus4 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap4 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus5 == 0){
            fluorescentMap5 = new int *[imageDimension+1];
            fluorescentMapStatus5 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap5 [counter1] = new int [imageDimension+1];
        }
        
        if (fluorescentMapStatus6 == 0){
            fluorescentMap6 = new int *[imageDimension+1];
            fluorescentMapStatus6 = 1;
            for (int counter1 = 0; counter1 < imageDimension+1; counter1++) fluorescentMap6 [counter1] = new int [imageDimension+1];
        }
        
        fluorescentMapFind1 = 0;
        fluorescentMapFind2 = 0;
        fluorescentMapFind3 = 0;
        fluorescentMapFind4 = 0;
        fluorescentMapFind5 = 0;
        fluorescentMapFind6 = 0;
        
        if (fluorescentEntryCount >= 1){
            extension2 = to_string(fluorescentNo1);
            
            string fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exTypeIF+fluorescentRoundNo;
            
            if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap1 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 2){
            extension2 = to_string(fluorescentNo2);
            
            string fluorescentProcessPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exTypeIF+fluorescentRoundNo;
            
            if (stat(fluorescentProcessPath2.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap2 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath2.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap2 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 3){
            extension2 = to_string(fluorescentNo3);
            
            string fluorescentProcessPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exTypeIF+fluorescentRoundNo;
            
            sizeForCopy = 0;
            
            if (stat(fluorescentProcessPath3.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap3 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath3.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap3 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 4){
            extension2 = to_string(fluorescentNo4);
            
            string fluorescentProcessPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exTypeIF+fluorescentRoundNo;
            
            if (stat(fluorescentProcessPath4.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap4 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath4.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap4 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 5){
            extension2 = to_string(fluorescentNo5);
            
            string fluorescentProcessPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exTypeIF+fluorescentRoundNo;
            
            if (stat(fluorescentProcessPath5.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap5 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath5.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap5 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentEntryCount >= 6){
            extension2 = to_string(fluorescentNo6);
            
            string fluorescentProcessPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exTypeIF+fluorescentRoundNo;
            
            if (stat(fluorescentProcessPath6.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                fluorescentDetection = 1;
                
                if (exType == ".tif" || exTypeIF == ".TIF"){
                    int dataConversion [4];
                    int endianType = 0;
                    int imageWidthEntry = 0;
                    int value0 = 0;
                    int value1 = 0;
                    int value2 = 0;
                    int imageDimensionReadCount = 0;
                    
                    unsigned long headPosition = 0;
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        dataConversion [0] = uploadTemp [0];
                        dataConversion [1] = uploadTemp [1];
                        
                        if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                        else endianType = 0;
                        
                        headPosition = 0;
                        
                        if (endianType == 1){
                            dataConversion [0] = uploadTemp [7];
                            dataConversion [1] = uploadTemp [6];
                            dataConversion [2] = uploadTemp [5];
                            dataConversion [3] = uploadTemp [4];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        else if (endianType == 0){
                            dataConversion [0] = uploadTemp [4];
                            dataConversion [1] = uploadTemp [5];
                            dataConversion [2] = uploadTemp [6];
                            dataConversion [3] = uploadTemp [7];
                            headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                        }
                        
                        imageDimensionReadCount = 0;
                        imageWidthEntry = 0;
                        
                        if (tifImageColorGray == 0){
                            for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                        else if (tifImageColorGray == 1){
                            for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                value0 = uploadTemp [counter3];
                                value1 = uploadTemp [counter3+1];
                                value2 = uploadTemp [counter3+2];
                                
                                fluorescentMap6 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                
                                if (imageWidthEntry == imageDimension){
                                    imageWidthEntry = 0;
                                    imageDimensionReadCount++;
                                }
                            }
                        }
                    }
                    
                    delete [] uploadTemp;
                }
                else if (exType == ".bmp" || exTypeIF == ".BMP"){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.open(fluorescentProcessPath6.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        int imageDimensionReadCount = 0;
                        
                        for (int counter1 = imageDimension-1; counter1 >= 0; counter1--){
                            for (int counter2 = 0; counter2 < imageDimension; counter2++){
                                fluorescentMap6 [imageDimensionReadCount][counter2] = uploadTemp [1078+counter1*imageDimension+counter2];
                            }
                            
                            imageDimensionReadCount++;
                        }
                    }
                    
                    delete [] uploadTemp;
                }
            }
        }
        
        if (fluorescentDetection == 1){
            string expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
            string expandDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendLineDataTemp";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(expandDataTempPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                else if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (expandFluorescentOutlineStatus == 1) delete [] expandFluorescentOutline;
            
            if (stat(expandDataTempPath.c_str(), &sizeOfFile) == -1 && stat(expandDataPath.c_str(), &sizeOfFile) == -1 && checkFlag == 0){
                expandFluorescentOutline = new int [10000];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = 10000;
                expandFluorescentOutlineStatus = 1;
            }
            else if (checkFlag == 1){
                expandFluorescentOutline = new int [sizeForCopy+50];
                expandFluorescentOutlineCount = 0;
                expandFluorescentOutlineLimit = (int)sizeForCopy+50;
                expandFluorescentOutlineStatus = 1;
                
                fin.open(expandDataTempPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    int finData [8];
                    
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                else{
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        int finData [8];
                        
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    readingError = 1;
                                }
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            unsigned long readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++;
                                    finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                    finData [2] = uploadTemp [readPosition], readPosition++;
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++;
                                    finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                    
                                    finData [1] = finData [0]*256+finData [1];
                                    finData [3] = finData [2]*256+finData [3];
                                    finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                    
                                    if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                    else{
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [3], expandFluorescentOutlineCount++;
                                        
                                        if (finData [6] == ifConnectNoUpDate){
                                            expandFluorescentOutline [expandFluorescentOutlineCount] = ifConnectNoCurrent, expandFluorescentOutlineCount++;
                                        }
                                        else expandFluorescentOutline [expandFluorescentOutlineCount] = finData [6], expandFluorescentOutlineCount++;
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = finData [7], expandFluorescentOutlineCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentOutline [counterA*4+counterB];
            //    cout<<"  expandFluorescentOutline "<<counterA<<endl;
            //}
            
            expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
            expandDataTempPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Treat/"+cellLineageNoHold+"/"+cellNoHold+"/"+extension+"_ExtendAreaDataTemp";
            
            sizeForCopy = 0;
            
            if (stat(expandDataTempPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            else if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            if (expandFluorescentDataStatus == 1) delete [] expandFluorescentData;
            
            if (sizeForCopy == 0){
                expandFluorescentData = new int [10000];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = 10000;
                expandFluorescentDataStatus = 1;
            }
            else{
                
                expandFluorescentData = new int [sizeForCopy+50];
                expandFluorescentDataCount = 0;
                expandFluorescentDataLimit = (int)sizeForCopy+50;
                expandFluorescentDataStatus = 1;
                
                fin.open(expandDataTempPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [8];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                            
                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                            else{
                                
                                expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                else{
                    
                    fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        fin.close();
                        
                        unsigned long readPosition = 0;
                        int stepCount = 0;
                        int finData [8];
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                else{
                                    
                                    if (finData [2] == ifConnectNoUpDate){
                                        expandFluorescentData [expandFluorescentDataCount] = ifConnectNoCurrent, expandFluorescentDataCount++;
                                    }
                                    else expandFluorescentData [expandFluorescentDataCount] = finData [2], expandFluorescentDataCount++;
                                    
                                    expandFluorescentData [expandFluorescentDataCount] = finData [3], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [4], expandFluorescentDataCount++;
                                    expandFluorescentData [expandFluorescentDataCount] = finData [7], expandFluorescentDataCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                        
                        delete [] uploadTemp;
                    }
                    else expandFluorescentDataCount = 0;
                }
            }
            
            //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
            //    cout<<" expandFluorescentData "<<counterA<<endl;
            //}
            
            if (trackingOn == 3 && trackingLowerLimit <= imageNumberTrackForDisplay && trackingUpperLimit >= imageNumberTrackForDisplay){
                int connectNoTemp = 0;
                
                for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                    if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                        connectNoTemp = arrayConnectLineageRel [counter1*6+1];
                        break;
                    }
                }
                
                if (connectNoTemp != 0){
                    int startPosition = 0;
                    
                    for (int counter1 = 0; counter1 < timeSelectedCount/10; counter1++){
                        if (connectNoTemp == arrayTimeSelected [counter1*10+8]){
                            startPosition = arrayTimeSelected [counter1*10+2];
                        }
                    }
                    
                    int lineDataFind = 0;
                    
                    //for (int counterA = 0; counterA < expandFluorescentOutlineCount/4; counterA++){
                    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentOutline [counterA*4+counterB];
                    //    cout<<"  expandFluorescentOutline "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < expandFluorescentOutlineCount/4; counter1++){
                        if (expandFluorescentOutline [counter1*4+2] == connectNoTemp){
                            lineDataFind = 1;
                            break;
                        }
                    }
                    
                    if (lineDataFind == 0){
                        int returnResults = 0;
                        
                        if (autoExpand == 1){
                            expandLine = [[ExpandLine alloc] init];
                            returnResults = [expandLine lineExtendTrackType2:connectNoTemp];
                        }
                        
                        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
                        //    cout<<" expandFluorescentData "<<counterA<<endl;
                        //}
                        
                        if (autoExpand == 0 || (autoExpand == 1 && returnResults == 1)){
                            for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                    if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                    expandFluorescentOutline [expandFluorescentOutlineCount] = 7, expandFluorescentOutlineCount++;
                                }
                                else{
                                    
                                    break;
                                }
                            }
                            
                            if (fluorescentEntryCount >= 2){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 8, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 9, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 10, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 11, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                for (int counter1 = startPosition; counter1 < positionReviseCount/7; counter1++){
                                    if (arrayPositionRevise [counter1*7+3] == connectNoTemp){
                                        if (expandFluorescentOutlineCount+20 > expandFluorescentOutlineLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate expandFluorescentOutlineUpDate];
                                        }
                                        
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = arrayPositionRevise [counter1*7+1], expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = connectNoTemp, expandFluorescentOutlineCount++;
                                        expandFluorescentOutline [expandFluorescentOutlineCount] = 12, expandFluorescentOutlineCount++;
                                    }
                                    else{
                                        
                                        break;
                                    }
                                }
                            }
                            
                            int pixelValueTemp = 0;
                            int pixelAreaTemp = 0;
                            int pixelValueTemp2 = 0;
                            int pixelAreaTemp2 = 0;
                            int pixelValueTemp3 = 0;
                            int pixelAreaTemp3 = 0;
                            int pixelValueTemp4 = 0;
                            int pixelAreaTemp4 = 0;
                            int pixelValueTemp5 = 0;
                            int pixelAreaTemp5 = 0;
                            int pixelValueTemp6 = 0;
                            int pixelAreaTemp6 = 0;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (revisedWorkingMap [counterY][counterX] == connectNoTemp){
                                        if (fluorescentEntryCount >= 1){
                                            if (fluorescentCutOff1 >= fluorescentMap1 [counterY][counterX]) pixelValueTemp = pixelValueTemp+fluorescentMap1 [counterY][counterX];
                                            pixelAreaTemp++;
                                        }
                                        if (fluorescentEntryCount >= 2){
                                            if (fluorescentCutOff2 >= fluorescentMap2 [counterY][counterX]) pixelValueTemp2 = pixelValueTemp2+fluorescentMap2 [counterY][counterX];
                                            pixelAreaTemp2++;
                                        }
                                        if (fluorescentEntryCount >= 3){
                                            if (fluorescentCutOff3 >= fluorescentMap3 [counterY][counterX]) pixelValueTemp3 = pixelValueTemp3+fluorescentMap3 [counterY][counterX];
                                            pixelAreaTemp3++;
                                        }
                                        if (fluorescentEntryCount >= 4){
                                            if (fluorescentCutOff4 >= fluorescentMap4 [counterY][counterX]) pixelValueTemp4 = pixelValueTemp4+fluorescentMap4 [counterY][counterX];
                                            pixelAreaTemp4++;
                                        }
                                        if (fluorescentEntryCount >= 5){
                                            if (fluorescentCutOff5 >= fluorescentMap5 [counterY][counterX]) pixelValueTemp5 = pixelValueTemp5+fluorescentMap5 [counterY][counterX];
                                            pixelAreaTemp5++;
                                        }
                                        if (fluorescentEntryCount >= 6){
                                            if (fluorescentCutOff6 >= fluorescentMap6 [counterY][counterX]) pixelValueTemp6 = pixelValueTemp6+fluorescentMap6 [counterY][counterX];
                                            pixelAreaTemp6++;
                                        }
                                    }
                                }
                            }
                            
                            double averageArea = pixelValueTemp/(double)pixelAreaTemp;
                            
                            if (expandFluorescentDataCount+20 > expandFluorescentDataLimit){
                                fileUpdate = [[FileUpdate alloc] init];
                                [fileUpdate expandFluorescentDataUpDate];
                            }
                            
                            expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = 7, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                            expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp, expandFluorescentDataCount++;
                            
                            if (fluorescentEntryCount >= 2){
                                averageArea = pixelValueTemp2/(double)pixelAreaTemp2;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 8, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp2, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 3){
                                averageArea = pixelValueTemp3/(double)pixelAreaTemp3;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 9, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp3, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 4){
                                averageArea = pixelValueTemp4/(double)pixelAreaTemp4;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 10, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp4, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 5){
                                averageArea = pixelValueTemp5/(double)pixelAreaTemp5;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 11, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp5, expandFluorescentDataCount++;
                            }
                            
                            if (fluorescentEntryCount >= 6){
                                averageArea = pixelValueTemp6/(double)pixelAreaTemp6;
                                
                                expandFluorescentData [expandFluorescentDataCount] = connectNoTemp, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = 12, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = (int)averageArea, expandFluorescentDataCount++;
                                expandFluorescentData [expandFluorescentDataCount] = pixelAreaTemp6, expandFluorescentDataCount++;
                            }
                        }
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
        //    cout<<" expandFluorescentData "<<counterA<<endl;
        //}
        
        if (upLoadCheck == 1){
            trackingOn = 6;
            tableTrackingProcessing = 0;
        }
        else{
            
            cellLineageExtract = cellLineageNoHold.substr(1);
            
            for (int counter1 = 0; counter1 < connectLineageRelCount/6; counter1++){
                if (arrayConnectLineageRel [counter1*6] == lineageAmendTemp && arrayConnectLineageRel [counter1*6+3] == cellAmendTemp){
                    arrayConnectLineageRel [counter1*6+4] = 1;
                    break;
                }
            }
            
            tableTrackingProcessing = 1;
        }
    }
    
    //for (int counterA = 0; counterA < expandFluorescentDataCount/4; counterA++){
    //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentData [counterA*4+counterB];
    //    cout<<" expandFluorescentData "<<counterA<<endl;
    //}
    
    return upLoadCheck;
}

@end
