//
//  DatabaseRepairImport.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-29.
//

#import "DatabaseRepairImport.h"

@implementation DatabaseRepairImport

-(IBAction)lineageImport:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)directoryPath.find("%20");
                
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            findString1 = (int)extractedID.find(analysisID+"_"+arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9]+"_LineageData");
            
            if (findString1 != -1){
                ifstream fin;
                
                int finData [29];
                
                struct stat sizeOfFile;
                long sizeForCopy = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                int readingError = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(directoryPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 1){
                    //-----Lineage data upload-----
                    int *arrayLineageRepairDataTemp = new int [sizeForCopy+50];
                    int lineageDataRepairTempCount = 0;
                    
                    int *arrayLineageRepairDataTemp2 = new int [sizeForCopy+50];
                    int lineageDataRepairTempCount2 = 0;
                    
                    fin.open(directoryPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                                readingError = 1;
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            int readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++;
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++;
                                    finData [17] = uploadTemp [readPosition], readPosition++;
                                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                    finData [19] = uploadTemp [readPosition], readPosition++;
                                    finData [20] = uploadTemp [readPosition], readPosition++;
                                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                    finData [22] = uploadTemp [readPosition], readPosition++;
                                    finData [23] = uploadTemp [readPosition], readPosition++;
                                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                    
                                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                    else finData [2] = finData [1]*256+finData [2];
                                    
                                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                    else finData [5] = finData [4]*256+finData [5];
                                    
                                    finData [7] = finData [6]*256+finData [7];
                                    
                                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                    
                                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                    
                                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                    
                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [2], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [5], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [7], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [8], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [13], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [18], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [21], lineageDataRepairTempCount++;
                                        arrayLineageRepairDataTemp [lineageDataRepairTempCount] = finData [24], lineageDataRepairTempCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                        
                        //for (int counterA = 0; counterA < lineageDataRepairTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairDataTemp [counterA*8+counterB];
                        //    cout<<" arrayLineageRepairDataTemp "<<counterA<<endl;
                        //}
                        
                        int lineageNoList = [lingNoSetDisplay integerValue];
                        
                        NSString *lingNoNSString = [lingNoSetDisplay stringValue];
                        
                        if ([lingNoNSString isEqualToString:@""] || readingError == 1){
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        else{
                            
                            int matchFind = 0;
                            
                            for (int counter1 = 0; counter1 < lineageDataRepairTempCount/8; counter1++){
                                if (arrayLineageRepairDataTemp [counter1*8+6] == lineageNoList){
                                    matchFind = 1;
                                    break;
                                }
                            }
                            
                            if (matchFind == 1){
                                for (int counter1 = 0; counter1 < lineageDataRepairTempCount/8; counter1++){
                                    if (arrayLineageRepairDataTemp [counter1*8+6] == lineageNoList){
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+1], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+2], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+3], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+4], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+5], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+6], lineageDataRepairTempCount2++;
                                        arrayLineageRepairDataTemp2 [lineageDataRepairTempCount2] = arrayLineageRepairDataTemp [counter1*8+7], lineageDataRepairTempCount2++;
                                    }
                                }
                                
                                lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9]+"_Connect/"+ analysisID+"_"+arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9]+"_LineageData";
                                
                                size1 = 0;
                                size2 = 0;
                                checkFlag = 0;
                                
                                for (int counter1 = 0; counter1 < 6; counter1++){
                                    sizeForCopy = 0;
                                    
                                    if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                    }
                                    
                                    if (sizeForCopy != 0){
                                        if (counter1 == 0) size1 = sizeForCopy;
                                        else if (counter1 == 1) size2 = sizeForCopy;
                                        else if (counter1 == 2){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                                break;
                                            }
                                            else{
                                                
                                                size1 = 0;
                                                size2 = 0;
                                                usleep (50000);
                                            }
                                        }
                                        else if (counter1 == 3) size1 = sizeForCopy;
                                        else if (counter1 == 4) size2 = sizeForCopy;
                                        else if (counter1 == 5){
                                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                                checkFlag = 1;
                                            }
                                        }
                                    }
                                }
                                
                                //-----Lineage data upload-----
                                arrayLineageRepairData = new int [sizeForCopy+50+lineageDataRepairTempCount2];
                                lineageDataRepairCount = 0;
                                
                                int returnValue2 = 0;
                                
                                if (checkFlag == 1){
                                    int processType2 = -1;
                                    
                                    dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                    returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
                                }
                                
                                //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
                                //    cout<<" arrayLineageRepairData "<<counterA<<endl;
                                //}
                                
                                if (returnValue2 == 0){
                                    int *arrayLineageRepairDataTemp3 = new int [sizeForCopy+50+lineageDataRepairTempCount2];
                                    int lineageDataRepairTempCount3 = 0;
                                    
                                    for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
                                        if (arrayLineageRepairData [counter1*8+6] != lineageNoList){
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+1], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+2], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+3], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+4], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+5], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+6], lineageDataRepairTempCount3++;
                                            arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairData [counter1*8+7], lineageDataRepairTempCount3++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < lineageDataRepairTempCount3/8; counterA++){
                                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairDataTemp3 [counterA*8+counterB];
                                    //    cout<<" arrayLineageRepairDataTemp3 "<<counterA<<endl;
                                    //}
                                    
                                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount2/8; counter1++){
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+1], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+2], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+3], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+4], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+5], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+6], lineageDataRepairTempCount3++;
                                        arrayLineageRepairDataTemp3 [lineageDataRepairTempCount3] = arrayLineageRepairDataTemp2 [counter1*8+7], lineageDataRepairTempCount3++;
                                    }
                                    
                                    lineageDataRepairCount = 0;
                                    
                                    for (int counter1 = 0; counter1 < lineageDataRepairTempCount3; counter1++) arrayLineageRepairData [lineageDataRepairCount] = arrayLineageRepairDataTemp3 [counter1], lineageDataRepairCount++;
                                    
                                    dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                    [dataRepairReadWrite lineageDataSave];
                                    
                                    delete [] arrayLineageRepairDataTemp3;
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Lineage File Read Error"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                delete [] arrayLineageRepairData;
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"No Lineage Match"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                    
                    delete [] arrayLineageRepairDataTemp;
                    delete [] arrayLineageRepairDataTemp2;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Lineage File Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Lineage File or Unrelated File"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageImportAll:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)directoryPath.find("%20");
                
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            findString1 = (int)extractedID.find(analysisID+"_"+arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9]+"_LineageData");
            
            if (findString1 != -1){
                ifstream fin;
                
                int finData [29];
                
                struct stat sizeOfFile;
                long sizeForCopy = 0;
                long size1 = 0;
                long size2 = 0;
                int checkFlag = 0;
                int readingError = 0;
                
                for (int counter1 = 0; counter1 < 6; counter1++){
                    sizeForCopy = 0;
                    
                    if (stat(directoryPath.c_str(), &sizeOfFile) == 0){
                        sizeForCopy = sizeOfFile.st_size;
                    }
                    
                    if (sizeForCopy != 0){
                        if (counter1 == 0) size1 = sizeForCopy;
                        else if (counter1 == 1) size2 = sizeForCopy;
                        else if (counter1 == 2){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                                break;
                            }
                            else{
                                
                                size1 = 0;
                                size2 = 0;
                                usleep (50000);
                            }
                        }
                        else if (counter1 == 3) size1 = sizeForCopy;
                        else if (counter1 == 4) size2 = sizeForCopy;
                        else if (counter1 == 5){
                            if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                checkFlag = 1;
                            }
                        }
                    }
                }
                
                if (checkFlag == 1){
                    //-----Lineage data upload-----
                    arrayLineageRepairData = new int [sizeForCopy+50];
                    lineageDataRepairCount = 0;
                    
                    fin.open(directoryPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0 || (finData [0] = uploadTemp [sizeForCopy-13]) != 0 || (finData [0] = uploadTemp [sizeForCopy-14]) != 0 || (finData [0] = uploadTemp [sizeForCopy-15]) != 0 || (finData [0] = uploadTemp [sizeForCopy-16]) != 0 || (finData [0] = uploadTemp [sizeForCopy-17]) != 0 || (finData [0] = uploadTemp [sizeForCopy-18]) != 0 || (finData [0] = uploadTemp [sizeForCopy-19]) != 0 || (finData [0] = uploadTemp [sizeForCopy-20]) != 0){
                                readingError = 1;
                            }
                        }
                        
                        fin.close();
                        
                        if (readingError == 0){
                            
                            int readPosition = 0;
                            int stepCount = 0;
                            
                            do{
                                
                                if (stepCount == 0){
                                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                    finData [12] = uploadTemp [readPosition], readPosition++;
                                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                    finData [16] = uploadTemp [readPosition], readPosition++;
                                    finData [17] = uploadTemp [readPosition], readPosition++;
                                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                    finData [19] = uploadTemp [readPosition], readPosition++;
                                    finData [20] = uploadTemp [readPosition], readPosition++;
                                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                    finData [22] = uploadTemp [readPosition], readPosition++;
                                    finData [23] = uploadTemp [readPosition], readPosition++;
                                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Lineage no Fuse
                                    
                                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                    else finData [2] = finData [1]*256+finData [2];
                                    
                                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                    else finData [5] = finData [4]*256+finData [5];
                                    
                                    finData [7] = finData [6]*256+finData [7];
                                    
                                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                    
                                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                    
                                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                    
                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                    else{
                                        
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [2], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [5], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [7], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [8], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [13], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [18], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [21], lineageDataRepairCount++;
                                        arrayLineageRepairData [lineageDataRepairCount] = finData [24], lineageDataRepairCount++;
                                    }
                                }
                                
                            } while (stepCount != 3);
                        }
                        
                        delete [] uploadTemp;
                        
                        //for (int counterA = 0; counterA < lineageDataRepairTempCount/8; counterA++){
                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairDataTemp [counterA*8+counterB];
                        //    cout<<" arrayLineageRepairDataTemp "<<counterA<<endl;
                        //}
                        
                        if (readingError == 0){
                            lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9]+"_Connect/"+ analysisID+"_"+arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9]+"_LineageData";
                            
                            dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                            [dataRepairReadWrite lineageDataSave];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Lineage File Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    
                    delete [] arrayLineageRepairData;
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Lineage File Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Lineage Match"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)mapImport:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                findString1 = (int)directoryPath.find("%20");
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            if ((int)extractedID.find ("RevisedMap~") != -1){
                string mapNameStringRep = extractedID.substr(0, extractedID.find ("~"));
                nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
                string mapNamePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+mapNameStringRep;
                
                ifstream fin;
                
                fin.open(mapNamePath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    fin.close();
                    
                    int imageSize = 0;
                    int yDimensionCount = 0;
                    int xDimensionCount = 0;
                    int readBit [4];
                    int pixData = 0;
                    int totalSize = 0;
                    
                    for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                        if (arrayImageSizeList [counter2*2] == nameStringRep){
                            imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                            break;
                        }
                    }
                    
                    int **revisedMapVer = new int *[imageSize+1];
                    
                    for (int counter2 = 0; counter2 < imageSize+1; counter2++){
                        revisedMapVer [counter2] = new int [imageSize+1];
                    }
                    
                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                            revisedMapVer [counter3][counter4] = 0;
                        }
                    }
                    
                    fin.open(directoryPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        uint8_t *upload2 = new uint8_t [totalSize+50];
                        fin.read((char*)upload2, totalSize+1);
                        fin.close();
                        
                        yDimensionCount = 0;
                        xDimensionCount = 0;
                        
                        for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                            readBit [0] = upload2[counter3];
                            readBit [1] = upload2[counter3+1];
                            readBit [2] = upload2[counter3+2];
                            readBit [3] = upload2[counter3+3];
                            
                            pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                            
                            for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                            }
                            
                            if (xDimensionCount == imageSize){
                                xDimensionCount = 0;
                                yDimensionCount++;
                                
                                if (yDimensionCount == imageSize){
                                    break;
                                }
                            }
                        }
                        
                        delete [] upload2;
                    }
                    
                    int indexCount = 0;
                    int dataTemp = 0;
                    int dataTemp2 = 0;
                    int entryCount = 0;
                    int readBit2 [4];
                    
                    char *dataHold = new char [imageSize*imageSize*4+500];
                    
                    for (int counterX = 0; counterX < imageSize; counterX++){
                        for (int counterY = 0; counterY < imageSize; counterY++){
                            dataTemp = revisedMapVer [counterX][counterY];
                            
                            if (counterY == 0) dataTemp2 = dataTemp, entryCount++;
                            else if (dataTemp != dataTemp2 || entryCount == 254 || counterY == imageSize-1){
                                readBit2 [0] = dataTemp2/65536;
                                dataTemp2 = dataTemp2%65536;
                                readBit2 [1] = dataTemp2/256;
                                dataTemp2 = dataTemp2%256;
                                readBit2 [2] = dataTemp2;
                                
                                if (counterY == imageSize-1){
                                    if (dataTemp != dataTemp2){
                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                        
                                        readBit2 [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit2 [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit2 [2] = dataTemp;
                                        
                                        entryCount = 1;
                                        
                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                    else{
                                        
                                        entryCount++;
                                        
                                        dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                        dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                        dataHold [indexCount] = (char)entryCount, indexCount++;
                                    }
                                }
                                else{
                                    
                                    dataHold [indexCount] = (char)readBit2 [0], indexCount++;
                                    dataHold [indexCount] = (char)readBit2 [1], indexCount++;
                                    dataHold [indexCount] = (char)readBit2 [2], indexCount++;
                                    dataHold [indexCount] = (char)entryCount, indexCount++;
                                }
                                
                                if (counterY == imageSize-1) entryCount = 0;
                                else entryCount = 1, dataTemp2 = dataTemp;
                            }
                            else entryCount++;
                        }
                    }
                    
                    ofstream outfile5 (mapNamePath.c_str(), ofstream::binary);
                    outfile5.write(dataHold, indexCount);
                    outfile5.close();
                    
                    delete [] dataHold;
                    
                    for (int counter2 = 0; counter2 < imageSize+1; counter2++){
                        delete [] revisedMapVer [counter2];
                    }
                    
                    delete [] revisedMapVer;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"No Rev Map Match"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Rev Map File"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)queueImport:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)directoryPath.find("%20");
                
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            if ((int)extractedID.find ("QueueList.dat~") != -1){
                string queueListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*QueueList.dat";
                
                struct stat sizeOfFile;
                long sizeForQueue = 0;
                
                if (stat(queueListPath.c_str(), &sizeOfFile) == 0){
                    sizeForQueue = sizeOfFile.st_size;
                }
                
                string *queueListVer = new string [sizeForQueue+500];
                int queueListVerCount = 0;
                
                string dataString;
                
                ifstream fin;
                
                if (sizeForQueue != 0){
                    fin.open(queueListPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTempChar = new char [sizeForQueue];
                        
                        fin.read((char*)uploadTempChar, sizeForQueue);
                        fin.close();
                        
                        dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTempChar [readPosition] != 10) dataString = dataString+uploadTempChar [readPosition];
                            else if (dataString != "End"){
                                queueListVer [queueListVerCount] = dataString, queueListVerCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTempChar;
                    }
                    
                    if (queueListVerCount != 0){
                        string extension2;
                        
                        char *mainDataEntry = new char [queueListVerCount*12+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < queueListVerCount; counter1++){
                            extension2 = queueListVer [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile2 (queueListPath.c_str(), ofstream::binary);
                        outfile2.write (mainDataEntry, totalEntryCount);
                        outfile2.close();
                        
                        delete [] mainDataEntry;
                    }
                }
                
                delete [] queueListVer;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Queue List Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)doneImport:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            string extractedID;
            string extractedID2;
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)directoryPath.find("%20");
                
                if (findString1 != -1){
                    extractedID2 = directoryPath.substr(0, (unsigned long)findString1);
                    directoryPath = directoryPath.substr((unsigned long)findString1+3);
                    directoryPath = extractedID2+" "+directoryPath;
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            extractedID = directoryPath;
            
            string stringExtract;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1){
                    stringExtract = extractedID.substr(0, (unsigned long)findString1);
                    extractedID = extractedID.substr((unsigned long)findString1+1);
                }
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            if ((int)extractedID.find ("DoneList.dat~") != -1){
                string doneListPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/*DoneList.dat";
                
                struct stat sizeOfFile;
                long sizeForDone = 0;
                
                if (stat(doneListPath.c_str(), &sizeOfFile) == 0){
                    sizeForDone = sizeOfFile.st_size;
                }
                
                string *doneListVer = new string [sizeForDone+500];
                int doneListVerCount = 0;
                
                string dataString;
                
                ifstream fin;
                
                if (sizeForDone != 0){
                    fin.open(doneListPath.c_str(), ios::in | ios::binary);
                    
                    if (fin.is_open()){
                        char *uploadTempChar = new char [sizeForDone];
                        
                        fin.read((char*)uploadTempChar, sizeForDone);
                        fin.close();
                        
                        dataString = "";
                        int readPosition = 0;
                        
                        do{
                            
                            if (uploadTempChar [readPosition] != 10) dataString = dataString+uploadTempChar [readPosition];
                            else if (dataString != "End"){
                                doneListVer [doneListVerCount] = dataString, doneListVerCount++;
                                dataString = "";
                            }
                            
                            readPosition++;
                            
                        } while (dataString != "End");
                        
                        delete [] uploadTempChar;
                    }
                    
                    if (doneListVerCount != 0){
                        string extension2;
                        
                        char *mainDataEntry = new char [doneListVerCount*12+10];
                        int totalEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < doneListVerCount; counter1++){
                            extension2 = doneListVer [counter1];
                            
                            for (int counter2 = 0; counter2 < (int)extension2.length(); counter2++){
                                mainDataEntry [totalEntryCount] = (char)extension2.at((unsigned long)counter2), totalEntryCount++;
                            }
                            
                            mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        }
                        
                        mainDataEntry [totalEntryCount] = 'E', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'n', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 'd', totalEntryCount++;
                        mainDataEntry [totalEntryCount] = 0x0a, totalEntryCount++;
                        
                        ofstream outfile2 (doneListPath.c_str(), ofstream::binary);
                        outfile2.write (mainDataEntry, totalEntryCount);
                        outfile2.close();
                        
                        delete [] mainDataEntry;
                    }
                }
                
                delete [] doneListVer;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Queue List Missing"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
