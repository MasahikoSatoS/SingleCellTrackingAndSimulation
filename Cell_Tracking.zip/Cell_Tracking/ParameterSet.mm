//
//  ParameterSet.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2016-02-18.
//
//

#import "ParameterSet.h"

NSString *notificationToParameterSet = @"notificationExecuteParameterSet";

@implementation ParameterSet

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToParameterSet object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    parameterSetWindowController = [[NSWindowController alloc] initWithWindowNibName:@"ParameterDataSet"];
    [parameterSetWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToParameterSetOperations object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [parameterSetWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [parameterSetWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [sdIntervalDisplay setDoubleValue: mitosisSDHold];
    [valueIntervalDisplay setIntValue:mitosisValueHold];
    [distanceIntervalDisplay setIntValue:divisionDistanceHold];
    [areaDisplay setDoubleValue: mitosisAreaHold];
    [relativeLowDisplay setDoubleValue:mitosisRelativeLowHold];
    [relativeHighDisplay setDoubleValue:mitosisRelativeHighHold];
    [overlapPercent setDoubleValue:percentOverlap];
    [autoCheckDistanceDisplay setIntValue:autoCheckDistanceHold];
    [autoCheckAreaDisplay setIntValue:autoCheckAreaHold];
    [autoCheckDivisionDisplay setIntValue:autoCheckDivisionHold];
    [autoCheckDistanceFoldDisplay setIntValue:autoCheckDistanceFoldHold];
    [autoCheckIntensityDisplay setIntValue:autoCheckIntensityHold];
    [optionalSearchPercentDisplay setIntValue:optionalShiftPercent];
    
    [stepperSDInterval setIntValue:(int)mitosisSDHold*1000];
    [stepperValueInterval setIntValue:mitosisValueHold];
    [stepperDistanceInterval setIntValue:divisionDistanceHold];
    [stepperArea setIntValue:mitosisAreaHold];
    [stepperRelativeLow setIntValue:(int)mitosisRelativeLowHold*100];
    [stepperRelativeHigh setIntValue:(int)mitosisRelativeHighHold*100];
    [stepperOverlap setIntValue:(int)percentOverlap*100];
    [stepperAutoCheckDistance setIntValue:autoCheckDistanceHold];
    [stepperAutoCheckArea setIntValue:autoCheckAreaHold];
    [stepperAutoCheckDivision setIntValue:autoCheckDivisionHold];
    [stepperAutoCheckDistanceFold setIntValue:autoCheckDistanceFoldHold];
    [stepperAutoCheckIntensity setIntValue:autoCheckIntensityHold];
    [stepperOptionalSearchPercent setIntValue:optionalShiftPercent];
    
    [sdIntervalDisplay setDelegate:self];
    [valueIntervalDisplay setDelegate:self];
    [distanceIntervalDisplay setDelegate:self];
    [areaDisplay setDelegate:self];
    [relativeHighDisplay setDelegate:self];
    [relativeLowDisplay setDelegate:self];
    [overlapPercent setDelegate:self];
    
    displayMode = 0;
    
    [firstColDisplay setStringValue:@"No."];
    [secondColDisplay setStringValue:@"SD"];
    [thirdColDisplay setStringValue:@"Value"];
    [typeDisplay setStringValue:@"SD and Value"];
    
    if (jumpAllFlag == 0) [jumpAllowDisplay setStringValue:@"Off"];
    else [jumpAllowDisplay setStringValue:@"On"];
    
    if (connectExpandFlag == 0) [expandAllowDisplay setStringValue:@"Off"];
    else if (connectExpandFlag == 1) [expandAllowDisplay setStringValue:@"First"];
    else if (connectExpandFlag == 2) [expandAllowDisplay setStringValue:@"First+Second"];
    
    if (mapMergeStatus == 0) [mapMergeDisplay setStringValue:@"Off"];
    else if (mapMergeStatus == 1) [mapMergeDisplay setStringValue:@"On"];
    
    if (gravityCenterMoveLimitFlag == 0) [cgCenterDisplay setStringValue:@"Off"];
    else if (gravityCenterMoveLimitFlag == 1) [cgCenterDisplay setStringValue:@"On"];
    
    if (mitosisOffFlag == 0) [mitosisOnOffDisplay setStringValue:@"On"];
    else if (mitosisOffFlag == 1) [mitosisOnOffDisplay setStringValue:@"Off"];
    
    if (fusionMarkSetFlag == 0) [fusionMarkOnOffDisplay setStringValue:@"On"];
    else if (fusionMarkSetFlag == 1) [fusionMarkOnOffDisplay setStringValue:@"Off"];
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == sdIntervalDisplay){
            if ([sdIntervalDisplay doubleValue] >= 0.001 && [sdIntervalDisplay doubleValue] <= 0.499){
                [stepperSDInterval setIntValue:(int)[sdIntervalDisplay doubleValue]*1000];
                
                mitosisSDHold = [sdIntervalDisplay doubleValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
        
        if ([aNotification object] == valueIntervalDisplay){
            if ([valueIntervalDisplay intValue] > 150 && [valueIntervalDisplay intValue] <= 255){
                [stepperValueInterval setIntValue:[valueIntervalDisplay intValue]];
                
                mitosisValueHold = [valueIntervalDisplay intValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
        
        if ([aNotification object] == distanceIntervalDisplay){
            if ([distanceIntervalDisplay intValue] >= 10 && [distanceIntervalDisplay intValue] <= 200){
                [stepperDistanceInterval setIntValue:[distanceIntervalDisplay intValue]];
                
                divisionDistanceHold = [distanceIntervalDisplay intValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
        
        if ([aNotification object] == areaDisplay){
            if ([areaDisplay intValue] >= 10 && [areaDisplay intValue] <= 100){
                [stepperArea setIntValue:[areaDisplay intValue]];
                
                mitosisAreaHold = [areaDisplay intValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
        
        if ([aNotification object] == relativeLowDisplay){
            if ([relativeLowDisplay doubleValue] >= 0.1 && [relativeLowDisplay doubleValue] <= 0.9){
                [stepperRelativeLow setIntValue:(int)[relativeLowDisplay doubleValue]*100];
                
                mitosisRelativeLowHold = [relativeLowDisplay doubleValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
        
        if ([aNotification object] == relativeHighDisplay){
            if ([relativeHighDisplay doubleValue] >= 1.1 && [relativeHighDisplay doubleValue] <= 5.0){
                [stepperRelativeHigh setIntValue:(int)[relativeHighDisplay doubleValue]*100];
                
                mitosisRelativeHighHold = [relativeHighDisplay doubleValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
        
        if ([aNotification object] == overlapPercent){
            if ([overlapPercent intValue] >= 0 && [overlapPercent intValue] <= 100){
                [stepperOverlap setIntValue:[overlapPercent intValue]];
                
                percentOverlap = [overlapPercent intValue];
                
                dataSaveRead = [[DataSaveRead alloc] init];
                [dataSaveRead saveParameters];
            }
        }
    }
}

-(IBAction)stepperActionSDInterval:(id)sender{
    NSString* setSDValue = [NSString stringWithFormat:@"%.02f", [stepperSDInterval intValue]/(double)1000];
    [sdIntervalDisplay setObjectValue: setSDValue];
    mitosisSDHold = [stepperSDInterval intValue]/(double)1000;
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperActionValueInterval:(id)sender{
    [valueIntervalDisplay setIntValue: [stepperValueInterval intValue]];
    mitosisValueHold = [stepperValueInterval intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperActionDistanceInterval:(id)sender{
    [distanceIntervalDisplay setIntValue: [stepperDistanceInterval intValue]];
    divisionDistanceHold = [stepperDistanceInterval intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperActionArea:(id)sender{
    [areaDisplay setIntValue: [stepperArea intValue]];
    mitosisAreaHold = [stepperArea intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperActionRelativeLow:(id)sender{
    NSString* setRelativeLowValue = [NSString stringWithFormat:@"%.02f", [stepperRelativeLow intValue]/(double)100];
    [relativeLowDisplay setObjectValue: setRelativeLowValue];
    mitosisRelativeLowHold = [stepperRelativeLow intValue]/(double)100;
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperActionRelativeHigh:(id)sender{
    NSString* setRelativeHighValue = [NSString stringWithFormat:@"%.02f", [stepperRelativeHigh intValue]/(double)100];
    [relativeHighDisplay setObjectValue: setRelativeHighValue];
    mitosisRelativeHighHold = [stepperRelativeHigh intValue]/(double)100;
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperActionOverlap:(id)sender{
    [areaDisplay setIntValue: [stepperArea intValue]];
    mitosisAreaHold = [stepperArea intValue];
    
    [overlapPercent setIntValue: [stepperOverlap intValue]];
    percentOverlap = [stepperOverlap intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)switchMode:(id)sender{
    if (displayMode == 2){
        displayMode = 0;
        [firstColDisplay setStringValue:@"No."];
        [secondColDisplay setStringValue:@"SD"];
        [thirdColDisplay setStringValue:@"Value"];
        [typeDisplay setStringValue:@"SD and Value"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToParameterSetOperations object:self];
    }
    else if (displayMode == 0){
        displayMode = 1;
        
        forAreaSizeCount = 0;
        
        int lingNoTemp = 0;
        int cellNoTemp = 0;
        int cellNoPrTemp1 = 0;
        int cellNoPrTemp2 = 0;
        int numberLength = 0;
        int zeroPoint = 0;
        int digitNumber = 0;
        int checkFlag = 0;
        int positionX1 = 0;
        int positionY1 = 0;
        int positionX2 = 0;
        int positionY2 = 0;
        int imageTime = 0;
        int connectNoTemp = 0;
        int areaTemp = 0;
        int connectNoTemp2 = 0;
        int areaTemp2 = 0;
        int stepCount = 0;
        int finData [19];
        int gravityCenterRevTempCount = 0;
        int gravityCenterRevTempLimit = 0;
        int connectLineageRelTempCount = 0;
        int checkFlag2 = 0;
        int readingError = 0;
        
        double length = 0;
        
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        
        unsigned long readPosition = 0;
        
        struct stat sizeOfFile;
        
        string cellNumberExtract;
        string digitExtract;
        string extension;
        string connectDataRevPath;
        string connectRelationPath;
        
        ifstream fin;
        
        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
            if (arrayLineageData [counter1*8+2] > imageNumberTrackForDisplay && arrayLineageData [counter1*8+2] < imageNumberTrackForDisplay+100){
                if (arrayLineageData [counter1*8+3] == 32){
                    lingNoTemp = arrayLineageData [counter1*8+6];
                    cellNoTemp = arrayLineageData [counter1*8+5];
                    
                    cellNumberExtract = to_string(cellNoTemp).substr(1);
                    
                    numberLength = (int)cellNumberExtract.length();
                    zeroPoint = -1;
                    checkFlag = 0;
                    
                    if (cellNoTemp == 0) cellNoPrTemp1 = -100000000;
                    else{
                        
                        for (int counter2 = 0; counter2 < numberLength; counter2++){
                            digitExtract = cellNumberExtract.substr((unsigned long)counter2, 1);
                            
                            if (checkFlag == 0 && digitExtract == "0"){
                                zeroPoint = counter2;
                                checkFlag = 1;
                            }
                            else if (checkFlag == 1 && digitExtract != "0"){
                                zeroPoint = -1;
                                checkFlag = 0;
                            }
                        }
                        
                        digitNumber = numberLength-zeroPoint;
                        
                        if (digitNumber == 8) cellNoPrTemp1 = cellNoTemp+10000000;
                        else if (digitNumber == 7) cellNoPrTemp1 = cellNoTemp+1000000;
                        else if (digitNumber == 6) cellNoPrTemp1 = cellNoTemp+100000;
                        else if (digitNumber == 5) cellNoPrTemp1 = cellNoTemp+10000;
                        else if (digitNumber == 4) cellNoPrTemp1 = cellNoTemp+1000;
                        else if (digitNumber == 3) cellNoPrTemp1 = cellNoTemp+100;
                        else if (digitNumber == 2) cellNoPrTemp1 = cellNoTemp+10;
                        else if (digitNumber == 1) cellNoPrTemp1 = cellNoTemp+1;
                    }
                    
                    zeroPoint = -1;
                    checkFlag = 0;
                    
                    if (cellNoTemp == 0) cellNoPrTemp2 = 100000000;
                    else{
                        
                        for (int counter2 = 0; counter2 < numberLength; counter2++){
                            digitExtract = cellNumberExtract.substr((unsigned long)counter2, 1);
                            
                            if (checkFlag == 0 && digitExtract == "0"){
                                zeroPoint = counter1;
                                checkFlag = 1;
                            }
                            else if (checkFlag == 1 && digitExtract != "0"){
                                zeroPoint = -1;
                                checkFlag = 0;
                            }
                        }
                        
                        digitNumber = numberLength-zeroPoint;
                        
                        if (digitNumber == 8) cellNoPrTemp2 = cellNoTemp-10000000;
                        else if (digitNumber == 7) cellNoPrTemp2 = cellNoTemp-1000000;
                        else if (digitNumber == 6) cellNoPrTemp2 = cellNoTemp-100000;
                        else if (digitNumber == 5) cellNoPrTemp2 = cellNoTemp-10000;
                        else if (digitNumber == 4) cellNoPrTemp2 = cellNoTemp-1000;
                        else if (digitNumber == 3) cellNoPrTemp2 = cellNoTemp-100;
                        else if (digitNumber == 2) cellNoPrTemp2 = cellNoTemp-10;
                        else if (digitNumber == 1) cellNoPrTemp2 = cellNoTemp-1;
                    }
                    
                    positionX1 = 0;
                    positionY1 = 0;
                    positionX2 = 0;
                    positionY2 = 0;
                    imageTime = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                        if (arrayLineageData [counter2*8+2] > imageNumberTrackForDisplay && arrayLineageData [counter2*8+2] < imageNumberTrackForDisplay+100){
                            if (arrayLineageData [counter2*8+3] == 31 && arrayLineageData [counter2*8+6] == lingNoTemp && arrayLineageData [counter2*8+5] == cellNoPrTemp1){
                                positionX1 = arrayLineageData [counter2*8];
                                positionY1 = arrayLineageData [counter2*8+1];
                                
                                if (positionX2 != 0){
                                    imageTime = arrayLineageData [counter2*8+2];
                                    break;
                                }
                            }
                        }
                        
                        if (arrayLineageData [counter2*8+2] > imageNumberTrackForDisplay && arrayLineageData [counter2*8+2] < imageNumberTrackForDisplay+100){
                            if (arrayLineageData [counter2*8+3] == 31 && arrayLineageData [counter2*8+6] == lingNoTemp && arrayLineageData [counter2*8+5] == cellNoPrTemp2){
                                positionX2 = arrayLineageData [counter2*8];
                                positionY2 = arrayLineageData [counter2*8+1];
                                
                                if (positionX1 != 0){
                                    imageTime = arrayLineageData [counter2*8+2];
                                    break;
                                }
                            }
                        }
                    }
                    
                    length = sqrt((positionX1-positionX2)*(positionX1-positionX2)+(positionY1-positionY2)*(positionY1-positionY2));
                    
                    extension = to_string(imageTime);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag2 = 0;
                    
                    for (int counter2 = 0; counter2 < 6; counter2++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter2 == 0) size1 = sizeForCopy;
                            else if (counter2 == 1) size2 = sizeForCopy;
                            else if (counter2 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag2 = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter2 == 3) size1 = sizeForCopy;
                            else if (counter2 == 4) size2 = sizeForCopy;
                            else if (counter2 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag2 = 1;
                                }
                            }
                        }
                    }
                    
                    if (checkFlag2 == 1){
                        long sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                        
                        int *arrayGravityCenterRevTemp = new int [sizeForCopy2+50];
                        gravityCenterRevTempCount = 0;
                        gravityCenterRevTempLimit = (int)sizeForCopy2+50;
                        
                        //-----Master Data upLoad-----
                        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                        
                        readingError = 0;
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    }
                                    else if (stepCount == 1){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        finData [9] = finData [8]*256+finData [9];
                                        
                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    }
                                    else if (stepCount == 2){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                        else{
                                            
                                            if (gravityCenterRevTempCount+6 > gravityCenterRevTempLimit){
                                                int *arrayUpDate = new int [gravityCenterRevTempCount+10];
                                                
                                                for (int counter2 = 0; counter2 < gravityCenterRevTempCount; counter2++) arrayUpDate [counter2] = arrayGravityCenterRevTemp [counter2];
                                                
                                                delete [] arrayGravityCenterRevTemp;
                                                arrayGravityCenterRevTemp = new int [gravityCenterRevTempLimit+2000];
                                                gravityCenterRevTempLimit = gravityCenterRevTempLimit+2000;
                                                
                                                for (int counter2 = 0; counter2 < gravityCenterRevTempCount; counter2++) arrayGravityCenterRevTemp [counter2] = arrayUpDate [counter2];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            int *arrayConnectLineageRelTemp = new int [gravityCenterRevTempLimit+500];
                            connectLineageRelTempCount = 0;
                            
                            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                        finData [3] = uploadTemp [readPosition], readPosition++;
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                        finData [7] = finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                            
                            connectNoTemp = 0;
                            
                            for (int counter2 = 0; counter2 < connectLineageRelTempCount/6; counter2++){
                                if (arrayConnectLineageRelTemp [counter2*6] == lingNoTemp && arrayConnectLineageRelTemp [counter2*6+3] == cellNoPrTemp1){
                                    connectNoTemp = arrayConnectLineageRelTemp [counter2*6+1];
                                    break;
                                }
                            }
                            
                            connectNoTemp2 = 0;
                            
                            for (int counter2 = 0; counter2 < connectLineageRelTempCount/6; counter2++){
                                if (arrayConnectLineageRelTemp [counter2*6] == lingNoTemp && arrayConnectLineageRelTemp [counter2*6+3] == cellNoPrTemp2){
                                    connectNoTemp2 = arrayConnectLineageRelTemp [counter2*6+1];
                                    break;
                                }
                            }
                            
                            delete [] arrayConnectLineageRelTemp;
                            
                            areaTemp = 0;
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevTempCount/6; counter2++){
                                if (arrayGravityCenterRevTemp [counter2*6+4] == connectNoTemp){
                                    areaTemp = arrayGravityCenterRevTemp [counter2*6+2];
                                    break;
                                }
                            }
                            
                            areaTemp2 = 0;
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevTempCount/6; counter2++){
                                if (arrayGravityCenterRevTemp [counter2*6+4] == connectNoTemp2){
                                    areaTemp2 = arrayGravityCenterRevTemp [counter2*6+2];
                                    break;
                                }
                            }
                            
                            if (forAreaSizeCount < 60){
                                arrayForAreaSize [forAreaSizeCount] = areaTemp, forAreaSizeCount++;
                                arrayForAreaSize [forAreaSizeCount] = areaTemp2, forAreaSizeCount++;
                                arrayForAreaSize [forAreaSizeCount] = length, forAreaSizeCount++;
                            }
                        }
                        
                        delete [] arrayGravityCenterRevTemp;
                    }
                }
            }
        }
        
        [firstColDisplay setStringValue:@"Prog.1"];
        [secondColDisplay setStringValue:@"Prog.2"];
        [thirdColDisplay setStringValue:@"Distance"];
        [typeDisplay setStringValue:@"Distance"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToParameterSetOperations object:self];
    }
    else if (displayMode == 1){
        displayMode = 2;
        
        forAreaSizeCount = 0;
        
        int lingNoTemp = 0;
        int cellNoTemp = 0;
        int cellNoPrTemp1 = 0;
        int cellNoPrTemp2 = 0;
        int numberLength = 0;
        int zeroPoint = 0;
        int digitNumber = 0;
        int checkFlag = 0;
        int imageTimeParent = 0;
        int imageTimeProgeny = 0;
        int connectNoTemp = 0;
        int areaTemp = 0;
        int connectNoTemp2 = 0;
        int areaTemp2 = 0;
        int connectNoTemp3 = 0;
        int areaTemp3 = 0;
        int stepCount = 0;
        int finData [19];
        int gravityCenterRevTempCount = 0;
        int gravityCenterRevTempLimit = 0;
        int connectLineageRelTempCount = 0;
        int checkFlag2 = 0;
        int readingError = 0;
        
        long sizeForCopy = 0;
        long sizeForCopy2 = 0;
        long size1 = 0;
        long size2 = 0;
        
        unsigned long readPosition = 0;
        
        struct stat sizeOfFile;
        
        string cellNumberExtract;
        string digitExtract;
        string extension;
        string connectDataRevPath;
        string connectRelationPath;
        
        ifstream fin;
        
        for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
            if (arrayLineageData [counter1*8+2] > imageNumberTrackForDisplay && arrayLineageData [counter1*8+2] < imageNumberTrackForDisplay+100){
                if (arrayLineageData [counter1*8+3] == 32){
                    lingNoTemp = arrayLineageData [counter1*8+6];
                    cellNoTemp = arrayLineageData [counter1*8+5];
                    imageTimeParent = arrayLineageData [counter1*8+2];
                    imageTimeProgeny = arrayLineageData [counter1*8+2]+1;
                    
                    cellNumberExtract = to_string(cellNoTemp).substr(1);
                    
                    numberLength = (int)cellNumberExtract.length();
                    zeroPoint = -1;
                    checkFlag = 0;
                    
                    if (cellNoTemp == 0) cellNoPrTemp1 = -100000000;
                    else{
                        
                        for (int counter2 = 0; counter2 < numberLength; counter2++){
                            digitExtract = cellNumberExtract.substr((unsigned long)counter2, 1);
                            
                            if (checkFlag == 0 && digitExtract == "0"){
                                zeroPoint = counter2;
                                checkFlag = 1;
                            }
                            else if (checkFlag == 1 && digitExtract != "0"){
                                zeroPoint = -1;
                                checkFlag = 0;
                            }
                        }
                        
                        digitNumber = numberLength-zeroPoint;
                        
                        if (digitNumber == 8) cellNoPrTemp1 = cellNoTemp+10000000;
                        else if (digitNumber == 7) cellNoPrTemp1 = cellNoTemp+1000000;
                        else if (digitNumber == 6) cellNoPrTemp1 = cellNoTemp+100000;
                        else if (digitNumber == 5) cellNoPrTemp1 = cellNoTemp+10000;
                        else if (digitNumber == 4) cellNoPrTemp1 = cellNoTemp+1000;
                        else if (digitNumber == 3) cellNoPrTemp1 = cellNoTemp+100;
                        else if (digitNumber == 2) cellNoPrTemp1 = cellNoTemp+10;
                        else if (digitNumber == 1) cellNoPrTemp1 = cellNoTemp+1;
                    }
                    
                    zeroPoint = -1;
                    checkFlag = 0;
                    
                    if (cellNoTemp == 0) cellNoPrTemp2 = 100000000;
                    else{
                        
                        for (int counter2 = 0; counter2 < numberLength; counter2++){
                            digitExtract = cellNumberExtract.substr((unsigned long)counter2, 1);
                            
                            if (checkFlag == 0 && digitExtract == "0"){
                                zeroPoint = counter1;
                                checkFlag = 1;
                            }
                            else if (checkFlag == 1 && digitExtract != "0"){
                                zeroPoint = -1;
                                checkFlag = 0;
                            }
                        }
                        
                        digitNumber = numberLength-zeroPoint;
                        
                        if (digitNumber == 8) cellNoPrTemp2 = cellNoTemp-10000000;
                        else if (digitNumber == 7) cellNoPrTemp2 = cellNoTemp-1000000;
                        else if (digitNumber == 6) cellNoPrTemp2 = cellNoTemp-100000;
                        else if (digitNumber == 5) cellNoPrTemp2 = cellNoTemp-10000;
                        else if (digitNumber == 4) cellNoPrTemp2 = cellNoTemp-1000;
                        else if (digitNumber == 3) cellNoPrTemp2 = cellNoTemp-100;
                        else if (digitNumber == 2) cellNoPrTemp2 = cellNoTemp-10;
                        else if (digitNumber == 1) cellNoPrTemp2 = cellNoTemp-1;
                    }
                    
                    extension = to_string(imageTimeParent);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag2 = 0;
                    readingError = 0;
                    
                    for (int counter2 = 0; counter2 < 6; counter2++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter2 == 0) size1 = sizeForCopy;
                            else if (counter2 == 1) size2 = sizeForCopy;
                            else if (counter2 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag2 = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter2 == 3) size1 = sizeForCopy;
                            else if (counter2 == 4) size2 = sizeForCopy;
                            else if (counter2 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag2 = 1;
                                }
                            }
                        }
                    }
                    
                    areaTemp = 0;
                    
                    if (checkFlag2 == 1){
                        sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                        
                        int *arrayGravityCenterRevTemp = new int [sizeForCopy2+50];
                        gravityCenterRevTempCount = 0;
                        gravityCenterRevTempLimit = (int)sizeForCopy2+50;
                        
                        //-----Master Data upLoad-----
                        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    }
                                    else if (stepCount == 1){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        finData [9] = finData [8]*256+finData [9];
                                        
                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    }
                                    else if (stepCount == 2){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                        else{
                                            
                                            if (gravityCenterRevTempCount+6 > gravityCenterRevTempLimit){
                                                int *arrayUpDate = new int [gravityCenterRevTempCount+10];
                                                
                                                for (int counter2 = 0; counter2 < gravityCenterRevTempCount; counter2++) arrayUpDate [counter2] = arrayGravityCenterRevTemp [counter2];
                                                
                                                delete [] arrayGravityCenterRevTemp;
                                                arrayGravityCenterRevTemp = new int [gravityCenterRevTempLimit+2000];
                                                gravityCenterRevTempLimit = gravityCenterRevTempLimit+2000;
                                                
                                                for (int counter2 = 0; counter2 < gravityCenterRevTempCount; counter2++) arrayGravityCenterRevTemp [counter2] = arrayUpDate [counter2];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            int *arrayConnectLineageRelTemp = new int [gravityCenterRevTempLimit+500];
                            connectLineageRelTempCount = 0;
                            
                            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                        finData [3] = uploadTemp [readPosition], readPosition++;
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                        finData [7] = finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                            
                            connectNoTemp = 0;
                            
                            for (int counter2 = 0; counter2 < connectLineageRelTempCount/6; counter2++){
                                if (arrayConnectLineageRelTemp [counter2*6] == lingNoTemp && arrayConnectLineageRelTemp [counter2*6+3] == cellNoTemp){
                                    connectNoTemp = arrayConnectLineageRelTemp [counter2*6+1];
                                    break;
                                }
                            }
                            
                            delete [] arrayConnectLineageRelTemp;
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevTempCount/6; counter2++){
                                if (arrayGravityCenterRevTemp [counter2*6+4] == connectNoTemp){
                                    areaTemp = arrayGravityCenterRevTemp [counter2*6+2];
                                    break;
                                }
                            }
                        }
                        
                        delete [] arrayGravityCenterRevTemp;
                    }
                    
                    extension = to_string(imageTimeProgeny);
                    
                    if (extension.length() == 1) extension = "000"+extension;
                    else if (extension.length() == 2) extension = "00"+extension;
                    else if (extension.length() == 3) extension = "0"+extension;
                    
                    connectDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag2 = 0;
                    readingError = 0;
                    
                    for (int counter2 = 0; counter2 < 6; counter2++){
                        sizeForCopy = 0;
                        
                        if (stat(connectDataRevPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter2 == 0) size1 = sizeForCopy;
                            else if (counter2 == 1) size2 = sizeForCopy;
                            else if (counter2 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag2 = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter2 == 3) size1 = sizeForCopy;
                            else if (counter2 == 4) size2 = sizeForCopy;
                            else if (counter2 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag2 = 1;
                                }
                            }
                        }
                    }
                    
                    areaTemp2 = 0;
                    areaTemp3 = 0;
                    
                    if (checkFlag2 == 1){
                        sizeForCopy2 = (long)(sizeForCopy*(double)0.1+50);
                        
                        int *arrayGravityCenterRevTemp = new int [sizeForCopy2+50];
                        gravityCenterRevTempCount = 0;
                        gravityCenterRevTempLimit = (int)sizeForCopy2+50;
                        
                        //-----Master Data upLoad-----
                        fin.open(connectDataRevPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                        readingError = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (readingError == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                        finData [14] = uploadTemp [readPosition], readPosition++;
                                        finData [15] = uploadTemp [readPosition], readPosition++;
                                        finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                    }
                                    else if (stepCount == 1){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        finData [9] = finData [8]*256+finData [9];
                                        
                                        if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                    }
                                    else if (stepCount == 2){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                        finData [8] = uploadTemp [readPosition], readPosition++;
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                        finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                        else{
                                            
                                            if (gravityCenterRevTempCount+6 > gravityCenterRevTempLimit){
                                                int *arrayUpDate = new int [gravityCenterRevTempCount+10];
                                                
                                                for (int counter2 = 0; counter2 < gravityCenterRevTempCount; counter2++) arrayUpDate [counter2] = arrayGravityCenterRevTemp [counter2];
                                                
                                                delete [] arrayGravityCenterRevTemp;
                                                arrayGravityCenterRevTemp = new int [gravityCenterRevTempLimit+2000];
                                                gravityCenterRevTempLimit = gravityCenterRevTempLimit+2000;
                                                
                                                for (int counter2 = 0; counter2 < gravityCenterRevTempCount; counter2++) arrayGravityCenterRevTemp [counter2] = arrayUpDate [counter2];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [1], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [3], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [6], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [7], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [10], gravityCenterRevTempCount++;
                                            arrayGravityCenterRevTemp [gravityCenterRevTempCount] = finData [11], gravityCenterRevTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ConnectLineageRel";
                        
                        sizeForCopy = 0;
                        
                        if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            int *arrayConnectLineageRelTemp = new int [gravityCenterRevTempLimit+500];
                            connectLineageRelTempCount = 0;
                            
                            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                        finData [3] = uploadTemp [readPosition], readPosition++;
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                        finData [7] = finData [6]*256+finData [7];
                                        
                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                        
                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                        else{
                                            
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [2], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [5], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [7], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [12], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [13], connectLineageRelTempCount++;
                                            arrayConnectLineageRelTemp [connectLineageRelTempCount] = finData [14], connectLineageRelTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                            
                            connectNoTemp2 = 0;
                            
                            for (int counter2 = 0; counter2 < connectLineageRelTempCount/6; counter2++){
                                if (arrayConnectLineageRelTemp [counter2*6] == lingNoTemp && arrayConnectLineageRelTemp [counter2*6+3] == cellNoPrTemp1){
                                    connectNoTemp2 = arrayConnectLineageRelTemp [counter2*6+1];
                                    break;
                                }
                            }
                            
                            connectNoTemp3 = 0;
                            
                            for (int counter2 = 0; counter2 < connectLineageRelTempCount/6; counter2++){
                                if (arrayConnectLineageRelTemp [counter2*6] == lingNoTemp && arrayConnectLineageRelTemp [counter2*6+3] == cellNoPrTemp2){
                                    connectNoTemp3 = arrayConnectLineageRelTemp [counter2*6+1];
                                    break;
                                }
                            }
                            
                            delete [] arrayConnectLineageRelTemp;
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevTempCount/6; counter2++){
                                if (arrayGravityCenterRevTemp [counter2*6+4] == connectNoTemp2){
                                    areaTemp2 = arrayGravityCenterRevTemp [counter2*6+2];
                                    break;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < gravityCenterRevTempCount/6; counter2++){
                                if (arrayGravityCenterRevTemp [counter2*6+4] == connectNoTemp3){
                                    areaTemp3 = arrayGravityCenterRevTemp [counter2*6+2];
                                    break;
                                }
                            }
                        }
                        
                        delete [] arrayGravityCenterRevTemp;
                    }
                    
                    if (forAreaSizeCount < 60){
                        arrayForAreaSize [forAreaSizeCount] = areaTemp, forAreaSizeCount++;
                        arrayForAreaSize [forAreaSizeCount] = areaTemp2, forAreaSizeCount++;
                        arrayForAreaSize [forAreaSizeCount] = areaTemp3, forAreaSizeCount++;
                    }
                }
            }
        }
        
        [firstColDisplay setStringValue:@"Parent"];
        [secondColDisplay setStringValue:@"Prog.1"];
        [thirdColDisplay setStringValue:@"Prog.2"];
        [typeDisplay setStringValue:@"Size"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToParameterSetOperations object:self];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)jumpAllowSet:(id)sender{
    if (jumpAllFlag == 0){
        jumpAllFlag = 1;
        [jumpAllowDisplay setStringValue:@"On"];
    }
    else{
        
        jumpAllFlag = 0;
        [jumpAllowDisplay setStringValue:@"Off"];
    }
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)expandAllowSet:(id)sender{
    if (connectExpandFlag == 0){
        connectExpandFlag = 1;
        [expandAllowDisplay setStringValue:@"First"];
    }
    else if (connectExpandFlag == 1){
        connectExpandFlag = 2;
        [expandAllowDisplay setStringValue:@"First+Second"];
    }
    else if (connectExpandFlag == 2){
        connectExpandFlag = 0;
        [expandAllowDisplay setStringValue:@"Off"];
    }
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)mergeSet:(id)sender{
    if (mapMergeStatus == 0){
        mapMergeStatus = 1;
        [mapMergeDisplay setStringValue:@"On"];
    }
    else if (mapMergeStatus == 1){
        mapMergeStatus = 0;
        [mapMergeDisplay setStringValue:@"Off"];
    }
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cGCenterLimitSet:(id)sender{
    if (gravityCenterMoveLimitFlag == 0){
        gravityCenterMoveLimitFlag = 1;
        [cgCenterDisplay setStringValue:@"On"];
    }
    else if (gravityCenterMoveLimitFlag == 1){
        gravityCenterMoveLimitFlag = 0;
        [cgCenterDisplay setStringValue:@"Off"];
    }
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)stepperAutoCheckDistanceSet:(id)sender{
    [autoCheckDistanceDisplay setIntValue: [stepperAutoCheckDistance intValue]];
    autoCheckDistanceHold = [stepperAutoCheckDistance intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperAutoCheckAreaSet:(id)sender{
    [autoCheckAreaDisplay setIntValue: [stepperAutoCheckArea intValue]];
    autoCheckAreaHold = [stepperAutoCheckArea intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperAutoCheckDivisionSet:(id)sender{
    [autoCheckDivisionDisplay setIntValue: [stepperAutoCheckDivision intValue]];
    autoCheckDivisionHold = [stepperAutoCheckDivision intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperAutoCheckDistanceFoldSet:(id)sender{
    [autoCheckDistanceFoldDisplay setIntValue: [stepperAutoCheckDistanceFold intValue]];
    autoCheckDistanceFoldHold = [stepperAutoCheckDistanceFold intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperAutoCheckIntensitySet:(id)sender{
    [autoCheckIntensityDisplay setIntValue: [stepperAutoCheckIntensity intValue]];
    autoCheckIntensityHold = [stepperAutoCheckIntensity intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)stepperOptionalSearchPercentSet:(id)sender{
    [optionalSearchPercentDisplay setIntValue: [stepperOptionalSearchPercent intValue]];
    optionalShiftPercent = [stepperOptionalSearchPercent intValue];
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
}

-(IBAction)mitosisOnSet:(id)sender{
    if (mitosisOffFlag == 0){
        mitosisOffFlag = 1;
        [mitosisOnOffDisplay setStringValue:@"Off"];
    }
    else if (mitosisOffFlag == 1){
        mitosisOffFlag = 0;
        [mitosisOnOffDisplay setStringValue:@"On"];
    }
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fusionMarkOnSet:(id)sender{
    if (fusionMarkSetFlag == 0){
        fusionMarkSetFlag = 1;
        [fusionMarkOnOffDisplay setStringValue:@"Off"];
    }
    else if (fusionMarkSetFlag == 1){
        fusionMarkSetFlag = 0;
        [fusionMarkOnOffDisplay setStringValue:@"On"];
    }
    
    dataSaveRead = [[DataSaveRead alloc] init];
    [dataSaveRead saveParameters];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)closeWindow:(id)sender{
    [parameterSetWindow orderOut:self];
    parameterSethWindowOperation = 2;
    parameterSetTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (parameterSethWindowOperation == 3){
        [parameterSetWindow makeKeyAndOrderFront:self];
        parameterSethWindowOperation = 1;
        [parameterSetTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToParameterSet object:nil];
}

@end
