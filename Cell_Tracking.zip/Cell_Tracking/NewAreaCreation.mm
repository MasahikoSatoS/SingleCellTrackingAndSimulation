//
// NewAreaCreation.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 01/09/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "NewAreaCreation.h"

@implementation NewAreaCreation

-(void)newAreaLine{
    int *connectNumber = new int [lineDataProcessingCount+50], connectNumberCount = 0;
    
    //-----Find overlap connect-----
    for (int counter1 = 0; counter1 < lineDataProcessingCount/2; counter1++){
        if (revisedWorkingMap [arrayLineDataProcessing [counter1*2+1]][arrayLineDataProcessing [counter1*2]] != 0) connectNumber [connectNumberCount] = revisedWorkingMap [arrayLineDataProcessing [counter1*2+1]][arrayLineDataProcessing [counter1*2]], connectNumberCount++;
    }
    
    if (connectNumberCount != 0){
        int lineEntryNumber = 0;
        
        if (targetHoldCount != 0) lineEntryNumber = arrayTargetHold [(targetHoldCount/3-1)*3+2];
        else lineEntryNumber = 0;
        
        lineEntryNumber++;
        
        int *connectSort = new int [connectNumberCount+2];
        int *connectNumberList = new int [connectNumberCount+2];
        
        for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
            connectSort [counter1] = 0;
            connectNumberList [counter1] = connectNumber [counter1];
        }
        
        int valueTemp2 = 0;
        
        for (int counter1 = 0; counter1 < connectNumberCount-1; counter1++){
            valueTemp2 = 0;
            
            if (connectSort [counter1] == 0) valueTemp2 = connectNumberList [counter1];
            
            for (int counter2 = counter1+1; counter2 < connectNumberCount; counter2++){
                if (connectNumberList [counter2] == valueTemp2) connectSort [counter2] = 1;
            }
        }
        
        int numberOfRemaining = 0;
        
        for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
            if (connectSort [counter1] == 0) numberOfRemaining++;
        }
        
        int *connectProcessList = new int [numberOfRemaining+2];
        int entryCount = 0; //-----List of connect that to be processed-----
        
        for (int counter1 = 0; counter1 < connectNumberCount; counter1++){
            if (connectSort [counter1] == 0) connectProcessList [entryCount] = connectNumberList [counter1], entryCount++;
        }
        
        delete [] connectSort;
        delete [] connectNumberList;
        
        //for (int counterA = 0; counterA < numberOfRemaining; counterA++) cout<<" "<<connectProcessList [counterA]<<" Connect List"<<endl;
        
        //-----Each connect process-----
        int positionReviseOriginalStatus = 0;
        int timeSelectedOriginalStatus = 0;
        int maxPointDimX = 0;
        int maxPointDimY = 0;
        int minPointDimX = 0;
        int minPointDimY = 0;
        int horizontalLength = 0;
        int verticalLength = 0;
        int dimension = 0;
        int horizontalStart = 0;
        int verticalStart = 0;
        int connectivityNumber = 0;
        int connectAnalysisCount = 0;
        int terminationFlag = 0;
        int connectAnalysisTempCount = 0;
        int xSource = 0;
        int ySource = 0;
        int connectTemp = 0;
        int maxConnectivityNumber = 0;
        int newConnectLineNo = 0;
        int largestConnect = 0;
        int largestConnectNo = 0;
        int xPositionTempStart = 0;
        int yPositionTempStart = 0;
        int lineSize = 0;
        int constructedLineCount = 0;
        int findFlag = 0;
        int terminationFlag2 = 0;
        int maxInsideCheck = 0;
        int insideFind = 0;
        int timeOneTempCount = 0;
        int currentStatus = 0;
        int gravityCenter1 [4];
        int maxVectorNumber = 0;
        int xGravityImageTemp = 0;
        int yGravityImageTemp = 0;
        int gravityX1 = 0;
        int gravityY1 = 0;
        int totalGRCount = 0;
        int averageIntensity = 0;
        int edgeCheck = 0;
        
        for (int counter1 = 0; counter1 < numberOfRemaining; counter1++){
            positionReviseOriginalStatus = 0;
            
            int *connectLineData = new int [positionReviseCount+50], connectLineDataCount = 0;
            
            for (int counter2 = arrayTimeSelected [(connectProcessList [counter1]-1)*10+2]; counter2 < positionReviseCount/7; counter2++){
                if (arrayPositionRevise [counter2*7+3] == arrayTimeSelected [(connectProcessList [counter1]-1)*10+8]){
                    connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7], connectLineDataCount++;
                    connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+1], connectLineDataCount++;
                    connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+2], connectLineDataCount++;
                    connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+3], connectLineDataCount++;
                    connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+4], connectLineDataCount++;
                    connectLineData [connectLineDataCount] = arrayPositionRevise [counter2*7+5], connectLineDataCount++;
                    
                    positionReviseOriginalStatus = arrayPositionRevise [counter2*7+5];
                }
                else{
                    
                    break;
                }
            }
            
            timeSelectedOriginalStatus = 0;
            
            for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                if (arrayTimeSelected [counter2*10+8] == connectProcessList [counter1]){
                    timeSelectedOriginalStatus = arrayTimeSelected [counter2*10];
                    break;
                }
            }
            
            //for (int counterA = 0; counterA < connectLineDataCount/6; counterA++){
            //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<connectLineData [counterA*6+counterB];
            //	cout<<" connectLineData "<<counterA<<endl;
            //}
            
            maxPointDimX = 0;
            maxPointDimY = 0;
            minPointDimX = 1000000;
            minPointDimY = 1000000;
            
            for (int counter2 = 0; counter2 < connectLineDataCount/6; counter2++){
                if (maxPointDimX < connectLineData [counter2*6]) maxPointDimX = connectLineData [counter2*6];
                if (minPointDimX > connectLineData [counter2*6]) minPointDimX = connectLineData [counter2*6];
                if (maxPointDimY < connectLineData [counter2*6+1]) maxPointDimY = connectLineData [counter2*6+1];
                if (minPointDimY > connectLineData [counter2*6+1]) minPointDimY = connectLineData [counter2*6+1];
            }
            
            //-----Determine the dimension of cell-----
            horizontalLength = (maxPointDimX-minPointDimX)/2*2;
            verticalLength = (maxPointDimY-minPointDimY)/2*2;
            dimension = 0;
            
            if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
            if (horizontalLength < verticalLength) dimension = verticalLength+30;
            
            dimension = (dimension/2)*2;
            
            horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
            verticalStart = minPointDimY-(dimension-verticalLength)/2;
            
            //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
            
            connectivityMap = new int *[dimension+1];
            for (int counter2 = 0; counter2 < dimension+1; counter2++) connectivityMap [counter2] = new int [dimension+1];
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = 0;
            }
            
            for (int counter2 = 0; counter2 < connectLineDataCount/6; counter2++){
                connectivityMap [connectLineData [counter2*6+1]-verticalStart][connectLineData [counter2*6]-horizontalStart] = 1;
            }
            
            delete [] connectLineData;
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            //-----Fill inside-----
            int *connectAnalysisX = new int [dimension*4];
            int *connectAnalysisY = new int [dimension*4];
            int *connectAnalysisTempX = new int [dimension*4];
            int *connectAnalysisTempY = new int [dimension*4];
            
            connectivityNumber = -3;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] == 0){
                        connectivityNumber = connectivityNumber+2;
                        connectAnalysisCount = 0;
                        
                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMap [counterY][counterX] = connectivityNumber;
                        
                        if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] == 0){
                            connectivityMap [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] == 0){
                            connectivityMap [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] == 0){
                            connectivityMap [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] == 0){
                            connectivityMap [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] == 0){
                                        connectivityMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] == 0){
                                        connectivityMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] == 0){
                                        connectivityMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] == 0){
                                        connectivityMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] == -1) connectivityMap [counterY][counterX] = 0;
                    else connectivityMap [counterY][counterX] = 1;
                }
            }
            
            for (int counter2 = 0; counter2 < lineDataProcessingCount/2; counter2++){
                if (arrayLineDataProcessing [counter2*2]-horizontalStart > 0 && arrayLineDataProcessing [counter2*2]-horizontalStart < dimension && arrayLineDataProcessing [counter2*2+1]-verticalStart >= 0 && arrayLineDataProcessing [counter2*2+1]-verticalStart < dimension) connectivityMap [arrayLineDataProcessing [counter2*2+1]-verticalStart][arrayLineDataProcessing [counter2*2]-horizontalStart] = 0;
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0) connectivityMap [counterY][counterX] = connectivityMap [counterY][counterX]*-1;
                }
            }
            
            connectivityNumber = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] < 0){
                        connectivityNumber++;
                        connectivityMap [counterY][counterX] = connectivityNumber;
                        connectAnalysisCount = 0;
                        
                        if (counterY-1 >= 0 && counterX-1 >= 0 && connectivityMap [counterY-1][counterX-1] < 0){
                            connectivityMap [counterY-1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && connectivityMap [counterY-1][counterX] < 0){
                            connectivityMap [counterY-1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterY-1 >= 0 && counterX+1 < dimension && connectivityMap [counterY-1][counterX+1] < 0){
                            connectivityMap [counterY-1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                        }
                        if (counterX+1 < dimension && connectivityMap [counterY][counterX+1] < 0){
                            connectivityMap [counterY][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX+1 < dimension && connectivityMap [counterY+1][counterX+1] < 0){
                            connectivityMap [counterY+1][counterX+1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && connectivityMap [counterY+1][counterX] < 0){
                            connectivityMap [counterY+1][counterX] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterY+1 < dimension && counterX-1 >= 0 && connectivityMap [counterY+1][counterX-1] < 0){
                            connectivityMap [counterY+1][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                        }
                        if (counterX-1 >= 0 && connectivityMap [counterY][counterX-1] < 0){
                            connectivityMap [counterY][counterX-1] = connectivityNumber;
                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                        }
                        
                        if (connectAnalysisCount != 0){
                            do{
                                
                                terminationFlag = 1;
                                connectAnalysisTempCount = 0;
                                
                                for (int counter2 = 0; counter2 < connectAnalysisCount; counter2++){
                                    xSource = connectAnalysisX [counter2], ySource = connectAnalysisY [counter2];
                                    
                                    if (ySource-1 >= 0 && xSource-1 >= 0 && connectivityMap [ySource-1][xSource-1] < 0){
                                        connectivityMap [ySource-1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && connectivityMap [ySource-1][xSource] < 0){
                                        connectivityMap [ySource-1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (ySource-1 >= 0 && xSource+1 < dimension && connectivityMap [ySource-1][xSource+1] < 0){
                                        connectivityMap [ySource-1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                    }
                                    if (xSource+1 < dimension && connectivityMap [ySource][xSource+1] < 0){
                                        connectivityMap [ySource][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 > dimension && xSource+1 < dimension && connectivityMap [ySource+1][xSource+1] < 0){
                                        connectivityMap [ySource+1][xSource+1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && connectivityMap [ySource+1][xSource] < 0){
                                        connectivityMap [ySource+1][xSource] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (ySource+1 < dimension && xSource-1 >= 0 && connectivityMap [ySource+1][xSource-1] < 0){
                                        connectivityMap [ySource+1][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                    }
                                    if (xSource-1 >= 0 && connectivityMap [ySource][xSource-1] < 0){
                                        connectivityMap [ySource][xSource-1] = connectivityNumber;
                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < connectAnalysisTempCount; counter2++){
                                    connectAnalysisX [counter2] = connectAnalysisTempX [counter2], connectAnalysisY [counter2] = connectAnalysisTempY [counter2];
                                }
                                
                                connectAnalysisCount = connectAnalysisTempCount;
                                
                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            //-----Determine number of pixels-----
            int *connectedPix = new int [connectivityNumber+50];
            
            for (int counter2 = 0; counter2 <= connectivityNumber; counter2++) connectedPix [counter2] = 0;
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
                }
            }
            
            //-----Map up-date-----
            connectTemp = 1;
            
            for (int counter2 = 1; counter2 <= connectivityNumber; counter2++){
                if (connectedPix [counter2] < 10) connectedPix [counter2] = 0;
                else{
                    
                    connectedPix [counter2] = connectTemp;
                    connectTemp++;
                }
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if ((connectTemp = connectivityMap [counterY][counterX]) != 0) connectivityMap [counterY][counterX] = connectedPix [connectTemp];
                }
            }
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //	for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //	cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            delete [] connectedPix;
            
            maxConnectivityNumber = 0;
            newConnectLineNo = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] > maxConnectivityNumber) maxConnectivityNumber = connectivityMap [counterY][counterX];
                }
            }
            
            int **outlineMap = new int *[dimension+1];
            int **outlineMap2 = new int *[dimension+1];
            int **outlineMap3 = new int *[dimension+1];
            int **internalConnectMap = new int *[dimension+1];
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++){
                outlineMap [counter2] = new int [dimension+1];
                outlineMap2 [counter2] = new int [dimension+1];
                outlineMap3 [counter2] = new int [dimension+1];
                internalConnectMap [counter2] = new int [dimension+1];
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    outlineMap3 [counterY][counterX] = 0;
                    internalConnectMap [counterY][counterX] = 0;
                }
            }
            
            int *outlineDataSet = new int [1000];
            int outlineDataSetCount = 0;
            int outlineDataSetLimit = 1000;
            
            for (int counter2 = 1; counter2 <= maxConnectivityNumber; counter2++){
                for (int counterY = 0; counterY < dimension; counterY++){
                    for (int counterX = 0; counterX < dimension; counterX++){
                        if (connectivityMap [counterY][counterX] == counter2) outlineMap [counterY][counterX] = 1;
                        else outlineMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < dimension; counterA++){
                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap [counterA][counterB];
                //    cout<<" outlineMap "<<counterA<<endl;
                //}
                
                do{
                    
                    terminationFlag = 0;
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (outlineMap [counterY][counterX] != 0){
                                if (counterX+1 < dimension && outlineMap [counterY][counterX+1] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterY+1 < dimension && outlineMap [counterY+1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterX-1 >= 0 && outlineMap [counterY][counterX-1] == 0) outlineMap [counterY][counterX] = -1;
                                else if (counterY-1 >= 0 && outlineMap [counterY-1][counterX] == 0) outlineMap [counterY][counterX] = -1;
                            }
                        }
                    }
                    
                    for (int counterY = 0; counterY < dimension; counterY++){
                        for (int counterX = 0; counterX < dimension; counterX++){
                            if (outlineMap [counterY][counterX] > 0) outlineMap [counterY][counterX] = 0;
                            if (outlineMap [counterY][counterX] < 0) outlineMap [counterY][counterX] = 1;
                        }
                    }
                    
                    connectivityNumber = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (outlineMap [counterY2][counterX2] == 0){
                                connectivityNumber--;
                                connectAnalysisCount = 0;
                                
                                outlineMap [counterY2][counterX2] = connectivityNumber;
                                
                                if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 0){
                                    outlineMap [counterY2-1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2-1, connectAnalysisCount++;
                                }
                                if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 0){
                                    outlineMap [counterY2][counterX2+1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2+1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 0){
                                    outlineMap [counterY2+1][counterX2] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2, connectAnalysisY [connectAnalysisCount] = counterY2+1, connectAnalysisCount++;
                                }
                                if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 0){
                                    outlineMap [counterY2][counterX2-1] = connectivityNumber;
                                    connectAnalysisX [connectAnalysisCount] = counterX2-1, connectAnalysisY [connectAnalysisCount] = counterY2, connectAnalysisCount++;
                                }
                                
                                if (connectAnalysisCount != 0){
                                    do{
                                        
                                        terminationFlag = 1;
                                        connectAnalysisTempCount = 0;
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                            xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                            
                                            if (ySource-1 >= 0 && outlineMap [ySource-1][xSource] == 0){
                                                outlineMap [ySource-1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                            }
                                            if (xSource+1 < dimension && outlineMap [ySource][xSource+1] == 0){
                                                outlineMap [ySource][xSource+1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                            if (ySource+1 < dimension && outlineMap [ySource+1][xSource] == 0){
                                                outlineMap [ySource+1][xSource] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                            }
                                            if (xSource-1 >= 0 && outlineMap [ySource][xSource-1] == 0){
                                                outlineMap [ySource][xSource-1] = connectivityNumber;
                                                connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                            connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                        }
                                        
                                        connectAnalysisCount = connectAnalysisTempCount;
                                        
                                        if (connectAnalysisCount == 0) terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                        }
                    }
                    
                    //-----Determine number of pixels-----
                    connectivityNumber = connectivityNumber*-1;
                    
                    int *connectedPix2 = new int [connectivityNumber+50];
                    for (int counter3 = 0; counter3 <= connectivityNumber; counter3++) connectedPix2 [counter3] = 0;
                    
                    for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                        for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                            if (outlineMap [counterY2][counterX2] < -1) connectedPix2 [outlineMap [counterY2][counterX2]*-1]++;
                        }
                    }
                    
                    largestConnect = 0;
                    largestConnectNo = 0;
                    
                    for (int counter3 = 2; counter3 <= connectivityNumber; counter3++){
                        if (connectedPix2 [counter3] > largestConnect){
                            largestConnect = connectedPix2 [counter3];
                            largestConnectNo = counter3;
                        }
                    }
                    
                    delete [] connectedPix2;
                    
                    if (largestConnectNo == 0 || largestConnect < 20) terminationFlag = 1;
                    else{
                        
                        int **newConnectivityMapTemp = new int *[dimension+4];
                        for (int counter3 = 0; counter3 < dimension+4; counter3++) newConnectivityMapTemp [counter3] = new int [dimension+4];
                        
                        for (int counterY = 0; counterY < dimension+4; counterY++){
                            for (int counterX = 0; counterX < dimension+4; counterX++) newConnectivityMapTemp [counterY][counterX] = 0;
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (outlineMap [counterY2][counterX2] == largestConnectNo*-1){
                                    if (counterY2-1 >= 0 && counterX2-1 >= 0 && outlineMap [counterY2-1][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2-1] = 1;
                                        outlineMap [counterY2-1][counterX2-1] = 0;
                                    }
                                    if (counterY2-1 >= 0 && outlineMap [counterY2-1][counterX2] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2] = 1;
                                        outlineMap [counterY2-1][counterX2] = 0;
                                    }
                                    if (counterY2-1 >= 0 && counterX2+1 < dimension && outlineMap [counterY2-1][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2-1][counterX2+1] = 1;
                                        outlineMap [counterY2-1][counterX2+1] = 0;
                                    }
                                    if (counterX2+1 < dimension && outlineMap [counterY2][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2][counterX2+1] = 1;
                                        outlineMap [counterY2][counterX2+1] = 0;
                                    }
                                    if (counterY2+1 < dimension && counterX2+1 < dimension && outlineMap [counterY2+1][counterX2+1] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2+1] = 1;
                                        outlineMap [counterY2+1][counterX2+1] = 0;
                                    }
                                    if (counterY2+1 < dimension && outlineMap [counterY2+1][counterX2] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2] = 1;
                                        outlineMap [counterY2+1][counterX2] = 0;
                                    }
                                    if (counterY2+1 < dimension && counterX2-1 >= 0 && outlineMap [counterY2+1][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2+1][counterX2-1] = 1;
                                        outlineMap [counterY2+1][counterX2-1] = 0;
                                    }
                                    if (counterX2-1 >= 0 && outlineMap [counterY2][counterX2-1] == 1){
                                        newConnectivityMapTemp [counterY2][counterX2-1] = 1;
                                        outlineMap [counterY2][counterX2-1] = 0;
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<newConnectivityMapTemp [counterA][counterB];
                        //    cout<<" newConnectivityMapTemp "<<counterA<<endl;
                        //}
                        
                        xPositionTempStart = 0;
                        yPositionTempStart = 0;
                        lineSize = 0;
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++) outlineMap2 [counterY2][counterX2] = 0;
                        }
                        
                        for (int counterY2 = 0; counterY2 < dimension; counterY2++){
                            for (int counterX2 = 0; counterX2 < dimension; counterX2++){
                                if (newConnectivityMapTemp [counterY2][counterX2] == 1){
                                    outlineMap2 [counterY2][counterX2] = 1;
                                    
                                    xPositionTempStart = counterX2;
                                    yPositionTempStart = counterY2;
                                    lineSize++;
                                }
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < dimension+4; counter3++) delete [] newConnectivityMapTemp [counter3];
                        delete [] newConnectivityMapTemp;
                        
                        constructedLineCount = 0;
                        
                        int *arrayNewLines = new int [lineSize*2+50];
                        
                        outlineMap2 [yPositionTempStart][xPositionTempStart] = -1;
                        arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                        arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                        
                        do{
                            
                            findFlag = 0;
                            terminationFlag2 = 0;
                            
                            if (xPositionTempStart+1 < dimension){
                                if (outlineMap2 [yPositionTempStart][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart+1 < dimension && yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && yPositionTempStart+1 < dimension && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart+1][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart+1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart+1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart-1 >= 0 && yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart-1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart-1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart-1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1, findFlag = 1;
                                }
                            }
                            if (xPositionTempStart+1 < dimension && yPositionTempStart-1 >= 0 && findFlag == 0){
                                if (outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] == 1){
                                    outlineMap2 [yPositionTempStart-1][xPositionTempStart+1] = -1;
                                    arrayNewLines [constructedLineCount] = xPositionTempStart+1, constructedLineCount++;
                                    arrayNewLines [constructedLineCount] = yPositionTempStart-1, constructedLineCount++;
                                    xPositionTempStart = xPositionTempStart+1, yPositionTempStart = yPositionTempStart-1, terminationFlag2 = 1;
                                }
                            }
                            
                        } while (terminationFlag2 == 1);
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                        //    cout<<" outlineMap2 "<<counterA<<endl;
                        //}
                        
                        newConnectLineNo++;
                        
                        for (int counter3 = 0; counter3 < constructedLineCount/2; counter3++){
                            if (outlineDataSetCount+3 > outlineDataSetLimit){
                                int *arrayUpDate = new int [outlineDataSetCount+10];
                                
                                for (int counter4 = 0; counter4 < outlineDataSetCount; counter4++) arrayUpDate [counter4] = outlineDataSet [counter4];
                                
                                delete [] outlineDataSet;
                                outlineDataSet = new int [outlineDataSetLimit+5000];
                                outlineDataSetLimit = outlineDataSetLimit+5000;
                                
                                for (int counter4 = 0; counter4 < outlineDataSetCount; counter4++) outlineDataSet [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            outlineDataSet [outlineDataSetCount] = newConnectLineNo, outlineDataSetCount++; //-----Vector no-----
                            outlineDataSet [outlineDataSetCount] = arrayNewLines [counter3*2], outlineDataSetCount++; //-----X Position-----
                            outlineDataSet [outlineDataSetCount] = arrayNewLines [counter3*2+1], outlineDataSetCount++; //-----Y Position-----
                        }
                        
                        delete [] arrayNewLines;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = outlineMap2 [counterY][counterX]*-1;
                            }
                        }
                        
                        connectivityNumber = -3;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == 0){
                                    connectivityNumber = connectivityNumber+2;
                                    outlineMap2 [counterY][counterX] = connectivityNumber;
                                    
                                    connectAnalysisCount = 0;
                                    
                                    if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0){
                                        outlineMap2 [counterY-1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                    }
                                    if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0){
                                        outlineMap2 [counterY][counterX+1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0){
                                        outlineMap2 [counterY+1][counterX] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                    }
                                    if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0){
                                        outlineMap2 [counterY][counterX-1] = connectivityNumber;
                                        connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                    }
                                    
                                    if (connectAnalysisCount != 0){
                                        do{
                                            
                                            terminationFlag = 1;
                                            connectAnalysisTempCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                
                                                if (ySource-1 >= 0 && outlineMap2 [ySource-1][xSource] == 0){
                                                    outlineMap2 [ySource-1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                }
                                                if (xSource+1 < dimension && outlineMap2 [ySource][xSource+1] == 0){
                                                    outlineMap2 [ySource][xSource+1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                                if (ySource+1 < dimension && outlineMap2 [ySource+1][xSource] == 0){
                                                    outlineMap2 [ySource+1][xSource] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                }
                                                if (xSource-1 >= 0 && outlineMap2 [ySource][xSource-1] == 0){
                                                    outlineMap2 [ySource][xSource-1] = connectivityNumber;
                                                    connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                            }
                                            
                                            connectAnalysisCount = connectAnalysisTempCount;
                                            
                                            if (connectAnalysisCount == 0) terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                            }
                        }
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] == -1) outlineMap2 [counterY][counterX] = 0;
                                else outlineMap2 [counterY][counterX] = newConnectLineNo;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<outlineMap2 [counterA][counterB];
                        //    cout<<" outlineMap2 "<<counterA<<endl;
                        //}
                        
                        //==========
                        //int **sourceImageAAA = new int *[dimension+1]; //=======For check
                        
                        //for (int counterA = 0; counterA < dimension+1; counterA++){
                        //    sourceImageAAA [counterA] = new int [dimension+1];
                        //}
                        
                        //for (int counterY = 0; counterY < dimension; counterY++){
                        //    for (int counterX = 0; counterX < dimension; counterX++){
                        //        sourceImageAAA [counterY][counterX] = 0;
                        //    }
                        //}
                        
                        //for (int counterY = 0; counterY < imageDimension; counterY++){
                        //    for (int counterX = 0; counterX < imageDimension; counterX++){
                        //        if (counterY-verticalStart >= 0 && counterY-verticalStart < dimension && counterX-horizontalStart >= 0 && counterX-horizontalStart < dimension){
                        //            if (revisedWorkingMap [counterY][counterX] != 0){
                        //                sourceImageAAA [counterY-verticalStart][counterX-horizontalStart] = revisedWorkingMap [counterY][counterX];
                        //            }
                        //        }
                        //    }
                        //}
                        
                        //for (int counterA = 0; counterA < dimension; counterA++){
                        //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<sourceImageAAA [counterA][counterB];
                        //    cout<<" sourceImageA "<<counterA<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < dimension+1; counterA++){
                        //    delete [] sourceImageAAA [counterA];
                        //}
                        
                        //delete [] sourceImageAAA;
                        //==========
                        
                        //======inside check=====
                        maxInsideCheck = timeSelectedCount/10;
                        
                        int *insideCheck = new int [maxInsideCheck*2+5];
                        
                        for (int counter3 = 0; counter3 < maxInsideCheck*2+5; counter3++) insideCheck [counter3] = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                    if (outlineMap2 [counterY][counterX] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2]++;
                                    }
                                    else if (outlineMap2 [counterY][counterX] == 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                        insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2+1]++;
                                    }
                                    
                                    edgeCheck = 0;
                                    
                                    if (outlineMap2 [counterY][counterX] != 0){
                                        if (counterY-1 >= 0 && outlineMap2 [counterY-1][counterX] == 0) edgeCheck++;
                                        if (counterX+1 < dimension && outlineMap2 [counterY][counterX+1] == 0) edgeCheck++;
                                        if (counterY+1 < dimension && outlineMap2 [counterY+1][counterX] == 0) edgeCheck++;
                                        if (counterX-1 >= 0 && outlineMap2 [counterY][counterX-1] == 0) edgeCheck++;
                                        
                                        if (edgeCheck != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                            insideCheck [revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart]*2+1]++;
                                        }
                                    }
                                }
                            }
                        }
                        
                        insideFind = 0;
                        
                        for (int counter3 = 1; counter3 <= maxInsideCheck; counter3++){
                            if (insideCheck [counter3*2] != 0 && insideCheck [counter3*2+1] == 0) insideFind = 1;
                            else if (insideCheck [counter3*2] != 0 && insideCheck [counter3*2+1] != 0) insideCheck [counter3*2] = 0;
                        }
                        
                        if (insideFind == 1){
                            for (int counterY = 0; counterY < dimension; counterY++){
                                for (int counterX = 0; counterX < dimension; counterX++){
                                    if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                        if (revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] != 0){
                                            for (int counter3 = 1; counter3 <= maxInsideCheck; counter3++){
                                                if (insideCheck [counter3*2] != 0 && revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] == counter3){
                                                    internalConnectMap [counterY][counterX] = revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart];
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        delete [] insideCheck;
                        //============================================
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (outlineMap2 [counterY][counterX] != 0){
                                    outlineMap [counterY][counterX] = 0;
                                    outlineMap3 [counterY][counterX] = outlineMap2 [counterY][counterX];
                                }
                                
                                if (outlineMap [counterY][counterX] != 0) outlineMap [counterY][counterX] = 0;
                            }
                        }
                    }
                    
                } while (terminationFlag == 0);
            }
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++) connectivityMap [counterY][counterX] = outlineMap3 [counterY][counterX];
            }
            
            //for (int counterA = 0; counterA < outlineDataSetCount/3; counterA++){
            //    cout<<counterA<<" "<<outlineDataSet [counterA*3]<<" "<<outlineDataSet [counterA*3+1]<<" "<<outlineDataSet [counterA*3+2]<<" Outline "<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<internalConnectMap [counterA][counterB];
            //    cout<<" internalConnectMap "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < dimension; counterA++){
            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMap [counterA][counterB];
            //    cout<<" connectivityMap "<<counterA<<endl;
            //}
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++){
                delete [] outlineMap [counter2];
                delete [] outlineMap2 [counter2];
                delete [] outlineMap3 [counter2];
            }
            
            delete [] outlineMap;
            delete [] outlineMap2;
            delete [] outlineMap3;
            
            delete [] connectAnalysisX;
            delete [] connectAnalysisY;
            delete [] connectAnalysisTempX;
            delete [] connectAnalysisTempY;
            
            //-----Determine number of pixels-----
            connectedPix = new int [newConnectLineNo+50];
            
            for (int counter2 = 0; counter2 <= newConnectLineNo; counter2++) connectedPix [counter2] = 0;
            
            for (int counterY = 0; counterY < dimension; counterY++){
                for (int counterX = 0; counterX < dimension; counterX++){
                    if (connectivityMap [counterY][counterX] != 0) connectedPix [connectivityMap [counterY][counterX]]++;
                }
            }
            
            if (newConnectLineNo == 0){
                int *arrayTimeOneTemp = new int [positionReviseCount+50];
                timeOneTempCount = 0;
                
                for (int counter2 = 0; counter2 < positionReviseCount/7; counter2++){
                    if (arrayPositionRevise [counter2*7+3] == connectProcessList [counter1]){
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+3], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+4], timeOneTempCount++;
                        
                        if (arrayPositionRevise [counter2*7+5] == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                        else if (arrayPositionRevise [counter2*7+5] == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                        else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+6], timeOneTempCount++;
                    }
                    else{
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+3], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+4], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+5], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter2*7+6], timeOneTempCount++;
                    }
                }
                
                positionReviseCount = 0;
                for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayPositionRevise [positionReviseCount] = arrayTimeOneTemp [counter2], positionReviseCount++;
                
                delete [] arrayTimeOneTemp;
                arrayTimeOneTemp = new int [timeSelectedCount+50];
                timeOneTempCount = 0;
                
                for (int counter2 = 0; counter2 < timeSelectedCount/10; counter2++){
                    if (counter2+1 == connectProcessList [counter1]){
                        if (arrayTimeSelected [counter2*10] == 0 || arrayTimeSelected [counter2*10] == 5 || arrayTimeSelected [counter2*10] == 6 || arrayTimeSelected [counter2*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                        else if (arrayTimeSelected [counter2*10] == 1 || arrayTimeSelected [counter2*10] == 7) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                    }
                    else{
                        
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+1], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+2], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+3], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+4], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+5], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+6], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+7], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+8], timeOneTempCount++;
                        arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter2*10+9], timeOneTempCount++;
                    }
                }
                
                timeSelectedCount = 0;
                for (int counter2 = 0; counter2 < timeOneTempCount; counter2++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter2], timeSelectedCount++;
                
                delete [] arrayTimeOneTemp;
                
                for (int counterY = 0; counterY < imageDimension; counterY++){
                    for (int counterX = 0; counterX < imageDimension; counterX++){
                        if (revisedWorkingMap [counterY][counterX] == connectProcessList [counter1]) revisedWorkingMap [counterY][counterX] = 0;
                    }
                }
                
                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                //}
            }
            
            if (newConnectLineNo > 0){
                currentStatus = 0;
                entryCount = 0;
                maxVectorNumber = 0;
                
                if (gravityCenterRevCount != 0) maxVectorNumber = arrayGravityCenterRev [(gravityCenterRevCount/6-1)*6+4];
                
                for (int counter2 = 1; counter2 < newConnectLineNo+1; counter2++){
                    if (connectedPix [counter2] != 0){
                        gravityCenter1 [0] = 0;
                        gravityCenter1 [1] = 0;
                        gravityCenter1 [2] = 0;
                        gravityCenter1 [3] = 0;
                        
                        //cout<<horizontalStart<<" "<<verticalStart<<" "<<dimension<<" hol-ver-dim"<<endl;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (connectivityMap [counterY][counterX] == counter2){
                                    gravityCenter1 [0] = gravityCenter1 [0]+counterX;
                                    gravityCenter1 [1] = gravityCenter1 [1]+counterY;
                                    gravityCenter1 [2]++;
                                    
                                    xGravityImageTemp = counterX+horizontalStart;
                                    yGravityImageTemp = counterY+verticalStart;
                                    
                                    if (xGravityImageTemp > imageDimension) xGravityImageTemp = imageDimension-1;
                                    if (xGravityImageTemp < 0) xGravityImageTemp = 0;
                                    if (yGravityImageTemp > imageDimension) yGravityImageTemp = imageDimension-1;
                                    if (yGravityImageTemp < 0) yGravityImageTemp = 0;
                                    
                                    gravityCenter1 [3] = gravityCenter1 [3]+sourceImage [yGravityImageTemp][xGravityImageTemp];
                                }
                            }
                        }
                        
                        //cout<<gravityCenter1 [0]<<" "<<gravityCenter1 [1]<<" "<<gravityCenter1 [2]<<" "<<gravityCenter1 [3]<<" GRData"<<endl;
                        
                        averageIntensity = (int)(gravityCenter1 [3]/(double)gravityCenter1 [2]);
                        
                        //cout<<gravityX1<<" "<<gravityY1<<" "<<averageIntensity<<" "<<entryCount<<" GRCenter"<<endl;
                        
                        //-----First Connect Get and Set required data-----
                        if (entryCount == 0){
                            entryCount = 1;
                            
                            int *arrayTimeOneTemp = new int [timeSelectedCount+50];
                            timeOneTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < timeSelectedCount/10; counter3++){
                                if (counter3+1 == connectProcessList [counter1]){
                                    if (arrayTimeSelected [counter3*10] == 0 || arrayTimeSelected [counter3*10] == 5 || arrayTimeSelected [counter3*10] == 6 || arrayTimeSelected [counter3*10] == 2) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                    else if (arrayTimeSelected [counter3*10] == 1 || arrayTimeSelected [counter3*10] == 7) arrayTimeOneTemp [timeOneTempCount] = 4, timeOneTempCount++;
                                    else arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = lineEntryNumber, timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+6], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+8], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+9], timeOneTempCount++;
                                }
                                else{
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+6], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+8], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayTimeSelected [counter3*10+9], timeOneTempCount++;
                                }
                                
                                //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                                //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                                //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                                //}
                            }
                            
                            timeSelectedCount = 0;
                            for (int counter3 = 0; counter3 < timeOneTempCount; counter3++) arrayTimeSelected [timeSelectedCount] = arrayTimeOneTemp [counter3], timeSelectedCount++;
                            
                            delete [] arrayTimeOneTemp;
                            
                            arrayTimeOneTemp = new int [positionReviseCount+50];
                            timeOneTempCount = 0;
                            
                            for (int counter3 = 0; counter3 < positionReviseCount/7; counter3++){
                                if (arrayPositionRevise [counter3*7+3] == connectProcessList [counter1]){
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+4], timeOneTempCount++;
                                    
                                    if (currentStatus == 0) currentStatus = arrayPositionRevise [counter3*7+5];
                                    
                                    if (currentStatus == 0) arrayTimeOneTemp [timeOneTempCount] = 2, timeOneTempCount++;
                                    else if (currentStatus == 1) arrayTimeOneTemp [timeOneTempCount] = 3, timeOneTempCount++;
                                    else arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+5], timeOneTempCount++;
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+6], timeOneTempCount++;
                                }
                                else{
                                    
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+1], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+2], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+3], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+4], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+5], timeOneTempCount++;
                                    arrayTimeOneTemp [timeOneTempCount] = arrayPositionRevise [counter3*7+6], timeOneTempCount++;
                                }
                            }
                            
                            positionReviseCount = 0;
                            for (int counter3 = 0; counter3 < timeOneTempCount; counter3++) arrayPositionRevise [positionReviseCount] = arrayTimeOneTemp [counter3], positionReviseCount++;
                            
                            delete [] arrayTimeOneTemp;
                            
                            for (int counterY = 0; counterY < imageDimension; counterY++){
                                for (int counterX = 0; counterX < imageDimension; counterX++){
                                    if (revisedWorkingMap [counterY][counterX] == connectProcessList [counter1]) revisedWorkingMap [counterY][counterX] = 0;
                                }
                            }
                        }
                        
                        //-----Process Connect pixels-----
                        maxVectorNumber++;
                        
                        if (positionReviseCount+outlineDataSetCount*3 > positionReviseLimit){
                            positionReviseAddition = outlineDataSetCount*3;
                            
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate positionRevSelectedUpDate];
                        }
                        
                        int lastConnectPosition = positionReviseCount/7;
                        
                        for (int counter3 = 0; counter3 < outlineDataSetCount/3; counter3++){
                            if (outlineDataSet [counter3*3] == counter2){
                                arrayPositionRevise [positionReviseCount] = outlineDataSet [counter3*3+1]+horizontalStart, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = outlineDataSet [counter3*3+2]+verticalStart, positionReviseCount++;
                                
                                if (outlineDataSet [counter3*3+2]+verticalStart >= 0 && outlineDataSet [counter3*3+2]+verticalStart < imageDimension && outlineDataSet [counter3*3+1]+horizontalStart >= 0 && outlineDataSet [counter3*3+1]+horizontalStart < imageDimension){
                                    arrayPositionRevise [positionReviseCount] = sourceImage [outlineDataSet [counter3*3+2]+verticalStart][outlineDataSet [counter3*3+1]+horizontalStart], positionReviseCount++;
                                }
                                else arrayPositionRevise [positionReviseCount] = 100, positionReviseCount++;
                                
                                arrayPositionRevise [positionReviseCount] = maxVectorNumber, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = positionReviseOriginalStatus, positionReviseCount++;
                                arrayPositionRevise [positionReviseCount] = 0, positionReviseCount++;
                            }
                        }
                        
                        gravityX1 = 0;
                        gravityY1 = 0;
                        totalGRCount = 0;
                        
                        for (int counterY = 0; counterY < dimension; counterY++){
                            for (int counterX = 0; counterX < dimension; counterX++){
                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension && connectivityMap [counterY][counterX] == counter2 && internalConnectMap [counterY][counterX] == 0){
                                    revisedWorkingMap [counterY+verticalStart][counterX+horizontalStart] = maxVectorNumber;
                                    
                                    gravityX1 = gravityX1+counterX+horizontalStart;
                                    gravityY1 = gravityY1+counterY+verticalStart;
                                    totalGRCount++;
                                }
                            }
                        }
                        
                        gravityX1 = (int)(gravityX1/(double)totalGRCount);
                        gravityY1 = (int)(gravityY1/(double)totalGRCount);
                        
                        if (gravityCenterRevCount+12 > gravityCenterRevLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate gravityCenterRevUpDate];
                        }
                        
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityX1, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityY1, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = gravityCenter1 [2], gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = averageIntensity, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = maxVectorNumber, gravityCenterRevCount++;
                        arrayGravityCenterRev [gravityCenterRevCount] = 0, gravityCenterRevCount++;
                        
                        //for (int counterA = 0; counterA < timeOneGravityCenterRevCount/6; counterA++){
                        //	for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayTimeOneGravityCenterRev [counterA*6+counterB];
                        //	cout<<" arrayTimeOneGravityCenterRev "<<counterA<<endl;
                        //}
                        
                        if (associateDataCount+12 > associateDataLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate associateDataUpDate];
                        }
                        
                        arrayAssociateData [associateDataCount] = maxVectorNumber, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        arrayAssociateData [associateDataCount] = 0, associateDataCount++;
                        
                        if (timeSelectedCount+10 > timeSelectedLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate timeSelectedUpDate];
                        }
                        
                        arrayTimeSelected [timeSelectedCount] = timeSelectedOriginalStatus, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = lineEntryNumber, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = lastConnectPosition, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = maxVectorNumber, timeSelectedCount++;
                        arrayTimeSelected [timeSelectedCount] = 0, timeSelectedCount++;
                        
                        //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
                        //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
                        //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
                        //}
                    }
                }
            }
            
            delete [] outlineDataSet;
            delete [] connectedPix;
            
            for (int counter2 = 0; counter2 < dimension+1; counter2++){
                delete [] connectivityMap [counter2];
                delete [] internalConnectMap [counter2];
            }
            
            delete [] connectivityMap;
            delete [] internalConnectMap;
        }
        
        delete [] connectProcessList;
    }
    
    delete [] connectNumber;
    
    //for (int counterA = 0; counterA < positionReviseCount/7; counterA++){
    //	for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionRevise [counterA*7+counterB];
    //	cout<<" arrayPositionRevise "<<counterA<<endl;
    //}
    
    //for (int counterA = 0; counterA < timeSelectedCount/10; counterA++){
    //	for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelected [counterA*10+counterB];
    //	cout<<" arrayTimeSelected "<<counterA+1<<endl;
    //}
}

@end
