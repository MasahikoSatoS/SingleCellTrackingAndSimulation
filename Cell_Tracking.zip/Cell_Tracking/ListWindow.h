//
// ListWindow.h
// Cell_Tracking
//
// Created by Masahiko Sato on 11/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef LISTWINDOW_H
#define LISTWINDOW_H
#import "Controller.h" 
#endif

@interface ListWindow : NSView {
    int totalPageNo; //Total page no
    int boxRowNumber; //Box row number
    int boxLineNumber; //Box line number
    int boxX; //Box x
    int boxY; //Box y
    int crickCheck; //Click check
    int xPositionClick; //x Position click
    int yPositionClick; //y Position click
    int cellNoForSelect; //Cell no
    double timePointSelect; //Time point
    
    IBOutlet NSWindow *listImageWindow;
    
    NSImage *listImage;
    
    id trackingSet;
    id lineSet;
}

-(void)dealloc;
-(void)mouseDown:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;
-(BOOL)acceptsFirstResponder;
-(void)imageNoSet:(int)setNumber;

@end
