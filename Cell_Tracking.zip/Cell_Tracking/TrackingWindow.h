//
// TrackingWindow.h
// Cell_Tracking
//
// Created by Masahiko Sato on 11/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef TRACKINGWINDOW_H
#define TRACKINGWINDOW_H
#import "Controller.h"
#endif

@interface TrackingWindow : NSView {
    int mouseDragFlag; //Window control
    int xPointLine; //x Point line
    int yPointLine; //y Point line
    int previousValue; //Previous value
    int previousImageNumber; //Previous image no
    double xPositionAdjustTrack; //X Position Magnification Adjust
    double yPositionAdjustTrack; //Y Position Magnification Adjust
    double xPointDownTrack; //X Position Mouse Down
    double yPointDownTrack; //Y Position Mouse Down
    double xPointDragTrack; //X Position Mouse drag
    double yPointDragTrack; //Y Position mouse drag
    double xPositionMoveTrack; //X Position Total Move by Drag
    double yPositionMoveTrack; //Y Position Total Move by Drag
    
    IBOutlet NSWindow *trackingImageWindow;
    
    NSImage *trackingImage;
    
    id trackingSet;
    id trackingDataSave;
    id eventSet;
    id lineSet;
    id targetFind2;
    id merge;
    id expandLine;
    id fileUpdate;
    id dataSaveRead;
}

-(void)dealloc;
-(void)mergeExtend:(int)groupNoMerge;
-(void)mergeExtendTrack:(int)groupNoMerge;

-(void)mouseDown:(NSEvent *)event;
-(void)mouseUp:(NSEvent *)event;
-(void)mouseDragged:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;

-(BOOL)acceptsFirstResponder;

@end
