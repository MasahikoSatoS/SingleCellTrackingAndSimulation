//
//  ExpandLine.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-01-26.
//
//

#ifndef EXPANDLINE_H
#define EXPANDLINE_H
#import "Controller.h" 
#endif


@interface ExpandLine : NSObject{
    id fileUpdate;
}

-(int)lineExtendTrackType1:(int)groupNoMerge;
-(int)lineExtendTrackType2:(int)groupNoMerge;
-(int)lineExtendTrackType3:(int)groupNoMerge;

@end
