//
//  ExportController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2018-01-23.
//
//

#import "ExportController.h"

NSString *notificationToExportController = @"notificationExecutExportController";

@implementation ExportController

-(id)init{
    self = [super init];
    
    if (self != nil){
        xPositionExHold = 0;
        yPositionExHold = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToExportController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    exportMainWindowController = [[NSWindowController alloc] initWithWindowNibName:@"ExportWindow"];
    [exportMainWindowController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToExportDisplay object:nil];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [exportMainWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [exportMainWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [exportStartDisplay setDelegate:self];
    [exportEndDisplay setDelegate:self];
    [titleNameHoldDisplay setDelegate:self];
    [densityDiameterDisplay setDelegate:self];
    [densityMaxDisplay setDelegate:self];
    [lineageLimitDisplay setDelegate:self];
    [thresholdCutOffDisplay setDelegate:self];
    [areaSizeMinDisplay setDelegate:self];
    [areaSizeMaxDisplay setDelegate:self];
    
    exportMainTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (timingEx == 1){
        [backSave startAnimation:self];
        
        if (backSave) timingEx = 2;
    }
    else if (timingEx == 3){
        [backSave stopAnimation:self];
        
        if (backSave) timingEx = 0;
    }
    
    
    if (xyPositionCall == 1){
        xyPositionCall = 2;
        
        [xPositionDisplay setIntegerValue:xPositionExHold];
        [yPositionDisplay setIntegerValue:yPositionExHold];
    }
    else if (xyPositionCall == 2){
        if ([xPositionDisplay intValue] == xPositionExHold && [yPositionDisplay intValue] == yPositionExHold){
            xyPositionCall = 0;
        }
        else{
            
            [xPositionDisplay setIntegerValue:xPositionExHold];
            [yPositionDisplay setIntegerValue:yPositionExHold];
        }
    }
}

-(void)controlTextDidChange:(NSNotification *)aNotification {
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        int maxImageNo = 0;
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            if (arrayTreatmentStatus [counter1*9] == treatmentNameHold){
                maxImageNo = atoi(arrayTreatmentStatus [counter1*9+8].c_str());
                break;
            }
        }
        
        if ([aNotification object] == exportStartDisplay){
            if ([exportStartDisplay intValue] >= 1 && [exportStartDisplay intValue] <= maxImageNo-1){
                startExport = [exportStartDisplay intValue];
                
                if (startExport > endExport){
                    endExport = 0;
                    [exportEndDisplay setIntegerValue:0];
                }
            }
            else [exportStartDisplay setIntegerValue:1];
        }
        
        if ([aNotification object] == exportEndDisplay){
            if ([exportEndDisplay intValue] >= 1){
                endExport = [exportEndDisplay intValue];
                
                if (endExport > maxImageNo){
                    endExport = maxImageNo;
                    [exportEndDisplay setIntegerValue:maxImageNo];
                }
            }
            else{
                
                endExport = 0;
                [exportEndDisplay setIntegerValue:0];
            }
        }
        
        if ([aNotification object] == titleNameHoldDisplay){
            string inputTemp = [[titleNameHoldDisplay stringValue] UTF8String];
            
            if ((int)inputTemp.length () < 15){
                titleNameExportHold = inputTemp;
            }
            else{
                
                titleNameExportHold = "";
                [titleNameHoldDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == densityDiameterDisplay){
            int inputTemp = [[densityDiameterDisplay stringValue] intValue];
            
            if (inputTemp < 5000){
                int oddFind = inputTemp%2;
                
                if (oddFind == 0) densityDiameterHold = inputTemp+1;
                else densityDiameterHold = inputTemp;
            }
            else{
                
                densityDiameterHold = 0;
                [densityDiameterDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == densityMaxDisplay){
            int inputTemp = [[densityMaxDisplay stringValue] intValue];
            
            if (inputTemp < 5000){
                densityValueMaxHold = inputTemp;
            }
            else{
                
                densityValueMaxHold = 0;
                [densityMaxDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == lineageLimitDisplay){
            int inputTemp = [[lineageLimitDisplay stringValue] intValue];
            
            if (inputTemp < 5000) lineageLimitHold = inputTemp;
            else{
                
                lineageLimitHold = 0;
                [lineageLimitDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == thresholdCutOffDisplay){
            int inputTemp = [[thresholdCutOffDisplay stringValue] intValue];
            
            if (inputTemp >= 0 && inputTemp < 255) thresholdCutHold = inputTemp;
            else{
                
                thresholdCutHold = 0;
                [thresholdCutOffDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == areaSizeMinDisplay){
            int inputTemp = [[areaSizeMinDisplay stringValue] intValue];
            
            if (inputTemp >= 0 && inputTemp < 20000) areaSizeMinHold = inputTemp;
            else{
                
                areaSizeMinHold = 0;
                [areaSizeMinDisplay setStringValue:@""];
            }
        }
        
        if ([aNotification object] == areaSizeMaxDisplay){
            int inputTemp = [[areaSizeMaxDisplay stringValue] intValue];
            
            if (inputTemp >= 0 && inputTemp < 20000) areaSizeMaxHold = inputTemp;
            else{
                
                areaSizeMaxHold = 0;
                [areaSizeMaxDisplay setStringValue:@""];
            }
        }
    }
}

-(IBAction)channelNoSet:(id)sender{
    if (channelNoExport == 0) channelNoExport = 1;
    else if (channelNoExport == 1) channelNoExport = 2;
    else if (channelNoExport == 2) channelNoExport = 3;
    else if (channelNoExport == 3) channelNoExport = 4;
    else if (channelNoExport == 4) channelNoExport = 5;
    else if (channelNoExport == 5) channelNoExport = 6;
    else if (channelNoExport == 6) channelNoExport = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)outlineWidthSet:(id)sender{
    if (outlineWidthExport == 1){
        outlineWidthExport = 2;
        [outLineWidthDisplay setStringValue:@"2 pix"];
    }
    else if (outlineWidthExport == 2){
        outlineWidthExport = 3;
        [outLineWidthDisplay setStringValue:@"3 pix"];
    }
    else if (outlineWidthExport == 3){
        outlineWidthExport = 4;
        [outLineWidthDisplay setStringValue:@"4 pix"];
    }
    else if (outlineWidthExport == 4){
        outlineWidthExport = 5;
        [outLineWidthDisplay setStringValue:@"5 pix"];
    }
    else if (outlineWidthExport == 5){
        outlineWidthExport = 6;
        [outLineWidthDisplay setStringValue:@"8 pix"];
    }
    else if (outlineWidthExport == 6){
        outlineWidthExport = 7;
        [outLineWidthDisplay setStringValue:@"10 pix"];
    }
    else if (outlineWidthExport == 7){
        outlineWidthExport = 8;
        [outLineWidthDisplay setStringValue:@"15 pix"];
    }
    else if (outlineWidthExport == 8){
        outlineWidthExport = 9;
        [outLineWidthDisplay setStringValue:@"0 pix"];
    }
    else if (outlineWidthExport == 9){
        outlineWidthExport = 10;
        [outLineWidthDisplay setStringValue:@"0.5 pix"];
    }
    else if (outlineWidthExport == 10){
        outlineWidthExport = 1;
        [outLineWidthDisplay setStringValue:@"1 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nonTargetWidthSet:(id)sender{
    if (nonTargetWidthExport == 1){
        nonTargetWidthExport = 2;
        [nonTargetWidthDisplay setStringValue:@"0.5 pix"];
    }
    else if (nonTargetWidthExport == 2){
        nonTargetWidthExport = 3;
        [nonTargetWidthDisplay setStringValue:@"1.0 pix"];
    }
    else if (nonTargetWidthExport == 3){
        nonTargetWidthExport = 4;
        [nonTargetWidthDisplay setStringValue:@"1.5 pix"];
    }
    else if (nonTargetWidthExport == 4){
        nonTargetWidthExport = 5;
        [nonTargetWidthDisplay setStringValue:@"2.0 pix"];
    }
    else if (nonTargetWidthExport == 5){
        nonTargetWidthExport = 6;
        [nonTargetWidthDisplay setStringValue:@"4.0 pix"];
    }
    else if (nonTargetWidthExport == 6){
        nonTargetWidthExport = 7;
        [nonTargetWidthDisplay setStringValue:@"6.0 pix"];
    }
    else if (nonTargetWidthExport == 7){
        nonTargetWidthExport = 8;
        [nonTargetWidthDisplay setStringValue:@"8.0 pix"];
    }
    else if (nonTargetWidthExport == 8){
        nonTargetWidthExport = 9;
        [nonTargetWidthDisplay setStringValue:@"0 pix"];
    }
    else if (nonTargetWidthExport == 9){
        nonTargetWidthExport = 1;
        [nonTargetWidthDisplay setStringValue:@"0.1 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nonTargetLengthSet:(id)sender{
    if (nonTargetLengthExport == 1){
        nonTargetLengthExport = 2;
        [nonTargetLengthDisplay setStringValue:@"10 pix"];
    }
    else if (nonTargetLengthExport == 2){
        nonTargetLengthExport = 3;
        [nonTargetLengthDisplay setStringValue:@"20 pix"];
    }
    else if (nonTargetLengthExport == 3){
        nonTargetLengthExport = 4;
        [nonTargetLengthDisplay setStringValue:@"30 pix"];
    }
    else if (nonTargetLengthExport == 4){
        nonTargetLengthExport = 5;
        [nonTargetLengthDisplay setStringValue:@"40 pix"];
    }
    else if (nonTargetLengthExport == 5){
        nonTargetLengthExport = 6;
        [nonTargetLengthDisplay setStringValue:@"50 pix"];
    }
    else if (nonTargetLengthExport == 6){
        nonTargetLengthExport = 7;
        [nonTargetLengthDisplay setStringValue:@"70 pix"];
    }
    else if (nonTargetLengthExport == 7){
        nonTargetLengthExport = 8;
        [nonTargetLengthDisplay setStringValue:@"100 pix"];
    }
    else if (nonTargetLengthExport == 8){
        nonTargetLengthExport = 9;
        [nonTargetLengthDisplay setStringValue:@"0 pix"];
    }
    else if (nonTargetLengthExport == 9){
        nonTargetLengthExport = 1;
        [nonTargetLengthDisplay setStringValue:@"5 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nonTargetFontSet:(id)sender{
    if (nonTargetFontExport == 1){
        nonTargetFontExport = 2;
        [nonTargetFontDisplay setStringValue:@"12 F"];
    }
    else if (nonTargetFontExport == 2){
        nonTargetFontExport = 3;
        [nonTargetFontDisplay setStringValue:@"18 F"];
    }
    else if (nonTargetFontExport == 3){
        nonTargetFontExport = 4;
        [nonTargetFontDisplay setStringValue:@"24 F"];
    }
    else if (nonTargetFontExport == 4){
        nonTargetFontExport = 5;
        
        [nonTargetFontDisplay setStringValue:@"30 F"];
    }
    else if (nonTargetFontExport == 5){
        nonTargetFontExport = 6;
        [nonTargetFontDisplay setStringValue:@"40 F"];
    }
    else if (nonTargetFontExport == 6){
        nonTargetFontExport = 7;
        [nonTargetFontDisplay setStringValue:@"50 F"];
    }
    else if (nonTargetFontExport == 7){
        nonTargetFontExport = 8;
        [nonTargetFontDisplay setStringValue:@"60 F"];
    }
    else if (nonTargetFontExport == 8){
        nonTargetFontExport = 9;
        [nonTargetFontDisplay setStringValue:@"0 F"];
    }
    else if (nonTargetFontExport == 9){
        nonTargetFontExport = 1;
        [nonTargetFontDisplay setStringValue:@"6 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)targetWidthSet:(id)sender{
    if (targetWidthExport == 1){
        targetWidthExport = 2;
        [targetWidthDisplay setStringValue:@"0.5 pix"];
    }
    else if (targetWidthExport == 2){
        targetWidthExport = 3;
        [targetWidthDisplay setStringValue:@"1.0 pix"];
    }
    else if (targetWidthExport == 3){
        targetWidthExport = 4;
        [targetWidthDisplay setStringValue:@"1.5 pix"];
    }
    else if (targetWidthExport == 4){
        targetWidthExport = 5;
        [targetWidthDisplay setStringValue:@"2.0 pix"];
    }
    else if (targetWidthExport == 5){
        targetWidthExport = 6;
        [targetWidthDisplay setStringValue:@"4.0 pix"];
    }
    else if (targetWidthExport == 6){
        targetWidthExport = 7;
        [targetWidthDisplay setStringValue:@"6.0 pix"];
    }
    else if (targetWidthExport == 7){
        targetWidthExport = 8;
        [targetWidthDisplay setStringValue:@"8.0 pix"];
    }
    else if (targetWidthExport == 8){
        targetWidthExport = 9;
        [targetWidthDisplay setStringValue:@"0 pix"];
    }
    else if (targetWidthExport == 9){
        targetWidthExport = 1;
        [targetWidthDisplay setStringValue:@"0.1 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)targetLengthSet:(id)sender{
    if (targetLengthExport == 1){
        targetLengthExport = 2;
        [targetLengthDisplay setStringValue:@"10 pix"];
    }
    else if (targetLengthExport == 2){
        targetLengthExport = 3;
        [targetLengthDisplay setStringValue:@"20 pix"];
    }
    else if (targetLengthExport == 3){
        targetLengthExport = 4;
        [targetLengthDisplay setStringValue:@"30 pix"];
    }
    else if (targetLengthExport == 4){
        targetLengthExport = 5;
        [targetLengthDisplay setStringValue:@"40 pix"];
    }
    else if (targetLengthExport == 5){
        targetLengthExport = 6;
        [targetLengthDisplay setStringValue:@"50 pix"];
    }
    else if (targetLengthExport == 6){
        targetLengthExport = 7;
        [targetLengthDisplay setStringValue:@"70 pix"];
    }
    else if (targetLengthExport == 7){
        targetLengthExport = 8;
        [targetLengthDisplay setStringValue:@"100 pix"];
    }
    else if (targetLengthExport == 8){
        targetLengthExport = 9;
        [targetLengthDisplay setStringValue:@"0 pix"];
    }
    else if (targetLengthExport == 9){
        targetLengthExport = 1;
        [targetLengthDisplay setStringValue:@"5 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)targetFontSet:(id)sender{
    if (targetFontExport == 1){
        targetFontExport = 2;
        [targetFontDisplay setStringValue:@"12 F"];
    }
    else if (targetFontExport == 2){
        targetFontExport = 3;
        [targetFontDisplay setStringValue:@"18 F"];
    }
    else if (targetFontExport == 3){
        targetFontExport = 4;
        [targetFontDisplay setStringValue:@"24 F"];
    }
    else if (targetFontExport == 4){
        targetFontExport = 5;
        [targetFontDisplay setStringValue:@"30 F"];
    }
    else if (targetFontExport == 5){
        targetFontExport = 6;
        [targetFontDisplay setStringValue:@"40 F"];
    }
    else if (targetFontExport == 6){
        targetFontExport = 7;
        [targetFontDisplay setStringValue:@"50 F"];
    }
    else if (targetFontExport == 7){
        targetFontExport = 8;
        [targetFontDisplay setStringValue:@"60 F"];
    }
    else if (targetFontExport == 8){
        targetFontExport = 9;
        [targetFontDisplay setStringValue:@"0 F"];
    }
    else if (targetFontExport == 9){
        targetFontExport = 1;
        [targetFontDisplay setStringValue:@"6 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)titleFontSet:(id)sender{
    if (titleFontExport == 1){
        titleFontExport = 2;
        [titleFontDisplay setStringValue:@"18 F"];
    }
    else if (titleFontExport == 2){
        titleFontExport = 3;
        [titleFontDisplay setStringValue:@"24 F"];
    }
    else if (titleFontExport== 3){
        titleFontExport = 4;
        [titleFontDisplay setStringValue:@"30 F"];
    }
    else if (titleFontExport == 4){
        titleFontExport = 5;
        [titleFontDisplay setStringValue:@"40 F"];
    }
    else if (titleFontExport == 5){
        titleFontExport = 6;
        [titleFontDisplay setStringValue:@"50 F"];
    }
    else if (titleFontExport == 6){
        titleFontExport = 7;
        [titleFontDisplay setStringValue:@"60 F"];
    }
    else if (titleFontExport == 7){
        titleFontExport = 8;
        [titleFontDisplay setStringValue:@"80 F"];
    }
    else if (titleFontExport == 8){
        titleFontExport = 9;
        [titleFontDisplay setStringValue:@"0 F"];
    }
    else if (titleFontExport == 9){
        titleFontExport = 10;
        [titleFontDisplay setStringValue:@"6 F"];
    }
    else if (titleFontExport == 10){
        titleFontExport = 11;
        [titleFontDisplay setStringValue:@"8 F"];
    }
    else if (titleFontExport == 11){
        titleFontExport = 1;
        [titleFontDisplay setStringValue:@"12 F"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)titleDisplaySet:(id)sender{
    if (titleNameExport == 0){
        titleNameExport = 1;
        [titleNameDisplay setStringValue:@"No"];
    }
    else if (titleNameExport == 1){
        titleNameExport = 0;
        [titleNameDisplay setStringValue:@"Yes"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)refreshSet:(id)sender{
    outlineWidthExport = 1;
    [outLineWidthDisplay setStringValue:@"1 pix"];
    
    nonTargetWidthExport = 5;
    [nonTargetWidthDisplay setStringValue:@"2.0 pix"];
    
    nonTargetLengthExport = 2;
    [nonTargetLengthDisplay setStringValue:@"10 pix"];
    
    nonTargetFontExport = 2;
    [nonTargetFontDisplay setStringValue:@"12 F"];
    
    targetWidthExport = 5;
    [targetWidthDisplay setStringValue:@"2.0 pix"];
    
    targetLengthExport = 2;
    [targetLengthDisplay setStringValue:@"10 pix"];
    
    targetFontExport = 2;
    [targetFontDisplay setStringValue:@"12 F"];
    
    titleFontExport = 4;
    [titleFontDisplay setStringValue:@"30 F"];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)linePrintColorSet:(id)sender{
    if (lineageFontColorExport == 0){
        lineageFontColorExport = 1;
        [titleFontColorDisplay setStringValue:@"WH"];
    }
    else if (lineageFontColorExport == 1){
        lineageFontColorExport = 2;
        [titleFontColorDisplay setStringValue:@"YL"];
    }
    else if (lineageFontColorExport == 2){
        lineageFontColorExport = 3;
        [titleFontColorDisplay setStringValue:@"BU"];
    }
    else if (lineageFontColorExport == 3){
        lineageFontColorExport = 4;
        [titleFontColorDisplay setStringValue:@"BL"];
    }
    else if (lineageFontColorExport == 4){
        lineageFontColorExport = 5;
        [titleFontColorDisplay setStringValue:@"RD"];
    }
    else if (lineageFontColorExport == 5){
        lineageFontColorExport = 0;
        [titleFontColorDisplay setStringValue:@"OR"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)displayModeForOutline:(id)sender{
    if (displayOutlineSet == 0){
        displayOutlineSet = 1;
        [modeForOutlineDisplay setStringValue:@"On"];
    }
    else if (displayOutlineSet == 1){
        displayOutlineSet = 0;
        [modeForOutlineDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)displayModeForNonTarget:(id)sender{
    if (displayNonTargetSet == 0){
        displayNonTargetSet = 1;
        [modeForNonTargetDisplay setStringValue:@"On"];
    }
    else if (displayNonTargetSet == 1){
        displayNonTargetSet = 0;
        [modeForNonTargetDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)DisplayModeForTargetFontSize:(id)sender{
    if (displayTargetFontSizeSet == 1){
        displayTargetFontSizeSet = 1.5;
        [modeForFontDisplay setStringValue:@"x1.5"];
    }
    else if (displayTargetFontSizeSet == 2){
        displayTargetFontSizeSet = 2;
        [modeForFontDisplay setStringValue:@"x2"];
    }
    else if (displayTargetFontSizeSet == 3){
        displayTargetFontSizeSet = 2.5;
        [modeForFontDisplay setStringValue:@"x2.5"];
    }
    else if (displayTargetFontSizeSet == 4){
        displayTargetFontSizeSet = 3;
        [modeForFontDisplay setStringValue:@"x3"];
    }
    else if (displayTargetFontSizeSet == 5){
        displayTargetFontSizeSet = 1;
        [modeForFontDisplay setStringValue:@"x1"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}


-(IBAction)exportNoOFCellsInArea:(id)sender{
    if (noOfCellsInAreaStatus == 1){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string nameString = "Export_Images-CA";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("CA")+2);
                    
                    if ((int)extractString.find(".txt") == -1) extractString = extractString.substr(0, entry.find(".txt"));
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string exportCellAreaSavePath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
        
        ofstream oin;
        oin.open(exportCellAreaSavePath.c_str(), ios::out);
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "X-Pixels";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Y-Pixels";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = to_string(noOfCellsInArea [1]);
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = to_string(noOfCellsInArea [1]);
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        oin.put(13);
        oin.put(10);
        
        ascIIstring = "Image no";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "No of Cells";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < noOfCellsInAreaCount/4; counter1++){
            ascIIstring = to_string(noOfCellsInArea [counter1*4]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = to_string(noOfCellsInArea [counter1*4+3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.close();
        
        delete [] arrayAscIIintData;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Cell/Area Data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)exportDensityData:(id)sender{
    if (densityModeHold == 1 && displayImageLoadPath != ""){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string nameString = "Export_Images-DN";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("DN")+2);
                    
                    if ((int)extractString.find(".txt") == -1) extractString = extractString.substr(0, entry.find(".txt"));
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string exportCellAreaSavePath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
        
        if (densityModeHold == 1){
            if (circleAreaHoldStatus == 1){
                for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++) delete [] circleAreaHold [counter1];
                delete [] circleAreaHold;
            }
            
            circleAreaHold = new int *[densityDiameterHold+2];
            
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                circleAreaHold [counter1] = new int [densityDiameterHold+2];
            }
            
            circleAreaHoldStatus = 1;
            
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                    circleAreaHold [counter1][counter2] = 0;
                }
            }
            
            int center2 = (densityDiameterHold/2)+1;
            double radius = densityDiameterHold/(double)2;
            double diameterCal = 0;
            
            for (int counter1 = 0; counter1 < densityDiameterHold+2; counter1++){
                for (int counter2 = 0; counter2 <densityDiameterHold+2; counter2++){
                    diameterCal = (counter1-center2)*(counter1-center2)+(counter2-center2)*(counter2-center2);
                    
                    if (sqrt(diameterCal) <= radius) circleAreaHold [counter1][counter2] = 1;
                }
            }
        }
        
        int imageNoEx = atoi(displayImageLoadPath.substr(displayImageLoadPath.find("STimage ")+8, 4).c_str());
        int xPointMarkTemp = 0;
        int yPointMarkTemp = 0;
        int xImageStart = -1;
        int yImageStart = -1;
        int xImageEnd = -1;
        int yImageEnd = -1;
        int xImageSizeEX = 0;
        int yImageSizeEX = 0;
        
        if (windowLockEX == 1){
            if (boxStartImageX > boxEndImageX && boxStartImageX-boxEndImageX > 100){
                xImageStart = (int)boxEndImageX;
                xImageEnd = (int)boxStartImageX;
                xImageSizeEX = (int)(boxStartImageX-boxEndImageX);
            }
            else if (boxStartImageX <= boxEndImageX && boxEndImageX-boxStartImageX > 100){
                xImageStart = (int)boxStartImageX;
                xImageEnd = (int)boxEndImageX;
                xImageSizeEX = (int)(boxEndImageX-boxStartImageX);
            }
            
            if (boxStartImageY > boxEndImageY && boxStartImageY-boxEndImageY > 100){
                yImageEnd = (int)(imageDimension-boxEndImageY);
                yImageStart = (int)(imageDimension-boxStartImageY);
                yImageSizeEX = (int)(boxStartImageY-boxEndImageY);
            }
            else if (boxStartImageY <= boxEndImageY && boxEndImageY-boxStartImageY > 100){
                yImageEnd = (int)(imageDimension-boxStartImageY);
                yImageStart = (int)(imageDimension-boxEndImageY);
                yImageSizeEX = (int)(boxEndImageY-boxStartImageY);
            }
        }
        
        if (xImageStart == -1 || yImageStart == -1 || xImageEnd == -1 || yImageEnd == -1){
            xImageStart = 0;
            yImageStart = 0;
            xImageSizeEX = imageDimension;
            yImageSizeEX = imageDimension;
        }
        
        int center = (densityDiameterHold/2)+1;
        int **densityMapHold = new int *[yImageSizeEX+1];
        
        for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
            densityMapHold [counter1] = new int [xImageSizeEX+1];
        }
        
        for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
            for (int counter2 = 0; counter2 < xImageSizeEX+1; counter2++){
                densityMapHold [counter1][counter2] = 0;
            }
        }
        
        int maxEntry = lineageStartEndCount/8;
        
        int *lineageListExp = new int [maxEntry*4+1];
        int lineageListCountExp = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (imageNoEx >= arrayLineageStartEnd [counter1*8+5] && imageNoEx <= arrayLineageStartEnd [counter1*8+7]){
                lineageListExp [lineageListCountExp] = arrayLineageStartEnd [counter1*8], lineageListCountExp++;
                lineageListExp [lineageListCountExp] = arrayLineageStartEnd [counter1*8+1], lineageListCountExp++;
                lineageListExp [lineageListCountExp] = 0, lineageListCountExp++;
                lineageListExp [lineageListCountExp] = 0, lineageListCountExp++;
                
                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                    xPointMarkTemp = arrayLineageData [counter2*8]-xImageStart;
                    yPointMarkTemp = imageHeightExport-(arrayLineageData [counter2*8+1]+yImageStart);
                    
                    if (arrayLineageData [counter2*8+2] == imageNoEx && arrayLineageData [counter2*8+3] != 13){
                        if (densityModeHold == 1){
                            for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                    if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                        densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4]++;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        int entryCount = 0;
        int pointCount = 0;
        
        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
            if (imageNoEx >= arrayLineageStartEnd [counter1*8+5] && imageNoEx <= arrayLineageStartEnd [counter1*8+7]){
                pointCount = 0;
                
                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                    xPointMarkTemp = arrayLineageData [counter2*8]-xImageStart;
                    yPointMarkTemp = imageHeightExport-(arrayLineageData [counter2*8+1]+yImageStart);
                    
                    if (arrayLineageData [counter2*8+2] == imageNoEx && arrayLineageData [counter2*8+3] != 13){
                        if (densityModeHold == 1){
                            for (int counter3 = 1; counter3 <= densityDiameterHold; counter3++){
                                for (int counter4 = 1; counter4 <= densityDiameterHold; counter4++){
                                    if (xPointMarkTemp-center+counter4 >= 0 && xPointMarkTemp-center+counter4 < xImageSizeEX && yPointMarkTemp-center+counter3 >= 0 && yPointMarkTemp-center+counter3 < yImageSizeEX && circleAreaHold [counter3][counter4] == 1){
                                        lineageListExp [entryCount*4+2] = lineageListExp [entryCount*4+2]+densityMapHold [yPointMarkTemp-center+counter3][xPointMarkTemp-center+counter4];
                                        pointCount++;
                                    }
                                }
                            }
                        }
                    }
                }
                
                lineageListExp [entryCount*4+3] = pointCount;
                entryCount++;
            }
        }
        
        //for (int counterA = 0; counterA < lineageListCountExp/4; counterA++){
        //    cout<<lineageListExp [counterA*4]<<" "<<lineageListExp [counterA*4+1]<<" "<<lineageListExp [counterA*4+2]<<" "<<lineageListExp [counterA*4+3]<<" Lineage"<<endl;
        //}
        
        ofstream oin;
        oin.open(exportCellAreaSavePath.c_str(), ios::out);
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "Lineage No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Cell No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Density";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        for (int counter1 = 0; counter1 < lineageListCountExp/4; counter1++){
            ascIIstring = to_string(lineageListExp [counter1*4]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = to_string(lineageListExp [counter1*4+1]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = to_string(lineageListExp [counter1*4+2]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            ascIIstring = to_string(lineageListExp [counter1*4+3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.close();
        
        for (int counter1 = 0; counter1 < yImageSizeEX+1; counter1++){
            delete [] densityMapHold [counter1];
        }
        
        delete [] densityMapHold;
        
        delete [] arrayAscIIintData;
        delete [] lineageListExp;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Density Mode Off/Perform S"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineTraceFunctionOnOff:(id)sender{
    if (lineTraceOnOff == 0){
        if (lineTraceStatus == 0){
            string treatmentNameTemp = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+"*LineTrace.dat";
            string getString;
            
            ifstream fin;
            
            fin.open(treatmentNameTemp.c_str(), ios::in);
            
            if (fin.is_open()){
                int entryCount = 0;
                
                do{
                    
                    getline(fin, getString);
                    
                    if (getString != "End"){
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        getline(fin, getString);
                        arrayLineTrace [entryCount] = getString, entryCount++;
                        
                        if (entryCount+80 > lineTraceLimit){
                            string *arrayUpDate = new string [entryCount+10];
                            
                            for (int counter1 = 0; counter1 < entryCount; counter1++) arrayUpDate [counter1] = arrayLineTrace [counter1];
                            
                            delete [] arrayLineTrace;
                            arrayLineTrace = new string [lineTraceLimit+8000];
                            lineTraceLimit = lineTraceLimit+8000;
                            
                            for (int counter1 = 0; counter1 < entryCount; counter1++) arrayLineTrace [counter1] = arrayUpDate [counter1];
                            delete [] arrayUpDate;
                        }
                    }
                    
                } while (getString != "End");
                
                lineTraceStatus = 1;
                lineTraceCount = entryCount;
               
                fin.close();
            }
        }
        
        [lineTraceStatusDisplay setStringValue:@"On"];
        lineTraceOnOff = 1;
        
        lineTraceStartX = -1;
        lineTraceStartY = -1;
        lineTraceStartTimePoint = -1;
        lineTraceEndX = -1;
        lineTraceEndY = -1;
        lineTraceEndTimePoint = -1;
        lineTraceActive = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        [lineTraceStatusDisplay setStringValue:@"Off"];
        lineTraceOnOff = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)stepperTraceLineColorSet:(id)sender{
    if ([stepperTraceLineColor intValue] >= 0 && [stepperTraceLineColor intValue] <= 72){
        lineExportColor = [stepperTraceLineColor intValue];
        [traceLineColorDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [lineExportColor] green:arrayColorRange [lineExportColor+1] blue:arrayColorRange [lineExportColor+2] alpha:1]];
        
        [traceLineColorDisplay setStringValue:@"Line Color:"];
    }
}

-(IBAction)traceLineWidthSet:(id)sender{
    if (lineExportWidth == 0){
        lineExportWidth = 1;
        [traceLineWidthDisplay setStringValue:@"2 pix"];
    }
    else if (lineExportWidth == 1){
        lineExportWidth = 2;
        [traceLineWidthDisplay setStringValue:@"3 pix"];
    }
    else if (lineExportWidth == 2){
        lineExportWidth = 3;
        [traceLineWidthDisplay setStringValue:@"4 pix"];
    }
    else if (lineExportWidth == 3){
        lineExportWidth = 4;
        [traceLineWidthDisplay setStringValue:@"5 pix"];
    }
    else if (lineExportWidth == 4){
        lineExportWidth = 5;
        [traceLineWidthDisplay setStringValue:@"6 pix"];
    }
    else if (lineExportWidth == 5){
        lineExportWidth = 6;
        [traceLineWidthDisplay setStringValue:@"7 pix"];
    }
    else if (lineExportWidth == 6){
        lineExportWidth = 7;
        [traceLineWidthDisplay setStringValue:@"8 pix"];
    }
    else if (lineExportWidth == 7){
        lineExportWidth = 8;
        [traceLineWidthDisplay setStringValue:@"9 pix"];
    }
    else if (lineExportWidth == 8){
        lineExportWidth = 9;
        [traceLineWidthDisplay setStringValue:@"10 pix"];
    }
    else if (lineExportWidth == 9){
        lineExportWidth = 0;
        [traceLineWidthDisplay setStringValue:@"1 pix"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)exportLineTraceData:(id)sender{
    if (lineTraceOnOff == 1){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Export_Images";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string nameString = "Export_Images-LT";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        int maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("LT")+2);
                    
                    if ((int)extractString.find(".txt") == -1) extractString = extractString.substr(0, entry.find(".txt"));
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string exportCellAreaSavePath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
        
        ofstream oin;
        oin.open(exportCellAreaSavePath.c_str(), ios::out);
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "Treatment";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Start X";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Start Y";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "End X";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "End Y";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "No Of Time point";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Distance";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Distance per Time";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        int numberOfTimePoint = 0;
        double distance = 0;
        int distanceInt = 0;
        string distsnceExport;
        
        //for (int counterA = 0; counterA < lineTraceCount/8; counterA++){
        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineTrace [counterA*8+counterB];
        //    cout<<" arrayLineTrace "<<counterA+1<<endl;
        //}
        
        for (int counter1 = 0; counter1 < lineTraceCount/8; counter1++){
            if (treatmentNameHold == arrayLineTrace [counter1*8+6] && arrayLineTrace [counter1*8+7] == "s"){
                ascIIstring = arrayLineTrace [counter1*8+6];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayLineTrace [counter1*8];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayLineTrace [counter1*8+1];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayLineTrace [counter1*8+3];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayLineTrace [counter1*8+4];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                numberOfTimePoint = atoi(arrayLineTrace [counter1*8+2].c_str())-atoi(arrayLineTrace [counter1*8+5].c_str());
                
                if (numberOfTimePoint < 0) numberOfTimePoint = numberOfTimePoint*-1;
                
                ascIIstring = to_string(numberOfTimePoint);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                distance = sqrt((atoi(arrayLineTrace [counter1*8].c_str())-atoi(arrayLineTrace [counter1*8+3].c_str()))*(atoi(arrayLineTrace [counter1*8].c_str())-atoi(arrayLineTrace [counter1*8+3].c_str()))+(atoi(arrayLineTrace [counter1*8+1].c_str())-atoi(arrayLineTrace [counter1*8+4].c_str()))*(atoi(arrayLineTrace [counter1*8+1].c_str())-atoi(arrayLineTrace [counter1*8+4].c_str())));
                
                distanceInt = (int)(distance*100);
                distance = distanceInt/(double)100;
                
                stringstream extension1;
                extension1 << distance;
                distsnceExport = extension1.str();
                
                ascIIstring = distsnceExport;
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                if (numberOfTimePoint != 0){
                    distance = distance/(double)numberOfTimePoint;
                    
                    distanceInt = (int)(distance*100);
                    distance = distanceInt/(double)100;
                }
                else distance = 0;
                
                stringstream extension2;
                extension2 << distance;
                distsnceExport = extension2.str();
                
                ascIIstring = distsnceExport;
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
        }
        
        oin.close();
        
        delete [] arrayAscIIintData;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Line Trace Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)reDisplayWindow{
    if (exportOperation == 3){
        [exportMainWindow makeKeyAndOrderFront:nil];
        exportOperation = 1;
        [exportMainTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [exportMainWindow orderOut:nil];
    exportOperation = 2;
    exportMainTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToExportController object:nil];
}

@end
