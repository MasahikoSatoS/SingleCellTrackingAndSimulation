//
//  ImageSequenceDisplayController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/2/17.
//
//

#ifndef IMAGESEQUENCEDISPLAYCONTROLLER_H
#define IMAGESEQUENCEDISPLAYCONTROLLER_H
#import "Controller.h" 
#endif

@interface ImageSequenceDisplayController : NSObject{
    IBOutlet NSTextField *seqWindowNoDisplay;
    IBOutlet NSTextField *imageWidthDisplay;
    
    IBOutlet NSWindow *imageSeqWindow;
    
    NSWindowController *imageSeqWindowController;
    
    NSTimer *imageSeqTimer;
    NSTimer *imageSeqTimer2;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)displayWindow;

-(IBAction)closeWindow:(id)sender;
-(IBAction)forwardSeq:(id)sender;
-(IBAction)backSeq:(id)sender;
-(IBAction)displayNoChange:(id)sender;
-(IBAction)imageWidthChange:(id)sender;

@end
