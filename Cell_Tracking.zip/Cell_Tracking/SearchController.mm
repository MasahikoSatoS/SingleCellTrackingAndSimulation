//
//  SearchController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-11-30.
//
//

#import "SearchController.h"

NSString *notificationToSearchController = @"notificationExecuteSearchController";

@implementation SearchController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSearchController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    searchWindowController = [[NSWindowController alloc] initWithWindowNibName:@"ListSearch"];
    [searchWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchOperations object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [searchWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [searchWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)closeWindow:(id)sender{
    [searchWindow orderOut:self];
    searchWindowOperation = 2;
    searchTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (searchWindowOperation == 3){
        [searchWindow makeKeyAndOrderFront:self];
        searchWindowOperation = 1;
        [searchTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSearchController object:nil];
}

@end
