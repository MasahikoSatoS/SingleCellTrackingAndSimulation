//
//  DatabaseRepairController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 12/6/16.
//
//

#import "DatabaseRepairController.h"

NSString *notificationToDatabaseRepairController = @"notificationExecuteDatabaseRepairController";

@implementation DatabaseRepairController

-(id)init{
    self = [super init];
    
    if (self != nil){
        verDisplayCall = 0;
        allErrorHold = 0;
        timePointValueHold = 0;
        verificationStopFlag = 0;
        checkOverrideFlag = 0;
        treatmentDoFlag = 0;
        onlyErrorFlag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDatabaseRepairController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    connectForVerifyHold = 0;
    dataTypeSend = 0;
    listArrayStatusHold = 0;
    errorNumberHold = 0;
    errorTimeModeHold = 0;
    
    databaseRepairSetWindowController = [[NSWindowController alloc] initWithWindowNibName:@"DatabaseRepairWindow"];
    [databaseRepairSetWindowController showWindow:self];
    
    [tableViewDatabaseTable setDataSource:self];
    [tableViewDatabaseTable reloadData];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseRepairOperation object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseListTable object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [databaseRepairSetWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [databaseRepairSetWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [allErrorDisplay setStringValue:@"All Time"];
    [errorTimeHoldDisplay setStringValue:@"Time"];
    
    [tableViewDatabaseTable setDataSource:self];
    [tableViewDatabaseTable reloadData];
    
    for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]){
        if ([[column identifier] isEqualToString:@"COL1"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL2"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL3"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL4"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL5"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL6"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL7"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL8"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL9"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL10"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL11"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL12"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL13"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL14"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL15"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
        else if ([[column identifier] isEqualToString:@"COL16"]){
            NSAttributedString *attrStr;
            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
            
            NSTableHeaderCell* cell2 = [column headerCell];
            
            [cell2 setAttributedStringValue:attrStr];
        }
    }
    
    databaseRepairSetTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (verDisplayCall == 1){
        verDisplayCall = 0;
        
        if (checkListCount == 0) [verResultsDisplay setStringValue:@"No Error Found"];
        else [verResultsDisplay setStringValue:@"Error Found"];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseRepairOperation object:self];
    }
    
    if (progressControl == 1){
        [backSave startAnimation:self];
        
        if (backSave) progressControl = 0;
    }
    else if (progressControl == 2){
        [backSave stopAnimation:self];
        
        if (backSave) progressControl = 0;
    }
    
    if (treatmentMainDisplayCall == 1){
        string treatmentStringTemp = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
        
        [treatmentMainDisplay setStringValue:@(treatmentStringTemp.c_str())];
        
        NSString *treatNSString = [treatmentMainDisplay stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (treatmentStringTemp == treatString) treatmentMainDisplayCall = 0;
        }
    }
    
    if (secondLineDisplayCall == 1){
        string treatmentStringTemp = arrayListString [repairListTableCurrentRow];
        NSString *fromNSString = [replaceLineFromDisplay stringValue];
        
        if (fromNSString != NULL){
            string fromString = [fromNSString UTF8String];
            
            if ((int)treatmentStringTemp.find ("//") != -1){
                string lineNumberTemp = treatmentStringTemp.substr(0, (int)treatmentStringTemp.find ("//"));
                
                if (atoi(fromString.c_str()) != 0 && atoi(fromString.c_str()) <= atoi(lineNumberTemp.c_str())){
                    int lingExtractTemp = atoi(lineNumberTemp.c_str());
                    lineNumberTemp = to_string(lingExtractTemp);
                    
                    [replaceLineToDisplay setStringValue:@(lineNumberTemp.c_str())];
                    
                    NSString *toNSString = [replaceLineToDisplay stringValue];
                    
                    if (toNSString != NULL){
                        string toString = [toNSString UTF8String];
                        
                        if (atoi(lineNumberTemp.c_str()) == atoi(toString.c_str())) secondLineDisplayCall = 0;
                    }
                }
                else secondLineDisplayCall = 0;
            }
            else secondLineDisplayCall = 0;
        }
    }
    
    if (secondLineDisplayRemoveCall == 1){
        string treatmentStringTemp = arrayListString [repairListTableCurrentRow];
        NSString *fromNSString = [removeLineFromDisplay stringValue];
        
        if (fromNSString != NULL){
            string fromString = [fromNSString UTF8String];
            
            if ((int)treatmentStringTemp.find ("//") != -1){
                string lineNumberTemp = treatmentStringTemp.substr(0, (int)treatmentStringTemp.find ("//"));
                
                if (atoi(fromString.c_str()) != 0 && atoi(fromString.c_str()) <= atoi(lineNumberTemp.c_str())){
                    int lingExtractTemp = atoi(lineNumberTemp.c_str());
                    lineNumberTemp = to_string(lingExtractTemp);
                    
                    [removeLineToDisplay setStringValue:@(lineNumberTemp.c_str())];
                    
                    NSString *toNSString = [removeLineToDisplay stringValue];
                    
                    if (toNSString != NULL){
                        string toString = [toNSString UTF8String];
                        
                        if (atoi(lineNumberTemp.c_str()) == atoi(toString.c_str())) secondLineDisplayRemoveCall = 0;
                    }
                }
                else secondLineDisplayRemoveCall = 0;
            }
            else secondLineDisplayRemoveCall = 0;
        }
    }
    
    if (treatDisplayCall == 1){
        if (treatVerNameHold == "0") [treatCountDisplay setStringValue:@"nil"];
        else [treatCountDisplay setStringValue:@(treatVerNameHold.c_str())];
        
        NSString *treatNSString = [treatCountDisplay stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (treatVerNameHold == treatString) treatDisplayCall = 0;
        }
    }
    
    if (timeDisplayCall == 1){
        if (timePointValueHold == 0) [timerCountDisplay setStringValue:@"nil"];
        else [timerCountDisplay setIntegerValue:timePointValueHold];
        
        NSString *treatNSString = [timerCountDisplay stringValue];
        
        if (treatNSString != NULL){
            string treatString = [treatNSString UTF8String];
            
            if (to_string (timePointValueHold) == treatString) timeDisplayCall = 0;
        }
    }
}

-(IBAction)allErrorSet:(id)sender{
    if (allErrorHold == 0){
        allErrorHold = 1;
        [allErrorDisplay setStringValue:@"Error"];
    }
    else if (allErrorHold == 1){
        allErrorHold = 0;
        [allErrorDisplay setStringValue:@"All Time"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)checkCurrentTreat:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (treatmentDoFlag == 0){
            treatmentDoFlag = 1;
            [treatmentDoDisplay setStringValue:@"Sel Treat"];
        }
        else{
            
            treatmentDoFlag = 0;
            [treatmentDoDisplay setStringValue:@"All Treat"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)checkErrorOnly:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        if (onlyErrorFlag == 0){
            onlyErrorFlag = 1;
            [onlyErrorDisplay setStringValue:@"Er. Time"];
        }
        else{
            
            onlyErrorFlag = 0;
            [onlyErrorDisplay setStringValue:@"None"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)analysisData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            string revisedMapPath;
            string connectStatusDataPath;
            string connectRelationPath;
            string extension;
            
            int stepCount = 0;
            int imageSize = 0;
            int yDimensionCount = 0;
            int xDimensionCount = 0;
            int readBit [4];
            int finData [25];
            int pixData = 0;
            int totalSize = 0;
            int timeSelectedVerCount = 0;
            int connectLineageRelVerCount = 0;
            int maxConnectNoStatus = 0;
            int maxConnectNoGr = 0;
            int maxConnectNoMap = 0;
            int maxConnectNoPR = 0;
            int mapNegativeValueFind = 0;
            int connectNoListTemp = 0;
            int readingErrorCheck = 0;
            
            unsigned long readPosition = 0;
            
            imageSize = 0;
            
            for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                if (arrayImageSizeList [counter2*2] == nameStringRep){
                    imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                    break;
                }
            }
            
            lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            //-----Lineage data upload-----
            arrayLineageRepairData = new int [sizeForCopy+50];
            lineageDataRepairCount = 0;
            
            int returnValue2 = 0;
            
            if (checkFlag == 1){
                int processType2 = -1;
                
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
            }
            
            if (returnValue2 == -1) readingErrorCheck = 1;
            
            ifstream fin;
            
            //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
            //    cout<<" arrayLineageRepairData "<<counterA<<endl;
            //}
            
            int **revisedMapVer = new int *[imageSize+1];
            for (int counter2 = 0; counter2 < imageSize+1; counter2++) revisedMapVer [counter2] = new int [imageSize+1];
            
            extension = to_string(checkList [repairOperationTableCurrentRow*8]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
            
            totalSize = imageSize*imageSize*4;
            
            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *upload2 = new uint8_t [totalSize+50];
                fin.read((char*)upload2, totalSize+1);
                fin.close();
                
                yDimensionCount = 0;
                xDimensionCount = 0;
                
                for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                    readBit [0] = upload2[counter3];
                    readBit [1] = upload2[counter3+1];
                    readBit [2] = upload2[counter3+2];
                    readBit [3] = upload2[counter3+3];
                    
                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                    
                    for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                        revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                    }
                    
                    if (xDimensionCount == imageSize){
                        xDimensionCount = 0;
                        yDimensionCount++;
                        
                        if (yDimensionCount == imageSize){
                            break;
                        }
                    }
                }
                
                delete [] upload2;
            }
            
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            size1 = 0;
            size2 = 0;
            checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            arrayPositionReviseVer = new int [sizeForCopy+50];
            positionReviseVerCount = 0;
            
            arrayGravityCenterVerRev = new int [sizeForCopy+50];
            gravityCenterRevVerCount = 0;
            
            arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
            repairDataHoldVerCount = 0;
            
            returnValue2 = 0;
            
            if (checkFlag == 1){
                int processType2 = -1;
                int dataType = -1;
                
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                returnValue2 = [dataRepairReadWrite masterDataSetList:sizeForCopy:processType2:dataType];
            }
            
            if (returnValue2 == -1) readingErrorCheck = 1;
            
            //-----Master Data Status UpLoad-----
            connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
            
            sizeForCopy = 0;
            
            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayTimeSelectedVer = new int [sizeForCopy+50];
            timeSelectedVerCount = 0;
            
            fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                readPosition = 0;
                stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++;
                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                        finData [7] = uploadTemp [readPosition], readPosition++;
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                        finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                        finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                        finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                        finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                        finData [13] = uploadTemp [readPosition], readPosition++;
                        finData [14] = uploadTemp [readPosition], readPosition++;
                        finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                        finData [16] = uploadTemp [readPosition], readPosition++;
                        finData [17] = uploadTemp [readPosition], readPosition++;
                        finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                        
                        finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                        finData [8] = finData [7]*256+finData [8];
                        finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                        finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                        
                        if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                        else{
                            
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [0], timeSelectedVerCount++; //-----Selected, removed, eliminated status-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [3], timeSelectedVerCount++; //-----When new line is created, enter line number which creates-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [6], timeSelectedVerCount++; //-----PositionRevise Start-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [8], timeSelectedVerCount++; //-----Cut line number-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [9], timeSelectedVerCount++; //-----X Start-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [10], timeSelectedVerCount++; //-----X End-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [11], timeSelectedVerCount++; //-----Y Start-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [12], timeSelectedVerCount++; //-----Y End-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [15], timeSelectedVerCount++; //-----Connect-----
                            arrayTimeSelectedVer [timeSelectedVerCount] = finData [18], timeSelectedVerCount++; //-----Lineage-----
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
            
            connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
            
            sizeForCopy = 0;
            
            if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
            connectLineageRelVerCount = 0;
            
            fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                readPosition = 0;
                stepCount = 0;
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++;
                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                        finData [3] = uploadTemp [readPosition], readPosition++;
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                        finData [9] = uploadTemp [readPosition], readPosition++;
                        finData [10] = uploadTemp [readPosition], readPosition++;
                        finData [11] = uploadTemp [readPosition], readPosition++;
                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                        
                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                        
                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                        else{
                            
                            arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                            arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                            arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                            arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                            arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                            arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                delete [] uploadTemp;
            }
            
            //    for (int counterA = 0; counterA < connectLineageRelVerCount/6; counterA++){
            //        for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelVer [counterA*6+counterB];
            //        cout<<" arrayConnectLineageRelVer "<<counterA<<endl;
            //    }
            
            maxConnectNoStatus = 0;
            maxConnectNoGr = 0;
            maxConnectNoMap = 0;
            maxConnectNoPR = 0;
            
            for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                if (arrayPositionReviseVer [counter3*7+3] > maxConnectNoPR){
                    maxConnectNoPR = arrayPositionReviseVer [counter3*7+3];
                }
            }
            
            for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                if (arrayGravityCenterVerRev [counter3*6+4] > maxConnectNoGr){
                    maxConnectNoGr = arrayGravityCenterVerRev [counter3*6+4];
                }
            }
            
            for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                if (arrayTimeSelectedVer [counter3*10+8] > maxConnectNoStatus){
                    maxConnectNoStatus = arrayTimeSelectedVer [counter3*10+8];
                }
            }
            
            mapNegativeValueFind = 0;
            
            for (int counter3 = 0; counter3 < imageSize; counter3++){
                for (int counter4 = 0; counter4 < imageSize; counter4++){
                    if (maxConnectNoMap < revisedMapVer [counter3][counter4]){
                        maxConnectNoMap = revisedMapVer [counter3][counter4];
                    }
                    
                    if (revisedMapVer [counter3][counter4] < 0) mapNegativeValueFind = 1;
                }
            }
            
            //cout<<maxConnectNoPR<<" "<<maxConnectNoGr<<" "<<maxConnectNoStatus<<" "<<maxConnectNoMap<<" max"<<endl;
            
            if ((maxConnectNoPR != 0 || maxConnectNoGr != 0 || maxConnectNoStatus != 0 || maxConnectNoMap != 0) && readingErrorCheck == 0){
                if (mapNegativeValueFind == 0){
                    int maxConnectNo = maxConnectNoPR;
                    if (maxConnectNo <= maxConnectNoGr) maxConnectNo = maxConnectNoGr;
                    if (maxConnectNo <= maxConnectNoStatus) maxConnectNo = maxConnectNoStatus;
                    if (maxConnectNo <= maxConnectNoMap) maxConnectNo = maxConnectNoMap;
                    
                    int *connectNoList = new int [maxConnectNo*16+32];
                    
                    for (int counter3 = 0; counter3 < maxConnectNo*16+32; counter3++) connectNoList [counter3] = -1;
                    
                    for (int counter3 = 1; counter3 <= maxConnectNo; counter3++) connectNoList [counter3*16] = counter3;
                    
                    //-----Status set-----
                    for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                        if (arrayTimeSelectedVer [counter3*10+9] != 0){
                            connectNoList [arrayTimeSelectedVer [counter3*10+8]*16+1] = arrayTimeSelectedVer [counter3*10+9];
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= maxConnectNoPR; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<connectNoList [counterA*16+counterB];
                    //    cout<<" connectNoList "<<counterA<<endl;
                    //}
                    
                    //-----Position revise set-----
                    for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                        if ((arrayPositionReviseVer [counter3*7+5] == 0 || arrayPositionReviseVer [counter3*7+5] == 1) && arrayPositionReviseVer [counter3*7+6] != 0){
                            connectNoList [arrayPositionReviseVer [counter3*7+3]*16+2] = arrayPositionReviseVer [counter3*7+6];
                            connectNoList [arrayPositionReviseVer [counter3*7+3]*16+3] = arrayPositionReviseVer [counter3*7+4];
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= maxConnectNoPR; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<connectNoList [counterA*16+counterB];
                    //    cout<<" connectNoList "<<counterA<<endl;
                    //}
                    
                    //-----Rel set-----
                    for (int counter3 = 0; counter3 < connectLineageRelVerCount/6; counter3++){
                        connectNoList [arrayConnectLineageRelVer [counter3*6+1]*16+4] = arrayConnectLineageRelVer [counter3*6];
                        connectNoList [arrayConnectLineageRelVer [counter3*6+1]*16+5] = arrayConnectLineageRelVer [counter3*6+3];
                    }
                    
                    //-----Gravity Center set-----
                    for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                        connectNoList [arrayGravityCenterVerRev [counter3*6+4]*16+8] = arrayGravityCenterVerRev [counter3*6];
                        connectNoList [arrayGravityCenterVerRev [counter3*6+4]*16+9] = arrayGravityCenterVerRev [counter3*6+1];
                    }
                    
                    //-----Map Gravity Center set-----
                    double *mapGravityCenterCalculation = new double [maxConnectNo*2+20];
                    int *mapGRPointNo = new int [maxConnectNo+10];
                    
                    for (int counter3 = 0; counter3 <= maxConnectNo; counter3++){
                        mapGravityCenterCalculation [counter3*2] = 0;
                        mapGravityCenterCalculation [counter3*2+1] = 0;
                        mapGRPointNo [counter3] = 0;
                    }
                    
                    for (int counter3 = 0; counter3 < imageSize; counter3++){
                        for (int counter4 = 0; counter4 < imageSize; counter4++){
                            mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2] = mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2]+counter4;
                            mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2+1] = mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2+1]+counter3;
                            mapGRPointNo [revisedMapVer [counter3][counter4]]++;
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= maxConnectNoPR; counterA++){
                    //    cout<<counterA<<" "<<mapGravityCenterCalculation [counterA*2]<<" "<<mapGravityCenterCalculation [counterA*2+1]<<" "<<mapGRPointNo [counterA]<<" mapvalue"<<endl;
                    //}
                    
                    for (int counter3 = 1; counter3 <= maxConnectNo; counter3++){
                        if (mapGRPointNo [counter3] != 0){
                            connectNoListTemp = (int)(mapGravityCenterCalculation [counter3*2]/(double)mapGRPointNo [counter3]);
                            connectNoList [counter3*16+10] = connectNoListTemp;
                            connectNoListTemp = (int)(mapGravityCenterCalculation [counter3*2+1]/(double)mapGRPointNo [counter3]);
                            connectNoList [counter3*16+11] = connectNoListTemp;
                        }
                    }
                    
                    //-----Lineage Lineage no/Cell no entry-----
                    for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                        if (arrayLineageRepairData [counter3*8+2] == checkList [repairOperationTableCurrentRow*8]){
                            for (int counter4 = 1; counter4 <= maxConnectNo; counter4++){
                                if ((connectNoList [counter4*16+2] != -1 || connectNoList [counter4*16+3] != -1 || connectNoList [counter4*16+4] != -1 || connectNoList [counter4*16+5] != -1) && ((arrayLineageRepairData [counter3*8] == connectNoList [counter4*16+10] && arrayLineageRepairData [counter3*8+1] == connectNoList [counter4*16+11]) || (arrayLineageRepairData [counter3*8] == connectNoList [counter4*16+8] && arrayLineageRepairData [counter3*8+1] == connectNoList [counter4*16+9]))){
                                    connectNoList [counter4*16+6] = arrayLineageRepairData [counter3*8+6];
                                    connectNoList [counter4*16+7] = arrayLineageRepairData [counter3*8+5];
                                    connectNoList [counter4*16+12] = arrayLineageRepairData [counter3*8];
                                    connectNoList [counter4*16+13] = arrayLineageRepairData [counter3*8+1];
                                    break;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= maxConnectNoPR; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<connectNoList [counterA*16+counterB];
                    //    cout<<" connectNoList "<<counterA<<endl;
                    //}
                    
                    connectForVerifyHold = 0;
                    
                    for (int counter1 = 1; counter1 <= maxConnectNo; counter1++){
                        if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                        
                        checkResults [checkResultsCount] = connectNoList [counter1*16], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+1], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+2], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+3], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+4], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+5], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+6], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+7], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+8], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+9], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+10], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+11], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+12], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+13], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+14], checkResultsCount++;
                        checkResults [checkResultsCount] = connectNoList [counter1*16+15], checkResultsCount++;
                        
                        if (connectNoList [counter1*16+6] == checkList [repairOperationTableCurrentRow*8+2] && connectNoList [counter1*16+7] == checkList [repairOperationTableCurrentRow*8+3]){
                            connectForVerifyHold = connectNoList [counter1*16];
                        }
                    }
                    
                    delete [] mapGravityCenterCalculation;
                    delete [] mapGRPointNo;
                    delete [] connectNoList;
                }
                
                [connectNoDisplay setIntegerValue:connectForVerifyHold];
                
                //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
                //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
                //    cout<<" checkResults "<<counterA<<endl;
                //}
                
                for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                    if ([[column identifier] isEqualToString:@"COL1"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"Con." attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL2"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"L.TS" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL3"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"L.PR" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL4"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"C.PR" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL5"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"L.RE" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL6"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"C.RE" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL7"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"L.Lin" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL8"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"C.Lin" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL9"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"GC.X" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL10"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"GC.Y" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL11"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"MP.X" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL12"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"MP.Y" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL13"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"LinX" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL14"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"LinY" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL15"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL16"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"St." attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                dataTypeSend = 1;
                
                [tableViewDatabaseTable reloadData];
            }
            
            delete [] arrayLineageRepairData;
            delete [] arrayPositionReviseVer;
            delete [] arrayGravityCenterVerRev;
            delete [] arrayRepairDataHoldVerRev;
            delete [] arrayTimeSelectedVer;
            delete [] arrayConnectLineageRelVer;
            
            for (int counter2 = 0; counter2 < imageSize+1; counter2++) delete [] revisedMapVer [counter2];
            delete [] revisedMapVer;
            
            if (readingErrorCheck == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8+2] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            
            lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            //-----Lineage data upload-----
            arrayLineageRepairData = new int [sizeForCopy+50];
            lineageDataRepairCount = 0;
            
            int returnValue2 = 0;
            
            if (checkFlag == 1){
                int processType2 = -1;
                
                dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                returnValue2 = [dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
            }
            
            //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
            //    cout<<" arrayLineageRepairData "<<counterA<<endl;
            //}
            
            if (returnValue2 == 0){
                for (int counter1 = 0; counter1 < lineageDataRepairCount/8; counter1++){
                    if (arrayLineageRepairData [counter1*8+6] == checkList [repairOperationTableCurrentRow*8+2]){
                        if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                        
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+1], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+2], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+3], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+4], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+5], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+6], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayLineageRepairData [counter1*8+7], checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
                //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
                //    cout<<" checkResults "<<counterA<<endl;
                //}
                
                connectForVerifyHold = 0;
                
                [connectNoDisplay setStringValue:@"nil"];
                
                for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                    if ([[column identifier] isEqualToString:@"COL1"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"X" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL2"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"Y" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL3"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"Time" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL4"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"Ev." attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL5"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"C.PF" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL6"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"C.No" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL7"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"L.No" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL8"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"L.Fu" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL9"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL10"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL11"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL12"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL13"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL14"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL15"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                    else if ([[column identifier] isEqualToString:@"COL16"]){
                        NSAttributedString *attrStr;
                        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                        [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                        
                        NSTableHeaderCell* cell2 = [column headerCell];
                        
                        [cell2 setAttributedStringValue:attrStr];
                    }
                }
                
                [tableViewDatabaseTable reloadData];
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Lineage Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            delete [] arrayLineageRepairData;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)timeSelectData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            string extension;
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            extension = to_string(checkList [repairOperationTableCurrentRow*8]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            string connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayTimeSelectedVer = new int [sizeForCopy+50];
            int timeSelectedVerCount = 0;
            
            ifstream fin;
            
            if (sizeForCopy != 0){
                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    readPosition = 0;
                    stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++;
                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                            finData [7] = uploadTemp [readPosition], readPosition++;
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                            finData [13] = uploadTemp [readPosition], readPosition++;
                            finData [14] = uploadTemp [readPosition], readPosition++;
                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                            finData [16] = uploadTemp [readPosition], readPosition++;
                            finData [17] = uploadTemp [readPosition], readPosition++;
                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                            
                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                            finData [8] = finData [7]*256+finData [8];
                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                            
                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                            else{
                                
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [0], timeSelectedVerCount++; //-----Selected, removed, eliminated status-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [3], timeSelectedVerCount++; //-----When new line is created, enter line number which creates-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [6], timeSelectedVerCount++; //-----PositionRevise Start-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [8], timeSelectedVerCount++; //-----Cut line number-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [9], timeSelectedVerCount++; //-----X Start-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [10], timeSelectedVerCount++; //-----X End-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [11], timeSelectedVerCount++; //-----Y Start-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [12], timeSelectedVerCount++; //-----Y End-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [15], timeSelectedVerCount++; //-----Connect-----
                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [18], timeSelectedVerCount++; //-----Lineage-----
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
            }
            
            connectForVerifyHold = checkList [repairOperationTableCurrentRow*8+4];
            
            for (int counter1 = 0; counter1 < timeSelectedVerCount/10; counter1++){
                if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+1], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+2], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+3], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+4], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+5], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+6], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+7], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+8], checkResultsCount++;
                checkResults [checkResultsCount] = arrayTimeSelectedVer [counter1*10+9], checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
            }
            
            delete [] arrayTimeSelectedVer;
            
            [connectNoDisplay setIntegerValue:connectForVerifyHold];
            
            for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                if ([[column identifier] isEqualToString:@"COL1"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Stat." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL2"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL3"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"PRSt." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL4"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL5"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL6"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL7"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL8"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL9"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Con." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL10"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Lineage." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL11"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL12"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL13"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL14"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL15"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL16"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
            }
            
            [tableViewDatabaseTable reloadData];
            
            //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
            //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
            //    cout<<" checkResults "<<counterA<<endl;
            //}
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            dataTypeSend = 2;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)relationData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            string extension;
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            extension = to_string(checkList [repairOperationTableCurrentRow*8]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            string connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            
            if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
            }
            
            int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
            int connectLineageRelVerCount = 0;
            
            ifstream fin;
            
            if (sizeForCopy != 0){
                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    readPosition = 0;
                    stepCount = 0;
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++;
                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                            finData [3] = uploadTemp [readPosition], readPosition++;
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                            finData [9] = uploadTemp [readPosition], readPosition++;
                            finData [10] = uploadTemp [readPosition], readPosition++;
                            finData [11] = uploadTemp [readPosition], readPosition++;
                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                            
                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                            
                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                            else{
                                
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
            }
            
            connectForVerifyHold = 0;
            
            for (int counter1 = 0; counter1 < connectLineageRelVerCount/6; counter1++){
                if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                
                checkResults [checkResultsCount] = arrayConnectLineageRelVer [counter1*6], checkResultsCount++;
                checkResults [checkResultsCount] = arrayConnectLineageRelVer [counter1*6+1], checkResultsCount++;
                checkResults [checkResultsCount] = arrayConnectLineageRelVer [counter1*6+2], checkResultsCount++;
                checkResults [checkResultsCount] = arrayConnectLineageRelVer [counter1*6+3], checkResultsCount++;
                checkResults [checkResultsCount] = arrayConnectLineageRelVer [counter1*6+4], checkResultsCount++;
                checkResults [checkResultsCount] = arrayConnectLineageRelVer [counter1*6+5], checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                checkResults [checkResultsCount] = -1, checkResultsCount++;
                
                if (arrayConnectLineageRelVer [counter1*6] == checkList [repairOperationTableCurrentRow*8+2] && arrayConnectLineageRelVer [counter1*6+3] == checkList [repairOperationTableCurrentRow*8+3]){
                    connectForVerifyHold = arrayConnectLineageRelVer [counter1*6+1];
                }
            }
            
            delete [] arrayConnectLineageRelVer;
            
            [connectNoDisplay setIntegerValue:connectForVerifyHold];
            
            for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                if ([[column identifier] isEqualToString:@"COL1"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Lineage." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL2"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Con." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL3"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Img." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL4"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Cell" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL5"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"Targ." attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL6"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL7"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL8"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL9"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL10"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL11"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL12"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL13"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL14"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL15"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
                else if ([[column identifier] isEqualToString:@"COL16"]){
                    NSAttributedString *attrStr;
                    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                    [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                    
                    NSTableHeaderCell* cell2 = [column headerCell];
                    
                    [cell2 setAttributedStringValue:attrStr];
                }
            }
            
            [tableViewDatabaseTable reloadData];
            
            //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
            //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
            //    cout<<" checkResults "<<counterA<<endl;
            //}
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            dataTypeSend = 3;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)positionReviseData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            string extension;
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            extension = to_string(checkList [repairOperationTableCurrentRow*8]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                arrayPositionReviseVer = new int [sizeForCopy+50];
                positionReviseVerCount = 0;
                
                ifstream fin;
                fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                else{
                                    
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [1], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [3], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [4], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [7], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [12], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [13], positionReviseVerCount++;
                                    arrayPositionReviseVer [positionReviseVerCount] = finData [16], positionReviseVerCount++;
                                }
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    for (int counter1 = 0; counter1 < positionReviseVerCount/7; counter1++){
                        if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                        
                        if (checkList [repairOperationTableCurrentRow*8+2] == arrayPositionReviseVer [counter1*7+6]){
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7], checkResultsCount++;
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7+1], checkResultsCount++;
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7+2], checkResultsCount++;
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7+3], checkResultsCount++;
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7+4], checkResultsCount++;
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7+5], checkResultsCount++;
                            checkResults [checkResultsCount] = arrayPositionReviseVer [counter1*7+6], checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                            checkResults [checkResultsCount] = -1, checkResultsCount++;
                        }
                    }
                    
                    delete [] arrayPositionReviseVer;
                    
                    [connectNoDisplay setStringValue:@"nil"];
                    
                    for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                        if ([[column identifier] isEqualToString:@"COL1"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"X" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL2"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Y" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL3"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Av." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL4"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Con." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL5"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Cell" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL6"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Stat." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL7"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Lineage." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL8"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL9"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL10"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL11"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL12"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL13"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL14"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL15"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL16"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                    }
                    
                    [tableViewDatabaseTable reloadData];
                    
                    //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
                    //    cout<<" checkResults "<<counterA<<endl;
                    //}
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Master Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Master Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            dataTypeSend = 0;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)gravityCenterData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            string extension;
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            extension = to_string(checkList [repairOperationTableCurrentRow*8]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                arrayGravityCenterVerRev = new int [sizeForCopy+50];
                gravityCenterRevVerCount = 0;
                
                ifstream fin;
                fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                else{
                                    
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [1], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [3], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [6], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [7], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [10], gravityCenterRevVerCount++;
                                    arrayGravityCenterVerRev [gravityCenterRevVerCount] = finData [11], gravityCenterRevVerCount++;
                                }
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    for (int counter1 = 0; counter1 < gravityCenterRevVerCount/6; counter1++){
                        if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                        
                        checkResults [checkResultsCount] = arrayGravityCenterVerRev [counter1*6], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayGravityCenterVerRev [counter1*6+1], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayGravityCenterVerRev [counter1*6+2], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayGravityCenterVerRev [counter1*6+3], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayGravityCenterVerRev [counter1*6+4], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayGravityCenterVerRev [counter1*6+5], checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                    }
                    
                    delete [] arrayGravityCenterVerRev;
                    
                    [connectNoDisplay setStringValue:@"nil"];
                    
                    for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                        if ([[column identifier] isEqualToString:@"COL1"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"X" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL2"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Y" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL3"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Area" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL4"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Av." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL5"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Con." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL6"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Targ." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL7"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL8"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL9"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL10"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL11"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL12"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL13"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL14"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL15"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL16"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                    }
                    
                    [tableViewDatabaseTable reloadData];
                    
                    //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
                    //    cout<<" checkResults "<<counterA<<endl;
                    //}
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Master Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Master Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            dataTypeSend = 0;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)associationData:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0 && cleaningProgress == 0 && progressControl == 0){
        if (checkList [repairOperationTableCurrentRow*8] != 0){
            if (checkResultsStatus == 0){
                checkResults = new int [5000];
                checkResultsCount = 0;
                checkResultsLimit = 5000;
                checkResultsStatus = 1;
            }
            else checkResultsCount = 0;
            
            nameStringRep = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
            string extension;
            
            int stepCount = 0;
            int finData [25];
            
            unsigned long readPosition = 0;
            
            extension = to_string(checkList [repairOperationTableCurrentRow*8]);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            //-----Master Data Status UpLoad-----
            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
            
            struct stat sizeOfFile;
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            int checkFlag = 0;
            int readingError = 0;
            
            for (int counter1 = 0; counter1 < 6; counter1++){
                sizeForCopy = 0;
                
                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                }
                
                if (sizeForCopy != 0){
                    if (counter1 == 0) size1 = sizeForCopy;
                    else if (counter1 == 1) size2 = sizeForCopy;
                    else if (counter1 == 2){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                            break;
                        }
                        else{
                            
                            size1 = 0;
                            size2 = 0;
                            usleep (50000);
                        }
                    }
                    else if (counter1 == 3) size1 = sizeForCopy;
                    else if (counter1 == 4) size2 = sizeForCopy;
                    else if (counter1 == 5){
                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                            checkFlag = 1;
                        }
                    }
                }
            }
            
            if (checkFlag == 1){
                arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                repairDataHoldVerCount = 0;
                
                ifstream fin;
                fin.open(masterDataRevPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    
                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                        usleep(50000);
                        fin.read((char*)uploadTemp, sizeForCopy+50);
                        
                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                            usleep(50000);
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy-12]) != 0){
                                readingError = 1;
                            }
                        }
                    }
                    
                    fin.close();
                    
                    if (readingError == 0){
                        readPosition = 0;
                        stepCount = 0;
                        
                        do{
                            
                            if (stepCount == 0){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++;
                                finData [11] = uploadTemp [readPosition], readPosition++;
                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                finData [14] = uploadTemp [readPosition], readPosition++;
                                finData [15] = uploadTemp [readPosition], readPosition++;
                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                
                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                
                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                            }
                            else if (stepCount == 1){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++;
                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++;
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                finData [9] = finData [8]*256+finData [9];
                                
                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                else{
                                    
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [2], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [3], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [4], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [7], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [9], repairDataHoldVerCount++;
                                    arrayRepairDataHoldVerRev [repairDataHoldVerCount] = finData [10], repairDataHoldVerCount++;
                                }
                            }
                            else if (stepCount == 2){
                                finData [0] = uploadTemp [readPosition], readPosition++;
                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                finData [2] = uploadTemp [readPosition], readPosition++;
                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                finData [4] = uploadTemp [readPosition], readPosition++;
                                finData [5] = uploadTemp [readPosition], readPosition++;
                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                finData [8] = uploadTemp [readPosition], readPosition++;
                                finData [9] = uploadTemp [readPosition], readPosition++;
                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                
                                finData [1] = finData [0]*256+finData [1];
                                finData [3] = finData [2]*256+finData [3];
                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                
                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                            }
                            
                        } while (stepCount != 3);
                    }
                    
                    delete [] uploadTemp;
                }
                
                if (readingError == 0){
                    for (int counter1 = 0; counter1 < repairDataHoldVerCount/6; counter1++){
                        if (checkResultsCount+20 > checkResultsLimit) [self checkResultsUpDate];
                        
                        checkResults [checkResultsCount] = arrayRepairDataHoldVerRev [counter1*6], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayRepairDataHoldVerRev [counter1*6+1], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayRepairDataHoldVerRev [counter1*6+2], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayRepairDataHoldVerRev [counter1*6+3], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayRepairDataHoldVerRev [counter1*6+4], checkResultsCount++;
                        checkResults [checkResultsCount] = arrayRepairDataHoldVerRev [counter1*6+5], checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                        checkResults [checkResultsCount] = -1, checkResultsCount++;
                    }
                    
                    delete [] arrayRepairDataHoldVerRev;
                    
                    [connectNoDisplay setStringValue:@"nil"];
                    
                    for (NSTableColumn* column in [tableViewDatabaseTable tableColumns]) {
                        if ([[column identifier] isEqualToString:@"COL1"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Con." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL2"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Pro. Ty" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL3"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Cut Ty" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL4"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Pair" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL5"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"Dim." attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL6"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"res" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL7"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL8"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL9"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL10"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL11"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL12"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL13"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL14"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL15"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                        else if ([[column identifier] isEqualToString:@"COL16"]){
                            NSAttributedString *attrStr;
                            NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
                            [attributes setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                            attrStr = [[NSAttributedString alloc] initWithString:@"nil" attributes:attributes];
                            
                            NSTableHeaderCell* cell2 = [column headerCell];
                            
                            [cell2 setAttributedStringValue:attrStr];
                        }
                    }
                    
                    [tableViewDatabaseTable reloadData];
                    
                    //for (int counterA = 0; counterA < checkResultsCount/16; counterA++){
                    //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<checkResults [counterA*16+counterB];
                    //    cout<<" checkResults "<<counterA<<endl;
                    //}
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Master Data Read Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Master Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            dataTypeSend = 0;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On or Perform Verification"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)ccheckOverrideSet:(id)sender{
    if (checkOverrideFlag == 0){
        checkOverrideFlag = 1;
        [checkOverrideStatusDisplay setStringValue:@"On"];
    }
    else{
        
        checkOverrideFlag = 0;
        [checkOverrideStatusDisplay setStringValue:@"On"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)stopVerification:(id)sender{
    if (verificationStopFlag == 0){
        verificationStopFlag = 1;
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)errorTimeSelect:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && checkListCount != 0){
        if (errorTimeModeHold == 0){
            errorTimeModeHold = 1;
            
            [errorTimeHoldDisplay setTextColor:[NSColor redColor]];
            [errorTimeHoldDisplay setStringValue:@"ErrorType"];
            
            [repairDisplay1 setTextColor:[NSColor redColor]];
            [repairDisplay1 setStringValue:@"Repair1: Lineage./No. PSGAR"];
            [repairDisplay2 setTextColor:[NSColor redColor]];
            [repairDisplay2 setStringValue:@"Repair2: No Lineage./PSGAR"];
            [repairDisplay5 setTextColor:[NSColor redColor]];
            [repairDisplay5 setStringValue:@"Repair5: PR reconstruct"];
            [repairDisplay6 setTextColor:[NSColor redColor]];
            [repairDisplay6 setStringValue:@"Repair6: ST reconstruct"];
            [repairDisplay7 setTextColor:[NSColor redColor]];
            [repairDisplay7 setStringValue:@"Repair7: RL reconstruct"];
            [repairDisplay8 setTextColor:[NSColor redColor]];
            [repairDisplay8 setStringValue:@"Repair8: GC reconstruct"];
            [repairDisplay9 setTextColor:[NSColor redColor]];
            [repairDisplay9 setStringValue:@"Repair9: AD reconstruct"];
            [repairDisplay11 setTextColor:[NSColor redColor]];
            [repairDisplay11 setStringValue:@"Repair12: Fluo reconstruct"];
            
            [errorNoDisplay setStringValue:@"nil"];
            errorNumberHold = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (errorTimeModeHold == 1){
            errorTimeModeHold = 2;
            
            [errorTimeHoldDisplay setTextColor:[NSColor blackColor]];
            [errorTimeHoldDisplay setStringValue:@"Error NO"];
            
            [repairDisplay1 setTextColor:[NSColor blackColor]];
            [repairDisplay1 setStringValue:@"Repair1: Lineage./No. PSGAR"];
            [repairDisplay2 setTextColor:[NSColor blackColor]];
            [repairDisplay2 setStringValue:@"Repair2: No Lineage./PSGAR"];
            [repairDisplay5 setTextColor:[NSColor blackColor]];
            [repairDisplay5 setStringValue:@"Repair5: PR reconstruct"];
            [repairDisplay6 setTextColor:[NSColor blackColor]];
            [repairDisplay6 setStringValue:@"Repair6: ST reconstruct"];
            [repairDisplay7 setTextColor:[NSColor blackColor]];
            [repairDisplay7 setStringValue:@"Repair7: RL reconstruct"];
            [repairDisplay8 setTextColor:[NSColor blackColor]];
            [repairDisplay8 setStringValue:@"Repair8: GC reconstruct"];
            [repairDisplay9 setTextColor:[NSColor blackColor]];
            [repairDisplay9 setStringValue:@"Repair9: AD reconstruct"];
            [repairDisplay11 setTextColor:[NSColor blackColor]];
            [repairDisplay11 setStringValue:@"Repair12: Fluo reconstruct"];
            
            string errorNoString = to_string(checkList [repairOperationTableCurrentRow*8+5]);
            errorNumberHold = checkList [repairOperationTableCurrentRow*8+5];
            
            [errorNoDisplay setStringValue:@(errorNoString.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (errorTimeModeHold == 2){
            errorTimeModeHold = 0;
            
            [errorTimeHoldDisplay setTextColor:[NSColor blackColor]];
            [errorTimeHoldDisplay setStringValue:@"Time"];
            
            [repairDisplay1 setTextColor:[NSColor blackColor]];
            [repairDisplay1 setStringValue:@"Repair1: Lineage./No. PSGAR"];
            [repairDisplay2 setTextColor:[NSColor blackColor]];
            [repairDisplay2 setStringValue:@"Repair2: No Lineage./PSGAR"];
            [repairDisplay5 setTextColor:[NSColor blackColor]];
            [repairDisplay5 setStringValue:@"Repair5: PR reconstruct"];
            [repairDisplay6 setTextColor:[NSColor blackColor]];
            [repairDisplay6 setStringValue:@"Repair6: ST reconstruct"];
            [repairDisplay7 setTextColor:[NSColor blackColor]];
            [repairDisplay7 setStringValue:@"Repair7: RL reconstruct"];
            [repairDisplay8 setTextColor:[NSColor blackColor]];
            [repairDisplay8 setStringValue:@"Repair8: GC reconstruct"];
            [repairDisplay9 setTextColor:[NSColor blackColor]];
            [repairDisplay9 setStringValue:@"Repair9: AD reconstruct"];
            [repairDisplay11 setTextColor:[NSColor blackColor]];
            [repairDisplay11 setStringValue:@"Repair12: Fluo reconstruct"];
            
            [errorNoDisplay setStringValue:@"nil"];
            errorNumberHold = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On or Verification Unperformed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataVerification:(id)sender{
    if (trackingOn != 3 && trackingOn != 2 && trackingOn != 0 && cleaningProgress == 0 && progressControl == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Verify Database?"];
        [alert setInformativeText:@" It will take > 2 minutes"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            if (treatmentDoFlag == 1){
                if (repairOperationTableCurrentRow != 0) treatSetNameHold = arrayTreatmentStatus [checkList [repairOperationTableCurrentRow*8+1]*9];
                else treatSetNameHold = treatmentNameHold;
            }
            else treatSetNameHold = "";
            
            if (checkListStatus == 0){
                checkList = new int [1000];
                checkListCount = 0;
                checkListLimit = 1000;
            }
            else checkListCount = 0;
            
            if (checkErrorTimeListStatus == 0){
                checkErrorTimeList = new int [1000];
                checkErrorTimeListCount = 0;
                checkErrorTimeListStatus = 1;
            }
            
            verificationStopFlag = 0;
            
            [verResultsDisplay setStringValue:@"nil"];
            [self verificationMain];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)verificationMain{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        cleaningProgress = 1;
        progressControl = 1;
        
        string statusDataFind;
        string timeOneString;
        string timeEndFind;
        string imageEndFind;
        string ifStartFind;
        string revisedMapPath;
        string connectStatusDataPath;
        string connectRelationPath;
        string extension;
        string connectFluorescentPath;
        
        int stepCount = 0;
        int imageSize = 0;
        int findFlag = 0;
        int siblingCount = 0;
        int yDimensionCount = 0;
        int xDimensionCount = 0;
        int readBit [4];
        int finData [25];
        int pixData = 0;
        int totalSize = 0;
        int timeSelectedVerCount = 0;
        int connectLineageRelVerCount = 0;
        int maxConnectNoStatus = 0;
        int maxConnectNoGr = 0;
        int maxConnectNoMap = 0;
        int maxConnectNoPR = 0;
        int mapNegativeValueFind = 0;
        int expandFluLineTempCount = 0;
        int expandFluAreaTempCount = 0;
        int maxConnectNoAA = 0;
        int mitosisCount = 0;
        int connectCheck = 0;
        int timeCorrectionFind = 0;
        int treatmentCorrectionFind = 0;
        int cellLingCheckBaseCount = 0;
        int xPositionPr = 0;
        int yPositionPr = 0;
        int xPositionPr2 = 0;
        int yPositionPr2 = 0;
        int connectPR = 0;
        int matchFlag = 0;
        int firstSet = 0;
        int missingConnectCount = 0;
        int structureCheck = 0;
        int structureCheck2 = 0;
        int ifAreaFind = 0;
        int ifLineFound = 0;
        int dualCircleCheckCount = 0;
        int maxConnectHold = 0;
        int maxFind = 0;
        int chNumber = 0;
        int cellNoRep = 0;
        int lingNoRep = 0;
        int eventTypeRep = 0;
        int firstSetFlag = 0;
        int proceedingVerFlag = 0;
        int cellLingCheckBaseTemp = 0;
        int readingErrorCheck = 0;
        int readingErrorCheck2 = 0;
        int processType2 = 0;
        int dataType = 0;
        int returnValue2 = 0;
        int checkFlag = 0;
        
        long sizeForCopy = 0;
        long size1 = 0;
        long size2 = 0;
        
        unsigned long readPosition = 0;
        
        struct stat sizeOfFile;
        ifstream fin;
        
        //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
        //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < treatmentStatusCount/9; counter1++){
            readingErrorCheck = 0;
            
            if (self->treatmentDoFlag == 0 || (self->treatmentDoFlag == 1 && treatSetNameHold == arrayTreatmentStatus [counter1*9])){
                self->treatDisplayCall = 1;
                treatVerNameHold = arrayTreatmentStatus [counter1*9];
                
                nameStringRep = arrayTreatmentStatus [counter1*9];
                statusDataFind = arrayTreatmentStatus [counter1*9+2];
                timeOneString = arrayTreatmentStatus [counter1*9+4];
                timeEndFind = arrayTreatmentStatus [counter1*9+5];
                imageEndFind = arrayTreatmentStatus [counter1*9+8];
                ifStartFind = arrayTreatmentStatus [counter1*9+7];
                
                treatmentCorrectionFind = 0;
                
                //*********arrayTreatmentStatus*********
                //1. TreatName
                //2. Lineage Data check (0: not fined, 1: find)
                //3. Status Data check (0: not fined, 1: find)
                //4. Other Map Data check (0: not fined, 1: find)
                //5. Time One
                //6. Time End
                //7. Time Max
                //8. IF Start
                //9. Image End
                
                imageSize = 0;
                
                for (int counter2 = 0; counter2 < imageSizeListCount/2; counter2++){
                    if (arrayImageSizeList [counter2*2] == nameStringRep){
                        imageSize = atoi(arrayImageSizeList [counter2*2+1].c_str());
                        break;
                    }
                }
                
                if (statusDataFind != "0"){
                    lineageDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+ analysisID+"_"+nameStringRep+"_LineageData";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    
                    for (int counter4 = 0; counter4 < 6; counter4++){
                        sizeForCopy = 0;
                        
                        if (stat(lineageDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter4 == 0) size1 = sizeForCopy;
                            else if (counter4 == 1) size2 = sizeForCopy;
                            else if (counter4 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter4 == 3) size1 = sizeForCopy;
                            else if (counter4 == 4) size2 = sizeForCopy;
                            else if (counter4 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    //-----Lineage data upload-----
                    arrayLineageRepairData = new int [sizeForCopy+50];
                    lineageDataRepairCount = 0;
                    
                    returnValue2 = 0;
                    
                    if (checkFlag == 1){
                        processType2 = -1;
                        
                        self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                        returnValue2 = [self->dataRepairReadWrite lineageDataSetList:sizeForCopy:processType2];
                    }
                    
                    if (returnValue2 == -1) readingErrorCheck = 1;
                    
                    //=========Lineage data check=========
                    
                    //-----Parent cell no and orphan check-----
                    for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                        if (arrayLineageRepairData [counter2*8+3] == 31 || arrayLineageRepairData [counter2*8+3] == 41 || arrayLineageRepairData [counter2*8+3] == 51){
                            findFlag = 0;
                            
                            for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                if (arrayLineageRepairData [counter2*8+6] == arrayLineageRepairData [counter3*8+6] && arrayLineageRepairData [counter2*8+4] == arrayLineageRepairData [counter3*8+5] && arrayLineageRepairData [counter2*8+2]-1 == arrayLineageRepairData [counter3*8+2]){
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+6], checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+5], checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 1, checkListCount++;
                                checkList [checkListCount] = 1, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                        }
                    }
                    
                    cellNoRep = -1;
                    lingNoRep = 0;
                    firstSetFlag = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                        if ((arrayLineageRepairData [counter2*8+5] != cellNoRep || arrayLineageRepairData [counter2*8+6] != lingNoRep) && firstSetFlag == 0){
                            cellNoRep = arrayLineageRepairData [counter2*8+5];
                            lingNoRep = arrayLineageRepairData [counter2*8+6];
                            eventTypeRep = arrayLineageRepairData [counter2*8+3];
                            firstSetFlag = 1;
                        }
                        else if (((arrayLineageRepairData [counter2*8+5] != cellNoRep || arrayLineageRepairData [counter2*8+6] != lingNoRep) || counter2 == lineageDataRepairCount/8-1) && firstSetFlag == 1){
                            if (eventTypeRep != 1 && eventTypeRep != 31 && eventTypeRep != 41  && eventTypeRep != 51 && eventTypeRep != 13){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = lingNoRep, checkListCount++;
                                checkList [checkListCount] = cellNoRep, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 1, checkListCount++;
                                checkList [checkListCount] = 1, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                            
                            if (counter2 != lineageDataRepairCount/8-1){
                                cellNoRep = arrayLineageRepairData [counter2*8+5];
                                lingNoRep = arrayLineageRepairData [counter2*8+6];
                                eventTypeRep = arrayLineageRepairData [counter2*8+3];
                            }
                        }
                    }
                    
                    //-----Lost sibling check-----
                    for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                        siblingCount = 0;
                        
                        if (arrayLineageRepairData [counter2*8+3] == 32 || arrayLineageRepairData [counter2*8+3] == 42 || arrayLineageRepairData [counter2*8+3] == 52){
                            for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                if (arrayLineageRepairData [counter2*8+6] == arrayLineageRepairData [counter3*8+6] && arrayLineageRepairData [counter2*8+5] == arrayLineageRepairData [counter3*8+4] && arrayLineageRepairData [counter2*8+2]+1 == arrayLineageRepairData [counter3*8+2]){
                                    siblingCount++;
                                }
                            }
                            
                            if ((arrayLineageRepairData [counter2*8+3] == 32 && siblingCount != 2) || (arrayLineageRepairData [counter2*8+3] == 42 && siblingCount != 3) || (arrayLineageRepairData [counter2*8+3] == 52 && siblingCount != 4)){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+6], checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+5], checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 2, checkListCount++;
                                checkList [checkListCount] = 2, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                        }
                    }
                    
                    //-----Mitosis check-----
                    for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                        mitosisCount = 0;
                        
                        if (arrayLineageRepairData [counter2*8+3] == 32 || arrayLineageRepairData [counter2*8+3] == 42 || arrayLineageRepairData [counter2*8+3] == 52){
                            for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                if (arrayLineageRepairData [counter2*8+6] == arrayLineageRepairData [counter3*8+6] && arrayLineageRepairData [counter2*8+5] == arrayLineageRepairData [counter3*8+5] && arrayLineageRepairData [counter3*8+3] == 6){
                                    mitosisCount++;
                                }
                                else if (arrayLineageRepairData [counter2*8+6] == arrayLineageRepairData [counter3*8+6] && arrayLineageRepairData [counter2*8+5] == arrayLineageRepairData [counter3*8+5] && (arrayLineageRepairData [counter3*8+3] == 32 || arrayLineageRepairData [counter3*8+3] == 42 || arrayLineageRepairData [counter3*8+3] == 52)){
                                    break;
                                }
                            }
                            
                            if (mitosisCount > 1){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+6], checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+5], checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 3, checkListCount++;
                                checkList [checkListCount] = 3, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                            else if (mitosisCount == 0){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+6], checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+5], checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 4, checkListCount++;
                                checkList [checkListCount] = 3, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                        }
                    }
                    
                    //-----Fusion partner check-----
                    for (int counter2 = 0; counter2 < lineageDataRepairCount/8; counter2++){
                        if (arrayLineageRepairData [counter2*8+3] == 91){
                            findFlag = 0;
                            
                            for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                if (arrayLineageRepairData [counter3*8+3] == 92 && arrayLineageRepairData [counter2*8+5] == arrayLineageRepairData [counter3*8+4] && arrayLineageRepairData [counter2*8+6] == arrayLineageRepairData [counter3*8+7]){
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+2], checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+6], checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+5], checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 5, checkListCount++;
                                checkList [checkListCount] = 3, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                        }
                        
                        if (arrayLineageRepairData [counter2*8+3] == 92){
                            findFlag = 0;
                            
                            for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                if (arrayLineageRepairData [counter3*8+3] == 91 && arrayLineageRepairData [counter2*8+5] == arrayLineageRepairData [counter3*8+4] && arrayLineageRepairData [counter2*8+6] == arrayLineageRepairData [counter3*8+7]){
                                    findFlag = 1;
                                    break;
                                }
                            }
                            
                            if (findFlag == 0){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+2], checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+6], checkListCount++;
                                checkList [checkListCount] = arrayLineageRepairData [counter2*8+5], checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 5, checkListCount++;
                                checkList [checkListCount] = 3, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                
                                treatmentCorrectionFind = 1;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageDataRepairCount/8; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageRepairData [counterA*8+counterB];
                    //    cout<<" arrayLineageRepairData "<<counterA<<endl;
                    //}
                    
                    //=======Each time point check==========
                    int **revisedMapVer = new int *[imageSize+1];
                    for (int counter2 = 0; counter2 < imageSize+1; counter2++) revisedMapVer [counter2] = new int [imageSize+1];
                    
                    for (int counter2 = atoi(timeOneString.c_str()); counter2 <= atoi(imageEndFind.c_str()); counter2++){
                        readingErrorCheck2 = 0;
                        proceedingVerFlag = 0;
                        
                        if (self->onlyErrorFlag == 1){
                            for (int counter3 = 0; counter3 < checkErrorTimeListCount/2; counter3++){
                                if (checkErrorTimeList [counter3*2] == counter2 && checkErrorTimeList [counter3*2+1] == counter1){
                                    proceedingVerFlag = 1;
                                    break;
                                }
                            }
                        }
                        else proceedingVerFlag = 1;
                        
                        if (proceedingVerFlag == 1){
                            self->timeDisplayCall = 1;
                            self->timePointValueHold = counter2;
                            timeCorrectionFind = 0;
                            
                            extension = to_string(counter2);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            //-----Map read-----
                            revisedMapPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_RevisedMap";
                            
                            for (int counter3 = 0; counter3 < imageSize; counter3++){
                                for (int counter4 = 0; counter4 < imageSize; counter4++){
                                    revisedMapVer [counter3][counter4] = 0;
                                }
                            }
                            
                            totalSize = imageSize*imageSize*4;
                            
                            fin.open(revisedMapPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *upload2 = new uint8_t [totalSize+50];
                                fin.read((char*)upload2, totalSize+1);
                                fin.close();
                                
                                yDimensionCount = 0;
                                xDimensionCount = 0;
                                
                                for (int counter3 = 0; counter3 < totalSize; counter3 = counter3+4){
                                    readBit [0] = upload2[counter3];
                                    readBit [1] = upload2[counter3+1];
                                    readBit [2] = upload2[counter3+2];
                                    readBit [3] = upload2[counter3+3];
                                    
                                    pixData = readBit [0]*65536+readBit [1]*256+readBit [2];
                                    
                                    for (int counter4 = 0; counter4 < readBit [3]; counter4++){
                                        revisedMapVer [yDimensionCount][xDimensionCount] = pixData, xDimensionCount++;
                                    }
                                    
                                    if (xDimensionCount == imageSize){
                                        xDimensionCount = 0;
                                        yDimensionCount++;
                                        
                                        if (yDimensionCount == imageSize){
                                            break;
                                        }
                                    }
                                }
                                
                                delete [] upload2;
                            }
                            
                            maxConnectNoMap = 0;
                            
                            for (int counter3 = 0; counter3 < imageSize; counter3++){
                                for (int counter4 = 0; counter4 < imageSize; counter4++){
                                    if (revisedMapVer [counter3][counter4] > maxConnectNoMap) maxConnectNoMap = revisedMapVer [counter3][counter4];
                                }
                            }
                            
                            double *mapGravityCenterCalculation = new double [maxConnectNoMap*2+20];
                            int *mapGRPointNo = new int [maxConnectNoMap+10];
                            
                            for (int counter3 = 0; counter3 <= maxConnectNoMap; counter3++){
                                mapGravityCenterCalculation [counter3*2] = 0;
                                mapGravityCenterCalculation [counter3*2+1] = 0;
                                mapGRPointNo [counter3] = 0;
                            }
                            
                            for (int counter3 = 0; counter3 < imageSize; counter3++){
                                for (int counter4 = 0; counter4 < imageSize; counter4++){
                                    if (revisedMapVer [counter3][counter4] > 0){
                                        mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2] = mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2]+counter4;
                                        mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2+1] = mapGravityCenterCalculation [revisedMapVer [counter3][counter4]*2+1]+counter3;
                                        mapGRPointNo [revisedMapVer [counter3][counter4]]++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 1; counterA <= maxConnectNoMap; counterA++){
                            //    cout<<mapGRPointNo [counterA] <<" "<<mapGravityCenterCalculation [counterA*2] <<" "<<mapGravityCenterCalculation [counterA*2+1]<<" connect"<<counterA<<endl;
                            //}
                            
                            //-----PR, GC, AD read-----
                            masterDataRevPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_MasterDataRevise";
                            
                            size1 = 0;
                            size2 = 0;
                            checkFlag = 0;
                            
                            for (int counter4 = 0; counter4 < 6; counter4++){
                                sizeForCopy = 0;
                                
                                if (stat(masterDataRevPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                if (sizeForCopy != 0){
                                    if (counter4 == 0) size1 = sizeForCopy;
                                    else if (counter4 == 1) size2 = sizeForCopy;
                                    else if (counter4 == 2){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            size1 = 0;
                                            size2 = 0;
                                            usleep (50000);
                                        }
                                    }
                                    else if (counter4 == 3) size1 = sizeForCopy;
                                    else if (counter4 == 4) size2 = sizeForCopy;
                                    else if (counter4 == 5){
                                        if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                            checkFlag = 1;
                                        }
                                    }
                                }
                            }
                            
                            arrayPositionReviseVer = new int [sizeForCopy+50];
                            positionReviseVerCount = 0;
                            
                            arrayGravityCenterVerRev = new int [sizeForCopy+50];
                            gravityCenterRevVerCount = 0;
                            
                            arrayRepairDataHoldVerRev = new int [sizeForCopy+50];
                            repairDataHoldVerCount = 0;
                            
                            returnValue2 = 0;
                            
                            if (checkFlag == 1){
                                processType2 = -1;
                                dataType = -1;
                                
                                self->dataRepairReadWrite = [[DataRepairReadWrite alloc] init];
                                returnValue2 = [self->dataRepairReadWrite masterDataSetList:sizeForCopy:processType2:dataType];
                            }
                            
                            if (returnValue2 == -1) readingErrorCheck2 = 1;
                            
                            //for (int counterA = 0; counterA < positionReviseVerCount/7; counterA++){
                            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayPositionReviseVer [counterA*7+counterB];
                            //    cout<<" arrayPositionReviseVer "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < gravityCenterRevVerCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterVerRev [counterA*6+counterB];
                            //    cout<<" arrayGravityCenterVerRev "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < repairDataHoldVerCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayRepairDataHoldVerRev [counterA*6+counterB];
                            //    cout<<" arrayRepairDataHoldVerRev "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < gravityCenterRevVerCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayGravityCenterVerRev [counterA*6+counterB];
                            //    cout<<" arrayGravityCenterVerRev "<<counterA<<endl;
                            //}
                            
                            //-----Status UpLoad-----
                            connectStatusDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_Status";
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectStatusDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            int *arrayTimeSelectedVer = new int [sizeForCopy+50];
                            timeSelectedVerCount = 0;
                            
                            if (sizeForCopy != 0){
                                fin.open(connectStatusDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 Status
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 Previous connect
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Start position
                                            finData [7] = uploadTemp [readPosition], readPosition++;
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 Cut no
                                            finData [9] = uploadTemp [readPosition], readPosition++; //--6 Ch2
                                            finData [10] = uploadTemp [readPosition], readPosition++; //--7 Ch3
                                            finData [11] = uploadTemp [readPosition], readPosition++; //--8 Ch4
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--9 Ch5
                                            finData [13] = uploadTemp [readPosition], readPosition++;
                                            finData [14] = uploadTemp [readPosition], readPosition++;
                                            finData [15] = uploadTemp [readPosition], readPosition++; //--10 Connect no
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--11 Lineage no
                                            
                                            finData [3] = finData [1]*65536+finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            finData [8] = finData [7]*256+finData [8];
                                            finData [15] = finData [13]*65536+finData [14]*256+finData [15];
                                            finData [18] = finData [16]*65536+finData [17]*256+finData [18];
                                            
                                            if (finData [15] == 0 && finData [18] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [0], timeSelectedVerCount++; //-----Selected, removed, eliminated status-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [3], timeSelectedVerCount++; //-----When new line is created, enter line number which creates-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [6], timeSelectedVerCount++; //-----PositionRevise Start-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [8], timeSelectedVerCount++; //-----Cut line number-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [9], timeSelectedVerCount++; //-----X Start-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [10], timeSelectedVerCount++; //-----X End-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [11], timeSelectedVerCount++; //-----Y Start-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [12], timeSelectedVerCount++; //-----Y End-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [15], timeSelectedVerCount++; //-----Connect-----
                                                arrayTimeSelectedVer [timeSelectedVerCount] = finData [18], timeSelectedVerCount++; //-----Lineage-----
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < timeSelectedVerCount/10; counterA++){
                            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<arrayTimeSelectedVer [counterA*10+counterB];
                            //    cout<<" arrayTimeSelectedVer "<<counterA<<endl;
                            //}
                            
                            //-----RL data read-----
                            connectRelationPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ConnectLineageRel";
                            
                            sizeForCopy = 0;
                            
                            if (stat(connectRelationPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            int *arrayConnectLineageRelVer = new int [sizeForCopy+50];
                            connectLineageRelVerCount = 0;
                            
                            if (sizeForCopy != 0){
                                fin.open(connectRelationPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Lineage no
                                            finData [3] = uploadTemp [readPosition], readPosition++;
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                            finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                            
                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                            finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                            finData [7] = finData [6]*256+finData [7];
                                            
                                            if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                            else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                            
                                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [2], connectLineageRelVerCount++;
                                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [5], connectLineageRelVerCount++;
                                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [7], connectLineageRelVerCount++;
                                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [12], connectLineageRelVerCount++;
                                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [13], connectLineageRelVerCount++;
                                                arrayConnectLineageRelVer [connectLineageRelVerCount] = finData [14], connectLineageRelVerCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < connectLineageRelVerCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelVer [counterA*6+counterB];
                            //    cout<<" arrayConnectLineageRelVer "<<counterA<<endl;
                            //}
                            
                            //-----Fluorescent line data read-----
                            connectFluorescentPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendLineData";
                            
                            ifLineFound = 0;
                            sizeForCopy = 0;
                            
                            if (stat(connectFluorescentPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            else ifLineFound = 1;
                            
                            int *arrayExpandFluorescentLineTemp = new int [sizeForCopy+50];
                            expandFluLineTempCount = 0;
                            
                            if (sizeForCopy != 0){
                                fin.open(connectFluorescentPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [1], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [3], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [6], expandFluLineTempCount++;
                                                arrayExpandFluorescentLineTemp [expandFluLineTempCount] = finData [7], expandFluLineTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < expandFluLineTempCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandFluorescentLineTemp [counterA*4+counterB];
                            //    cout<<" arrayExpandFluorescentLineTemp "<<counterA<<endl;
                            //}
                            
                            //-----Fluorescent area data read-----
                            connectFluorescentPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+nameStringRep+"_Connect/"+extension+"_"+analysisID+"_"+nameStringRep+"_ExtendAreaData";
                            
                            ifAreaFind = 0;
                            sizeForCopy = 0;
                            
                            if (stat(connectFluorescentPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            else ifAreaFind = 1;
                            
                            int *arrayExpandFluorescentAreaTemp = new int [sizeForCopy+50];
                            expandFluAreaTempCount = 0;
                            
                            if (sizeForCopy != 0){
                                fin.open(connectFluorescentPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                            
                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [2], expandFluAreaTempCount++;
                                                arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [3], expandFluAreaTempCount++;
                                                arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [4], expandFluAreaTempCount++;
                                                arrayExpandFluorescentAreaTemp [expandFluAreaTempCount] = finData [7], expandFluAreaTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < expandFluAreaTempCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<arrayExpandFluorescentAreaTemp [counterA*4+counterB];
                            //    cout<<" arrayExpandFluorescentAreaTemp "<<counterA<<endl;
                            //}
                            
                            //==========Connect no check==========
                            maxConnectNoStatus = 0;
                            maxConnectNoGr = 0;
                            maxConnectNoPR = 0;
                            maxConnectNoAA = 0;
                            
                            for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                if (arrayPositionReviseVer [counter3*7+3] > maxConnectNoPR) maxConnectNoPR = arrayPositionReviseVer [counter3*7+3];
                            }
                            
                            for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                                if (arrayGravityCenterVerRev [counter3*6+4] > maxConnectNoGr) maxConnectNoGr = arrayGravityCenterVerRev [counter3*6+4];
                            }
                            
                            for (int counter3 = 0; counter3 < repairDataHoldVerCount/6; counter3++){
                                if (arrayRepairDataHoldVerRev [counter3*6] > maxConnectNoAA) maxConnectNoAA = arrayRepairDataHoldVerRev [counter3*6];
                            }
                            
                            for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                                if (arrayTimeSelectedVer [counter3*10+8] > maxConnectNoStatus) maxConnectNoStatus = arrayTimeSelectedVer [counter3*10+8];
                            }
                            
                            //for (int counterA = 0; counterA < repairDataHoldVerCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayRepairDataHoldVerRev [counterA*6+counterB];
                            //    cout<<" arrayRepairDataHoldVerRev "<<counterA<<endl;
                            //}
                            
                            //cout<<maxConnectNoStatus<<" "<<maxConnectNoGr<<" "<<maxConnectNoMap<<" "<<maxConnectNoPR<<" "<<maxConnectNoAA<<" connect"<<endl;
                            
                            if (maxConnectNoStatus != 0 || maxConnectNoGr != 0 || maxConnectNoMap != 0 || maxConnectNoPR != 0 || maxConnectNoAA != 0){
                                if (maxConnectNoStatus != maxConnectNoGr || maxConnectNoStatus != maxConnectNoMap || maxConnectNoStatus != maxConnectNoPR || maxConnectNoStatus != maxConnectNoAA || maxConnectNoGr != maxConnectNoMap || maxConnectNoGr != maxConnectNoPR || maxConnectNoGr != maxConnectNoAA || maxConnectNoMap != maxConnectNoPR || maxConnectNoMap != maxConnectNoAA || maxConnectNoPR != maxConnectNoAA){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 6, checkListCount++;
                                    checkList [checkListCount] = 4, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                maxFind = 1;
                                
                                if (maxConnectNoStatus < maxConnectNoGr) maxFind = 0;
                                if (maxConnectNoStatus < maxConnectNoMap) maxFind = 0;
                                if (maxConnectNoStatus < maxConnectNoPR) maxFind = 0;
                                if (maxConnectNoStatus < maxConnectNoAA) maxFind = 0;
                                
                                if (maxFind == 1) maxConnectHold = maxConnectNoStatus;
                                else{
                                    
                                    maxFind = 1;
                                    
                                    if (maxConnectNoGr < maxConnectNoMap) maxFind = 0;
                                    if (maxConnectNoGr < maxConnectNoPR) maxFind = 0;
                                    if (maxConnectNoGr < maxConnectNoAA) maxFind = 0;
                                    
                                    if (maxFind == 1) maxConnectHold = maxConnectNoGr;
                                    else{
                                        
                                        maxFind = 1;
                                        
                                        if (maxConnectNoMap < maxConnectNoPR) maxFind = 0;
                                        if (maxConnectNoMap < maxConnectNoAA) maxFind = 0;
                                        
                                        if (maxFind == 1) maxConnectHold = maxConnectNoMap;
                                        else{
                                            
                                            if (maxConnectNoPR < maxConnectNoAA) maxConnectHold = maxConnectNoAA;
                                            else maxConnectHold = maxConnectNoPR;
                                        }
                                    }
                                }
                                
                                //==========Make lineage list and add individual info==========
                                int *cellLingCheckBase = new int [maxConnectHold*16+90];
                                cellLingCheckBaseCount = 0;
                                
                                for (int counter3 = 0; counter3 < maxConnectHold*16+90; counter3++) cellLingCheckBase [counter3] = 0;
                                
                                for (int counter3 = 0; counter3 < lineageDataRepairCount/8; counter3++){
                                    if (arrayLineageRepairData [counter3*8+3] != 91 && arrayLineageRepairData [counter3*8+2] == counter2){
                                        cellLingCheckBase [cellLingCheckBaseCount] = arrayLineageRepairData [counter3*8+6], cellLingCheckBaseCount++; //--Lineage-0
                                        cellLingCheckBase [cellLingCheckBaseCount] = arrayLineageRepairData [counter3*8+5], cellLingCheckBaseCount++; //--Cell no-1
                                        cellLingCheckBase [cellLingCheckBaseCount] = arrayLineageRepairData [counter3*8], cellLingCheckBaseCount++; //--Lineage x-2
                                        cellLingCheckBase [cellLingCheckBaseCount] = arrayLineageRepairData [counter3*8+1], cellLingCheckBaseCount++; //--Lineage y-3
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--Rel connect-4
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--PR connect-5
                                        cellLingCheckBase [cellLingCheckBaseCount] = arrayLineageRepairData [counter3*8+3], cellLingCheckBaseCount++; //--Lineage event type-6
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--PR
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--ST connect-8
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--GC x-9
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--GC y-10
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--GC connect-11
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--Map x-12
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--Map y-13
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--Map connect-14
                                        cellLingCheckBase [cellLingCheckBaseCount] = 0, cellLingCheckBaseCount++; //--AD connect-15
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < cellLingCheckBaseCount/16; counterA++){
                                //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<cellLingCheckBase [counterA*16+counterB];
                                //    cout<<" cellLingCheckBase "<<counterA<<endl;
                                //}
                                
                                //**********ConnectLineageRel**********
                                //1. Lineage No;
                                //2. Connect No;
                                //3. Image number;
                                //4. Cell no;
                                //5. Target (0: non-target, 1: target);
                                //6. Reserve;
                                
                                for (int counter3 = 0; counter3 < cellLingCheckBaseCount/16; counter3++){
                                    //-----RE set-----
                                    for (int counter4 = 0; counter4 < connectLineageRelVerCount/6; counter4++){
                                        if (cellLingCheckBase [counter3*16] == arrayConnectLineageRelVer [counter4*6] && cellLingCheckBase [counter3*16+1] == arrayConnectLineageRelVer [counter4*6+3]){
                                            cellLingCheckBase [counter3*16+4] = arrayConnectLineageRelVer [counter4*6+1];
                                            break;
                                        }
                                    }
                                    
                                    //**********Position Revise (main line data array)**********
                                    //1. X position;
                                    //2. Y position;
                                    //3. Average:
                                    //4. Connect No;
                                    //5. Cell No;
                                    //6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
                                    //7. Lineage no;
                                    
                                    //-----PR set-----
                                    for (int counter4 = 0; counter4 < positionReviseVerCount/7; counter4++){
                                        if (arrayPositionReviseVer [counter4*7+5] == 1 && cellLingCheckBase [counter3*16] == arrayPositionReviseVer [counter4*7+6] && cellLingCheckBase [counter3*16+1] == arrayPositionReviseVer [counter4*7+4]){
                                            cellLingCheckBase [counter3*16+5] = arrayPositionReviseVer [counter4*7+3];
                                            break;
                                        }
                                    }
                                    
                                    //**********arrayTimeSelected**********
                                    //1. Status:[0: Non-Track, 1: Track, 3: Non-Track-Deleted (Delete "0", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning),
                                    //4: Track-Deleted (Delete "1 or 7", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning), 7: Cell-Confirmed, 2: Noise, 5: Only for Time One (Area) Non-Track-Deleted, 6: Only for Time One (Area) Track-Deleted]
                                    //2. Previous Connect No: When Cut line is set, Hold cut line no that created the connect; When data is saved this information is cleared;
                                    //3. Starting position of MasterData
                                    //4. Cut Line number hold: when cut line is set, the line number is entered; When data is saved this information is cleared;
                                    //5. OPEN;
                                    //6. OPEN;
                                    //7. OPEN;
                                    //8. OPEN;
                                    //9. Connect no.
                                    //10. Lineage no.
                                    
                                    //-----Status set-----
                                    for (int counter4 = 0; counter4 < timeSelectedVerCount/10; counter4++){
                                        if ((arrayTimeSelectedVer [counter4*10] == 1 || arrayTimeSelectedVer [counter4*10] == 7) && cellLingCheckBase [counter3*16] == arrayTimeSelectedVer [counter4*10+9] && cellLingCheckBase [counter3*16+4] == arrayTimeSelectedVer [counter4*10+8]){
                                            cellLingCheckBase [counter3*16+8] = arrayTimeSelectedVer [counter4*10+8];
                                            break;
                                        }
                                    }
                                    
                                    //*********arrayGravityCenterRev (GR Center)**********
                                    //1. X Position;
                                    //2. Y Position;
                                    //3. Total Area;
                                    //4. Average;
                                    //5. Connect No.
                                    //6. Target Hit;
                                    
                                    //-----If connect no are OK-----
                                    if (cellLingCheckBase [counter3*16+4] == cellLingCheckBase [counter3*16+5] && cellLingCheckBase [counter3*16+4] == cellLingCheckBase [counter3*16+8] && cellLingCheckBase [counter3*16+5] == cellLingCheckBase [counter3*16+8]){
                                        
                                        //-----Gravity Center set-----
                                        for (int counter4 = 0; counter4 < gravityCenterRevVerCount/6; counter4++){
                                            if (cellLingCheckBase [counter3*16+4] == arrayGravityCenterVerRev [counter4*6+4]){
                                                cellLingCheckBase [counter3*16+9] = arrayGravityCenterVerRev [counter4*6];
                                                cellLingCheckBase [counter3*16+10] = arrayGravityCenterVerRev [counter4*6+1];
                                                cellLingCheckBase [counter3*16+11] = arrayGravityCenterVerRev [counter4*6+4];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    //-----Map set-----
                                    cellLingCheckBaseTemp = (int)(mapGravityCenterCalculation [cellLingCheckBase [counter3*16+4]*2]/(double)mapGRPointNo [cellLingCheckBase [counter3*16+4]]);
                                    cellLingCheckBase [counter3*16+12] = cellLingCheckBaseTemp;
                                    cellLingCheckBaseTemp = (int)(mapGravityCenterCalculation [cellLingCheckBase [counter3*16+4]*2+1]/(double)mapGRPointNo [cellLingCheckBase [counter3*16+4]]);
                                    cellLingCheckBase [counter3*16+13] = cellLingCheckBaseTemp;
                                    
                                    if (cellLingCheckBase [counter3*16+4] != 0) cellLingCheckBase [counter3*16+14] = cellLingCheckBase [counter3*16+4];
                                    else if (cellLingCheckBase [counter3*16+5] != 0) cellLingCheckBase [counter3*16+14] = cellLingCheckBase [counter3*16+5];
                                    else if (cellLingCheckBase [counter3*16+8] != 0) cellLingCheckBase [counter3*16+14] = cellLingCheckBase [counter3*16+8];
                                    else if (cellLingCheckBase [counter3*16+11] != 0) cellLingCheckBase [counter3*16+14] = cellLingCheckBase [counter3*16+11];
                                    
                                    //-----AD set-----
                                    for (int counter4 = 0; counter4 < repairDataHoldVerCount/6; counter4++){
                                        if (cellLingCheckBase [counter3*16+4] == arrayRepairDataHoldVerRev [counter4*6]){
                                            cellLingCheckBase [counter3*16+15] = arrayRepairDataHoldVerRev [counter4*6];
                                            break;
                                        }
                                    }
                                }
                                
                                //==========PR data structure check==========
                                //**********Position Revise (main line data array)**********
                                //1. X position;
                                //2. Y position;
                                //3. Average:
                                //4. Connect No;
                                //5. Cell No;
                                //6. Status (0. Non-Track (+Noise), 1. Track (+Cell Confirm), 2. Non-Track Deleted, 3. Track-Deleted)
                                //7. Lineage no;
                                
                                structureCheck = 0;
                                
                                for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                    if (arrayPositionReviseVer [counter3*7] < 0) structureCheck = 1;
                                    if (arrayPositionReviseVer [counter3*7+1] < 0) structureCheck = 1;
                                    if (arrayPositionReviseVer [counter3*7+2] < 0 || arrayPositionReviseVer [counter3*7+2] > 255) structureCheck = 1;
                                    if (arrayPositionReviseVer [counter3*7+3] < 0) structureCheck = 1;
                                    if (arrayPositionReviseVer [counter3*7+5] < 0 || arrayPositionReviseVer [counter3*7+5] > 3) structureCheck = 1;
                                    if (arrayPositionReviseVer [counter3*7+6] < 0) structureCheck = 1;
                                }
                                
                                if (structureCheck == 1){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 7, checkListCount++;
                                    checkList [checkListCount] = 5, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (structureCheck == 0){
                                    int *connectNoList = new int [maxConnectNoPR+90];
                                    
                                    for (int counter3 = 0; counter3 < maxConnectNoPR+90; counter3++) connectNoList [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < positionReviseVerCount/7; counter3++){
                                        connectNoList [arrayPositionReviseVer [counter3*7+3]] = 1;
                                    }
                                    
                                    //-----PR line close check-----
                                    xPositionPr = 0;
                                    yPositionPr = 0;
                                    xPositionPr2 = 0;
                                    yPositionPr2 = 0;
                                    connectPR = 0;
                                    firstSet = 0;
                                    
                                    int *connectNOPositionStartList = new int [maxConnectNoPR*2+10];
                                    
                                    for (int counter3 = 0; counter3 < maxConnectNoPR*2+10; counter3++) connectNOPositionStartList [counter3] = -1;
                                    
                                    for (int counter4 = 0; counter4 < positionReviseVerCount/7; counter4++){
                                        if (connectPR != arrayPositionReviseVer [counter4*7+3] && (arrayPositionReviseVer [counter4*7+5] == 0 || arrayPositionReviseVer [counter4*7+5] == 1) && firstSet == 0){
                                            connectPR = arrayPositionReviseVer [counter4*7+3];
                                            xPositionPr = arrayPositionReviseVer [counter4*7];
                                            yPositionPr = arrayPositionReviseVer [counter4*7+1];
                                            
                                            firstSet = 1;
                                            
                                            connectNOPositionStartList [connectPR*2] = counter4;
                                            connectNOPositionStartList [connectPR*2+1] = arrayPositionReviseVer [counter4*7+5];
                                        }
                                        else if (connectPR == arrayPositionReviseVer [counter4*7+3] && counter4 != positionReviseVerCount/7-1 && (arrayPositionReviseVer [counter4*7+5] == 0 || arrayPositionReviseVer [counter4*7+5] == 1) && firstSet == 1){
                                            xPositionPr2 = arrayPositionReviseVer [counter4*7];
                                            yPositionPr2 = arrayPositionReviseVer [counter4*7+1];
                                        }
                                        else if ((connectPR != arrayPositionReviseVer [counter4*7+3] || counter4 == positionReviseVerCount/7-1) && (arrayPositionReviseVer [counter4*7+5] == 0 || arrayPositionReviseVer [counter4*7+5] == 1) && firstSet == 1){
                                            
                                            if (counter4 == positionReviseVerCount/7-1){
                                                xPositionPr2 = arrayPositionReviseVer [counter4*7];
                                                yPositionPr2 = arrayPositionReviseVer [counter4*7+1];
                                            }
                                            
                                            matchFlag = 0;
                                            
                                            if (xPositionPr-1 == xPositionPr2 && yPositionPr-1 == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr == xPositionPr2 && yPositionPr-1 == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr+1 == xPositionPr2 && yPositionPr-1 == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr+1 == xPositionPr2 && yPositionPr == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr+1 == xPositionPr2 && yPositionPr+1 == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr == xPositionPr2 && yPositionPr+1 == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr-1 == xPositionPr2 && yPositionPr+1 == yPositionPr2) matchFlag = 1;
                                            else if (xPositionPr-1 == xPositionPr2 && yPositionPr == yPositionPr2) matchFlag = 1;
                                            
                                            if (matchFlag == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = connectPR, checkListCount++;
                                                checkList [checkListCount] = 10, checkListCount++;
                                                checkList [checkListCount] = 6, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                            
                                            xPositionPr = arrayPositionReviseVer [counter4*7];
                                            yPositionPr = arrayPositionReviseVer [counter4*7+1];
                                            connectPR = arrayPositionReviseVer [counter4*7+3];
                                            
                                            connectNOPositionStartList [connectPR*2] = counter4;
                                            connectNOPositionStartList [connectPR*2+1] = arrayPositionReviseVer [counter4*7+5];
                                        }
                                    }
                                    
                                    //-----PR line Lineage Data Match-----
                                    for (int counter3 = 1; counter3 <= maxConnectNoPR; counter3++){
                                        if (connectNoList [counter3] == 1){
                                            structureCheck = 0;
                                            
                                            if (connectNOPositionStartList [counter3*2+1] == 1) structureCheck = 1;
                                            
                                            if (structureCheck == 1){
                                                structureCheck = 0;
                                                
                                                for (int counter4 = 0; counter4 < cellLingCheckBaseCount/16; counter4++){
                                                    if (counter3 == cellLingCheckBase [counter4*16+4]) structureCheck = 1;
                                                }
                                                
                                                if (structureCheck == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 11, checkListCount++;
                                                    checkList [checkListCount] = 8, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                    }
                                    
                                    delete [] connectNoList;
                                    
                                    int connectFind = 0;
                                    int connectNotFind = 0;
                                    
                                    for (int counter3 = 1; counter3 <= maxConnectNoPR; counter3++){
                                        if (connectNOPositionStartList [counter3*2] != -1){
                                            connectFind = 0;
                                            connectNotFind = 0;
                                            
                                            for (int counter4 = connectNOPositionStartList [counter3*2]; counter4 < positionReviseVerCount/7; counter4++){
                                                if (arrayPositionReviseVer [counter4*7+3] != counter3){
                                                    break;
                                                }
                                                
                                                if (revisedMapVer [arrayPositionReviseVer [counter4*7+1]][arrayPositionReviseVer [counter4*7]] == counter3){
                                                    connectFind = 1;
                                                }
                                                else connectNotFind = 1;
                                            }
                                            
                                            if (connectFind == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = counter3, checkListCount++;
                                                checkList [checkListCount] = 9, checkListCount++;
                                                checkList [checkListCount] = 18, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                            }
                                            else if (connectFind == 1 && connectNotFind == 1){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = counter3, checkListCount++;
                                                checkList [checkListCount] = 12, checkListCount++;
                                                checkList [checkListCount] = 18, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                            }
                                        }
                                    }
                                    
                                    delete [] connectNOPositionStartList;
                                }
                                
                                //**********arrayTimeSelected**********
                                //1. Status:[0: Non-Track, 1: Track, 3: Non-Track-Deleted (Delete "0", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning),
                                //4: Track-Deleted (Delete "1 or 7", Used to recover from Cut, when cut line is removed. It will be removed by Cleaning), 7: Cell-Confirmed, 2: Noise, 5: Only for Time One (Area) Non-Track-Deleted, 6: Only for Time One (Area) Track-Deleted]
                                //2. Previous Connect No: When Cut line is set, Hold cut line no that created the connect; When data is saved this information is cleared;
                                //3. Starting position of MasterData
                                //4. Cut Line number hold: when cut line is set, the line number is entered; When data is saved this information is cleared;
                                //5. OPEN;
                                //6. OPEN;
                                //7. OPEN;
                                //8. OPEN;
                                //9. Connect no.
                                //10. Lineage no.
                                
                                //==========ST data structure check==========
                                structureCheck = 0;
                                
                                for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                                    if (arrayTimeSelectedVer [counter3*10] != 0 && arrayTimeSelectedVer [counter3*10] != 1 && arrayTimeSelectedVer [counter3*10] != 3 && arrayTimeSelectedVer [counter3*10] != 4 && arrayTimeSelectedVer [counter3*10] != 7) structureCheck = 1;
                                    if (counter3 != 0 && arrayTimeSelectedVer [counter3*10+2] <= 0) structureCheck = 2;
                                    if (arrayTimeSelectedVer [counter3*10+8] < 0) structureCheck = 1;
                                    if (arrayTimeSelectedVer [counter3*10+9] < 0) structureCheck = 1;
                                }
                                
                                if (structureCheck == 1){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 14, checkListCount++;
                                    checkList [checkListCount] = 9, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                else if (structureCheck == 2){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 8, checkListCount++;
                                    checkList [checkListCount] = 25, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (timeSelectedVerCount/10 != maxConnectNoStatus){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 15, checkListCount++;
                                    checkList [checkListCount] = 9, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (structureCheck == 0){
                                    //-----Connect gap check-----
                                    int *connectNoList = new int [maxConnectNoStatus+90];
                                    
                                    for (int counter3 = 0; counter3 < maxConnectNoStatus+90; counter3++) connectNoList [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                                        connectNoList [arrayTimeSelectedVer [counter3*10+8]] = 1;
                                    }
                                    
                                    missingConnectCount = 0;
                                    
                                    for (int counter3 = 1; counter3 <= maxConnectNoStatus; counter3++){
                                        if (connectNoList [counter3] == 0) missingConnectCount++;
                                    }
                                    
                                    if (missingConnectCount >= 1 && missingConnectCount <= 10){
                                        for (int counter3 = 1; counter3 <= maxConnectNoStatus; counter3++){
                                            if (connectNoList [counter3] == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = counter3, checkListCount++;
                                                checkList [checkListCount] = 16, checkListCount++;
                                                checkList [checkListCount] = 26, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                        }
                                    }
                                    else if (missingConnectCount >= 11){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 17, checkListCount++;
                                        checkList [checkListCount] = 26, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellLingCheckBaseCount/16; counter3++){
                                        structureCheck = 0;
                                        
                                        for (int counter4 = 0; counter4 < timeSelectedVerCount/10; counter4++){
                                            if (cellLingCheckBase [counter3*16+4] == arrayTimeSelectedVer [counter4*10+8] && arrayTimeSelectedVer [counter4*10] != 1 && arrayTimeSelectedVer [counter4*10] != 7){
                                                structureCheck = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (structureCheck == 1){
                                            if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                            
                                            checkList [checkListCount] = counter2, checkListCount++;
                                            checkList [checkListCount] = counter1, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = cellLingCheckBase [counter3*16+4], checkListCount++;
                                            checkList [checkListCount] = 19, checkListCount++;
                                            checkList [checkListCount] = 26, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            
                                            timeCorrectionFind = 1;
                                            treatmentCorrectionFind = 1;
                                        }
                                        
                                        structureCheck = 0;
                                        
                                        for (int counter4 = 0; counter4 < timeSelectedVerCount/10; counter4++){
                                            if (cellLingCheckBase [counter3*16+4] == arrayTimeSelectedVer [counter4*10+8] && arrayTimeSelectedVer [counter4*10+9] != cellLingCheckBase [counter3*16]){
                                                structureCheck = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (structureCheck == 1){
                                            if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                            
                                            checkList [checkListCount] = counter2, checkListCount++;
                                            checkList [checkListCount] = counter1, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = cellLingCheckBase [counter3*16+4], checkListCount++;
                                            checkList [checkListCount] = 20, checkListCount++;
                                            checkList [checkListCount] = 26, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            
                                            timeCorrectionFind = 1;
                                            treatmentCorrectionFind = 1;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                                        if (arrayTimeSelectedVer [counter3*10] == 1 || arrayTimeSelectedVer [counter3*10] == 7){
                                            structureCheck = 0;
                                            
                                            for (int counter4 = 0; counter4 < cellLingCheckBaseCount/16; counter4++){
                                                if (cellLingCheckBase [counter4*16+14] == arrayTimeSelectedVer [counter3*10+8]){
                                                    structureCheck = 1;
                                                    break;
                                                }
                                            }
                                            
                                            if (structureCheck == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = arrayTimeSelectedVer [counter3*10+8], checkListCount++;
                                                checkList [checkListCount] = 21, checkListCount++;
                                                checkList [checkListCount] = 26, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < timeSelectedVerCount/10; counter3++){
                                        if (arrayTimeSelectedVer [counter3*10] == 0 && arrayTimeSelectedVer [counter3*10+9] != 0){
                                            if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                            
                                            checkList [checkListCount] = counter2, checkListCount++;
                                            checkList [checkListCount] = counter1, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = arrayTimeSelectedVer [counter3*10+8], checkListCount++;
                                            checkList [checkListCount] = 22, checkListCount++;
                                            checkList [checkListCount] = 27, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            
                                            timeCorrectionFind = 1;
                                            treatmentCorrectionFind = 1;
                                        }
                                        
                                        if (arrayTimeSelectedVer [counter3*10] == 0 || arrayTimeSelectedVer [counter3*10] == 1){
                                            if (arrayPositionReviseVer [arrayTimeSelectedVer [counter3*10+2]*7+3] != arrayTimeSelectedVer [counter3*10+8]){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = arrayTimeSelectedVer [counter3*10+8], checkListCount++;
                                                checkList [checkListCount] = 4, checkListCount++;
                                                checkList [checkListCount] = 27, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                        }
                                    }
                                    
                                    delete [] connectNoList;
                                }
                                
                                //*********arrayGravityCenterRev (GR Center)**********
                                //1. X Position;
                                //2. Y Position;
                                //3. Total Area;
                                //4. Average;
                                //5. Connect No.
                                //6. Target Hit;
                                
                                //==========GC data structure check==========
                                structureCheck = 0;
                                
                                for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                                    if (arrayGravityCenterVerRev [counter3*6] < 0) structureCheck = 1;
                                    if (arrayGravityCenterVerRev [counter3*6+1] < 0) structureCheck = 1;
                                    if (arrayGravityCenterVerRev [counter3*6+2] < 0) structureCheck = 1;
                                    if (arrayGravityCenterVerRev [counter3*6+3] < 0 || arrayGravityCenterVerRev [counter3*6+3] > 255) structureCheck = 1;
                                    if (arrayGravityCenterVerRev [counter3*6+4] < 0) structureCheck = 1;
                                }
                                
                                if (structureCheck == 1){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 23, checkListCount++;
                                    checkList [checkListCount] = 11, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (gravityCenterRevVerCount/6 != maxConnectNoGr){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 24, checkListCount++;
                                    checkList [checkListCount] = 11, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (structureCheck == 0){
                                    //-----Connect gap check-----
                                    int *connectNoList = new int [maxConnectNoGr+90];
                                    
                                    for (int counter3 = 0; counter3 < maxConnectNoGr+90; counter3++) connectNoList [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < gravityCenterRevVerCount/6; counter3++){
                                        connectNoList [arrayGravityCenterVerRev [counter3*6+4]] = 1;
                                    }
                                    
                                    missingConnectCount = 0;
                                    
                                    for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                        if (connectNoList [counter3] == 0) missingConnectCount++;
                                    }
                                    
                                    if (missingConnectCount >= 1 && missingConnectCount <= 10){
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList [counter3] == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = counter3, checkListCount++;
                                                checkList [checkListCount] = 25, checkListCount++;
                                                checkList [checkListCount] = 15, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                        }
                                    }
                                    else if (missingConnectCount >= 11){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 26, checkListCount++;
                                        checkList [checkListCount] = 15, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                    
                                    delete [] connectNoList;
                                }
                                
                                //*********arrayAssociateData (not used)--Cell Carving is using this array, so keep it**********
                                //1. Connect No;
                                //2. Process type;
                                //3. Cut type;
                                //4. Pair no;
                                //5. Cell dimension
                                //6. Reserve;
                                
                                //==========AD data structure check==========
                                structureCheck = 0;
                                
                                for (int counter3 = 0; counter3 < repairDataHoldVerCount/6; counter3++){
                                    if (arrayRepairDataHoldVerRev [counter3*6] < 0) structureCheck = 1;
                                }
                                
                                if (structureCheck == 1){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 27, checkListCount++;
                                    checkList [checkListCount] = 7, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (repairDataHoldVerCount/6 != maxConnectNoAA){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 28, checkListCount++;
                                    checkList [checkListCount] = 7, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (structureCheck == 0){
                                    //-----Connect gap check-----
                                    int *connectNoList = new int [maxConnectNoAA+90];
                                    
                                    for (int counter3 = 0; counter3 < maxConnectNoAA+90; counter3++) connectNoList [counter3] = 0;
                                    
                                    for (int counter3 = 0; counter3 < repairDataHoldVerCount/6; counter3++){
                                        connectNoList [arrayRepairDataHoldVerRev [counter3*6]] = 1;
                                    }
                                    
                                    missingConnectCount = 0;
                                    
                                    for (int counter3 = 1; counter3 <= maxConnectNoAA; counter3++){
                                        if (connectNoList [counter3] == 0) missingConnectCount++;
                                    }
                                    
                                    if (missingConnectCount >= 1 && missingConnectCount <= 10){
                                        for (int counter3 = 1; counter3 <= maxConnectNoAA; counter3++){
                                            if (connectNoList [counter3] == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = counter3, checkListCount++;
                                                checkList [checkListCount] = 29, checkListCount++;
                                                checkList [checkListCount] = 12, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                        }
                                    }
                                    else if (missingConnectCount >= 11){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 30, checkListCount++;
                                        checkList [checkListCount] = 12, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                    
                                    delete [] connectNoList;
                                }
                                
                                //**********ConnectLineageRel**********
                                //1. Lineage No;
                                //2. Connect No;
                                //3. Image number;
                                //4. Cell no;
                                //5. Target (0: non-target, 1: target);
                                //6. Reserve;
                                
                                //    for (int counterA = 0; counterA < connectLineageRelVerCount/6; counterA++){
                                //        for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayConnectLineageRelVer [counterA*6+counterB];
                                //        cout<<" arrayConnectLineageRelVer "<<counterA<<endl;
                                //    }
                                
                                //==========RE data structure check==========
                                structureCheck = 0;
                                
                                for (int counter3 = 0; counter3 < connectLineageRelVerCount/6; counter3++){
                                    if (arrayConnectLineageRelVer [counter3*6] < 0) structureCheck = 1;
                                    if (arrayConnectLineageRelVer [counter3*6+1] < 0) structureCheck = 1;
                                    if (arrayConnectLineageRelVer [counter3*6+2] < 0) structureCheck = 1;
                                }
                                
                                if (structureCheck == 1){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 31, checkListCount++;
                                    checkList [checkListCount] = 14, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                if (structureCheck == 0){
                                    //-----RE Lineage Data Match-----
                                    for (int counter3 = 0; counter3 < connectLineageRelVerCount/6; counter3++){
                                        structureCheck = 0;
                                        
                                        for (int counter4 = 0; counter4 < cellLingCheckBaseCount/16; counter4++){
                                            if (arrayConnectLineageRelVer [counter3*6] == cellLingCheckBase [counter4*16] && arrayConnectLineageRelVer [counter3*6+3] == cellLingCheckBase [counter4*16+1]){
                                                structureCheck = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (structureCheck == 0){
                                            for (int counter4 = 0; counter4 < lineageDataRepairCount/8; counter4++){
                                                if (arrayLineageRepairData [counter4*8+3] == 91 && arrayConnectLineageRelVer [counter3*6] == arrayLineageRepairData [counter4*8+6] && arrayConnectLineageRelVer [counter3*6+3] == arrayLineageRepairData [counter4*8+5]){
                                                    structureCheck = 1;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (structureCheck == 0){
                                            if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                            
                                            checkList [checkListCount] = counter2, checkListCount++;
                                            checkList [checkListCount] = counter1, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = arrayConnectLineageRelVer [counter3*6+1], checkListCount++;
                                            checkList [checkListCount] = 32, checkListCount++;
                                            checkList [checkListCount] = 10, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            
                                            timeCorrectionFind = 1;
                                            treatmentCorrectionFind = 1;
                                        }
                                    }
                                }
                                
                                //==========MAP data structure check==========
                                mapNegativeValueFind = 0;
                                
                                for (int counter3 = 0; counter3 < imageSize; counter3++){
                                    for (int counter4 = 0; counter4 < imageSize; counter4++){
                                        if (revisedMapVer [counter3][counter4] < 0) mapNegativeValueFind = 1;
                                    }
                                }
                                
                                if (mapNegativeValueFind == 1){
                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                    
                                    checkList [checkListCount] = counter2, checkListCount++;
                                    checkList [checkListCount] = counter1, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    checkList [checkListCount] = 33, checkListCount++;
                                    checkList [checkListCount] = 4, checkListCount++;
                                    checkList [checkListCount] = 0, checkListCount++;
                                    
                                    timeCorrectionFind = 1;
                                    treatmentCorrectionFind = 1;
                                }
                                
                                //**********Fluorescent Line data*********
                                //1. X Position
                                //2. Y position
                                //3. Connect No
                                //4. Channel No (1, 2, 3 Live, 4, 5, 6 IF)
                                
                                //*********Fluorescent Data**********
                                //1. Connect No
                                //2. Channel No (1, 2, 3 Live, 4, 5, 6 IF)
                                //3. CH Value
                                //4. CH Area
                                
                                //=========Fluorescent Line data read check==========
                                if (ifLineFound == 0 && ifAreaFind == 0){
                                    structureCheck = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluLineTempCount/4; counter3++){
                                        if (arrayExpandFluorescentLineTemp [counter3*4] < 0) structureCheck = 1;
                                        if (arrayExpandFluorescentLineTemp [counter3*4+1] < 0) structureCheck = 1;
                                        if (arrayExpandFluorescentLineTemp [counter3*4+2] < 1 || arrayExpandFluorescentLineTemp [counter3*4+2] > maxConnectNoGr) structureCheck = 1;
                                        if (arrayExpandFluorescentLineTemp [counter3*4+3] < 1 || arrayExpandFluorescentLineTemp [counter3*4+3] > 12) structureCheck = 1;
                                    }
                                    
                                    if (structureCheck == 1){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 36, checkListCount++;
                                        checkList [checkListCount] = 17, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                    
                                    structureCheck2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluAreaTempCount/4; counter3++){
                                        if (arrayExpandFluorescentAreaTemp [counter3*4] < 1 || arrayExpandFluorescentAreaTemp [counter3*4] > maxConnectNoGr) structureCheck2 = 1;
                                        if (arrayExpandFluorescentAreaTemp [counter3*4+1] < 1 || arrayExpandFluorescentAreaTemp [counter3*4+1] > 12) structureCheck2 = 1;
                                        if (arrayExpandFluorescentAreaTemp [counter3*4+2] < 0) structureCheck2 = 1;
                                        if (arrayExpandFluorescentAreaTemp [counter3*4+3] < 0) structureCheck2 = 1;
                                    }
                                    
                                    //*********Fluorescent Data**********
                                    //1. Connect No
                                    //2. Channel No (1, 2, 3 Live, 4, 5, 6 IF)
                                    //3. CH Value
                                    //4. CH Area
                                    
                                    if (structureCheck2 == 1){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 41, checkListCount++;
                                        checkList [checkListCount] = 19, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                    
                                    if (structureCheck == 0){
                                        //-----Fluorescent line data-open check-----
                                        xPositionPr = 0;
                                        yPositionPr = 0;
                                        xPositionPr2 = 0;
                                        yPositionPr2 = 0;
                                        connectPR = 0;
                                        firstSet = 0;
                                        chNumber = 0;
                                        
                                        int *dualCircleCheck = new int [expandFluLineTempCount/2];
                                        
                                        for (int counter4 = 0; counter4 < expandFluLineTempCount/4; counter4++){
                                            if (connectPR != arrayExpandFluorescentLineTemp [counter4*4+2] && firstSet == 0){
                                                connectPR = arrayExpandFluorescentLineTemp [counter4*4+2];
                                                xPositionPr = arrayExpandFluorescentLineTemp [counter4*4];
                                                yPositionPr = arrayExpandFluorescentLineTemp [counter4*4+1];
                                                chNumber = arrayExpandFluorescentLineTemp [counter4*4+3];
                                                
                                                dualCircleCheckCount = 0;
                                                
                                                dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4], dualCircleCheckCount++;
                                                dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4+1], dualCircleCheckCount++;
                                                
                                                firstSet = 1;
                                            }
                                            else if (connectPR == arrayExpandFluorescentLineTemp [counter4*4+2] && counter4 != expandFluLineTempCount/4-1 && chNumber == arrayExpandFluorescentLineTemp [counter4*4+3] && firstSet == 1){
                                                xPositionPr2 = arrayExpandFluorescentLineTemp [counter4*4];
                                                yPositionPr2 = arrayExpandFluorescentLineTemp [counter4*4+1];
                                                
                                                dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4], dualCircleCheckCount++;
                                                dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4+1], dualCircleCheckCount++;
                                            }
                                            else if ((connectPR != arrayExpandFluorescentLineTemp [counter4*4+2] || counter4 == expandFluLineTempCount/4-1 || chNumber != arrayExpandFluorescentLineTemp [counter4*4+3]) && firstSet == 1){
                                                if (counter4 == expandFluLineTempCount/4-1){
                                                    xPositionPr2 = arrayExpandFluorescentLineTemp [counter4*4];
                                                    yPositionPr2 = arrayExpandFluorescentLineTemp [counter4*4+1];
                                                    
                                                    dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4], dualCircleCheckCount++;
                                                    dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4+1], dualCircleCheckCount++;
                                                }
                                                
                                                matchFlag = 0;
                                                
                                                if (xPositionPr-1 == xPositionPr2 && yPositionPr-1 == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr == xPositionPr2 && yPositionPr-1 == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr+1 == xPositionPr2 && yPositionPr-1 == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr+1 == xPositionPr2 && yPositionPr == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr+1 == xPositionPr2 && yPositionPr+1 == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr == xPositionPr2 && yPositionPr+1 == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr-1 == xPositionPr2 && yPositionPr+1 == yPositionPr2) matchFlag = 1;
                                                else if (xPositionPr-1 == xPositionPr2 && yPositionPr == yPositionPr2) matchFlag = 1;
                                                
                                                if (matchFlag == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = connectPR, checkListCount++;
                                                    checkList [checkListCount] = 39, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                
                                                xPositionPr = arrayExpandFluorescentLineTemp [counter4*4];
                                                yPositionPr = arrayExpandFluorescentLineTemp [counter4*4+1];
                                                connectPR = arrayExpandFluorescentLineTemp [counter4*4+2];
                                                chNumber = arrayExpandFluorescentLineTemp [counter4*4+3];
                                                
                                                dualCircleCheckCount = 0;
                                                
                                                dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4], dualCircleCheckCount++;
                                                dualCircleCheck [dualCircleCheckCount] = arrayExpandFluorescentLineTemp [counter4*4+1], dualCircleCheckCount++;
                                            }
                                        }
                                        
                                        delete [] dualCircleCheck;
                                    }
                                    
                                    if (structureCheck == 0 && structureCheck2 == 0){
                                        int *connectNoList = new int [maxConnectNoGr+90];
                                        int *connectNoList2 = new int [maxConnectNoGr+90];
                                        int *connectNoList3 = new int [maxConnectNoGr+90];
                                        int *connectNoList4 = new int [maxConnectNoGr+90];
                                        int *connectNoList5 = new int [maxConnectNoGr+90];
                                        int *connectNoList6 = new int [maxConnectNoGr+90];
                                        int *connectNoList7 = new int [maxConnectNoGr+90];
                                        int *connectNoList8 = new int [maxConnectNoGr+90];
                                        int *connectNoList9 = new int [maxConnectNoGr+90];
                                        int *connectNoList10 = new int [maxConnectNoGr+90];
                                        int *connectNoList11 = new int [maxConnectNoGr+90];
                                        int *connectNoList12 = new int [maxConnectNoGr+90];
                                        
                                        for (int counter3 = 0; counter3 < maxConnectNoGr+90; counter3++){
                                            connectNoList [counter3] = 0;
                                            connectNoList2 [counter3] = 0;
                                            connectNoList3 [counter3] = 0;
                                            connectNoList4 [counter3] = 0;
                                            connectNoList5 [counter3] = 0;
                                            connectNoList6 [counter3] = 0;
                                            connectNoList7 [counter3] = 0;
                                            connectNoList8 [counter3] = 0;
                                            connectNoList9 [counter3] = 0;
                                            connectNoList10 [counter3] = 0;
                                            connectNoList11 [counter3] = 0;
                                            connectNoList12 [counter3] = 0;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < expandFluLineTempCount/4; counter3++){
                                            if (arrayExpandFluorescentLineTemp [counter3*4+3] == 1) connectNoList [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 2) connectNoList2 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 3) connectNoList3 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 4) connectNoList4 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 5) connectNoList5 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 6) connectNoList6 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 7) connectNoList7 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 8) connectNoList8 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 9) connectNoList9 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 10) connectNoList10 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 11) connectNoList11 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                            else if (arrayExpandFluorescentLineTemp [counter3*4+3] == 12) connectNoList12 [arrayExpandFluorescentLineTemp [counter3*4+2]] = 1;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < expandFluAreaTempCount/4; counter3++){
                                            missingConnectCount = 0;
                                            
                                            if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 1){
                                                if (connectNoList [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 2){
                                                if (connectNoList2 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 3){
                                                if (connectNoList3 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 4){
                                                if (connectNoList4 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 5){
                                                if (connectNoList5 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 6){
                                                if (connectNoList6 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 7){
                                                if (connectNoList7 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 8){
                                                if (connectNoList8 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 9){
                                                if (connectNoList9 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 10){
                                                if (connectNoList10 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 11){
                                                if (connectNoList11 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            else if (arrayExpandFluorescentAreaTemp [counter3*4+1] == 12){
                                                if (connectNoList12 [arrayExpandFluorescentAreaTemp [counter3*4]] == 1) missingConnectCount++;
                                            }
                                            
                                            if (missingConnectCount == 0){
                                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                
                                                checkList [checkListCount] = counter2, checkListCount++;
                                                checkList [checkListCount] = counter1, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                checkList [checkListCount] = arrayExpandFluorescentAreaTemp [counter3*4], checkListCount++;
                                                checkList [checkListCount] = 34, checkListCount++;
                                                checkList [checkListCount] = 4, checkListCount++;
                                                checkList [checkListCount] = 0, checkListCount++;
                                                
                                                timeCorrectionFind = 1;
                                                treatmentCorrectionFind = 1;
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 1) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList2 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 2) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList3 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 3) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList4 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 4) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList5 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 5) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList6 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 6) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList7 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 7) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList8 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 8) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList9 [counter3] == 1){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 9) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList6 [counter3] == 10){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 10) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList6 [counter3] == 11){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 11) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        for (int counter3 = 1; counter3 <= maxConnectNoGr; counter3++){
                                            if (connectNoList6 [counter3] == 12){
                                                missingConnectCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < expandFluAreaTempCount/4; counter4++){
                                                    if (arrayExpandFluorescentAreaTemp [counter4*4] == counter3 && arrayExpandFluorescentAreaTemp [counter4*4+1] == 12) missingConnectCount++;
                                                }
                                                
                                                if (missingConnectCount == 0){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 35, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                                else if (missingConnectCount > 1){
                                                    if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                                    
                                                    checkList [checkListCount] = counter2, checkListCount++;
                                                    checkList [checkListCount] = counter1, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    checkList [checkListCount] = counter3, checkListCount++;
                                                    checkList [checkListCount] = 37, checkListCount++;
                                                    checkList [checkListCount] = 4, checkListCount++;
                                                    checkList [checkListCount] = 0, checkListCount++;
                                                    
                                                    timeCorrectionFind = 1;
                                                    treatmentCorrectionFind = 1;
                                                }
                                            }
                                        }
                                        
                                        delete [] connectNoList;
                                        delete [] connectNoList2;
                                        delete [] connectNoList3;
                                        delete [] connectNoList4;
                                        delete [] connectNoList5;
                                        delete [] connectNoList6;
                                        delete [] connectNoList7;
                                        delete [] connectNoList8;
                                        delete [] connectNoList9;
                                        delete [] connectNoList10;
                                        delete [] connectNoList11;
                                        delete [] connectNoList12;
                                    }
                                }
                                else{
                                    
                                    if (ifLineFound == 0 && ifAreaFind == 1){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 42, checkListCount++;
                                        checkList [checkListCount] = 4, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                    
                                    if (ifLineFound == 1 && ifAreaFind == 0){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 42, checkListCount++;
                                        checkList [checkListCount] = 4, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                }
                                
                                //*********Lineage Found, Check other arrays*********
                                connectCheck = 0;
                                
                                //=========Connect no consistency check=========
                                for (int counter3 = 0; counter3 < cellLingCheckBaseCount/16; counter3++){
                                    if (cellLingCheckBase [counter3*16+6] != 91 && cellLingCheckBase [counter3*16+1] != -1 && (cellLingCheckBase [counter3*16+4] != cellLingCheckBase [counter3*16+5] || cellLingCheckBase [counter3*16+4] != cellLingCheckBase [counter3*16+8] || cellLingCheckBase [counter3*16+4] != cellLingCheckBase [counter3*16+11] || cellLingCheckBase [counter3*16+4] != cellLingCheckBase [counter3*16+14] || cellLingCheckBase [counter3*16+4] != cellLingCheckBase [counter3*16+15] || cellLingCheckBase [counter3*16+5] != cellLingCheckBase [counter3*16+8] || cellLingCheckBase [counter3*16+5] != cellLingCheckBase [counter3*16+11] || cellLingCheckBase [counter3*16+5] != cellLingCheckBase [counter3*16+14] || cellLingCheckBase [counter3*16+5] != cellLingCheckBase [counter3*16+15] || cellLingCheckBase [counter3*16+8] != cellLingCheckBase [counter3*16+11] || cellLingCheckBase [counter3*16+8] != cellLingCheckBase [counter3*16+14] || cellLingCheckBase [counter3*16+8] != cellLingCheckBase [counter3*16+15] || cellLingCheckBase [counter3*16+11] != cellLingCheckBase [counter3*16+14] || cellLingCheckBase [counter3*16+11] != cellLingCheckBase [counter3*16+15] || cellLingCheckBase [counter3*16+14] != cellLingCheckBase [counter3*16+15])){
                                        
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = cellLingCheckBase [counter3*16], checkListCount++;
                                        checkList [checkListCount] = cellLingCheckBase [counter3*16+1], checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        checkList [checkListCount] = 44, checkListCount++;
                                        checkList [checkListCount] = 20, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        connectCheck = 1;
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellLingCheckBaseCount/16; counter3++){
                                    if (cellLingCheckBase [counter3*16+6] != 91 && cellLingCheckBase [counter3*16+1] != -1 && (cellLingCheckBase [counter3*16+2] != cellLingCheckBase [counter3*16+9] || cellLingCheckBase [counter3*16+2] != cellLingCheckBase [counter3*16+12] || cellLingCheckBase [counter3*16+9] != cellLingCheckBase [counter3*16+12] || cellLingCheckBase [counter3*16+3] != cellLingCheckBase [counter3*16+10] || cellLingCheckBase [counter3*16+3] != cellLingCheckBase [counter3*16+13] || cellLingCheckBase [counter3*16+10] != cellLingCheckBase [counter3*16+13])){
                                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                        
                                        checkList [checkListCount] = counter2, checkListCount++;
                                        checkList [checkListCount] = counter1, checkListCount++;
                                        checkList [checkListCount] = cellLingCheckBase [counter3*16], checkListCount++;
                                        checkList [checkListCount] = cellLingCheckBase [counter3*16+1], checkListCount++;
                                        
                                        if (connectCheck == 1) checkList [checkListCount] = 0, checkListCount++;
                                        else checkList [checkListCount] = cellLingCheckBase [counter3*16+4], checkListCount++;
                                        
                                        checkList [checkListCount] = 45, checkListCount++;
                                        checkList [checkListCount] = 21, checkListCount++;
                                        checkList [checkListCount] = 0, checkListCount++;
                                        
                                        //---If Map is OK, use Rep 1, check GC from map, set new GC
                                        
                                        timeCorrectionFind = 1;
                                        treatmentCorrectionFind = 1;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < checkListCount/8; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<checkList [counterA*8+counterB];
                                //    cout<<" checkList "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < cellLingCheckBaseCount/16; counter3++){
                                    connectCheck = 0;
                                    
                                    if (cellLingCheckBase [counter3*16+6] != 91 && cellLingCheckBase [counter3*16+1] != -1){
                                        if (cellLingCheckBase [counter3*16+4] == 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+5] == 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+8] == 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+11] == 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+15] == 0) connectCheck = 1;
                                        
                                        if (connectCheck == 1){
                                            if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                            
                                            checkList [checkListCount] = counter2, checkListCount++;
                                            checkList [checkListCount] = counter1, checkListCount++;
                                            checkList [checkListCount] = cellLingCheckBase [counter3*16], checkListCount++;
                                            checkList [checkListCount] = cellLingCheckBase [counter3*16+1], checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = 46, checkListCount++;
                                            checkList [checkListCount] = 21, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            
                                            timeCorrectionFind = 1;
                                            treatmentCorrectionFind = 1;
                                        }
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellLingCheckBaseCount/16; counter3++){
                                    connectCheck = 0;
                                    
                                    if (cellLingCheckBase [counter3*16+6] == 91){
                                        if (cellLingCheckBase [counter3*16+4] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+5] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+8] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+9] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+10] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+11] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+14] != 0) connectCheck = 1;
                                        if (cellLingCheckBase [counter3*16+15] != 0) connectCheck = 1;
                                        
                                        if (connectCheck == 1){
                                            if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                            
                                            checkList [checkListCount] = counter2, checkListCount++;
                                            checkList [checkListCount] = counter1, checkListCount++;
                                            checkList [checkListCount] = cellLingCheckBase [counter3*16], checkListCount++;
                                            checkList [checkListCount] = cellLingCheckBase [counter3*16+1], checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            checkList [checkListCount] = 35, checkListCount++;
                                            checkList [checkListCount] = 24, checkListCount++;
                                            checkList [checkListCount] = 0, checkListCount++;
                                            
                                            timeCorrectionFind = 1;
                                            treatmentCorrectionFind = 1;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < cellLingCheckBaseCount/16; counterA++){
                                //    for (int counterB = 0; counterB < 16; counterB++) cout<<" "<<cellLingCheckBase [counterA*16+counterB];
                                //    cout<<" cellLingCheckBase "<<counterA<<endl;
                                //}
                                
                                delete [] cellLingCheckBase;
                            }
                            
                            delete [] arrayPositionReviseVer;
                            delete [] arrayGravityCenterVerRev;
                            delete [] arrayRepairDataHoldVerRev;
                            delete [] arrayTimeSelectedVer;
                            delete [] arrayConnectLineageRelVer;
                            delete [] arrayExpandFluorescentLineTemp;
                            delete [] arrayExpandFluorescentAreaTemp;
                            
                            delete [] mapGravityCenterCalculation;
                            delete [] mapGRPointNo;
                            
                            if (timeCorrectionFind == 0 && self->allErrorHold == 0){
                                if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                                
                                checkList [checkListCount] = counter2, checkListCount++;
                                checkList [checkListCount] = counter1, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                                checkList [checkListCount] = 48, checkListCount++;
                                checkList [checkListCount] = 23, checkListCount++;
                                checkList [checkListCount] = 0, checkListCount++;
                            }
                            
                            if (self->verificationStopFlag == 1){
                                break;
                            }
                        }
                        
                        if (readingErrorCheck2 == 1){
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < imageSize+1; counter2++) delete [] revisedMapVer [counter2];
                    delete [] revisedMapVer;
                    
                    delete [] arrayLineageRepairData;
                    
                    if (treatmentCorrectionFind == 0 && self->allErrorHold == 0){
                        if (checkListCount+30 > checkListLimit) [self checkListUpDate];
                        
                        checkList [checkListCount] = -1, checkListCount++;
                        checkList [checkListCount] = counter1, checkListCount++;
                        checkList [checkListCount] = 0, checkListCount++;
                        checkList [checkListCount] = 0, checkListCount++;
                        checkList [checkListCount] = 0, checkListCount++;
                        checkList [checkListCount] = 48, checkListCount++;
                        checkList [checkListCount] = 23, checkListCount++;
                        checkList [checkListCount] = 0, checkListCount++;
                    }
                }
                
                if (self->verificationStopFlag == 1){
                    self->verificationStopFlag = 0;
                    break;
                }
            }
            
            if (readingErrorCheck == 1 || readingErrorCheck2 == 1){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Tracking/Time One/Other Processes On"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
                
                break;
            }
        }
        
        if (readingErrorCheck == 0 && readingErrorCheck2 == 0){
            self->treatDisplayCall = 1;
            treatVerNameHold = "0";
            self->timeDisplayCall = 1;
            self->timePointValueHold = 0;
            
            delete [] checkErrorTimeList;
            checkErrorTimeList = new int [(checkListCount/8)*2+10];
            checkErrorTimeListCount = 0;
            
            for (int counter1 = 0; counter1 < (checkListCount/8)*2+10; counter1++) checkErrorTimeList [counter1] = -1;
            
            for (int counter1 = 0; counter1 < checkListCount/8; counter1++){
                if (checkList [counter1*8+5] != 48 && checkList [counter1*8] != 0){
                    checkErrorTimeList [checkErrorTimeListCount] = checkList [counter1*8], checkErrorTimeListCount++;
                    checkErrorTimeList [checkErrorTimeListCount] = checkList [counter1*8+1], checkErrorTimeListCount++;
                }
            }
            
            //for (int counterA = 0; counterA < checkListCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<checkList [counterA*8+counterB];
            //    cout<<" checkList "<<counterA<<endl;
            //}
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        
        cleaningProgress = 0;
        self->verDisplayCall = 1;
        
        progressControl = 2;
    });
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = 0;
    tableViewContent = checkResultsCount/16;
    
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
    [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
    
    string entryNumber1;
    string entryNumber2;
    string entryNumber3;
    string entryNumber4;
    string entryNumber5;
    string entryNumber6;
    string entryNumber7;
    string entryNumber8;
    string entryNumber9;
    string entryNumber10;
    string entryNumber11;
    string entryNumber12;
    string entryNumber13;
    string entryNumber14;
    string entryNumber15;
    string entryNumber16;
    
    if (checkResults [rowIndex*16] != -1) entryNumber1 = to_string(checkResults [rowIndex*16]);
    else entryNumber1 = "-";
    
    if (checkResults [rowIndex*16+1] != -1) entryNumber2 = to_string(checkResults [rowIndex*16+1]);
    else entryNumber2 = "-";
    
    if (checkResults [rowIndex*16+2] != -1) entryNumber3 = to_string(checkResults [rowIndex*16+2]);
    else entryNumber3 = "-";
    
    if (checkResults [rowIndex*16+3] != -1) entryNumber4 = to_string(checkResults [rowIndex*16+3]);
    else entryNumber4 = "-";
    
    if (checkResults [rowIndex*16+4] != -1) entryNumber5 = to_string(checkResults [rowIndex*16+4]);
    else entryNumber5 = "-";
    
    if (checkResults [rowIndex*16+5] != -1) entryNumber6 = to_string(checkResults [rowIndex*16+5]);
    else entryNumber6 = "-";
    
    if (checkResults [rowIndex*16+6] != -1) entryNumber7 = to_string(checkResults [rowIndex*16+6]);
    else entryNumber7 = "-";
    
    if (checkResults [rowIndex*16+7] != -1) entryNumber8 = to_string(checkResults [rowIndex*16+7]);
    else entryNumber8 = "-";
    
    if (checkResults [rowIndex*16+8] != -1) entryNumber9 = to_string(checkResults [rowIndex*16+8]);
    else entryNumber9 = "-";
    
    if (checkResults [rowIndex*16+9] != -1) entryNumber10 = to_string(checkResults [rowIndex*16+9]);
    else entryNumber10 = "-";
    
    if (checkResults [rowIndex*16+10] != -1) entryNumber11 = to_string(checkResults [rowIndex*16+10]);
    else entryNumber11 = "-";
    
    if (checkResults [rowIndex*16+11] != -1) entryNumber12 = to_string(checkResults [rowIndex*16+11]);
    else entryNumber12 = "-";
    
    if (checkResults [rowIndex*16+12] != -1) entryNumber13 = to_string(checkResults [rowIndex*16+12]);
    else entryNumber13 = "-";
    
    if (checkResults [rowIndex*16+13] != -1) entryNumber14 = to_string(checkResults [rowIndex*16+13]);
    else entryNumber14 = "-";
    
    if (checkResults [rowIndex*16+14] != -1) entryNumber15 = to_string(checkResults [rowIndex*16+14]);
    else entryNumber15 = "-";
    
    if (checkResults [rowIndex*16+15] != -1) entryNumber16 = to_string(checkResults [rowIndex*16+15]);
    else entryNumber16 = "-";
    
    int statusFlag = 0;
    
    if (dataTypeSend == 1 && checkResults [rowIndex*16+15] > 6) statusFlag = 2;
    if (dataTypeSend == 1 && connectForVerifyHold != 0 && connectForVerifyHold == checkResults [rowIndex*16]) statusFlag = 1;
    if (dataTypeSend == 2 && connectForVerifyHold != 0 && connectForVerifyHold == checkResults [rowIndex*16+9]) statusFlag = 1;
    if (dataTypeSend == 3 && connectForVerifyHold != 0 && connectForVerifyHold == checkResults [rowIndex*16+1]) statusFlag = 1;
    
    if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber1.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber2.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber2.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL2"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber2.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber3.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber3.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL3"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber3.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber4.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber4.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL4"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber4.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber5.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber5.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL5"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber5.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL6"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber6.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL6"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber6.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL6"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber6.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL7"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber7.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL7"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber7.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL7"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber7.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL8"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber8.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL8"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber8.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL8"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber8.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL9"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber9.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL9"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber9.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL9"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber9.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL10"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber10.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL10"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber10.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL10"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber10.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL11"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber11.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL11"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber11.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL11"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber11.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL12"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber12.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL12"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber12.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL12"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber12.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL13"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber13.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL13"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber13.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL13"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber13.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL14"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber14.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL14"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber14.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL14"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber14.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL15"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber15.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL15"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber15.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL15"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber15.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL16"] && statusFlag == 0){
        [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber16.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL16"] && statusFlag == 1){
        [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber16.c_str()) attributes:attributes];
    }
    else if ([[aTableColumn identifier] isEqualToString:@"COL16"] && statusFlag == 2){
        [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
        attrStr = [[NSAttributedString alloc] initWithString:@(entryNumber16.c_str()) attributes:attributes];
    }
    else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    
    return attrStr;
}

-(void)reDisplayWindow{
    if (repairWindowOperation == 3){
        [databaseRepairSetWindow makeKeyAndOrderFront:self];
        repairWindowOperation = 1;
        [databaseRepairSetTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [databaseRepairSetWindow orderOut:self];
    repairWindowOperation = 2;
    databaseRepairSetTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)checkListUpDate{
    int *arrayUpDate = new int [checkListCount+10];
    
    for (int counter1 = 0; counter1 < checkListCount; counter1++) arrayUpDate [counter1] = checkList [counter1];
    
    delete [] checkList;
    checkList = new int [checkListLimit+5000];
    checkListLimit = checkListLimit+5000;
    
    for (int counter1 = 0; counter1 < checkListCount; counter1++) checkList [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)checkResultsUpDate{
    int *arrayUpDate = new int [checkResultsCount+10];
    
    for (int counter1 = 0; counter1 < checkResultsCount; counter1++) arrayUpDate [counter1] = checkResults [counter1];
    
    delete [] checkResults;
    checkResults = new int [checkResultsLimit+5000];
    checkResultsLimit = checkResultsLimit+5000;
    
    for (int counter1 = 0; counter1 < checkResultsCount; counter1++) checkResults [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDatabaseRepairController object:nil];
}

@end
