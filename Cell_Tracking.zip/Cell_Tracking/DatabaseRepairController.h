//
//  DatabaseRepairController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 12/6/16.
//
//

#ifndef DATABASEREPAIRCONTROLLER_H
#define DATABASEREPAIRCONTROLLER_H
#import "Controller.h" 
#endif

@interface DatabaseRepairController : NSObject<NSTableViewDataSource>{
    int verDisplayCall; //Verification display call
    int connectNoRep; //Connect no
    int allErrorHold; //All error or select status
    int treatDisplayCall; //Treat display call
    int timeDisplayCall; //Time display call
    int timePointValueHold; //Time point value display call
    int verificationStopFlag; //Verification stop
    int checkOverrideFlag; //Check over ride
    int treatmentDoFlag; //Treatment Do
    int onlyErrorFlag; //Error point only
    
    IBOutlet NSTextField *verResultsDisplay;
    IBOutlet NSTextField *connectNoDisplay;
    IBOutlet NSTextField *allErrorDisplay;
    IBOutlet NSTextField *treatmentListDisplay;
    IBOutlet NSTextField *listTableDisplay;
    IBOutlet NSTextField *replaceLineFromDisplay;
    IBOutlet NSTextField *replaceLineToDisplay;
    IBOutlet NSTextField *removeLineFromDisplay;
    IBOutlet NSTextField *removeLineToDisplay;
    IBOutlet NSTextField *treatmentMainDisplay;
    IBOutlet NSTextField *errorTimeHoldDisplay;
    IBOutlet NSTextField *repairDisplay1;
    IBOutlet NSTextField *repairDisplay2;
    IBOutlet NSTextField *repairDisplay5;
    IBOutlet NSTextField *repairDisplay6;
    IBOutlet NSTextField *repairDisplay7;
    IBOutlet NSTextField *repairDisplay8;
    IBOutlet NSTextField *repairDisplay9;
    IBOutlet NSTextField *repairDisplay11;
    IBOutlet NSTextField *treatCountDisplay;
    IBOutlet NSTextField *timerCountDisplay;
    IBOutlet NSTextField *checkOverrideStatusDisplay;
    IBOutlet NSTextField *treatmentDoDisplay;
    IBOutlet NSTextField *onlyErrorDisplay;
    IBOutlet NSTextField *errorNoDisplay;
    
    IBOutlet NSWindow *databaseRepairSetWindow;
    IBOutlet NSTableView *tableViewDatabaseTable;
    
    IBOutlet NSProgressIndicator *backSave;
    
    NSWindowController *databaseRepairSetWindowController;
    
    NSTimer *databaseRepairSetTimer;
    NSTimer *databaseRepairSetTimer2;
    
    id dataRepairReadWrite;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)checkListUpDate;
-(void)checkResultsUpDate;
-(void)verificationMain;
-(void)display;

-(IBAction)closeWindow:(id)sender;
-(IBAction)dataVerification:(id)sender;
-(IBAction)analysisData:(id)sender;
-(IBAction)lineageData:(id)sender;
-(IBAction)timeSelectData:(id)sender;
-(IBAction)gravityCenterData:(id)sender;
-(IBAction)positionReviseData:(id)sender;
-(IBAction)relationData:(id)sender;
-(IBAction)associationData:(id)sender;
-(IBAction)allErrorSet:(id)sender;
-(IBAction)checkCurrentTreat:(id)sender;
-(IBAction)checkErrorOnly:(id)sender;

-(IBAction)ccheckOverrideSet:(id)sender;
-(IBAction)stopVerification:(id)sender;
-(IBAction)errorTimeSelect:(id)sender;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
