//
// ListWindow.mm
// Cell_Tracking
//
// Created by Masahiko Sato on 11/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#import "ListWindow.h"

NSString *notificationToListWindow = @"notificationExecuteListWindow";

@implementation ListWindow

- (id)initWithFrame:(NSRect)frame {
    self = [super initWithFrame:frame];
    
    if (self != nil){
        listImage = [[NSImage alloc] initWithContentsOfFile:@""];
        
        totalPageNo = 1;
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToListWindow object:nil];
    }
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    if (cellNoHold == ""){
        string backgroundImagePath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"Blank.jpg";
        NSString *cellImageNSString = [NSString stringWithCString:backgroundImagePath.c_str() encoding: NSASCIIStringEncoding];
        
        listImage = [[NSImage alloc] initWithContentsOfFile:cellImageNSString];
    }
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
        xPositionClick = (int)clickPoint.x;
        yPositionClick = (int)clickPoint.y;
        
        if (listDisplaySelection != 2){
            boxRowNumber = 0;
            boxLineNumber = 0;
            boxX = 0;
            boxY = 0;
            crickCheck = 0;
            
            for (int counter1 = 0; counter1 < 8; counter1++){
                if (xPositionClick >= 30+counter1*110 && xPositionClick <= 30+counter1*110+100){
                    boxLineNumber = counter1+1;
                    boxX = 30+counter1*110;
                    break;
                }
            }
            
            for (int counter1 = 0; counter1 < 4; counter1++){
                if (yPositionClick >= 420-counter1*135 && yPositionClick <= 420-counter1*135+100){
                    boxRowNumber = counter1+1;
                    boxY = 420-counter1*135;
                    break;
                }
            }
            
            if (boxRowNumber > 0 && boxRowNumber <= 4 && boxLineNumber > 0 && boxLineNumber <= 7){
                crickCheck = 1;
                [self setNeedsDisplay:YES];
            }
        }
        else{
            
            crickCheck = 1;
            [self setNeedsDisplay:YES];
        }
    }
}

-(void)keyDown:(NSEvent *)event{
    if (mainSavingInProgress == 0 && cleaningProgress == 0){
        int keyCode = [event keyCode];
        int proceedingFlag = 0;
        crickCheck = 0;
        
        if (listDisplaySelection != 2){
            //-----Image Forward-----
            if (keyCode == 3){
                if (listDisplaySelection == 0 && totalPageNo > currentPageNoCell){
                    currentPageNoCell++;
                    proceedingFlag = 1;
                }
                else if (listDisplaySelection == 1 && totalPageNo > currentPageNoMitosis){
                    currentPageNoMitosis++;
                    proceedingFlag = 1;
                }
            }
            
            //-----Image Backward-----
            if (keyCode == 15){
                if (listDisplaySelection == 0 && 1 < currentPageNoCell){
                    currentPageNoCell--;
                    proceedingFlag = 1;
                }
                else if (listDisplaySelection == 1 && 1 < currentPageNoMitosis){
                    currentPageNoMitosis--;
                    proceedingFlag = 1;
                }
            }
            
            //-----Box Forward-----
            if (keyCode == 124 && listDisplaySelection == 0){
                boxX = 0;
                boxY = 0;
                
                boxLineNumber++;
                
                if (boxLineNumber == 8){
                    boxRowNumber++;
                    
                    if (boxRowNumber == 5){
                        currentPageNoCell++;
                        
                        if (totalPageNo < currentPageNoCell){
                            currentPageNoCell--;
                            boxRowNumber--;
                            boxLineNumber--;
                        }
                        else{
                            
                            boxRowNumber = 1;
                            boxLineNumber = 1;
                            boxX = 30+(boxLineNumber-1)*110;
                            boxY = 420-(boxRowNumber-1)*135;
                            crickCheck = 1;
                            proceedingFlag = 1;
                        }
                    }
                    else{
                        
                        boxLineNumber = 1;
                        boxX = 30+(boxLineNumber-1)*110;
                        boxY = 420-(boxRowNumber-1)*135;
                        crickCheck = 1;
                        proceedingFlag = 1;
                    }
                }
                else{
                    
                    boxX = 30+(boxLineNumber-1)*110;
                    boxY = 420-(boxRowNumber-1)*135;
                    crickCheck = 1;
                    proceedingFlag = 1;
                }
            }
            
            //-----Box Reverse-----
            if (keyCode == 123 && listDisplaySelection == 0){
                boxX = 0;
                boxY = 0;
                
                boxLineNumber--;
                
                if (boxLineNumber < 1){
                    boxRowNumber--;
                    
                    if (boxRowNumber < 1){
                        currentPageNoCell--;
                        
                        if (currentPageNoCell < 1){
                            currentPageNoCell = 1;
                            boxRowNumber = 1;
                            boxLineNumber = 1;
                        }
                        else{
                            
                            boxRowNumber = 4;
                            boxLineNumber = 7;
                            boxX = 30+(boxLineNumber-1)*110;
                            boxY = 420-(boxRowNumber-1)*135;
                            crickCheck = 1;
                            proceedingFlag = 1;
                        }
                    }
                    else{
                        
                        boxLineNumber = 7;
                        boxX = 30+(boxLineNumber-1)*110;
                        boxY = 420-(boxRowNumber-1)*135;
                        crickCheck = 1;
                        proceedingFlag = 1;
                    }
                }
                else{
                    
                    boxX = 30+(boxLineNumber-1)*110;
                    boxY = 420-(boxRowNumber-1)*135;
                    crickCheck = 1;
                    proceedingFlag = 1;
                }
            }
            
            if (proceedingFlag == 1) [self setNeedsDisplay:YES];
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

- (void)drawRect:(NSRect)rect {
    [[NSColor grayColor] set];
    
    NSBezierPath *path;
    path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 820, 560)];
    [path fill];
    
    if (imageEndHold != 0){
        int proceedingFlag = 0;
        int listPointNumber = 0;
        
        ifstream fin;
        
        int *arrayCellListDisplay;
        int cellListCount = 0;
        int arrayCellListDisplayStatus = 0;
        
        //cout<<listDisplaySelection<<" "<<cellLineageNoHold<<" "<<cellNoHold<<" cellInfo"<<endl;
        
        if (cellLineageNoHold != "" && cellNoHold != "" && listDisplaySelection == 0 && listLoadingProcessing == 0){
            proceedingFlag = 1;
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            string cellNoExtract = cellNoHold.substr(1);
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            int cellAmendTemp = atoi(cellNoExtract.c_str());
            int lineageEntryStart = 0;
            int lineageEntryEnd = 0;
            
            for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                    lineageEntryStart = arrayLineageStartEnd [counter1*8+4];
                    lineageEntryEnd = arrayLineageStartEnd [counter1*8+6];
                    break;
                }
            }
            
            //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
            //	for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageData [counterA*8+counterB];
            //	cout<<" arrayLineageData "<<counterA<<endl;
            //}
            
            int *cellExtractedInfo = new int [imageEndHold*8+50], cellExtractedInfoCount = 0;
            
            for (int counter1 = lineageEntryStart; counter1 <= lineageEntryEnd; counter1++){
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+1], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+2], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+3], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+4], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+5], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+6], cellExtractedInfoCount++;
                cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+7], cellExtractedInfoCount++;
            }
            
            listPointNumber = lineageEntryEnd-lineageEntryStart+1;
            
            arrayCellListDisplay = new int [listPatternCount+100];
            cellListCount = 0;
            arrayCellListDisplayStatus = 1;
            
            for (int counter1 = 0; counter1 < listPatternCount; counter1++)  arrayCellListDisplay [cellListCount] = arrayListPattern [counter1], cellListCount++;
            
            delete [] cellExtractedInfo;
        }
        else if (listDisplaySelection == 1){
            proceedingFlag = 1;
            string mitosisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/"+"Mitosis.dat";
            
            long sizeForCopy = 0;
            
            struct stat sizeOfFile;
            
            if (stat(mitosisPath.c_str(), &sizeOfFile) == 0){
                sizeForCopy = sizeOfFile.st_size;
                
                int *arrayCellListDisplayTemp = new int [sizeForCopy+50];
                int cellListDisplayTempCount = 0;
                
                fin.open(mitosisPath.c_str(), ios::in | ios::binary);
                
                if (fin.is_open()){
                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                    fin.read((char*)uploadTemp, sizeForCopy+50);
                    fin.close();
                    
                    unsigned long readPosition = 0;
                    int stepCount = 0;
                    int finData [8];
                    
                    do{
                        
                        if (stepCount == 0){
                            finData [0] = uploadTemp [readPosition], readPosition++;
                            finData [1] = uploadTemp [readPosition], readPosition++; //--2. Entry No
                            finData [2] = uploadTemp [readPosition], readPosition++;
                            finData [3] = uploadTemp [readPosition], readPosition++; //--5. X Position
                            finData [4] = uploadTemp [readPosition], readPosition++;
                            finData [5] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                            finData [6] = uploadTemp [readPosition], readPosition++;
                            finData [7] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                            
                            finData [1] = finData [0]*256+finData [1];
                            finData [3] = finData [2]*256+finData [3];
                            finData [5] = finData [4]*256+finData [5];
                            finData [7] = finData [6]*256+finData [7];
                            
                            if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                            else{
                                
                                arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [1], cellListDisplayTempCount++;
                                arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [3], cellListDisplayTempCount++;
                                arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [5], cellListDisplayTempCount++;
                                arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [7], cellListDisplayTempCount++;
                            }
                        }
                        
                    } while (stepCount != 3);
                    
                    delete [] uploadTemp;
                }
                
                arrayCellListDisplay = new int [cellListDisplayTempCount*3+50];
                cellListCount = 0;
                arrayCellListDisplayStatus = 1;
                
                listPointNumber = 0;
                
                for (int counter1 = 0; counter1 < cellListDisplayTempCount/4; counter1++){
                    arrayCellListDisplay [cellListCount] = arrayCellListDisplayTemp [counter1*4+1], cellListCount++;
                    arrayCellListDisplay [cellListCount] = arrayCellListDisplayTemp [counter1*4+2], cellListCount++;
                    arrayCellListDisplay [cellListCount] = arrayCellListDisplayTemp [counter1*4], cellListCount++;
                    arrayCellListDisplay [cellListCount] = arrayCellListDisplayTemp [counter1*4], cellListCount++;
                    arrayCellListDisplay [cellListCount] = 0, cellListCount++;
                    
                    if (listPointNumber < arrayCellListDisplayTemp [counter1*4]) listPointNumber = arrayCellListDisplayTemp [counter1*4];
                }
                
                delete [] arrayCellListDisplayTemp;
            }
            else proceedingFlag = 0;
        }
        else if (cellLineageNoHold != "" && listDisplaySelection == 2 && listLoadingProcessing == 0){
            [[NSColor whiteColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 820, 560)];
            [path fill];
            
            proceedingFlag = 2;
        }
        
        //for (int counterA = 0; counterA < cellListCount/5; counterA++){
        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayCellListDisplay [counterA*5+counterB];
        //    cout<<" arrayCellListDisplay "<<counterA<<endl;
        //}
        
        if (proceedingFlag == 1){
            [[NSColor lightGrayColor] set];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 920, 570)];
            [path fill];
            
            int displayNumberCount = 0;
            int breakFlag = 0;
            int xPosition = 30;
            int yPosition = 420;
            int pageNoTemp = 0;
            
            if (listDisplaySelection == 0) pageNoTemp = currentPageNoCell;
            else if (listDisplaySelection == 1) pageNoTemp = currentPageNoMitosis;
            
            int lastPageContent = 0;
            totalPageNo = listPointNumber/28; //-----No of page that contains 28 image-----
            
            if (listPointNumber-totalPageNo*28 > 0) lastPageContent = listPointNumber-totalPageNo*28, totalPageNo++; //-----Add one, ast page no-----
            else if (listPointNumber != 0 && listPointNumber-totalPageNo*28 == 0) lastPageContent = 28;
            
            if (pageNoTemp > totalPageNo) pageNoTemp = totalPageNo;
            
            int boxDisplay = 0;
            
            if (pageNoTemp < totalPageNo) boxDisplay = 28;
            else boxDisplay = lastPageContent;
            
            for (int counter1 = 0; counter1 < 4; counter1++){
                for (int counter2 = 0; counter2 < 7; counter2++){
                    if (displayNumberCount == boxDisplay){
                        breakFlag = 1;
                        break;
                    }
                    
                    [[NSColor blackColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPosition, yPosition, 100, 100)];
                    [path fill];
                    
                    [[NSColor blueColor] set];
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPosition-1, yPosition-1, 102, 102)];
                    [path stroke];
                    
                    xPosition = xPosition+110;
                    displayNumberCount++;
                }
                
                if (breakFlag == 1){
                    break;
                }
                
                xPosition = 30;
                yPosition = yPosition-135;
            }
            
            int listPositionCountX = -1;
            int listPositionCountY = 0;
            int xDisplayOrigin = -80;
            int yDisplayOrigin = 420;
            int listDisplayNumber = (pageNoTemp-1)*28;
            int relativePositionCount = 0;
            int startingPositionToDisplay = 0;
            
            for (int counter1 = 0; counter1 < cellListCount/5; counter1++){
                if (arrayCellListDisplay [counter1*5+3] == listDisplayNumber+1){
                    startingPositionToDisplay = counter1;
                    break;
                }
            }
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont systemFontOfSize:9] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
            [NSBezierPath setDefaultLineWidth:0.5];
            
            string extension2;
            string infoDisplayString;
            int displayFrequency = 0;
            int currentPosition = 0;
            int eventType = 0;
            int dataTempX = 0;
            int dataTempY = 0;
            
            for (int counter1 = startingPositionToDisplay; counter1 < cellListCount/5; counter1++){
                if (arrayCellListDisplay [counter1*5+3] != listDisplayNumber){
                    relativePositionCount++;
                    
                    if (relativePositionCount == 29){
                        break;
                    }
                    
                    currentPosition = arrayCellListDisplay [counter1*5+2];
                    listDisplayNumber = arrayCellListDisplay [counter1*5+3];
                    listPositionCountX++;
                    
                    if (listPositionCountX == 7){
                        listPositionCountX = 0, listPositionCountY++;
                        xDisplayOrigin = 30;
                        yDisplayOrigin = yDisplayOrigin-135;
                    }
                    else xDisplayOrigin = xDisplayOrigin+110;
                    
                    if (listDisplaySelection == 0) extension2 = to_string(currentPosition);
                    else extension2 = to_string(listDisplayNumber);
                    
                    if (listDisplaySelection == 0) infoDisplayString = "Time: "+extension2;
                    else infoDisplayString = "Snap: "+extension2;
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                    pointA.x = xDisplayOrigin;
                    pointA.y = yDisplayOrigin+105;
                    [attrStrA drawAtPoint:pointA];
                }
                
                eventType = arrayCellListDisplay [counter1*5+4];
                dataTempX = arrayCellListDisplay [counter1*5];
                dataTempY = arrayCellListDisplay [counter1*5+1];
                
                dataTempX = dataTempX+xDisplayOrigin;
                dataTempY = (100-dataTempY)+yDisplayOrigin;
                
                if (displayFrequency == 0){
                    
                    //-----LINE DATA AMEND-----
                    //-----1. Image No, 2, X position, 3 Y position, 4. Event, 5. Connect No, 6. Lineage NO-----
                    //-----Event type 1: I, 2: P, DStart:31, DEnd: 32, 33, TStart:41, TEnd: 42, 43, 44, HStart: 51, HEnd: 52, 53, 54, 55, M: 6, CD: 7, OF: 8, FUEnd: 91, FUCont: 92-----
                    //-----FMark: 10, MD: 11, EF: 12, NE: 13 (in the event that cell enter image, create Dummy entry mark in Time One)-----
                    
                    if (listDisplaySelection == 0){
                        if (eventType == 1) [[NSColor whiteColor] set];
                        if (eventType == 2) [[NSColor greenColor] set];
                        else if (eventType == 31 || eventType == 32) [[NSColor redColor] set];
                        else if (eventType == 41 || eventType == 42 || eventType == 51 || eventType == 52) [[NSColor magentaColor] set];
                        else if (eventType == 6) [[NSColor cyanColor] set];
                        else if (eventType == 7) [[NSColor blueColor] set];
                        else if (eventType == 8) [[NSColor grayColor] set];
                        else if (eventType == 91 || eventType == 92) [[NSColor yellowColor] set];
                        else if (eventType == 10) [[NSColor orangeColor] set];
                        else if (eventType == 11) [[NSColor purpleColor] set];
                        else if (eventType == 12) [[NSColor whiteColor] set];
                        
                        if (ifStartHold != 0 && currentPosition >= ifStartHold) [[NSColor whiteColor] set];
                        
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect(dataTempX, dataTempY, 1, 1)];
                        [path stroke];
                        
                        displayFrequency = 2;
                    }
                    
                    if (listDisplaySelection == 1){
                        [[NSColor greenColor] set];
                        path = [NSBezierPath bezierPathWithRect: NSMakeRect(dataTempX, dataTempY, 1, 1)];
                        [path stroke];
                    }
                }
                else displayFrequency = 0;
            }
            
            string pageTotalString = to_string(totalPageNo);
            string pageCurrentString = to_string(pageNoTemp);
            
            infoDisplayString = "Page: "+pageCurrentString+"/"+pageTotalString;
            
            [attributesA setObject:[NSFont systemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            [attributesA removeObjectForKey:NSBackgroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 30;
            pointA.y = 545;
            [attrStrA drawAtPoint:pointA];
            
            //-----Selected Box Process-----
            int boxPositionInPage = (boxRowNumber-1)*7+boxLineNumber;
            boxPositionInPage = boxPositionInPage+(pageNoTemp-1)*28;
            
            boxImageNumber = boxPositionInPage;
            
            //cout<<boxRowNumber<<" "<<boxLineNumber<<" "<<boxImageNumber<<" boxNo"<<endl;
            
            if (listDisplaySelection == 0) currentPageNoCell = pageNoTemp;
            else if (listDisplaySelection == 1) currentPageNoMitosis = pageNoTemp;
            
            int listPointNumberTemp = 0;
            
            if (boxPositionInPage > listPointNumber){
                if (listPointNumber > 28) listPointNumberTemp = listPointNumber%28;
                else listPointNumberTemp = listPointNumber;
                
                boxRowNumber = listPointNumberTemp/7+1;
                boxLineNumber = listPointNumberTemp-(listPointNumberTemp/7)*7;
                
                if (boxLineNumber == 0 && boxRowNumber != 1) boxLineNumber = 1;
                
                boxPositionInPage = (boxRowNumber-1)*7+boxLineNumber;
                boxPositionInPage = boxPositionInPage+(pageNoTemp-1)*28;
                
                boxImageNumber = boxPositionInPage;
                
                boxX = 30+(boxLineNumber-1)*110;
                boxY = 420-(boxRowNumber-1)*135;
            }
            
            if (boxPositionInPage <= listPointNumber && boxX != 0 && boxY != 0){
                NSBezierPath *markPath2 = [NSBezierPath bezierPath];
                [markPath2 setLineWidth:5];
                [markPath2 appendBezierPathWithRect: NSMakeRect(boxX-1, boxY-1, 102, 102)];
                [[NSColor colorWithCalibratedRed:0.80 green:0.30 blue:0.50 alpha:0.55] set];
                [markPath2 stroke];
                
                if (listDisplaySelection == 0){
                    int newImageDisplayNo = 0;
                    
                    for (int counter1 = 0; counter1 < cellListCount/5; counter1++){
                        if (arrayCellListDisplay [counter1*5+3] == boxPositionInPage){
                            newImageDisplayNo = arrayCellListDisplay [counter1*5+2];
                            break;
                        }
                    }
                    
                    //cout<<newImageDisplayNo<<" "<<currentPosition<<" "<<trackingOn<<" "<<currentPosition<<" "<<ifStartHold<<" Info "<<clickCheck<<endl;
                    
                    if (newImageDisplayNo != 0 && trackingOn == 1 && crickCheck == 1){
                        [self imageNoSet:newImageDisplayNo];
                        
                        int dataLoadingCheck = 0;
                        int processType = 3;
                        trackingSet = [[TrackingSet alloc] init];
                        dataLoadingCheck = [trackingSet trackingSetMain:processType];
                        
                        if (dataLoadingCheck == 0){
                            listToTrackCall = 1;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Data Read Error"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
            }
        }
        else if (proceedingFlag == 2){
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:2];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(25, 40, 770, 500)];
            [path stroke];
            
            string timeString = "Time point";
            NSString *timeNSString = @(timeString.c_str());
            
            NSFont* font = [NSFont fontWithName:@"Times New Roman" size:12];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSString attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            NSPoint pointA;
            NSAttributedString *attrStrA;
            NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSString attributes:attributesA];
            pointA.x = 410-size2/(double)2;
            pointA.y = 6;
            [attrStrA drawAtPoint:pointA];
            
            double lengthDivision = timeEndHold/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            
            double lengthPix = ((750-40)/(double)timeEndHold)*lengthDivisionInt;
            int numberOfDivision = (int)((750-40)/(double)lengthPix)+1;
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            int sift = 0;
            
            for (int counter1 = 0; counter1 < numberOfDivision; counter1++){
                positionAA.x = 40+lengthPix*counter1;
                positionAA.y = 40;
                positionBB.x = 40+lengthPix*counter1;
                positionBB.y = 50;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSString2 = @(to_string(counter1*lengthDivisionInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSString2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter1*lengthDivision == 0) sift = 1;
                else if (counter1*lengthDivision < 1000) sift = 2;
                
                NSPoint pointA2;
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSString2 attributes:attributesA];
                pointA2.x = (40+lengthPix*counter1)-size2/(double)2-sift;
                pointA2.y = 25;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            string lineageNo = "Lineage: "+cellLineageNoHold;
            
            attrStrA = [[NSAttributedString alloc] initWithString:@(lineageNo.c_str()) attributes:attributesA];
            pointA.x = 30;
            pointA.y = 520;
            [attrStrA drawAtPoint:pointA];
            
            string cellLineageExtract = cellLineageNoHold.substr(1);
            int lineageAmendTemp = atoi(cellLineageExtract.c_str());
            
            double *cellExtractedInfo = new double [imageEndHold*8+50];
            int cellExtractedInfoCount = 0;
            int cellExtractedInfoLimit = imageEndHold*8+50;
            
            double *cellNolist = new double [lineageDataCount*3+50];
            int cellNolistCount = 0;
            
            for (int counter1 = 0; counter1 < lineageDataCount; counter1++) cellNolist [counter1] = 0;
            
            for (int counter1 = 0; counter1 < lineageDataCount/8; counter1++){
                if (arrayLineageData [counter1*8+6] == lineageAmendTemp){
                    if (cellExtractedInfoCount+10 > cellExtractedInfoLimit){
                        double *arrayUpDate = new double [cellExtractedInfoCount+10];
                        
                        for (int counter2 = 0; counter2 < cellExtractedInfoCount; counter2++) arrayUpDate [counter2] = cellExtractedInfo [counter2];
                        
                        delete [] cellExtractedInfo;
                        cellExtractedInfo = new double [cellExtractedInfoLimit+2000];
                        cellExtractedInfoLimit = cellExtractedInfoLimit+2000;
                        
                        for (int counter2 = 0; counter2 < cellExtractedInfoCount; counter2++) cellExtractedInfo [counter2] = arrayUpDate [counter2];
                        delete [] arrayUpDate;
                    }
                    
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+1], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+2], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+3], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+4], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+5], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+6], cellExtractedInfoCount++;
                    cellExtractedInfo [cellExtractedInfoCount] = arrayLineageData [counter1*8+7], cellExtractedInfoCount++;
                    
                    if (arrayLineageData [counter1*8+3] == 1 || arrayLineageData [counter1*8+3] == 31 || arrayLineageData [counter1*8+3] == 41 || arrayLineageData [counter1*8+3] == 51){
                        cellNolist [cellNolistCount] = arrayLineageData [counter1*8+5], cellNolistCount++;
                        cellNolist [cellNolistCount] = arrayLineageData [counter1*8+4], cellNolistCount++;
                        cellNolist [cellNolistCount] = 0, cellNolistCount++;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellExtractedInfo [counterA*8+counterB];
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //for (int counterA = 0; counterA < cellNolistCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<cellNolist [counterA*3+counterB];
            //    cout<<" cellNolist "<<counterA<<endl;
            //}
            
            string extensionNoExtract;
            string extensionNoExtract2;
            string extensionNoExtractB;
            int extensionValueSource = 0;
            double extensionValue = 0;
            double parentInfo = 0;
            
            for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                if (cellNolist [counter2*3] <= 299999999 && cellNolist [counter2*3] >= -299999999){
                    cellNolist [counter2*3+2] = cellNolist [counter2*3]*1000000;
                    cellNolist [counter2*3+1] = cellNolist [counter2*3+1]*1000000;
                }
                else if (cellNolist [counter2*3] <= 499999999 && cellNolist [counter2*3] >= 300000000 && cellNolist [counter2*3+1] <= 299999999 && cellNolist [counter2*3+1] >= -299999999){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    extensionNoExtract2 = to_string(cellNolist [counter2*3+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNolist [counter2*3+2] = extensionValue;
                    cellNolist [counter2*3+1] = cellNolist [counter2*3+1]*1000000;
                }
                else if (cellNolist [counter2*3] >= -499999999 && cellNolist [counter2*3] <= -300000000 && cellNolist [counter2*3+1] <= 299999999 && cellNolist [counter2*3+1] >= -299999999){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                    extensionNoExtractB = to_string(extensionValueSource)+"000";
                    
                    extensionNoExtract2 = to_string(cellNolist [counter2*3+1]);
                    
                    if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                    
                    extensionNoExtract2 = extensionNoExtract2+"000000";
                    extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                    
                    cellNolist [counter2*3+2] = extensionValue;
                    cellNolist [counter2*3+1] = cellNolist [counter2*3+1]*1000000;
                }
            }
            
            for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                if (cellNolist [counter2*3] <= 499999999 && cellNolist [counter2*3] >= 300000000 && cellNolist [counter2*3+1] <= 499999999 && cellNolist [counter2*3+1] >= 300000000){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter3*3] == cellNolist [counter2*3+1]){
                            parentInfo = cellNolist [counter3*3+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter2*3+1] == cellNolist [counter3*3] && cellNolist [counter3*3+1] > 999999999){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNolist [counter2*3+2] = extensionValue;
                            cellNolist [counter2*3+1] = cellNolist [counter3*3+2];
                            break;
                        }
                    }
                }
                else if (cellNolist [counter2*3] >= -499999999 && cellNolist [counter2*3] <= -300000000 && cellNolist [counter2*3+1] >= -499999999 && cellNolist [counter2*3+1] <= -300000000){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter3*3] == cellNolist [counter2*3+1]){
                            parentInfo = cellNolist [counter3*3+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter2*3+1] == cellNolist [counter3*3] && cellNolist [counter3*3+1] < -999999999){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource)+"000";
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNolist [counter2*3+2] = extensionValue;
                            cellNolist [counter2*3+1] = cellNolist [counter3*3+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                if (cellNolist [counter2*3] <= 699999999 && cellNolist [counter2*3] >= 500000000 && cellNolist [counter2*3+1] <= 499999999 && cellNolist [counter2*3+1] >= 300000000){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter3*3] == cellNolist [counter2*3+1]){
                            parentInfo = cellNolist [counter3*3+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter2*3+1] == cellNolist [counter3*3] && cellNolist [counter3*3+1] > 999999999){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNolist [counter2*3+2] = extensionValue;
                            cellNolist [counter2*3+1] = cellNolist [counter3*3+2];
                            break;
                        }
                    }
                }
                else if (cellNolist [counter2*3] >= -699999999 && cellNolist [counter2*3] <= -500000000 && cellNolist [counter2*3+1] >= -499999999 && cellNolist [counter2*3+1] <= -300000000){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter3*3] == cellNolist [counter2*3+1]){
                            parentInfo = cellNolist [counter3*3+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter2*3+1] == cellNolist [counter3*3] && cellNolist [counter3*3+1] < -999999999){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNolist [counter2*3+2] = extensionValue;
                            cellNolist [counter2*3+1] = cellNolist [counter3*3+2];
                            break;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                if (cellNolist [counter2*3] <= 699999999 && cellNolist [counter2*3] >= 500000000 && cellNolist [counter2*3+1] <= 699999999 && cellNolist [counter2*3+1] >= 500000000){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(6, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter3*3] == cellNolist [counter2*3+1]){
                            parentInfo = cellNolist [counter3*3+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter2*3+1] == cellNolist [counter3*3] && cellNolist [counter3*3+1] > 999999999){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNolist [counter2*3+2] = extensionValue;
                            cellNolist [counter2*3+1] = cellNolist [counter3*3+2];
                            break;
                        }
                    }
                }
                else if (cellNolist [counter2*3] >= -699999999 && cellNolist [counter2*3] <= -500000000 && cellNolist [counter2*3+1] >= -699999999 && cellNolist [counter2*3+1] <= -500000000){
                    extensionNoExtract = to_string(cellNolist [counter2*3]);
                    
                    if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                    
                    extensionNoExtract = extensionNoExtract.substr(7, 3);
                    parentInfo = 0;
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter3*3] == cellNolist [counter2*3+1]){
                            parentInfo = cellNolist [counter3*3+1];
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellNolistCount/3; counter3++){
                        if (cellNolist [counter2*3+1] == cellNolist [counter3*3] && cellNolist [counter3*3+1] < -999999999){
                            extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                            extensionNoExtractB = to_string(extensionValueSource);
                            extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                            cellNolist [counter2*3+2] = extensionValue;
                            cellNolist [counter2*3+1] = cellNolist [counter3*3+2];
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellNolistCount/3; counterA++){
            //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<to_string(cellNolist [counterA*3+counterB]);
            //    cout<<" cellNolist "<<counterA<<endl;
            //}
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/8; counter1++){
                for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                    if (cellExtractedInfo [counter1*8+5] == cellNolist [counter2*3]){
                        cellExtractedInfo [counter1*8+5] = cellNolist [counter2*3+2];
                        break;
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                    if (cellExtractedInfo [counter1*8+4] == cellNolist [counter2*3]){
                        cellExtractedInfo [counter1*8+4] = cellNolist [counter2*3+2];
                        break;
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellExtractedInfoCount/8; counterA++){
            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<cellExtractedInfo [counterA*8+counterB];
            //    cout<<" cellExtractedInfo "<<counterA<<endl;
            //}
            
            //-----Lineage display Horizontal set-----
            int numberOfCellEntry = 0;
            int numberOfEventCount = 0;
            
            for (int counter1 = 0; counter1 < cellExtractedInfoCount/8; counter1++){
                if (cellExtractedInfo [counter1*8+3] == 1 || cellExtractedInfo [counter1*8+3] == 31 || cellExtractedInfo [counter1*8+3] == 41 || cellExtractedInfo [counter1*8+3] == 51) numberOfCellEntry++;
                
                if (cellExtractedInfo [counter1*8+3] == 32 || cellExtractedInfo [counter1*8+3] == 42 || cellExtractedInfo [counter1*8+3] == 52 || cellExtractedInfo [counter1*8+3] == 91 || cellExtractedInfo [counter1*8+3] == 6 || cellExtractedInfo [counter1*8+3] == 92 || cellExtractedInfo [counter1*8+3] == 8 || cellExtractedInfo [counter1*8+3] == 10 || cellExtractedInfo [counter1*8+3] == 11 || cellExtractedInfo [counter1*8+3] == 7){
                    numberOfEventCount++;
                }
            }
            
            int *queueLingTemp = new int [numberOfCellEntry*3+10];
            int queueLingTempCount = 0;
            int exceedLimitFlag = 0;
            
            for (int counter1 = 0; counter1 < queueListCount/6; counter1++){
                if (numberOfCellEntry*3+10 > queueLingTempCount+3 && arrayQueueList [counter1*6+1] == cellLineageNoHold && arrayQueueList [counter1*6] == treatmentNameHold){
                    queueLingTemp [queueLingTempCount] = atoi(arrayQueueList [counter1*6+2].substr(1).c_str()), queueLingTempCount++;
                    queueLingTemp [queueLingTempCount] = atoi(arrayQueueList [counter1*6+3].substr(0, arrayQueueList [counter1*6+3].find(":")).c_str()), queueLingTempCount++;
                    queueLingTemp [queueLingTempCount] = atoi(arrayQueueList [counter1*6+3].substr(arrayQueueList [counter1*6+3].find(":")+1).c_str()), queueLingTempCount++;
                }
                else if (numberOfCellEntry*3+10 <= queueLingTempCount+3){
                    exceedLimitFlag = 1;
                }
            }
            
            for (int counter1 = 0; counter1 < doneListCount/5; counter1++){
                if (numberOfCellEntry*3+10 > queueLingTempCount+3 && arrayDoneList [counter1*5+1] == cellLineageNoHold && arrayDoneList [counter1*5] == treatmentNameHold){
                    queueLingTemp [queueLingTempCount] = atoi(arrayDoneList [counter1*5+2].substr(1).c_str()), queueLingTempCount++;
                    queueLingTemp [queueLingTempCount] = atoi(arrayDoneList [counter1*5+3].substr(0, arrayDoneList [counter1*5+3].find(":")).c_str()), queueLingTempCount++;
                    queueLingTemp [queueLingTempCount] = atoi(arrayDoneList [counter1*5+3].substr(arrayDoneList [counter1*5+3].find(":")+1).c_str()), queueLingTempCount++;
                }
                else if (numberOfCellEntry*3+10 <= queueLingTempCount+3){
                    exceedLimitFlag = 1;
                }
            }
            
            if (exceedLimitFlag == 0){
                double *horizontalList = new double [numberOfCellEntry*7+50];
                int horizontalListCount = 0;
                double *eventList = new double [numberOfEventCount*5+50];
                int eventListCount = 0;
                int largestTimePoint = 0;
                int findFlag = 0;
                
                for (int counter1 = 0; counter1 < cellExtractedInfoCount/8; counter1++){
                    if (cellExtractedInfo [counter1*8+3] == 1 || cellExtractedInfo [counter1*8+3] == 31 || cellExtractedInfo [counter1*8+3] == 41 || cellExtractedInfo [counter1*8+3] == 51){
                        horizontalList [horizontalListCount] = cellExtractedInfo [counter1*8+5], horizontalListCount++;
                        horizontalList [horizontalListCount] = cellExtractedInfo [counter1*8+6], horizontalListCount++;
                        horizontalList [horizontalListCount] = 0, horizontalListCount++;
                        horizontalList [horizontalListCount] = cellExtractedInfo [counter1*8+2], horizontalListCount++;
                        
                        largestTimePoint = 0;
                        findFlag = 0;
                        
                        for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                            if ((cellExtractedInfo [counter2*8+3] == 32 || cellExtractedInfo [counter2*8+3] == 42 || cellExtractedInfo [counter2*8+3] == 52 || cellExtractedInfo [counter2*8+3] == 91 || cellExtractedInfo [counter2*8+3] == 6 || cellExtractedInfo [counter2*8+3] == 92 || cellExtractedInfo [counter2*8+3] == 8 || cellExtractedInfo [counter2*8+3] == 10 || cellExtractedInfo [counter2*8+3] == 11 || cellExtractedInfo [counter2*8+3] == 7) && cellExtractedInfo [counter2*8+5] == cellExtractedInfo [counter1*8+5] && cellExtractedInfo [counter2*8+6] == cellExtractedInfo [counter1*8+6]){
                                eventList [eventListCount] = cellExtractedInfo [counter2*8+5], eventListCount++;
                                eventList [eventListCount] = cellExtractedInfo [counter2*8+6], eventListCount++;
                                eventList [eventListCount] = cellExtractedInfo [counter2*8+2], eventListCount++;
                                eventList [eventListCount] = cellExtractedInfo [counter2*8+3], eventListCount++;
                                eventList [eventListCount] = 0, eventListCount++;
                            }
                        }
                        
                        for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                            if ((cellExtractedInfo [counter2*8+3] == 32 || cellExtractedInfo [counter2*8+3] == 42 || cellExtractedInfo [counter2*8+3] == 52 || cellExtractedInfo [counter2*8+3] == 91) && cellExtractedInfo [counter2*8+5] == cellExtractedInfo [counter1*8+5] && cellExtractedInfo [counter2*8+6] == cellExtractedInfo [counter1*8+6]){
                                horizontalList [horizontalListCount] = cellExtractedInfo [counter2*8+2], horizontalListCount++;
                                horizontalList [horizontalListCount] = cellExtractedInfo [counter2*8+3], horizontalListCount++;
                                findFlag = 1;
                                break;
                            }
                            else{
                                
                                if (cellExtractedInfo [counter2*8+5] == cellExtractedInfo [counter1*8+5] && cellExtractedInfo [counter2*8+6] == cellExtractedInfo [counter1*8+6]){
                                    if (cellExtractedInfo [counter2*8+2] > largestTimePoint) largestTimePoint = (int)cellExtractedInfo [counter2*8+2];
                                }
                            }
                        }
                        
                        if (findFlag == 0){
                            horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                            horizontalList [horizontalListCount] = 2, horizontalListCount++;
                        }
                        
                        if (cellExtractedInfo [counter1*8+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                        else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                    }
                }
                
                //for (int counterA = 0; counterA <  horizontalListCount/7; counterA++){
                //    cout<<horizontalList [counterA*7]<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" "<<horizontalList [counterA*7+5]<<" horizontalList"<<endl;
                //}
                
                //for (int counterA = 0; counterA <  eventListCount/5; counterA++){
                //    cout<<eventList [counterA*5]<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
                //}
                
                int terminationFlag = 0;
                int lineageSelect = 0;
                int cellSelectPosition = 0;
                double cellSelect = 0;
                
                double *horizontalList2 = new double [numberOfCellEntry*7+50];
                int horizontalListCount2 = 0;
                double *eventList2 = new double [numberOfEventCount*6+50];
                int eventListCount2 = 0;
                
                for (int counter1 = 0; counter1 < numberOfEventCount*6+50; counter1++) eventList2 [counter1] = 0;
                
                int entryOrder = 0;
                
                do{
                    
                    terminationFlag = 1;
                    lineageSelect = 100000;
                    
                    for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                        if (horizontalList [counter1*7+1] != -1){
                            lineageSelect = (int)horizontalList [counter1*7+1];
                            break;
                        }
                    }
                    
                    if (lineageSelect == 100000) terminationFlag = 0;
                    else{
                        
                        cellSelect = 999999999999999;
                        cellSelectPosition = 0;
                        
                        for (int counter1 = 0; counter1 < horizontalListCount/7; counter1++){
                            if (horizontalList [counter1*7] != -1 && horizontalList [counter1*7+1] == lineageSelect && horizontalList [counter1*7] < cellSelect){
                                cellSelect = horizontalList [counter1*7];
                                cellSelectPosition = counter1;
                            }
                        }
                        
                        if (cellSelect != 999999999999999){
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //-----cell no---
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //-----Lineage no----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //-----zero----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //-----Time start-----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //-----Time end-----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //-----Event last-----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //-----Event I-----
                            
                            for (int counter1 = 0; counter1 < eventListCount/5; counter1++){
                                if (eventList [counter1*5] == horizontalList [cellSelectPosition*7] && eventList [counter1*5+1] == horizontalList [cellSelectPosition*7+1]){
                                    eventList2 [eventListCount2] = eventList [counter1 *5], eventListCount2++; //-----Cell no-----
                                    eventList2 [eventListCount2] = eventList [counter1 *5+1], eventListCount2++; //-----Lineage no-----
                                    eventList2 [eventListCount2] = eventList [counter1 *5+2], eventListCount2++; //-----Time-----
                                    eventList2 [eventListCount2] = eventList [counter1 *5+3], eventListCount2++; //-----Event-----
                                    eventList2 [eventListCount2] = entryOrder, eventListCount2++; //-----Entry order-----
                                }
                            }
                            
                            horizontalList [cellSelectPosition*7] = -1;
                            horizontalList [cellSelectPosition*7+1] = -1;
                            
                            entryOrder++;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                //for (int counterA = 0; counterA <  horizontalListCount2/7; counterA++){
                //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" horizontalList2"<<endl;
                //}
                
                //-----Lineage display Vertical set-----
                double *verticalList = new double [numberOfEventCount*8+50];
                int verticalListCount = 0;
                
                double parentCellNo = 0;
                double cellNoLow = 0;
                double cellNoHigh = 0;
                int cellNoLowPosition = 0;
                int cellNoHighPosition = 0;
                int matchFindFlag = 0;
                
                for (int counter1 = 0; counter1 < cellExtractedInfoCount/8; counter1++){
                    if (cellExtractedInfo [counter1*8+3] == 91){
                        matchFindFlag = 0;
                        
                        for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                            if ((verticalList [counter2*9] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+1] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+2] == cellExtractedInfo [counter1*8+2]) || (verticalList [counter2*9+3] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+4] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+5] == cellExtractedInfo [counter1*8+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                                if (cellExtractedInfo [counter2*8+3] == 92 && cellExtractedInfo [counter1*8+4] == cellExtractedInfo [counter2*8+5] && cellExtractedInfo [counter1*8+7] == cellExtractedInfo [counter2*8+6] && cellExtractedInfo [counter2*8+2] == cellExtractedInfo [counter1*8+2]){
                                    verticalList [verticalListCount] = cellExtractedInfo [counter1*8+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter1*8+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter1*8+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter2*8+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter2*8+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter2*8+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 91, verticalListCount++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (cellExtractedInfo [counter1*8+3] == 92){
                        matchFindFlag = 0;
                        
                        for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                            if ((verticalList [counter2*9] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+1] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+2] == cellExtractedInfo [counter1*8+2]) || (verticalList [counter2*9+3] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+4] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+5] == cellExtractedInfo [counter1*8+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                                if (cellExtractedInfo [counter2*8+3] == 91 && cellExtractedInfo [counter1*8+4] == cellExtractedInfo [counter2*8+5] && cellExtractedInfo [counter1*8+7] == cellExtractedInfo [counter2*8+6] && cellExtractedInfo [counter2*8+2] == cellExtractedInfo [counter1*8+2]){
                                    verticalList [verticalListCount] = cellExtractedInfo [counter1*8+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter1*8+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter1*8+2], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter2*8+5], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter2*8+6], verticalListCount++;
                                    verticalList [verticalListCount] = cellExtractedInfo [counter2*8+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 91, verticalListCount++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (cellExtractedInfo [counter1*8+3] == 31){
                        parentCellNo = cellExtractedInfo [counter1*8+4];
                        matchFindFlag = 0;
                        
                        for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                            if ((verticalList [counter2*9] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+1] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+2] == cellExtractedInfo [counter1*8+2]) || (verticalList [counter2*9+3] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+4] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+5] == cellExtractedInfo [counter1*8+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                                if (cellExtractedInfo [counter2*8+3] == 31 && cellExtractedInfo [counter1*8+6] == cellExtractedInfo [counter2*8+6] && cellExtractedInfo [counter2*8+4] == parentCellNo && cellExtractedInfo [counter2*8+5] != cellExtractedInfo [counter1*8+5] && cellExtractedInfo [counter2*8+2] == cellExtractedInfo [counter1*8+2]){
                                    if (cellExtractedInfo [counter2*8+5] > cellExtractedInfo [counter1*8+5]){
                                        verticalList [verticalListCount] = cellExtractedInfo [counter1*8+5], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter1*8+6], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter1*8+2], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter2*8+5], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter2*8+6], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter2*8+2], verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 31, verticalListCount++;
                                    }
                                    else{
                                        
                                        verticalList [verticalListCount] = cellExtractedInfo [counter2*8+5], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter2*8+6], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter2*8+2], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter1*8+5], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter1*8+6], verticalListCount++;
                                        verticalList [verticalListCount] = cellExtractedInfo [counter1*8+2], verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 31, verticalListCount++;
                                    }
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (cellExtractedInfo [counter1*8+3] == 41){
                        parentCellNo = cellExtractedInfo [counter1*8+4];
                        cellNoLow = cellExtractedInfo [counter1*8+5];
                        cellNoHigh = cellExtractedInfo [counter1*8+5];
                        cellNoLowPosition = counter1;
                        cellNoHighPosition = counter1;
                        
                        matchFindFlag = 0;
                        
                        for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                            if ((verticalList [counter2*9] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+1] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+2] == cellExtractedInfo [counter1*8+2]) || (verticalList [counter2*9+3] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+4] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+5] == cellExtractedInfo [counter1*8+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                                if (cellExtractedInfo [counter2*8+3] == 41 && cellExtractedInfo [counter1*8+6] == cellExtractedInfo [counter2*8+6] && cellExtractedInfo [counter2*8+4] == parentCellNo && cellExtractedInfo [counter2*8+5] != cellExtractedInfo [counter1*8+5]){
                                    if (cellExtractedInfo [counter2*8+5] > cellNoHigh){
                                        cellNoHigh = cellExtractedInfo [counter2*8+5];
                                        cellNoHighPosition = counter2;
                                    }
                                    
                                    if (cellExtractedInfo [counter2*8+5] < cellNoLow){
                                        cellNoHigh = cellExtractedInfo [counter2*8+5];
                                        cellNoLowPosition = counter2;
                                    }
                                }
                            }
                            
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoLowPosition*8+5], verticalListCount++;
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoLowPosition*8+6], verticalListCount++;
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoLowPosition*8+2], verticalListCount++;
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoHighPosition*8+5], verticalListCount++;
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoHighPosition*8+6], verticalListCount++;
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoHighPosition*8+2], verticalListCount++;
                            verticalList [verticalListCount] = 0, verticalListCount++;
                            verticalList [verticalListCount] = 0, verticalListCount++;
                            verticalList [verticalListCount] = 41, verticalListCount++;
                        }
                    }
                    else if (cellExtractedInfo [counter1*8+3] == 51){
                        parentCellNo = cellExtractedInfo [counter1*8+4];
                        cellNoLow = cellExtractedInfo [counter1*8+5];
                        cellNoHigh = cellExtractedInfo [counter1*8+5];
                        cellNoLowPosition = counter1;
                        cellNoHighPosition = counter1;
                        
                        matchFindFlag = 0;
                        
                        for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                            if ((verticalList [counter2*9] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+1] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+2] == cellExtractedInfo [counter1*8+2]) || (verticalList [counter2*9+3] == cellExtractedInfo [counter1*8+5] && verticalList [counter2*9+4] == cellExtractedInfo [counter1*8+6] && verticalList [counter2*9+5] == cellExtractedInfo [counter1*8+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                                if (cellExtractedInfo [counter2*8+3] == 51 && cellExtractedInfo [counter1*8+6] == cellExtractedInfo [counter2*8+6] && cellExtractedInfo [counter2*8+4] == parentCellNo && cellExtractedInfo [counter2*8+5] != cellExtractedInfo [counter1*8+5]){
                                    if (cellExtractedInfo [counter2*8+5] > cellNoHigh){
                                        cellNoHigh = cellExtractedInfo [counter2*8+5];
                                        cellNoHighPosition = counter2;
                                    }
                                    
                                    if (cellExtractedInfo [counter2*8+5] < cellNoLow){
                                        cellNoHigh = cellExtractedInfo [counter2*8+5];
                                        cellNoLowPosition = counter2;
                                    }
                                }
                            }
                            
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoLowPosition*8+5], verticalListCount++; //-----cell no 1-----
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoLowPosition*8+6], verticalListCount++; //-----Lineage no 1-----
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoLowPosition*8+2], verticalListCount++; //-----time 1-----
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoHighPosition*8+5], verticalListCount++; //-----cell no 2-----
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoHighPosition*8+6], verticalListCount++; //-----Lineage no 2-----
                            verticalList [verticalListCount] = cellExtractedInfo [cellNoHighPosition*8+2], verticalListCount++; //-----time 2-----
                            verticalList [verticalListCount] = 0, verticalListCount++; //-----cell order 1-----
                            verticalList [verticalListCount] = 0, verticalListCount++; //-----cell order 2-----
                            verticalList [verticalListCount] = 51, verticalListCount++; //-----event-----
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< verticalList [counterA*9+counterB];
                //    cout<<" verticalList "<<counterA<<endl;
                //}
                
                for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        if (horizontalList2 [counter2*7] == verticalList [counter1*9] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+1]){
                            verticalList [counter1*9+6] = counter2;
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        if (horizontalList2 [counter2*7] == verticalList [counter1*9+3] && horizontalList2 [counter2*7+1] == verticalList [counter1*9+4]){
                            verticalList [counter1*9+7] = counter2;
                            break;
                        }
                    }
                }
                
                double increment = (480-52)/(double)(numberOfCellEntry+1);
                double horizontalIncrement = (750-40)/(double)timeEndHold;
                
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1];
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
                
                //for (int counterA = 0; counterA <  eventListCount2/5; counterA++){
                //    cout<<eventList2 [counterA*5]<<" "<<eventList2 [counterA*5+1]<<" "<< eventList2 [counterA*5+2]<<" "<<eventList2 [counterA*5+3]<<" "<<eventList2 [counterA*5+4]<<"   event2"<<endl;
                //}
                
                //-----Live vertical line-----
                int positionShiftA = 0;
                
                //-----Lineage Display Vertical-----
                [NSBezierPath setDefaultLineWidth:2];
                
                for (int counter1 = 0; counter1 < verticalListCount/9; counter1++){
                    if (verticalList [counter1*9+8] == 91) [[NSColor orangeColor] set];
                    else if (verticalList [counter1*9+8] == 31) [[NSColor blackColor] set];
                    else if (verticalList [counter1*9+8] == 41) [[NSColor redColor] set];
                    else if (verticalList [counter1*9+8] == 51) [[NSColor redColor] set];
                    
                    positionAA.x = 40+verticalList [counter1*9+2]*horizontalIncrement;
                    positionAA.y = 52+increment+verticalList [counter1*9+6]*increment;
                    positionBB.x = 40+verticalList [counter1*9+5]*horizontalIncrement;
                    positionBB.y = 52+increment+verticalList [counter1*9+7]*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [[NSColor blackColor] set];
                
                int endType = 0;
                int endType2 = 0;
                int endReach = 0;
                int startType = 0;
                int checkFind = 0;
                int cellNoOriginal = 0;
                int newPointSet = 0;
                string liveName = "";
                string cellNumberString;
                string horizontalString;
                
                NSBezierPath *pathCircle;
                
                for (int counter1 = 0; counter1 < horizontalListCount2/7; counter1++){
                    [[NSColor blackColor] set];
                    
                    cellNoOriginal = 0;
                    
                    for (int counter2 = 0; counter2 < cellNolistCount/3; counter2++){
                        if (horizontalList2 [counter1*7] == cellNolist [counter2*3+2]){
                            cellNoOriginal = (int)(cellNolist [counter2*3]);
                            break;
                        }
                    }
                    
                    if (horizontalList2 [counter1*7+5] == 32 || horizontalList2 [counter1*7+3] == 42 || horizontalList2 [counter1*7+3] == 52) endType = 1;
                    else endType = 0;
                    
                    endType2 = 0;
                    
                    for (int counter2 = 0; counter2 < cellExtractedInfoCount/8; counter2++){
                        if (cellExtractedInfo [counter2*8+2] == horizontalList2 [counter1*7+4] && horizontalList2 [counter1*7+4] != timeEndHold && horizontalList2 [counter1*7] == cellExtractedInfo [counter2*8+5] && cellExtractedInfo [counter2*8+3] == 2){
                            endType2 = 1;
                            break;
                        }
                    }
                    
                    if (horizontalList2 [counter1*7+6] == 1) startType = 1;
                    else startType = 0;
                    
                    if (xPositionClick >= 40+horizontalList2 [counter1*7+3]*horizontalIncrement && xPositionClick <= 40+horizontalList2 [counter1*7+4]*horizontalIncrement && yPositionClick >= 52+increment+counter1*increment-4 && yPositionClick <= 52+increment+counter1*increment+4){
                        timePointSelect = (xPositionClick-40)/(double)horizontalIncrement;
                        cellNoForSelect = cellNoOriginal;
                        
                        newPointSet = 1;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    
                    if (endType2 == 1){
                        [[NSColor blueColor] set];
                    }
                    else [[NSColor blackColor] set];
                    
                    positionAA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement;
                    positionAA.y = 52+increment+counter1*increment;
                    
                    if (endType == 1) positionBB.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement;
                    else positionBB.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement;
                    
                    positionBB.y = 52+increment+counter1*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    for (int counter2 = 0; counter2 < eventListCount2/5; counter2++){
                        if (eventList2 [counter2*5+4] == counter1){
                            if (eventList2 [counter2*5+3] == 91 || eventList2 [counter2*5+3] == 92){
                                [[NSColor orangeColor] set];
                                pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 47+increment+counter1*increment, 12, 12)];
                                [pathCircle fill];
                            }
                            else if (eventList2 [counter2*5+3] == 6){
                                [[NSColor cyanColor] set];
                                pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 47+increment+counter1*increment, 12, 12)];
                                [pathCircle fill];
                            }
                            else if (eventList2 [counter2*5+3] == 7){
                                [[NSColor magentaColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 47+increment+counter1*increment, 12, 12)];
                                [path fill];
                            }
                            else if (eventList2 [counter2*5+3] == 8){
                                [[NSColor grayColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 47+increment+counter1*increment, 12, 12)];
                                [path fill];
                            }
                            else if (eventList2 [counter2*5+3] == 10){
                                [[NSColor redColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 47+increment+counter1*increment, 12, 12)];
                                [path stroke];
                            }
                            else if (eventList2 [counter2*5+3] == 11){
                                [[NSColor blueColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(40+eventList2 [counter2*5+2]*horizontalIncrement-6, 47+increment+counter1*increment, 12, 12)];
                                [path fill];
                            }
                        }
                    }
                    
                    checkFind = 0;
                    
                    for (int counter3 = 0; counter3 < queueLingTempCount/3; counter3++){
                        if (cellNoOriginal == queueLingTemp [counter3*3] && queueLingTemp [counter3*3+1] != queueLingTemp [counter3*3+2]){
                            checkFind = queueLingTemp [counter3*3+2];
                            break;
                        }
                    }
                    
                    if (checkFind != 0){
                        [[NSColor greenColor] set];
                        pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(40+checkFind*horizontalIncrement-6, 47+increment+counter1*increment, 10, 10)];
                        [pathCircle fill];
                    }
                    
                    if (startType == 0){
                        if (to_string(horizontalList2 [counter1*7+3]).length() == 1) positionShiftA = 7;
                        else if (to_string(horizontalList2 [counter1*7+3]).length() == 2) positionShiftA = 14;
                        else if (to_string(horizontalList2 [counter1*7+3]).length() == 3) positionShiftA = 21;
                        else if (to_string(horizontalList2 [counter1*7+3]).length() == 4) positionShiftA = 28;
                        
                        if ((int)to_string(horizontalList2 [counter1*7+3]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+3]).substr(0, to_string(horizontalList2 [counter1*7+3]).find ("."));
                        else horizontalString = to_string(horizontalList2 [counter1*7+3]);
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement-positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                    else{
                        
                        [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                        
                        if (to_string(horizontalList2 [counter1*7+1]).length() == 1) positionShiftA = 7;
                        else if (to_string(horizontalList2 [counter1*7+1]).length() == 2) positionShiftA = 11;
                        else if (to_string(horizontalList2 [counter1*7+1]).length() == 3) positionShiftA = 17;
                        else if (to_string(horizontalList2 [counter1*7+1]).length() == 4) positionShiftA = 24;
                        
                        if ((int)to_string(horizontalList2 [counter1*7+1]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+1]).substr(0, to_string(horizontalList2 [counter1*7+1]).find ("."));
                        else horizontalString = to_string(horizontalList2 [counter1*7+1]);
                        
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+horizontalList2 [counter1*7+3]*horizontalIncrement-positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                    
                    if (endType == 1){
                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        
                        if (to_string(horizontalList2 [counter1*7+4]+1).length() == 1) positionShiftA = 1;
                        else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 2) positionShiftA = 2;
                        else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 3) positionShiftA = 3;
                        else if (to_string(horizontalList2 [counter1*7+4]+1).length() == 4) positionShiftA = 4;
                        
                        if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                        else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                        pointA.x = 40+(horizontalList2 [counter1*7+4]+1)*horizontalIncrement+positionShiftA;
                        pointA.y = 47+increment+counter1*increment;
                        [attrStrA drawAtPoint:pointA];
                    }
                    else{
                        
                        endReach = 0;
                        
                        for (int counter3 = 0; counter3 < queueLingTempCount/3; counter3++){
                            if (cellNoOriginal == queueLingTemp [counter3*3] && queueLingTemp [counter3*3+1] == queueLingTemp [counter3*3+2]){
                                endReach = 1;
                                break;
                            }
                        }
                        
                        if (to_string(horizontalList2 [counter1*7+4]).length() == 1) positionShiftA = 1;
                        else if (to_string(horizontalList2 [counter1*7+4]).length() == 2) positionShiftA = 2;
                        else if (to_string(horizontalList2 [counter1*7+4]).length() == 3) positionShiftA = 3;
                        else if (to_string(horizontalList2 [counter1*7+4]).length() == 4) positionShiftA = 4;
                        
                        if ((int)to_string(horizontalList2 [counter1*7+4]).find (".") != -1) horizontalString = to_string(horizontalList2 [counter1*7+4]).substr(0, to_string(horizontalList2 [counter1*7+4]).find ("."));
                        else horizontalString = to_string(horizontalList2 [counter1*7+4]);
                        
                        if (endReach == 0){
                            [attributesA setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                            pointA.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement+positionShiftA;
                            pointA.y = 47+increment+counter1*increment;
                            [attrStrA drawAtPoint:pointA];
                        }
                        else{
                            
                            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA = [[NSAttributedString alloc] initWithString:@(horizontalString.c_str()) attributes:attributesA];
                            pointA.x = 40+horizontalList2 [counter1*7+4]*horizontalIncrement+positionShiftA;
                            pointA.y = 47+increment+counter1*increment;
                            [attrStrA drawAtPoint:pointA];
                        }
                    }
                }
                
                delete [] horizontalList;
                delete [] horizontalList2;
                delete [] eventList;
                delete [] eventList2;
                delete [] verticalList;
                
                if (newPointSet != 0 && trackingOn == 1 && crickCheck == 1 && timePointSelect >= 1){
                    [self imageNoSet:(int)timePointSelect];
                    
                    int dataLoadingCheck = 0;
                    int processType = 3;
                    trackingSet = [[TrackingSet alloc] init];
                    dataLoadingCheck = [trackingSet trackingSetMain:processType];
                    
                    if (dataLoadingCheck == 0){
                        cellNumberString = to_string(cellNoForSelect);
                        
                        if (cellNoForSelect >= 0){
                            if (cellNumberString.length() == 1) cellNumberString = "C00000000"+cellNumberString;
                            else if (cellNumberString.length() == 2) cellNumberString = "C0000000"+cellNumberString;
                            else if (cellNumberString.length() == 3) cellNumberString = "C000000"+cellNumberString;
                            else if (cellNumberString.length() == 4) cellNumberString = "C00000"+cellNumberString;
                            else if (cellNumberString.length() == 5) cellNumberString = "C0000"+cellNumberString;
                            else if (cellNumberString.length() == 6) cellNumberString = "C000"+cellNumberString;
                            else if (cellNumberString.length() == 7) cellNumberString = "C00"+cellNumberString;
                            else if (cellNumberString.length() == 8) cellNumberString = "C0"+cellNumberString;
                            else if (cellNumberString.length() == 9) cellNumberString = "C"+cellNumberString;
                        }
                        else{
                            
                            cellNumberString = cellNumberString.substr(1);
                            
                            if (cellNumberString.length() == 1) cellNumberString = "C-00000000"+cellNumberString;
                            else if (cellNumberString.length() == 2) cellNumberString = "C-0000000"+cellNumberString;
                            else if (cellNumberString.length() == 3) cellNumberString = "C-000000"+cellNumberString;
                            else if (cellNumberString.length() == 4) cellNumberString = "C-00000"+cellNumberString;
                            else if (cellNumberString.length() == 5) cellNumberString = "C-0000"+cellNumberString;
                            else if (cellNumberString.length() == 6) cellNumberString = "C-000"+cellNumberString;
                            else if (cellNumberString.length() == 7) cellNumberString = "C-00"+cellNumberString;
                            else if (cellNumberString.length() == 8) cellNumberString = "C-0"+cellNumberString;
                            else if (cellNumberString.length() == 9) cellNumberString = "C-"+cellNumberString;
                        }
                        
                        cellNoHold = cellNumberString;
                        imageNumber = imageNumberTrackForDisplay;
                        
                        cellLineageExtract = cellLineageNoHold.substr(1);
                        string cellNoExtract = cellNoHold.substr(1);
                        lineageAmendTemp = atoi(cellLineageExtract.c_str());
                        int cellAmendTemp = atoi(cellNoExtract.c_str());
                        
                        int lineageEntryStart = 10000;
                        int lineageEntryEnd = 0;
                        int lineageEntryStartHold = 10000;
                        int lineageEntryEndHold = 0;
                        
                        for (int counter1 = 0; counter1 < lineageStartEndCount/8; counter1++){
                            if (arrayLineageStartEnd [counter1*8] == lineageAmendTemp && arrayLineageStartEnd [counter1*8+1] == cellAmendTemp){
                                for (int counter2 = arrayLineageStartEnd [counter1*8+4]; counter2 <= arrayLineageStartEnd [counter1*8+6]; counter2++){
                                    if (arrayLineageData [counter2*8+2] > lineageEntryEndHold) lineageEntryEndHold = arrayLineageData [counter2*8+2], lineageEntryEnd = counter2;
                                    if (arrayLineageData [counter2*8+2] < lineageEntryStartHold) lineageEntryStartHold = arrayLineageData [counter2*8+2], lineageEntryStart = counter2;
                                }
                                
                                break;
                            }
                        }
                        
                        if (xyPositionListStatus == 1) delete [] arrayXYPositionList;
                        arrayXYPositionList = new int [(lineageEntryEnd-lineageEntryStart+1)*10+50];
                        xyPositionListCount = 0;
                        xyPositionListStatus = 1;
                        
                        for (int counter1 = lineageEntryStart; counter1 <= lineageEntryEnd; counter1++){
                            if (arrayLineageData [counter1*8+2] == imageNumberTrackForDisplay){
                                xCellPosition = arrayLineageData [counter1*8];
                                yCellPosition = arrayLineageData [counter1*8+1];
                            }
                            
                            arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter1*8+2], xyPositionListCount++; //-----Image Number-----
                            arrayXYPositionList [xyPositionListCount] = 0, xyPositionListCount++; //-----Connect Number-----
                            arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter1*8], xyPositionListCount++; //-----X Position-----
                            arrayXYPositionList [xyPositionListCount] = arrayLineageData [counter1*8+1], xyPositionListCount++; //-----Y Position-----
                            arrayXYPositionList [xyPositionListCount] = 1, xyPositionListCount++; //-----Target-----
                        }
                        
                        int lineSetError = 0;
                        
                        lineSet = [[LineSet alloc] init];
                        lineSetError = [lineSet dataRead:imageNumber];
                        
                        if (lineSetError == 0){
                            do{
                                
                                if (masterLineForTrackingStatus == 1 && masterLineForDisplayStatus == 1 && masterLineGravityCenterStatus == 1 && masterLineGCDisplayStatus == 1){
                                    listToTrackCall = 1;
                                }
                                
                            } while (masterLineForTrackingStatus == 0 || masterLineForDisplayStatus == 0 || masterLineGravityCenterStatus == 0 || masterLineGCDisplayStatus == 0);
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Data Read Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            
            delete [] cellNolist;
            delete [] cellExtractedInfo;
            delete [] queueLingTemp;
        }
        else{
            
            NSRect srcRect;
            srcRect.origin.x = 0;
            srcRect.origin.y = 0;
            srcRect.size.width = 820;
            srcRect.size.height = 560;
            
            [listImage drawInRect:rect fromRect:srcRect operation:NSCompositingOperationCopy fraction:1.0f];
            
            if (listDisplaySelection == 0 && listLoadingProcessing != 0){
                NSPoint pointA;
                NSAttributedString *attrStrA;
                NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
                
                [attributesA setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
                
                string infoDisplayString = "List Data Loading";
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
                pointA.x = 10;
                pointA.y = 540;
                [attrStrA drawAtPoint:pointA];
            }
        }
        
        if (arrayCellListDisplayStatus == 1) delete [] arrayCellListDisplay;
    }
    
    if (imageLoadMonitor > 0) imageLoadMonitor++;
    
    crickCheck = 0;
}

-(void)imageNoSet:(int)setNumber{
    if (setNumber <= imageNumberTrackForDisplay && ifEntry == 1){
        if (ifStartHold != 0 && setNumber < ifStartHold){
            ifEntry = 0;
            fluorescentNo1 = fluorescentNoHold1;
            fluorescentNo2 = fluorescentNoHold2;
            fluorescentNo3 = fluorescentNoHold3;
            fluorescentNo4 = fluorescentNoHold4;
            fluorescentNo5 = fluorescentNoHold5;
            fluorescentNo6 = fluorescentNoHold6;
            fluorescentEntryCount = fluorescentEntryCountHold;
            fluorescentName1 = fluorescentNameHold1;
            fluorescentName2 = fluorescentNameHold2;
            fluorescentName3 = fluorescentNameHold3;
            fluorescentName4 = fluorescentNameHold4;
            fluorescentName5 = fluorescentNameHold5;
            fluorescentName6 = fluorescentNameHold6;
            
            string extension = to_string(setNumber);
            
            if (extension.length() == 1) extension = "000"+extension;
            else if (extension.length() == 2) extension = "00"+extension;
            else if (extension.length() == 3) extension = "0"+extension;
            
            string extension2 = to_string(fluorescentNo1);
            string fluorescentPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
            
            struct stat sizeOfFile;
            
            if (stat(fluorescentPath1.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == setNumber){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        break;
                    }
                }
                
                if (matchFind == 0){
                    string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
                    
                    if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                        int nearestCount = 0;
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                            if (arrayFluorescentCutOff [counter1*7] < setNumber){
                                if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                    nearestCount = arrayFluorescentCutOff [counter1*7];
                                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                                }
                            }
                        }
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        if (nearestCount != 0){
                            arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                        }
                        else{
                            
                            arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        }
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                    else{
                        
                        fluorescentCutOff1 = 150;
                        fluorescentCutOff2 = 150;
                        fluorescentCutOff3 = 150;
                        fluorescentCutOff4 = 150;
                        fluorescentCutOff5 = 150;
                        fluorescentCutOff6 = 150;
                        
                        if (fluorescentCutOffStatus == 0){
                            arrayFluorescentCutOff = new int [imageEndHold*7];
                            fluorescentCutOffCount = 0;
                            fluorescentCutOffStatus = 1;
                        }
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        
                        ofstream oin;
                        oin.open(cutOffPath.c_str(), ios::out);
                        
                        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                        
                        oin<<"End"<<endl;
                        oin.close();
                    }
                }
            }
        }
        else if (ifStartHold != 0 && setNumber >= ifStartHold){
            int nextLoad = 0;
            
            for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= setNumber){
                    nextLoad = counter1/15+1;
                }
                else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                    break;
                }
            }
            
            if (nextLoad > 0){
                nextLoad--;
                
                fluorescentNo1 = 0;
                fluorescentNo2 = 0;
                fluorescentNo3 = 0;
                fluorescentNo4 = 0;
                fluorescentNo5 = 0;
                fluorescentNo6 = 0;
                fluorescentEntryCount = 0;
                fluorescentName1 = "";
                fluorescentName2 = "";
                fluorescentName3 = "";
                fluorescentName4 = "";
                fluorescentName5 = "";
                fluorescentName6 = "";
                
                fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                
                if (fluorescentEntryCount >= 1){
                    fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                    fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                }
                
                if (fluorescentEntryCount >= 2){
                    fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                    fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                }
                
                if (fluorescentEntryCount >= 3){
                    fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                    fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                }
                
                if (fluorescentEntryCount >= 4){
                    fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                    fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                }
                
                if (fluorescentEntryCount >= 5){
                    fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                    fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                }
                
                if (fluorescentEntryCount >= 6){
                    fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                    fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                }
            }
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            struct stat sizeOfFile;
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == setNumber){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        
                        break;
                    }
                }
                
                if (matchFind == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < setNumber){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
            else{
                
                fluorescentCutOff1 = 150;
                fluorescentCutOff2 = 150;
                fluorescentCutOff3 = 150;
                fluorescentCutOff4 = 150;
                fluorescentCutOff5 = 150;
                fluorescentCutOff6 = 150;
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
        }
        
        imageNumberTrackForDisplay = setNumber;
        fluorescentValueDisplayControl = 1;
        setStatus4 = 4;
    }
    else if (setNumber <= imageNumberTrackForDisplay && ifEntry == 0) imageNumberTrackForDisplay = setNumber;
    else if (setNumber >= imageNumberTrackForDisplay && ifEntry == 0){
        if (ifStartHold != 0 && setNumber >= ifStartHold){
            ifEntry = 1;
            fluorescentNoHold1 = fluorescentNo1;
            fluorescentNoHold2 = fluorescentNo2;
            fluorescentNoHold3 = fluorescentNo3;
            fluorescentNoHold4 = fluorescentNo4;
            fluorescentNoHold5 = fluorescentNo5;
            fluorescentNoHold6 = fluorescentNo6;
            fluorescentEntryCountHold = fluorescentEntryCount;
            fluorescentNameHold1 = fluorescentName1;
            fluorescentNameHold2 = fluorescentName2;
            fluorescentNameHold3 = fluorescentName3;
            fluorescentNameHold4 = fluorescentName4;
            fluorescentNameHold5 = fluorescentName5;
            fluorescentNameHold6 = fluorescentName6;
            
            int nextLoad = 0;
            
            for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
                if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= setNumber){
                    nextLoad = counter1/15+1;
                }
                else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                    break;
                }
            }
            
            if (nextLoad > 0){
                nextLoad--;
                
                fluorescentNo1 = 0;
                fluorescentNo2 = 0;
                fluorescentNo3 = 0;
                fluorescentNo4 = 0;
                fluorescentNo5 = 0;
                fluorescentNo6 = 0;
                fluorescentEntryCount = 0;
                fluorescentName1 = "";
                fluorescentName2 = "";
                fluorescentName3 = "";
                fluorescentName4 = "";
                fluorescentName5 = "";
                fluorescentName6 = "";
                
                fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
                fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
                
                if (fluorescentEntryCount >= 1){
                    fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                    fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
                }
                
                if (fluorescentEntryCount >= 2){
                    fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                    fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
                }
                
                if (fluorescentEntryCount >= 3){
                    fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                    fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
                }
                
                if (fluorescentEntryCount >= 4){
                    fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                    fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
                }
                
                if (fluorescentEntryCount >= 5){
                    fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                    fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
                }
                
                if (fluorescentEntryCount >= 6){
                    fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                    fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
                }
                
                if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
                    trackingUpperLimit = setNumber;
                    trackingOnInfoDisplay = 1;
                }
            }
            
            if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
                trackingUpperLimit = setNumber;
                trackingOnInfoDisplay = 1;
            }
            
            string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
            
            struct stat sizeOfFile;
            
            if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
                int matchFind = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] == setNumber){
                        fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                        fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                        fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                        fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                        fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                        fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        matchFind = 1;
                        
                        break;
                    }
                }
                
                if (matchFind == 0){
                    int nearestCount = 0;
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                        if (arrayFluorescentCutOff [counter1*7] < setNumber){
                            if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                                nearestCount = arrayFluorescentCutOff [counter1*7];
                                fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                                fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                                fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                                fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                                fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                                fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                            }
                        }
                    }
                    
                    if (fluorescentCutOffStatus == 0){
                        arrayFluorescentCutOff = new int [imageEndHold*7];
                        fluorescentCutOffCount = 0;
                        fluorescentCutOffStatus = 1;
                    }
                    
                    if (nearestCount != 0){
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                    }
                    else{
                        
                        arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                        arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    }
                    
                    ofstream oin;
                    oin.open(cutOffPath.c_str(), ios::out);
                    
                    for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                    
                    oin<<"End"<<endl;
                    oin.close();
                }
            }
            else{
                
                fluorescentCutOff1 = 150;
                fluorescentCutOff2 = 150;
                fluorescentCutOff3 = 150;
                fluorescentCutOff4 = 150;
                fluorescentCutOff5 = 150;
                fluorescentCutOff6 = 150;
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
            
            imageNumberTrackForDisplay = setNumber;
            fluorescentValueDisplayControl = 1;
            setStatus4 = 4;
        }
        else if (ifStartHold == 0 || setNumber < ifStartHold) imageNumberTrackForDisplay = setNumber;
    }
    else if (setNumber >= imageNumberTrackForDisplay && ifEntry == 1){
        int nextLoad = 0;
        
        for (int counter1 = 0; counter1 < 450; counter1 = counter1+15){
            if (atoi(arrayIFDataHold [counter1].c_str()) != 0 && atoi(arrayIFDataHold [counter1+14].c_str()) <= setNumber){
                nextLoad = counter1/15+1;
            }
            else if (atoi(arrayIFDataHold [counter1].c_str()) == 0){
                break;
            }
        }
        
        if (nextLoad > 0){
            nextLoad--;
            
            fluorescentNo1 = 0;
            fluorescentNo2 = 0;
            fluorescentNo3 = 0;
            fluorescentNo4 = 0;
            fluorescentNo5 = 0;
            fluorescentNo6 = 0;
            fluorescentEntryCount = 0;
            fluorescentName1 = "";
            fluorescentName2 = "";
            fluorescentName3 = "";
            fluorescentName4 = "";
            fluorescentName5 = "";
            fluorescentName6 = "";
            
            fluorescentEntryCount = atoi(arrayIFDataHold [nextLoad*15+13].c_str());
            fluorescentRoundNo = arrayIFDataHold [nextLoad*15];
            
            if (fluorescentEntryCount >= 1){
                fluorescentNo1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                fluorescentName1 = arrayIFDataHold [nextLoad*15+1];
            }
            
            if (fluorescentEntryCount >= 2){
                fluorescentNo2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                fluorescentName2 = arrayIFDataHold [nextLoad*15+2];
            }
            
            if (fluorescentEntryCount >= 3){
                fluorescentNo3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                fluorescentName3 = arrayIFDataHold [nextLoad*15+3];
            }
            
            if (fluorescentEntryCount >= 4){
                fluorescentNo4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                fluorescentName4 = arrayIFDataHold [nextLoad*15+4];
            }
            
            if (fluorescentEntryCount >= 5){
                fluorescentNo5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                fluorescentName5 = arrayIFDataHold [nextLoad*15+5];
            }
            
            if (fluorescentEntryCount >= 6){
                fluorescentNo6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                fluorescentName6 = arrayIFDataHold [nextLoad*15+6];
            }
            
            if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
                trackingUpperLimit = setNumber;
                trackingOnInfoDisplay = 1;
            }
        }
        
        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
        
        struct stat sizeOfFile;
        
        if (stat(cutOffPath.c_str(), &sizeOfFile) == 0){
            int matchFind = 0;
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == setNumber){
                    fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                    fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                    fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                    fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                    fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                    fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                    matchFind = 1;
                    
                    break;
                }
            }
            
            if (matchFind == 0){
                int nearestCount = 0;
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                    if (arrayFluorescentCutOff [counter1*7] < setNumber){
                        if (nearestCount < arrayFluorescentCutOff [counter1*7]){
                            nearestCount = arrayFluorescentCutOff [counter1*7];
                            fluorescentCutOff1 = arrayFluorescentCutOff [counter1*7+1];
                            fluorescentCutOff2 = arrayFluorescentCutOff [counter1*7+2];
                            fluorescentCutOff3 = arrayFluorescentCutOff [counter1*7+3];
                            fluorescentCutOff4 = arrayFluorescentCutOff [counter1*7+4];
                            fluorescentCutOff5 = arrayFluorescentCutOff [counter1*7+5];
                            fluorescentCutOff6 = arrayFluorescentCutOff [counter1*7+6];
                        }
                    }
                }
                
                if (fluorescentCutOffStatus == 0){
                    arrayFluorescentCutOff = new int [imageEndHold*7];
                    fluorescentCutOffCount = 0;
                    fluorescentCutOffStatus = 1;
                }
                
                if (nearestCount != 0){
                    arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
                }
                else{
                    
                    arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                    arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
                }
                
                ofstream oin;
                oin.open(cutOffPath.c_str(), ios::out);
                
                for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
                
                oin<<"End"<<endl;
                oin.close();
            }
        }
        else{
            
            fluorescentCutOff1 = 150;
            fluorescentCutOff2 = 150;
            fluorescentCutOff3 = 150;
            fluorescentCutOff4 = 150;
            fluorescentCutOff5 = 150;
            fluorescentCutOff6 = 150;
            
            if (fluorescentCutOffStatus == 0){
                arrayFluorescentCutOff = new int [imageEndHold*7];
                fluorescentCutOffCount = 0;
                fluorescentCutOffStatus = 1;
            }
            
            arrayFluorescentCutOff [fluorescentCutOffCount] = setNumber, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = 150, fluorescentCutOffCount++;
            
            ofstream oin;
            oin.open(cutOffPath.c_str(), ios::out);
            
            for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
            
            oin<<"End"<<endl;
            oin.close();
        }
        
        if (lineModificationFlag == 1 && trackingUpperLimit < setNumber){
            trackingUpperLimit = setNumber;
            trackingOnInfoDisplay = 1;
        }
        
        imageNumberTrackForDisplay = setNumber;
        fluorescentValueDisplayControl = 1;
        setStatus4 = 4;
    }
    
    if (ifEntry == 0) fluorescentDisplayNo = 0;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToListWindow object:nil];
}

@end
