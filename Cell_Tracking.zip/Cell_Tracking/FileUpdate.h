//
//  FileUpdate.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#ifndef FILEUPDATE_H
#define FILEUPDATA_H
#import "Controller.h"
#endif

@interface FileUpdate : NSObject{
}

-(void)fileDeleteUpDate;
-(void)expandFluorescentDataUpDate;
-(void)expandFluorescentOutlineUpDate;
-(void)lineageStartEndUpDate;
-(void)queueListUpDate;
-(void)doneListUpDate;
-(void)gravityCenterRevUpDate;
-(void)associateDataUpDate;
-(void)lineageExtractionUpDate;
-(void)referenceLineCountUpDate;
-(void)eventSequenceUpDate;
-(void)lineageGRCurrentUpDate;
-(void)masterLineGCUpDate;
-(void)masterLineSelectedUpDate;
-(void)masterLineSelectedDisplayUpDate;
-(void)masterLineGCDisplayUpDate;
-(void)positionRevSelectedUpDate;
-(void)timeSelectedUpDate;
-(void)connectLineageRelUpDate;

-(int)nameCheck;

@end
