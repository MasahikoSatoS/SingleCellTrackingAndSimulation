//
//  SearchController.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-11-30.
//
//

#ifndef SEARCHCONTROLLER_H
#define SEARCHCONTROLLER_H
#import "Controller.h" 
#endif

@interface SearchController : NSObject {
    IBOutlet NSWindow *searchWindow;
    
    NSTimer *searchTimer;
    
    NSWindowController *searchWindowController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(IBAction)closeWindow:(id)sender;

@end
