//
// GapFill.mm
// cell_Tracking
//
// Created by Masahiko Sato on 20/12/12.
// Copyright 2012 Masahiko Sato All rights reserved.
//

#import "GapFill.h"

@implementation GapFill

-(void)gapFilling:(int)originX :(int)originY :(int)destinationX :(int)destinationY{
    int xDistance = destinationX-originX;
    int yDistance = destinationY-originY;
    int xIncrement = 0;
    int yIncrement = 0;
    int xLinear = 0;
    int yLinear = 0;
    int remaining = 0;
    int numberOfPixTemp = 0;
    
    if (abs(xDistance) >= abs(yDistance)){
        numberOfPixTemp = abs(xDistance)-1;
        
        if (yDistance != 0){
            xIncrement = abs(xDistance)/abs(yDistance);
            remaining = abs(xDistance)%abs(yDistance);
        }
        else{
            
            xIncrement = abs(xDistance);
            xLinear = 1;
        }
    }
    if (abs(xDistance) < abs(yDistance)){
        numberOfPixTemp = abs(yDistance)-1;
        
        if (xDistance != 0){
            yIncrement = abs(yDistance)/abs(xDistance);
            remaining = abs(yDistance)%abs(xDistance);
        }
        else{
            
            yIncrement = abs(yDistance);
            yLinear = 1;
        }
    }
    
    int **pixelValueTemp2 = new int *[numberOfPixTemp+1];
    for (int counter1 = 0; counter1 < numberOfPixTemp+1; counter1++) pixelValueTemp2 [counter1] = new int [3];
    
    int remainingAddCount = abs(remaining);
    int xDistanceTemp = originX;
    int yDistanceTemp = originY;
    
    if (xIncrement != 0 && yIncrement == 0){
        int incrementSet = 0;
        int xIncrementCount = 0;
        int yIncrementCount = 0;
        int addCountFlag = 0;
        
        if (xDistance < 0) xIncrementCount = -1;
        else xIncrementCount = 1;
        
        if (yDistance < 0) yIncrementCount = -1;
        else if (xLinear == 1) yIncrementCount = 0;
        else yIncrementCount = 1;
        
        for (int counter1 = 0; counter1 < numberOfPixTemp; counter1++){
            pixelValueTemp2 [counter1][0] = xDistanceTemp+xIncrementCount;
            pixelValueTemp2 [counter1][1] = yDistanceTemp+yIncrementCount;
            incrementSet++;
            
            if (incrementSet == abs(xIncrement)){
                if (remainingAddCount != 0 && addCountFlag == 0){
                    incrementSet = incrementSet-1;
                    remainingAddCount = remainingAddCount-1;
                    addCountFlag = 1;
                }
                else{
                    
                    incrementSet = 0;
                    addCountFlag = 0;
                    
                    if (yDistance < 0) yIncrementCount = yIncrementCount-1;
                    else if (xLinear == 1) yIncrementCount = 0;
                    else yIncrementCount++;
                }
            }
            if (xDistance < 0) xIncrementCount = xIncrementCount-1;
            else xIncrementCount++;
        }
    }
    
    if (xIncrement == 0 && yIncrement != 0){
        int incrementSet = 0;
        int xIncrementCount = 0;
        int yIncrementCount = 0;
        int addCountFlag = 0;
        
        if (xDistance < 0) xIncrementCount = -1;
        else if (yLinear == 1) xIncrementCount = 0;
        else xIncrementCount = 1;
        
        if (yDistance < 0) yIncrementCount = -1;
        else yIncrementCount = 1;
        
        for (int counter1 = 0; counter1 < numberOfPixTemp; counter1++){
            pixelValueTemp2 [counter1][0] = xDistanceTemp+xIncrementCount;
            pixelValueTemp2 [counter1][1] = yDistanceTemp+yIncrementCount;
            incrementSet++;
            
            if (incrementSet == abs(yIncrement)){
                if (remainingAddCount != 0 && addCountFlag == 0){
                    incrementSet = incrementSet-1;
                    remainingAddCount = remainingAddCount-1;
                    addCountFlag = 1;
                }
                else{
                    
                    incrementSet = 0;
                    addCountFlag = 0;
                    
                    if (xDistance < 0) xIncrementCount = xIncrementCount-1;
                    else if (yLinear == 1) xIncrementCount = 0;
                    else xIncrementCount++;
                }
            }
            
            if (yDistance < 0) yIncrementCount = yIncrementCount-1;
            else yIncrementCount++;
        }
    }
    
    for (int counter1 = 0; counter1 < numberOfPixTemp; counter1++){
        if (gapDataCount+4 > gapDataLimit){
            int *arrayDataUpData = new int [gapDataCount+10];
            
            for (int counter2 = 0; counter2 < gapDataCount; counter2++) arrayDataUpData [counter2] = arrayGapData [counter2];
            
            delete [] arrayGapData;
            arrayGapData = new int [gapDataLimit+500];
            gapDataLimit = gapDataLimit+500;
            
            for (int counter2 = 0; counter2 < gapDataCount; counter2++) arrayGapData [counter2] = arrayDataUpData [counter2];
            delete [] arrayDataUpData;
        }
        
        arrayGapData [gapDataCount] = pixelValueTemp2 [counter1][0], gapDataCount++;
        arrayGapData [gapDataCount] = pixelValueTemp2 [counter1][1], gapDataCount++;
    }
    
    for (int counter1 = 0; counter1 < numberOfPixTemp+1; counter1++) delete [] pixelValueTemp2 [counter1];
    delete [] pixelValueTemp2;
    
    return;
}

@end
