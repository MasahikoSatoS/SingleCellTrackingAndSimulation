//
//  ActiveProcessMonitor.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2015-03-09.
//
//

#ifndef ACTIVEPROCESSMONITOR_H
#define ACTIVEPROCESSMONITOR_H
#import "Controller.h" 
#endif

@interface ActiveProcessMonitor : NSObject {
    NSTimer *activeProcessTimer;
}

-(id)init;
-(void)dealloc;
-(void)processControl;

@end
