//
//  ImageSequenceDisplayController.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2/2/17.
//
//

#import "ImageSequenceDisplayController.h"

NSString *notificationToImageSequenceDisplayController = @"notificationImageSequenceDisplayController";

@implementation ImageSequenceDisplayController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToImageSequenceDisplayController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    seqOpenFlag = 1;
    
    [seqWindowNoDisplay setStringValue:@"10"];
    [imageWidthDisplay setStringValue:@"130"];
    
    imageSeqWindowController = [[NSWindowController alloc] initWithWindowNibName:@"SeqDisplay"];
    [imageSeqWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [imageSeqWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [imageSeqWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    imageSeqTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(displayWindow) userInfo:nil repeats:YES];
}

-(void)displayWindow{
    if (seqWindowFront == 1){
        [imageSeqWindow makeKeyAndOrderFront:self];
        
        NSWindow *keyWindow = [[NSApplication sharedApplication] keyWindow];
        NSString *title = [keyWindow title];
        
        if ([title isEqualToString:@"Image sequence"]){
            seqWindowFront = 0;
        }
    }
}

-(IBAction)forwardSeq:(id)sender{
    if (seqImageCheck != 0){
        int seqImageTopTemp = seqImageTop;
        
        if (noOfSeqDisplay == 0) seqImageTop = seqImageTop+6;
        else if (noOfSeqDisplay == 1) seqImageTop = seqImageTop+9;
        
        if (seqImageTop <= seqImageLast){
            seqImageNoSet1 = 0;
            seqImageNoSet2 = 0;
            seqImageNoSet3 = 0;
            seqImageNoSet4 = 0;
            seqImageNoSet5 = 0;
            seqImageNoSet6 = 0;
            seqImageNoSet7 = 0;
            seqImageNoSet8 = 0;
            seqImageNoSet9 = 0;
            seqImageNoSet10 = 0;
            
            seqImageNoSet1 = seqImageTop;
            if (timeEndHold >= seqImageTop+1) seqImageNoSet2 = seqImageTop+1;
            if (timeEndHold >= seqImageTop+2) seqImageNoSet3 = seqImageTop+2;
            if (timeEndHold >= seqImageTop+3) seqImageNoSet4 = seqImageTop+3;
            if (timeEndHold >= seqImageTop+4) seqImageNoSet5 = seqImageTop+4;
            if (timeEndHold >= seqImageTop+5) seqImageNoSet6 = seqImageTop+5;
            if (timeEndHold >= seqImageTop+6) seqImageNoSet7 = seqImageTop+6;
            if (timeEndHold >= seqImageTop+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageTop+7;
            if (timeEndHold >= seqImageTop+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageTop+8;
            if (timeEndHold >= seqImageTop+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageTop+9;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
            
            if (noOfSeqDisplay == 1){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            seqImageTop = seqImageTopTemp;
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Load Needed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)backSeq:(id)sender{
    if (seqImageCheck != 0){
        int seqImageTopTemp = seqImageTop;
        
        if (noOfSeqDisplay == 0) seqImageTop = seqImageTop-6;
        else if (noOfSeqDisplay == 1) seqImageTop = seqImageTop-9;
        
        if (seqImageTopTemp != seqImageFirst && seqImageTop < seqImageFirst) seqImageTop = seqImageFirst;
        
        if (seqImageTop >= seqImageFirst){
            seqImageNoSet1 = 0;
            seqImageNoSet2 = 0;
            seqImageNoSet3 = 0;
            seqImageNoSet4 = 0;
            seqImageNoSet5 = 0;
            seqImageNoSet6 = 0;
            seqImageNoSet7 = 0;
            seqImageNoSet8 = 0;
            seqImageNoSet9 = 0;
            seqImageNoSet10 = 0;
            
            seqImageNoSet1 = seqImageTop;
            if (timeEndHold >= seqImageTop+1) seqImageNoSet2 = seqImageTop+1;
            if (timeEndHold >= seqImageTop+2) seqImageNoSet3 = seqImageTop+2;
            if (timeEndHold >= seqImageTop+3) seqImageNoSet4 = seqImageTop+3;
            if (timeEndHold >= seqImageTop+4) seqImageNoSet5 = seqImageTop+4;
            if (timeEndHold >= seqImageTop+5) seqImageNoSet6 = seqImageTop+5;
            if (timeEndHold >= seqImageTop+6) seqImageNoSet7 = seqImageTop+6;
            if (timeEndHold >= seqImageTop+7 && noOfSeqDisplay == 1) seqImageNoSet8 = seqImageTop+7;
            if (timeEndHold >= seqImageTop+8 && noOfSeqDisplay == 1) seqImageNoSet9 = seqImageTop+8;
            if (timeEndHold >= seqImageTop+9 && noOfSeqDisplay == 1) seqImageNoSet10 = seqImageTop+9;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay1 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay2 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay3 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay4 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay5 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay6 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay7 object:self];
            
            if (noOfSeqDisplay == 1){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay8 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay9 object:self];
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToImageDisplay10 object:self];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            seqImageTop = seqImageTopTemp;
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image Load Needed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageWidthChange:(id)sender{
    if (imageWidthSeq == 130){
        imageWidthSeq = 50;
        [imageWidthDisplay setStringValue:@"50"];
    }
    else if (imageWidthSeq == 50){
        imageWidthSeq = 60;
        [imageWidthDisplay setStringValue:@"60"];
    }
    else if (imageWidthSeq == 60){
        imageWidthSeq = 70;
        [imageWidthDisplay setStringValue:@"70"];
    }
    else if (imageWidthSeq == 70){
        imageWidthSeq = 80;
        [imageWidthDisplay setStringValue:@"80"];
    }
    else if (imageWidthSeq == 80){
        imageWidthSeq = 90;
        [imageWidthDisplay setStringValue:@"90"];
    }
    else if (imageWidthSeq == 90){
        imageWidthSeq = 100;
        [imageWidthDisplay setStringValue:@"100"];
    }
    else if (imageWidthSeq == 100){
        imageWidthSeq = 110;
        [imageWidthDisplay setStringValue:@"110"];
    }
    else if (imageWidthSeq == 110){
        imageWidthSeq = 120;
        [imageWidthDisplay setStringValue:@"120"];
    }
    else if (imageWidthSeq == 120){
        imageWidthSeq = 130;
        [imageWidthDisplay setStringValue:@"130"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)displayNoChange:(id)sender{
    if (noOfSeqDisplay == 0){
        noOfSeqDisplay = 1;
        [seqWindowNoDisplay setStringValue:@"10"];
    }
    else{
        
        noOfSeqDisplay = 0;
        [seqWindowNoDisplay setStringValue:@"7"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)closeWindow:(id)sender{
    [imageSeqWindow orderOut:self];
    imageSeqOperation = 2;
    imageSeqTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (imageSeqOperation == 3){
        [imageSeqWindow makeKeyAndOrderFront:self];
        imageSeqOperation = 1;
        [imageSeqTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToImageSequenceDisplayController object:nil];
}

@end
