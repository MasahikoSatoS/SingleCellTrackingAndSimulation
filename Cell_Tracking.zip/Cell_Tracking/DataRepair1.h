//
//  DataRepair1.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-05-28.
//

#ifndef DATABASEREPAIR1_H
#define DATABASEREPAIR1_H
#import "Controller.h"
#endif

@interface DataRepair1 : NSObject{
    id dataRepairReadWrite;
}

-(void)reconstruct:(int)processType;

-(IBAction)dataRepair1:(id)sender;
-(IBAction)dataRepair2:(id)sender;
-(IBAction)dataRepair5:(id)sender;
-(IBAction)dataRepair6:(id)sender;
-(IBAction)dataRepair7:(id)sender;
-(IBAction)dataRepair8:(id)sender;
-(IBAction)dataRepair8B:(id)sender;
-(IBAction)dataRepair9:(id)sender;
-(IBAction)dataRepair10:(id)sender;
-(IBAction)dataRepair11:(id)sender;

@end
