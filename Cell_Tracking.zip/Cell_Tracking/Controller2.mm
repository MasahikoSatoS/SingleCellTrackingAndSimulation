//
//  Controller2.m
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2022-03-31.
//

#import "Controller2.h"

@implementation Controller2

-(IBAction)restorePreviousData:(id)sender{
    if (trackingOn == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Erase Tracking Data And Load From Temp-Saved File?"];
        [alert setInformativeText:@"This processing will take a few minutes"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            restoreDataFlag = 1;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Before Tracking Starts"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deletePreviousData:(id)sender{
    if (trackingOn == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Delete Temp Backup Data?"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            firstTrackStart = 2;
            folderCopy = [[FolderCopy alloc] init];
            [folderCopy folderDeleteMain];
            
            firstTrackStart = 0;
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string sourceAnalysisPath2;
            
            dir = opendir(backUpTempPath.c_str());
            fileDeleteCount = 0;
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        sourceAnalysisPath2 = backUpTempPath+"/"+entry;
                        
                        if (fileDeleteCount+5 > fileDeleteLimit){
                            fileUpdate = [[FileUpdate alloc] init];
                            [fileUpdate fileDeleteUpDate];
                        }
                        
                        arrayFileDelete [fileDeleteCount] = sourceAnalysisPath2, fileDeleteCount++;
                    }
                }
                
                closedir (dir);
            }
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                remove (arrayFileDelete [counter1].c_str());
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Perform Before Tracking Starts"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)databaseRepairStart:(id)sender{
    if (trackingOn != 0 && trackingOn != 2 && trackingOn != 3){
        if (repairWindowOperation == 0){
            repairWindowOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDatabaseRepairController object:self];
        }
        
        if (repairWindowOperation == 2) repairWindowOperation = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineWidthSet1:(id)sender{
    if (trackingOn != 0){
        if (lineWidth != 1){
            lineWidth = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineWidthSet2:(id)sender{
    if (trackingOn != 0){
        if (lineWidth != 0.75){
            lineWidth = 0.75;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineWidthSet3:(id)sender{
    if (trackingOn != 0){
        if (lineWidth != 0.5){
            lineWidth = 0.5;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineWidthSet4:(id)sender{
    if (trackingOn != 0){
        if (lineWidth != 0.25){
            lineWidth = 0.25;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineTypeFine:(id)sender{
    if (trackingOn != 0){
        if (lineTypeSet == 0){
            lineTypeSet = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineTypeNormal:(id)sender{
    if (trackingOn != 0){
        if (lineTypeSet == 1){
            lineTypeSet = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentOptionStart:(id)sender{
    if (trackingOn != 0 && trackingOn != 2 && trackingOn != 3){
        if (fluorescentOptionOperation == 0){
            fluorescentOptionOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluoresentQuantOptions object:self];
        }
        
        if (fluorescentOptionOperation == 2) fluorescentOptionOperation = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stepperFluorescentDivSet:(id)sender{
    if (fluorescentDivisionStatus == 0){
        fluorescentDivisionNo = [stepperFluorescentSetCount intValue];
        
        if (fluorescentDivisionNo == 0) [fluorescentQuantDivNoDisplay setStringValue:@"nil"];
        else [fluorescentQuantDivNoDisplay setIntegerValue:fluorescentDivisionNo];
        
        fluorescentDivisionNo = [stepperFluorescentSetCount intValue];
        
        string fluorescentCountStatusPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/"+"FluoQuant";
        
        ofstream oin;
        oin.open(fluorescentCountStatusPath.c_str(), ios::out);
        oin<<fluorescentDivisionNo<<endl;
        oin<<fluorescentDivisionTime<<endl;
        oin<<fluorescentDivisionCh<<endl;
        oin<<fluorescentDivisionStatus<<endl;
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Disable Quant Option"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)autoExpandSet:(id)sender{
    if (trackingOn != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert addButtonWithTitle:@"Cancel"];
        [alert setMessageText:@"Toggle Fluorescent Expansion?"];
        [alert setInformativeText:@" Quantitation status of fluorescent images will be changed"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        if ([alert runModal] == NSAlertFirstButtonReturn){
            if (autoExpand == 1){
                autoExpand = 0;
                [autoExpandDisplay setStringValue:@"Off"];
            }
            else if (autoExpand == 0){
                autoExpand = 1;
                [autoExpandDisplay setStringValue:@"On"];
            }
            
            dataSaveRead = [[DataSaveRead alloc] init];
            [dataSaveRead saveTrackingCurrent];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking/Time One Mode Off or Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentUpDate:(id)sender{
    if (trackingOn == 1 && queueHoldingStatus == 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        if (fluorescentEntryCount != 0 || ifStartHold != 0){
            int processStart = 0;
            int processEnd = 0;
            
            if (fluorescentEntryCount != 0 && ifStartHold != 0){
                processStart = timeOneHold;
                processEnd = imageEndHold;
            }
            else if (fluorescentEntryCount == 0 && ifStartHold != 0){
                processStart = ifStartHold;
                processEnd = imageEndHold;
            }
            else if (fluorescentEntryCount != 0 && ifStartHold == 0){
                processStart = timeOneHold;
                processEnd = imageEndHold;
            }
            
            string extensionString2;
            string extension2;
            string fluorescentPath;
            string fluorescentPath2;
            string fluorescentPath3;
            string fluorescentPath4;
            string fluorescentPath5;
            string fluorescentPath6;
            string fluorescentUpdateName1;
            string fluorescentUpdateName2;
            string fluorescentUpdateName3;
            string fluorescentUpdateName4;
            string fluorescentUpdateName5;
            string fluorescentUpdateName6;
            string fluorescentRoundUpdateNo;
            string expandDataPath;
            
            int fluorescentEntryNumber = 0;
            int fluorescentNoUpdate1 = 0;
            int fluorescentNoUpdate2 = 0;
            int fluorescentNoUpdate3 = 0;
            int fluorescentNoUpdate4 = 0;
            int fluorescentNoUpdate5 = 0;
            int fluorescentNoUpdate6 = 0;
            int fluorescentCutUpdate1 = 0;
            int fluorescentCutUpdate2 = 0;
            int fluorescentCutUpdate3 = 0;
            int fluorescentCutUpdate4 = 0;
            int fluorescentCutUpdate5 = 0;
            int fluorescentCutUpdate6 = 0;
            int fluorescentFileFind = 0;
            int nextLoad = 0;
            int expandFluorescentOutlineTempCount = 0;
            int stepCount = 0;
            int expandFluorescentDataTempCount = 0;
            int imageDimensionReadCount = 0;
            int firstFindFlag = 0;
            int maxPointDimX = 0;
            int maxPointDimY = 0;
            int minPointDimX = 0;
            int minPointDimY = 0;
            int connectExpNo = 0;
            int expandFluorescentOutlineHoldCount = 0;
            int fluorescentRoundNoHoldTemp = 0;
            int horizontalLength = 0;
            int verticalLength = 0;
            int dimension = 0;
            int horizontalStart = 0;
            int verticalStart = 0;
            int connectivityNumber = 0;
            int connectAnalysisCount = 0;
            int terminationFlag = 0;
            int connectAnalysisTempCount = 0;
            int xSource = 0;
            int ySource = 0;
            int pixelValueTemp = 0;
            int pixelAreaTemp = 0;
            int indexCount = 0;
            int dataTemp = 0;
            int finData [8];
            int readBit [4];
            int dataConversion [4];
            int endianType = 0;
            int imageWidthEntry = 0;
            int value0 = 0;
            int value1 = 0;
            int value2 = 0;
            int errorFound = 0;
            int checkFlag = 0;
            
            long sizeForCopy = 0;
            long size1 = 0;
            long size2 = 0;
            
            double averageArea = 0;
            unsigned long readPosition = 0;
            unsigned long headPosition = 0;
            
            struct stat sizeOfFile;
            
            ifstream fin;
            
            string fluorescentReadPath;
            
            for (int counter1 = processStart; counter1 <= processEnd; counter1++){
                extensionString2 = to_string(counter1);
                extension2 = to_string(fluorescentNo1);
                
                if (extensionString2.length() == 1) extensionString2 = "000"+extensionString2;
                else if (extensionString2.length() == 2) extensionString2 = "00"+extensionString2;
                else if (extensionString2.length() == 3) extensionString2 = "0"+extensionString2;
                
                fluorescentFileFind = 0;
                
                if (ifStartHold == 0 || (ifStartHold != 0 && counter1 < ifStartHold)){
                    fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+exType;
                    
                    if (stat(fluorescentPath.c_str(), &sizeOfFile) == 0){
                        fluorescentFileFind = 1;
                    }
                }
                
                if (fluorescentFileFind == 1 || counter1 >= ifStartHold){
                    fluorescentEntryNumber = 0;
                    
                    if (fluorescentFileFind == 1){
                        extension2 = to_string(fluorescentNo1);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName1+exType;
                        
                        extension2 = to_string(fluorescentNo2);
                        fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName2+exType;
                        
                        extension2 = to_string(fluorescentNo3);
                        fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName3+exType;
                        
                        extension2 = to_string(fluorescentNo4);
                        fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName4+exType;
                        
                        extension2 = to_string(fluorescentNo5);
                        fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName5+exType;
                        
                        extension2 = to_string(fluorescentNo6);
                        fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentName6+exType;
                        
                        fluorescentEntryNumber = fluorescentEntryCount;
                    }
                    else if (counter1 >= ifStartHold){
                        nextLoad = 0;
                        
                        for (int counter2 = 0; counter2 < 450; counter2 = counter2+15){
                            if (atoi(arrayIFDataHold [counter2].c_str()) != 0 && atoi(arrayIFDataHold [counter2+14].c_str()) <= counter1){
                                nextLoad = counter2/15+1;
                            }
                            else if (atoi(arrayIFDataHold [counter2].c_str()) == 0){
                                break;
                            }
                        }
                        
                        fluorescentNoUpdate1 = 0;
                        fluorescentNoUpdate2 = 0;
                        fluorescentNoUpdate3 = 0;
                        fluorescentNoUpdate4 = 0;
                        fluorescentNoUpdate5 = 0;
                        fluorescentNoUpdate6 = 0;
                        fluorescentUpdateName1 = "";
                        fluorescentUpdateName2 = "";
                        fluorescentUpdateName3 = "";
                        fluorescentUpdateName4 = "";
                        fluorescentUpdateName5 = "";
                        fluorescentUpdateName6 = "";
                        fluorescentRoundUpdateNo = "";
                        
                        if (nextLoad > 0){
                            nextLoad--;
                            
                            fluorescentEntryNumber = atoi(arrayIFDataHold [nextLoad*15+14].c_str());
                            fluorescentRoundUpdateNo = arrayIFDataHold [nextLoad*15];
                            
                            if (fluorescentEntryNumber >= 1){
                                fluorescentNoUpdate1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                                fluorescentUpdateName1 = arrayIFDataHold [nextLoad*15+1];
                            }
                            if (fluorescentEntryNumber >= 2){
                                fluorescentNoUpdate2 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                                fluorescentUpdateName2 = arrayIFDataHold [nextLoad*15+2];
                            }
                            if (fluorescentEntryNumber >= 3){
                                fluorescentNoUpdate3 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                                fluorescentUpdateName3 = arrayIFDataHold [nextLoad*15+3];
                            }
                            if (fluorescentEntryNumber >= 4){
                                fluorescentNoUpdate4 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                                fluorescentUpdateName4 = arrayIFDataHold [nextLoad*15+4];
                            }
                            if (fluorescentEntryNumber >= 5){
                                fluorescentNoUpdate5 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                                fluorescentUpdateName5 = arrayIFDataHold [nextLoad*15+5];
                            }
                            if (fluorescentEntryNumber >= 6){
                                fluorescentNoUpdate6 = atoi(arrayIFDataHold [nextLoad*15+12].c_str());
                                fluorescentUpdateName6 = arrayIFDataHold [nextLoad*15+6];
                            }
                        }
                        
                        extension2 = to_string(fluorescentNoUpdate1);
                        fluorescentPath = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentUpdateName1+exTypeIF+fluorescentRoundUpdateNo;
                        
                        extension2 = to_string(fluorescentNoUpdate2);
                        fluorescentPath2 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentUpdateName2+exTypeIF+fluorescentRoundUpdateNo;
                        
                        extension2 = to_string(fluorescentNoUpdate3);
                        fluorescentPath3 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentUpdateName3+exTypeIF+fluorescentRoundUpdateNo;
                        
                        extension2 = to_string(fluorescentNoUpdate4);
                        fluorescentPath4 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentUpdateName4+exTypeIF+fluorescentRoundUpdateNo;
                        
                        extension2 = to_string(fluorescentNoUpdate5);
                        fluorescentPath5 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentUpdateName5+exTypeIF+fluorescentRoundUpdateNo;
                        
                        extension2 = to_string(fluorescentNoUpdate6);
                        fluorescentPath6 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extensionString2+"_"+extension2+"_"+fluorescentUpdateName6+exTypeIF+fluorescentRoundUpdateNo;
                    }
                    
                    fluorescentCutUpdate1 = 150;
                    fluorescentCutUpdate2 = 150;
                    fluorescentCutUpdate3 = 150;
                    fluorescentCutUpdate4 = 150;
                    fluorescentCutUpdate5 = 150;
                    fluorescentCutUpdate6 = 150;
                    
                    for (int counter3 = 0; counter3 < fluorescentCutOffCount/7; counter3++){
                        if (arrayFluorescentCutOff [counter3*7] == counter1){
                            fluorescentCutUpdate1 = arrayFluorescentCutOff [counter3*7+1];
                            fluorescentCutUpdate2 = arrayFluorescentCutOff [counter3*7+2];
                            fluorescentCutUpdate3 = arrayFluorescentCutOff [counter3*7+3];
                            fluorescentCutUpdate4 = arrayFluorescentCutOff [counter3*7+4];
                            fluorescentCutUpdate5 = arrayFluorescentCutOff [counter3*7+5];
                            fluorescentCutUpdate6 = arrayFluorescentCutOff [counter3*7+6];
                            break;
                        }
                    }
                    
                    expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                    
                    size1 = 0;
                    size2 = 0;
                    checkFlag = 0;
                    errorFound = 0;
                    
                    for (int counter2 = 0; counter2 < 6; counter2++){
                        sizeForCopy = 0;
                        
                        if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                            sizeForCopy = sizeOfFile.st_size;
                        }
                        
                        if (sizeForCopy != 0){
                            if (counter2 == 0) size1 = sizeForCopy;
                            else if (counter2 == 1) size2 = sizeForCopy;
                            else if (counter2 == 2){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                    break;
                                }
                                else{
                                    
                                    size1 = 0;
                                    size2 = 0;
                                    usleep (50000);
                                }
                            }
                            else if (counter2 == 3) size1 = sizeForCopy;
                            else if (counter2 == 4) size2 = sizeForCopy;
                            else if (counter2 == 5){
                                if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                    checkFlag = 1;
                                }
                            }
                        }
                    }
                    
                    if (checkFlag == 1){
                        int *expandFluorescentOutlineTemp = new int [sizeForCopy+50];
                        expandFluorescentOutlineTempCount = 0;
                        
                        fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                        
                        if (fin.is_open()){
                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                            fin.read((char*)uploadTemp, sizeForCopy+50);
                            
                            if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                usleep(50000);
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        errorFound = 1;
                                    }
                                }
                            }
                            
                            fin.close();
                            
                            if (errorFound == 0){
                                readPosition = 0;
                                stepCount = 0;
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                        finData [2] = uploadTemp [readPosition], readPosition++;
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                        
                                        finData [1] = finData [0]*256+finData [1];
                                        finData [3] = finData [2]*256+finData [3];
                                        finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                        
                                        if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                        else{
                                            
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [1], expandFluorescentOutlineTempCount++;
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [3], expandFluorescentOutlineTempCount++;
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [6], expandFluorescentOutlineTempCount++;
                                            expandFluorescentOutlineTemp [expandFluorescentOutlineTempCount] = finData [7], expandFluorescentOutlineTempCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                            }
                            
                            delete [] uploadTemp;
                        }
                        
                        if (errorFound == 0){
                            expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extensionString2+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                            
                            if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                int *expandFluorescentDataTemp = new int [sizeForCopy+50];
                                expandFluorescentDataTempCount = 0;
                                
                                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                            
                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = finData [2], expandFluorescentDataTempCount++;
                                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = finData [3], expandFluorescentDataTempCount++;
                                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = finData [4], expandFluorescentDataTempCount++;
                                                expandFluorescentDataTemp [expandFluorescentDataTempCount] = finData [7], expandFluorescentDataTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                                
                                //for (int counterA = 0; counterA < expandFluorescentOutlineTempCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentOutlineTemp [counterA*4+counterB];
                                //    cout<<" expandFluorescentOutlineTemp "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < expandFluorescentDataTempCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandFluorescentDataTemp [counterA*4+counterB];
                                //    cout<<" expandFluorescentDataTemp "<<counterA<<endl;
                                //}
                                
                                for (int counter2 = 1; counter2 <= fluorescentEntryNumber; counter2++){
                                    if (counter2 == 1) fluorescentReadPath = fluorescentPath;
                                    else if (counter2 == 2) fluorescentReadPath = fluorescentPath2;
                                    else if (counter2 == 3) fluorescentReadPath = fluorescentPath3;
                                    else if (counter2 == 4) fluorescentReadPath = fluorescentPath4;
                                    else if (counter2 == 5) fluorescentReadPath = fluorescentPath5;
                                    else if (counter2 == 6) fluorescentReadPath = fluorescentPath6;
                                    
                                    if (stat(fluorescentReadPath.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        int **fluorescentMapTemp = new int *[imageDimension+1];
                                        for (int counter3 = 0; counter3 < imageDimension+1; counter3++) fluorescentMapTemp [counter3] = new int [imageDimension+1];
                                        
                                        if (exType == ".tif" || exTypeIF == ".TIF"){
                                            uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                                            fin.open(fluorescentReadPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.read((char*)uploadTemp2, sizeForCopy+50);
                                                fin.close();
                                                
                                                dataConversion [0] = uploadTemp2 [0];
                                                dataConversion [1] = uploadTemp2 [1];
                                                
                                                if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                                else endianType = 0;
                                                
                                                headPosition = 0;
                                                
                                                if (endianType == 1){
                                                    dataConversion [0] = uploadTemp2 [7];
                                                    dataConversion [1] = uploadTemp2 [6];
                                                    dataConversion [2] = uploadTemp2 [5];
                                                    dataConversion [3] = uploadTemp2 [4];
                                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                }
                                                else if (endianType == 0){
                                                    dataConversion [0] = uploadTemp2 [4];
                                                    dataConversion [1] = uploadTemp2 [5];
                                                    dataConversion [2] = uploadTemp2 [6];
                                                    dataConversion [3] = uploadTemp2 [7];
                                                    headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                                }
                                                
                                                imageDimensionReadCount = 0;
                                                imageWidthEntry = 0;
                                                
                                                if (tifImageColorGray == 0){
                                                    for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                        fluorescentMapTemp [imageDimensionReadCount][imageWidthEntry] = uploadTemp2 [counter3], imageWidthEntry++;
                                                        
                                                        if (imageWidthEntry == imageDimension){
                                                            imageWidthEntry = 0;
                                                            imageDimensionReadCount++;
                                                        }
                                                    }
                                                }
                                                else if (tifImageColorGray == 1){
                                                    for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                        value0 = uploadTemp2 [counter3];
                                                        value1 = uploadTemp2 [counter3+1];
                                                        value2 = uploadTemp2 [counter3+2];
                                                        
                                                        fluorescentMapTemp [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                        
                                                        if (imageWidthEntry == imageDimension){
                                                            imageWidthEntry = 0;
                                                            imageDimensionReadCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            delete [] uploadTemp2;
                                        }
                                        else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                            uint8_t *uploadTemp2 = new uint8_t [sizeForCopy+50];
                                            fin.open(fluorescentReadPath.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                fin.read((char*)uploadTemp2, sizeForCopy+50);
                                                fin.close();
                                                
                                                imageDimensionReadCount = 0;
                                                
                                                for (int counter3 = imageDimension-1; counter3 >= 0; counter3--){
                                                    for (int counter4 = 0; counter4 < imageDimension; counter4++){
                                                        fluorescentMapTemp [imageDimensionReadCount][counter4] = uploadTemp2 [1078+counter3*imageDimension+counter4];
                                                    }
                                                    
                                                    imageDimensionReadCount++;
                                                }
                                            }
                                            
                                            delete [] uploadTemp2;
                                        }
                                        
                                        firstFindFlag = 0;
                                        
                                        maxPointDimX = 0;
                                        maxPointDimY = 0;
                                        minPointDimX = 1000000;
                                        minPointDimY = 1000000;
                                        
                                        connectExpNo = 0;
                                        int *expandFluorescentOutlineHold = new int [expandFluorescentOutlineTempCount+100];
                                        expandFluorescentOutlineHoldCount = 0;
                                        
                                        if (counter1 >= ifStartHold) fluorescentRoundNoHoldTemp = counter2+6;
                                        else fluorescentRoundNoHoldTemp = counter2;
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentOutlineTempCount/4; counter3++){
                                            if (fluorescentRoundNoHoldTemp == expandFluorescentOutlineTemp [counter3*4+3] && connectExpNo != expandFluorescentOutlineTemp [counter3*4+2] && firstFindFlag == 0){
                                                connectExpNo = expandFluorescentOutlineTemp [counter3*4+2];
                                                firstFindFlag = 1;
                                                
                                                if (maxPointDimX < expandFluorescentOutlineTemp [counter3*4]) maxPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                if (minPointDimX > expandFluorescentOutlineTemp [counter3*4]) minPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                if (maxPointDimY < expandFluorescentOutlineTemp [counter3*4+1]) maxPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                if (minPointDimY > expandFluorescentOutlineTemp [counter3*4+1]) minPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                
                                                expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4], expandFluorescentOutlineHoldCount++;
                                                expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4+1], expandFluorescentOutlineHoldCount++;
                                                
                                            }
                                            else if (fluorescentRoundNoHoldTemp == expandFluorescentOutlineTemp [counter3*4+3] && connectExpNo == expandFluorescentOutlineTemp [counter3*4+2] && counter3 != expandFluorescentOutlineTempCount/4-1 && firstFindFlag == 1){
                                                if (maxPointDimX < expandFluorescentOutlineTemp [counter3*4]) maxPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                if (minPointDimX > expandFluorescentOutlineTemp [counter3*4]) minPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                if (maxPointDimY < expandFluorescentOutlineTemp [counter3*4+1]) maxPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                if (minPointDimY > expandFluorescentOutlineTemp [counter3*4+1]) minPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                
                                                expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4], expandFluorescentOutlineHoldCount++;
                                                expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4+1], expandFluorescentOutlineHoldCount++;
                                            }
                                            else if (fluorescentRoundNoHoldTemp == expandFluorescentOutlineTemp [counter3*4+3] && (connectExpNo != expandFluorescentOutlineTemp [counter3*4+2] || counter3 == expandFluorescentOutlineTempCount/4-1) && firstFindFlag == 1){
                                                if (counter3 == expandFluorescentOutlineTempCount/4-1){
                                                    if (maxPointDimX < expandFluorescentOutlineTemp [counter3*4]) maxPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                    if (minPointDimX > expandFluorescentOutlineTemp [counter3*4]) minPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                    if (maxPointDimY < expandFluorescentOutlineTemp [counter3*4+1]) maxPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                    if (minPointDimY > expandFluorescentOutlineTemp [counter3*4+1]) minPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                    
                                                    expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4], expandFluorescentOutlineHoldCount++;
                                                    expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4+1], expandFluorescentOutlineHoldCount++;
                                                }
                                                
                                                horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                                verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                                dimension = 0;
                                                
                                                if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                                if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                                
                                                dimension = (dimension/2)*2;
                                                
                                                horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                                verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                                
                                                int **connectivityMapTemp = new int *[dimension+1];
                                                
                                                for (int counter4 = 0; counter4 < dimension+1; counter4++) connectivityMapTemp [counter4] = new int [dimension+1];
                                                
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++) connectivityMapTemp [counterY][counterX] = 0;
                                                }
                                                
                                                for (int counter4 = 0; counter4 < expandFluorescentOutlineHoldCount/2; counter4++){
                                                    connectivityMapTemp [expandFluorescentOutlineHold [counter4*2+1]-verticalStart][expandFluorescentOutlineHold [counter4*2]-horizontalStart] = 1;
                                                }
                                                
                                                //-----Connectivity analysis, For Zero-----
                                                int *connectAnalysisX = new int [dimension*4];
                                                int *connectAnalysisY = new int [dimension*4];
                                                int *connectAnalysisTempX = new int [dimension*4];
                                                int *connectAnalysisTempY = new int [dimension*4];
                                                
                                                connectivityNumber = -3;
                                                
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++){
                                                        if (connectivityMapTemp [counterY][counterX] == 0){
                                                            connectivityNumber = connectivityNumber+2;
                                                            connectivityMapTemp [counterY][counterX] = connectivityNumber;
                                                            
                                                            connectAnalysisCount = 0;
                                                            
                                                            if (counterY-1 >= 0 && connectivityMapTemp [counterY-1][counterX] == 0){
                                                                connectivityMapTemp [counterY-1][counterX] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                            }
                                                            if (counterX+1 < dimension && connectivityMapTemp [counterY][counterX+1] == 0){
                                                                connectivityMapTemp [counterY][counterX+1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                            }
                                                            if (counterY+1 < dimension && connectivityMapTemp [counterY+1][counterX] == 0){
                                                                connectivityMapTemp [counterY+1][counterX] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                            }
                                                            if (counterX-1 >= 0 && connectivityMapTemp [counterY][counterX-1] == 0){
                                                                connectivityMapTemp [counterY][counterX-1] = connectivityNumber;
                                                                connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                            }
                                                            
                                                            if (connectAnalysisCount != 0){
                                                                do{
                                                                    
                                                                    terminationFlag = 1;
                                                                    connectAnalysisTempCount = 0;
                                                                    
                                                                    for (int counter4 = 0; counter4 < connectAnalysisCount; counter4++){
                                                                        xSource = connectAnalysisX [counter4], ySource = connectAnalysisY [counter4];
                                                                        
                                                                        if (ySource-1 >= 0 && connectivityMapTemp [ySource-1][xSource] == 0){
                                                                            connectivityMapTemp [ySource-1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource+1 < dimension && connectivityMapTemp [ySource][xSource+1] == 0){
                                                                            connectivityMapTemp [ySource][xSource+1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                        if (ySource+1 < dimension && connectivityMapTemp [ySource+1][xSource] == 0){
                                                                            connectivityMapTemp [ySource+1][xSource] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                        }
                                                                        if (xSource-1 >= 0 && connectivityMapTemp [ySource][xSource-1] == 0){
                                                                            connectivityMapTemp [ySource][xSource-1] = connectivityNumber;
                                                                            connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                        }
                                                                    }
                                                                    
                                                                    for (int counter4 = 0; counter4 < connectAnalysisTempCount; counter4++){
                                                                        connectAnalysisX [counter4] = connectAnalysisTempX [counter4], connectAnalysisY [counter4] = connectAnalysisTempY [counter4];
                                                                    }
                                                                    
                                                                    connectAnalysisCount = connectAnalysisTempCount;
                                                                    
                                                                    if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                    
                                                                } while (terminationFlag == 1);
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                delete [] connectAnalysisX;
                                                delete [] connectAnalysisY;
                                                delete [] connectAnalysisTempX;
                                                delete [] connectAnalysisTempY;
                                                
                                                //-----Remove connect groups, which attach edge, extract inner part of Linked Line-----
                                                for (int counterY = 0; counterY < dimension; counterY++){
                                                    for (int counterX = 0; counterX < dimension; counterX++){
                                                        if (connectivityMapTemp [counterY][counterX] == -1) connectivityMapTemp [counterY][counterX] = 0;
                                                    }
                                                }
                                                
                                                //for (int counterA = 0; counterA < dimension; counterA++){
                                                //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapTemp [counterA][counterB];
                                                //    cout<<" connectivityMapTemp "<<counterA<<endl;
                                                //}
                                                
                                                pixelValueTemp = 0;
                                                pixelAreaTemp = 0;
                                                
                                                if (counter1 >= ifStartHold){
                                                    for (int counterY = 0; counterY < dimension; counterY++){
                                                        for (int counterX = 0; counterX < dimension; counterX++){
                                                            if (connectivityMapTemp [counterY][counterX] != 0){
                                                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                                                    if (fluorescentRoundNoHoldTemp == 7){
                                                                        if (fluorescentCutUpdate1 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 8){
                                                                        if (fluorescentCutUpdate2 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 9){
                                                                        if (fluorescentCutUpdate3 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 10){
                                                                        if (fluorescentCutUpdate4 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 11){
                                                                        if (fluorescentCutUpdate5 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 12){
                                                                        if (fluorescentCutUpdate6 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                else{
                                                    
                                                    for (int counterY = 0; counterY < dimension; counterY++){
                                                        for (int counterX = 0; counterX < dimension; counterX++){
                                                            if (connectivityMapTemp [counterY][counterX] != 0){
                                                                if (counterY+verticalStart >= 0 && counterY+verticalStart < imageDimension && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageDimension){
                                                                    if (fluorescentRoundNoHoldTemp == 1){
                                                                        if (fluorescentCutUpdate1 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 2){
                                                                        if (fluorescentCutUpdate2 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 3){
                                                                        if (fluorescentCutUpdate3 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 4){
                                                                        if (fluorescentCutUpdate4 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 5){
                                                                        if (fluorescentCutUpdate5 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                    if (fluorescentRoundNoHoldTemp == 6){
                                                                        if (fluorescentCutUpdate6 >= fluorescentMapTemp [counterX+horizontalStart][counterX+horizontalStart]) pixelValueTemp = pixelValueTemp+fluorescentMapTemp [counterY+verticalStart][counterX+horizontalStart];
                                                                        pixelAreaTemp++;
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                                
                                                for (int counter4 = 0; counter4 < expandFluorescentDataTempCount/4; counter4++){
                                                    if (expandFluorescentDataTemp [counter4*4] == connectExpNo && expandFluorescentDataTemp [counter4*4+1] == fluorescentRoundNoHoldTemp){
                                                        expandFluorescentDataTemp [counter4*4+2] = (int)averageArea;
                                                        expandFluorescentDataTemp [counter4*4+3] = pixelAreaTemp;
                                                        break;
                                                    }
                                                }
                                                
                                                connectExpNo = expandFluorescentOutlineTemp [counter3*4+2];
                                                expandFluorescentOutlineHoldCount = 0;
                                                
                                                maxPointDimX = 0;
                                                maxPointDimY = 0;
                                                minPointDimX = 1000000;
                                                minPointDimY = 1000000;
                                                
                                                if (counter3 != expandFluorescentOutlineTempCount/4-1){
                                                    if (maxPointDimX < expandFluorescentOutlineTemp [counter3*4]) maxPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                    if (minPointDimX > expandFluorescentOutlineTemp [counter3*4]) minPointDimX = expandFluorescentOutlineTemp [counter3*4];
                                                    if (maxPointDimY < expandFluorescentOutlineTemp [counter3*4+1]) maxPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                    if (minPointDimY > expandFluorescentOutlineTemp [counter3*4+1]) minPointDimY = expandFluorescentOutlineTemp [counter3*4+1];
                                                    
                                                    expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4], expandFluorescentOutlineHoldCount++;
                                                    expandFluorescentOutlineHold [expandFluorescentOutlineHoldCount] = expandFluorescentOutlineTemp [counter3*4+1], expandFluorescentOutlineHoldCount++;
                                                }
                                                
                                                for (int counter4 = 0; counter4 < dimension+1; counter4++) delete [] connectivityMapTemp [counter4];
                                                delete [] connectivityMapTemp;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < imageDimension+1; counter3++) delete [] fluorescentMapTemp [counter3];
                                        delete [] fluorescentMapTemp;
                                        
                                        delete [] expandFluorescentOutlineHold;
                                    }
                                }
                                
                                indexCount = 0;
                                char *writingArray = new char [expandFluorescentDataTempCount*2+20];
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataTempCount/4; counter2++){
                                    dataTemp = expandFluorescentDataTemp [counter2*4];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)expandFluorescentDataTemp [counter2*4+1], indexCount++;
                                    writingArray [indexCount] = (char)expandFluorescentDataTemp [counter2*4+2], indexCount++;
                                    
                                    dataTemp = expandFluorescentDataTemp [counter2*4+3];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter2 = 0; counter2 < 8; counter2++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile5 (expandDataPath.c_str(), ofstream::binary);
                                outfile5.write ((char*)writingArray, indexCount);
                                outfile5.close();
                                
                                delete [] writingArray;
                                delete [] expandFluorescentDataTemp;
                            }
                        }
                        
                        delete [] expandFluorescentOutlineTemp;
                        
                        if (errorFound == 1){
                            break;
                        }
                    }
                }
            }
            
            if (errorFound == 0){
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Fluorescent Line Data Read Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Fluorescent Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (trackingOn != 1){
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Tracking On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Auto Processing/Other Processes On"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
}

-(IBAction)fluorescentOptionSet:(id)sender{
    if (fluorescentDivisionStatus == 0){
        if (fluorescentDivisionNo != 0){
            if (fluorescentDivisionTime >= timeOneHold && fluorescentDivisionTime <= imageEndHold){
                if ((fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh <= 6) || (fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh >= 7)){
                    if (fluorescentOpInformationStatus == 0){
                        fluorescentOpInformationHold = new int [(imageEndHold-ifStartHold+1)*4*3*4+(imageEndHold-ifStartHold+1)*4+50];
                        
                        for (int counter1 = 0; counter1 < (imageEndHold-ifStartHold+1)*4*3*4+(imageEndHold-ifStartHold+1)*4+50; counter1++){
                            fluorescentOpInformationHold [counter1] = 0;
                        }
                        
                        fluorescentOpInformationStatus = 1;
                        fluorescentOpInformationCount = 0;
                    }
                    
                    if (fluorescentLevelDataStatus == 0){
                        fluorescentLevelDataHold = new int [10000];
                        fluorescentLevelDataCount = 0;
                        fluorescentLevelDataLimit = 10000;
                        fluorescentLevelDataStatus = 1;
                    }
                    
                    string connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect";
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    ifstream fin;
                    fileDeleteCount = 0;
                    
                    fin.open(connectDataPath.c_str(), ios::in);
                    
                    if (fin.is_open()){
                        fin.close();
                        
                        fin.open(connectDataPath.c_str(), ios::in);
                        
                        if (fin.is_open()){
                            fin.close();
                            
                            dir = opendir(connectDataPath.c_str());
                            
                            if (dir != NULL){
                                string entry;
                                
                                while((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (fileDeleteCount+5 > fileDeleteLimit){
                                            fileUpdate = [[FileUpdate alloc] init];
                                            [fileUpdate fileDeleteUpDate];
                                        }
                                        
                                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                    }
                                }
                                
                                closedir(dir);
                                
                                //-----Directory Sort-----
                                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                                }
                                
                                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                                
                                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                                    arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                                }
                            }
                        }
                    }
                    
                    if (fileDeleteCount != 0){
                        string stringExtract;
                        fluorescentOpInformationCount = 0;
                        
                        for (int counter2 = 0; counter2 < fileDeleteCount; counter2++){
                            if ((int)arrayFileDelete [counter2].find("IFLevelData") != -1){
                                fluorescentOpInformationHold [fluorescentOpInformationCount] = atoi(arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("IFLevelData")+12, 4).c_str()), fluorescentOpInformationCount++;
                                stringExtract = arrayFileDelete [counter2].substr(arrayFileDelete [counter2].find("IFLevelData")+12);
                                fluorescentOpInformationHold [fluorescentOpInformationCount] = atoi(stringExtract.substr(5, 1).c_str()), fluorescentOpInformationCount++;
                                stringExtract = stringExtract.substr(5);
                                fluorescentOpInformationHold [fluorescentOpInformationCount] = atoi(stringExtract.substr(2, 1).c_str()), fluorescentOpInformationCount++;
                                fluorescentOpInformationHold [fluorescentOpInformationCount] = atoi(stringExtract.substr(4, 1).c_str()), fluorescentOpInformationCount++;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < fluorescentOpInformationCount/4; counterA++){
                        //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<fluorescentOpInformationHold [counterA*4+counterB];
                        //    cout<<" fluorescentOpInformationHold "<<counterA<<endl;
                        //}
                        
                        int matchFluorescentFind = 0;
                        int mergeStatus = 0;
                        
                        for (int counter2 = 0; counter2 < fluorescentOpInformationCount/4; counter2++){
                            if (fluorescentOpInformationHold [counter2*4] == fluorescentDivisionTime && fluorescentOpInformationHold [counter2*4+1] == fluorescentDivisionCh && fluorescentOpInformationHold [counter2*4+2] == fluorescentDivisionNo){
                                matchFluorescentFind = 1;
                                mergeStatus = fluorescentOpInformationHold [counter2*4+3];
                            }
                        }
                        
                        if (matchFluorescentFind == 1){
                            string extension = to_string(fluorescentDivisionTime);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            fluorescentSavePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(fluorescentDivisionCh)+"_"+to_string(fluorescentDivisionNo)+"="+to_string(mergeStatus);
                            
                            long sizeForCopy = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(fluorescentSavePath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            delete [] fluorescentLevelDataHold;
                            fluorescentLevelDataHold = new int [sizeForCopy+50];
                            fluorescentLevelDataCount = 0;
                            fluorescentLevelDataLimit = sizeForCopy+50;
                            
                            fin.open(fluorescentSavePath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                int finData [8];
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                        else{
                                            
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [2], fluorescentLevelDataCount++;
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [3], fluorescentLevelDataCount++;
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [4], fluorescentLevelDataCount++;
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [7], fluorescentLevelDataCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                            }
                            
                            //for (int counterA = 0; counterA < fluorescentLevelDataCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<fluorescentLevelDataHold [counterA*4+counterB];
                            //    cout<<" fluorescentLevelDataHold "<<counterA<<endl;
                            //}
                            
                            if (fluorescentOptionOperation == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentQuantitationTable object:self];
                            
                            if ((fluorescentDivisionTime == imageNumberTrackForDisplay && fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime == imageNumberTrackForDisplay && fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)){
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Navigate to Image/Channel"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                            }
                            
                            fluorescentDivisionStatus = 1;
                            fluorescentLevelValueHold = 10;
                            
                            [fluorescentQuantStatusDisplay setStringValue:@"On"];
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            string extension = to_string(fluorescentDivisionTime);
                            
                            if (extension.length() == 1) extension = "000"+extension;
                            else if (extension.length() == 2) extension = "00"+extension;
                            else if (extension.length() == 3) extension = "0"+extension;
                            
                            connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                            
                            long sizeForCopy = 0;
                            
                            struct stat sizeOfFile;
                            
                            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            delete [] fluorescentLevelDataHold;
                            fluorescentLevelDataHold = new int [sizeForCopy+50];
                            fluorescentLevelDataCount = 0;
                            fluorescentLevelDataLimit = sizeForCopy+50;
                            
                            fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                fin.close();
                                
                                unsigned long readPosition = 0;
                                int stepCount = 0;
                                int finData [8];
                                
                                do{
                                    
                                    if (stepCount == 0){
                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                        
                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                        
                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                        else{
                                            
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [2], fluorescentLevelDataCount++;
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [3], fluorescentLevelDataCount++;
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [4], fluorescentLevelDataCount++;
                                            fluorescentLevelDataHold [fluorescentLevelDataCount] = finData [7], fluorescentLevelDataCount++;
                                        }
                                    }
                                    
                                } while (stepCount != 3);
                                
                                delete [] uploadTemp;
                                
                                for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++) fluorescentLevelDataHold [counter1*4+2] = 10;
                                
                                //for (int counterA = 0; counterA < fluorescentLevelDataCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<fluorescentLevelDataHold [counterA*4+counterB];
                                //    cout<<" fluorescentLevelDataHold "<<counterA<<endl;
                                //}
                                
                                fluorescentSavePath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_IFLevelData~"+extension+"="+to_string(fluorescentDivisionCh)+"_"+to_string(fluorescentDivisionNo)+"=0";
                                
                                if (fluorescentLevelDataCount != 0){
                                    int readBit [3];
                                    int dataTemp = 0;
                                    unsigned long indexCount = 0;
                                    
                                    char *writingArray = new char [fluorescentLevelDataCount*2+20];
                                    
                                    for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                                        dataTemp = fluorescentLevelDataHold [counter1*4];
                                        
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                                        writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                                        
                                        dataTemp = fluorescentLevelDataHold [counter1*4+3];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
                                    outfile2.write ((char*)writingArray, indexCount);
                                    outfile2.close();
                                    
                                    delete [] writingArray;
                                    
                                    fluorescentOpInformationHold [fluorescentOpInformationCount] = fluorescentDivisionTime, fluorescentOpInformationCount++;
                                    fluorescentOpInformationHold [fluorescentOpInformationCount] = fluorescentDivisionCh, fluorescentOpInformationCount++;
                                    fluorescentOpInformationHold [fluorescentOpInformationCount] = fluorescentDivisionNo, fluorescentOpInformationCount++;
                                    fluorescentOpInformationHold [fluorescentOpInformationCount] = 0, fluorescentOpInformationCount++;
                                }
                                
                                if (fluorescentOptionOperation == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToFluorescentQuantitationTable object:self];
                                
                                if ((fluorescentDivisionTime == imageNumberTrackForDisplay && fluorescentDivisionTime <= timeEndHold && fluorescentDivisionCh == fluorescentDisplayNo) || (fluorescentDivisionTime == imageNumberTrackForDisplay && fluorescentDivisionTime > timeEndHold && fluorescentDivisionCh-6 == fluorescentDisplayNo)){
                                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Navigate to Image/Channel"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                }
                                
                                fluorescentDivisionStatus = 1;
                                fluorescentSaveCount = 0;
                                fluorescentLevelValueHold = 10;
                                
                                [fluorescentQuantStatusDisplay setStringValue:@"On"];
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"No Corresponding Fluorescent Data"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Tracking Data Missing"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Live: Ch 1, 2, 3, 4, 5, 6, IF: Ch 7, 8, 9, 10, 11, 12"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Time: Range Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set Number of Levels"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        //for (int counterA = 0; counterA < 90/9; counterA++){
        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
        //    cout<<" arrayIFDataHold "<<counterA<<endl;
        //}
    }
    else if (fluorescentDivisionStatus == 1){
        fluorescentDivisionStatus = 0;
        
        if (fluorescentSaveCount != 0 && fluorescentSaveCount != 0){
            fluorescentSaveCount = 0;
            
            int readBit [3];
            int dataTemp = 0;
            unsigned long indexCount = 0;
            
            char *writingArray = new char [fluorescentLevelDataCount*2+20];
            
            for (int counter1 = 0; counter1 < fluorescentLevelDataCount/4; counter1++){
                dataTemp = fluorescentLevelDataHold [counter1*4];
                
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
                
                writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+1], indexCount++;
                writingArray [indexCount] = (char)fluorescentLevelDataHold [counter1*4+2], indexCount++;
                
                dataTemp = fluorescentLevelDataHold [counter1*4+3];
                readBit [0] = dataTemp/65536;
                dataTemp = dataTemp%65536;
                readBit [1] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [2] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                writingArray [indexCount] = (char)readBit [2], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile2 (fluorescentSavePath.c_str(), ofstream::binary);
            outfile2.write ((char*)writingArray, indexCount);
            outfile2.close();
            
            delete [] writingArray;
        }
        
        fluorescentLevelValueHold = 10;
        
        [fluorescentQuantStatusDisplay setStringValue:@"Off"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)fluorescentSave:(id)sender{
    if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        int matchFind = 0;
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
            if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                matchFind = 1;
                break;
            }
        }
        
        if (matchFind == 1){
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                    arrayFluorescentCutOff [counter1*7+1] = fluorescentCutOff1;
                    arrayFluorescentCutOff [counter1*7+2] = fluorescentCutOff2;
                    arrayFluorescentCutOff [counter1*7+3] = fluorescentCutOff3;
                    arrayFluorescentCutOff [counter1*7+4] = fluorescentCutOff4;
                    arrayFluorescentCutOff [counter1*7+5] = fluorescentCutOff5;
                    arrayFluorescentCutOff [counter1*7+6] = fluorescentCutOff6;
                    break;
                }
            }
        }
        else{
            
            if (fluorescentCutOffStatus == 0){
                arrayFluorescentCutOff = new int [imageEndHold*7];
                fluorescentCutOffCount = 0;
                fluorescentCutOffStatus = 1;
            }
            
            arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
            arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
        }
        
        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
        
        ofstream oin;
        oin.open(cutOffPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
        
        oin<<"End"<<endl;
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Fluorescent Mode/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentApplyAll:(id)sender{
    if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0 && mainSavingInProgress == 0 && cleaningProgress == 0){
        int matchFind = 0;
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
            if (arrayFluorescentCutOff [counter1*7] == imageNumberTrackForDisplay){
                matchFind = 1;
                break;
            }
        }
        
        if (matchFind == 1){
            for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
                if (arrayFluorescentCutOff [counter1*7] >= imageNumberTrackForDisplay){
                    if (fluorescentDisplayNo == 1) arrayFluorescentCutOff [counter1*7+1] = fluorescentCutOff1;
                    if (fluorescentDisplayNo == 2) arrayFluorescentCutOff [counter1*7+2] = fluorescentCutOff2;
                    if (fluorescentDisplayNo == 3) arrayFluorescentCutOff [counter1*7+3] = fluorescentCutOff3;
                    if (fluorescentDisplayNo == 4) arrayFluorescentCutOff [counter1*7+4] = fluorescentCutOff4;
                    if (fluorescentDisplayNo == 5) arrayFluorescentCutOff [counter1*7+5] = fluorescentCutOff5;
                    if (fluorescentDisplayNo == 6) arrayFluorescentCutOff [counter1*7+6] = fluorescentCutOff6;
                }
            }
        }
        else{
            
            if (fluorescentCutOffStatus == 0){
                arrayFluorescentCutOff = new int [imageEndHold*7];
                fluorescentCutOffCount = 0;
                fluorescentCutOffStatus = 1;
            }
            
            arrayFluorescentCutOff [fluorescentCutOffCount] = imageNumberTrackForDisplay, fluorescentCutOffCount++;
            if (fluorescentDisplayNo == 1) arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff1, fluorescentCutOffCount++;
            if (fluorescentDisplayNo == 2) arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff2, fluorescentCutOffCount++;
            if (fluorescentDisplayNo == 3) arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff3, fluorescentCutOffCount++;
            if (fluorescentDisplayNo == 4) arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff4, fluorescentCutOffCount++;
            if (fluorescentDisplayNo == 5) arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff5, fluorescentCutOffCount++;
            if (fluorescentDisplayNo == 6) arrayFluorescentCutOff [fluorescentCutOffCount] = fluorescentCutOff6, fluorescentCutOffCount++;
        }
        
        string cutOffPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+ analysisID+"_"+treatmentNameHold+"_CutOffData";
        
        ofstream oin;
        oin.open(cutOffPath.c_str(), ios::out);
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCount; counter1++) oin<<arrayFluorescentCutOff [counter1]<<endl;
        
        oin<<"End"<<endl;
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Fluorescent Mode/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)fluorescentReQuantitation:(id)sender{
    int quantConst = 0;
    [self fileReQuantConstruct:quantConst];
}

-(IBAction)fluorescentReConstruct:(id)sender{
    int quantConst = 1;
    [self fileReQuantConstruct:quantConst];
}

-(void)fileReQuantConstruct:(int)quantConst{
    if (fluorescentDetectionDisplay == 1 && fluorescentDisplayNo != 0 && mainSavingInProgress == 0 && cleaningProgress == 0 && imageEndHold != 0){
        int *timeLineDataHold = new int [imageEndHold+10];
        
        for (int counter1 = 0; counter1 < imageEndHold+10; counter1++){
            timeLineDataHold [counter1] = 0;
        }
        
        for (int counter1 = 0; counter1 < fluorescentCutOffCount/7; counter1++){
            timeLineDataHold [arrayFluorescentCutOff [counter1*7]] = 1;
        }
        
        int entryNo = 0;
        
        for (int counter1 = 0; counter1 < imageEndHold+10; counter1++){
            if (timeLineDataHold [counter1] != 0){
                entryNo = 1;
            }
        }
        
        if (entryNo == 1){
            if (ifEntry == 0){
                int fluorescentCutReQuant = 0;
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 0;
                int minPointDimY = 0;
                int expandFluorescentOutlineReQuantCount = 0;
                int expandFluorescentDataReQuantCount = 0;
                int expandFluorescentOutlineReQuantTempCount = 0;
                int expandFluorescentDataReQuantTempCount = 0;
                int masterReQuantCount = 0;
                int maxConnectNo = 0;
                int horizontalLength = 0;
                int verticalLength = 0;
                int dimension = 0;
                int horizontalStart = 0;
                int verticalStart = 0;
                int connectAnalysisCount = 0;
                int terminationFlag = 0;
                int connectAnalysisTempCount = 0;
                int xSource = 0;
                int ySource = 0;
                int connectivityNumber = 0;
                int imageDimensionReadCount = 0;
                int pixelValueTemp = 0;
                int pixelAreaTemp = 0;
                int dataTemp = 0;
                int stepCount = 0;
                int expandFluorescentDataReQuantLimit = 0;
                int finData [17];
                int dataConversion [4];
                int endianType = 0;
                int imageWidthEntry = 0;
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int checkFlag = 0;
                int checkFlag2 = 0;
                int readingError = 0;
                
                long sizeForCopy = 0;
                long sizeForCopy2 = 0;
                long size1 = 0;
                long size2 = 0;
                
                unsigned long readPosition = 0;
                unsigned long headPosition = 0;
                
                double averageArea = 0;
                
                struct stat sizeOfFile;
                
                string expandFluorescentPath;
                string expandDataPath;
                string extension;
                string extension2;
                string fluorescentProcessPath1;
                string connectDataPath;
                
                ifstream fin;
                
                for (int counter1 = 1; counter1 <= timeEndHold; counter1++){
                    if (timeLineDataHold [counter1] != 0){
                        fluorescentCutReQuant = 0;
                        
                        for (int counter2 = 0; counter2 < fluorescentCutOffCount/7; counter2++){
                            if (arrayFluorescentCutOff [counter2*7] == counter1){
                                if (fluorescentDisplayNo == 1) fluorescentCutReQuant = fluorescentCutOff1;
                                if (fluorescentDisplayNo == 2) fluorescentCutReQuant = fluorescentCutOff2;
                                if (fluorescentDisplayNo == 3) fluorescentCutReQuant = fluorescentCutOff3;
                                if (fluorescentDisplayNo == 4) fluorescentCutReQuant = fluorescentCutOff4;
                                if (fluorescentDisplayNo == 5) fluorescentCutReQuant = fluorescentCutOff5;
                                if (fluorescentDisplayNo == 6) fluorescentCutReQuant = fluorescentCutOff6;
                                break;
                            }
                        }
                        
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) extension = "000"+extension;
                        else if (extension.length() == 2) extension = "00"+extension;
                        else if (extension.length() == 3) extension = "0"+extension;
                        
                        expandFluorescentPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        
                        for (int counter2 = 0; counter2 < 6; counter2++){
                            sizeForCopy = 0;
                            
                            if (stat(expandFluorescentPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter2 == 0) size1 = sizeForCopy;
                                else if (counter2 == 1) size2 = sizeForCopy;
                                else if (counter2 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter2 == 3) size1 = sizeForCopy;
                                else if (counter2 == 4) size2 = sizeForCopy;
                                else if (counter2 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag2 = 0;
                        
                        for (int counter2 = 0; counter2 < 6; counter2++){
                            sizeForCopy2 = 0;
                            
                            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy2 = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy2 != 0){
                                if (counter2 == 0) size1 = sizeForCopy2;
                                else if (counter2 == 1) size2 = sizeForCopy2;
                                else if (counter2 == 2){
                                    if (size1 == sizeForCopy2 && size2 == sizeForCopy2 && size1 == size2){
                                        checkFlag2 = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter2 == 3) size1 = sizeForCopy2;
                                else if (counter2 == 4) size2 = sizeForCopy2;
                                else if (counter2 == 5){
                                    if (size1 == sizeForCopy2 && size2 == sizeForCopy2 && size1 == size2){
                                        checkFlag2 = 1;
                                    }
                                }
                            }
                        }
                        
                        if ((quantConst == 0 && checkFlag == 1) || (quantConst == 1 && checkFlag == 1 && checkFlag2 == 1)){
                            readingError = 0;
                            
                            int *expandFluorescentOutlineReQuant = new int [sizeForCopy+sizeForCopy2+50];
                            expandFluorescentOutlineReQuantCount = 0;
                            
                            fin.open(expandFluorescentPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [1], expandFluorescentOutlineReQuantCount++;
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [3], expandFluorescentOutlineReQuantCount++;
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [6], expandFluorescentOutlineReQuantCount++;
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [7], expandFluorescentOutlineReQuantCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                            }
                            
                            int *masterReQuant = new int [sizeForCopy2+50];
                            
                            masterReQuantCount = 0;
                            
                            if (quantConst == 1){
                                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy2+50];
                                    fin.read((char*)uploadTemp, sizeForCopy2+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy2-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy2+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy2-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy2+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy2-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-12]) != 0){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++;
                                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                else{
                                                    
                                                    masterReQuant [masterReQuantCount] = finData [1], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [3], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [4], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [7], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [12], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [13], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [16], masterReQuantCount++;
                                                }
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData [9] = finData [8]*256+finData [9];
                                                
                                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                            }
                                            
                                        } while (stepCount != 3);
                                    }
                                    
                                    delete [] uploadTemp;
                                }
                                
                                if (readingError == 0){
                                    int *expandFluorescentOutlineReQuantTemp = new int [sizeForCopy+sizeForCopy2+50];
                                    expandFluorescentOutlineReQuantTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                        if (expandFluorescentOutlineReQuant [counter3*4+3] != fluorescentDisplayNo){
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4+1], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4+2], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4+3], expandFluorescentOutlineReQuantTempCount++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < masterReQuantCount/7; counterA++){
                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< masterReQuant [counterA*7+counterB];
                                    //    cout<<"  masterReQuant "<<counterA<<endl;
                                    //}
                                    
                                    for (int counter3 = 0; counter3 < masterReQuantCount/7; counter3++){
                                        if (masterReQuant [counter3*7+6] != 0){
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = masterReQuant [counter3*7], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = masterReQuant [counter3*7+1], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = masterReQuant [counter3*7+3], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = fluorescentDisplayNo, expandFluorescentOutlineReQuantTempCount++;
                                        }
                                    }
                                    
                                    expandFluorescentOutlineReQuantCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantTempCount; counter3++) expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = expandFluorescentOutlineReQuantTemp [counter3], expandFluorescentOutlineReQuantCount++;
                                    
                                    delete [] expandFluorescentOutlineReQuantTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < expandFluorescentOutlineReQuantCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentOutlineReQuant [counterA*4+counterB];
                            //    cout<<"  expandFluorescentOutlineReQuant "<<counterA<<endl;
                            //}
                            
                            if (readingError == 0){
                                expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                                
                                sizeForCopy = 0;
                                
                                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                int *expandFluorescentDataReQuant = new int [sizeForCopy+50];
                                expandFluorescentDataReQuantCount = 0;
                                expandFluorescentDataReQuantLimit = sizeForCopy+50;
                                
                                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                            
                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [2], expandFluorescentDataReQuantCount++;
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [3], expandFluorescentDataReQuantCount++;
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [4], expandFluorescentDataReQuantCount++;
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [7], expandFluorescentDataReQuantCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                                
                                int *expandFluorescentDataReQuantTemp = new int [expandFluorescentDataReQuantCount+50];
                                expandFluorescentDataReQuantTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < expandFluorescentDataReQuantCount/4; counter3++){
                                    if (expandFluorescentDataReQuant [counter3*4+1] != fluorescentDisplayNo){
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4], expandFluorescentDataReQuantTempCount++;
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4+1], expandFluorescentDataReQuantTempCount++;
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4+2], expandFluorescentDataReQuantTempCount++;
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4+3], expandFluorescentDataReQuantTempCount++;
                                    }
                                }
                                
                                expandFluorescentDataReQuantCount = 0;
                                
                                for (int counter3 = 0; counter3 < expandFluorescentDataReQuantTempCount; counter3++) expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = expandFluorescentDataReQuantTemp [counter3], expandFluorescentDataReQuantCount++;
                                
                                delete [] expandFluorescentDataReQuantTemp;
                                
                                //for (int counterA = 0; counterA < expandFluorescentDataReQuantCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentDataReQuant [counterA*4+counterB];
                                //    cout<<"  expandFluorescentDataReQuant "<<counterA<<endl;
                                //}
                                
                                maxConnectNo = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataReQuantCount/4; counter2++){
                                    if (expandFluorescentDataReQuant [counter2*4] > maxConnectNo) maxConnectNo = expandFluorescentDataReQuant [counter2*4];
                                }
                                
                                if (quantConst == 1){
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineReQuantCount/4; counter2++){
                                        if (expandFluorescentOutlineReQuant [counter2*4+2] > maxConnectNo) maxConnectNo = expandFluorescentOutlineReQuant [counter2*4+2];
                                    }
                                }
                                
                                int *connectReQuantList = new int [maxConnectNo+10];
                                
                                for (int counter2 = 0; counter2 < maxConnectNo+10; counter2++) connectReQuantList [counter2] = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataReQuantCount/4; counter2++){
                                    connectReQuantList [expandFluorescentDataReQuant [counter2*4]] = 1;
                                }
                                
                                if (quantConst == 1){
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineReQuantCount/4; counter2++){
                                        connectReQuantList [expandFluorescentOutlineReQuant [counter2*4+2]] = 1;
                                    }
                                }
                                
                                int **fluorescentMapVer1 = new int *[imageWidthTrack+1];
                                for (int counter3 = 0; counter3 < imageWidthTrack+1; counter3++) fluorescentMapVer1 [counter3] = new int [imageWidthTrack+1];
                                
                                if (fluorescentDisplayNo == 1){
                                    extension2 = to_string(fluorescentNo1);
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName1+exType;
                                }
                                else if (fluorescentDisplayNo == 2){
                                    extension2 = to_string(fluorescentNo2);
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName2+exType;
                                }
                                else if (fluorescentDisplayNo == 3){
                                    extension2 = to_string(fluorescentNo3);
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName3+exType;
                                }
                                else if (fluorescentDisplayNo == 4){
                                    extension2 = to_string(fluorescentNo4);
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName4+exType;
                                }
                                else if (fluorescentDisplayNo == 5){
                                    extension2 = to_string(fluorescentNo5);
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName5+exType;
                                }
                                else if (fluorescentDisplayNo == 6){
                                    extension2 = to_string(fluorescentNo6);
                                    fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentName6+exType;
                                }
                                
                                if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter3 = imageWidthTrack-1; counter3 >= 0; counter3--){
                                                for (int counter4 = 0; counter4 < imageWidthTrack; counter4++){
                                                    fluorescentMapVer1 [imageDimensionReadCount][counter4] = uploadTemp [1078+counter3*imageWidthTrack+counter4];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                                
                                for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                                    if (connectReQuantList [counter2] != 0){
                                        maxPointDimX = 0;
                                        maxPointDimY = 0;
                                        minPointDimX = 1000000;
                                        minPointDimY = 1000000;
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                            if (expandFluorescentOutlineReQuant [counter3*4+2] == counter2 && expandFluorescentOutlineReQuant [counter3*4+3] == fluorescentDisplayNo){
                                                if (maxPointDimX < expandFluorescentOutlineReQuant [counter3*4]) maxPointDimX = expandFluorescentOutlineReQuant [counter3*4];
                                                if (minPointDimX > expandFluorescentOutlineReQuant [counter3*4]) minPointDimX = expandFluorescentOutlineReQuant [counter3*4];
                                                if (maxPointDimY < expandFluorescentOutlineReQuant [counter3*4+1]) maxPointDimY = expandFluorescentOutlineReQuant [counter3*4+1];
                                                if (minPointDimY > expandFluorescentOutlineReQuant [counter3*4+1]) minPointDimY = expandFluorescentOutlineReQuant [counter3*4+1];
                                            }
                                        }
                                        
                                        //-----Determine the dimension of cell-----
                                        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                        verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                        dimension = 0;
                                        
                                        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                        if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                        
                                        dimension = (dimension/2)*2;
                                        
                                        horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                        verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                        
                                        if (dimension > 0){
                                            int **connectivityMapVerRE = new int *[dimension+1];
                                            
                                            for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                                connectivityMapVerRE [counter3] = new int [dimension+1];
                                            }
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    connectivityMapVerRE [counterY][counterX] = 0;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                                if (expandFluorescentOutlineReQuant [counter3*4+2] == counter2 && expandFluorescentOutlineReQuant [counter3*4+3] == fluorescentDisplayNo){
                                                    connectivityMapVerRE [expandFluorescentOutlineReQuant [counter3*4+1]-verticalStart][expandFluorescentOutlineReQuant [counter3*4]-horizontalStart] = 1;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < dimension; counterA++){
                                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapVerRE [counterA][counterB];
                                            //    cout<<" connectivityMapVerRE "<<counterA<<endl;
                                            //}
                                            
                                            //-----Fill inside-----
                                            int *connectAnalysisX = new int [dimension*4];
                                            int *connectAnalysisY = new int [dimension*4];
                                            int *connectAnalysisTempX = new int [dimension*4];
                                            int *connectAnalysisTempY = new int [dimension*4];
                                            
                                            connectivityNumber = -3;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerRE [counterY][counterX] == 0){
                                                        connectivityNumber = connectivityNumber+2;
                                                        connectAnalysisCount = 0;
                                                        
                                                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerRE [counterY][counterX] = connectivityNumber;
                                                        
                                                        if (counterY-1 >= 0 && connectivityMapVerRE [counterY-1][counterX] == 0){
                                                            connectivityMapVerRE [counterY-1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                        }
                                                        if (counterX+1 < dimension && connectivityMapVerRE [counterY][counterX+1] == 0){
                                                            connectivityMapVerRE [counterY][counterX+1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        if (counterY+1 < dimension && connectivityMapVerRE [counterY+1][counterX] == 0){
                                                            connectivityMapVerRE [counterY+1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                        }
                                                        if (counterX-1 >= 0 && connectivityMapVerRE [counterY][counterX-1] == 0){
                                                            connectivityMapVerRE [counterY][counterX-1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        
                                                        if (connectAnalysisCount != 0){
                                                            do{
                                                                terminationFlag = 1;
                                                                connectAnalysisTempCount = 0;
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                    
                                                                    if (ySource-1 >= 0 && connectivityMapVerRE [ySource-1][xSource] == 0){
                                                                        connectivityMapVerRE [ySource-1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource+1 < dimension && connectivityMapVerRE [ySource][xSource+1] == 0){
                                                                        connectivityMapVerRE [ySource][xSource+1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                    if (ySource+1 < dimension && connectivityMapVerRE [ySource+1][xSource] == 0){
                                                                        connectivityMapVerRE [ySource+1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource-1 >= 0 && connectivityMapVerRE [ySource][xSource-1] == 0){
                                                                        connectivityMapVerRE [ySource][xSource-1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                }
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                }
                                                                
                                                                connectAnalysisCount = connectAnalysisTempCount;
                                                                
                                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                
                                                            } while (terminationFlag == 1);
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerRE [counterY][counterX] == -1) connectivityMapVerRE [counterY][counterX] = 0;
                                                    else connectivityMapVerRE [counterY][counterX] = 1;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < dimension; counterA++){
                                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapVerRE [counterA][counterB];
                                            //    cout<<" connectivityMapVerRE "<<counterA<<endl;
                                            //}
                                            
                                            delete [] connectAnalysisX;
                                            delete [] connectAnalysisY;
                                            delete [] connectAnalysisTempX;
                                            delete [] connectAnalysisTempY;
                                            
                                            pixelValueTemp = 0;
                                            pixelAreaTemp = 0;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerRE [counterY][counterX] != 0){
                                                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidthTrack && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidthTrack){
                                                            if (fluorescentCutReQuant <= fluorescentMapVer1 [counterY+verticalStart][counterX+horizontalStart]){
                                                                pixelValueTemp = pixelValueTemp+fluorescentMapVer1 [counterY+verticalStart][counterX+horizontalStart];
                                                            }
                                                            
                                                            pixelAreaTemp++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                            
                                            if (expandFluorescentDataReQuantCount+8 > expandFluorescentDataReQuantLimit){
                                                int *arrayUpDate = new int [expandFluorescentDataReQuantCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluorescentDataReQuantCount; counter4++) arrayUpDate [counter4] = expandFluorescentDataReQuant [counter4];
                                                
                                                delete [] expandFluorescentDataReQuant;
                                                expandFluorescentDataReQuantLimit = expandFluorescentDataReQuantCount+500;
                                                expandFluorescentDataReQuant = new int [expandFluorescentDataReQuantLimit];
                                                
                                                for (int counter4 = 0; counter4 < expandFluorescentDataReQuantCount; counter4++) expandFluorescentDataReQuant [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = counter2, expandFluorescentDataReQuantCount++;
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = fluorescentDisplayNo, expandFluorescentDataReQuantCount++;
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = (int)averageArea, expandFluorescentDataReQuantCount++;
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = pixelAreaTemp, expandFluorescentDataReQuantCount++;
                                            
                                            for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                                delete [] connectivityMapVerRE [counter3];
                                            }
                                            
                                            delete [] connectivityMapVerRE;
                                        }
                                    }
                                }
                                
                                if (expandFluorescentDataReQuantCount != 0){
                                    int readBit [3];
                                    unsigned long indexCount = 0;
                                    char *writingArray = new char [expandFluorescentDataReQuantCount*2+20];
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentDataReQuantCount/4; counter3++){
                                        dataTemp = expandFluorescentDataReQuant [counter3*4];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)expandFluorescentDataReQuant [counter3*4+1], indexCount++;
                                        writingArray [indexCount] = (char)expandFluorescentDataReQuant [counter3*4+2], indexCount++;
                                        
                                        dataTemp = expandFluorescentDataReQuant [counter3*4+3];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile2 (expandDataPath.c_str(), ofstream::binary);
                                    outfile2.write ((char*)writingArray, indexCount);
                                    outfile2.close();
                                    
                                    delete [] writingArray;
                                }
                                
                                if (quantConst == 1){
                                    if (expandFluorescentOutlineReQuantCount != 0){
                                        int readBit [3];
                                        unsigned long indexCount = 0;
                                        
                                        char *writingArray = new char [expandFluorescentOutlineReQuantCount*2+200];
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                            dataTemp = expandFluorescentOutlineReQuant [counter3*4];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = expandFluorescentOutlineReQuant [counter3*4+1];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = expandFluorescentOutlineReQuant [counter3*4+2];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            writingArray [indexCount] = (char)expandFluorescentOutlineReQuant [counter3*4+3], indexCount++;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile4 (expandFluorescentPath.c_str(), ofstream::binary);
                                        outfile4.write ((char*)writingArray, indexCount);
                                        outfile4.close();
                                        
                                        delete [] writingArray;
                                    }
                                }
                                
                                if (imageNumberTrackForDisplay == counter1){
                                    if (expandFluorescentDataReQuantCount > expandFluorescentDataLimit+20){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentDataUpDate];
                                    }
                                    
                                    expandFluorescentDataCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentDataReQuantCount; counter3++) expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataReQuant [counter3], expandFluorescentDataCount++;
                                }
                                
                                if (imageNumberTrackForDisplay == counter1 && quantConst == 1){
                                    if (expandFluorescentOutlineReQuantCount > expandFluorescentOutlineLimit+20) {
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutlineCount = 0;
                                    for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount; counter3++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineReQuant [counter3], expandFluorescentOutlineCount++;
                                }
                                
                                delete [] expandFluorescentDataReQuant;
                                delete [] connectReQuantList;
                                
                                for (int counter3 = 0; counter3 < imageWidthTrack+1; counter3++) delete [] fluorescentMapVer1 [counter3];
                                delete [] fluorescentMapVer1;
                            }
                            
                            delete [] expandFluorescentOutlineReQuant;
                            delete [] masterReQuant;
                            
                            if (readingError == 1){
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"File Read Error"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                                
                                break;
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"File Read Error/Redo File Read"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            break;
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (ifEntry != 0){
                int fluorescentCutReQuant = 0;
                int maxPointDimX = 0;
                int maxPointDimY = 0;
                int minPointDimX = 0;
                int minPointDimY = 0;
                int expandFluorescentOutlineReQuantCount = 0;
                int expandFluorescentDataReQuantCount = 0;
                int expandFluorescentOutlineReQuantTempCount = 0;
                int expandFluorescentDataReQuantTempCount = 0;
                int masterReQuantCount = 0;
                int maxConnectNo = 0;
                int horizontalLength = 0;
                int verticalLength = 0;
                int dimension = 0;
                int horizontalStart = 0;
                int verticalStart = 0;
                int connectAnalysisCount = 0;
                int terminationFlag = 0;
                int connectAnalysisTempCount = 0;
                int xSource = 0;
                int ySource = 0;
                int connectivityNumber = 0;
                int imageDimensionReadCount = 0;
                int pixelValueTemp = 0;
                int pixelAreaTemp = 0;
                int dataTemp = 0;
                int stepCount = 0;
                int nextLoad = 0;
                int fluorescentNoVer1 = 0;
                int expandFluorescentDataReQuantLimit = 0;
                int finData [17];
                int dataConversion [4];
                int endianType = 0;
                int imageWidthEntry = 0;
                int value0 = 0;
                int value1 = 0;
                int value2 = 0;
                int checkFlag = 0;
                int checkFlag2 = 0;
                int readingError = 0;
                
                long sizeForCopy = 0;
                long sizeForCopy2 = 0;
                long size1 = 0;
                long size2 = 0;
                
                unsigned long readPosition = 0;
                unsigned long headPosition = 0;
                
                double averageArea = 0;
                
                struct stat sizeOfFile;
                
                string fluorescentRoundNoVer;
                string expandFluorescentPath;
                string expandDataPath;
                string extension;
                string extension2;
                string fluorescentProcessPath1;
                string fluorescentNameVer1;
                string connectDataPath;
                
                ifstream fin;
                
                for (int counter1 = ifStartHold; counter1 <= imageEndHold; counter1++){
                    if (timeLineDataHold [counter1] != imageNumberTrackForDisplay){
                        fluorescentCutReQuant = 0;
                        
                        for (int counter2 = 0; counter2 < fluorescentCutOffCount/7; counter2++){
                            if (arrayFluorescentCutOff [counter2*7] == counter1){
                                if (fluorescentDisplayNo == 1) fluorescentCutReQuant = fluorescentCutOff1;
                                if (fluorescentDisplayNo == 2) fluorescentCutReQuant = fluorescentCutOff2;
                                if (fluorescentDisplayNo == 3) fluorescentCutReQuant = fluorescentCutOff3;
                                if (fluorescentDisplayNo == 4) fluorescentCutReQuant = fluorescentCutOff4;
                                if (fluorescentDisplayNo == 5) fluorescentCutReQuant = fluorescentCutOff5;
                                if (fluorescentDisplayNo == 6) fluorescentCutReQuant = fluorescentCutOff6;
                                break;
                            }
                        }
                        
                        extension = to_string(counter1);
                        
                        if (extension.length() == 1) extension = "000"+extension;
                        else if (extension.length() == 2) extension = "00"+extension;
                        else if (extension.length() == 3) extension = "0"+extension;
                        
                        expandFluorescentPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendLineData";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag = 0;
                        
                        for (int counter2 = 0; counter2 < 6; counter2++){
                            sizeForCopy = 0;
                            
                            if (stat(expandFluorescentPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy != 0){
                                if (counter2 == 0) size1 = sizeForCopy;
                                else if (counter2 == 1) size2 = sizeForCopy;
                                else if (counter2 == 2){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter2 == 3) size1 = sizeForCopy;
                                else if (counter2 == 4) size2 = sizeForCopy;
                                else if (counter2 == 5){
                                    if (size1 == sizeForCopy && size2 == sizeForCopy && size1 == size2){
                                        checkFlag = 1;
                                    }
                                }
                            }
                        }
                        
                        connectDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_MasterDataRevise";
                        
                        size1 = 0;
                        size2 = 0;
                        checkFlag2 = 0;
                        
                        for (int counter2 = 0; counter2 < 6; counter2++){
                            sizeForCopy2 = 0;
                            
                            if (stat(connectDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy2 = sizeOfFile.st_size;
                            }
                            
                            if (sizeForCopy2 != 0){
                                if (counter2 == 0) size1 = sizeForCopy2;
                                else if (counter2 == 1) size2 = sizeForCopy2;
                                else if (counter2 == 2){
                                    if (size1 == sizeForCopy2 && size2 == sizeForCopy2 && size1 == size2){
                                        checkFlag2 = 1;
                                        break;
                                    }
                                    else{
                                        
                                        size1 = 0;
                                        size2 = 0;
                                        usleep (50000);
                                    }
                                }
                                else if (counter2 == 3) size1 = sizeForCopy2;
                                else if (counter2 == 4) size2 = sizeForCopy2;
                                else if (counter2 == 5){
                                    if (size1 == sizeForCopy2 && size2 == sizeForCopy2 && size1 == size2){
                                        checkFlag2 = 1;
                                    }
                                }
                            }
                        }
                        
                        if ((quantConst == 0 && checkFlag == 1) || (quantConst == 1 && checkFlag == 1 && checkFlag2 == 1)){
                            readingError = 0;
                            
                            int *expandFluorescentOutlineReQuant = new int [sizeForCopy+sizeForCopy2+50];
                            expandFluorescentOutlineReQuantCount = 0;
                            
                            fin.open(expandFluorescentPath.c_str(), ios::in | ios::binary);
                            
                            if (fin.is_open()){
                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                
                                if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                    usleep(50000);
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy-8]) != 0){
                                            readingError = 1;
                                        }
                                    }
                                }
                                
                                fin.close();
                                
                                if (readingError == 0){
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1 X Position
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Y Position
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++; //--4 Connect No
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--7 Channel No
                                            
                                            finData [1] = finData [0]*256+finData [1];
                                            finData [3] = finData [2]*256+finData [3];
                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                            
                                            if (finData [1] == 0 && finData [3] == 0 && finData [6] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [1], expandFluorescentOutlineReQuantCount++;
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [3], expandFluorescentOutlineReQuantCount++;
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [6], expandFluorescentOutlineReQuantCount++;
                                                expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = finData [7], expandFluorescentOutlineReQuantCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                }
                                
                                delete [] uploadTemp;
                            }
                            
                            int *masterReQuant = new int [sizeForCopy2+50];
                            
                            masterReQuantCount = 0;
                            
                            if (quantConst == 1){
                                fin.open(connectDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy2+50];
                                    fin.read((char*)uploadTemp, sizeForCopy2+50);
                                    
                                    if ((finData [0] = uploadTemp [sizeForCopy2-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-12]) != 0){
                                        usleep(50000);
                                        fin.read((char*)uploadTemp, sizeForCopy2+50);
                                        
                                        if ((finData [0] = uploadTemp [sizeForCopy2-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-12]) != 0){
                                            usleep(50000);
                                            fin.read((char*)uploadTemp, sizeForCopy2+50);
                                            
                                            if ((finData [0] = uploadTemp [sizeForCopy2-1]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-2]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-3]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-4]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-5]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-6]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-7]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-8]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-9]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-10]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-11]) != 0 || (finData [0] = uploadTemp [sizeForCopy2-12]) != 0){
                                                readingError = 1;
                                            }
                                        }
                                    }
                                    
                                    fin.close();
                                    
                                    if (readingError == 0){
                                        readPosition = 0;
                                        stepCount = 0;
                                        
                                        do{
                                            
                                            if (stepCount == 0){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++; //--+/- Flag
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++;
                                                finData [11] = uploadTemp [readPosition], readPosition++;
                                                finData [12] = uploadTemp [readPosition], readPosition++; //--5 Cell no
                                                finData [13] = uploadTemp [readPosition], readPosition++; //--6 Status
                                                finData [14] = uploadTemp [readPosition], readPosition++;
                                                finData [15] = uploadTemp [readPosition], readPosition++;
                                                finData [16] = uploadTemp [readPosition], readPosition++; //--7 Lineage no
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                
                                                if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                
                                                finData [16] = finData [14]*65536+finData [15]*256+finData [16];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                else{
                                                    
                                                    masterReQuant [masterReQuantCount] = finData [1], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [3], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [4], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [7], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [12], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [13], masterReQuantCount++;
                                                    masterReQuant [masterReQuantCount] = finData [16], masterReQuantCount++;
                                                }
                                            }
                                            else if (stepCount == 1){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++;
                                                finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++;
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                finData [9] = finData [8]*256+finData [9];
                                                
                                                if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                            }
                                            else if (stepCount == 2){
                                                finData [0] = uploadTemp [readPosition], readPosition++;
                                                finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                finData [2] = uploadTemp [readPosition], readPosition++;
                                                finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                finData [4] = uploadTemp [readPosition], readPosition++;
                                                finData [5] = uploadTemp [readPosition], readPosition++;
                                                finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                                finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                finData [8] = uploadTemp [readPosition], readPosition++;
                                                finData [9] = uploadTemp [readPosition], readPosition++;
                                                finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                                finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                                
                                                finData [1] = finData [0]*256+finData [1];
                                                finData [3] = finData [2]*256+finData [3];
                                                finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                
                                                if (finData [1] == 0 && finData [3] == 0 && finData [10] == 0) stepCount = 3;
                                            }
                                            
                                        } while (stepCount != 3);
                                    }
                                    
                                    delete [] uploadTemp;
                                }
                                
                                if (readingError == 0){
                                    int *expandFluorescentOutlineReQuantTemp = new int [sizeForCopy+sizeForCopy2+50];
                                    expandFluorescentOutlineReQuantTempCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                        if (expandFluorescentOutlineReQuant [counter3*4+3] != fluorescentDisplayNo+6){
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4+1], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4+2], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = expandFluorescentOutlineReQuant [counter3*4+3], expandFluorescentOutlineReQuantTempCount++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < masterReQuantCount/7; counter3++){
                                        if (masterReQuant [counter3*7+6] != 0){
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = masterReQuant [counter3*7], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = masterReQuant [counter3*7+1], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = masterReQuant [counter3*7+3], expandFluorescentOutlineReQuantTempCount++;
                                            expandFluorescentOutlineReQuantTemp [expandFluorescentOutlineReQuantTempCount] = fluorescentDisplayNo+6, expandFluorescentOutlineReQuantTempCount++;
                                        }
                                    }
                                    
                                    expandFluorescentOutlineReQuantCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantTempCount; counter3++) expandFluorescentOutlineReQuant [expandFluorescentOutlineReQuantCount] = expandFluorescentOutlineReQuantTemp [counter3], expandFluorescentOutlineReQuantCount++;
                                    
                                    delete [] expandFluorescentOutlineReQuantTemp;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < expandFluorescentOutlineReQuantCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentOutlineReQuant [counterA*4+counterB];
                            //    cout<<"  expandFluorescentOutlineReQuant "<<counterA<<endl;
                            //}
                            
                            if (readingError == 0){
                                expandDataPath = trackDataFolderPath+"/"+analysisImageName+"_Series/"+analysisID+"_TrackData/"+treatmentNameHold+"_Connect/"+extension+"_"+analysisID+"_"+treatmentNameHold+"_ExtendAreaData";
                                
                                sizeForCopy = 0;
                                
                                if (stat(expandDataPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                int *expandFluorescentDataReQuant = new int [sizeForCopy+50];
                                expandFluorescentDataReQuantCount = 0;
                                expandFluorescentDataReQuantLimit = sizeForCopy+50;
                                
                                fin.open(expandDataPath.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pixel
                                            
                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            
                                            if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                            else{
                                                
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [2], expandFluorescentDataReQuantCount++;
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [3], expandFluorescentDataReQuantCount++;
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [4], expandFluorescentDataReQuantCount++;
                                                expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = finData [7], expandFluorescentDataReQuantCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                }
                                
                                //for (int counterA = 0; counterA < expandFluorescentDataReQuantCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentDataReQuant [counterA*4+counterB];
                                //    cout<<"  expandFluorescentDataReQuant "<<counterA<<endl;
                                //}
                                
                                int *expandFluorescentDataReQuantTemp = new int [expandFluorescentDataReQuantCount+50];
                                expandFluorescentDataReQuantTempCount = 0;
                                
                                for (int counter3 = 0; counter3 < expandFluorescentDataReQuantCount/4; counter3++){
                                    if (expandFluorescentDataReQuant [counter3*4+1] != fluorescentDisplayNo+6){
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4], expandFluorescentDataReQuantTempCount++;
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4+1], expandFluorescentDataReQuantTempCount++;
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4+2], expandFluorescentDataReQuantTempCount++;
                                        expandFluorescentDataReQuantTemp [expandFluorescentDataReQuantTempCount] = expandFluorescentDataReQuant [counter3*4+3], expandFluorescentDataReQuantTempCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < expandFluorescentDataReQuantTempCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentDataReQuantTemp [counterA*4+counterB];
                                //    cout<<"  expandFluorescentDataReQuantTemp "<<counterA<<endl;
                                //}
                                
                                expandFluorescentDataReQuantCount = 0;
                                
                                for (int counter3 = 0; counter3 < expandFluorescentDataReQuantTempCount; counter3++) expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = expandFluorescentDataReQuantTemp [counter3], expandFluorescentDataReQuantCount++;
                                
                                delete [] expandFluorescentDataReQuantTemp;
                                
                                maxConnectNo = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataReQuantCount/4; counter2++){
                                    if (expandFluorescentDataReQuant [counter2*4] > maxConnectNo) maxConnectNo = expandFluorescentDataReQuant [counter2*4];
                                }
                                
                                if (quantConst == 1){
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineReQuantCount/4; counter2++){
                                        if (expandFluorescentOutlineReQuant [counter2*4+2] > maxConnectNo) maxConnectNo = expandFluorescentOutlineReQuant [counter2*4+2];
                                    }
                                }
                                
                                int *connectReQuantList = new int [maxConnectNo+10];
                                
                                for (int counter2 = 0; counter2 < maxConnectNo+10; counter2++) connectReQuantList [counter2] = 0;
                                
                                for (int counter2 = 0; counter2 < expandFluorescentDataReQuantCount/4; counter2++){
                                    connectReQuantList [expandFluorescentDataReQuant [counter2*4]] = 1;
                                }
                                
                                if (quantConst == 1){
                                    for (int counter2 = 0; counter2 < expandFluorescentOutlineReQuantCount/4; counter2++){
                                        connectReQuantList [expandFluorescentOutlineReQuant [counter2*4+2]] = 1;
                                    }
                                }
                                
                                nextLoad = 0;
                                
                                for (int counter3 = 0; counter3 < 450; counter3 = counter3+15){
                                    if (atoi(arrayIFDataHold [counter3].c_str()) != 0 && atoi(arrayIFDataHold [counter3+14].c_str()) == counter1){
                                        nextLoad = counter3/15;
                                    }
                                    else if (atoi(arrayIFDataHold [counter3].c_str()) == 0){
                                        break;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 90/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
                                //    cout<<" arrayIFDataHold "<<counterA<<endl;
                                //}
                                
                                fluorescentRoundNoVer = arrayIFDataHold [nextLoad*15];
                                fluorescentNoVer1 = 0;
                                
                                if (fluorescentDisplayNo == 1){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+7].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+1];
                                }
                                if (fluorescentDisplayNo == 2){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+8].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+2];
                                }
                                if (fluorescentDisplayNo == 3){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+9].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+3];
                                }
                                if (fluorescentDisplayNo == 4){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+10].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+4];
                                }
                                if (fluorescentDisplayNo == 5){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+11].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+5];
                                }
                                if (fluorescentDisplayNo == 6){
                                    fluorescentNoVer1 = atoi(arrayIFDataHold [nextLoad*15+15].c_str());
                                    fluorescentNameVer1 = arrayIFDataHold [nextLoad*15+6];
                                }
                                
                                int **fluorescentMapVer1 = new int *[imageWidthTrack+1];
                                for (int counter3 = 0; counter3 < imageWidthTrack+1; counter3++) fluorescentMapVer1 [counter3] = new int [imageWidthTrack+1];
                                
                                extension2 = to_string(fluorescentNoVer1);
                                fluorescentProcessPath1 = imageFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Stitch/"+"STimage "+extension+"_"+extension2+"_"+fluorescentNameVer1+exTypeIF+fluorescentRoundNoVer;
                                
                                if (stat(fluorescentProcessPath1.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    if (exType == ".tif" || exTypeIF == ".TIF"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            dataConversion [0] = uploadTemp [0];
                                            dataConversion [1] = uploadTemp [1];
                                            
                                            if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                            else endianType = 0;
                                            
                                            headPosition = 0;
                                            
                                            if (endianType == 1){
                                                dataConversion [0] = uploadTemp [7];
                                                dataConversion [1] = uploadTemp [6];
                                                dataConversion [2] = uploadTemp [5];
                                                dataConversion [3] = uploadTemp [4];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            else if (endianType == 0){
                                                dataConversion [0] = uploadTemp [4];
                                                dataConversion [1] = uploadTemp [5];
                                                dataConversion [2] = uploadTemp [6];
                                                dataConversion [3] = uploadTemp [7];
                                                headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                            }
                                            
                                            imageDimensionReadCount = 0;
                                            imageWidthEntry = 0;
                                            
                                            if (tifImageColorGray == 0){
                                                for (unsigned long counter3 = 8; counter3 < headPosition; counter3++){
                                                    fluorescentMapVer1 [imageDimensionReadCount][imageWidthEntry] = uploadTemp [counter3], imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                            else if (tifImageColorGray == 1){
                                                for (unsigned long counter3 = 8; counter3 < headPosition-3; counter3 = counter3+3){
                                                    value0 = uploadTemp [counter3];
                                                    value1 = uploadTemp [counter3+1];
                                                    value2 = uploadTemp [counter3+2];
                                                    
                                                    fluorescentMapVer1 [imageDimensionReadCount][imageWidthEntry] = (int)((value0+value1+value2)/(double)3), imageWidthEntry++;
                                                    
                                                    if (imageWidthEntry == imageDimension){
                                                        imageWidthEntry = 0;
                                                        imageDimensionReadCount++;
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                    else if (exType == ".bmp" || exTypeIF == ".BMP"){
                                        uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                        fin.open(fluorescentProcessPath1.c_str(), ios::in | ios::binary);
                                        
                                        if (fin.is_open()){
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            imageDimensionReadCount = 0;
                                            
                                            for (int counter3 = imageWidthTrack-1; counter3 >= 0; counter3--){
                                                for (int counter4 = 0; counter4 < imageWidthTrack; counter4++){
                                                    fluorescentMapVer1 [imageDimensionReadCount][counter4] = uploadTemp [1078+counter3*imageWidthTrack+counter4];
                                                }
                                                
                                                imageDimensionReadCount++;
                                            }
                                        }
                                        
                                        delete [] uploadTemp;
                                    }
                                }
                                
                                for (int counter2 = 1; counter2 <= maxConnectNo; counter2++){
                                    if (connectReQuantList [counter2] != 0){
                                        maxPointDimX = 0;
                                        maxPointDimY = 0;
                                        minPointDimX = 1000000;
                                        minPointDimY = 1000000;
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                            if (expandFluorescentOutlineReQuant [counter3*4+2] == counter2 && expandFluorescentOutlineReQuant [counter3*4+3] == fluorescentDisplayNo+6){
                                                if (maxPointDimX < expandFluorescentOutlineReQuant [counter3*4]) maxPointDimX = expandFluorescentOutlineReQuant [counter3*4];
                                                if (minPointDimX > expandFluorescentOutlineReQuant [counter3*4]) minPointDimX = expandFluorescentOutlineReQuant [counter3*4];
                                                if (maxPointDimY < expandFluorescentOutlineReQuant [counter3*4+1]) maxPointDimY = expandFluorescentOutlineReQuant [counter3*4+1];
                                                if (minPointDimY > expandFluorescentOutlineReQuant [counter3*4+1]) minPointDimY = expandFluorescentOutlineReQuant [counter3*4+1];
                                            }
                                        }
                                        
                                        //-----Determine the dimension of cell-----
                                        horizontalLength = (maxPointDimX-minPointDimX)/2*2;
                                        verticalLength = (maxPointDimY-minPointDimY)/2*2;
                                        dimension = 0;
                                        
                                        if (horizontalLength >= verticalLength) dimension = horizontalLength+30;
                                        if (horizontalLength < verticalLength) dimension = verticalLength+30;
                                        
                                        dimension = (dimension/2)*2;
                                        
                                        horizontalStart = minPointDimX-(dimension-horizontalLength)/2;
                                        verticalStart = minPointDimY-(dimension-verticalLength)/2;
                                        
                                        if (dimension > 0){
                                            int **connectivityMapVerRE = new int *[dimension+1];
                                            
                                            for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                                connectivityMapVerRE [counter3] = new int [dimension+1];
                                            }
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    connectivityMapVerRE [counterY][counterX] = 0;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                                if (expandFluorescentOutlineReQuant [counter3*4+2] == counter2 && expandFluorescentOutlineReQuant [counter3*4+3] == fluorescentDisplayNo+6){
                                                    connectivityMapVerRE [expandFluorescentOutlineReQuant [counter3*4+1]-verticalStart][expandFluorescentOutlineReQuant [counter3*4]-horizontalStart] = 1;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < dimension; counterA++){
                                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapVerRE [counterA][counterB];
                                            //    cout<<" connectivityMapVerRE "<<counterA<<endl;
                                            //}
                                            
                                            //-----Fill inside-----
                                            int *connectAnalysisX = new int [dimension*4];
                                            int *connectAnalysisY = new int [dimension*4];
                                            int *connectAnalysisTempX = new int [dimension*4];
                                            int *connectAnalysisTempY = new int [dimension*4];
                                            
                                            connectivityNumber = -3;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerRE [counterY][counterX] == 0){
                                                        connectivityNumber = connectivityNumber+2;
                                                        connectAnalysisCount = 0;
                                                        
                                                        if (connectivityNumber >= 1) connectivityNumber = 1, connectivityMapVerRE [counterY][counterX] = connectivityNumber;
                                                        
                                                        if (counterY-1 >= 0 && connectivityMapVerRE [counterY-1][counterX] == 0){
                                                            connectivityMapVerRE [counterY-1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY-1, connectAnalysisCount++;
                                                        }
                                                        if (counterX+1 < dimension && connectivityMapVerRE [counterY][counterX+1] == 0){
                                                            connectivityMapVerRE [counterY][counterX+1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX+1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        if (counterY+1 < dimension && connectivityMapVerRE [counterY+1][counterX] == 0){
                                                            connectivityMapVerRE [counterY+1][counterX] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX, connectAnalysisY [connectAnalysisCount] = counterY+1, connectAnalysisCount++;
                                                        }
                                                        if (counterX-1 >= 0 && connectivityMapVerRE [counterY][counterX-1] == 0){
                                                            connectivityMapVerRE [counterY][counterX-1] = connectivityNumber;
                                                            connectAnalysisX [connectAnalysisCount] = counterX-1, connectAnalysisY [connectAnalysisCount] = counterY, connectAnalysisCount++;
                                                        }
                                                        
                                                        if (connectAnalysisCount != 0){
                                                            do{
                                                                terminationFlag = 1;
                                                                connectAnalysisTempCount = 0;
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisCount; counter3++){
                                                                    xSource = connectAnalysisX [counter3], ySource = connectAnalysisY [counter3];
                                                                    
                                                                    if (ySource-1 >= 0 && connectivityMapVerRE [ySource-1][xSource] == 0){
                                                                        connectivityMapVerRE [ySource-1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource-1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource+1 < dimension && connectivityMapVerRE [ySource][xSource+1] == 0){
                                                                        connectivityMapVerRE [ySource][xSource+1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource+1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                    if (ySource+1 < dimension && connectivityMapVerRE [ySource+1][xSource] == 0){
                                                                        connectivityMapVerRE [ySource+1][xSource] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource, connectAnalysisTempY [connectAnalysisTempCount] = ySource+1, connectAnalysisTempCount++;
                                                                    }
                                                                    if (xSource-1 >= 0 && connectivityMapVerRE [ySource][xSource-1] == 0){
                                                                        connectivityMapVerRE [ySource][xSource-1] = connectivityNumber;
                                                                        connectAnalysisTempX [connectAnalysisTempCount] = xSource-1, connectAnalysisTempY [connectAnalysisTempCount] = ySource, connectAnalysisTempCount++;
                                                                    }
                                                                }
                                                                
                                                                for (int counter3 = 0; counter3 < connectAnalysisTempCount; counter3++){
                                                                    connectAnalysisX [counter3] = connectAnalysisTempX [counter3], connectAnalysisY [counter3] = connectAnalysisTempY [counter3];
                                                                }
                                                                
                                                                connectAnalysisCount = connectAnalysisTempCount;
                                                                
                                                                if (connectAnalysisCount == 0) terminationFlag = 0;
                                                                
                                                            } while (terminationFlag == 1);
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerRE [counterY][counterX] == -1) connectivityMapVerRE [counterY][counterX] = 0;
                                                    else connectivityMapVerRE [counterY][counterX] = 1;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < dimension; counterA++){
                                            //    for (int counterB = 0; counterB < dimension; counterB++) cout<<" "<<connectivityMapVerRE [counterA][counterB];
                                            //    cout<<" connectivityMapVerRE "<<counterA<<endl;
                                            //}
                                            
                                            delete [] connectAnalysisX;
                                            delete [] connectAnalysisY;
                                            delete [] connectAnalysisTempX;
                                            delete [] connectAnalysisTempY;
                                            
                                            pixelValueTemp = 0;
                                            pixelAreaTemp = 0;
                                            
                                            for (int counterY = 0; counterY < dimension; counterY++){
                                                for (int counterX = 0; counterX < dimension; counterX++){
                                                    if (connectivityMapVerRE [counterY][counterX] != 0){
                                                        if (counterY+verticalStart >= 0 && counterY+verticalStart < imageWidthTrack && counterX+horizontalStart >= 0 && counterX+horizontalStart < imageWidthTrack){
                                                            if (fluorescentCutReQuant <= fluorescentMapVer1 [counterY+verticalStart][counterX+horizontalStart]){
                                                                pixelValueTemp = pixelValueTemp+fluorescentMapVer1 [counterY+verticalStart][counterX+horizontalStart];
                                                            }
                                                            
                                                            pixelAreaTemp++;
                                                        }
                                                    }
                                                }
                                            }
                                            
                                            if (expandFluorescentDataReQuantCount+8 > expandFluorescentDataReQuantLimit){
                                                int *arrayUpDate = new int [expandFluorescentDataReQuantCount+10];
                                                
                                                for (int counter4 = 0; counter4 < expandFluorescentDataReQuantCount; counter4++) arrayUpDate [counter4] = expandFluorescentDataReQuant [counter4];
                                                
                                                delete [] expandFluorescentDataReQuant;
                                                expandFluorescentDataReQuantLimit = expandFluorescentDataReQuantCount+500;
                                                expandFluorescentDataReQuant = new int [expandFluorescentDataReQuantLimit];
                                                
                                                for (int counter4 = 0; counter4 < expandFluorescentDataReQuantCount; counter4++) expandFluorescentDataReQuant [counter4] = arrayUpDate [counter4];
                                                delete [] arrayUpDate;
                                            }
                                            
                                            averageArea = pixelValueTemp/(double)pixelAreaTemp;
                                            
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = counter2, expandFluorescentDataReQuantCount++;
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = fluorescentDisplayNo+6, expandFluorescentDataReQuantCount++;
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = (int)averageArea, expandFluorescentDataReQuantCount++;
                                            expandFluorescentDataReQuant [expandFluorescentDataReQuantCount] = pixelAreaTemp, expandFluorescentDataReQuantCount++;
                                            
                                            for (int counter3 = 0; counter3 < dimension+1; counter3++){
                                                delete [] connectivityMapVerRE [counter3];
                                            }
                                            
                                            delete [] connectivityMapVerRE;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < expandFluorescentDataReQuantCount/4; counterA++){
                                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< expandFluorescentDataReQuant [counterA*4+counterB];
                                //    cout<<"  expandFluorescentDataReQuant "<<counterA<<endl;
                                //}
                                
                                if (expandFluorescentDataReQuantCount != 0){
                                    int readBit [3];
                                    unsigned long indexCount = 0;
                                    char *writingArray = new char [expandFluorescentDataReQuantCount*2+20];
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentDataReQuantCount/4; counter3++){
                                        dataTemp = expandFluorescentDataReQuant [counter3*4];
                                        
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)expandFluorescentDataReQuant [counter3*4+1], indexCount++;
                                        writingArray [indexCount] = (char)expandFluorescentDataReQuant [counter3*4+2], indexCount++;
                                        
                                        dataTemp = expandFluorescentDataReQuant [counter3*4+3];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile2 (expandDataPath.c_str(), ofstream::binary);
                                    outfile2.write ((char*)writingArray, indexCount);
                                    outfile2.close();
                                    
                                    delete [] writingArray;
                                }
                                
                                if (quantConst == 1){
                                    if (expandFluorescentOutlineReQuantCount != 0){
                                        int readBit [3];
                                        unsigned long indexCount = 0;
                                        
                                        char *writingArray = new char [expandFluorescentOutlineReQuantCount*2+200];
                                        
                                        for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount/4; counter3++){
                                            dataTemp = expandFluorescentOutlineReQuant [counter3*4];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = expandFluorescentOutlineReQuant [counter3*4+1];
                                            readBit [0] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [1] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            
                                            dataTemp = expandFluorescentOutlineReQuant [counter3*4+2];
                                            readBit [0] = dataTemp/65536;
                                            dataTemp = dataTemp%65536;
                                            readBit [1] = dataTemp/256;
                                            dataTemp = dataTemp%256;
                                            readBit [2] = dataTemp;
                                            
                                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            
                                            writingArray [indexCount] = (char)expandFluorescentOutlineReQuant [counter3*4+3], indexCount++;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < 8; counter3++) writingArray [indexCount] = 0, indexCount++;
                                        
                                        ofstream outfile4 (expandFluorescentPath.c_str(), ofstream::binary);
                                        outfile4.write ((char*)writingArray, indexCount);
                                        outfile4.close();
                                        
                                        delete [] writingArray;
                                    }
                                }
                                
                                if (imageNumberTrackForDisplay == counter1){
                                    if (expandFluorescentDataReQuantCount > expandFluorescentDataLimit+20){
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentDataUpDate];
                                    }
                                    
                                    expandFluorescentDataCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < expandFluorescentDataReQuantCount; counter3++) expandFluorescentData [expandFluorescentDataCount] = expandFluorescentDataReQuant [counter3], expandFluorescentDataCount++;
                                }
                                
                                if (imageNumberTrackForDisplay == counter1 && quantConst == 1){
                                    if (expandFluorescentOutlineReQuantCount > expandFluorescentOutlineLimit+20) {
                                        fileUpdate = [[FileUpdate alloc] init];
                                        [fileUpdate expandFluorescentOutlineUpDate];
                                    }
                                    
                                    expandFluorescentOutlineCount = 0;
                                    for (int counter3 = 0; counter3 < expandFluorescentOutlineReQuantCount; counter3++) expandFluorescentOutline [expandFluorescentOutlineCount] = expandFluorescentOutlineReQuant [counter3], expandFluorescentOutlineCount++;
                                }
                                
                                delete [] expandFluorescentDataReQuant;
                                delete [] connectReQuantList;
                                
                                for (int counter3 = 0; counter3 < imageWidthTrack+1; counter3++) delete [] fluorescentMapVer1 [counter3];
                                delete [] fluorescentMapVer1;
                            }
                            
                            delete [] expandFluorescentOutlineReQuant;
                            delete [] masterReQuant;
                            
                            if (readingError == 1){
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"File Read Error"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                                
                                break;
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"File Read Error/Redo File Read"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            break;
                        }
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        
        delete [] timeLineDataHold;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Fluorescent Mode/Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)imageExportStart:(id)sender{
    if (trackingOn != 0){
        if (treatmentNameHold != ""){
            if (exportOperation == 0){
                exportOperation = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToExportController object:self];
            }
            
            if (exportOperation == 2) exportOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Treatment Name Required"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)phaseImageLoad:(id)sender{
    if (trackingOn != 0){
        if (treatmentNameHold != ""){
            NSOpenPanel *openDlg = [NSOpenPanel openPanel];
            [openDlg setCanChooseFiles:NO];
            [openDlg setCanChooseDirectories:YES];
            [openDlg setCanCreateDirectories:YES];
            
            if ([openDlg runModal] == NSModalResponseOK){
                NSArray *files = [openDlg URLs];
                NSString *fileName = [[files objectAtIndex:0] absoluteString];
                
                string directoryPathExtract = [fileName UTF8String];
                
                unsigned long directoryLength = directoryPathExtract.length();
                string extractedID;
                
                if ((int)directoryPathExtract.find("Volumes") != -1) extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Volumes/"), directoryLength-directoryPathExtract.find("/Volumes/")-1);
                else extractedID = directoryPathExtract.substr(directoryPathExtract.find("/Users/"), directoryLength-directoryPathExtract.find("/Users/")-1);
                
                string extractedID2;
                
                int terminationFlag = 0;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = extractedID.substr(0, extractedID.find("%20"));
                        extractedID = extractedID.substr(extractedID.find("%20")+3);
                        extractedID = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string cellFolderPath;
                
                dir = opendir(extractedID.c_str());
                
                int imageWidthPh = 0;
                int imageHeightPh = 0;
                int entryNo = 0;
                int endianType = 0;
                int dataConversion [4];
                int imageWidth = 0;
                int imageHeight = 0;
                int imageBit = 0; //Check 8, 16
                int imageCompression = 0; //Check 1
                int photoMetric = 0;//Check 0, 1, 2
                int samplePerPix = 0;
                int numberOfLayers = 0;
                
                long sizeForCopy = 0;
                
                unsigned long headPosition = 0;
                unsigned long stripFirstAddress = 0;
                unsigned long stripByteCountAddress = 0;
                unsigned long nextAddress = 0;
                unsigned long stripEntry = 0;
                
                double xPosition = 0;
                double yPosition = 0;
                
                struct stat sizeOfFile;
                
                ifstream fin;
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        cellFolderPath = extractedID+"/"+entry;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Phase") == -1){
                            if ((int)entry.find("tif") != -1 || (int)entry.find("TIF") != -1){
                                if (stat(cellFolderPath.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    fileReadArray = new uint8_t [sizeForCopy+50];
                                    fin.open(cellFolderPath.c_str(), ios::in | ios::binary);
                                    
                                    fin.read((char*)fileReadArray, sizeForCopy+50);
                                    fin.close();
                                    
                                    dataConversion [0] = fileReadArray [0];
                                    dataConversion [1] = fileReadArray [1];
                                    
                                    if (dataConversion [0] == 77 && dataConversion [1] == 77) endianType = 1;
                                    else endianType = 0;
                                    
                                    headPosition = 0;
                                    
                                    if (endianType == 1){
                                        dataConversion [0] = fileReadArray [7];
                                        dataConversion [1] = fileReadArray [6];
                                        dataConversion [2] = fileReadArray [5];
                                        dataConversion [3] = fileReadArray [4];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    else if (endianType == 0){
                                        dataConversion [0] = fileReadArray [4];
                                        dataConversion [1] = fileReadArray [5];
                                        dataConversion [2] = fileReadArray [6];
                                        dataConversion [3] = fileReadArray [7];
                                        headPosition = (unsigned long)dataConversion [3]*16777216+(unsigned long)dataConversion [2]*65536+(unsigned long)dataConversion [1]*256+(unsigned long)dataConversion [0];
                                    }
                                    
                                    if (endianType == 1){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadBigEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (photoMetric == 2) tifImageColorGray = 1;
                                        else if (photoMetric == 0) tifImageColorGray = 0;
                                        
                                        imageWidthPh = imageWidth;
                                        imageHeightPh = imageHeight;
                                    }
                                    else if (endianType == 0){
                                        tiffFileRead = [[TiffFileRead alloc] init];
                                        [tiffFileRead tiffReadLittleEndian: headPosition:&imageWidth:&imageHeight:&imageBit:&imageCompression:&photoMetric:&xPosition:&yPosition:&samplePerPix:&stripFirstAddress:&stripEntry:&stripByteCountAddress:&nextAddress:&numberOfLayers];
                                        
                                        if (photoMetric == 2) tifImageColorGray = 1;
                                        else if (photoMetric == 0) tifImageColorGray = 0;
                                        
                                        imageWidthPh = imageWidth;
                                        imageHeightPh = imageHeight;
                                    }
                                }
                            }
                            else if ((int)entry.find("bmp") != -1 || (int)entry.find("BMP") != -1){
                                fin.open(cellFolderPath.c_str(),ios::in | ios::binary);
                                
                                if (fin.is_open() && imageWidth == 0 && imageHeight == 0){
                                    unsigned long  bitPosition = 0;
                                    int horizontalBit [4] = {0,0,0,0};
                                    int verticalBit [4] = {0,0,0,0};
                                    int bitData = 0;
                                    
                                    while ((bitData = fin.get()) != EOF){
                                        if (bitPosition == 18) horizontalBit [0] = bitData;
                                        if (bitPosition == 19) horizontalBit [1] = bitData;
                                        if (bitPosition == 20) horizontalBit [2] = bitData;
                                        if (bitPosition == 21) horizontalBit [3] = bitData;
                                        if (bitPosition == 22) verticalBit [0] = bitData;
                                        if (bitPosition == 23) verticalBit [1] = bitData;
                                        if (bitPosition == 24) verticalBit [2] = bitData;
                                        if (bitPosition == 25){
                                            verticalBit [3] = bitData;
                                            
                                            imageWidthPh = horizontalBit [3]*16777216+horizontalBit [2]*65536+horizontalBit [1]*256+horizontalBit [0];
                                            imageHeightPh = verticalBit [3]*16777216+verticalBit [2]*65536+verticalBit [1]*256+verticalBit [0];
                                            break;
                                        }
                                        
                                        bitPosition++;
                                    }
                                    
                                    fin.close();
                                }
                                
                                if (atoi(entry.substr(entry.find("Phase")+1, 4).c_str()) > entryNo) entryNo = atoi(entry.substr(entry.find("Phase")+1, 4).c_str());
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                int imageDimensionCheck = 0;
                
                for (int counter1 = 0; counter1 < imageSizeListCount/2; counter1++){
                    if (arrayImageSizeList [counter1*2] == treatmentNameHold){
                        imageDimensionCheck = atoi(arrayImageSizeList [counter1*2+1].c_str());
                        break;
                    }
                }
                
                if ((timeEndHold == entryNo || imageEndHold == entryNo) && imageWidthPh == imageDimensionCheck && imageHeightPh == imageDimensionCheck){
                    string productPath2 = masterDataFolderPath+"/"+analysisImageName+"_Image/"+treatmentNameHold+"_Phase";
                    
                    mkdir(productPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    arrayFileDelete = new string [3000];
                    
                    dir = opendir(extractedID.c_str());
                    int fileDeleteCount2 = 0;
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                cellFolderPath = extractedID+"/"+entry;
                                arrayFileDelete [fileDeleteCount2] = entry, fileDeleteCount2++;
                            }
                        }
                        
                        closedir(dir);
                        
                        //-----Directory Sort-----
                        NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                        
                        for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                            [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
                        }
                        
                        [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                        
                        for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                            arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
                        }
                    }
                    
                    string savedDataPath;
                    string sourceDataPath;
                    
                    for (int counter2 = 0; counter2 < fileDeleteCount2; counter2++){
                        sourceDataPath = extractedID+"/"+arrayFileDelete [counter2];
                        savedDataPath = productPath2+"/"+arrayFileDelete [counter2];
                        
                        if ((int)arrayFileDelete [counter2].find("bmp") != -1 || (int)arrayFileDelete [counter2].find("tif") != -1){
                            if (stat(sourceDataPath.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (sourceDataPath.c_str(), ifstream::binary);
                                ofstream outfile (savedDataPath.c_str(), ofstream::binary);
                                
                                char* buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete[] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                    }
                    
                    delete [] arrayFileDelete;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Image Missing or Image Size Mismatch"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Treatment Name Required"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking On: Image Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)phaseStatusSet:(id)sender{
    if (phaseStatus == 0){
        phaseStatus = 1;
        sliderBarSet = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        
        [phaseStatusDisplay setStringValue:@"On"];
    }
    else{
        
        phaseStatus = 0;
        sliderBarSet = 1;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrackingWindow object:self];
        
        [phaseStatusDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)saveAsAnalysis:(id)sender{
    if ((trackingOn == 1 || trackingOn == 3) && mainSavingInProgress == 0 && cleaningProgress == 0){
        NSSavePanel *save = [NSSavePanel savePanel];
        
        long int result2 = [save runModal];
        
        if (result2 == NSModalResponseOK){
            NSURL *files = [save URL];
            NSString *selectedFile = files.path;
            
            string extractedID = [selectedFile UTF8String];
            string directoryPath = [selectedFile UTF8String];
            
            int terminationFlag = 1;
            int findString1 = 0;
            
            do{
                
                terminationFlag = 1;
                findString1 = (int)extractedID.find("/");
                
                if (findString1 != -1) extractedID = extractedID.substr((unsigned long)findString1+1);
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            findString1 = (int)directoryPath.find (extractedID);
            directoryPath = directoryPath.substr (0, (unsigned long)findString1);
            
            if (extractedID != "" && analysisID != ""){
                destinationName = extractedID;
                
                fileUpdate = [[FileUpdate alloc] init];
                int returnResults = [fileUpdate nameCheck];
                
                if (returnResults == 0){
                    destinationAnalysisPath = directoryPath+extractedID+"_TrackData";
                    sourceAnalysisPath = trackDataFolderPath+"/"+analysisImageName+"_Series"+"/"+analysisID+"_TrackData";
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    //-----Check whether same ID exist-----
                    int proceedingFlag = 0;
                    string checkName = destinationName+"_TrackData";
                    
                    string entry;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if (checkName == entry){
                                    proceedingFlag = 1;
                                    break;
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    else proceedingFlag = 1;
                    
                    //-----If it exists, proceed-----
                    if (proceedingFlag == 0){
                        folderCopy = [[FolderCopy alloc] init];
                        [folderCopy folderCopyMain];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Use Unique Save-ID Name"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Save Folder Name, Illegal Characters"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Choose Analysis Folder"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off or Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)patternRegister:(id)sender{
    if ((trackingOn == 1 || trackingOn == 3) && mainSavingInProgress == 0 && cleaningProgress == 0){
        ifstream fin;
        
        string mitosisPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"10_Cell_Tracking_Library/"+"Mitosis.dat";
        long sizeForCopy = 0;
        
        struct stat sizeOfFile;
        
        if (stat(mitosisPath.c_str(), &sizeOfFile) == 0){
            sizeForCopy = sizeOfFile.st_size;
            
            int listPointNumberShot = 0;
            
            int *arrayCellListDisplayTemp = new int [sizeForCopy+50];
            int cellListDisplayTempCount = 0;
            
            fin.open(mitosisPath.c_str(), ios::in | ios::binary);
            
            if (fin.is_open()){
                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                fin.read((char*)uploadTemp, sizeForCopy+50);
                fin.close();
                
                unsigned long readPosition = 0;
                int stepCount = 0;
                int finData [9];
                
                do{
                    
                    if (stepCount == 0){
                        finData [0] = uploadTemp [readPosition], readPosition++;
                        finData [1] = uploadTemp [readPosition], readPosition++; //--2. Entry No
                        finData [2] = uploadTemp [readPosition], readPosition++;
                        finData [3] = uploadTemp [readPosition], readPosition++; //--5. X Position
                        finData [4] = uploadTemp [readPosition], readPosition++;
                        finData [5] = uploadTemp [readPosition], readPosition++; //--8. Y Position
                        finData [6] = uploadTemp [readPosition], readPosition++;
                        finData [7] = uploadTemp [readPosition], readPosition++; //--10. Area
                        
                        finData [1] = finData [0]*256+finData [1];
                        finData [3] = finData [2]*256+finData [3];
                        finData [5] = finData [4]*256+finData [5];
                        finData [7] = finData [6]*256+finData [7];
                        
                        if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                        else{
                            
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [1], cellListDisplayTempCount++;
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [3], cellListDisplayTempCount++;
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [5], cellListDisplayTempCount++;
                            arrayCellListDisplayTemp [cellListDisplayTempCount] = finData [7], cellListDisplayTempCount++;
                        }
                    }
                    
                } while (stepCount != 3);
                
                listPointNumberShot = arrayCellListDisplayTemp [(cellListDisplayTempCount/4-1)*4];
                
                delete [] uploadTemp;
            }
            
            //for (int counterA = 0; counterA < cellListDisplayTempCount/4; counterA++){
            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<< arrayCellListDisplayTemp [counterA*3+counterB];
            //    cout<<"  arrayCellListDisplayTemp "<<counterA<<endl;
            //}
            
            int **duplicateRemoveMap = new int *[101];
            int **duplicateRemoveMap2 = new int *[101];
            
            for (int counter1 = 0; counter1 < 101; counter1++){
                duplicateRemoveMap [counter1] = new int [101];
                duplicateRemoveMap2 [counter1] = new int [101];
            }
            
            int sequentialStart = 0;
            int totalMap1 = 0;
            int totalMap2 = 0;
            int deleteMap = 0;
            
            for (int counter1 = 1; counter1 <= listPointNumberShot-1; counter1++){
                for (int counterY = 0; counterY < 101; counterY++){
                    for (int counterX = 0; counterX < 101; counterX++) duplicateRemoveMap [counterY][counterX] = 0;
                }
                
                sequentialStart = 0;
                totalMap1 = 0;
                
                for (int counter2 = 0; counter2 < cellListDisplayTempCount/4; counter2++){
                    if (arrayCellListDisplayTemp [counter2*4] == counter1 && sequentialStart == 0){
                        duplicateRemoveMap [arrayCellListDisplayTemp [counter2*4+2]][arrayCellListDisplayTemp [counter2*4+1]] = 1;
                        sequentialStart = 1;
                        totalMap1++;
                    }
                    else if (arrayCellListDisplayTemp [counter2*4] == counter1 && sequentialStart == 1){
                        duplicateRemoveMap [arrayCellListDisplayTemp [counter2*4+2]][arrayCellListDisplayTemp [counter2*4+1]] = 1;
                        totalMap1++;
                    }
                    else if (arrayCellListDisplayTemp [counter2*4] != counter1 && sequentialStart == 1){
                        break;
                    }
                }
                
                //for (int counterA = 0; counterA < 101; counterA++){
                //    for (int counterB = 0; counterB < 101; counterB++) cout<<" "<<duplicateRemoveMap [counterA][counterB];
                //    cout<<" duplicateRemoveMap "<<counterA<<endl;
                //}
                
                if (totalMap1 != 0){
                    for (int counter2 = counter1+1; counter2 <= listPointNumberShot; counter2++){
                        for (int counterY = 0; counterY < 101; counterY++){
                            for (int counterX = 0; counterX < 101; counterX++) duplicateRemoveMap2 [counterY][counterX] = 0;
                        }
                        
                        sequentialStart = 0;
                        totalMap2 = 0;
                        
                        for (int counter3 = 0; counter3 < cellListDisplayTempCount/4; counter3++){
                            if (arrayCellListDisplayTemp [counter3*4] == counter2 && sequentialStart == 0){
                                duplicateRemoveMap2 [arrayCellListDisplayTemp [counter3*4+2]][arrayCellListDisplayTemp [counter3*4+1]] = 1;
                                sequentialStart = 1;
                                totalMap2++;
                            }
                            else if (arrayCellListDisplayTemp [counter3*4] == counter2 && sequentialStart == 1){
                                duplicateRemoveMap2 [arrayCellListDisplayTemp [counter3*4+2]][arrayCellListDisplayTemp [counter3*4+1]] = 1;
                                totalMap2++;
                            }
                            else if (arrayCellListDisplayTemp [counter3*4] != counter2 && sequentialStart == 1){
                                break;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < 101; counterA++){
                        //    for (int counterB = 0; counterB < 101; counterB++) cout<<" "<<duplicateRemoveMap2 [counterA][counterB];
                        //    cout<<" duplicateRemoveMap2 "<<counterA<<endl;
                        //}
                        
                        deleteMap = 0;
                        
                        for (int counterY = 0; counterY < 101; counterY++){
                            for (int counterX = 0; counterX < 101; counterX++){
                                if (duplicateRemoveMap [counterY][counterX] != 0 && duplicateRemoveMap2 [counterY][counterX] != 0) deleteMap++;
                            }
                        }
                        
                        if (deleteMap/(double)totalMap2 > 0.95 && deleteMap/(double)totalMap1 > 0.95){
                            for (int counter3 = 0; counter3 < cellListDisplayTempCount/4; counter3++){
                                if (arrayCellListDisplayTemp [counter3*4] == counter2) arrayCellListDisplayTemp [counter3*4] = 0;
                            }
                        }
                    }
                }
            }
            
            for (int counter1 = 0; counter1 < 101; counter1++){
                delete [] duplicateRemoveMap [counter1];
                delete [] duplicateRemoveMap2 [counter1];
            }
            
            delete [] duplicateRemoveMap;
            delete [] duplicateRemoveMap2;
            
            int *arrayCellListDisplayTemp2 = new int [cellListDisplayTempCount+50];
            int cellListDisplayTempCount2 = 0;
            
            int sequentialNumber = 0;
            int sequentialPosition = 0;
            
            for (int counter1 = 0; counter1 < cellListDisplayTempCount/4; counter1++){
                if (arrayCellListDisplayTemp [counter1*3] != 0){
                    if (sequentialNumber != arrayCellListDisplayTemp [counter1*4]){
                        sequentialNumber = arrayCellListDisplayTemp [counter1*4];
                        sequentialPosition++;
                    }
                    
                    arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = sequentialPosition, cellListDisplayTempCount2++;
                    arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+1], cellListDisplayTempCount2++;
                    arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+2], cellListDisplayTempCount2++;
                    arrayCellListDisplayTemp2 [cellListDisplayTempCount2] = arrayCellListDisplayTemp [counter1*4+3], cellListDisplayTempCount2++;
                }
            }
            
            delete [] arrayCellListDisplayTemp;
            
            char *writingArray = new char [cellListDisplayTempCount2*2+20];
            
            unsigned long indexCount = 0;
            int readBit [3];
            int dataTemp = 0;
            
            for (int counter1 = 0; counter1 < cellListDisplayTempCount2/4; counter1++){
                dataTemp = arrayCellListDisplayTemp2 [counter1*4];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayCellListDisplayTemp2 [counter1*4+1];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayCellListDisplayTemp2 [counter1*4+2];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
                
                dataTemp = arrayCellListDisplayTemp2 [counter1*4+3];
                readBit [0] = dataTemp/256;
                dataTemp = dataTemp%256;
                readBit [1] = dataTemp;
                
                writingArray [indexCount] = (char)readBit [0], indexCount++;
                writingArray [indexCount] = (char)readBit [1], indexCount++;
            }
            
            for (int counter1 = 0; counter1 < 8; counter1++) writingArray [indexCount] = 0, indexCount++;
            
            ofstream outfile2 (mitosisPath.c_str(), ofstream::binary);
            outfile2.write ((char*) writingArray, indexCount);
            outfile2.close();
            
            delete [] writingArray;
            delete [] arrayCellListDisplayTemp2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToListWindow object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Data File"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off or Other Processes On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)toolParameterSet:(id)sender{
    if (trackingOn != 0){
        if (parameterSethWindowOperation == 0){
            parameterSethWindowOperation = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToParameterSet object:self];
        }
        
        if (parameterSethWindowOperation == 2) parameterSethWindowOperation = 3;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Tracking Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

@end
