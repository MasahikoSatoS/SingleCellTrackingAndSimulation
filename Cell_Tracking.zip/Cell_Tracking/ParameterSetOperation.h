//
//  ParameterSetOperation.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 2016-02-18.
//
//

#ifndef PARAMETERSETOPERATION_H
#define PARAMETERSETOPERATION_H
#import "Controller.h"
#endif

@interface ParameterSetOperation : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *tableViewParameter;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)clearList:(id)sender;
-(IBAction)reloadList:(id)sender;
-(IBAction)reloadArea:(id)sender;

@end
