//
// AddDelete.h
// Cell_Tracking
//
// Created by Masahiko Sato on 09/10/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef ADDDELETE_H
#define ADDDELETE_H
#import "Controller.h" 
#endif

@interface AddDelete : NSObject {
    id expandLine;
    id fileUpdate;
}

-(int)addLineageMain:(int)connectNoAdd;
-(int)delLineageMain:(int)connectNoDel :(int)processType :(int)delCellNo :(int)startPointSet;
-(int)insertLineageMain:(int)connectNoAdd;

@end
