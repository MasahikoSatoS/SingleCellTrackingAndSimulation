//
//  FolderCopy.h
//  Cell_Tracking
//
//  Created by Masahiko Sato on 10/3/16.
//
//

#ifndef FOLDERCOPY_H
#define FOLDERCOPY_H
#import "Controller.h" 
#endif

@interface FolderCopy : NSObject{
    id fileUpdate;
}

-(void)folderCopyMain;
-(void)folderDeleteMain;

@end
