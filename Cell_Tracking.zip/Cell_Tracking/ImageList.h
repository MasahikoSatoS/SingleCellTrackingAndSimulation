//
// ImageList.h
// Cell_Tracking
//
// Created by Masahiko Sato on 07/08/13.
// Copyright 2013 Masahiko Sato All rights reserved.
//

#ifndef IMAGELIST_H
#define IMAGELIST_H
#import "Controller.h" 
#endif

@interface ImageList : NSObject <NSTableViewDataSource> {
    int fluorescentColorTemp1; //Fluorescent color temp
    int fluorescentColorTemp2; //Fluorescent color temp
    int fluorescentColorTemp3; //Fluorescent color temp
    int fluorescentColorTemp4; //Fluorescent color temp
    int fluorescentColorTemp5; //Fluorescent color temp
    int fluorescentColorTemp6; //Fluorescent color temp
    int fluoColorCountTemp; //Fluorescent color temp count
    int fluorescentDisplayCount; //Fluorescent color temp display count
    int fluorescentDisplayMax; //Fluorescent color display max
    
    IBOutlet NSTextField *analysisSeriesDisplay;
    IBOutlet NSTextField *analysisIDDisplay;
    IBOutlet NSTextField *analysisIDChange;
    IBOutlet NSTextField *timeSetDisplay;
    IBOutlet NSTextField *analysisCurrent;
    IBOutlet NSTextField *analysisIDCurrent;
    IBOutlet NSTextField *channelDisplay2;
    IBOutlet NSTextField *channelDisplay3;
    IBOutlet NSTextField *channelDisplay4;
    IBOutlet NSTextField *channelDisplay5;
    IBOutlet NSTextField *channelDisplay6;
    IBOutlet NSTextField *channelDisplay7;
    IBOutlet NSTextField *channelDisplayCh2;
    IBOutlet NSTextField *channelDisplayCh3;
    IBOutlet NSTextField *channelDisplayCh4;
    IBOutlet NSTextField *channelDisplayCh5;
    IBOutlet NSTextField *channelDisplayCh6;
    IBOutlet NSTextField *channelDisplayCh7;
    IBOutlet NSTextField *fluoType;
    
    IBOutlet NSWindow *imageList;
    
    IBOutlet NSBrowser *imageListBrowser;
    IBOutlet NSTableView *timeViewList;
    
    NSWindowController *imageListWindController;
    
    NSTimer *listTimer;
    
    id fileUpdate;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)changeID:(id)sender;
-(IBAction)setData:(id)sender;
-(IBAction)fluorescentDisplay:(id)sender;
-(IBAction)closeWindow:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;

@end
