//
//  AppDelegate.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2022-12-30.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>

@end
