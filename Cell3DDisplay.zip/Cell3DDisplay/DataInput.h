//
//  DataInput.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-06.
//

#ifndef DATAINPUT_H
#define DATAINPUT_H
#import "Controller.h"
#endif

@interface DataInput : NSObject<NSTextFieldDelegate>{
    IBOutlet NSTextField *videoImageSizeDisplay;
    IBOutlet NSTextField *specificTimeDisplay;
}

-(id)init;
-(void)dealloc;

@end
