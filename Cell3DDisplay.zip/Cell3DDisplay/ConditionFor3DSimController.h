//
//  ConditionFor3DSimController.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-12.
//

#ifndef CONDITIONFOR3DCIMCONTROLLER_H
#define CONDITIONFOR3DCIMCONTROLLER_H
#import "Controller.h"
#endif

@interface ConditionFor3DSimController : NSObject{
    IBOutlet NSTextField *zLengthDisplay;
    
    IBOutlet NSWindow *conditionFor3DSimWindow;
    NSWindowController *conditionFor3DSimController;
    
    NSTimer *conditionFor3DSimTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;
-(IBAction)commentsStart:(id)sender;

@end
