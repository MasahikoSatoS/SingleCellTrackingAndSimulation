//
//  TableDisplay.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-04.
//

#ifndef TABLEDISPAY_H
#define TABLEDISPAY_H
#import "Controller.h"
#endif

@interface TableDisplay : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *tableViewList;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
