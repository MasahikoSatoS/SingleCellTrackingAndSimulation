//
//  DataExport.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-07-10.
//

#import "DataExport.h"

@implementation DataExport

-(IBAction)exportDataMain:(id)sender{
    if (mainProcessOn == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            
            string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            
            if ((int)directoryPath.find("_3DBackUp") != -1 || (int)directoryPath.find("CLIA_LiveCell")){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMessage object:self];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    exportStatus = 1;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    string entry;
                    string entry2;
                    
                    int totalRepeatPoint = 0;
                    int totalTimePoint = 0;
                    
                    string dataLoadPath;
                    string dataLoadPath2;
                    string timeExtract;
                    string timeExtract2;
                    
                    int fileDeleteCount2 = 0;
                    int fileDeleteCount3 = 0;
                    int fileCountMax = 0;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            if ((int)entry.find("_3DRepeatData") != -1 || (int)entry.find("09_Cell_Tracking_Analysis_Results") != -1){
                                totalRepeatPoint++;
                                
                                dataLoadPath = directoryPath+"/"+entry;
                                
                                dir2 = opendir(dataLoadPath.c_str());
                                
                                if (dir2 != NULL){
                                    fileDeleteCount2 = 0;
                                    
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if ((int)entry2.find("EnvList.Dat") != -1 || (int)entry2.find("EventType.Dat") != -1 || (int)entry2.find("Layer.Dat") != -1){
                                            fileDeleteCount2++;
                                            
                                            timeExtract = entry2.substr(0, 8);
                                            
                                            if (totalTimePoint < atoi(timeExtract.c_str())){
                                                totalTimePoint = atoi(timeExtract.c_str());
                                                timeExtract2 = timeExtract;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                    
                                    if (fileCountMax < fileDeleteCount2) fileCountMax = fileDeleteCount2;
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/3D_Results";
                    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    //==========Export file Header set==========
                    string extractString;
                    string path;
                    int maxEntryNo = 0;
                    
                    ofstream oin;
                    ofstream oin2;
                    ofstream oin3;
                    
                    dir = opendir(resultSavePath2.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("3D_Results") != -1){
                                extractString = entry.substr(entry.find("EL")+2, entry.find(".txt")-entry.find("EL")-2);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    path = resultSavePath2+"/3D_Results-EL"+to_string(maxEntryNo)+".txt";
                    
                    oin.open(path.c_str(), ios::out | ios::binary);
                    
                    int *arrayAscIIintData = new int [100];
                    int ascIIintDataCount = 0;
                    
                    oin.put(9);
                    
                    ascIIstring = "No cells";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin.put(9);
                    }
                    
                    ascIIstring = "BD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "MD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "CD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "CF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "OF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    //==========Export file Header set layer==========
                    maxEntryNo = 0;
                    
                    dir = opendir(resultSavePath2.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("3D_Results") != -1){
                                extractString = entry.substr(entry.find("LA")+2, entry.find(".txt")-entry.find("LA")-2);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    path = resultSavePath2+"/3D_Results-LA"+to_string(maxEntryNo)+".txt";
                    
                    oin2.open(path.c_str(), ios::out | ios::binary);
                    
                    oin2.put(9);
                    
                    ascIIstring = "No cells 10";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin2.put(9);
                    }
                    
                    ascIIstring = "No cells 11";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin2.put(9);
                    }
                    
                    ascIIstring = "No cells 12";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin2.put(9);
                    }
                    
                    ascIIstring = "No cells 13";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin2.put(9);
                    }
                    
                    ascIIstring = "BD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    
                    oin2.put(9);
                    
                    ascIIstring = "MD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    
                    oin2.put(9);
                    
                    ascIIstring = "CD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    
                    oin2.put(9);
                    
                    ascIIstring = "CF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    
                    oin2.put(9);
                    
                    ascIIstring = "OF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                    
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    oin2.put(9);
                    
                    oin2.put(13);
                    oin2.put(10);
                    
                    //==========Export file Header set Env==========
                    maxEntryNo = 0;
                    
                    dir = opendir(resultSavePath2.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("3D_Results") != -1){
                                extractString = entry.substr(entry.find("EN")+2, entry.find(".txt")-entry.find("EN")-2);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    path = resultSavePath2+"/3D_Results-EN"+to_string(maxEntryNo)+".txt";
                    
                    oin3.open(path.c_str(), ios::out | ios::binary);
                    
                    oin3.put(9);
                    
                    ascIIstring = "No cells S";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin3.put(9);
                    }
                    
                    ascIIstring = "No cells P";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin3.put(9);
                    }
                    
                    ascIIstring = "No cells K";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin3.put(9);
                    }
                    
                    ascIIstring = "No cells F";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin3.put(9);
                    }
                    
                    ascIIstring = "No cells FD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    
                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                        oin3.put(9);
                    }
                    
                    ascIIstring = "BD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    
                    ascIIstring = "MD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    
                    ascIIstring = "CD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    
                    ascIIstring = "CF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    
                    ascIIstring = "OF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                    
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    oin3.put(9);
                    
                    oin3.put(13);
                    oin3.put(10);
                    
                    //========Data writing======
                    ifstream fin;
                    string getString;
                    string stringR;
                    
                    double *cellEventList = new double [10000];
                    double *cellLayerList = new double [10000];
                    double *cellEnvList = new double [10000];
                    
                    int cellEventListCount = 0;
                    int cellLayerListCount = 0;
                    int cellEnvListCount = 0;
                    
                    int cellEventListLimit = 10000;
                    int cellLayerListLimit = 10000;
                    int cellEnvListLimit = 10000;
                    
                    double data1 = 0;
                    double data2 = 0;
                    double data3 = 0;
                    double data4 = 0;
                    double data5 = 0;
                    double data6 = 0;
                    double data7 = 0;
                    double data8 = 0;
                    double data9 = 0;
                    double data10 = 0;
                    double data11 = 0;
                    double data12 = 0;
                    
                    int findFlag = 0;
                    int seriesEntryTemp = 0;
                    
                    int numberOfBD = 0;
                    int numberOfMD = 0;
                    int numberOfCD = 0;
                    int numberOfCF = 0;
                    int numberOfOF = 0;
                    
                    int numberOfBD2 = 0;
                    int numberOfMD2 = 0;
                    int numberOfCD2 = 0;
                    int numberOfCF2 = 0;
                    int numberOfOF2 = 0;
                    
                    int numberOfBD3 = 0;
                    int numberOfMD3 = 0;
                    int numberOfCD3 = 0;
                    int numberOfCF3 = 0;
                    int numberOfOF3 = 0;
                    
                    int numberOfBD4 = 0;
                    int numberOfMD4 = 0;
                    int numberOfCD4 = 0;
                    int numberOfCF4 = 0;
                    int numberOfOF4 = 0;
                    
                    int numberOfBD5 = 0;
                    int numberOfMD5 = 0;
                    int numberOfCD5 = 0;
                    int numberOfCF5 = 0;
                    int numberOfOF5 = 0;
                    
                    double percentS = 0;
                    double percentP = 0;
                    double percentK = 0;
                    double percentF = 0;
                    
                    double fuseS = 0;
                    double fuseP = 0;
                    double fuseK = 0;
                    double fuseF = 0;
                    
                    int timeEnd = 0;
                    int shortestEndWithoutEvent = 0;
                    int longestEndWithoutEvent = 0;
                    
                    string *arrayFileDelete2 = new string [totalRepeatPoint+50];
                    fileDeleteCount2 = 0;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("_3DRepeatData") != -1 || (int)entry.find("09_Cell_Tracking_Analysis_Results") != -1){
                                arrayFileDelete2 [fileDeleteCount2] = directoryPath+"/"+entry, fileDeleteCount2++;
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete2 [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete2 [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    string *arrayFileDelete3 = new string [fileCountMax+50];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        dir = opendir(arrayFileDelete2 [counter1].c_str());
                        
                        if (dir != NULL){
                            fileDeleteCount3 = 0;
                            
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if ((int)entry.find("EnvList.Dat") != -1 || (int)entry.find("EventType.Dat") != -1 || (int)entry.find("Layer.Dat") != -1){
                                    arrayFileDelete3 [fileDeleteCount3] = arrayFileDelete2 [counter1]+"/"+entry, fileDeleteCount3++;
                                }
                            }
                            
                            closedir(dir);
                            
                            //-------Directory Sort------
                            NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount3; counter2++){
                                [unsortedArray2 addObject:@(arrayFileDelete3 [counter2].c_str())];
                            }
                            
                            [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter2 = 0; counter2 < [unsortedArray2 count]; counter2++){
                                arrayFileDelete3 [counter2] = [unsortedArray2 [counter2] UTF8String];
                            }
                            
                            //for (int counterA = 0; counterA < fileDeleteCount3; counterA++){
                            //    cout<<arrayFileDelete3 [counterA]<<" File"<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount3; counter2++){
                                if ((int)arrayFileDelete3 [counter2].find("EnvList.Dat") != -1){
                                    fin.open(arrayFileDelete3 [counter2].c_str(),ios::in);
                                    
                                    if (fin.is_open()){
                                        do{
                                            
                                            getline(fin, getString), data1 = atof(getString.c_str());
                                            getline(fin, getString), data2 = atof(getString.c_str());
                                            getline(fin, getString), data3 = atof(getString.c_str());
                                            getline(fin, getString), data4 = atof(getString.c_str());
                                            getline(fin, getString), data5 = atof(getString.c_str());
                                            getline(fin, getString), data6 = atof(getString.c_str());
                                            getline(fin, getString), data7 = atof(getString.c_str());
                                            getline(fin, getString), data8 = atof(getString.c_str());
                                            getline(fin, getString), data9 = atof(getString.c_str());
                                            getline(fin, getString), data10 = atof(getString.c_str());
                                            getline(fin, getString), data11 = atof(getString.c_str());
                                            
                                            if (data1 != -1 && data2 != -1 && data3 != -1){
                                                findFlag = 0;
                                                
                                                for (int counter3 = 0; counter3 < cellEnvListCount/11; counter3++){
                                                    if (data1 == cellEnvList [counter3*11] && data2 == cellEnvList [counter3*11+1] && data3 == cellEnvList [counter3*11+2]){
                                                        cellEnvList [counter3*11+3] = data4;
                                                        cellEnvList [counter3*11+4] = data5;
                                                        cellEnvList [counter3*11+5] = data6;
                                                        cellEnvList [counter3*11+6] = data7;
                                                        cellEnvList [counter3*11+7] = data8;
                                                        cellEnvList [counter3*11+8] = data9;
                                                        cellEnvList [counter3*11+9] = data10;
                                                        cellEnvList [counter3*11+10] = data11;
                                                        
                                                        findFlag = 1;
                                                    }
                                                }
                                                
                                                if (findFlag == 0){
                                                    if (cellEnvListCount+50 > cellEnvListLimit){
                                                        double *arrayUpDate = new double [cellEnvListCount+11];
                                                        
                                                        for (int counter3 = 0; counter3 < cellEnvListCount; counter3++) arrayUpDate [counter3] = cellEnvList [counter3];
                                                        
                                                        delete [] cellEnvList;
                                                        cellEnvList = new double [cellEnvListLimit+10000];
                                                        cellEnvListLimit = cellEnvListLimit+10000;
                                                        
                                                        for (int counter3 = 0; counter3 < cellEnvListCount; counter3++) cellEnvList [counter3] = arrayUpDate [counter3];
                                                        delete [] arrayUpDate;
                                                    }
                                                    
                                                    cellEnvList [cellEnvListCount] = data1, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data2, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data3, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data4, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data5, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data6, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data7, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data8, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data9, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data10, cellEnvListCount++;
                                                    cellEnvList [cellEnvListCount] = data11, cellEnvListCount++;
                                                }
                                            }
                                            
                                        } while (data1 != -1 && data2 != -1);
                                        
                                        fin.close();
                                    }
                                    
                                    //for (int counterA = 0; counterA < cellEnvListCount/11; counterA++){
                                    //    for (int counterB = 0; counterB < 11; counterB++) cout<<" "<<cellEnvList [counterA*11+counterB];
                                    //    cout<<" cellEnvList "<<counterA<<endl;
                                    //}
                                }
                                else if ((int)arrayFileDelete3 [counter2].find("EventType.Dat") != -1 && (int)arrayFileDelete3 [counter2].find(timeExtract2) != -1){
                                    fin.open(arrayFileDelete3 [counter2].c_str(),ios::in);
                                    
                                    if (fin.is_open()){
                                        do{
                                            
                                            getline(fin, getString), data1 = atof(getString.c_str());
                                            getline(fin, getString), data2 = atof(getString.c_str());
                                            getline(fin, getString), data3 = atof(getString.c_str());
                                            getline(fin, getString), data4 = atof(getString.c_str());
                                            getline(fin, getString), data5 = atof(getString.c_str());
                                            getline(fin, getString), data6 = atof(getString.c_str());
                                            getline(fin, getString), data7 = atof(getString.c_str());
                                            getline(fin, getString), data8 = atof(getString.c_str());
                                            getline(fin, getString), data9 = atof(getString.c_str());
                                            getline(fin, getString), data10 = atof(getString.c_str());
                                            getline(fin, getString), data11 = atof(getString.c_str());
                                            getline(fin, getString), data12 = atof(getString.c_str());
                                            
                                            //cout<<data2<<" "<<data3<<" "<<data4<<" "<<data5<<" "<<data6<<" "<<data7<<" "<<data8<<" "<<data9<<" "<<data10<<" Data"<<endl;
                                            
                                            if (data1 != -1 && data2 != -1 && data3 != -1){
                                                findFlag = 0;
                                                
                                                for (int counter3 = 0; counter3 < cellEventListCount/12; counter3++){
                                                    if (data1 == cellEventList [counter3*12] && data2 == cellEventList [counter3*12+1] && data3 == cellEventList [counter3*12+2]){
                                                        cellEventList [counter3*12+3] = data4;
                                                        cellEventList [counter3*12+4] = data5;
                                                        cellEventList [counter3*12+5] = data6;
                                                        cellEventList [counter3*12+6] = data7;
                                                        cellEventList [counter3*12+7] = data8;
                                                        cellEventList [counter3*12+8] = data9;
                                                        cellEventList [counter3*12+9] = data10;
                                                        cellEventList [counter3*12+10] = data11;
                                                        cellEventList [counter3*12+11] = data12;
                                                        
                                                        findFlag = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                if (findFlag == 0){
                                                    if (cellEventListCount+50 > cellEventListLimit){
                                                        double *arrayUpDate = new double [cellEventListCount+12];
                                                        
                                                        for (int counter3 = 0; counter3 < cellEventListCount; counter3++) arrayUpDate [counter3] = cellEventList [counter3];
                                                        
                                                        delete [] cellEventList;
                                                        cellEventList = new double [cellEventListLimit+10000];
                                                        cellEventListLimit = cellEventListLimit+10000;
                                                        
                                                        for (int counter3 = 0; counter3 < cellEventListCount; counter3++) cellEventList [counter3] = arrayUpDate [counter3];
                                                        delete [] arrayUpDate;
                                                    }
                                                    
                                                    cellEventList [cellEventListCount] = data1, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data2, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data3, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data4, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data5, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data6, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data7, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data8, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data9, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data10, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data11, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data12, cellEventListCount++;
                                                }
                                            }
                                            else{
                                                
                                                percentS = data9;
                                                percentP = data10;
                                                percentK = data11;
                                                percentF = data12;
                                                
                                                fuseS = data5;
                                                fuseP = data6;
                                                fuseK = data7;
                                                fuseF = data8;
                                            }
                                            
                                        } while (data1 != -1 && data2 != -1);
                                        
                                        fin.close();
                                    }
                                }
                                else if ((int)arrayFileDelete3 [counter2].find("Layer.Dat") != -1){
                                    fin.open(arrayFileDelete3 [counter2].c_str(),ios::in);
                                    
                                    if (fin.is_open()){
                                        do{
                                            
                                            getline(fin, getString), data1 = atof(getString.c_str());
                                            getline(fin, getString), data2 = atof(getString.c_str());
                                            getline(fin, getString), data3 = atof(getString.c_str());
                                            getline(fin, getString), data4 = atof(getString.c_str());
                                            getline(fin, getString), data5 = atof(getString.c_str());
                                            getline(fin, getString), data6 = atof(getString.c_str());
                                            getline(fin, getString), data7 = atof(getString.c_str());
                                            getline(fin, getString), data8 = atof(getString.c_str());
                                            getline(fin, getString), data9 = atof(getString.c_str());
                                            getline(fin, getString), data10 = atof(getString.c_str());
                                            getline(fin, getString), data11 = atof(getString.c_str());
                                            
                                            if (data1 != -1 && data2 != -1 && data3 != -1){
                                                findFlag = 0;
                                                
                                                for (int counter3 = 0; counter3 < cellLayerListCount/11; counter3++){
                                                    if (data1 == cellLayerList [counter3*11] && data2 == cellLayerList [counter3*11+1] && data3 == cellLayerList [counter3*11+2]){
                                                        cellLayerList [counter3*11+3] = data4;
                                                        cellLayerList [counter3*11+4] = data5;
                                                        cellLayerList [counter3*11+5] = data6;
                                                        cellLayerList [counter3*11+6] = data7;
                                                        cellLayerList [counter3*11+7] = data8;
                                                        cellLayerList [counter3*11+8] = data9;
                                                        cellLayerList [counter3*11+9] = data10;
                                                        cellLayerList [counter3*11+10] = data11;
                                                        
                                                        findFlag = 1;
                                                    }
                                                }
                                                
                                                if (findFlag == 0){
                                                    if (cellLayerListCount+50 > cellLayerListLimit){
                                                        double *arrayUpDate = new double [cellLayerListCount+11];
                                                        
                                                        for (int counter3 = 0; counter3 < cellLayerListCount; counter3++) arrayUpDate [counter3] = cellLayerList [counter3];
                                                        
                                                        delete [] cellLayerList;
                                                        cellLayerList = new double [cellLayerListLimit+10000];
                                                        cellLayerListLimit = cellLayerListLimit+10000;
                                                        
                                                        for (int counter3 = 0; counter3 < cellLayerListCount; counter3++) cellLayerList [counter3] = arrayUpDate [counter3];
                                                        delete [] arrayUpDate;
                                                    }
                                                    
                                                    cellLayerList [cellLayerListCount] = data1, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data2, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data3, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data4, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data5, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data6, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data7, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data8, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data9, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data10, cellLayerListCount++;
                                                    cellLayerList [cellLayerListCount] = data11, cellLayerListCount++;
                                                }
                                            }
                                            
                                        } while (data1 != -1 && data2 != -1);
                                        
                                        fin.close();
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellEventListCount/12; counterA++){
                            //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<cellEventList [counterA*12+counterB];
                            //    cout<<" cellEventList "<<counterA<<endl;
                            //}
                            
                            //=========Cell Event export=========
                            int *seriesEntryCount = new int [15];
                            
                            for (int counter3 = 0; counter3 < 15; counter3++){
                                seriesEntryCount [counter3] = 0;
                            }
                            
                            for (int counter3 = 0; counter3 < cellEventListCount/12; counter3++){
                                seriesEntryCount [(int)cellEventList [counter3*12]] = 1;
                            }
                            
                            seriesEntryTemp = 0;
                            
                            for (int counter3 = 1; counter3 < 10; counter3++){
                                if (seriesEntryCount [counter3] != 0){
                                    seriesEntryTemp++;
                                    
                                    seriesEntryCount [counter3] = seriesEntryTemp;
                                }
                            }
                            
                            int *cellNumber1 = new int [totalTimePoint+10];
                            int *cellNumberTBProg = new int [totalTimePoint+10];
                            
                            for (int counter3 = 1; counter3 < 10; counter3++){
                                longestEndWithoutEvent = 100000;
                                
                                if (seriesEntryCount [counter3] != 0){
                                    numberOfBD = 0;
                                    numberOfMD = 0;
                                    numberOfCD = 0;
                                    numberOfCF = 0;
                                    numberOfOF = 0;
                                    
                                    for (int counter4 = 0; counter4 < totalTimePoint+10; counter4++){
                                        cellNumber1 [counter4] = 0;
                                        cellNumberTBProg [counter4] = 0;
                                    }
                                    
                                    for (int counter4 = 0; counter4 < cellEventListCount/12; counter4++){
                                        if (seriesEntryCount [counter3] == cellEventList [counter4*12] && cellEventList [counter4*12+5] <= totalTimePoint){
                                            
                                            if (cellEventList [counter4*12+6] > totalTimePoint) timeEnd = totalTimePoint;
                                            else timeEnd = (int)cellEventList [counter4*12+6];
                                            
                                            
                                            for (int counter5 = (int)cellEventList [counter4*12+5]; counter5 <= timeEnd; counter5++){
                                                cellNumber1 [counter5]++;
                                            }
                                            
                                            if (cellEventList [counter4*12+10] == 1 || cellEventList [counter4*12+10] == 3){
                                                for (int counter5 = (int)cellEventList [counter4*12+5]; counter5 <= timeEnd; counter5++){
                                                    cellNumberTBProg [counter5]++;
                                                }
                                            }
                                            
                                            if (cellEventList [counter4*12+4] == 32) numberOfBD++;
                                            if (cellEventList [counter4*12+4] == 42 || cellEventList [counter4*12+4] == 52) numberOfMD++;
                                            if (cellEventList [counter4*12+4] == 7) numberOfCD++;
                                            if (cellEventList [counter4*12+4] == 91) numberOfCF++;
                                            if (cellEventList [counter4*12+4] == 8) numberOfOF++;
                                            
                                            if ((cellEventList [counter4*12+3] == 31 || cellEventList [counter4*12+3] == 41 || cellEventList [counter4*12+3] == 51) && (cellEventList [counter4*12+4] == 2 || cellEventList [counter4*12+4] == 7)){
                                                if (longestEndWithoutEvent > cellEventList [counter4*12+6] && cellEventList [counter4*12+6] != 0){
                                                    longestEndWithoutEvent = (int)cellEventList [counter4*12+6];
                                                }
                                            }
                                        }
                                    }
                                    
                                    stringR = to_string(counter1+1);
                                    
                                    if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                                    else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                                    else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                                    else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                                    
                                    ascIIstring = "R "+stringR;
                                    
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                        ascIIstring = to_string(cellNumber1 [counter5]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                    }
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(numberOfBD);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(numberOfMD);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(numberOfCD);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(numberOfCF);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(numberOfOF);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(percentS);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(percentP);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(percentK);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(percentF);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(fuseS);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(fuseP);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(fuseK);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = to_string(fuseF);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = "ShortestProm "+to_string(shortestEndWithoutEvent);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    ascIIstring = "ShortestSup "+to_string(longestEndWithoutEvent);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                    
                                    stringR = to_string(counter1+1);
                                    
                                    if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                                    else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                                    else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                                    else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                                    
                                    ascIIstring = "T "+stringR;
                                    
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                        ascIIstring = to_string(cellNumberTBProg [counter5]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                    }
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                            }
                            
                            delete [] cellNumber1;
                            delete [] cellNumberTBProg;
                            
                            //==========LayerData export=========
                            cellNumber1 = new int [totalTimePoint+10];
                            int *cellNumber2 = new int [totalTimePoint+10];
                            int *cellNumber3 = new int [totalTimePoint+10];
                            int *cellNumber4 = new int [totalTimePoint+10];
                            
                            numberOfBD = 0;
                            numberOfMD = 0;
                            numberOfCD = 0;
                            numberOfCF = 0;
                            numberOfOF = 0;
                            
                            numberOfBD2 = 0;
                            numberOfMD2 = 0;
                            numberOfCD2 = 0;
                            numberOfCF2 = 0;
                            numberOfOF2 = 0;
                            
                            numberOfBD3 = 0;
                            numberOfMD3 = 0;
                            numberOfCD3 = 0;
                            numberOfCF3 = 0;
                            numberOfOF3 = 0;
                            
                            numberOfBD4 = 0;
                            numberOfMD4 = 0;
                            numberOfCD4 = 0;
                            numberOfCF4 = 0;
                            numberOfOF4 = 0;
                            
                            for (int counter4 = 0; counter4 < totalTimePoint+10; counter4++){
                                cellNumber1 [counter4] = 0;
                                cellNumber2 [counter4] = 0;
                                cellNumber3 [counter4] = 0;
                                cellNumber4 [counter4] = 0;
                            }
                            
                            for (int counter4 = 0; counter4 < cellLayerListCount/11; counter4++){
                                if (cellLayerList [counter4*11+7] == 10){
                                    if (cellLayerList [counter4*11+5] <= totalTimePoint){
                                        if (cellLayerList [counter4*11+6] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellLayerList [counter4*11+6];
                                        
                                        for (int counter5 = (int)cellLayerList [counter4*11+5]; counter5 <= timeEnd; counter5++){
                                            cellNumber1 [counter5]++;
                                        }
                                        
                                        if (cellLayerList [counter4*11+4] == 32) numberOfBD++;
                                        if (cellLayerList [counter4*11+4] == 42 || cellLayerList [counter4*11+4] == 52) numberOfMD++;
                                        if (cellLayerList [counter4*11+4] == 7) numberOfCD++;
                                        if (cellLayerList [counter4*11+4] == 91) numberOfCF++;
                                        if (cellLayerList [counter4*11+4] == 8) numberOfOF++;
                                    }
                                }
                                else if (cellLayerList [counter4*11+7] == 11){
                                    if (cellLayerList [counter4*11+5] <= totalTimePoint){
                                        
                                        if (cellLayerList [counter4*11+6] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellLayerList [counter4*11+6];
                                        
                                        for (int counter5 = (int)cellLayerList [counter4*11+5]; counter5 <= timeEnd; counter5++){
                                            cellNumber2 [counter5]++;
                                        }
                                        
                                        if (cellLayerList [counter4*11+4] == 32) numberOfBD2++;
                                        if (cellLayerList [counter4*11+4] == 42 || cellLayerList [counter4*11+4] == 52) numberOfMD2++;
                                        if (cellLayerList [counter4*11+4] == 7) numberOfCD2++;
                                        if (cellLayerList [counter4*11+4] == 91) numberOfCF2++;
                                        if (cellLayerList [counter4*11+4] == 8) numberOfOF2++;
                                    }
                                }
                                else if (cellLayerList [counter4*11+7] == 12){
                                    if (cellLayerList [counter4*11+5] <= totalTimePoint){
                                        
                                        if (cellLayerList [counter4*11+6] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellLayerList [counter4*11+6];
                                        
                                        for (int counter5 = (int)cellLayerList [counter4*11+5]; counter5 <= timeEnd; counter5++){
                                            cellNumber3 [counter5]++;
                                        }
                                        
                                        if (cellLayerList [counter4*11+4] == 32) numberOfBD3++;
                                        if (cellLayerList [counter4*11+4] == 42 || cellLayerList [counter4*11+4] == 52) numberOfMD3++;
                                        if (cellLayerList [counter4*11+4] == 7) numberOfCD3++;
                                        if (cellLayerList [counter4*11+4] == 91) numberOfCF3++;
                                        if (cellLayerList [counter4*11+4] == 8) numberOfOF3++;
                                    }
                                }
                                else if (cellLayerList [counter4*11+7] == 13){
                                    if (cellLayerList [counter4*11+5] <= totalTimePoint){
                                        
                                        if (cellLayerList [counter4*11+6] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellLayerList [counter4*11+6];
                                        
                                        for (int counter5 = (int)cellLayerList [counter4*11+5]; counter5 <= timeEnd; counter5++){
                                            cellNumber4 [counter5]++;
                                        }
                                        
                                        if (cellLayerList [counter4*11+4] == 32) numberOfBD4++;
                                        if (cellLayerList [counter4*11+4] == 42 || cellLayerList [counter4*11+4] == 52) numberOfMD4++;
                                        if (cellLayerList [counter4*11+4] == 7) numberOfCD4++;
                                        if (cellLayerList [counter4*11+4] == 91) numberOfCF4++;
                                        if (cellLayerList [counter4*11+4] == 8) numberOfOF4++;
                                    }
                                }
                            }
                            
                            stringR = to_string(counter1+1);
                            
                            if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                            else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                            else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                            else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                            
                            ascIIstring = "R "+stringR;
                            
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber1 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin2.put((char)arrayAscIIintData [counter6]);
                                
                                oin2.put(9);
                            }
                            
                            oin2.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber2 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin2.put((char)arrayAscIIintData [counter6]);
                                
                                oin2.put(9);
                            }
                            
                            oin2.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber3 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin2.put((char)arrayAscIIintData [counter6]);
                                
                                oin2.put(9);
                            }
                            
                            oin2.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber4 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin2.put((char)arrayAscIIintData [counter6]);
                                
                                oin2.put(9);
                            }
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfBD);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfBD2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfBD3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfBD4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfMD);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfMD2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfMD3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfMD4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCD);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCD2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCD3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCD4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCF2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCF3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfCF4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfOF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfOF2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfOF3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(numberOfOF4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            oin2.put(9);
                            
                            ascIIstring = to_string(percentS);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(percentP);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(percentK);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(percentF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(fuseS);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(fuseP);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(fuseK);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            ascIIstring = to_string(fuseF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin2.put((char)arrayAscIIintData [counter4]);
                            
                            oin2.put(9);
                            
                            oin2.put(13);
                            oin2.put(10);
                            
                            delete [] cellNumber1;
                            delete [] cellNumber2;
                            delete [] cellNumber3;
                            delete [] cellNumber4;
                            
                            //==========EnvData export=========
                            cellNumber1 = new int [totalTimePoint+10];
                            cellNumber2 = new int [totalTimePoint+10];
                            cellNumber3 = new int [totalTimePoint+10];
                            cellNumber4 = new int [totalTimePoint+10];
                            int *cellNumber5 = new int [totalTimePoint+10];
                            
                            numberOfBD = 0;
                            numberOfMD = 0;
                            numberOfCD = 0;
                            numberOfCF = 0;
                            numberOfOF = 0;
                            
                            numberOfBD2 = 0;
                            numberOfMD2 = 0;
                            numberOfCD2 = 0;
                            numberOfCF2 = 0;
                            numberOfOF2 = 0;
                            
                            numberOfBD3 = 0;
                            numberOfMD3 = 0;
                            numberOfCD3 = 0;
                            numberOfCF3 = 0;
                            numberOfOF3 = 0;
                            
                            numberOfBD4 = 0;
                            numberOfMD4 = 0;
                            numberOfCD4 = 0;
                            numberOfCF4 = 0;
                            numberOfOF4 = 0;
                            
                            numberOfBD5 = 0;
                            numberOfMD5 = 0;
                            numberOfCD5 = 0;
                            numberOfCF5 = 0;
                            numberOfOF5 = 0;
                            
                            for (int counter4 = 0; counter4 < totalTimePoint+10; counter4++){
                                cellNumber1 [counter4] = 0;
                                cellNumber2 [counter4] = 0;
                                cellNumber3 [counter4] = 0;
                                cellNumber4 [counter4] = 0;
                                cellNumber5 [counter4] = 0;
                            }
                            
                            for (int counter4 = 0; counter4 < cellEnvListCount/11; counter4++){
                                if (cellEnvList [counter4*11+10] == 1){
                                    if (cellEnvList [counter4*11+4] <= totalTimePoint){
                                        if (cellEnvList [counter4*11+5] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellEnvList [counter4*11+5];
                                        
                                        for (int counter5 = (int)cellEnvList [counter4*11+4]; counter5 <= timeEnd; counter5++){
                                            cellNumber1 [counter5]++;
                                        }
                                        
                                        if (cellEnvList [counter4*11+3] == 32) numberOfBD++;
                                        if (cellEnvList [counter4*11+3] == 42 || cellEnvList [counter4*11+3] == 52) numberOfMD++;
                                        if (cellEnvList [counter4*11+3] == 7) numberOfCD++;
                                        if (cellEnvList [counter4*11+3] == 91) numberOfCF++;
                                        if (cellEnvList [counter4*11+3] == 8) numberOfOF++;
                                    }
                                }
                                else if (cellEnvList [counter4*11+10] == 2){
                                    if (cellEnvList [counter4*11+4] <= totalTimePoint){
                                        if (cellEnvList [counter4*11+5] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellEnvList [counter4*11+5];
                                        
                                        for (int counter5 = (int)cellEnvList [counter4*11+4]; counter5 <= timeEnd; counter5++){
                                            cellNumber2 [counter5]++;
                                        }
                                        
                                        if (cellEnvList [counter4*11+3] == 32) numberOfBD2++;
                                        if (cellEnvList [counter4*11+3] == 42 || cellEnvList [counter4*11+3] == 52) numberOfMD2++;
                                        if (cellEnvList [counter4*11+3] == 7) numberOfCD2++;
                                        if (cellEnvList [counter4*11+3] == 91) numberOfCF2++;
                                        if (cellEnvList [counter4*11+3] == 8) numberOfOF2++;
                                    }
                                }
                                else if (cellEnvList [counter4*11+10] == 3){
                                    if (cellEnvList [counter4*11+4] <= totalTimePoint){
                                        if (cellEnvList [counter4*11+5] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellEnvList [counter4*11+5];
                                        
                                        for (int counter5 = (int)cellEnvList [counter4*11+4]; counter5 <= timeEnd; counter5++){
                                            cellNumber3 [counter5]++;
                                        }
                                        
                                        if (cellEnvList [counter4*11+3] == 32) numberOfBD3++;
                                        if (cellEnvList [counter4*11+3] == 42 || cellEnvList [counter4*11+3] == 52) numberOfMD3++;
                                        if (cellEnvList [counter4*11+3] == 7) numberOfCD3++;
                                        if (cellEnvList [counter4*11+3] == 91) numberOfCF3++;
                                        if (cellEnvList [counter4*11+3] == 8) numberOfOF3++;
                                    }
                                }
                                else if (cellEnvList [counter4*11+10] == 4){
                                    if (cellEnvList [counter4*11+4] <= totalTimePoint){
                                        if (cellEnvList [counter4*11+5] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellEnvList [counter4*11+5];
                                        
                                        for (int counter5 = (int)cellEnvList [counter4*11+4]; counter5 <= timeEnd; counter5++){
                                            cellNumber4 [counter5]++;
                                        }
                                        
                                        if (cellEnvList [counter4*11+3] == 32) numberOfBD4++;
                                        if (cellEnvList [counter4*11+3] == 42 || cellEnvList [counter4*11+3] == 52) numberOfMD4++;
                                        if (cellEnvList [counter4*11+3] == 7) numberOfCD4++;
                                        if (cellEnvList [counter4*11+3] == 91) numberOfCF4++;
                                        if (cellEnvList [counter4*11+3] == 8) numberOfOF4++;
                                    }
                                }
                                else if (cellEnvList [counter4*11+10] == 5){
                                    if (cellEnvList [counter4*11+4] <= totalTimePoint){
                                        if (cellEnvList [counter4*11+5] > totalTimePoint) timeEnd = totalTimePoint;
                                        else timeEnd = (int)cellEnvList [counter4*11+5];
                                        
                                        for (int counter5 = (int)cellEnvList [counter4*11+4]; counter5 <= timeEnd; counter5++){
                                            cellNumber5 [counter5]++;
                                        }
                                        
                                        if (cellEnvList [counter4*11+3] == 32) numberOfBD5++;
                                        if (cellEnvList [counter4*11+3] == 42 || cellEnvList [counter4*11+3] == 52) numberOfMD5++;
                                        if (cellEnvList [counter4*11+3] == 7) numberOfCD5++;
                                        if (cellEnvList [counter4*11+3] == 91) numberOfCF5++;
                                        if (cellEnvList [counter4*11+3] == 8) numberOfOF5++;
                                    }
                                }
                            }
                            
                            stringR = to_string(counter1+1);
                            
                            if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                            else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                            else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                            else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                            
                            ascIIstring = "R "+stringR;
                            
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber1 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin3.put((char)arrayAscIIintData [counter6]);
                                
                                oin3.put(9);
                            }
                            
                            oin3.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber2 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin3.put((char)arrayAscIIintData [counter6]);
                                
                                oin3.put(9);
                            }
                            
                            oin3.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber3 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin3.put((char)arrayAscIIintData [counter6]);
                                
                                oin3.put(9);
                            }
                            
                            oin3.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber4 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin3.put((char)arrayAscIIintData [counter6]);
                                
                                oin3.put(9);
                            }
                            
                            oin3.put(9);
                            
                            for (int counter5 = 1; counter5 <= totalTimePoint; counter5++){
                                ascIIstring = to_string(cellNumber5 [counter5]);
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin3.put((char)arrayAscIIintData [counter6]);
                                
                                oin3.put(9);
                            }
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfBD);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfBD2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfBD3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfBD4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfBD5);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfMD);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfMD2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfMD3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfMD4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfMD5);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCD);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCD2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCD3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCD4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCD5);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCF2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCF3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCF4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfCF5);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfOF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfOF2);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfOF3);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfOF4);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(numberOfOF5);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            oin3.put(9);
                            
                            ascIIstring = to_string(percentS);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(percentP);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(percentK);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(percentF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(fuseS);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(fuseP);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(fuseK);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            ascIIstring = to_string(fuseF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin3.put((char)arrayAscIIintData [counter4]);
                            
                            oin3.put(9);
                            
                            oin3.put(13);
                            oin3.put(10);
                            
                            delete [] cellNumber1;
                            delete [] cellNumber2;
                            delete [] cellNumber3;
                            delete [] cellNumber4;
                            delete [] cellNumber5;
                            
                            delete [] seriesEntryCount;
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    delete [] arrayFileDelete3;
                    delete [] arrayAscIIintData;
                    
                    delete [] cellEventList;
                    delete [] cellLayerList;
                    delete [] cellEnvList;
                    
                    oin.close();
                    oin2.close();
                    oin3.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    exportStatus = 2;
                });
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"ID Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            
            //Series
            //Ling
            //Cell
            //Start time
            //End time
            //Start Event
            //End event
            //Parent
            //Fusion Ling
            //Fusion cell
            //Fluo
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Main Progress ON"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)exportHeat:(id)sender{
    if (mainProcessOn == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            
            string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            
            if ((int)directoryPath.find("_3DBackUp") != -1 || (int)directoryPath.find("CLIA_LiveCell")){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMessage object:self];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    exportStatus = 1;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    string entry;
                    string entry2;
                    string timeExtract;
                    
                    int totalRepeatPoint = 0;
                    
                    string dataLoadPath;
                    string dataLoadPath2;
                    string timeExtract2;
                    
                    int fileDeleteCount2 = 0;
                    int fileDeleteCount3 = 0;
                    int fileCountMax = 0;
                    int totalTimePoint = 0;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (entry != "_3DRepeatData" || (int)entry.find("09_Cell_Tracking_Analysis_Results") != -1)){
                                totalRepeatPoint++;
                                
                                dataLoadPath = directoryPath+"/"+entry;
                                
                                dir2 = opendir(dataLoadPath.c_str());
                                
                                if (dir2 != NULL){
                                    fileDeleteCount2 = 0;
                                    
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if ((int)entry2.find("EventType.Dat") != -1){
                                            fileDeleteCount2++;
                                            
                                            timeExtract = entry2.substr(0, 8);
                                            
                                            if (totalTimePoint < atoi(timeExtract.c_str())){
                                                totalTimePoint = atoi(timeExtract.c_str());
                                                timeExtract2 = timeExtract;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                    
                                    if (fileCountMax < fileDeleteCount2) fileCountMax = fileDeleteCount2;
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/3D_Results";
                    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    //==========Export file Header set==========
                    string extractString;
                    string path;
                    int maxEntryNo = 0;
                    
                    ofstream oin;
                    
                    dir = opendir(resultSavePath2.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("3D_Results") != -1){
                                extractString = entry.substr(entry.find("FF")+2, entry.find(".txt")-entry.find("FF")-2);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    path = resultSavePath2+"/3D_Results-FF"+to_string(maxEntryNo)+".txt";
                    
                    oin.open(path.c_str(), ios::out | ios::binary);
                    
                    int *arrayAscIIintData = new int [100];
                    int ascIIintDataCount = 0;
                    
                    //========Data writing======
                    ifstream fin;
                    string getString;
                    string stringR;
                    
                    double *cellEventList = new double [10000];
                    double *cellEventList2 = new double [10000];
                    
                    int cellEventListCount = 0;
                    int cellEventListCount2 = 0;
                    int cellEventListLimit = 10000;
                    
                    double data1 = 0;
                    double data2 = 0;
                    double data3 = 0;
                    double data4 = 0;
                    double data5 = 0;
                    double data6 = 0;
                    double data7 = 0;
                    double data8 = 0;
                    double data9 = 0;
                    double data10 = 0;
                    double data11 = 0;
                    double data12 = 0;
                    
                    int seriesEntry = 0;
                    int lineageEntry = 0;
                    int cellEntry = 0;
                    
                    int terminationFlag = 0;
                    int terminationFlag2 = 0;
                    int terminationFlag3 = 0;
                    int findFlag1 = 0;
                    int findFlag2 = 0;
                    int findFlag3 = 0;
                    
                    int lowestCellNo = 0;
                    int lowestCellNoPosition = 0;
                    int seriesTempCount = 0;
                    int lingTempCount = 0;
                    int cellTempCount = 0;
                    int entryListCount = 0;
                    
                    double percentS = 0;
                    double percentP = 0;
                    double percentK = 0;
                    double percentF = 0;
                    
                    double fuseS = 0;
                    double fuseP = 0;
                    double fuseK = 0;
                    double fuseF = 0;
                    
                    string *arrayFileDelete2 = new string [totalRepeatPoint+50];
                    fileDeleteCount2 = 0;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            if ((int)entry.find ("_3DRepeatData") != -1 ||  (int)entry.find("09_Cell_Tracking_Analysis_Results") != -1){
                                arrayFileDelete2 [fileDeleteCount2] = directoryPath+"/"+entry, fileDeleteCount2++;
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete2 [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete2 [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    //for (int counterA = 0; counterA < fileDeleteCount2; counterA++){
                    //   cout<<arrayFileDelete2 [counterA]<<" File"<<endl;
                    //}
                    
                    string *arrayFileDelete3 = new string [fileCountMax+50];
                    
                    double *entryList = new double [10];
                    
                    int firstTimeFlag = 0;
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        dir = opendir(arrayFileDelete2 [counter1].c_str());
                        
                        if (dir != NULL){
                            fileDeleteCount3 = 0;
                            
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if ((int)entry.find("EventType.Dat") != -1 ){
                                    arrayFileDelete3 [fileDeleteCount3] = arrayFileDelete2 [counter1]+"/"+entry, fileDeleteCount3++;
                                }
                            }
                            
                            closedir(dir);
                            
                            //-------Directory Sort------
                            NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount3; counter2++){
                                [unsortedArray2 addObject:@(arrayFileDelete3 [counter2].c_str())];
                            }
                            
                            [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter2 = 0; counter2 < [unsortedArray2 count]; counter2++){
                                arrayFileDelete3 [counter2] = [unsortedArray2 [counter2] UTF8String];
                            }
                            
                            //for (int counterA = 0; counterA < fileDeleteCount3; counterA++){
                            //    cout<<arrayFileDelete3 [counterA]<<" File"<<endl;
                            //}
                            
                            double *seriesTemp = new double [10];
                            double *lingTemp = new double [10];
                            double *cellTemp = new double [10];
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount3; counter2++){
                                cellEventListCount = 0;
                                
                                if ((int)arrayFileDelete3 [counter2].find("EventType.Dat") != -1 && (int)arrayFileDelete3 [counter2].find(timeExtract2) != -1){
                                    fin.open(arrayFileDelete3 [counter2].c_str(),ios::in);
                                    
                                    if (fin.is_open()){
                                        do{
                                            
                                            getline(fin, getString), data1 = atof(getString.c_str());
                                            getline(fin, getString), data2 = atof(getString.c_str());
                                            getline(fin, getString), data3 = atof(getString.c_str());
                                            getline(fin, getString), data4 = atof(getString.c_str());
                                            getline(fin, getString), data5 = atof(getString.c_str());
                                            getline(fin, getString), data6 = atof(getString.c_str());
                                            getline(fin, getString), data7 = atof(getString.c_str());
                                            getline(fin, getString), data8 = atof(getString.c_str());
                                            getline(fin, getString), data9 = atof(getString.c_str());
                                            getline(fin, getString), data10 = atof(getString.c_str());
                                            getline(fin, getString), data11 = atof(getString.c_str());
                                            getline(fin, getString), data12 = atof(getString.c_str());
                                            
                                            if (data1 != -1 && data2 != -1 && data3 != -1){
                                                if (cellEventListCount+50 > cellEventListLimit){
                                                    double *arrayUpDate = new double [cellEventListCount+12];
                                                    
                                                    for (int counter3 = 0; counter3 < cellEventListCount; counter3++) arrayUpDate [counter3] = cellEventList [counter3];
                                                    
                                                    delete [] cellEventList;
                                                    cellEventList = new double [cellEventListLimit+10000];
                                                    cellEventListLimit = cellEventListLimit+10000;
                                                    
                                                    for (int counter3 = 0; counter3 < cellEventListCount; counter3++) cellEventList [counter3] = arrayUpDate [counter3];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                cellEventList [cellEventListCount] = data1, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data2, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data3, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data4, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data5, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data6, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data7, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data8, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data9, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data10, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data11, cellEventListCount++;
                                                cellEventList [cellEventListCount] = data12, cellEventListCount++;
                                                cellEventList [cellEventListCount] = 0, cellEventListCount++;
                                            }
                                            else{
                                                
                                                percentS = data8;
                                                percentP = data9;
                                                percentK = data10;
                                                percentF = data11;
                                                
                                                fuseS = data4;
                                                fuseP = data5;
                                                fuseK = data6;
                                                fuseF = data7;
                                            }
                                            
                                        } while (data1 != -1 && data2 != -1);
                                        
                                        //for (int counterA = 0; counterA < cellEventListCount/13; counterA++){
                                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<cellEventList [counterA*13+counterB];
                                        //    cout<<" cellEventList "<<counterA<<endl;
                                        // }
                                        
                                        fin.close();
                                        
                                        if (firstTimeFlag == 0){
                                            delete [] cellEventList2;
                                            cellEventList2 = new double [cellEventListCount+20];
                                            
                                            delete [] seriesTemp;
                                            seriesTemp = new double [cellEventListCount+20];
                                            
                                            delete [] lingTemp;
                                            lingTemp = new double [cellEventListCount+20];
                                            
                                            delete [] cellTemp;
                                            cellTemp = new double [cellEventListCount+20];
                                            
                                            seriesEntry = 0;
                                            lineageEntry = 0;
                                            cellEntry = 0;
                                            
                                            do{
                                                
                                                terminationFlag = 0;
                                                findFlag1 = 0;
                                                seriesTempCount = 0;
                                                
                                                seriesEntry++;
                                                
                                                for (int counter3 = 0; counter3 < cellEventListCount/13; counter3++){
                                                    if (cellEventList [counter3*13+12] != 1 && seriesEntry == cellEventList [counter3*13]){
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+1], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+2], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+3], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+4], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+5], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+6], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+7], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+8], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+9], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+10], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+11], seriesTempCount++;
                                                        seriesTemp [seriesTempCount] = cellEventList [counter3*13+12], seriesTempCount++;
                                                        
                                                        cellEventList [counter3*13+12] = 1;
                                                    }
                                                }
                                                
                                                for (int counter3 = 0; counter3 < cellEventListCount/13; counter3++){
                                                    if (cellEventList [counter3*13+12] == 0) findFlag1 = 1;
                                                }
                                                
                                                if (findFlag1 == 0) terminationFlag = 1;
                                                
                                                if (seriesTempCount != 0){
                                                    do{
                                                        
                                                        terminationFlag2 = 0;
                                                        findFlag2 = 0;
                                                        lingTempCount = 0;
                                                        
                                                        lineageEntry++;
                                                        
                                                        for (int counter3 = 0; counter3 < seriesTempCount/13; counter3++){
                                                            if (seriesTemp [counter3*13+12] != 1 && seriesTemp [counter3*13+1] == lineageEntry){
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+1], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+2], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+3], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+4], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+5], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+6], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+7], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+8], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+9], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+10], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+11], lingTempCount++;
                                                                lingTemp [lingTempCount] = seriesTemp [counter3*13+12], lingTempCount++;
                                                                
                                                                seriesTemp [counter3*13+12] = 1;
                                                            }
                                                        }
                                                        
                                                        for (int counter3 = 0; counter3 < seriesTempCount/13; counter3++){
                                                            if (seriesTemp [counter3*13+12] == 0) findFlag2 = 1;
                                                        }
                                                        
                                                        if (findFlag2 == 0) terminationFlag2 = 1;
                                                        
                                                        if (lingTempCount != 0){
                                                            cellTempCount = 0;
                                                            
                                                            do{
                                                                
                                                                terminationFlag3 = 0;
                                                                findFlag3 = 0;
                                                                
                                                                cellEntry++;
                                                                
                                                                lowestCellNo = 999999999;
                                                                lowestCellNoPosition = -1;
                                                                
                                                                for (int counter3 = 0; counter3 < lingTempCount/13; counter3++){
                                                                    if (lingTemp [counter3*13+12] != 1){
                                                                        if (lingTemp [counter3*13+2] < lowestCellNo){
                                                                            lowestCellNo = (int)lingTemp [counter3*13+2];
                                                                            lowestCellNoPosition = counter3;
                                                                        }
                                                                    }
                                                                }
                                                                
                                                                if (lowestCellNoPosition != -1){
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+1], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+2], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+3], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+4], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+5], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+6], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+7], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+8], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+9], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+10], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+11], cellTempCount++;
                                                                    cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+12], cellTempCount++;
                                                                    
                                                                    lingTemp [lowestCellNoPosition*13+12] = 1;
                                                                }
                                                                
                                                                //for (int counterA = 0; counterA < cellTempCount/13; counterA++){
                                                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<cellTemp [counterA*13+counterB];
                                                                //    cout<<" cellTemp "<<counterA<<endl;
                                                                //}
                                                                
                                                                for (int counter3 = 0; counter3 < lingTempCount/13; counter3++){
                                                                    if (lingTemp [counter3*13+12] == 0) findFlag3 = 1;
                                                                }
                                                                
                                                                if (findFlag3 == 0){
                                                                    terminationFlag3 = 1;
                                                                    
                                                                    for (int counter3 = 0; counter3 < cellTempCount/13; counter3++){
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+1], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+2], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+3], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+4], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+5], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+6], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+7], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+8], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+9], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+10], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+11], cellEventListCount2++;
                                                                        cellEventList2 [cellEventListCount2] = cellTemp [counter3*13+12], cellEventListCount2++;
                                                                    }
                                                                }
                                                                
                                                            } while (terminationFlag3 == 0);
                                                        }
                                                        
                                                    } while (terminationFlag2 == 0);
                                                }
                                                
                                            } while (terminationFlag == 0);
                                            
                                            delete [] entryList;
                                            entryList = new double [cellEventListCount2+10];
                                            entryListCount = 0;
                                            
                                            for (int counter3 = 0; counter3 < cellEventListCount2/13; counter3++){
                                                entryList [entryListCount] = cellEventList2 [counter3*13], entryListCount++;
                                                entryList [entryListCount] = cellEventList2 [counter3*13+1], entryListCount++;
                                                entryList [entryListCount] = cellEventList2 [counter3*13+2], entryListCount++;
                                                entryList [entryListCount] = -1, entryListCount++;
                                            }
                                            
                                            firstTimeFlag = 1;
                                        }
                                        
                                        //for (int counterA = 0; counterA < cellEventListCount/13; counterA++){
                                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<to_string(cellEventList [counterA*13+counterB]);
                                        //    cout<<" cellEventList "<<counterA<<endl;
                                        //}
                                        
                                        for (int counter3 = 0; counter3 < cellEventListCount/13; counter3++){
                                            for (int counter4 = 0; counter4 < entryListCount/4; counter4++){
                                                if (entryList [counter4*4] == cellEventList [counter3*13] && entryList [counter4*4+1] == cellEventList [counter3*13+1] && entryList [counter4*4+2] == cellEventList [counter3*13+2] && cellEventList [counter3*13+5] <= totalTimePoint && cellEventList [counter3*13+6] >= totalTimePoint){
                                                    entryList [counter4*4+3] = cellEventList [counter3*13+11];
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < entryListCount/4; counterA++){
                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(entryList [counterA*4+counterB]);
                            //    cout<<" entryList "<<counterA<<endl;
                            //}
                            
                            //=========Cell Event export=========
                            if (firstTimeFlag == 1){
                                ascIIstring = "Series";
                                
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < entryListCount/4; counter3++){
                                    ascIIstring = to_string((int)entryList [counter3*4]);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Ling";
                                
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < entryListCount/4; counter3++){
                                    ascIIstring = to_string((int)entryList [counter3*4+1]);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Cell";
                                
                                ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < entryListCount/4; counter3++){
                                    ascIIstring = to_string((int)entryList [counter3*4+2]);
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                firstTimeFlag = 2;
                            }
                            
                            stringR = to_string(counter1+1);
                            
                            if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                            else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                            else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                            else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                            
                            ascIIstring = "R "+stringR;
                            
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            for (int counter3 = 0; counter3 < entryListCount/4; counter3++){
                                if (entryList [counter3*4+3] != -1){
                                    ascIIstring = to_string((int)(entryList [counter3*4+3]));
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                }
                                
                                oin.put(9);
                            }
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(percentS);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(percentP);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(percentK);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(percentF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(fuseS);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(fuseP);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(fuseK);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            ascIIstring = to_string(fuseF);
                            ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 0; counter3 < entryListCount/4; counter3++){
                                entryList [counter3*4+3] = -1;
                            }
                            
                            delete [] seriesTemp;
                            delete [] lingTemp;
                            delete [] cellTemp;
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    delete [] arrayFileDelete3;
                    delete [] arrayAscIIintData;
                    
                    delete [] cellEventList;
                    delete [] cellEventList2;
                    
                    delete [] entryList;
                    
                    oin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    exportStatus = 2;
                });
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Main Progress ON"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)exportLineage:(id)sender{
    if (mainProcessOn == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            
            string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            string directoryPath = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1-1);
            
            if ((int)directoryPath.find("_3DBackUp") != -1 || (int)directoryPath.find("CLIA_LiveCell")){
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMessage object:self];
                
                dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
                    exportStatus = 1;
                    
                    DIR *dir;
                    struct dirent *dent;
                    DIR *dir2;
                    struct dirent *dent2;
                    
                    string entry;
                    string entry2;
                    
                    int totalRepeatPoint = 0;
                    int totalTimePoint = 0;
                    
                    string dataLoadPath;
                    string dataLoadPath2;
                    string timeExtract;
                    string timeExtract2;
                    
                    int fileDeleteCount2 = 0;
                    int fileDeleteCount3 = 0;
                    int fileCountMax = 0;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            if ((int)entry.find("_3DRepeatData") != -1 || (int)entry.find("09_Cell_Tracking_Analysis_Results") != -1){
                                totalRepeatPoint++;
                                
                                dataLoadPath = directoryPath+"/"+entry;
                                
                                dir2 = opendir(dataLoadPath.c_str());
                                
                                if (dir2 != NULL){
                                    fileDeleteCount2 = 0;
                                    
                                    while ((dent2 = readdir(dir2))){
                                        entry2 = dent2 -> d_name;
                                        
                                        if ((int)entry2.find("EventType.Dat") != -1){
                                            fileDeleteCount2++;
                                            
                                            timeExtract = entry2.substr(0, 8);
                                            
                                            if (totalTimePoint < atoi(timeExtract.c_str())){
                                                totalTimePoint = atoi(timeExtract.c_str());
                                                timeExtract2 = timeExtract;
                                            }
                                        }
                                    }
                                    
                                    closedir(dir2);
                                    
                                    if (fileCountMax < fileDeleteCount2) fileCountMax = fileDeleteCount2;
                                }
                            }
                        }
                        
                        closedir (dir);
                    }
                    
                    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/3D_Results";
                    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    //==========Export file Header set==========
                    string extractString;
                    string path;
                    int maxEntryNo = 0;
                    
                    ofstream oin;
                    
                    dir = opendir(resultSavePath2.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("3D_Results") != -1){
                                extractString = entry.substr(entry.find("ET")+2, entry.find(".txt")-entry.find("ET")-2);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    path = resultSavePath2+"/3D_Results-ET"+to_string(maxEntryNo)+".txt";
                    
                    oin.open(path.c_str(), ios::out | ios::binary);
                    
                    int *arrayAscIIintData = new int [100];
                    int ascIIintDataCount = 0;
                    
                    ascIIstring = "SerNo";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "LingNo";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Total-No-Of-cells";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "No-Of-Cells-End";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Total-Fluo";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Total-Fluo-End";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "BD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "MD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "CD";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "CF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "OF";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    ascIIstring = "NDV";
                    
                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    //========Data writing======
                    ifstream fin;
                    string getString;
                    string stringR;
                    
                    double *cellEventList = new double [10000];
                    
                    int cellEventListCount = 0;
                    int cellEventListLimit = 10000;
                    
                    double data1 = 0;
                    double data2 = 0;
                    double data3 = 0;
                    double data4 = 0;
                    double data5 = 0;
                    double data6 = 0;
                    double data7 = 0;
                    double data8 = 0;
                    double data9 = 0;
                    double data10 = 0;
                    double data11 = 0;
                    double data12 = 0;
                    
                    int findFlag = 0;
                    int seriesEntryTemp = 0;
                    
                    string *arrayFileDelete2 = new string [totalRepeatPoint+50];
                    fileDeleteCount2 = 0;
                    
                    dir = opendir(directoryPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if ((int)entry.find("_3DRepeatData") != -1 || (int)entry.find("09_Cell_Tracking_Analysis_Results") != -1){
                                arrayFileDelete2 [fileDeleteCount2] = directoryPath+"/"+entry, fileDeleteCount2++;
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    //-------Directory Sort------
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        [unsortedArray addObject:@(arrayFileDelete2 [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayFileDelete2 [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                    
                    int maxLingNo = 0;
                    
                    string *arrayFileDelete3 = new string [fileCountMax+50];
                    
                    for (int counter1 = 0; counter1 < fileDeleteCount2; counter1++){
                        dir = opendir(arrayFileDelete2 [counter1].c_str());
                        
                        if (dir != NULL){
                            fileDeleteCount3 = 0;
                            
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if ((int)entry.find("EventType.Dat") != -1){
                                    arrayFileDelete3 [fileDeleteCount3] = arrayFileDelete2 [counter1]+"/"+entry, fileDeleteCount3++;
                                }
                            }
                            
                            closedir(dir);
                            
                            //-------Directory Sort------
                            NSMutableArray *unsortedArray2 = [[NSMutableArray alloc] init];
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount3; counter2++){
                                [unsortedArray2 addObject:@(arrayFileDelete3 [counter2].c_str())];
                            }
                            
                            [unsortedArray2 sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                            
                            for (NSUInteger counter2 = 0; counter2 < [unsortedArray2 count]; counter2++){
                                arrayFileDelete3 [counter2] = [unsortedArray2 [counter2] UTF8String];
                            }
                            
                            //for (int counterA = 0; counterA < fileDeleteCount3; counterA++){
                            //    cout<<arrayFileDelete3 [counterA]<<" File"<<endl;
                            //}
                            
                            maxLingNo = 0;
                            
                            for (int counter2 = 0; counter2 < fileDeleteCount3; counter2++){
                                if ((int)arrayFileDelete3 [counter2].find("EventType.Dat") != -1 && (int)arrayFileDelete3 [counter2].find(timeExtract2) != -1){
                                    fin.open(arrayFileDelete3 [counter2].c_str(),ios::in);
                                    
                                    if (fin.is_open()){
                                        do{
                                            
                                            getline(fin, getString), data1 = atof(getString.c_str());
                                            getline(fin, getString), data2 = atof(getString.c_str());
                                            getline(fin, getString), data3 = atof(getString.c_str());
                                            getline(fin, getString), data4 = atof(getString.c_str());
                                            getline(fin, getString), data5 = atof(getString.c_str());
                                            getline(fin, getString), data6 = atof(getString.c_str());
                                            getline(fin, getString), data7 = atof(getString.c_str());
                                            getline(fin, getString), data8 = atof(getString.c_str());
                                            getline(fin, getString), data9 = atof(getString.c_str());
                                            getline(fin, getString), data10 = atof(getString.c_str());
                                            getline(fin, getString), data11 = atof(getString.c_str());
                                            getline(fin, getString), data12 = atof(getString.c_str());
                                            
                                            if (maxLingNo < data2) maxLingNo = (int)data2;
                                            
                                            //cout<<data2<<" "<<data3<<" "<<data4<<" "<<data5<<" "<<data6<<" "<<data7<<" "<<data8<<" "<<data9<<" "<<data10<<" Data"<<endl;
                                            
                                            if (data1 != -1 && data2 != -1 && data3 != -1){
                                                findFlag = 0;
                                                
                                                for (int counter3 = 0; counter3 < cellEventListCount/12; counter3++){
                                                    if (data1 == cellEventList [counter3*12] && data2 == cellEventList [counter3*12+1] && data3 == cellEventList [counter3*12+2]){
                                                        cellEventList [counter3*12+3] = data4;
                                                        cellEventList [counter3*12+4] = data5;
                                                        cellEventList [counter3*12+5] = data6;
                                                        cellEventList [counter3*12+6] = data7;
                                                        cellEventList [counter3*12+7] = data8;
                                                        cellEventList [counter3*12+8] = data9;
                                                        cellEventList [counter3*12+9] = data10;
                                                        cellEventList [counter3*12+10] = data11;
                                                        cellEventList [counter3*12+11] = data12;
                                                        
                                                        findFlag = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                if (findFlag == 0){
                                                    if (cellEventListCount+50 > cellEventListLimit){
                                                        double *arrayUpDate = new double [cellEventListCount+12];
                                                        
                                                        for (int counter3 = 0; counter3 < cellEventListCount; counter3++) arrayUpDate [counter3] = cellEventList [counter3];
                                                        
                                                        delete [] cellEventList;
                                                        cellEventList = new double [cellEventListLimit+10000];
                                                        cellEventListLimit = cellEventListLimit+10000;
                                                        
                                                        for (int counter3 = 0; counter3 < cellEventListCount; counter3++) cellEventList [counter3] = arrayUpDate [counter3];
                                                        delete [] arrayUpDate;
                                                    }
                                                    
                                                    cellEventList [cellEventListCount] = data1, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data2, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data3, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data4, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data5, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data6, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data7, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data8, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data9, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data10, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data11, cellEventListCount++;
                                                    cellEventList [cellEventListCount] = data12, cellEventListCount++;
                                                }
                                            }
                                            
                                        } while (data1 != -1 && data2 != -1);
                                        
                                        fin.close();
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < cellEventListCount/12; counterA++){
                            //        for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<cellEventList [counterA*12+counterB];
                            //        cout<<" cellEventList "<<counterA<<endl;
                            //}
                            
                            int *lingDataSummary = new int [maxLingNo*10+50];
                            
                            //=========Cell Event export=========
                            int *seriesEntryCount = new int [15];
                            
                            for (int counter3 = 0; counter3 < 15; counter3++){
                                seriesEntryCount [counter3] = 0;
                            }
                            
                            for (int counter3 = 0; counter3 < cellEventListCount/12; counter3++){
                                seriesEntryCount [(int)cellEventList [counter3*12]] = 1;
                            }
                            
                            seriesEntryTemp = 0;
                            
                            for (int counter3 = 1; counter3 < 10; counter3++){
                                if (seriesEntryCount [counter3] != 0){
                                    seriesEntryTemp++;
                                    seriesEntryCount [counter3] = seriesEntryTemp;
                                }
                            }
                            
                            for (int counter3 = 1; counter3 < 10; counter3++){
                                if (seriesEntryCount [counter3] != 0){
                                    for (int counter4 = 0; counter4 < maxLingNo*10+50; counter4++){
                                        lingDataSummary [counter4] = 0;
                                    }
                                    
                                    for (int counter4 = 0; counter4 < cellEventListCount/12; counter4++){
                                        if (seriesEntryCount [counter3] == cellEventList [counter4*12]){
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && (cellEventList [counter4*12+3] == 31 || cellEventList [counter4*12+3] == 41 || cellEventList [counter4*12+3] == 51 || cellEventList [counter4*12+3] == 1)) lingDataSummary [(int)cellEventList [counter4*12+1]*10]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+6] >= totalTimePoint) lingDataSummary [(int)cellEventList [counter4*12+1]*10+1]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && (cellEventList [counter4*12+3] == 31 || cellEventList [counter4*12+3] == 41 || cellEventList [counter4*12+3] == 51 || cellEventList [counter4*12+3] == 1) && cellEventList [counter4*12+11] >= 0) lingDataSummary [(int)cellEventList [counter4*12+1]*10+2] = lingDataSummary [(int)cellEventList [counter4*12+1]*10+2]+(int)cellEventList [counter4*12+11];
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+6] >= totalTimePoint && cellEventList [counter4*12+11] >= 0) lingDataSummary [(int)cellEventList [counter4*12+1]*10+3] = lingDataSummary [(int)cellEventList [counter4*12+1]*10+3]+(int)cellEventList [counter4*12+11];
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+4] == 32) lingDataSummary [(int)cellEventList [counter4*12+1]*10+4]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && (cellEventList [counter4*12+4] == 42 || cellEventList [counter4*12+4] == 52)) lingDataSummary [(int)cellEventList [counter4*12+1]*10+5]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+4] == 7) lingDataSummary [(int)cellEventList [counter4*12+1]*10+6]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+4] == 91) lingDataSummary [(int)cellEventList [counter4*12+1]*10+7]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+4] == 8) lingDataSummary [(int)cellEventList [counter4*12+1]*10+8]++;
                                            
                                            if (cellEventList [counter4*12+5] <= totalTimePoint && cellEventList [counter4*12+5] > 0 && cellEventList [counter4*12+4] == 2 && cellEventList [counter4*12+6] >= totalTimePoint && cellEventList [counter4*12+2] == 0) lingDataSummary [(int)cellEventList [counter4*12+1]*10+9]++;
                                        }
                                    }
                                    
                                    //for (int counterA = 1; counterA <= maxLingNo; counterA++){
                                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<<lingDataSummary [counterA*10+counterB];
                                    //    cout<<" lingDataSummary "<<counterA<<endl;
                                    //}
                                    
                                    for (int counter4 = 1; counter4 <= maxLingNo; counter4++){
                                        if (lingDataSummary [counter4*10] == 1 && lingDataSummary [counter4*10+6] == 0 && lingDataSummary [counter4*10+7] == 0 && lingDataSummary [counter4*10+8] == 0 && lingDataSummary [counter4*10+9] == 0){
                                            lingDataSummary [counter4*10+6]++;
                                        }
                                    }
                                    
                                    stringR = to_string(counter1+1);
                                    
                                    if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                                    else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                                    else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                                    else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                                    
                                    ascIIstring = "R "+stringR;
                                    
                                    ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                    
                                    for (int counter5 = 1; counter5 <= maxLingNo; counter5++){
                                        ascIIstring = to_string(seriesEntryCount [counter3]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        stringR = to_string(counter5);
                                        
                                        if ((int)stringR.length() == 1) stringR = "0000"+stringR;
                                        else if ((int)stringR.length() == 2) stringR = "000"+stringR;
                                        else if ((int)stringR.length() == 3) stringR = "00"+stringR;
                                        else if ((int)stringR.length() == 4) stringR = "0"+stringR;
                                        
                                        ascIIstring = stringR;
                                        
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+1]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+2]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+3]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+4]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+5]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+6]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+7]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+8]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        ascIIstring = to_string(lingDataSummary [counter5*10+9]);
                                        ascIIintDataCount = [self ascIICode:arrayAscIIintData];
                                        
                                        for (int counter6 = 0; counter6 < ascIIintDataCount; counter6++) oin.put((char)arrayAscIIintData [counter6]);
                                        
                                        oin.put(9);
                                        
                                        oin.put(13);
                                        oin.put(10);
                                    }
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                            }
                            
                            delete [] lingDataSummary;
                            delete [] seriesEntryCount;
                        }
                    }
                    
                    delete [] arrayFileDelete2;
                    delete [] arrayFileDelete3;
                    delete [] arrayAscIIintData;
                    
                    delete [] cellEventList;
                    
                    oin.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    exportStatus = 2;
                });
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"ID Error"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Main Progress ON"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)ascIICode:(int*)arrayAscIIintData{
    int ascIIint = 0;
    int length = (int)ascIIstring.length();
    string writeData;
    
    int ascIIintDataCount = 0;
    
    for (int counter1 = 0; counter1 < length; counter1++){
        writeData = ascIIstring.substr((unsigned long)counter1, 1);
        
        if (writeData == "A") ascIIint = 65;
        else if (writeData == "B") ascIIint = 66;
        else if (writeData == "C") ascIIint = 67;
        else if (writeData == "D") ascIIint = 68;
        else if (writeData == "E") ascIIint = 69;
        else if (writeData == "F") ascIIint = 70;
        else if (writeData == "G") ascIIint = 71;
        else if (writeData == "H") ascIIint = 72;
        else if (writeData == "I") ascIIint = 73;
        else if (writeData == "J") ascIIint = 74;
        else if (writeData == "K") ascIIint = 75;
        else if (writeData == "L") ascIIint = 76;
        else if (writeData == "M") ascIIint = 77;
        else if (writeData == "N") ascIIint = 78;
        else if (writeData == "O") ascIIint = 79;
        else if (writeData == "P") ascIIint = 80;
        else if (writeData == "Q") ascIIint = 81;
        else if (writeData == "R") ascIIint = 82;
        else if (writeData == "S") ascIIint = 83;
        else if (writeData == "T") ascIIint = 84;
        else if (writeData == "U") ascIIint = 85;
        else if (writeData == "V") ascIIint = 86;
        else if (writeData == "W") ascIIint = 87;
        else if (writeData == "X") ascIIint = 88;
        else if (writeData == "Y") ascIIint = 89;
        else if (writeData == "Z") ascIIint = 90;
        else if (writeData == "a") ascIIint = 97;
        else if (writeData == "b") ascIIint = 98;
        else if (writeData == "c") ascIIint = 99;
        else if (writeData == "d") ascIIint = 100;
        else if (writeData == "e") ascIIint = 101;
        else if (writeData == "f") ascIIint = 102;
        else if (writeData == "g") ascIIint = 103;
        else if (writeData == "h") ascIIint = 104;
        else if (writeData == "i") ascIIint = 105;
        else if (writeData == "j") ascIIint = 106;
        else if (writeData == "k") ascIIint = 107;
        else if (writeData == "l") ascIIint = 108;
        else if (writeData == "m") ascIIint = 109;
        else if (writeData == "n") ascIIint = 110;
        else if (writeData == "o") ascIIint = 111;
        else if (writeData == "p") ascIIint = 112;
        else if (writeData == "q") ascIIint = 113;
        else if (writeData == "r") ascIIint = 114;
        else if (writeData == "s") ascIIint = 115;
        else if (writeData == "t") ascIIint = 116;
        else if (writeData == "u") ascIIint = 117;
        else if (writeData == "v") ascIIint = 118;
        else if (writeData == "w") ascIIint = 119;
        else if (writeData == "x") ascIIint = 120;
        else if (writeData == "y") ascIIint = 121;
        else if (writeData == "z") ascIIint = 122;
        else if (writeData == "1") ascIIint = 49;
        else if (writeData == "2") ascIIint = 50;
        else if (writeData == "3") ascIIint = 51;
        else if (writeData == "4") ascIIint = 52;
        else if (writeData == "5") ascIIint = 53;
        else if (writeData == "6") ascIIint = 54;
        else if (writeData == "7") ascIIint = 55;
        else if (writeData == "8") ascIIint = 56;
        else if (writeData == "9") ascIIint = 57;
        else if (writeData == "0") ascIIint = 48;
        else if (writeData == ".") ascIIint = 46;
        else if (writeData == "-") ascIIint = 45;
        else if (writeData == "_") ascIIint = 95;
        else if (writeData == "+") ascIIint = 43;
        else if (writeData == "=") ascIIint = 61;
        else if (writeData == " ") ascIIint = 32;
        else if (writeData == ">") ascIIint = 62;
        else if (writeData == "±") ascIIint = 241;
        
        arrayAscIIintData [ascIIintDataCount] = ascIIint, ascIIintDataCount++;
    }
    
    return ascIIintDataCount;
}

@end
