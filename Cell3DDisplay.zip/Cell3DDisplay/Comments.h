//
//  Comments.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-07-04.
//

#ifndef COMMENTS_H
#define COMMENTS_H
#import "Controller.h"
#endif

@interface Comments : NSObject{
    IBOutlet NSWindow *commentsWindow;
    NSWindowController *commentsController;
    
    NSTimer *commentsTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;

@end
