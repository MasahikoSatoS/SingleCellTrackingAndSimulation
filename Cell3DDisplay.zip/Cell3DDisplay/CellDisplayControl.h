//
//  CellDisplayControl.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2022-12-31.
//

#import <ModelIO/ModelIO.h>
#import <SceneKit/SceneKit.h>
#import <SceneKit/ModelIO.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

@interface CellDisplayControl : NSViewController <SCNSceneRendererDelegate>{
    IBOutlet NSTextField *timeDisplay;
    
    IBOutlet NSTextField *positionXDisplay;
    IBOutlet NSTextField *positionYDisplay;
    IBOutlet NSTextField *positionZDisplay;
    
    IBOutlet NSTextField *rotationXDisplay;
    IBOutlet NSTextField *rotationYDisplay;
    IBOutlet NSTextField *rotationZDisplay;
    IBOutlet NSTextField *rotationWDisplay;
    
    IBOutlet NSTextField *orientationXDisplay;
    IBOutlet NSTextField *orientationYDisplay;
    IBOutlet NSTextField *orientationZDisplay;
    IBOutlet NSTextField *orientationWDisplay;
    
    IBOutlet NSTextField *scaleXDisplay;
    IBOutlet NSTextField *scaleYDisplay;
    IBOutlet NSTextField *scaleZDisplay;
    IBOutlet NSTextField *scaleMainDisplay;
    
    IBOutlet NSTextField *initZPositionDisplay;
    IBOutlet NSTextField *axeLengthDisplay;
    
    IBOutlet NSTextField *sphereSetStatusDisplay;
    IBOutlet NSTextField *exportStatusDisplay;
    
    IBOutlet NSTextField *exportStartDisplay;
    
    IBOutlet NSWindow *controller;
    
    NSTimer *exportFor3DSimTimer;
}

@property (weak) IBOutlet SCNView *sceneView;

-(void)cell3DDisplayProcessing;
-(void)cell3DExportProcessing;

-(IBAction)startAnimation:(id)sender;
-(IBAction)exportAnimation:(id)sender;
-(IBAction)forwardOne:(id)sender;
-(IBAction)forwardTen:(id)sender;
-(IBAction)forwardHundred:(id)sender;
-(IBAction)backwardOne:(id)sender;
-(IBAction)backwardTen:(id)sender;
-(IBAction)backwardHundred:(id)sender;
-(IBAction)saveCameraParameters:(id)sender;
-(IBAction)refreshParameters:(id)sender;
-(IBAction)sphereDisplaySet:(id)sender;

@end
