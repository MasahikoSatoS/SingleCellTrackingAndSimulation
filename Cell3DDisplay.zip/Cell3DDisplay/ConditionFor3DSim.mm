//
//  ConditionFor3DSim.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-12.
//

#import "ConditionFor3DSim.h"

NSString *notificationToConditionFor3DSim = @"notificationExecuteConditionFor3DSim";

@implementation ConditionFor3DSim

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToConditionFor3DSim object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[cccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[eccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[fccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    [[nccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
}

-(IBAction)color1Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [0] green:arrayColorRange2 [1] blue:arrayColorRange2 [2] alpha:1]];
    colorNoSimHold = 0;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color2Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [3] green:arrayColorRange2 [4] blue:arrayColorRange2 [5] alpha:1]];
    colorNoSimHold = 1;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color3Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [6] green:arrayColorRange2 [7] blue:arrayColorRange2 [8] alpha:1]];
    colorNoSimHold = 2;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color4Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [9] green:arrayColorRange2 [10] blue:arrayColorRange2 [11] alpha:1]];
    colorNoSimHold = 3;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color5Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [12] green:arrayColorRange2 [13] blue:arrayColorRange2 [14] alpha:1]];
    colorNoSimHold = 4;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color6Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [15] green:arrayColorRange2 [16] blue:arrayColorRange2 [17] alpha:1]];
    colorNoSimHold = 5;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color7Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [18] green:arrayColorRange2 [19] blue:arrayColorRange2 [20] alpha:1]];
    colorNoSimHold = 6;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color8Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [21] green:arrayColorRange2 [22] blue:arrayColorRange2 [23] alpha:1]];
    colorNoSimHold = 7;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color9Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [24] green:arrayColorRange2 [25] blue:arrayColorRange2 [26] alpha:1]];
    colorNoSimHold = 8;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color10Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [27] green:arrayColorRange2 [28] blue:arrayColorRange2 [29] alpha:1]];
    colorNoSimHold = 9;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color11Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [30] green:arrayColorRange2 [31] blue:arrayColorRange2 [32] alpha:1]];
    colorNoSimHold = 10;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color12Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [33] green:arrayColorRange2 [34] blue:arrayColorRange2 [35] alpha:1]];
    colorNoSimHold = 11;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color13Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [36] green:arrayColorRange2 [37] blue:arrayColorRange2 [38] alpha:1]];
    colorNoSimHold = 12;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color14Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [39] green:arrayColorRange2 [40] blue:arrayColorRange2 [41] alpha:1]];
    colorNoSimHold = 13;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color15Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [42] green:arrayColorRange2 [43] blue:arrayColorRange2 [44] alpha:1]];
    colorNoSimHold = 14;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)color16Set:(id)sender{
    [[baseColorButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [45] green:arrayColorRange2 [46] blue:arrayColorRange2 [47] alpha:1]];
    colorNoSimHold = 15;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet1:(id)sender{
    colorNumberHold [0] = colorNoSimHold;
    [[cccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet2:(id)sender{
    colorNumberHold [1] = colorNoSimHold;
    [[cccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet3:(id)sender{
    colorNumberHold [2] = colorNoSimHold;
    [[cccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet4:(id)sender{
    colorNumberHold [3] = colorNoSimHold;
    [[cccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet5:(id)sender{
    colorNumberHold [4] = colorNoSimHold;
    [[cccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet6:(id)sender{
    colorNumberHold [5] = colorNoSimHold;
    [[cccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet7:(id)sender{
    colorNumberHold [6] = colorNoSimHold;
    [[cccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cccolorSet8:(id)sender{
    colorNumberHold [7] = colorNoSimHold;
    [[cccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet1:(id)sender{
    colorNumberHold [8] = colorNoSimHold;
    [[fccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet2:(id)sender{
    colorNumberHold [9] = colorNoSimHold;
    [[fccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet3:(id)sender{
    colorNumberHold [10] = colorNoSimHold;
    [[fccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet4:(id)sender{
    colorNumberHold [11] = colorNoSimHold;
    [[fccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet5:(id)sender{
    colorNumberHold [12] = colorNoSimHold;
    [[fccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet6:(id)sender{
    colorNumberHold [13] = colorNoSimHold;
    [[fccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet7:(id)sender{
    colorNumberHold [14] = colorNoSimHold;
    [[fccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)fccolorSet8:(id)sender{
    colorNumberHold [15] = colorNoSimHold;
    [[fccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet1:(id)sender{
    colorNumberHold [16] = colorNoSimHold;
    [[eccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet2:(id)sender{
    colorNumberHold [17] = colorNoSimHold;
    [[eccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet3:(id)sender{
    colorNumberHold [18] = colorNoSimHold;
    [[eccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet4:(id)sender{
    colorNumberHold [19] = colorNoSimHold;
    [[eccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet5:(id)sender{
    colorNumberHold [20] = colorNoSimHold;
    [[eccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet6:(id)sender{
    colorNumberHold [21] = colorNoSimHold;
    [[eccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet7:(id)sender{
    colorNumberHold [22] = colorNoSimHold;
    [[eccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)eccolorSet8:(id)sender{
    colorNumberHold [23] = colorNoSimHold;
    [[eccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet1:(id)sender{
    colorNumberHold [24] = colorNoSimHold;
    [[nccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet2:(id)sender{
    colorNumberHold [25] = colorNoSimHold;
    [[nccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet3:(id)sender{
    colorNumberHold [26] = colorNoSimHold;
    [[nccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet4:(id)sender{
    colorNumberHold [27] = colorNoSimHold;
    [[nccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet5:(id)sender{
    colorNumberHold [28] = colorNoSimHold;
    [[nccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet6:(id)sender{
    colorNumberHold [29] = colorNoSimHold;
    [[nccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet7:(id)sender{
    colorNumberHold [30] = colorNoSimHold;
    [[nccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)nccolorSet8:(id)sender{
    colorNumberHold [31] = colorNoSimHold;
    [[nccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)rccolorSet1:(id)sender{
    colorNumberHold [32] = colorNoSimHold;
    [[rccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)rccolorSet2:(id)sender{
    colorNumberHold [33] = colorNoSimHold;
    [[rccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)rccolorSet3:(id)sender{
    colorNumberHold [34] = colorNoSimHold;
    [[rccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)rccolorSet4:(id)sender{
    colorNumberHold [35] = colorNoSimHold;
    [[rccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)ccInCancerSet1:(id)sender{
    colorNumberHold [36] = colorNoSimHold;
    [[ccInCancerButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)ccInCancerSet2:(id)sender{
    colorNumberHold [37] = colorNoSimHold;
    [[ccInCancerButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)ccInCancerSet3:(id)sender{
    colorNumberHold [38] = colorNoSimHold;
    [[ccInCancerButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)ccInCancerSet4:(id)sender{
    colorNumberHold [39] = colorNoSimHold;
    [[ccInCancerButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)ncInCancerSet:(id)sender{
    colorNumberHold [40] = colorNoSimHold;
    [[ncInCancerButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNoSimHold*3] green:arrayColorRange2 [colorNoSimHold*3+1] blue:arrayColorRange2 [colorNoSimHold*3+2] alpha:1]];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)modeChange:(id)sender{
    if (mainProcessOn == 0){
        if (animationMode == 0){
            animationMode = 1;
            [modeDisplay setStringValue:@"Sphere"];
            stemSetStatus = 0;
            [stemSetStatusDisplay setStringValue:@"None"];
        }
        else if (animationMode == 1){
            animationMode = 2;
            [modeDisplay setStringValue:@"Layer"];
        }
        else if (animationMode == 2){
            animationMode = 0;
            [modeDisplay setStringValue:@"Box"];
            stemSetStatus = 0;
            [stemSetStatusDisplay setStringValue:@"None"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveData:(id)sender{
    if (mainProcessOn == 0){
        string temp3DParameters = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/11_System_Data/DataTemp3DSimulationParameters.Dat";
        
        ofstream oin;
        oin.open(temp3DParameters.c_str(), ios::out | ios::binary);
        
        oin<<"PARAMETERS"<<endl;
        
        oin<<lingColorSetStatus<<endl;
        oin<<animationMode<<endl;
        oin<<stemSetStatus<<endl;
        
        int dataTemp = [concentrateDisplay intValue];
        
        if (dataTemp < 0) dataTemp = 0;
        else if (dataTemp > 200) dataTemp = 200;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [totalNumberCellDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [switchTimeDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [turnoverDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        double dataTempFloat = [nucSizeDisplay floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTemp = [simTimeDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [xyExpandDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [zExpandDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [xSiftDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [yShiftDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [zDistanceDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [belowExpandDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [aboveExpandDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [concentrateRadiusDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageTimeDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageTimeEveryDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [necrosisCountDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [cryptStemDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [layerStemCountDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        oin<<stemCancerSet<<endl;
        
        oin<<growthCancerSet<<endl;
        
        oin<<differentCancerSet<<endl;
        
        oin<<deathLayerCancerSet<<endl;
        
        dataTemp = [imagePickUpFreqDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10) dataTemp = 10;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [cryptStemZNoDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [cryptDivZNoDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [cryptDifZDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [noOfGrowthDivDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        //======Cell type information======
        string dataTempString = [[cellTypeADisplay1 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay2 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay3 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay4 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay5 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay6 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay7 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[cellTypeADisplay8 stringValue] UTF8String];
        
        if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1 || (int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1 || (int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1 || (int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1 || (int)dataTempString.find("j") != -1 || (int)dataTempString.find("J") != -1){
            if ((int)dataTempString.find("C") != -1 || (int)dataTempString.find("c") != -1){
                dataTemp = atoi(dataTempString.substr(1).c_str());
                oin<<dataTemp<<endl;
            }
            else if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1){
                oin<<1000<<endl;
            }
            else if ((int)dataTempString.find("D") != -1 || (int)dataTempString.find("d") != -1){
                oin<<2000<<endl;
            }
            else if ((int)dataTempString.find("J") != -1 || (int)dataTempString.find("j") != -1){
                oin<<3000<<endl;
            }
            else if ((int)dataTempString.find("G") != -1 || (int)dataTempString.find("g") != -1){
                oin<<4000<<endl;
            }
        }
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay1 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay2 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay3 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay4 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay5 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay6 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay7 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeDisplay8 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempFloat = [sizeDisplay1 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay2 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay3 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay4 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay5 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay6 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay7 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [sizeDisplay8 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay1 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay2 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay3 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay4 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay5 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay6 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay7 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [percentDisplay8 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTemp = [doublingTDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay5 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay6 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay7 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doublingTDisplay8 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay5 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay6 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay7 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [tdoublingGDisplay8 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 10000) dataTemp = 10000;
        
        oin<<dataTemp<<endl;
        
        dataTempString = [[layerSDisplay1 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay1 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay2 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay2 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay3 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay3 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay4 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay4 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay5 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay5 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay6 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay6 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay7 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay7 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        dataTempString = [[layerSDisplay8 stringValue] UTF8String];
        
        if (dataTempString == "I" || dataTempString == "i") oin<<100<<endl;
        else if (dataTempString == "S" || dataTempString == "s") oin<<200<<endl;
        else if (dataTempString == "C" || dataTempString == "c") oin<<300<<endl;
        else{
            
            dataTemp = [layerSDisplay8 intValue];
            
            if (dataTemp <= 0) dataTemp = 0;
            else if (dataTemp > 10) dataTemp = 10;
            
            oin<<dataTemp<<endl;
        }
        
        int value1 = 0;
        int value2 = 0;
        string value;
        
        dataTempString = [[layerEDisplay1 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay2 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay3 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay4 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay5 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay6 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay7 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempString = [[layerEDisplay8 stringValue] UTF8String];
        
        if ((int)dataTempString.find("/") != -1 && ((int)dataTempString.find("/") == 1 || (int)dataTempString.find("/") == 2)){
            if ((int)dataTempString.find("/") == 1) value = dataTempString.substr(0, 1);
            else if ((int)dataTempString.find("/") == 2) value = dataTempString.substr(0, 2);
            
            value1 = atoi(value.c_str());
            
            if ((int)dataTempString.length()-(int)dataTempString.find("/")-1 == 1 || (int)dataTempString.length()-(int)dataTempString.find("/")-1 == 2){
                value = dataTempString.substr(dataTempString.find("/")+1);
                value2 = atoi(value.c_str());
            }
            
            if (value1 == 0 || value1 > 8) value = "";
            else value = to_string(value1);
            
            if (value2 == 0 || value2 > 8) value2 = 0;
            
            if (value2 != 0 && value2 > value1) value = value+"/"+to_string(value2);
        }
        else{
            
            value1 = atoi(dataTempString.c_str());
            
            if (value1 > 0 && value1 <= 8) value = to_string(value1);
            else value = "";
        }
        
        oin<<value<<endl;
        
        dataTempFloat = [motADisplay1 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay2 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay3 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay4 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay5 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay6 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay7 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motADisplay8 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay1 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay2 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay3 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay4 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay5 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay6 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay7 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [motBDisplay8 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempString = [[necDisplay1 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay2 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay3 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay4 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay5 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay6 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay7 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[necDisplay8 stringValue] UTF8String];
        
        if (dataTempString == "On" || dataTempString == "on") oin<<1<<endl;
        else oin<<0<<endl;
        
        oin<<colorNumberHold [0]<<endl;
        oin<<colorNumberHold [1]<<endl;
        oin<<colorNumberHold [2]<<endl;
        oin<<colorNumberHold [3]<<endl;
        oin<<colorNumberHold [4]<<endl;
        oin<<colorNumberHold [5]<<endl;
        oin<<colorNumberHold [6]<<endl;
        oin<<colorNumberHold [7]<<endl;
        
        dataTempFloat = [alphaDisplay1 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay2 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay3 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay4 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay5 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay6 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay7 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaDisplay8 floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 1) dataTempFloat = 1.0;
        
        oin<<dataTempFloat<<endl;
        
        dataTemp = [fluChDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay5 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay6 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay7 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fluChDisplay8 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 12) dataTemp = 12;
        
        oin<<dataTemp<<endl;
        
        oin<<colorNumberHold [8]<<endl;
        oin<<colorNumberHold [9]<<endl;
        oin<<colorNumberHold [10]<<endl;
        oin<<colorNumberHold [11]<<endl;
        oin<<colorNumberHold [12]<<endl;
        oin<<colorNumberHold [13]<<endl;
        oin<<colorNumberHold [14]<<endl;
        oin<<colorNumberHold [15]<<endl;
        
        dataTempString = [[eventsDisplay1 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay2 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay3 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay4 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay5 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay6 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay7 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[eventsDisplay8 stringValue] UTF8String];
        
        if (dataTempString == "T" || dataTempString == "t") oin<<1<<endl;
        else if (dataTempString == "F" || dataTempString == "f") oin<<2<<endl;
        else if (dataTempString == "TB" || dataTempString == "tb") oin<<3<<endl;
        else oin<<0<<endl;
        
        oin<<colorNumberHold [16]<<endl;
        oin<<colorNumberHold [17]<<endl;
        oin<<colorNumberHold [18]<<endl;
        oin<<colorNumberHold [19]<<endl;
        oin<<colorNumberHold [20]<<endl;
        oin<<colorNumberHold [21]<<endl;
        oin<<colorNumberHold [22]<<endl;
        oin<<colorNumberHold [23]<<endl;
        
        oin<<colorNumberHold [24]<<endl;
        oin<<colorNumberHold [25]<<endl;
        oin<<colorNumberHold [26]<<endl;
        oin<<colorNumberHold [27]<<endl;
        oin<<colorNumberHold [28]<<endl;
        oin<<colorNumberHold [29]<<endl;
        oin<<colorNumberHold [30]<<endl;
        oin<<colorNumberHold [31]<<endl;
        
        dataTemp = [deathFreqDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay5 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay6 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay7 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [deathFreqDisplay8 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay5 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay6 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay7 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [damageFreqDisplay8 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        oin<<colorNumberHold [32]<<endl;
        oin<<colorNumberHold [33]<<endl;
        oin<<colorNumberHold [34]<<endl;
        oin<<colorNumberHold [35]<<endl;
        
        oin<<microenvironmentStatus<<endl;
        
        dataTemp = [percentInCancerDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doubleInCancerDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doubleInCancerDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doubleInCancerDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [doubleInCancerDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTempFloat > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [motInCancerDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [motInCancerDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [motInCancerDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [motInCancerDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTempString = [[shapeInCancerDisplay1 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeInCancerDisplay2 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeInCancerDisplay3 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[shapeInCancerDisplay4 stringValue] UTF8String];
        
        if ((int)dataTempString.find("S") != -1 || (int)dataTempString.find("s") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("CV") != -1 || (int)dataTempString.find("cv") != -1) oin<<2<<endl;
        else if ((int)dataTempString.find("CH") != -1 || (int)dataTempString.find("ch") != -1) oin<<3<<endl;
        else if ((int)dataTempString.find("B") != -1 || (int)dataTempString.find("b") != -1) oin<<4<<endl;
        else oin<<0<<endl;
        
        oin<<colorNumberHold [36]<<endl;
        oin<<colorNumberHold [37]<<endl;
        oin<<colorNumberHold [38]<<endl;
        oin<<colorNumberHold [39]<<endl;
        
        dataTempFloat = [sizeInCancerDisplay floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [alphaInCancerDisplay floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 10) dataTempFloat = 10;
        
        oin<<dataTempFloat<<endl;
        
        oin<<colorNumberHold [40]<<endl;
        
        dataTemp = [restrainDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay5 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay6 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay7 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [restrainDisplay8 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTempFloat = [movementCancerDisplay floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [movementLayerDisplay floatValue];
        
        if (dataTempFloat <= 0) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTemp = [necrosisInitDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fusedDoubleInCancerDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [fusedMotInCancerDisplay intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100000) dataTemp = 100000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerEndDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerEndDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerEndDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [percentInCancerEndDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerEndDisplay1 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerEndDisplay2 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerEndDisplay3 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [extInCancerEndDisplay4 intValue];
        
        if (dataTemp <= 0) dataTemp = 0;
        else if (dataTemp > 1000) dataTemp = 1000;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [FluoCancerDisplay1 intValue];
        
        if (dataTemp < 0 ) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [FluoCancerDisplay2 intValue];
        
        if (dataTemp < 00 ) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [FluoCancerDisplay3 intValue];
        
        if (dataTemp < 0 ) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [FluoCancerDisplay4 intValue];
        
        if (dataTemp < 0 ) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        dataTemp = [FluorescentDamageDisplay intValue];
        
        if (dataTemp < 0 ) dataTemp = 0;
        else if (dataTemp > 100) dataTemp = 100;
        
        oin<<dataTemp<<endl;
        
        oin<<repeatType<<endl;
        
        dataTempString = [[infPerCancerDisplay1 stringValue] UTF8String];
        
        if ((int)dataTempString.find("i") != -1 || (int)dataTempString.find("I") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("p") != -1 || (int)dataTempString.find("P") != -1) oin<<2<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[infPerCancerDisplay2 stringValue] UTF8String];
        
        if ((int)dataTempString.find("i") != -1 || (int)dataTempString.find("I") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("p") != -1 || (int)dataTempString.find("P") != -1) oin<<2<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[infPerCancerDisplay3 stringValue] UTF8String];
        
        if ((int)dataTempString.find("i") != -1 || (int)dataTempString.find("I") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("p") != -1 || (int)dataTempString.find("P") != -1) oin<<2<<endl;
        else oin<<0<<endl;
        
        dataTempString = [[infPerCancerDisplay4 stringValue] UTF8String];
        
        if ((int)dataTempString.find("i") != -1 || (int)dataTempString.find("I") != -1) oin<<1<<endl;
        else if ((int)dataTempString.find("p") != -1 || (int)dataTempString.find("P") != -1) oin<<2<<endl;
        else oin<<0<<endl;
        
        dataTempFloat = [envSearchDisplay floatValue];
        
        if (dataTempFloat < 0 ) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        dataTempFloat = [restrainSearchDisplay floatValue];
        
        if (dataTempFloat < 0 ) dataTempFloat = 0;
        else if (dataTempFloat > 100) dataTempFloat = 100;
        
        oin<<dataTempFloat<<endl;
        
        oin<<skipSave3DHold<<endl;
        oin<<skipSaveEnvHold<<endl;
        oin<<skipSaveLayerHold<<endl;
        oin<<heatConversionHold<<endl;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)refreshData:(id)sender{
    [lingStatusDisplay setStringValue:@""];
    [concentrateDisplay setStringValue:@""];
    [totalNumberCellDisplay setStringValue:@""];
    [switchTimeDisplay setStringValue:@""];
    [turnoverDisplay setStringValue:@""];
    [nucSizeDisplay setStringValue:@""];
    [simTimeDisplay setStringValue:@""];
    [xyExpandDisplay setStringValue:@""];
    [zExpandDisplay setStringValue:@""];
    [xSiftDisplay setStringValue:@""];
    [yShiftDisplay setStringValue:@""];
    [zDistanceDisplay setStringValue:@""];
    [belowExpandDisplay setStringValue:@""];
    [aboveExpandDisplay setStringValue:@""];
    [concentrateRadiusDisplay setStringValue:@""];
    [damageTimeDisplay setStringValue:@""];
    [damageTimeEveryDisplay setStringValue:@""];
    [necrosisCountDisplay setStringValue:@""];
    [cryptStemDisplay setStringValue:@""];
    [layerStemCountDisplay setStringValue:@""];
    [imagePickUpFreqDisplay setStringValue:@""];
    [cryptStemZNoDisplay setStringValue:@""];
    [cryptDivZNoDisplay setStringValue:@""];
    [cryptDifZDisplay setStringValue:@""];
    [noOfGrowthDivDisplay setStringValue:@""];
    [cellTypeADisplay1 setStringValue:@""];
    [cellTypeADisplay2 setStringValue:@""];
    [cellTypeADisplay3 setStringValue:@""];
    [cellTypeADisplay4 setStringValue:@""];
    [cellTypeADisplay5 setStringValue:@""];
    [cellTypeADisplay6 setStringValue:@""];
    [cellTypeADisplay7 setStringValue:@""];
    [cellTypeADisplay8 setStringValue:@""];
    [shapeDisplay1 setStringValue:@""];
    [shapeDisplay2 setStringValue:@""];
    [shapeDisplay3 setStringValue:@""];
    [shapeDisplay4 setStringValue:@""];
    [shapeDisplay5 setStringValue:@""];
    [shapeDisplay6 setStringValue:@""];
    [shapeDisplay7 setStringValue:@""];
    [shapeDisplay8 setStringValue:@""];
    [sizeDisplay1 setStringValue:@""];
    [sizeDisplay2 setStringValue:@""];
    [sizeDisplay3 setStringValue:@""];
    [sizeDisplay4 setStringValue:@""];
    [sizeDisplay5 setStringValue:@""];
    [sizeDisplay6 setStringValue:@""];
    [sizeDisplay7 setStringValue:@""];
    [sizeDisplay8 setStringValue:@""];
    [percentDisplay1 setStringValue:@""];
    [percentDisplay2 setStringValue:@""];
    [percentDisplay3 setStringValue:@""];
    [percentDisplay4 setStringValue:@""];
    [percentDisplay5 setStringValue:@""];
    [percentDisplay6 setStringValue:@""];
    [percentDisplay7 setStringValue:@""];
    [percentDisplay8 setStringValue:@""];
    [doublingTDisplay1 setStringValue:@""];
    [doublingTDisplay2 setStringValue:@""];
    [doublingTDisplay3 setStringValue:@""];
    [doublingTDisplay4 setStringValue:@""];
    [doublingTDisplay5 setStringValue:@""];
    [doublingTDisplay6 setStringValue:@""];
    [doublingTDisplay7 setStringValue:@""];
    [doublingTDisplay8 setStringValue:@""];
    [tdoublingGDisplay1 setStringValue:@""];
    [tdoublingGDisplay2 setStringValue:@""];
    [tdoublingGDisplay3 setStringValue:@""];
    [tdoublingGDisplay4 setStringValue:@""];
    [tdoublingGDisplay5 setStringValue:@""];
    [tdoublingGDisplay6 setStringValue:@""];
    [tdoublingGDisplay7 setStringValue:@""];
    [tdoublingGDisplay8 setStringValue:@""];
    [layerSDisplay1 setStringValue:@""];
    [layerSDisplay2 setStringValue:@""];
    [layerSDisplay3 setStringValue:@""];
    [layerSDisplay4 setStringValue:@""];
    [layerSDisplay5 setStringValue:@""];
    [layerSDisplay6 setStringValue:@""];
    [layerSDisplay7 setStringValue:@""];
    [layerSDisplay8 setStringValue:@""];
    [layerEDisplay1 setStringValue:@""];
    [layerEDisplay2 setStringValue:@""];
    [layerEDisplay3 setStringValue:@""];
    [layerEDisplay4 setStringValue:@""];
    [layerEDisplay5 setStringValue:@""];
    [layerEDisplay6 setStringValue:@""];
    [layerEDisplay7 setStringValue:@""];
    [layerEDisplay8 setStringValue:@""];
    [motADisplay1 setStringValue:@""];
    [motADisplay2 setStringValue:@""];
    [motADisplay3 setStringValue:@""];
    [motADisplay4 setStringValue:@""];
    [motADisplay5 setStringValue:@""];
    [motADisplay6 setStringValue:@""];
    [motADisplay7 setStringValue:@""];
    [motADisplay8 setStringValue:@""];
    [motBDisplay1 setStringValue:@""];
    [motBDisplay2 setStringValue:@""];
    [motBDisplay3 setStringValue:@""];
    [motBDisplay4 setStringValue:@""];
    [motBDisplay5 setStringValue:@""];
    [motBDisplay6 setStringValue:@""];
    [motBDisplay7 setStringValue:@""];
    [motBDisplay8 setStringValue:@""];
    [necDisplay1 setStringValue:@""];
    [necDisplay2 setStringValue:@""];
    [necDisplay3 setStringValue:@""];
    [necDisplay4 setStringValue:@""];
    [necDisplay5 setStringValue:@""];
    [necDisplay6 setStringValue:@""];
    [necDisplay7 setStringValue:@""];
    [necDisplay8 setStringValue:@""];
    [alphaDisplay1 setStringValue:@""];
    [alphaDisplay2 setStringValue:@""];
    [alphaDisplay3 setStringValue:@""];
    [alphaDisplay4 setStringValue:@""];
    [alphaDisplay5 setStringValue:@""];
    [alphaDisplay6 setStringValue:@""];
    [alphaDisplay7 setStringValue:@""];
    [alphaDisplay8 setStringValue:@""];
    [fluChDisplay1 setStringValue:@""];
    [fluChDisplay2 setStringValue:@""];
    [fluChDisplay3 setStringValue:@""];
    [fluChDisplay4 setStringValue:@""];
    [fluChDisplay5 setStringValue:@""];
    [fluChDisplay6 setStringValue:@""];
    [fluChDisplay7 setStringValue:@""];
    [fluChDisplay8 setStringValue:@""];
    [eventsDisplay1 setStringValue:@""];
    [eventsDisplay2 setStringValue:@""];
    [eventsDisplay3 setStringValue:@""];
    [eventsDisplay4 setStringValue:@""];
    [eventsDisplay5 setStringValue:@""];
    [eventsDisplay6 setStringValue:@""];
    [eventsDisplay7 setStringValue:@""];
    [eventsDisplay8 setStringValue:@""];
    
    [deathFreqDisplay1 setStringValue:@""];
    [deathFreqDisplay2 setStringValue:@""];
    [deathFreqDisplay3 setStringValue:@""];
    [deathFreqDisplay4 setStringValue:@""];
    [deathFreqDisplay5 setStringValue:@""];
    [deathFreqDisplay6 setStringValue:@""];
    [deathFreqDisplay7 setStringValue:@""];
    [deathFreqDisplay8 setStringValue:@""];
    
    [damageFreqDisplay1 setStringValue:@""];
    [damageFreqDisplay2 setStringValue:@""];
    [damageFreqDisplay3 setStringValue:@""];
    [damageFreqDisplay4 setStringValue:@""];
    [damageFreqDisplay5 setStringValue:@""];
    [damageFreqDisplay6 setStringValue:@""];
    [damageFreqDisplay7 setStringValue:@""];
    [damageFreqDisplay8 setStringValue:@""];
    
    [percentInCancerDisplay1 setStringValue:@""];
    [percentInCancerDisplay2 setStringValue:@""];
    [percentInCancerDisplay3 setStringValue:@""];
    [percentInCancerDisplay4 setStringValue:@""];
    [doubleInCancerDisplay1 setStringValue:@""];
    [doubleInCancerDisplay2 setStringValue:@""];
    [doubleInCancerDisplay3 setStringValue:@""];
    [doubleInCancerDisplay4 setStringValue:@""];
    [extInCancerDisplay1 setStringValue:@""];
    [extInCancerDisplay2 setStringValue:@""];
    [extInCancerDisplay3 setStringValue:@""];
    [extInCancerDisplay4 setStringValue:@""];
    [motInCancerDisplay1 setStringValue:@""];
    [motInCancerDisplay2 setStringValue:@""];
    [motInCancerDisplay3 setStringValue:@""];
    [motInCancerDisplay4 setStringValue:@""];
    
    [shapeInCancerDisplay1 setStringValue:@""];
    [shapeInCancerDisplay2 setStringValue:@""];
    [shapeInCancerDisplay3 setStringValue:@""];
    [shapeInCancerDisplay4 setStringValue:@""];
    
    [sizeInCancerDisplay setStringValue:@""];
    [alphaInCancerDisplay setStringValue:@""];
    
    [restrainDisplay1 setStringValue:@""];
    [restrainDisplay2 setStringValue:@""];
    [restrainDisplay3 setStringValue:@""];
    [restrainDisplay4 setStringValue:@""];
    [restrainDisplay5 setStringValue:@""];
    [restrainDisplay6 setStringValue:@""];
    [restrainDisplay7 setStringValue:@""];
    [restrainDisplay8 setStringValue:@""];
    
    [movementCancerDisplay setStringValue:@""];
    [movementLayerDisplay setStringValue:@""];
    [necrosisInitDisplay setStringValue:@""];
    
    [fusedDoubleInCancerDisplay setStringValue:@""];
    [fusedMotInCancerDisplay setStringValue:@""];
    
    [percentInCancerEndDisplay1 setStringValue:@""];
    [percentInCancerEndDisplay2 setStringValue:@""];
    [percentInCancerEndDisplay3 setStringValue:@""];
    [percentInCancerEndDisplay4 setStringValue:@""];
    [extInCancerEndDisplay1 setStringValue:@""];
    [extInCancerEndDisplay2 setStringValue:@""];
    [extInCancerEndDisplay3 setStringValue:@""];
    [extInCancerEndDisplay4 setStringValue:@""];
    [FluoCancerDisplay1 setStringValue:@""];
    [FluoCancerDisplay2 setStringValue:@""];
    [FluoCancerDisplay3 setStringValue:@""];
    [FluoCancerDisplay4 setStringValue:@""];
    [infPerCancerDisplay1 setStringValue:@""];
    [infPerCancerDisplay2 setStringValue:@""];
    [infPerCancerDisplay3 setStringValue:@""];
    [infPerCancerDisplay4 setStringValue:@""];
    
    [FluorescentDamageDisplay setStringValue:@""];
    [envSearchDisplay setStringValue:@""];
    [restrainSearchDisplay setStringValue:@""];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)parameterLoad:(id)sender{
    string temp3DParameters = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/11_System_Data/DataTemp3DSimulationParameters.Dat";
    
    ifstream fin;
    fin.open(temp3DParameters.c_str(),ios::in);
    
    if (fin.is_open()){
        string getString;
        
        getline(fin, getString);
        
        if (getString == "PARAMETERS"){
            getline(fin, getString);
            
            if (getString == "0"){
                lingColorSetStatus = 0;
                [lingStatusDisplay setStringValue:@"Off"];
            }
            else if (getString == "1"){
                lingColorSetStatus = 1;
                [lingStatusDisplay setStringValue:@"On"];
            }
            
            getline(fin, getString);
            
            if (getString == "0"){
                animationMode = 0;
                [modeDisplay setStringValue:@"Box"];
            }
            else if (getString == "1"){
                animationMode = 1;
                [modeDisplay setStringValue:@"Sphere"];
            }
            else if (getString == "2"){
                animationMode = 2;
                [modeDisplay setStringValue:@"Layer"];
            }
            else if (getString == "3"){
                animationMode = 3;
                [modeDisplay setStringValue:@"Micro"];
            }
            
            getline(fin, getString);
            
            if (getString == "0"){
                stemSetStatus = 0;
                [stemSetStatusDisplay setStringValue:@"None"];
            }
            else if (getString == "1"){
                stemSetStatus = 1;
                [stemSetStatusDisplay setStringValue:@"Basal"];
            }
            else if (getString == "2"){
                stemSetStatus = 2;
                [stemSetStatusDisplay setStringValue:@"Crypt"];
            }
            
            getline(fin, getString);
            int dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [concentrateDisplay setStringValue:@(getString.c_str())];
            else [concentrateDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [totalNumberCellDisplay setStringValue:@(getString.c_str())];
            else [totalNumberCellDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [switchTimeDisplay setStringValue:@(getString.c_str())];
            else [switchTimeDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0)[turnoverDisplay setStringValue:@(getString.c_str())];
            else [turnoverDisplay setStringValue:@""];
            
            getline(fin, getString);
            double dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [nucSizeDisplay setDoubleValue:dataTempFloat];
            else [nucSizeDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [simTimeDisplay setStringValue:@(getString.c_str())];
            else [simTimeDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [xyExpandDisplay setStringValue:@(getString.c_str())];
            else [xyExpandDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [zExpandDisplay setStringValue:@(getString.c_str())];
            else [zExpandDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [xSiftDisplay setStringValue:@(getString.c_str())];
            else [xSiftDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [yShiftDisplay setStringValue:@(getString.c_str())];
            else [yShiftDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [zDistanceDisplay setStringValue:@(getString.c_str())];
            else [zDistanceDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [belowExpandDisplay setStringValue:@(getString.c_str())];
            else [belowExpandDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [aboveExpandDisplay setStringValue:@(getString.c_str())];
            else [aboveExpandDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [concentrateRadiusDisplay setStringValue:@(getString.c_str())];
            else [concentrateRadiusDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageTimeDisplay setStringValue:@(getString.c_str())];
            else [damageTimeDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageTimeEveryDisplay setStringValue:@(getString.c_str())];
            else [damageTimeEveryDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [necrosisCountDisplay setStringValue:@(getString.c_str())];
            else [necrosisCountDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [cryptStemDisplay setStringValue:@(getString.c_str())];
            else [cryptStemDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [layerStemCountDisplay setStringValue:@(getString.c_str())];
            else [layerStemCountDisplay setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1"){
                stemCancerSet = 1;
                [stemCancerDisplay setTextColor:[NSColor redColor]];
                [stemCancerDisplay setStringValue:@"Stem"];
            }
            else if (getString == "0"){
                stemCancerSet = 0;
                [stemCancerDisplay setTextColor:[NSColor blackColor]];
                [stemCancerDisplay setStringValue:@"Stem"];
            }
            
            getline(fin, getString);
            
            if (getString == "1"){
                growthCancerSet = 1;
                [growthCancerDisplay setTextColor:[NSColor redColor]];
                [growthCancerDisplay setStringValue:@"Growth"];
            }
            else if (getString == "0"){
                growthCancerSet = 0;
                [growthCancerDisplay setTextColor:[NSColor blackColor]];
                [growthCancerDisplay setStringValue:@"Growth"];
            }
            
            getline(fin, getString);
            
            if (getString == "1"){
                differentCancerSet = 1;
                [diffrentCancerDisplay setTextColor:[NSColor redColor]];
                [diffrentCancerDisplay setStringValue:@"Diff."];
            }
            else if (getString == "0"){
                differentCancerSet = 0;
                [diffrentCancerDisplay setTextColor:[NSColor blackColor]];
                [diffrentCancerDisplay setStringValue:@"Diff."];
            }
            
            getline(fin, getString);
            
            if (getString == "1"){
                deathLayerCancerSet = 1;
                [cellDeathCancerDisplay setTextColor:[NSColor redColor]];
                [cellDeathCancerDisplay setStringValue:@"Death"];
            }
            else if (getString == "0"){
                deathLayerCancerSet = 0;
                [cellDeathCancerDisplay setTextColor:[NSColor blackColor]];
                [cellDeathCancerDisplay setStringValue:@"Death"];
            }
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [imagePickUpFreqDisplay setStringValue:@(getString.c_str())];
            else [imagePickUpFreqDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [cryptStemZNoDisplay setStringValue:@(getString.c_str())];
            else [cryptStemZNoDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [cryptDivZNoDisplay setStringValue:@(getString.c_str())];
            else [cryptDivZNoDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [cryptDifZDisplay setStringValue:@(getString.c_str())];
            else [cryptDifZDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [noOfGrowthDivDisplay setStringValue:@(getString.c_str())];
            else [noOfGrowthDivDisplay setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay1 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay1 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay1 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay1 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay1 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay1 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay2 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay2 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay2 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay2 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay2 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay2 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay3 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay3 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay3 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay3 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay3 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay3 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay4 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay4 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay4 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay4 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay4 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay4 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay5 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay5 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay5 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay5 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay5 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay5 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay6 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay6 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay6 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay6 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay6 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay6 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay7 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay7 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay7 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay7 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay7 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay7 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "0") [cellTypeADisplay8 setStringValue:@""];
            else if (getString == "1000") [cellTypeADisplay8 setStringValue:@"S"];
            else if (getString == "2000") [cellTypeADisplay8 setStringValue:@"D"];
            else if (getString == "3000") [cellTypeADisplay8 setStringValue:@"J"];
            else if (getString == "4000") [cellTypeADisplay8 setStringValue:@"G"];
            else{
                
                string dataTempString = "C"+getString;
                [cellTypeADisplay8 setStringValue:@(dataTempString.c_str())];
            }
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay1 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay1 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay1 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay1 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay2 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay2 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay2 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay2 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay3 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay3 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay3 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay3 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay4 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay4 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay4 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay4 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay5 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay5 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay5 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay5 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay6 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay6 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay6 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay6 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay7 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay7 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay7 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay7 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeDisplay8 setStringValue:@"S"];
            else if (getString == "2") [shapeDisplay8 setStringValue:@"CV"];
            else if (getString == "3") [shapeDisplay8 setStringValue:@"CH"];
            else if (getString == "4") [shapeDisplay8 setStringValue:@"B"];
            else if (getString == "0") [shapeDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay1 setDoubleValue:dataTempFloat];
            else [sizeDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay2 setDoubleValue:dataTempFloat];
            else [sizeDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay3 setDoubleValue:dataTempFloat];
            else [sizeDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay4 setDoubleValue:dataTempFloat];
            else [sizeDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay5 setDoubleValue:dataTempFloat];
            else [sizeDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay6 setDoubleValue:dataTempFloat];
            else [sizeDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay7 setDoubleValue:dataTempFloat];
            else [sizeDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeDisplay8 setDoubleValue:dataTempFloat];
            else [sizeDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay1 setDoubleValue:dataTempFloat];
            else [percentDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay2 setDoubleValue:dataTempFloat];
            else [percentDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay3 setDoubleValue:dataTempFloat];
            else [percentDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay4 setDoubleValue:dataTempFloat];
            else [percentDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay5 setDoubleValue:dataTempFloat];
            else [percentDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay6 setDoubleValue:dataTempFloat];
            else [percentDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay7 setDoubleValue:dataTempFloat];
            else [percentDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [percentDisplay8 setDoubleValue:dataTempFloat];
            else [percentDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay1 setStringValue:@(getString.c_str())];
            else [doublingTDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay2 setStringValue:@(getString.c_str())];
            else [doublingTDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay3 setStringValue:@(getString.c_str())];
            else [doublingTDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay4 setStringValue:@(getString.c_str())];
            else [doublingTDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay5 setStringValue:@(getString.c_str())];
            else [doublingTDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay6 setStringValue:@(getString.c_str())];
            else [doublingTDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay7 setStringValue:@(getString.c_str())];
            else [doublingTDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doublingTDisplay8 setStringValue:@(getString.c_str())];
            else [doublingTDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay1 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay2 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay3 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay4 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay5 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay6 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay7 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [tdoublingGDisplay8 setStringValue:@(getString.c_str())];
            else [tdoublingGDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay1 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay1 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay1 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay1 setStringValue:@""];
            else [layerSDisplay1 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay2 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay2 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay2 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay2 setStringValue:@""];
            else [layerSDisplay2 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay3 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay3 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay3 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay3 setStringValue:@""];
            else [layerSDisplay3 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay4 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay4 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay4 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay4 setStringValue:@""];
            else [layerSDisplay4 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay5 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay5 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay5 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay5 setStringValue:@""];
            else [layerSDisplay5 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay6 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay6 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay6 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay6 setStringValue:@""];
            else [layerSDisplay6 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay7 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay7 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay7 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay7 setStringValue:@""];
            else [layerSDisplay7 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            if (getString == "100") [layerSDisplay8 setStringValue:@"I"];
            else if (getString == "200") [layerSDisplay8 setStringValue:@"S"];
            else if (getString == "300") [layerSDisplay8 setStringValue:@"C"];
            else if (getString == "0") [layerSDisplay8 setStringValue:@""];
            else [layerSDisplay8 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay1 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay2 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay3 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay4 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay5 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay6 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay7 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            
            [layerEDisplay8 setStringValue:@(getString.c_str())];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay1 setDoubleValue:dataTempFloat];
            else [motADisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay2 setDoubleValue:dataTempFloat];
            else [motADisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay3 setDoubleValue:dataTempFloat];
            else [motADisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay4 setDoubleValue:dataTempFloat];
            else [motADisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay5 setDoubleValue:dataTempFloat];
            else [motADisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay6 setDoubleValue:dataTempFloat];
            else [motADisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay7 setDoubleValue:dataTempFloat];
            else [motADisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motADisplay8 setDoubleValue:dataTempFloat];
            else [motADisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay1 setDoubleValue:dataTempFloat];
            else [motBDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay2 setDoubleValue:dataTempFloat];
            else [motBDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay3 setDoubleValue:dataTempFloat];
            else [motBDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay4 setDoubleValue:dataTempFloat];
            else [motBDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay5 setDoubleValue:dataTempFloat];
            else [motBDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay6 setDoubleValue:dataTempFloat];
            else [motBDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay7 setDoubleValue:dataTempFloat];
            else [motBDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [motBDisplay8 setDoubleValue:dataTempFloat];
            else [motBDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay1 setStringValue:@"On"];
            else [necDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay2 setStringValue:@"On"];
            else [necDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay3 setStringValue:@"On"];
            else [necDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay4 setStringValue:@"On"];
            else [necDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay5 setStringValue:@"On"];
            else [necDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay6 setStringValue:@"On"];
            else [necDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay7 setStringValue:@"On"];
            else [necDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [necDisplay8 setStringValue:@"On"];
            else [necDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [0] = dataTemp;
            [[cccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [1] = dataTemp;
            [[cccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [2] = dataTemp;
            [[cccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [3] = dataTemp;
            [[cccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [4] = dataTemp;
            [[cccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [5] = dataTemp;
            [[cccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [6] = dataTemp;
            [[cccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [7] = dataTemp;
            [[cccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay1 setDoubleValue:dataTempFloat];
            else [alphaDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay2 setDoubleValue:dataTempFloat];
            else [alphaDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay3 setDoubleValue:dataTempFloat];
            else [alphaDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay4 setDoubleValue:dataTempFloat];
            else [alphaDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay5 setDoubleValue:dataTempFloat];
            else [alphaDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay6 setDoubleValue:dataTempFloat];
            else [alphaDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay7 setDoubleValue:dataTempFloat];
            else [alphaDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaDisplay8 setDoubleValue:dataTempFloat];
            else [alphaDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay1 setStringValue:@(getString.c_str())];
            else [fluChDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay2 setStringValue:@(getString.c_str())];
            else [fluChDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay3 setStringValue:@(getString.c_str())];
            else [fluChDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay4 setStringValue:@(getString.c_str())];
            else [fluChDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay5 setStringValue:@(getString.c_str())];
            else [fluChDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay6 setStringValue:@(getString.c_str())];
            else [fluChDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay7 setStringValue:@(getString.c_str())];
            else [fluChDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fluChDisplay8 setStringValue:@(getString.c_str())];
            else [fluChDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [8] = dataTemp;
            [[fccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [9] = dataTemp;
            [[fccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [10] = dataTemp;
            [[fccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [11] = dataTemp;
            [[fccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [12] = dataTemp;
            [[fccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [13] = dataTemp;
            [[fccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [14] = dataTemp;
            [[fccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [15] = dataTemp;
            [[fccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay1 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay1 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay1 setStringValue:@"TB"];
            else [eventsDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay2 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay2 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay2 setStringValue:@"TB"];
            else [eventsDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay3 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay3 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay3 setStringValue:@"TB"];
            else [eventsDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay4 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay4 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay4 setStringValue:@"TB"];
            else [eventsDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay5 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay5 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay5 setStringValue:@"TB"];
            else [eventsDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay6 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay6 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay6 setStringValue:@"TB"];
            else [eventsDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay7 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay7 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay7 setStringValue:@"TB"];
            else [eventsDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [eventsDisplay8 setStringValue:@"T"];
            else if (getString == "2") [eventsDisplay8 setStringValue:@"F"];
            else if (getString == "3") [eventsDisplay8 setStringValue:@"TB"];
            else [eventsDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [16] = dataTemp;
            [[eccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [17] = dataTemp;
            [[eccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [18] = dataTemp;
            [[eccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [19] = dataTemp;
            [[eccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [20] = dataTemp;
            [[eccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [21] = dataTemp;
            [[eccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [22] = dataTemp;
            [[eccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [23] = dataTemp;
            [[eccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [24] = dataTemp;
            [[nccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [25] = dataTemp;
            [[nccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [26] = dataTemp;
            [[nccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [27] = dataTemp;
            [[nccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [28] = dataTemp;
            [[nccolorButton5 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [29] = dataTemp;
            [[nccolorButton6 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [30] = dataTemp;
            [[nccolorButton7 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [31] = dataTemp;
            [[nccolorButton8 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay1 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay2 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay3 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay4 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay5 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay6 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay7 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [deathFreqDisplay8 setStringValue:@(getString.c_str())];
            else [deathFreqDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay1 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay2 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay3 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay4 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay5 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay6 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay7 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [damageFreqDisplay8 setStringValue:@(getString.c_str())];
            else [damageFreqDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [32] = dataTemp;
            [[rccolorButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [33] = dataTemp;
            [[rccolorButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [34] = dataTemp;
            [[rccolorButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [35] = dataTemp;
            [[rccolorButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 1){
                microenvironmentStatus = 1;
                [microenvironmentStatusDisplay setStringValue:@"On"];
            }
            else{
                
                microenvironmentStatus = 0;
                [microenvironmentStatusDisplay setStringValue:@"Off"];
            }
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerDisplay1 setIntegerValue:dataTemp];
            else [percentInCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerDisplay2 setIntegerValue:dataTemp];
            else [percentInCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerDisplay3 setIntegerValue:dataTemp];
            else [percentInCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerDisplay4 setIntegerValue:dataTemp];
            else [percentInCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doubleInCancerDisplay1 setIntegerValue:dataTemp];
            else [doubleInCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doubleInCancerDisplay2 setIntegerValue:dataTemp];
            else [doubleInCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doubleInCancerDisplay3 setIntegerValue:dataTemp];
            else [doubleInCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [doubleInCancerDisplay4 setIntegerValue:dataTemp];
            else [doubleInCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerDisplay1 setIntegerValue:dataTemp];
            else [extInCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerDisplay2 setIntegerValue:dataTemp];
            else [extInCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerDisplay3 setIntegerValue:dataTemp];
            else [extInCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerDisplay4 setIntegerValue:dataTemp];
            else [extInCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [motInCancerDisplay1 setIntegerValue:dataTemp];
            else [motInCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [motInCancerDisplay2 setIntegerValue:dataTemp];
            else [motInCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [motInCancerDisplay3 setIntegerValue:dataTemp];
            else [motInCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [motInCancerDisplay4 setIntegerValue:dataTemp];
            else [motInCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeInCancerDisplay1 setStringValue:@"S"];
            else if (getString == "2") [shapeInCancerDisplay1 setStringValue:@"CV"];
            else if (getString == "3") [shapeInCancerDisplay1 setStringValue:@"CH"];
            else if (getString == "4") [shapeInCancerDisplay1 setStringValue:@"B"];
            else if (getString == "0") [shapeInCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeInCancerDisplay2 setStringValue:@"S"];
            else if (getString == "2") [shapeInCancerDisplay2 setStringValue:@"CV"];
            else if (getString == "3") [shapeInCancerDisplay2 setStringValue:@"CH"];
            else if (getString == "4") [shapeInCancerDisplay2 setStringValue:@"B"];
            else if (getString == "0") [shapeInCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeInCancerDisplay3 setStringValue:@"S"];
            else if (getString == "2") [shapeInCancerDisplay3 setStringValue:@"CV"];
            else if (getString == "3") [shapeInCancerDisplay3 setStringValue:@"CH"];
            else if (getString == "4") [shapeInCancerDisplay3 setStringValue:@"B"];
            else if (getString == "0") [shapeInCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            
            if (getString == "1") [shapeInCancerDisplay4 setStringValue:@"S"];
            else if (getString == "2") [shapeInCancerDisplay4 setStringValue:@"CV"];
            else if (getString == "3") [shapeInCancerDisplay4 setStringValue:@"CH"];
            else if (getString == "4") [shapeInCancerDisplay4 setStringValue:@"B"];
            else if (getString == "0") [shapeInCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [36] = dataTemp;
            [[ccInCancerButton1 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [37] = dataTemp;
            [[ccInCancerButton2 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [38] = dataTemp;
            [[ccInCancerButton3 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [39] = dataTemp;
            [[ccInCancerButton4 cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [sizeInCancerDisplay setDoubleValue:dataTempFloat];
            else [sizeInCancerDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [alphaInCancerDisplay setDoubleValue:dataTempFloat];
            else [alphaInCancerDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            colorNumberHold [40] = dataTemp;
            [[ncInCancerButton cell] setBackgroundColor:[NSColor colorWithCalibratedRed:arrayColorRange2 [dataTemp*3] green:arrayColorRange2 [dataTemp*3+1] blue:arrayColorRange2 [dataTemp*3+2] alpha:1]];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay1 setIntegerValue:dataTemp];
            else [restrainDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay2 setIntegerValue:dataTemp];
            else [restrainDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay3 setIntegerValue:dataTemp];
            else [restrainDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay4 setIntegerValue:dataTemp];
            else [restrainDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay5 setIntegerValue:dataTemp];
            else [restrainDisplay5 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay6 setIntegerValue:dataTemp];
            else [restrainDisplay6 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay7 setIntegerValue:dataTemp];
            else [restrainDisplay7 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [restrainDisplay8 setIntegerValue:dataTemp];
            else [restrainDisplay8 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [movementCancerDisplay setDoubleValue:dataTempFloat];
            else [movementCancerDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [movementLayerDisplay setDoubleValue:dataTempFloat];
            else [movementLayerDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [necrosisInitDisplay setIntegerValue:dataTemp];
            else [necrosisInitDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fusedDoubleInCancerDisplay setIntegerValue:dataTemp];
            else [fusedDoubleInCancerDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [fusedMotInCancerDisplay setIntegerValue:dataTemp];
            else [fusedMotInCancerDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerEndDisplay1 setIntegerValue:dataTemp];
            else [percentInCancerEndDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerEndDisplay2 setIntegerValue:dataTemp];
            else [percentInCancerEndDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerEndDisplay3 setIntegerValue:dataTemp];
            else [percentInCancerEndDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [percentInCancerEndDisplay4 setIntegerValue:dataTemp];
            else [percentInCancerEndDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerEndDisplay1 setIntegerValue:dataTemp];
            else [extInCancerEndDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerEndDisplay2 setIntegerValue:dataTemp];
            else [extInCancerEndDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerEndDisplay3 setIntegerValue:dataTemp];
            else [extInCancerEndDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [extInCancerEndDisplay4 setIntegerValue:dataTemp];
            else [extInCancerEndDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [FluoCancerDisplay1 setIntegerValue:dataTemp];
            else [FluoCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [FluoCancerDisplay2 setIntegerValue:dataTemp];
            else [FluoCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [FluoCancerDisplay3 setIntegerValue:dataTemp];
            else [FluoCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [FluoCancerDisplay4 setIntegerValue:dataTemp];
            else [FluoCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp != 0) [FluorescentDamageDisplay setIntegerValue:dataTemp];
            else [FluorescentDamageDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 0) [repeatTypeDisplay setStringValue:@"% Cancer"];
            else [repeatTypeDisplay setStringValue:@"Ext/Frq"];
            
            repeatType = dataTemp;
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 1) [infPerCancerDisplay1 setStringValue:@"I"];
            else if (dataTemp == 2) [infPerCancerDisplay1 setStringValue:@"P"];
            else [infPerCancerDisplay1 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 1) [infPerCancerDisplay2 setStringValue:@"I"];
            else if (dataTemp == 2) [infPerCancerDisplay2 setStringValue:@"P"];
            else [infPerCancerDisplay2 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 1) [infPerCancerDisplay3 setStringValue:@"I"];
            else if (dataTemp == 2) [infPerCancerDisplay3 setStringValue:@"P"];
            else [infPerCancerDisplay3 setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 1) [infPerCancerDisplay4 setStringValue:@"I"];
            else if (dataTemp == 2) [infPerCancerDisplay4 setStringValue:@"P"];
            else [infPerCancerDisplay4 setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [envSearchDisplay setDoubleValue:dataTempFloat];
            else [envSearchDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTempFloat = atof(getString.c_str());
            
            if (dataTempFloat != 0) [restrainSearchDisplay setDoubleValue:dataTempFloat];
            else [restrainSearchDisplay setStringValue:@""];
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 0) [skipSave3DDisplay setStringValue:@"No"];
            else [skipSave3DDisplay setStringValue:@"Yes"];
            skipSave3DHold = dataTemp;
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 0) [skipSaveEnvDisplay setStringValue:@"No"];
            else [skipSaveEnvDisplay setStringValue:@"Yes"];
            skipSaveEnvHold = dataTemp;
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 0) [skipSaveLayerDisplay setStringValue:@"No"];
            else [skipSaveLayerDisplay setStringValue:@"Yes"];
            skipSaveLayerHold = dataTemp;
            
            getline(fin, getString);
            dataTemp = atoi(getString.c_str());
            
            if (dataTemp == 0) [heatConversionDisplay setStringValue:@"No"];
            else [heatConversionDisplay setStringValue:@"Yes"];
            heatConversionHold = dataTemp;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Parameter File Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
        
        fin.close();
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Parameter File Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)parameterExport:(id)sender{
    string temp3DSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/11_System_Data/DataTemp3DSimulationParameters.Dat";
    
    NSSavePanel *save = [NSSavePanel savePanel];
    
    long int result2 = [save runModal];
    
    if (result2 == NSModalResponseOK){
        NSURL *files = [save URL];
        NSString *selectedFile = files.path;
        
        string extractedID = [selectedFile UTF8String];
        string directoryPath = [selectedFile UTF8String];
        
        int terminationFlag = 0;
        
        do{
            
            terminationFlag = 1;
            
            if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
            else terminationFlag = 0;
            
        } while (terminationFlag == 1);
        
        unsigned long findString1 = directoryPath.find (extractedID);
        directoryPath = directoryPath.substr (0, findString1);
        
        if (extractedID != ""){
            destinationName = extractedID;
            
            int returnResults = [self nameCheck];
            
            if (returnResults == 0){
                string destinationAnalysisPath = directoryPath+extractedID+"_DataTemp3DSimulationParameters.Dat";
                
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                if (stat(temp3DSave.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    ifstream infile (temp3DSave.c_str(), ifstream::binary);
                    ofstream outfile (destinationAnalysisPath.c_str(), ofstream::binary);
                    
                    char* buffer = new char[sizeForCopy];
                    infile.read (buffer, sizeForCopy);
                    outfile.write (buffer, sizeForCopy);
                    delete[] buffer;
                    
                    outfile.close();
                    infile.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Illegal Characters Found"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
    }
}

-(IBAction)parameterImport:(id)sender{
    if (mainProcessOn == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:YES];
        [openDlg setCanChooseDirectories:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            int findString1 = (int)directoryPathExtract.find("/Users/");
            if (findString1 == -1) findString1 = (int)directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            
            string extractedID = directoryPathExtract.substr((unsigned long)findString1, directoryLength-(unsigned long)findString1);
            
            if ((int)extractedID.find("DataTemp3DSimulationParameters") != -1){
                string temp3DSave = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/11_System_Data/DataTemp3DSimulationParameters.Dat";
                
                long sizeForCopy = 0;
                struct stat sizeOfFile;
                
                if (stat(extractedID.c_str(), &sizeOfFile) == 0){
                    sizeForCopy = sizeOfFile.st_size;
                    
                    ifstream infile (extractedID.c_str(), ifstream::binary);
                    ofstream outfile (temp3DSave.c_str(), ofstream::binary);
                    
                    char* buffer = new char[sizeForCopy];
                    infile.read (buffer, sizeForCopy);
                    outfile.write (buffer, sizeForCopy);
                    delete[] buffer;
                    
                    outfile.close();
                    infile.close();
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Processing On"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lingColorSet:(id)sender{
    if (lingColorSetStatus == 0){
        lingColorSetStatus = 1;
        [lingStatusDisplay setStringValue:@"On"];
    }
    else if (lingColorSetStatus == 1){
        lingColorSetStatus = 0;
        [lingStatusDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)stemSet:(id)sender{
    if (animationMode == 2){
        if (stemSetStatus == 0){
            stemSetStatus = 1;
            [stemSetStatusDisplay setStringValue:@"Basal"];
        }
        else if (stemSetStatus == 1){
            stemSetStatus = 2;
            [stemSetStatusDisplay setStringValue:@"Crypt"];
        }
        else if (stemSetStatus == 2){
            stemSetStatus = 0;
            [stemSetStatusDisplay setStringValue:@"None"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Layer Mode Off"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)stemCancerPosition:(id)sender{
    if (stemCancerSet == 0){
        stemCancerSet = 1;
        [stemCancerDisplay setTextColor:[NSColor redColor]];
        [stemCancerDisplay setStringValue:@"Stem"];
    }
    else if (stemCancerSet == 1){
        stemCancerSet = 0;
        [stemCancerDisplay setTextColor:[NSColor blackColor]];
        [stemCancerDisplay setStringValue:@"Stem"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)growthCancerPosition:(id)sender{
    if (growthCancerSet == 0){
        growthCancerSet = 1;
        [growthCancerDisplay setTextColor:[NSColor redColor]];
        [growthCancerDisplay setStringValue:@"Growth"];
    }
    else if (growthCancerSet == 1){
        growthCancerSet = 0;
        [growthCancerDisplay setTextColor:[NSColor blackColor]];
        [growthCancerDisplay setStringValue:@"Growth"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)diffrentCancerPosition:(id)sender{
    if (differentCancerSet == 0){
        differentCancerSet = 1;
        [diffrentCancerDisplay setTextColor:[NSColor redColor]];
        [diffrentCancerDisplay setStringValue:@"Diff."];
    }
    else if (differentCancerSet == 1){
        differentCancerSet = 0;
        [diffrentCancerDisplay setTextColor:[NSColor blackColor]];
        [diffrentCancerDisplay setStringValue:@"Diff."];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)cellDeathCancerPosition:(id)sender{
    if (deathLayerCancerSet == 0){
        deathLayerCancerSet = 1;
        [cellDeathCancerDisplay setTextColor:[NSColor redColor]];
        [cellDeathCancerDisplay setStringValue:@"Death"];
    }
    else if (deathLayerCancerSet == 1){
        deathLayerCancerSet = 0;
        [cellDeathCancerDisplay setTextColor:[NSColor blackColor]];
        [cellDeathCancerDisplay setStringValue:@"Death"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)microenvironmentSet:(id)sender{
    if (microenvironmentStatus == 0){
        microenvironmentStatus = 1;
        [microenvironmentStatusDisplay setStringValue:@"On"];
    }
    else if (microenvironmentStatus == 1){
        microenvironmentStatus = 0;
        [microenvironmentStatusDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)repeatSet:(id)sender{
    if (repeatType == 0){
        repeatType = 1;
        [repeatTypeDisplay setStringValue:@"Ext/Frq"];
    }
    else if (repeatType == 1){
        repeatType = 0;
        [repeatTypeDisplay setStringValue:@"% Cancer"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)skipSave3DSet:(id)sender{
    if (skipSave3DHold == 0){
        skipSave3DHold = 1;
        [skipSave3DDisplay setStringValue:@"Yes"];
    }
    else if (skipSave3DHold == 1){
        skipSave3DHold = 0;
        [skipSave3DDisplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)skipSaveEnvSet:(id)sender{
    if (skipSaveEnvHold == 0){
        skipSaveEnvHold = 1;
        [skipSaveEnvDisplay setStringValue:@"Yes"];
    }
    else if (skipSaveEnvHold == 1){
        skipSaveEnvHold = 0;
        [skipSaveEnvDisplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)skipSaveLayerSet:(id)sender{
    if (skipSaveLayerHold == 0){
        skipSaveLayerHold = 1;
        [skipSaveLayerDisplay setStringValue:@"Yes"];
    }
    else if (skipSaveLayerHold == 1){
        skipSaveLayerHold = 0;
        [skipSaveLayerDisplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)heatConversionSet:(id)sender{
    if (heatConversionHold == 0){
        heatConversionHold = 1;
        [heatConversionDisplay setStringValue:@"Yes"];
    }
    else if (heatConversionHold == 1){
        heatConversionHold = 0;
        [heatConversionDisplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(int)nameCheck{
    int errorFlag = 0;
    string newAnalysisID = destinationName;
    
    if (newAnalysisID.length() < 4 || newAnalysisID.length() > 15) errorFlag = 1;
    if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
    if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
    
    return errorFlag;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToConditionFor3DSim object:nil];
}

@end
