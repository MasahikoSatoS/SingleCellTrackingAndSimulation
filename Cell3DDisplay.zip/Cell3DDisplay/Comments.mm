//
//  Comments.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-07-04.
//

#import "Comments.h"

NSString *notificationToComments = @"notificationExecuteComments";

@implementation Comments

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToComments object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    commentsController = [[NSWindowController alloc] initWithWindowNibName:@"CommentsSetting"];
    [commentsController showWindow:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [commentsWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [commentsWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)closeWindow:(id)sender{
    [commentsWindow orderOut:self];
    commentsOperation = 2;
    commentsTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (commentsOperation == 3){
        [commentsWindow makeKeyAndOrderFront:self];
        commentsOperation = 1;
        [commentsTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToComments object:nil];
}

@end
