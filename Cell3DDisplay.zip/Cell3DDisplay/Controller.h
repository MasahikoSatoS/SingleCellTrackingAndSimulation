//
//  Controller.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2022-12-31.
//

#ifndef CONTROLLER_H
#define CONTROLLER_H
#import <Cocoa/Cocoa.h>
#import "SourceSAT.h"
#import "TableDisplay.h"
#import "DataInput.h"
#import "ConditionFor3DSim.h"
#import "ConditionFor3DSimController.h"
#import "Message.h"
#import "DataExport.h"
#include <iostream>
#include <dirent.h>
#include <sys/stat.h>
#include <fstream>
#include <sstream>
#include <math.h>
#endif

using namespace std;

extern NSString *notificationToTable;
extern NSString *notificationToDataInput;
extern NSString *notificationToConditionFor3DSimController;
extern NSString *notificationToConditionFor3DSim;
extern NSString *notificationToMessage;
extern NSString *notificationToComments;

extern string pathNameString; //Path name
extern string trackDataFolderPath; //Track data path
extern string analysisDataFolderPath; //Analysis data path
extern string seriesName; //Series name
extern string analysisID; //Analysis ID
extern string treatName; //Treat name

extern string *arrayDirectoryInfo; //For file sorting
extern int directoryInfoCount;
extern int directoryInfoLimit;

extern int sourceStatusHold; //Source/Analysis status hold
extern int firstReadFlag; //First array set flag
extern int lineageDataEntryCount; //No of entered lineage data

extern int **arrayLineageData; //Hold Lineage data
extern unsigned long *arrayLineageDataEntryHold; //Hold no of Lineage data entry
extern int **arrayIFData; //Hold IF data, value and area, original
extern int *arrayIFDataEntryHold; //Hold IF data, no of value and area, original, entry hold
extern int **arrayIFTimeLineData; //IF data, time point sorted
extern int *arrayIFTimeLineDataEntryHold; //IF data, time point sorted, entry hold
extern string **arrayTableMain; //Main table info
extern int *arrayTableMainHold; //Main Table Entry no Hold
extern int **arrayIfTimeStatus; //IF Time Status, 0, inc., 1: exc.
extern int *arrayIfTimeStatusHold; //Hold number of entry of arrayIfTimeStatus
extern int **arrayAreaData; //Area data
extern int *arrayAreaDataHold; //Hold Number of Entry

extern string **arrayLineageDataType; //Hold Type Definition
extern string **arrayLineageFluorescentDataType; //Hold Type Definition
extern int lineageFluorescentDataTypeEntryCount;
extern int lineageFluorescentDataTypeEntryLimit;

extern int initialArraySet; //Array set status hold
extern int tableViewCall;
extern int tableCurrentRowHold; //Table control
extern int tableCallCount; //Table control
extern int rowIndexHold; //Table control

extern int videoImageSizeHold; //Video image size
extern int timePointMaxHold; //Video image size

extern string IDNameHold; //ID name
extern string destinationName; //Destination name name

extern int conditionFor3DSimControllerOperation; //Window operation
extern int commentsOperation; //Window operation

extern CGFloat *arrayColorRange; //Color range Heat map
extern CGFloat *arrayColorRange2; //Color range manual set
extern int colorNoSimHold; //Color set no
extern int *colorNumberHold; //Color no hold array

extern int animationMode; //Animation mode, sphere, box, layer
extern int lingColorSetStatus; //Lineage color set
extern int dataMainTimeOne; //Animation time one
extern int dataMainTimeSpecific; //Animation specific time
extern int stemSetStatus; //Stem status, layer or crypt

extern int stemCancerSet; //Cancer set at stem
extern int growthCancerSet; //Cancer set at growth
extern int differentCancerSet; //Cancer set at diff
extern int deathLayerCancerSet; //Cancer set at death
extern double *dimensionListLayer2; //Dimension layer array
extern double *dimensionListLayerHold; //Dimension layer hold array

extern int microenvironmentStatus; //Microenvironment status
extern int processStop; //Stop process
extern int messageSend; //For message display
extern int messageSend2; //For message display
extern int mainProcessOn; //Set when main process is ON
extern int zFullLength; //Set when main process is ON
extern int processingNo; //Time point under the processing
extern int repeatNo; //Processing repeat
extern int repeatType; //Processing repeat
extern int totalRepeat; //Processing repeat
extern int repeatNoCurrent; //Processing repeat
extern int exportStatus; //Export Status
extern string dataSavePath; //Data save path

extern string ascIIstring; //AscII string

extern int necrosisFoundMonitor; //Monitor for necrosis
extern int supFoundMonitor; //Monitor for Sup
extern int promFoundMonitor; //Monitor for Prom
extern int killFoundMonitor; //Monitor for Kill
extern int fuseFoundMonitor; //Monitor for Fuse
extern int restrainFoundMonitor; //Monitor for restrain
extern int firstChoiceMonitor; //Monitor for First Choice
extern int secondChoiceMonitor; //Monitor for Second Choice

extern string *listArray; //Multiple process list
extern int listArrayCount; //Multiple process list count
extern int listArrayEachEntry; //Multiple process entry
extern int listArrayStatus; //Multiple process status
extern int listMode; //Multiple process mode
extern int listCurrentCount; //Multiple process current
extern int listTotal; //Multiple process total

extern int skipSave3DHold; //Skip set 3D
extern int skipSaveEnvHold; //Skip set Env
extern int skipSaveLayerHold; //Skip set Layer
extern int heatConversionHold; //Skip set heat conversion

@interface Controller : NSObject{
    IBOutlet NSTextField *inputIDSetDisplay;
    IBOutlet NSTextField *inputIDDisplay;
    IBOutlet NSTextField *videoImageSizeDisplay;
    IBOutlet NSTextField *specificTimeDisplay;
    IBOutlet NSTextField *processingRepeatDisplay;
    IBOutlet NSTextField *listStatusDisplay;
    IBOutlet NSTextField *listSetDisplay;
    
    IBOutlet NSBrowser *listBrowser;
    id sourceSAT;
}

//List Array Format
//Column 1: A%, Column 2: Value etc

//Mac text file
//Heading:ID
//List of ID
//Heading:Suppression
//List of Suppression
//Heading: Promotion
//List of Promotion
//Heading: Kill
//List of Kill
//END

-(id)init;
-(void)directoryInfoUpDate;
-(int)nameCheck;
-(void)create3DDataMain:(int)videoSizeTemp;
-(int*)trajectory:(int)positionInitX :(int)positionInitY :(int)positionInitX2 :(int)positionInitY2 :(int)typeValue :(int)dimensionListLayerCount2 :(int)imagePickUp :(int*)moveCellSelectCount;

-(IBAction)browserDoubleClick:(id)browser;
-(IBAction)clearSelect:(id)sender;
-(IBAction)quitAnalysis:(id)sender;
-(IBAction)create3DData:(id)sender;
-(IBAction)create3DDataTime1:(id)sender;
-(IBAction)create3DSavedData:(id)sender;
-(IBAction)create3DLoadData:(id)sender;
-(IBAction)conditionFor3DSimStart:(id)sender;
-(IBAction)inputIDSet:(id)sender;
-(IBAction)stopDataProcessing:(id)sender;
-(IBAction)directorySelect:(id)sender;
-(IBAction)listOn:(id)sender;
-(IBAction)listSelect:(id)sender;

@end
