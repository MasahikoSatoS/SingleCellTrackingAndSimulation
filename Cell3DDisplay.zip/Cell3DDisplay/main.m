//
//  main.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2022-12-30.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
