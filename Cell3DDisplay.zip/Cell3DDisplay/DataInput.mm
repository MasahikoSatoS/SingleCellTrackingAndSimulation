//
//  DataInput.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-06.
//

#import "DataInput.h"

NSString *notificationToDataInput = @"notificationExecuteDataInput";

@implementation DataInput

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDataInput object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [videoImageSizeDisplay setDelegate:self];
    [videoImageSizeDisplay setIntegerValue:500];
    [specificTimeDisplay setIntegerValue:1];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == videoImageSizeDisplay){
            videoImageSizeHold = [videoImageSizeDisplay intValue];
            
            if (videoImageSizeHold < 0){
                videoImageSizeHold = 0;
                [videoImageSizeDisplay setIntegerValue:0];
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDataInput object:nil];
}

@end
