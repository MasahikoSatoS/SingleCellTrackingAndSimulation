//
//  ConditionFor3DSim.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-12.
//

#ifndef CONDITIONFOR3DCIM_H
#define CONDITIONFOR3DCIM_H
#import "Controller.h"
#endif

@interface ConditionFor3DSim : NSObject{
    IBOutlet NSTextField *cellTypeADisplay1;
    IBOutlet NSTextField *cellTypeADisplay2;
    IBOutlet NSTextField *cellTypeADisplay3;
    IBOutlet NSTextField *cellTypeADisplay4;
    IBOutlet NSTextField *cellTypeADisplay5;
    IBOutlet NSTextField *cellTypeADisplay6;
    IBOutlet NSTextField *cellTypeADisplay7;
    IBOutlet NSTextField *cellTypeADisplay8;
    
    IBOutlet NSTextField *shapeDisplay1;
    IBOutlet NSTextField *shapeDisplay2;
    IBOutlet NSTextField *shapeDisplay3;
    IBOutlet NSTextField *shapeDisplay4;
    IBOutlet NSTextField *shapeDisplay5;
    IBOutlet NSTextField *shapeDisplay6;
    IBOutlet NSTextField *shapeDisplay7;
    IBOutlet NSTextField *shapeDisplay8;
    
    IBOutlet NSTextField *sizeDisplay1;
    IBOutlet NSTextField *sizeDisplay2;
    IBOutlet NSTextField *sizeDisplay3;
    IBOutlet NSTextField *sizeDisplay4;
    IBOutlet NSTextField *sizeDisplay5;
    IBOutlet NSTextField *sizeDisplay6;
    IBOutlet NSTextField *sizeDisplay7;
    IBOutlet NSTextField *sizeDisplay8;
    
    IBOutlet NSTextField *percentDisplay1;
    IBOutlet NSTextField *percentDisplay2;
    IBOutlet NSTextField *percentDisplay3;
    IBOutlet NSTextField *percentDisplay4;
    IBOutlet NSTextField *percentDisplay5;
    IBOutlet NSTextField *percentDisplay6;
    IBOutlet NSTextField *percentDisplay7;
    IBOutlet NSTextField *percentDisplay8;
    
    IBOutlet NSTextField *doublingTDisplay1;
    IBOutlet NSTextField *doublingTDisplay2;
    IBOutlet NSTextField *doublingTDisplay3;
    IBOutlet NSTextField *doublingTDisplay4;
    IBOutlet NSTextField *doublingTDisplay5;
    IBOutlet NSTextField *doublingTDisplay6;
    IBOutlet NSTextField *doublingTDisplay7;
    IBOutlet NSTextField *doublingTDisplay8;
    
    IBOutlet NSTextField *tdoublingGDisplay1;
    IBOutlet NSTextField *tdoublingGDisplay2;
    IBOutlet NSTextField *tdoublingGDisplay3;
    IBOutlet NSTextField *tdoublingGDisplay4;
    IBOutlet NSTextField *tdoublingGDisplay5;
    IBOutlet NSTextField *tdoublingGDisplay6;
    IBOutlet NSTextField *tdoublingGDisplay7;
    IBOutlet NSTextField *tdoublingGDisplay8;
    
    IBOutlet NSTextField *layerSDisplay1;
    IBOutlet NSTextField *layerSDisplay2;
    IBOutlet NSTextField *layerSDisplay3;
    IBOutlet NSTextField *layerSDisplay4;
    IBOutlet NSTextField *layerSDisplay5;
    IBOutlet NSTextField *layerSDisplay6;
    IBOutlet NSTextField *layerSDisplay7;
    IBOutlet NSTextField *layerSDisplay8;
    
    IBOutlet NSTextField *layerEDisplay1;
    IBOutlet NSTextField *layerEDisplay2;
    IBOutlet NSTextField *layerEDisplay3;
    IBOutlet NSTextField *layerEDisplay4;
    IBOutlet NSTextField *layerEDisplay5;
    IBOutlet NSTextField *layerEDisplay6;
    IBOutlet NSTextField *layerEDisplay7;
    IBOutlet NSTextField *layerEDisplay8;
    
    IBOutlet NSTextField *motADisplay1;
    IBOutlet NSTextField *motADisplay2;
    IBOutlet NSTextField *motADisplay3;
    IBOutlet NSTextField *motADisplay4;
    IBOutlet NSTextField *motADisplay5;
    IBOutlet NSTextField *motADisplay6;
    IBOutlet NSTextField *motADisplay7;
    IBOutlet NSTextField *motADisplay8;
    
    IBOutlet NSTextField *motBDisplay1;
    IBOutlet NSTextField *motBDisplay2;
    IBOutlet NSTextField *motBDisplay3;
    IBOutlet NSTextField *motBDisplay4;
    IBOutlet NSTextField *motBDisplay5;
    IBOutlet NSTextField *motBDisplay6;
    IBOutlet NSTextField *motBDisplay7;
    IBOutlet NSTextField *motBDisplay8;
    
    IBOutlet NSTextField *necDisplay1;
    IBOutlet NSTextField *necDisplay2;
    IBOutlet NSTextField *necDisplay3;
    IBOutlet NSTextField *necDisplay4;
    IBOutlet NSTextField *necDisplay5;
    IBOutlet NSTextField *necDisplay6;
    IBOutlet NSTextField *necDisplay7;
    IBOutlet NSTextField *necDisplay8;
    
    IBOutlet NSTextField *alphaDisplay1;
    IBOutlet NSTextField *alphaDisplay2;
    IBOutlet NSTextField *alphaDisplay3;
    IBOutlet NSTextField *alphaDisplay4;
    IBOutlet NSTextField *alphaDisplay5;
    IBOutlet NSTextField *alphaDisplay6;
    IBOutlet NSTextField *alphaDisplay7;
    IBOutlet NSTextField *alphaDisplay8;
    
    IBOutlet NSTextField *fluChDisplay1;
    IBOutlet NSTextField *fluChDisplay2;
    IBOutlet NSTextField *fluChDisplay3;
    IBOutlet NSTextField *fluChDisplay4;
    IBOutlet NSTextField *fluChDisplay5;
    IBOutlet NSTextField *fluChDisplay6;
    IBOutlet NSTextField *fluChDisplay7;
    IBOutlet NSTextField *fluChDisplay8;
    
    IBOutlet NSTextField *eventsDisplay1;
    IBOutlet NSTextField *eventsDisplay2;
    IBOutlet NSTextField *eventsDisplay3;
    IBOutlet NSTextField *eventsDisplay4;
    IBOutlet NSTextField *eventsDisplay5;
    IBOutlet NSTextField *eventsDisplay6;
    IBOutlet NSTextField *eventsDisplay7;
    IBOutlet NSTextField *eventsDisplay8;
    
    IBOutlet NSTextField *deathFreqDisplay1;
    IBOutlet NSTextField *deathFreqDisplay2;
    IBOutlet NSTextField *deathFreqDisplay3;
    IBOutlet NSTextField *deathFreqDisplay4;
    IBOutlet NSTextField *deathFreqDisplay5;
    IBOutlet NSTextField *deathFreqDisplay6;
    IBOutlet NSTextField *deathFreqDisplay7;
    IBOutlet NSTextField *deathFreqDisplay8;
    
    IBOutlet NSTextField *damageFreqDisplay1;
    IBOutlet NSTextField *damageFreqDisplay2;
    IBOutlet NSTextField *damageFreqDisplay3;
    IBOutlet NSTextField *damageFreqDisplay4;
    IBOutlet NSTextField *damageFreqDisplay5;
    IBOutlet NSTextField *damageFreqDisplay6;
    IBOutlet NSTextField *damageFreqDisplay7;
    IBOutlet NSTextField *damageFreqDisplay8;
    
    IBOutlet NSTextField *restrainDisplay1;
    IBOutlet NSTextField *restrainDisplay2;
    IBOutlet NSTextField *restrainDisplay3;
    IBOutlet NSTextField *restrainDisplay4;
    IBOutlet NSTextField *restrainDisplay5;
    IBOutlet NSTextField *restrainDisplay6;
    IBOutlet NSTextField *restrainDisplay7;
    IBOutlet NSTextField *restrainDisplay8;
    
    IBOutlet NSTextField *modeDisplay;
    IBOutlet NSTextField *concentrateDisplay;
    IBOutlet NSTextField *totalNumberCellDisplay;
    IBOutlet NSTextField *switchTimeDisplay;
    IBOutlet NSTextField *turnoverDisplay;
    IBOutlet NSTextField *nucSizeDisplay;
    IBOutlet NSTextField *simTimeDisplay;
    IBOutlet NSTextField *xyExpandDisplay;
    IBOutlet NSTextField *zExpandDisplay;
    IBOutlet NSTextField *xSiftDisplay;
    IBOutlet NSTextField *yShiftDisplay;
    IBOutlet NSTextField *zDistanceDisplay;
    IBOutlet NSTextField *belowExpandDisplay;
    IBOutlet NSTextField *aboveExpandDisplay;
    IBOutlet NSTextField *concentrateRadiusDisplay;
    IBOutlet NSTextField *damageTimeDisplay;
    IBOutlet NSTextField *damageTimeEveryDisplay;
    IBOutlet NSTextField *lingStatusDisplay;
    IBOutlet NSTextField *necrosisCountDisplay;
    IBOutlet NSTextField *cryptStemDisplay;
    IBOutlet NSTextField *layerStemCountDisplay;
    IBOutlet NSTextField *imagePickUpFreqDisplay;
    IBOutlet NSTextField *cryptStemZNoDisplay;
    IBOutlet NSTextField *cryptDivZNoDisplay;
    IBOutlet NSTextField *cryptDifZDisplay;
    IBOutlet NSTextField *stemSetStatusDisplay;
    
    IBOutlet NSTextField *stemCancerDisplay;
    IBOutlet NSTextField *growthCancerDisplay;
    IBOutlet NSTextField *diffrentCancerDisplay;
    IBOutlet NSTextField *cellDeathCancerDisplay;
    IBOutlet NSTextField *microenvironmentStatusDisplay;
    IBOutlet NSTextField *noOfGrowthDivDisplay;
    
    IBOutlet NSTextField *percentInCancerDisplay1;
    IBOutlet NSTextField *percentInCancerDisplay2;
    IBOutlet NSTextField *percentInCancerDisplay3;
    IBOutlet NSTextField *percentInCancerDisplay4;
    
    IBOutlet NSTextField *percentInCancerEndDisplay1;
    IBOutlet NSTextField *percentInCancerEndDisplay2;
    IBOutlet NSTextField *percentInCancerEndDisplay3;
    IBOutlet NSTextField *percentInCancerEndDisplay4;
    
    IBOutlet NSTextField *doubleInCancerDisplay1;
    IBOutlet NSTextField *doubleInCancerDisplay2;
    IBOutlet NSTextField *doubleInCancerDisplay3;
    IBOutlet NSTextField *doubleInCancerDisplay4;
    
    IBOutlet NSTextField *extInCancerDisplay1;
    IBOutlet NSTextField *extInCancerDisplay2;
    IBOutlet NSTextField *extInCancerDisplay3;
    IBOutlet NSTextField *extInCancerDisplay4;
    
    IBOutlet NSTextField *extInCancerEndDisplay1;
    IBOutlet NSTextField *extInCancerEndDisplay2;
    IBOutlet NSTextField *extInCancerEndDisplay3;
    IBOutlet NSTextField *extInCancerEndDisplay4;
    
    IBOutlet NSTextField *motInCancerDisplay1;
    IBOutlet NSTextField *motInCancerDisplay2;
    IBOutlet NSTextField *motInCancerDisplay3;
    IBOutlet NSTextField *motInCancerDisplay4;
    
    IBOutlet NSTextField *shapeInCancerDisplay1;
    IBOutlet NSTextField *shapeInCancerDisplay2;
    IBOutlet NSTextField *shapeInCancerDisplay3;
    IBOutlet NSTextField *shapeInCancerDisplay4;
    
    IBOutlet NSTextField *FluoCancerDisplay1;
    IBOutlet NSTextField *FluoCancerDisplay2;
    IBOutlet NSTextField *FluoCancerDisplay3;
    IBOutlet NSTextField *FluoCancerDisplay4;
    
    IBOutlet NSTextField *infPerCancerDisplay1;
    IBOutlet NSTextField *infPerCancerDisplay2;
    IBOutlet NSTextField *infPerCancerDisplay3;
    IBOutlet NSTextField *infPerCancerDisplay4;
    
    IBOutlet NSTextField *sizeInCancerDisplay;
    IBOutlet NSTextField *alphaInCancerDisplay;
    
    IBOutlet NSTextField *fusedDoubleInCancerDisplay;
    IBOutlet NSTextField *fusedMotInCancerDisplay;
    
    IBOutlet NSTextField *movementCancerDisplay;
    IBOutlet NSTextField *movementLayerDisplay;
    IBOutlet NSTextField *necrosisInitDisplay;
    
    IBOutlet NSTextField *FluorescentDamageDisplay;
    IBOutlet NSTextField *repeatTypeDisplay;
    
    IBOutlet NSTextField *envSearchDisplay;
    IBOutlet NSTextField *restrainSearchDisplay;
    
    IBOutlet NSTextField *skipSave3DDisplay;
    IBOutlet NSTextField *skipSaveEnvDisplay;
    IBOutlet NSTextField *skipSaveLayerDisplay;
    IBOutlet NSTextField *heatConversionDisplay;
    
    IBOutlet NSButton *baseColorButton;
    
    IBOutlet NSButton *cccolorButton1;
    IBOutlet NSButton *cccolorButton2;
    IBOutlet NSButton *cccolorButton3;
    IBOutlet NSButton *cccolorButton4;
    IBOutlet NSButton *cccolorButton5;
    IBOutlet NSButton *cccolorButton6;
    IBOutlet NSButton *cccolorButton7;
    IBOutlet NSButton *cccolorButton8;
    
    IBOutlet NSButton *eccolorButton1;
    IBOutlet NSButton *eccolorButton2;
    IBOutlet NSButton *eccolorButton3;
    IBOutlet NSButton *eccolorButton4;
    IBOutlet NSButton *eccolorButton5;
    IBOutlet NSButton *eccolorButton6;
    IBOutlet NSButton *eccolorButton7;
    IBOutlet NSButton *eccolorButton8;
    
    IBOutlet NSButton *fccolorButton1;
    IBOutlet NSButton *fccolorButton2;
    IBOutlet NSButton *fccolorButton3;
    IBOutlet NSButton *fccolorButton4;
    IBOutlet NSButton *fccolorButton5;
    IBOutlet NSButton *fccolorButton6;
    IBOutlet NSButton *fccolorButton7;
    IBOutlet NSButton *fccolorButton8;
    
    IBOutlet NSButton *nccolorButton1;
    IBOutlet NSButton *nccolorButton2;
    IBOutlet NSButton *nccolorButton3;
    IBOutlet NSButton *nccolorButton4;
    IBOutlet NSButton *nccolorButton5;
    IBOutlet NSButton *nccolorButton6;
    IBOutlet NSButton *nccolorButton7;
    IBOutlet NSButton *nccolorButton8;
    
    IBOutlet NSButton *rccolorButton1;
    IBOutlet NSButton *rccolorButton2;
    IBOutlet NSButton *rccolorButton3;
    IBOutlet NSButton *rccolorButton4;
    
    IBOutlet NSButton *ccInCancerButton1;
    IBOutlet NSButton *ccInCancerButton2;
    IBOutlet NSButton *ccInCancerButton3;
    IBOutlet NSButton *ccInCancerButton4;
    
    IBOutlet NSButton *ncInCancerButton;
}

-(id)init;
-(void)dealloc;
-(int)nameCheck;

-(IBAction)saveData:(id)sender;
-(IBAction)refreshData:(id)sender;
-(IBAction)modeChange:(id)sender;
-(IBAction)parameterLoad:(id)sender;
-(IBAction)parameterExport:(id)sender;
-(IBAction)parameterImport:(id)sender;
-(IBAction)lingColorSet:(id)sender;

-(IBAction)color1Set:(id)sender;
-(IBAction)color2Set:(id)sender;
-(IBAction)color3Set:(id)sender;
-(IBAction)color4Set:(id)sender;
-(IBAction)color5Set:(id)sender;
-(IBAction)color6Set:(id)sender;
-(IBAction)color7Set:(id)sender;
-(IBAction)color8Set:(id)sender;
-(IBAction)color9Set:(id)sender;
-(IBAction)color10Set:(id)sender;
-(IBAction)color11Set:(id)sender;
-(IBAction)color12Set:(id)sender;
-(IBAction)color13Set:(id)sender;
-(IBAction)color14Set:(id)sender;
-(IBAction)color15Set:(id)sender;
-(IBAction)color16Set:(id)sender;

-(IBAction)cccolorSet1:(id)sender;
-(IBAction)cccolorSet2:(id)sender;
-(IBAction)cccolorSet3:(id)sender;
-(IBAction)cccolorSet4:(id)sender;
-(IBAction)cccolorSet5:(id)sender;
-(IBAction)cccolorSet6:(id)sender;
-(IBAction)cccolorSet7:(id)sender;
-(IBAction)cccolorSet8:(id)sender;

-(IBAction)fccolorSet1:(id)sender;
-(IBAction)fccolorSet2:(id)sender;
-(IBAction)fccolorSet3:(id)sender;
-(IBAction)fccolorSet4:(id)sender;
-(IBAction)fccolorSet5:(id)sender;
-(IBAction)fccolorSet6:(id)sender;
-(IBAction)fccolorSet7:(id)sender;
-(IBAction)fccolorSet8:(id)sender;

-(IBAction)eccolorSet1:(id)sender;
-(IBAction)eccolorSet2:(id)sender;
-(IBAction)eccolorSet3:(id)sender;
-(IBAction)eccolorSet4:(id)sender;
-(IBAction)eccolorSet5:(id)sender;
-(IBAction)eccolorSet6:(id)sender;
-(IBAction)eccolorSet7:(id)sender;
-(IBAction)eccolorSet8:(id)sender;

-(IBAction)nccolorSet1:(id)sender;
-(IBAction)nccolorSet2:(id)sender;
-(IBAction)nccolorSet3:(id)sender;
-(IBAction)nccolorSet4:(id)sender;
-(IBAction)nccolorSet5:(id)sender;
-(IBAction)nccolorSet6:(id)sender;
-(IBAction)nccolorSet7:(id)sender;
-(IBAction)nccolorSet8:(id)sender;

-(IBAction)rccolorSet1:(id)sender;
-(IBAction)rccolorSet2:(id)sender;
-(IBAction)rccolorSet3:(id)sender;
-(IBAction)rccolorSet4:(id)sender;

-(IBAction)ccInCancerSet1:(id)sender;
-(IBAction)ccInCancerSet2:(id)sender;
-(IBAction)ccInCancerSet3:(id)sender;
-(IBAction)ccInCancerSet4:(id)sender;

-(IBAction)ncInCancerSet:(id)sender;

-(IBAction)stemSet:(id)sender;

-(IBAction)stemCancerPosition:(id)sender;
-(IBAction)growthCancerPosition:(id)sender;
-(IBAction)diffrentCancerPosition:(id)sender;
-(IBAction)cellDeathCancerPosition:(id)sender;
-(IBAction)microenvironmentSet:(id)sender;
-(IBAction)repeatSet:(id)sender;

-(IBAction)skipSave3DSet:(id)sender;
-(IBAction)skipSaveEnvSet:(id)sender;
-(IBAction)skipSaveLayerSet:(id)sender;
-(IBAction)heatConversionSet:(id)sender;

@end
