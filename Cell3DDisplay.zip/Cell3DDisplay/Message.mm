//
//  Message.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-07-03.
//

#import "Message.h"

NSString *notificationToMessage = @"notificationExecuteConditionForMessage";

@implementation Message

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMessage object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    conditionFor3DSimTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (messageSend == 1){
        messageSend = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Parameter Table Entry/No B Entry for Layer/No S Entry For Box/Sphere"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (messageSend == 2){
        messageSend = 0;
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Imaging Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (messageSend == 3){
        messageSend = 0;
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Image size: 500-10000"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else if (messageSend == 4){
        messageSend = 0;
        [zLengthDisplay setIntegerValue:zFullLength];
    }
    else if (messageSend == 5){
        messageSend = 0;
        [totalRepeatDisplay setIntegerValue:totalRepeat];
        [repeatNoDisplay setIntegerValue:repeatNoCurrent];
    }
    else if (messageSend == 6){
        messageSend = 0;
        [necrosisCountDisplay setIntegerValue:necrosisFoundMonitor];
    }
    else if (messageSend == 7){
        messageSend = 0;
        
        if (supFoundMonitor != 0 || promFoundMonitor != 0 || killFoundMonitor != 0 || fuseFoundMonitor != 0){
            [supCountDisplay setIntegerValue:supFoundMonitor];
            [promCountDisplay setIntegerValue:promFoundMonitor];
            [killCountDisplay setIntegerValue:killFoundMonitor];
            [fuseCountDisplay setIntegerValue:fuseFoundMonitor];
            [firstChoiceDisplay setIntegerValue:firstChoiceMonitor];
            [secondChoiceDisplay setIntegerValue:secondChoiceMonitor];
        }
    }
    else if (messageSend == 8){
        messageSend = 0;
        
        if (restrainFoundMonitor != 0){
            [restrainCountDisplay setIntegerValue:restrainFoundMonitor];
        }
    }
    
    if (messageSend2 == 9){
        messageSend2 = 0;
        
        [listCurrentDisplay setIntegerValue:listCurrentCount];
        [listTotalDisplay setIntegerValue:listTotal];
    }
    
    if (processingNo != -1){
        if (processingNo != 1000000){
            [timePointDisplay setIntegerValue:processingNo];
        }
        else if (processingNo == 1000000){
            [timePointDisplay setStringValue:@"nil"];
        }
        
        processingNo = -1;
    }
    
    if (exportStatus == 1){
        exportStatus = -1;
        [backSave startAnimation:self];
    }
    else if (exportStatus == 2){
        exportStatus = 0;
        [backSave stopAnimation:self];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMessage object:nil];
}

@end
