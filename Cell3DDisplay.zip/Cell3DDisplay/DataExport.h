//
//  DataExport.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-07-10.
//

#ifndef DATAEXPORT_H
#define DATAEXPORT_H
#import "Controller.h"
#endif

@interface DataExport : NSObject{
}

-(IBAction)exportDataMain:(id)sender;
-(IBAction)exportHeat:(id)sender;
-(IBAction)exportLineage:(id)sender;
-(int)ascIICode:(int*)arrayAscIIintData;

@end
