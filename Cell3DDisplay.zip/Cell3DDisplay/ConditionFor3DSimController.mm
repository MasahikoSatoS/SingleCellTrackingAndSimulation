//
//  ConditionFor3DSimController.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-12.
//

#import "ConditionFor3DSimController.h"

NSString *notificationToConditionFor3DSimController = @"notificationExecuteConditionFor3DSimController";

@implementation ConditionFor3DSimController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToConditionFor3DSimController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    conditionFor3DSimController = [[NSWindowController alloc] initWithWindowNibName:@"ConditionSetting"];
    [conditionFor3DSimController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToConditionFor3DSim object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [conditionFor3DSimWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [conditionFor3DSimWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
}

-(IBAction)closeWindow:(id)sender{
    [conditionFor3DSimWindow orderOut:self];
    conditionFor3DSimControllerOperation = 2;
    conditionFor3DSimTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (conditionFor3DSimControllerOperation == 3){
        [conditionFor3DSimWindow makeKeyAndOrderFront:self];
        conditionFor3DSimControllerOperation = 1;
        [conditionFor3DSimTimer invalidate];
    }
}

-(IBAction)commentsStart:(id)sender{
    if (commentsOperation == 0){
        commentsOperation = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToComments object:self];
    }
    
    if (commentsOperation == 2) commentsOperation = 3;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToConditionFor3DSimController object:nil];
}

@end
