//
//  SourceSAT.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-01-01.
//

#ifndef SOURCESAT_H
#define SOURCESAT_H
#import "Controller.h"
#endif

@interface SourceSAT : NSObject{
}

-(void)sourceMain;
-(void)lineageFluorescentDataTypeUpDate;

@end
