//
//  Message.h
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2023-07-03.
//

#ifndef MESSAGE_H
#define MESSAGE_H
#import "Controller.h"
#endif

@interface Message : NSObject{
    IBOutlet NSTextField *zLengthDisplay;
    IBOutlet NSTextField *timePointDisplay;
    IBOutlet NSTextField *totalRepeatDisplay;
    IBOutlet NSTextField *repeatNoDisplay;
    
    IBOutlet NSTextField *necrosisCountDisplay;
    IBOutlet NSTextField *supCountDisplay;
    IBOutlet NSTextField *promCountDisplay;
    IBOutlet NSTextField *killCountDisplay;
    IBOutlet NSTextField *fuseCountDisplay;
    IBOutlet NSTextField *restrainCountDisplay;
    IBOutlet NSTextField *firstChoiceDisplay;
    IBOutlet NSTextField *secondChoiceDisplay;
    IBOutlet NSTextField *listCurrentDisplay;
    IBOutlet NSTextField *listTotalDisplay;
    
    IBOutlet NSProgressIndicator *backSave;
    
    NSTimer *conditionFor3DSimTimer2;
}

-(id)init;
-(void)dealloc;

-(void)display;

@end
