//
//  CellDisplayControl.m
//  Cell3DDisplay
//
//  Created by Masahiko Sato on 2022-12-31.
//

#import "CellDisplayControl.h"

@implementation CellDisplayControl{
    SCNNode *cameraNode;
    
    int timePointPosition;
    NSUInteger touchCount;
    
    CGFloat positionX;
    CGFloat positionY;
    CGFloat positionZ;
    
    CGFloat rotationX;
    CGFloat rotationY;
    CGFloat rotationZ;
    CGFloat rotationW;
    
    CGFloat orientationX;
    CGFloat orientationY;
    CGFloat orientationZ;
    CGFloat orientationW;
    
    CGFloat scaleX;
    CGFloat scaleY;
    CGFloat scaleZ;
    
    CGFloat positionXTemp;
    CGFloat positionYTemp;
    CGFloat positionZTemp;
    
    CGFloat rotationXTemp;
    CGFloat rotationYTemp;
    CGFloat rotationZTemp;
    CGFloat rotationWTemp;
    
    CGFloat orientationXTemp;
    CGFloat orientationYTemp;
    CGFloat orientationZTemp;
    CGFloat orientationWTemp;
    
    CGFloat axeLength;
    
    int imageSizeTemp;
    int maxTimePoint;
    int sphereDisplayOnOff;
    int exportStatus;
    int exportStop;
    int startTimeExport;
    int currentTimePointHold;
    
    char savePath2 [1000];
    char exportPath2 [1000];
    char exportFilePath2 [1000];
    
    double totalSize;
}

- (void) awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [controller frame];
    
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 20;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    [controller setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    SCNScene *cellScene = [SCNScene sceneNamed:@"CellBaseScene.scn"];
    
    SCNSphere *cell = [SCNSphere sphereWithRadius:0.8];
    cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:0 green:0 blue:1 alpha:0.2];
    SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
    cellNode.position = SCNVector3Make(0, 0, 0);
    cellNode.geometry.firstMaterial.diffuse.contents = @"images.jpeg";
    [[cellScene rootNode] addChildNode:cellNode];
    
    positionX = 0;
    positionY = 0;
    positionZ = 5;
    
    rotationX = 0;
    rotationY = 0;
    rotationZ = 0;
    rotationW = 0;
    
    orientationX = 0;
    orientationY = 0;
    orientationZ = 0;
    orientationW = 1;
    
    scaleX = 1;
    scaleY = 1;
    scaleZ = 1;
    
    positionXTemp = 0;
    positionYTemp = 0;
    positionZTemp = 5;
    
    rotationXTemp = 0;
    rotationYTemp = 0;
    rotationZTemp = 0;
    rotationWTemp = 0;
    
    orientationXTemp = 0;
    orientationYTemp = 0;
    orientationZTemp = 0;
    orientationWTemp = 1;
    exportStatus = 0;
    exportStop = 0;
    startTimeExport = 1;
    currentTimePointHold = 0;
    
    axeLength = 5.0;
    
    [positionXDisplay setDoubleValue:positionXTemp];
    [positionYDisplay setDoubleValue:positionYTemp];
    [positionZDisplay setDoubleValue:positionZTemp];
    [rotationXDisplay setDoubleValue:rotationXTemp];
    [rotationYDisplay setDoubleValue:rotationYTemp];
    [rotationZDisplay setDoubleValue:rotationZTemp];
    [rotationWDisplay setDoubleValue:rotationWTemp];
    [orientationXDisplay setDoubleValue:orientationXTemp];
    [orientationYDisplay setDoubleValue:orientationYTemp];
    [orientationZDisplay setDoubleValue:orientationZTemp];
    [orientationWDisplay setDoubleValue:orientationWTemp];
    [scaleXDisplay setDoubleValue:scaleX];
    [scaleYDisplay setDoubleValue:scaleY];
    [scaleZDisplay setDoubleValue:scaleZ];
    
    cameraNode = [[SCNNode alloc] init];
    cameraNode.camera = [SCNCamera camera];
    cameraNode.position = SCNVector3Make(0, 0, 5);
    cameraNode.rotation = SCNVector4Make(0, 0, 0, 0);
    cameraNode.orientation = SCNVector4Make(0, 0, 0, 1);
    cameraNode.scale = SCNVector3Make(1, 1, 1);
    
    [[cellScene rootNode] addChildNode:cameraNode];
    
    SCNVector3 positions [] = {
        SCNVector3Make(0.0, 0.0, 0.0),
        SCNVector3Make(2.0, 0.0, 0.0)
    };
    
    int indices [] = {0, 1};
    
    SCNGeometrySource *vertexSource = [SCNGeometrySource geometrySourceWithVertices:positions count:2];
    NSData *indexData = [NSData dataWithBytes:indices length:sizeof(indices)];
    SCNGeometryElement *element = [SCNGeometryElement geometryElementWithData:indexData primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
    
    SCNGeometry *line = [SCNGeometry geometryWithSources:@[vertexSource] elements:@[element]];
    SCNMaterial * material = [SCNMaterial material];
    material.diffuse.contents = [[NSColor greenColor] colorWithAlphaComponent:1.0f];
    line.materials = @[material];
    
    SCNNode *lineNode = [SCNNode nodeWithGeometry:line];
    [[cellScene rootNode] addChildNode:lineNode];
    
    SCNVector3 positions2 [] = {
        SCNVector3Make(0.0, 0.0, 0.0),
        SCNVector3Make(0.0, 2.0, 0.0)
    };
    
    int indices2 [] = {0, 1};
    
    SCNGeometrySource *vertexSource2 = [SCNGeometrySource geometrySourceWithVertices:positions2 count:2];
    NSData *indexData2 = [NSData dataWithBytes:indices2 length:sizeof(indices2)];
    SCNGeometryElement *element2 = [SCNGeometryElement geometryElementWithData:indexData2 primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
    
    SCNGeometry *line2 = [SCNGeometry geometryWithSources:@[vertexSource2] elements:@[element2]];
    SCNMaterial * material2 = [SCNMaterial material];
    material2.diffuse.contents = [[NSColor blueColor] colorWithAlphaComponent:1.0f];
    line2.materials = @[material2];
    
    SCNNode *lineNode2 = [SCNNode nodeWithGeometry:line2];
    [[cellScene rootNode] addChildNode:lineNode2];
    
    SCNVector3 positions3 [] = {
        SCNVector3Make(0.0, 0.0, 0.0),
        SCNVector3Make(0.0, 0.0, 2.0)
    };
    
    int indices3 [] = {0, 1};
    
    SCNGeometrySource *vertexSource3 = [SCNGeometrySource geometrySourceWithVertices:positions3 count:2];
    NSData *indexData3 = [NSData dataWithBytes:indices3 length:sizeof(indices3)];
    SCNGeometryElement *element3 = [SCNGeometryElement geometryElementWithData:indexData3 primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
    
    SCNGeometry *line3 = [SCNGeometry geometryWithSources:@[vertexSource3] elements:@[element3]];
    SCNMaterial * material3 = [SCNMaterial material];
    material3.diffuse.contents = [[NSColor redColor] colorWithAlphaComponent:1.0f];
    line3.materials = @[material3];
    
    SCNNode *lineNode3 = [SCNNode nodeWithGeometry:line3];
    [[cellScene rootNode] addChildNode:lineNode3];
    
    self.sceneView.scene = cellScene;
    self.sceneView.allowsCameraControl = YES;
    self.sceneView.pointOfView = cameraNode;
    
    timePointPosition = 1;
    imageSizeTemp = 0;
    maxTimePoint = 0;
    sphereDisplayOnOff = 0;
}

-(IBAction)exportAnimation:(id)sender{
    if (exportStatus == 0){
        exportStatus = 1;
        exportStop = 0;
        
        [exportStatusDisplay setStringValue:@"On"];
        
        NSString *folder = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Desktop"];
        
        startTimeExport = [exportStartDisplay intValue];
        
        if (startTimeExport <= 0) startTimeExport = 1;
        
        //NSLog(@"%@", folder);
        
        const char *folderPath = [folder UTF8String];
        
        char *extract1 = strstr(folderPath, "Users");
        char *extract2 = strstr(extract1, "/");
        int lengthOfString = (int)strlen(extract2);
        char extract3 [lengthOfString+10];
        strncpy(extract3, extract2+1, lengthOfString-1);
        
        char *string1  = strchr(extract3, '/');
        int index = (int)(string1-extract3);
        
        int lengthOfString2 = (int)strlen(extract3);
        char pathNameCString [lengthOfString2+10];
        strncpy(pathNameCString, extract3, index);
        pathNameCString [index] = '\0';
        
        lengthOfString2 = (int)strlen(pathNameCString);
        
        char savePath [7+lengthOfString2+58+19+10];
        strcpy(savePath, "/Users/");
        strcat(savePath, pathNameCString);
        strcat(savePath, "/Desktop/CLIA_LiveCell/09_Cell_Tracking_Analysis_Results/");
        
        strcpy(savePath2, savePath);
        
        //printf("%s \n", savePath2);
        
        char exportPath [7+lengthOfString2+34+10];
        strcpy(exportPath, "/Users/");
        strcat(exportPath, pathNameCString);
        strcat(exportPath, "/Desktop/CLIA_Results/Animation3D/");
        
        strcpy(exportPath2, exportPath);
        
        char parameterPath [7+lengthOfString2+52+10];
        strcpy(parameterPath, "/Users/");
        strcat(parameterPath, pathNameCString);
        strcat(parameterPath, "/Desktop/CLIA_LiveCell/11_System_Data/DataTemp3D.Dat");
        
        totalSize = 0;
        imageSizeTemp = 0;
        maxTimePoint = 0;
        
        FILE *dataParameter;
        
        dataParameter = fopen(parameterPath, "r");
        
        if (NULL == dataParameter) {
            totalSize = 500*500*500;
            maxTimePoint = 1;
        }
        else{
            
            fscanf(dataParameter,"%d", &imageSizeTemp);
            totalSize = imageSizeTemp*imageSizeTemp*imageSizeTemp;
            
            fscanf(dataParameter,"%d", &maxTimePoint);
            
            if (timePointPosition >= maxTimePoint) timePointPosition = maxTimePoint;
            
            fscanf(dataParameter, "%lf", &positionX);
            fscanf(dataParameter, "%lf", &positionY);
            fscanf(dataParameter, "%lf", &positionZ);
            fscanf(dataParameter, "%lf", &rotationX);
            fscanf(dataParameter, "%lf", &rotationY);
            fscanf(dataParameter, "%lf", &rotationZ);
            fscanf(dataParameter, "%lf", &rotationW);
            fscanf(dataParameter, "%lf", &orientationX);
            fscanf(dataParameter, "%lf", &orientationY);
            fscanf(dataParameter, "%lf", &orientationZ);
            fscanf(dataParameter, "%lf", &orientationW);
            fscanf(dataParameter, "%lf", &scaleX);
            fscanf(dataParameter, "%lf", &scaleY);
            fscanf(dataParameter, "%lf", &scaleZ);
            fscanf(dataParameter, "%lf", &axeLength);
            
            fclose(dataParameter);
            
            positionXTemp = positionX;
            positionYTemp = positionY;
            positionZTemp = positionZ;
            rotationXTemp = rotationX;
            rotationYTemp = rotationY;
            rotationZTemp = rotationZ;
            rotationWTemp = rotationW;
            orientationXTemp = orientationX;
            orientationYTemp = orientationY;
            orientationZTemp = orientationZ;
            orientationWTemp = orientationW;
        }
        
        //=========Destination folder create=========
        if (access(exportPath, F_OK) == -1) {
            mkdir(exportPath, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        }
        
        int folderFileNumberMax = 0;
        int lengthOfString5 = 0;
        
        DIR *dir;
        struct dirent *dent;
        
        dir = opendir(exportPath);
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                if(strstr(dent -> d_name, "AD") != NULL){
                    char *extract5 = strstr(dent -> d_name, "AD");
                    lengthOfString5 = (int)strlen(extract5);
                    
                    if (lengthOfString5 >= 3){
                        char extract6 [lengthOfString5+2];
                        strncpy(extract6, extract5+2, lengthOfString5);
                        
                        if (folderFileNumberMax < atoi(extract6)) folderFileNumberMax = atoi(extract6);
                    }
                }
            }
            
            closedir(dir);
        }
        
        folderFileNumberMax++;
        
        int numberLengthCheck = 0;
        
        if (folderFileNumberMax < 10) numberLengthCheck = 1;
        else if (folderFileNumberMax < 100) numberLengthCheck = 2;
        else if (folderFileNumberMax < 1000) numberLengthCheck = 3;
        else if (folderFileNumberMax < 10000) numberLengthCheck = 4;
        else if (folderFileNumberMax < 100000) numberLengthCheck = 5;
        
        int lengthOfString6 = (int)strlen(exportPath);
        char pathNameCString6 [lengthOfString6+1+14+numberLengthCheck];
        
        strcpy(pathNameCString6, exportPath);
        strcat(pathNameCString6, "Animation3D_AD");
        
        //printf("%s \n", pathNameCString6);
        
        char numberAddString [numberLengthCheck+1];
        sprintf(numberAddString, "%d", folderFileNumberMax);
        strcat(pathNameCString6, numberAddString);
        
        mkdir(pathNameCString6, S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        strcpy(exportFilePath2, pathNameCString6);
        
        [self cell3DExportProcessing];
        
        //printf("%s \n", pathNameCString6);
    }
    else if (exportStatus == 1){
        exportStatus = 0;
        exportStop = 1;
        [exportStatusDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)cell3DExportProcessing{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
        int terminationFlag = 0;
        int exportTime = self->startTimeExport;
        
        do{
            
            terminationFlag = 1;
            
            int timePoint = exportTime;
            char numberString [9];
            
            sprintf(numberString, "%d", timePoint);
            
            char numberForPath [10];
            
            if ((int)strlen(numberString) == 1){
                strcpy(numberForPath, "0000000");
                strcat(numberForPath, numberString);
            }
            else if ((int)strlen(numberString) == 2){
                strcpy(numberForPath, "000000");
                strcat(numberForPath, numberString);
            }
            else if ((int)strlen(numberString) == 3){
                strcpy(numberForPath, "00000");
                strcat(numberForPath, numberString);
            }
            else if ((int)strlen(numberString) == 4){
                strcpy(numberForPath, "0000");
                strcat(numberForPath, numberString);
            }
            else if ((int)strlen(numberString) == 5){
                strcpy(numberForPath, "000");
                strcat(numberForPath, numberString);
            }
            else if ((int)strlen(numberString) == 6){
                strcpy(numberForPath, "00");
                strcat(numberForPath, numberString);
            }
            else if ((int)strlen(numberString) == 7){
                strcpy(numberForPath, "0");
                strcat(numberForPath, numberString);
            }
            
            int savePathLength = (int)strlen(self->savePath2);
            
            char savePath3 [savePathLength+20];
            
            strcpy(savePath3, self->savePath2);
            strcat(savePath3, numberForPath);
            strcat(savePath3, "_3dTemp.Dat");
            
            int exportPathLength = (int)strlen(self->exportFilePath2);
            
            //printf("%d \n", exportPathLength);
            
            char exportPath3 [exportPathLength+50];
            
            strcpy(exportPath3, self->exportFilePath2);
            strcat(exportPath3, "/Animation3D-AD");
            strcat(exportPath3, numberForPath);
            strcat(exportPath3, ".tif");
            
            //printf("%f \n", self->totalSize);
            
            double *dataArrayFor3D = malloc((int)self->totalSize * sizeof(double));
            
            int entryCount = 0;
            
            FILE *dataPath3D;
            double numberTemp = 0;
            
            dataPath3D = fopen(savePath3, "r");
            
            if (NULL != dataPath3D) {
                int totalEntry = 0;
                fscanf(dataPath3D,"%d", &totalEntry);
                
                do {
                    
                    fscanf(dataPath3D,"%lf", &numberTemp);
                    dataArrayFor3D [entryCount] = numberTemp;
                    
                    entryCount++;
                    
                } while (entryCount <= totalEntry);
                
                fclose(dataPath3D);
                
                SCNScene *cellScene = [SCNScene sceneNamed:@"CellBaseScene.scn"];
                
                //========Cell nuclei display=========
                for (int counter1 = 0; counter1 < entryCount/18; counter1++){
                    SCNSphere *cell = [SCNSphere sphereWithRadius:dataArrayFor3D [counter1*18+11]];
                    cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+15] green:dataArrayFor3D [counter1*18+16] blue:dataArrayFor3D [counter1*18+17] alpha:1.0f];
                    SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                    cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                    [[cellScene rootNode] addChildNode:cellNode];
                }
                
                //========Cell sphere display=========
                double xRoatPosition = 0;
                double yRoatPosition = 0;
                double xRoatPosition2 = 0;
                double yRoatPosition2 = 0;
                
                for (int counter1 = 0; counter1 < entryCount/18; counter1++){
                    if (dataArrayFor3D [counter1*18+7] == 1){
                        SCNSphere *cell = [SCNSphere sphereWithRadius:dataArrayFor3D [counter1*18+9]];
                        cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                        SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                        cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                        [[cellScene rootNode] addChildNode:cellNode];
                        
                        //printf("%lf /n", dataArrayFor3D [counter1*18+9]);
                    }
                    else if (dataArrayFor3D [counter1*18+7] == 4){
                        SCNBox *cell = [SCNBox boxWithWidth:dataArrayFor3D [counter1*18+9]*(double)1.5 height:dataArrayFor3D [counter1*18+9]*(double)1.5 length:dataArrayFor3D [counter1*18+9]*(double)1.5 chamferRadius:(dataArrayFor3D [counter1*18+9]*(double)1.5)*(double)0.2];
                        cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                        SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                        cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                        [[cellScene rootNode] addChildNode:cellNode];
                    }
                    else if (dataArrayFor3D [counter1*18+7] == 2){
                        SCNCapsule *cell = [SCNCapsule capsuleWithCapRadius:dataArrayFor3D [counter1*18+9] height:dataArrayFor3D [counter1*18+9]*(double)3.5];
                        cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                        SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                        cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                        [[cellScene rootNode] addChildNode:cellNode];
                    }
                    else if (dataArrayFor3D [counter1*18+7] == 3){
                        xRoatPosition = (dataArrayFor3D [counter1*18+4]/(double)200)*cos(90)-(dataArrayFor3D [counter1*18+5]/(double)200)*sin(90);
                        yRoatPosition = (dataArrayFor3D [counter1*18+4]/(double)200)*cos(90)+(dataArrayFor3D [counter1*18+5]/(double)200)*sin(90);
                        
                        if (xRoatPosition > dataArrayFor3D [counter1*18+4]/(double)200){
                            xRoatPosition2 = (xRoatPosition-dataArrayFor3D [counter1*18+4]/(double)200)*-1;
                        }
                        else xRoatPosition2 = (dataArrayFor3D [counter1*18+4]/(double)200)-xRoatPosition;
                        
                        if (yRoatPosition > dataArrayFor3D [counter1*18+5]/(double)200){
                            yRoatPosition2 = (yRoatPosition-dataArrayFor3D [counter1*18+5]/(double)200)*-1;
                        }
                        else yRoatPosition2 = (dataArrayFor3D [counter1*18+5]/(double)200)-yRoatPosition;
                        
                        xRoatPosition2 = xRoatPosition2+xRoatPosition;
                        yRoatPosition2 = yRoatPosition2+yRoatPosition;
                        
                        SCNCapsule *cell = [SCNCapsule capsuleWithCapRadius:dataArrayFor3D [counter1*18+9] height:dataArrayFor3D [counter1*18+9]*(double)3.5];
                        SCNMatrix4 rotMat= SCNMatrix4Rotate(SCNMatrix4Identity, M_PI_2, 0, 0, 1);
                        cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                        SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                        cellNode.transform = SCNMatrix4Mult(cellNode.transform, rotMat);
                        cellNode.position = SCNVector3Make(xRoatPosition2, yRoatPosition2, dataArrayFor3D [counter1*18+6]/(double)200);
                        
                        [[cellScene rootNode] addChildNode:cellNode];
                    }
                }
                
                //========Sphere=========
                if (self->sphereDisplayOnOff == 1){
                    CGFloat sphereLarge = self->imageSizeTemp/(double)2;
                    
                    SCNSphere *cell2 = [SCNSphere sphereWithRadius:sphereLarge/(double)200];
                    cell2.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:1 green:1 blue:1 alpha:0.1];
                    SCNNode *cellNode2 = [SCNNode nodeWithGeometry:cell2];
                    cellNode2.position = SCNVector3Make(sphereLarge/(double)200, sphereLarge/(double)200, sphereLarge/(double)200);
                    
                    [[cellScene rootNode] addChildNode:cellNode2];
                }
                
                //========Axe display========
                SCNVector3 positions [] = {
                    SCNVector3Make(0.0, 0.0, 0.0),
                    SCNVector3Make(self->axeLength, 0.0, 0.0)
                };
                
                int indices [] = {0, 1};
                
                SCNGeometrySource *vertexSource = [SCNGeometrySource geometrySourceWithVertices:positions count:2];
                NSData *indexData = [NSData dataWithBytes:indices length:sizeof(indices)];
                SCNGeometryElement *element = [SCNGeometryElement geometryElementWithData:indexData primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
                
                SCNGeometry *line = [SCNGeometry geometryWithSources:@[vertexSource] elements:@[element]];
                SCNMaterial * material = [SCNMaterial material];
                material.diffuse.contents = [[NSColor greenColor] colorWithAlphaComponent:1.0f];
                line.materials = @[material];
                
                SCNNode *lineNode = [SCNNode nodeWithGeometry:line];
                [[cellScene rootNode] addChildNode:lineNode];
                
                SCNVector3 positions2 [] = {
                    SCNVector3Make(0.0, 0.0, 0.0),
                    SCNVector3Make(0.0, self->axeLength, 0.0)
                };
                
                int indices2 [] = {0, 1};
                
                SCNGeometrySource *vertexSource2 = [SCNGeometrySource geometrySourceWithVertices:positions2 count:2];
                NSData *indexData2 = [NSData dataWithBytes:indices2 length:sizeof(indices2)];
                SCNGeometryElement *element2 = [SCNGeometryElement geometryElementWithData:indexData2 primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
                
                SCNGeometry *line2 = [SCNGeometry geometryWithSources:@[vertexSource2] elements:@[element2]];
                SCNMaterial * material2 = [SCNMaterial material];
                material2.diffuse.contents = [[NSColor blueColor] colorWithAlphaComponent:1.0f];
                line2.materials = @[material2];
                
                SCNNode *lineNode2 = [SCNNode nodeWithGeometry:line2];
                [[cellScene rootNode] addChildNode:lineNode2];
                
                SCNVector3 positions3 [] = {
                    SCNVector3Make(0.0, 0.0, 0.0),
                    SCNVector3Make(0.0, 0.0, self->axeLength)
                };
                
                int indices3 [] = {0, 1};
                
                SCNGeometrySource *vertexSource3 = [SCNGeometrySource geometrySourceWithVertices:positions3 count:2];
                NSData *indexData3 = [NSData dataWithBytes:indices3 length:sizeof(indices3)];
                SCNGeometryElement *element3 = [SCNGeometryElement geometryElementWithData:indexData3 primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
                
                SCNGeometry *line3 = [SCNGeometry geometryWithSources:@[vertexSource3] elements:@[element3]];
                SCNMaterial * material3 = [SCNMaterial material];
                material3.diffuse.contents = [[NSColor redColor] colorWithAlphaComponent:1.0f];
                line3.materials = @[material3];
                
                SCNNode *lineNode3 = [SCNNode nodeWithGeometry:line3];
                [[cellScene rootNode] addChildNode:lineNode3];
                
                self->cameraNode = [[SCNNode alloc] init];
                self->cameraNode.camera = [SCNCamera camera];
                self->cameraNode.position = SCNVector3Make(self->positionX, self->positionY, self->positionZ);
                self->cameraNode.rotation  = SCNVector4Make(self->rotationX, self->rotationY, self->rotationZ, self->rotationW);//-M_PI_4 180 degree
                self->cameraNode.orientation  = SCNVector4Make(self->orientationX, self->orientationY, self->orientationZ, self->orientationW);
                self->cameraNode.scale  = SCNVector3Make(self->scaleX, self->scaleY, self->scaleZ);
                
                [[cellScene rootNode] addChildNode:self->cameraNode];
                
                self.sceneView.scene = cellScene;
                self.sceneView.allowsCameraControl = YES;
                self.sceneView.pointOfView = self->cameraNode;
                
                [SCNTransaction begin];
                [SCNTransaction setDisableActions:YES];
                
                NSImage* image3D = self.sceneView.snapshot;
                
                NSData *data3D = [image3D TIFFRepresentation];
                NSBitmapImageRep *bitmap = [NSBitmapImageRep imageRepWithData:data3D];
                NSDictionary *imageProportion = [NSDictionary dictionary];
                data3D = [bitmap representationUsingType:NSBitmapImageFileTypePNG properties: imageProportion];
                
                NSError *error = nil;
                [data3D writeToFile:@(exportPath3) options:NSAtomicWrite error:&error];
                
                [SCNTransaction commit];
                
                exportTime++;
                
                if (exportTime > self->maxTimePoint){
                    terminationFlag = 0;
                }
            }
            else terminationFlag = 0;
            
            if (self->exportStop == 1){
                self->exportStop = 0;
                terminationFlag = 0;
            }
            
            free(dataArrayFor3D);
            
            sleep(100);
            
        } while (terminationFlag == 1);
    });
}

-(IBAction)startAnimation:(id)sender{
    timePointPosition = 1;
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)forwardOne:(id)sender{
    currentTimePointHold = timePointPosition;
    timePointPosition++;
    
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)forwardTen:(id)sender{
    currentTimePointHold = timePointPosition;
    timePointPosition =  timePointPosition+10;
    
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)forwardHundred:(id)sender{
    currentTimePointHold = timePointPosition;
    timePointPosition =  timePointPosition+100;
    
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)backwardOne:(id)sender{
    timePointPosition =  timePointPosition-1;
    
    if (timePointPosition <= 0) timePointPosition = 1;
    
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)backwardTen:(id)sender{
    timePointPosition =  timePointPosition-10;
    
    if (timePointPosition <= 0) timePointPosition = 1;
    
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)backwardHundred:(id)sender{
    timePointPosition =  timePointPosition-100;
    
    if (timePointPosition <= 0) timePointPosition = 1;
    
    [self cell3DDisplayProcessing];
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)cell3DDisplayProcessing{
    NSString *folder = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Desktop"];
    
    //NSLog(@"%@", folder);
    
    const char *folderPath = [folder UTF8String];
    
    char *extract1 = strstr(folderPath, "Users");
    char *extract2 = strstr(extract1, "/");
    int lengthOfString = (int)strlen(extract2);
    char extract3 [lengthOfString+10];
    strncpy(extract3, extract2+1, lengthOfString-1);
    
    char *string1  = strchr(extract3, '/');
    int index = (int)(string1-extract3);
    
    int lengthOfString2 = (int)strlen(extract3);
    char pathNameCString [lengthOfString2+10];
    strncpy(pathNameCString, extract3, index);
    pathNameCString [index] = '\0';
    
    lengthOfString2 = (int)strlen(pathNameCString);
    
    char savePath [7+lengthOfString2+58+19+10];
    strcpy(savePath, "/Users/");
    strcat(savePath, pathNameCString);
    strcat(savePath, "/Desktop/CLIA_LiveCell/09_Cell_Tracking_Analysis_Results/");
    
    int timePoint = timePointPosition;
    
    char numberString [9];
    
    sprintf(numberString, "%d", timePoint);
    
    char numberForPath [9];
    
    if ((int)strlen(numberString) == 1){
        strcpy(numberForPath, "0000000");
        strcat(numberForPath, numberString);
    }
    else if ((int)strlen(numberString) == 2){
        strcpy(numberForPath, "000000");
        strcat(numberForPath, numberString);
    }
    else if ((int)strlen(numberString) == 3){
        strcpy(numberForPath, "00000");
        strcat(numberForPath, numberString);
    }
    else if ((int)strlen(numberString) == 4){
        strcpy(numberForPath, "0000");
        strcat(numberForPath, numberString);
    }
    else if ((int)strlen(numberString) == 5){
        strcpy(numberForPath, "000");
        strcat(numberForPath, numberString);
    }
    else if ((int)strlen(numberString) == 6){
        strcpy(numberForPath, "00");
        strcat(numberForPath, numberString);
    }
    else if ((int)strlen(numberString) == 7){
        strcpy(numberForPath, "0");
        strcat(numberForPath, numberString);
    }
    
    strcat(savePath, numberForPath);
    strcat(savePath, "_3dTemp.Dat");
    
    char parameterPath [7+lengthOfString2+52+10];
    strcpy(parameterPath, "/Users/");
    strcat(parameterPath, pathNameCString);
    strcat(parameterPath, "/Desktop/CLIA_LiveCell/11_System_Data/DataTemp3D.Dat");
    
    totalSize = 0;
    imageSizeTemp = 0;
    maxTimePoint = 0;
    
    FILE *dataParameter;
    
    dataParameter = fopen(parameterPath, "r");
    
    if (NULL == dataParameter) {
        totalSize = 500*500*500;
        maxTimePoint = 1;
    }
    else{
        
        fscanf(dataParameter,"%d", &imageSizeTemp);
        totalSize = imageSizeTemp*imageSizeTemp*imageSizeTemp;
        
        //printf("%d \n", imageSizeTemp);
        
        fscanf(dataParameter,"%d", &maxTimePoint);
        
        if (timePointPosition >= maxTimePoint) timePointPosition = maxTimePoint;
        
        fscanf(dataParameter, "%lf", &positionX);
        fscanf(dataParameter, "%lf", &positionY);
        fscanf(dataParameter, "%lf", &positionZ);
        fscanf(dataParameter, "%lf", &rotationX);
        fscanf(dataParameter, "%lf", &rotationY);
        fscanf(dataParameter, "%lf", &rotationZ);
        fscanf(dataParameter, "%lf", &rotationW);
        fscanf(dataParameter, "%lf", &orientationX);
        fscanf(dataParameter, "%lf", &orientationY);
        fscanf(dataParameter, "%lf", &orientationZ);
        fscanf(dataParameter, "%lf", &orientationW);
        fscanf(dataParameter, "%lf", &scaleX);
        fscanf(dataParameter, "%lf", &scaleY);
        fscanf(dataParameter, "%lf", &scaleZ);
        fscanf(dataParameter, "%lf", &axeLength);
        
        fclose(dataParameter);
        
        //printf("%lf \n", positionZ);
        
        positionXTemp = positionX;
        positionYTemp = positionY;
        positionZTemp = positionZ;
        rotationXTemp = rotationX;
        rotationYTemp = rotationY;
        rotationZTemp = rotationZ;
        rotationWTemp = rotationW;
        orientationXTemp = orientationX;
        orientationYTemp = orientationY;
        orientationZTemp = orientationZ;
        orientationWTemp = orientationW;
        
        [positionXDisplay setDoubleValue:positionXTemp];
        [positionYDisplay setDoubleValue:positionYTemp];
        [positionZDisplay setDoubleValue:positionZTemp];
        [rotationXDisplay setDoubleValue:rotationXTemp];
        [rotationYDisplay setDoubleValue:rotationYTemp];
        [rotationZDisplay setDoubleValue:rotationZTemp];
        [rotationWDisplay setDoubleValue:rotationWTemp];
        [orientationXDisplay setDoubleValue:orientationXTemp];
        [orientationYDisplay setDoubleValue:orientationYTemp];
        [orientationZDisplay setDoubleValue:orientationZTemp];
        [orientationWDisplay setDoubleValue:orientationWTemp];
    }
    
    [timeDisplay setIntegerValue:timePointPosition];
    
    //printf("%lf \n", totalSize);
    
    double *dataArrayFor3D = malloc((int)totalSize * sizeof(double));
    
    int entryCount = 0;
    
    FILE *dataPath3D;
    double numberTemp = 0;
    
    dataPath3D = fopen(savePath, "r");
    
    //printf("%s \n", savePath);
    
    if (NULL == dataPath3D) {
        timePointPosition = currentTimePointHold;
        [timeDisplay setIntegerValue:timePointPosition];
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Entered 3D data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
    else{
        
        int totalEntry = 0;
        fscanf(dataPath3D,"%d", &totalEntry);
        
        do {
            
            fscanf(dataPath3D,"%lf", &numberTemp);
            dataArrayFor3D [entryCount] = numberTemp;
            
            entryCount++;
            
        } while (entryCount <= totalEntry);
        
        fclose(dataPath3D);
        
        SCNScene *cellScene = [SCNScene sceneNamed:@"CellBaseScene.scn"];
        
        //========Cell nuclei display=========
        for (int counter1 = 0; counter1 < entryCount/18; counter1++){
            SCNSphere *cell = [SCNSphere sphereWithRadius:dataArrayFor3D [counter1*18+11]];
            cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+15] green:dataArrayFor3D [counter1*18+16] blue:dataArrayFor3D [counter1*18+17] alpha:1.0f];
            SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
            cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
            [[cellScene rootNode] addChildNode:cellNode];
        }
        
        //========Cell sphere display=========
        double xRoatPosition = 0;
        double yRoatPosition = 0;
        double xRoatPosition2 = 0;
        double yRoatPosition2 = 0;
        
        for (int counter1 = 0; counter1 < entryCount/18; counter1++){
            if (dataArrayFor3D [counter1*18+7] == 1){
                SCNSphere *cell = [SCNSphere sphereWithRadius:dataArrayFor3D [counter1*18+9]];
                cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                [[cellScene rootNode] addChildNode:cellNode];
                
                //printf("%lf \n", dataArrayFor3D [counter1*18+7]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+9]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+10]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+12]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+13]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+14]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+4]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+5]);
                //printf("%lf \n", dataArrayFor3D [counter1*18+6]);
            }
            else if (dataArrayFor3D [counter1*18+7] == 4){
                SCNBox *cell = [SCNBox boxWithWidth:dataArrayFor3D [counter1*18+9]*(double)1.5 height:dataArrayFor3D [counter1*18+9]*(double)1.5 length:dataArrayFor3D [counter1*18+9]*(double)1.5 chamferRadius:(dataArrayFor3D [counter1*18+9]*(double)1.5)*(double)0.2];
                cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                [[cellScene rootNode] addChildNode:cellNode];
            }
            else if (dataArrayFor3D [counter1*18+7] == 2){
                SCNCapsule *cell = [SCNCapsule capsuleWithCapRadius:dataArrayFor3D [counter1*18+9] height:dataArrayFor3D [counter1*18+9]*(double)3.5];
                cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                cellNode.position = SCNVector3Make(dataArrayFor3D [counter1*18+4]/(double)200, dataArrayFor3D [counter1*18+5]/(double)200, dataArrayFor3D [counter1*18+6]/(double)200);
                [[cellScene rootNode] addChildNode:cellNode];
            }
            else if (dataArrayFor3D [counter1*18+7] == 3){
                xRoatPosition = (dataArrayFor3D [counter1*18+4]/(double)200)*cos(90)-(dataArrayFor3D [counter1*18+5]/(double)200)*sin(90);
                yRoatPosition = (dataArrayFor3D [counter1*18+4]/(double)200)*cos(90)+(dataArrayFor3D [counter1*18+5]/(double)200)*sin(90);
                
                if (xRoatPosition > dataArrayFor3D [counter1*18+4]/(double)200){
                    xRoatPosition2 = (xRoatPosition-dataArrayFor3D [counter1*18+4]/(double)200)*-1;
                }
                else xRoatPosition2 = (dataArrayFor3D [counter1*18+4]/(double)200)-xRoatPosition;
                
                if (yRoatPosition > dataArrayFor3D [counter1*18+5]/(double)200){
                    yRoatPosition2 = (yRoatPosition-dataArrayFor3D [counter1*18+5]/(double)200)*-1;
                }
                else yRoatPosition2 = (dataArrayFor3D [counter1*18+5]/(double)200)-yRoatPosition;
                
                xRoatPosition2 = xRoatPosition2+xRoatPosition;
                yRoatPosition2 = yRoatPosition2+yRoatPosition;
                
                SCNCapsule *cell = [SCNCapsule capsuleWithCapRadius:dataArrayFor3D [counter1*18+9] height:dataArrayFor3D [counter1*18+9]*(double)3.5];
                SCNMatrix4 rotMat= SCNMatrix4Rotate(SCNMatrix4Identity, M_PI_2, 0, 0, 1);
                cell.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:dataArrayFor3D [counter1*18+12] green:dataArrayFor3D [counter1*18+13] blue:dataArrayFor3D [counter1*18+14] alpha:dataArrayFor3D [counter1*18+10]];
                SCNNode *cellNode = [SCNNode nodeWithGeometry:cell];
                cellNode.transform = SCNMatrix4Mult(cellNode.transform, rotMat);
                cellNode.position = SCNVector3Make(xRoatPosition2, yRoatPosition2, dataArrayFor3D [counter1*18+6]/(double)200);
                
                [[cellScene rootNode] addChildNode:cellNode];
            }
        }
        
        //========Sphere=========
        if (sphereDisplayOnOff == 1){
            CGFloat sphereLarge = imageSizeTemp/(double)2;
            
            SCNSphere *cell2 = [SCNSphere sphereWithRadius:sphereLarge/(double)200];
            cell2.firstMaterial.diffuse.contents = [NSColor colorWithCalibratedRed:1 green:1 blue:1 alpha:0.1];
            SCNNode *cellNode2 = [SCNNode nodeWithGeometry:cell2];
            cellNode2.position = SCNVector3Make(sphereLarge/(double)200, sphereLarge/(double)200, sphereLarge/(double)200);
            
            [[cellScene rootNode] addChildNode:cellNode2];
        }
        
        //========Axe display========
        SCNVector3 positions [] = {
            SCNVector3Make(0.0, 0.0, 0.0),
            SCNVector3Make(axeLength, 0.0, 0.0)
        };
        
        int indices [] = {0, 1};
        
        SCNGeometrySource *vertexSource = [SCNGeometrySource geometrySourceWithVertices:positions count:2];
        NSData *indexData = [NSData dataWithBytes:indices length:sizeof(indices)];
        SCNGeometryElement *element = [SCNGeometryElement geometryElementWithData:indexData primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
        
        SCNGeometry *line = [SCNGeometry geometryWithSources:@[vertexSource] elements:@[element]];
        SCNMaterial * material = [SCNMaterial material];
        material.diffuse.contents = [[NSColor greenColor] colorWithAlphaComponent:1.0f];
        line.materials = @[material];
        
        SCNNode *lineNode = [SCNNode nodeWithGeometry:line];
        [[cellScene rootNode] addChildNode:lineNode];
        
        SCNVector3 positions2 [] = {
            SCNVector3Make(0.0, 0.0, 0.0),
            SCNVector3Make(0.0, axeLength, 0.0)
        };
        
        int indices2 [] = {0, 1};
        
        SCNGeometrySource *vertexSource2 = [SCNGeometrySource geometrySourceWithVertices:positions2 count:2];
        NSData *indexData2 = [NSData dataWithBytes:indices2 length:sizeof(indices2)];
        SCNGeometryElement *element2 = [SCNGeometryElement geometryElementWithData:indexData2 primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
        
        SCNGeometry *line2 = [SCNGeometry geometryWithSources:@[vertexSource2] elements:@[element2]];
        SCNMaterial * material2 = [SCNMaterial material];
        material2.diffuse.contents = [[NSColor blueColor] colorWithAlphaComponent:1.0f];
        line2.materials = @[material2];
        
        SCNNode *lineNode2 = [SCNNode nodeWithGeometry:line2];
        [[cellScene rootNode] addChildNode:lineNode2];
        
        SCNVector3 positions3 [] = {
            SCNVector3Make(0.0, 0.0, 0.0),
            SCNVector3Make(0.0, 0.0, axeLength)
        };
        
        int indices3 [] = {0, 1};
        
        SCNGeometrySource *vertexSource3 = [SCNGeometrySource geometrySourceWithVertices:positions3 count:2];
        NSData *indexData3 = [NSData dataWithBytes:indices3 length:sizeof(indices3)];
        SCNGeometryElement *element3 = [SCNGeometryElement geometryElementWithData:indexData3 primitiveType:SCNGeometryPrimitiveTypeLine primitiveCount:1 bytesPerIndex:sizeof(int)];
        
        SCNGeometry *line3 = [SCNGeometry geometryWithSources:@[vertexSource3] elements:@[element3]];
        SCNMaterial * material3 = [SCNMaterial material];
        material3.diffuse.contents = [[NSColor redColor] colorWithAlphaComponent:1.0f];
        line3.materials = @[material3];
        
        SCNNode *lineNode3 = [SCNNode nodeWithGeometry:line3];
        [[cellScene rootNode] addChildNode:lineNode3];
        
        cameraNode = [[SCNNode alloc] init];
        cameraNode.camera = [SCNCamera camera];
        cameraNode.position = SCNVector3Make(positionX, positionY, positionZ);
        cameraNode.rotation = SCNVector4Make(rotationX, rotationY, rotationZ, rotationW);//-M_PI_4 180 degree
        cameraNode.orientation = SCNVector4Make(orientationX, orientationY, orientationZ, orientationW);
        cameraNode.scale  = SCNVector3Make(scaleX, scaleY, scaleZ);
        
        [[cellScene rootNode] addChildNode:cameraNode];
        
        self.sceneView.scene = cellScene;
        self.sceneView.allowsCameraControl = YES;
        self.sceneView.pointOfView = cameraNode;
        
        NSClickGestureRecognizer *tapGestureRecognizer = [[NSClickGestureRecognizer alloc] initWithTarget:self action:@selector(handleDoubleTap:)];
        tapGestureRecognizer.numberOfTouchesRequired = 2;
        self.sceneView.gestureRecognizers = @[tapGestureRecognizer];
    }
    
    free(dataArrayFor3D);
}

-(void)handleDoubleTap:(NSClickGestureRecognizer *) gesture{
    positionXTemp = self.sceneView.pointOfView.position.x;
    positionYTemp = self.sceneView.pointOfView.position.y;
    positionZTemp = self.sceneView.pointOfView.position.z;
    rotationXTemp = self.sceneView.pointOfView.rotation.x;
    rotationYTemp = self.sceneView.pointOfView.rotation.y;
    rotationZTemp = self.sceneView.pointOfView.rotation.z;
    rotationWTemp = self.sceneView.pointOfView.rotation.w;
    orientationXTemp = self.sceneView.pointOfView.orientation.x;
    orientationYTemp = self.sceneView.pointOfView.orientation.y;
    orientationZTemp = self.sceneView.pointOfView.orientation.z;
    orientationWTemp = self.sceneView.pointOfView.orientation.w;
    
    [positionXDisplay setDoubleValue:positionXTemp];
    [positionYDisplay setDoubleValue:positionYTemp];
    [positionZDisplay setDoubleValue:positionZTemp];
    [rotationXDisplay setDoubleValue:rotationXTemp];
    [rotationYDisplay setDoubleValue:rotationYTemp];
    [rotationZDisplay setDoubleValue:rotationZTemp];
    [rotationWDisplay setDoubleValue:rotationWTemp];
    [orientationXDisplay setDoubleValue:orientationXTemp];
    [orientationYDisplay setDoubleValue:orientationYTemp];
    [orientationZDisplay setDoubleValue:orientationZTemp];
    [orientationWDisplay setDoubleValue:orientationWTemp];
    
    //NSLog(@"Camera position: %f %f %f", self.sceneView.pointOfView.position.x, self.sceneView.pointOfView.position.y, self.sceneView.pointOfView.position.z);
    //NSLog(@"Camera rotation: %f %f %f %f", self.sceneView.pointOfView.rotation.x, self.sceneView.pointOfView.rotation.y, self.sceneView.pointOfView.rotation.z, self.sceneView.pointOfView.rotation.w);
    //NSLog(@"Camera orientat: %f %f %f %f", self.sceneView.pointOfView.orientation.x, self.sceneView.pointOfView.orientation.y, self.sceneView.pointOfView.orientation.z, self.sceneView.pointOfView.orientation.w);
    //NSLog(@"Camera scale: %f %f %f", self.sceneView.pointOfView.scale.x, self.sceneView.pointOfView.scale.y, self.sceneView.pointOfView.scale.z);
}

-(IBAction)saveCameraParameters:(id)sender{
    NSString *folder = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Desktop"];
    
    //NSLog(@"%@", folder);
    
    const char *folderPath = [folder UTF8String];
    
    char *extract1 = strstr(folderPath, "Users");
    char *extract2 = strstr(extract1, "/");
    int lengthOfString = (int)strlen(extract2);
    char extract3 [lengthOfString+10];
    strncpy(extract3, extract2+1, lengthOfString-1);
    
    char *string1  = strchr(extract3, '/');
    int index = (int)(string1-extract3);
    
    int lengthOfString2 = (int)strlen(extract3);
    char pathNameCString [lengthOfString2+10];
    strncpy(pathNameCString, extract3, index);
    pathNameCString [index] = '\0';
    
    lengthOfString2 = (int)strlen(pathNameCString);
    
    char parameterPath [7+lengthOfString2+52+10];
    strcpy(parameterPath, "/Users/");
    strcat(parameterPath, pathNameCString);
    strcat(parameterPath, "/Desktop/CLIA_LiveCell/11_System_Data/DataTemp3D.Dat");
    
    FILE *savePath;
    savePath = fopen(parameterPath,"r");
    
    int imageSize = 0;
    fscanf(savePath,"%d", &imageSize);
    
    int timePointTemp = 0;
    fscanf(savePath,"%d", &timePointTemp);
    
    if (NULL != savePath){
        fclose(savePath);
        
        positionX = positionXTemp;
        positionY = positionYTemp;
        positionZ = positionZTemp;
        rotationX = rotationXTemp;
        rotationY = rotationYTemp;
        rotationZ = rotationZTemp;
        rotationW = rotationWTemp;
        orientationX = orientationXTemp;
        orientationY = orientationYTemp;
        orientationZ = orientationZTemp;
        orientationW = orientationWTemp;
        
        CGFloat scaleTemp = [scaleMainDisplay floatValue];
        
        if (scaleTemp <= 0 || scaleTemp > 100) scaleTemp = 1;
        
        scaleX = scaleTemp;
        scaleY = scaleTemp;
        scaleZ = scaleTemp;
        
        [scaleXDisplay setDoubleValue:scaleX];
        [scaleYDisplay setDoubleValue:scaleY];
        [scaleZDisplay setDoubleValue:scaleZ];
        
        axeLength = [axeLengthDisplay floatValue];
        
        if (axeLength <= 0 || axeLength > 100) axeLength = 5;
        
        [axeLengthDisplay setDoubleValue:axeLength];
        
        CGFloat positionZInitTemp = [initZPositionDisplay floatValue];
        
        if (positionZInitTemp > 0 && positionZInitTemp <= 100){
            positionZ = positionZInitTemp;
        }
        
        [positionZDisplay setDoubleValue:positionZ];
        
        savePath = fopen(parameterPath,"w");
        
        fprintf(savePath, "%d\n", imageSize);
        fprintf(savePath, "%d\n", timePointTemp);
        fprintf(savePath, "%.8f\n", positionX);
        fprintf(savePath, "%.8f\n", positionY);
        fprintf(savePath, "%.8f\n", positionZ);
        fprintf(savePath, "%.8f\n", rotationX);
        fprintf(savePath, "%.8f\n", rotationY);
        fprintf(savePath, "%.8f\n", rotationZ);
        fprintf(savePath, "%.8f\n", rotationW);
        fprintf(savePath, "%.8f\n", orientationX);
        fprintf(savePath, "%.8f\n", orientationY);
        fprintf(savePath, "%.8f\n", orientationZ);
        fprintf(savePath, "%.8f\n", orientationW);
        fprintf(savePath, "%.8f\n", scaleX);
        fprintf(savePath, "%.8f\n", scaleY);
        fprintf(savePath, "%.8f\n", scaleZ);
        fprintf(savePath, "%.8f\n", axeLength);
        fclose(savePath);
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Entered 3D data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)refreshParameters:(id)sender{
    NSString *folder = [[[NSBundle mainBundle] resourcePath] stringByAppendingPathComponent:@"Desktop"];
    
    //NSLog(@"%@", folder);
    
    const char *folderPath = [folder UTF8String];
    
    char *extract1 = strstr(folderPath, "Users");
    char *extract2 = strstr(extract1, "/");
    int lengthOfString = (int)strlen(extract2);
    char extract3 [lengthOfString+10];
    strncpy(extract3, extract2+1, lengthOfString-1);
    
    char *string1  = strchr(extract3, '/');
    int index = (int)(string1-extract3);
    
    int lengthOfString2 = (int)strlen(extract3);
    char pathNameCString [lengthOfString2+10];
    strncpy(pathNameCString, extract3, index);
    pathNameCString [index] = '\0';
    
    lengthOfString2 = (int)strlen(pathNameCString);
    
    char parameterPath [7+lengthOfString2+58+19+10];
    strcpy(parameterPath, "/Users/");
    strcat(parameterPath, pathNameCString);
    strcat(parameterPath, "/Desktop/CLIA_LiveCell/11_System_Data/DataTemp3D.Dat");
    
    FILE *savePath;
    savePath = fopen(parameterPath,"r");
    
    int imageSize = 0;
    fscanf(savePath,"%d", &imageSize);
    
    int timePointTemp = 0;
    fscanf(savePath,"%d", &timePointTemp);
    
    if (NULL != savePath){
        fclose(savePath);
        
        positionX = 0;
        positionY = 0;
        positionZ = 5;
        rotationX = 0;
        rotationY = 0;
        rotationZ = 0;
        rotationW = 0;
        orientationX = 0;
        orientationY = 0;
        orientationZ = 0;
        orientationW = 1;
        scaleX = 1;
        scaleY = 1;
        scaleZ = 1;
        
        positionXTemp = 0;
        positionYTemp = 0;
        positionZTemp = 5;
        rotationXTemp = 0;
        rotationYTemp = 0;
        rotationZTemp = 0;
        rotationWTemp = 0;
        orientationXTemp = 0;
        orientationYTemp = 0;
        orientationZTemp = 0;
        orientationWTemp = 1;
        
        axeLength = 5.0;
        
        [positionXDisplay setDoubleValue:positionXTemp];
        [positionYDisplay setDoubleValue:positionYTemp];
        [positionZDisplay setDoubleValue:positionZTemp];
        [rotationXDisplay setDoubleValue:rotationXTemp];
        [rotationYDisplay setDoubleValue:rotationYTemp];
        [rotationZDisplay setDoubleValue:rotationZTemp];
        [rotationWDisplay setDoubleValue:rotationWTemp];
        [orientationXDisplay setDoubleValue:orientationXTemp];
        [orientationYDisplay setDoubleValue:orientationYTemp];
        [orientationZDisplay setDoubleValue:orientationZTemp];
        [orientationWDisplay setDoubleValue:orientationWTemp];
        [scaleXDisplay setDoubleValue:scaleX];
        [scaleYDisplay setDoubleValue:scaleY];
        [scaleZDisplay setDoubleValue:scaleZ];
        
        [axeLengthDisplay setDoubleValue:axeLength];
        [initZPositionDisplay setDoubleValue:positionZ];
        
        savePath = fopen(parameterPath,"w");
        
        fprintf(savePath, "%d\n", imageSize);
        fprintf(savePath, "%d\n", timePointTemp);
        fprintf(savePath, "%.8f\n", positionX);
        fprintf(savePath, "%.8f\n", positionY);
        fprintf(savePath, "%.8f\n", positionZ);
        fprintf(savePath, "%.8f\n", rotationX);
        fprintf(savePath, "%.8f\n", rotationY);
        fprintf(savePath, "%.8f\n", rotationZ);
        fprintf(savePath, "%.8f\n", rotationW);
        fprintf(savePath, "%.8f\n", orientationX);
        fprintf(savePath, "%.8f\n", orientationY);
        fprintf(savePath, "%.8f\n", orientationZ);
        fprintf(savePath, "%.8f\n", orientationW);
        fprintf(savePath, "%.8f\n", scaleX);
        fprintf(savePath, "%.8f\n", scaleY);
        fprintf(savePath, "%.8f\n", scaleZ);
        fprintf(savePath, "%.8f\n", axeLength);
        fclose(savePath);
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Entered 3D data"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sphereDisplaySet:(id)sender{
    if (sphereDisplayOnOff == 0){
        sphereDisplayOnOff = 1;
        [sphereSetStatusDisplay setStringValue:@"On"];
    }
    else if (sphereDisplayOnOff == 1){
        sphereDisplayOnOff = 0;
        [sphereSetStatusDisplay setStringValue:@"Off"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

@end
