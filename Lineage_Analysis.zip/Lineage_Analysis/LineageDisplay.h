//
//  LineageDisplay.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/14/16.
//
//

#ifndef LINEAGDISPLAY_H
#define LINEAGDISPLAY_H
#import "Controller.h" 
#endif

@interface LineageDisplay : NSView{
    double xPointDownLingDisplay; //Display operation
    double yPointDownLingDisplay; //Display operation
    
    IBOutlet NSWindow *lineageListWindow;
}

-(void)dealloc;
-(BOOL)acceptsFirstResponder;
-(void)mouseDown:(NSEvent *)event;
-(void)keyDown:(NSEvent *)event;

@end
