//
//  ProgenyNoController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-10.
//
//

#ifndef PROGENYNOCONTROLLER_H
#define PROGENYNOCONTROLLER_H
#import "Controller.h" 
#endif

@interface ProgenyNoController : NSObject <NSTextFieldDelegate>{
    int categoryTimeHold; //Category time
    int categoryRangeHold; //Category range
    int categoryGroupHold; //Category group
    int categoryZeroInclude; //Category zero inc
    int categoryHold; //Category
    int sdCalculationHold; //SD calculation
    int normalizeHold; //Normalize
    int lineageComparisonStatusHold; //Lineage comparison
    
    IBOutlet NSTextField *categoryDDDisplay;
    IBOutlet NSTextField *categoryTDDisplay;
    IBOutlet NSTextField *categoryHDDisplay;
    IBOutlet NSTextField *categoryOFDisplay;
    IBOutlet NSTextField *categoryCDDisplay;
    IBOutlet NSTextField *categoryCFDisplay;
    IBOutlet NSTextField *categoryIPDisplay;
    IBOutlet NSTextField *categoryMIDisplay;
    IBOutlet NSTextField *categoryPGDisplay;
    IBOutlet NSTextField *categoryTODisplay;
    IBOutlet NSTextField *categoryDisplay;
    IBOutlet NSTextField *zeroIncludeDisplay;
    IBOutlet NSTextField *categoryTimeDisplay;
    IBOutlet NSTextField *categoryRangeDisplay;
    IBOutlet NSTextField *categoryGroupDisplay;
    IBOutlet NSTextField *sdModeDisplay;
    IBOutlet NSTextField *normalizeDisplay;
    
    IBOutlet NSWindow *categoryProgenyWindow;
    
    NSWindowController *categoryProgenyWindowController;
    
    NSTimer *categoryProgenyTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)analysisSet;
-(void)lineageFluorescentDataTypeUpDate;

-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFile2:(id)sender;
-(IBAction)closeWindow:(id)sender;

-(IBAction)categorySave:(id)sender;
-(IBAction)analysisStart:(id)sender;
-(IBAction)zeroStatusHold:(id)sender;
-(IBAction)sdCalculationHoldSet:(id)sender;
-(IBAction)lineageComparison:(id)sender;
-(IBAction)createExcelFileComp:(id)sender;
-(IBAction)createExcelFileComp2:(id)sender;

-(IBAction)setDD:(id)sender;
-(IBAction)setTD:(id)sender;
-(IBAction)setHD:(id)sender;
-(IBAction)setOF:(id)sender;
-(IBAction)setCD:(id)sender;
-(IBAction)setIP:(id)sender;
-(IBAction)setMI:(id)sender;
-(IBAction)setCF:(id)sender;
-(IBAction)setPG:(id)sender;
-(IBAction)setTO:(id)sender;

@end
