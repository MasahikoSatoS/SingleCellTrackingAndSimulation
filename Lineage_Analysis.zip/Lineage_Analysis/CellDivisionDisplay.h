//
//  CellDivisionDisplay.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/15/16.
//
//

#ifndef CELLDIVISIONDISPLAY_H
#define CELLDIVISIONDISPLAY_H
#import "Controller.h" 
#endif

@interface CellDivisionDisplay : NSView{
    IBOutlet NSWindow *cellDivisionListWindow;
}

-(void)dealloc;
-(BOOL)acceptsFirstResponder;
-(void)mouseDown:(NSEvent *)event;

@end
