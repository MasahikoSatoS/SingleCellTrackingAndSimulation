//
//  MotilityTable.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#import "MotilityTable.h"

@implementation MotilityTable

NSString *notificationToMotilityTable = @"notificationExecuteMotilityTable";

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMotilityTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [motilityTable setDataSource:self];
    [motilityTable reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = motilityResultsHoldCount/10;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (motilityAnalysisPerformHold >= 1){
        string displayData1;
        string displayData2;
        string displayData3;
        string displayData4;
        string displayData5;
        
        displayData1 = arrayMotilityResultsHold [rowIndex*10+7];
        displayData2 = arrayMotilityResultsHold [rowIndex*10+8];
        displayData3 = arrayMotilityResultsHold [rowIndex*10+9];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    motilityOperationTableCount++;
    motilityOperationTableCurrentRow = rowIndex;
    
    if (motilityOperationTableCount == 2){
        if (upLoadingProgress == 0){
            motilityOperationTableCurrentRow = rowMotilityOperationTable;
            
            if (arrayMotilityResultsHold [motilityOperationTableCurrentRow*10] != "D" && arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+3] != "999999999"){
                int xStartMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+3].c_str());
                int xEndMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+4].c_str());
                int yStartMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+5].c_str());
                int yEndMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+6].c_str());
                int lineageSelectNo = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10].c_str());
                
                int scaleLength = 0;
                
                if ((xEndMotility-xStartMotility) > (yEndMotility-yStartMotility)){
                    scaleLength = xEndMotility-xStartMotility-10;
                    motilityVerticalStartHold = yStartMotility-(int)(((xEndMotility-xStartMotility)-(yEndMotility-yStartMotility))/(double)2)-10;
                    motilityHorizontalStartHold = xStartMotility;
                }
                else{
                    
                    scaleLength = yEndMotility-yStartMotility;
                    motilityVerticalStartHold = yStartMotility-10;
                    motilityHorizontalStartHold = xStartMotility-(int)(((yEndMotility-yStartMotility)-(xEndMotility-xStartMotility))/(double)2)-10;
                }
                
                if (fixSizeHold == 0) motilityDisplayScaleMaxHold = scaleLength+20;
                
                int verticalEnd = motilityVerticalStartHold+motilityDisplayScaleMaxHold;
                int horizontalEnd = motilityHorizontalStartHold+motilityDisplayScaleMaxHold;
                
                motilityRangeVertical = to_string(motilityVerticalStartHold)+" < "+to_string(verticalEnd);
                motilityRangeHorizontal = to_string(motilityHorizontalStartHold)+" < "+to_string(horizontalEnd);
                
                motilityTreatmentHold = arrayTableMain [lineageSelectNo][4];
                
                if (arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+1] == "D") motilityLineageHold = "nil";
                else motilityLineageHold = arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+1];
                
                if (arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+2] == "D")  motilityCellNoHold = -1;
                else motilityCellNoHold = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+2].c_str());
                
                motilityAnalysisPerformHold = 2;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDataSet object:nil];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            motilityOperationTableCurrentRow = rowIndex;
            
            if (arrayMotilityResultsHold [motilityOperationTableCurrentRow*10] != "D" && arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+3] != "999999999"){
                int xStartMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+3].c_str());
                int xEndMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+4].c_str());
                int yStartMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+5].c_str());
                int yEndMotility = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+6].c_str());
                int lineageSelectNo = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10].c_str());
                
                //for (int counterA = 0; counterA < motilityResultsHoldCount/10; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayMotilityResultsHold [counterA*10+counterB];
                //    cout<<"  arrayMotilityResultsHold "<<counterA<<endl;
                //}
                
                int scaleLength = 0;
                
                if ((xEndMotility-xStartMotility) > (yEndMotility-yStartMotility)){
                    scaleLength = xEndMotility-xStartMotility;
                    motilityVerticalStartHold = yStartMotility-(int)(((xEndMotility-xStartMotility)-(yEndMotility-yStartMotility))/(double)2)-10;
                    motilityHorizontalStartHold = xStartMotility-10;
                }
                else{
                    
                    scaleLength = yEndMotility-yStartMotility;
                    motilityVerticalStartHold = yStartMotility-10;
                    motilityHorizontalStartHold = xStartMotility-(int)(((yEndMotility-yStartMotility)-(xEndMotility-xStartMotility))/(double)2)-10;
                }
                
                if (fixSizeHold == 0) motilityDisplayScaleMaxHold = scaleLength+20;
                
                int verticalEnd = motilityVerticalStartHold+motilityDisplayScaleMaxHold;
                int horizontalEnd = motilityHorizontalStartHold+motilityDisplayScaleMaxHold;
                
                motilityRangeVertical = to_string(motilityVerticalStartHold)+" < "+to_string(verticalEnd);
                motilityRangeHorizontal = to_string(motilityHorizontalStartHold)+" < "+to_string(horizontalEnd);
                
                motilityTreatmentHold = arrayTableMain [lineageSelectNo][4];
                
                if (arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+1] == "D") motilityLineageHold = "nil";
                else motilityLineageHold = arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+1];
                
                if (arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+2] == "D")  motilityCellNoHold = -1;
                else motilityCellNoHold = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10+2].c_str());
                
                //for (int counterA = 0; counterA < motilityResultsHoldCount/10; counterA++){
                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< arrayMotilityResultsHold [counterA*10+counterB];
                //    cout<<"  arrayMotilityResultsHold "<<counterA<<endl;
                //}
                
                motilityAnalysisPerformHold = 2;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDataSet object:nil];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMotilityTable object:nil];
}

@end
