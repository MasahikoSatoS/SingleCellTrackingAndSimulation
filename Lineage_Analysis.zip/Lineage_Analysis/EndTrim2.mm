//
//  EndTrim2.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-07-02.
//
//

#import "EndTrim2.h"

@implementation EndTrim2

-(IBAction)lineageCut:(id)sender{
    if (lineageDataEntryCount > 0 && lineageDataEntryCount < 101){
        if (arrayTrimResultsHold [trimOperationTableCurrentRow*6] != "SO"){
            int lineageTimeDivHold = [lineageCutValueDisplay intValue];
            int timeLineageStart = arrayTableDetail [trimOperationTableCurrentRow][2];
            int timeLineageEnd = arrayTableDetail [trimOperationTableCurrentRow][3];
            
            if ((lineageCutStatusHold == 0 && lineageTimeDivHold > timeLineageStart && lineageTimeDivHold < timeLineageEnd-50) || (lineageCutStatusHold == 1 && lineageTimeDivHold > 0) ||lineageCutStatusHold == 2){
                if (lineageCutStatusHold == 0){
                    string entry;
                    
                    DIR *dir;
                    struct dirent *dent;
                    int maxCategoryLingNo = 0;
                    
                    string imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [trimOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [trimOperationTableCurrentRow][3]+"_IDResults";
                    
                    dir = opendir(imageDisplayPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                if ((int)entry.find("AN") != -1){
                                    if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxCategoryLingNo) maxCategoryLingNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxCategoryLingNo++;
                    
                    string treatNameExtract = arrayTableMain [trimOperationTableCurrentRow][4].substr(arrayTableMain [trimOperationTableCurrentRow][4].find("-")+1, arrayTableMain [trimOperationTableCurrentRow][4].find("_Results")-arrayTableMain [trimOperationTableCurrentRow][4].find("-")-1);
                    
                    imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [trimOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [trimOperationTableCurrentRow][3]+"_IDResults/"+"AN"+to_string(maxCategoryLingNo)+"-"+treatNameExtract+"_Results";
                    
                    mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    unsigned long lineageEntrySize = arrayLineageDataEntryHold [trimOperationTableCurrentRow];
                    
                    int lineageEntryNo = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [trimOperationTableCurrentRow][counter3*9+6] > lineageEntryNo){
                            lineageEntryNo = arrayLineageData [trimOperationTableCurrentRow][counter3*9+6];
                        }
                    }
                    
                    int timePointEndHold = 0;
                    
                    if (arrayTableDetail [trimOperationTableCurrentRow][5] != 0){
                        timePointEndHold = arrayTableDetail [trimOperationTableCurrentRow][5];
                    }
                    else timePointEndHold = arrayTableDetail [trimOperationTableCurrentRow][3];
                    
                    int totalNumberOfCells = arrayTableDetail [trimOperationTableCurrentRow][9];
                    
                    int *lineageExtractTemp = new int [arrayLineageDataEntryHold [trimOperationTableCurrentRow]+500+(unsigned long)(totalNumberOfCells*2*9)];
                    unsigned long lineageExtractTempCount = 0;
                    unsigned long lineageExtractTempLimit = arrayLineageDataEntryHold [trimOperationTableCurrentRow]+500+(unsigned long)(totalNumberOfCells*2*9);
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [trimOperationTableCurrentRow]/9; counter3++){
                        if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                            int *arrayUpDate = new int [lineageExtractTempCount+10];
                            
                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) arrayUpDate [counter4] = lineageExtractTemp [counter4];
                            
                            delete [] lineageExtractTemp;
                            lineageExtractTempLimit = lineageExtractTempCount+5000;
                            lineageExtractTemp = new int [lineageExtractTempLimit];
                            
                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) lineageExtractTemp [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+1], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+2], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+3], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+4], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+5], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+6], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+7], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+8], lineageExtractTempCount++;
                    }
                    
                    //----Data sort----
                    int *lineageExtractTempSort = new int [lineageExtractTempCount+100];
                    int lineageExtractTempSortCount = 0;
                    int *lineageExtractTempSort2 = new int [lineageExtractTempCount+100];
                    int lineageExtractTempSortCount2 = 0;
                    
                    int *cellExtractTempSort = new int [totalNumberOfCells+100];
                    int cellExtractTempSortCount = 0;
                    int *cellExtractTempSort2 = new int [totalNumberOfCells+100];
                    int cellExtractTempSortCount2 = 0;
                    
                    int maxLineageSort = 0; //==
                    int maxCellSort = 0; //==
                    int sortFind = 0;
                    int sortFindPosition = 0;
                    int terminationFlag = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                        if (lineageExtractTemp [counter3*9+6] > maxLineageSort) maxLineageSort = lineageExtractTemp [counter3*9+6];
                    }
                    
                    for (int counter3 = 1; counter3 <= maxLineageSort; counter3++){
                        lineageExtractTempSortCount = 0;
                        
                        for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount/9; counter4++){
                            if (lineageExtractTemp [counter4*9+6] == counter3){
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+1], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+2], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+3], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+4], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+5], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+6], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+7], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+8], lineageExtractTempSortCount++;
                            }
                        }
                        
                        cellExtractTempSortCount = 0;
                        
                        for (int counter4 = 0; counter4 < lineageExtractTempSortCount/9; counter4++){
                            sortFind = 0;
                            
                            for (int counter5 = 0; counter5 < cellExtractTempSortCount; counter5++){
                                if (cellExtractTempSort [counter5] == lineageExtractTempSort [counter4*9+5]){
                                    sortFind = 1;
                                    break;
                                }
                            }
                            
                            if (sortFind == 0){
                                cellExtractTempSort [cellExtractTempSortCount] = lineageExtractTempSort [counter4*9+5], cellExtractTempSortCount++;
                            }
                        }
                        
                        cellExtractTempSortCount2 = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            
                            maxCellSort = -999999999;
                            sortFindPosition = 0;
                            
                            for (int counter5 = 0; counter5 < cellExtractTempSortCount; counter5++){
                                if (cellExtractTempSort [counter5] > maxCellSort){
                                    maxCellSort = cellExtractTempSort [counter5];
                                    sortFindPosition = counter5;
                                }
                            }
                            
                            if (maxCellSort != -999999999){
                                cellExtractTempSort2 [cellExtractTempSortCount2] = maxCellSort, cellExtractTempSortCount2++;
                                cellExtractTempSort [sortFindPosition] = -999999999;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        for (int counter4 = 0; counter4 < cellExtractTempSortCount2; counter4++){
                            for (int counter5 = 0; counter5 < lineageExtractTempSortCount/9; counter5++){
                                if (cellExtractTempSort2 [counter4] == lineageExtractTempSort [counter5*9+5]){
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+1], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+2], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+3], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+4], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+5], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+6], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+7], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+8], lineageExtractTempSortCount2++;
                                }
                            }
                        }
                    }
                    
                    lineageExtractTempCount = 0;
                    
                    for (int counter3 = 0; counter3 < lineageExtractTempSortCount2; counter3++) lineageExtractTemp [lineageExtractTempCount] = lineageExtractTempSort2 [counter3], lineageExtractTempCount++;
                    
                    delete [] lineageExtractTempSort;
                    delete [] lineageExtractTempSort2;
                    delete [] cellExtractTempSort;
                    delete [] cellExtractTempSort2;
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp "<<counterA<<endl;
                    //}
                    
                    //----IF data: Array set----
                    int *ifExtractTemp = new int [arrayIFDataEntryHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*22];
                    int ifExtractTempCount = 0;
                    int ifExtractTempLimit = arrayIFDataEntryHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*22;
                    
                    for (int counter3 = 0; counter3 < arrayIFDataEntryHold [trimOperationTableCurrentRow]/22; counter3++){
                        if (ifExtractTempCount+50 > ifExtractTempLimit){
                            int *arrayUpDate = new int [ifExtractTempCount+10];
                            
                            for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) arrayUpDate [counter4] = ifExtractTemp [counter4];
                            
                            delete [] ifExtractTemp;
                            ifExtractTempLimit = ifExtractTempCount+5000;
                            ifExtractTemp = new int [ifExtractTempLimit];
                            
                            for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) ifExtractTemp [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+1], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+2], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+3], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+4], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+5], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+6], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+7], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+8], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+9], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+10], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+11], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+12], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+13], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+14], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+15], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+16], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+17], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+18], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+19], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+20], ifExtractTempCount++;
                        ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+21], ifExtractTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                    //    cout<<" ifExtractTemp "<<counterA<<endl;
                    //}
                    
                    int *arrayIFTimeLineDataTemp = new int [arrayIFTimeLineDataEntryHold [trimOperationTableCurrentRow]+50];
                    int arrayIFTimeLineDataTempCount = 0;
                    
                    for (int counter1 = 0; counter1 <= timePointEndHold; counter1++){
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+1], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+2], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+3], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+4], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+5], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+6], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+7], arrayIFTimeLineDataTempCount++;
                        arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+8], arrayIFTimeLineDataTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                    //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                    //}
                    
                    //----AreaData: Array set----
                    int *areaExtractTemp = new int [arrayAreaDataHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*5];
                    int areaExtractTempCount = 0;
                    int areaExtractTempLimit = arrayAreaDataHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*5;
                    
                    for (int counter3 = 0; counter3 < arrayAreaDataHold [trimOperationTableCurrentRow]/5; counter3++){
                        if (areaExtractTempCount+10 > areaExtractTempLimit){
                            int *arrayUpDate = new int [areaExtractTempCount+10];
                            
                            for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) arrayUpDate [counter4] = areaExtractTemp [counter4];
                            
                            delete [] areaExtractTemp;
                            areaExtractTempLimit = areaExtractTempCount+5000;
                            areaExtractTemp = new int [areaExtractTempLimit];
                            
                            for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) areaExtractTemp [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+1], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+2], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+3], areaExtractTempCount++;
                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+4], areaExtractTempCount++;
                    }
                    
                    int *lineageExtractTemp2 = new int [lineageExtractTempCount+500+(unsigned long)(totalNumberOfCells*2*9)];
                    int lineageExtractTempCount2 = 0;
                    
                    int *ifExtractTemp2 = new int [ifExtractTempCount+500+totalNumberOfCells*2*22];
                    int ifExtractTempCount2 = 0;
                    
                    int *areaExtractTemp2 = new int [areaExtractTempCount+500+totalNumberOfCells*2*5];
                    int areaExtractTempCount2 = 0;
                    
                    for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                        if (lineageExtractTemp [counter1*9+2] >= lineageTimeDivHold){
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+1], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+2], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+3], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+4], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+5], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+6], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+7], lineageExtractTempCount2++;
                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter1*9+8], lineageExtractTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < ifExtractTempCount/22; counter1++){
                        if (ifExtractTemp [counter1*22+2] >= lineageTimeDivHold){
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+1], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+2], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+3], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+4], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+5], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+6], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+7], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+8], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+9], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+10], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+11], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+12], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+13], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+14], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+15], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+16], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+17], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+18], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+19], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+20], ifExtractTempCount2++;
                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter1*22+21], ifExtractTempCount2++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp2 [counterA*13+counterB];
                    //    cout<<" ifExtractTemp2 "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 0; counter1 < areaExtractTempCount/5; counter1++){
                        if (areaExtractTemp [counter1*5+4] >= lineageTimeDivHold){
                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter1*5], areaExtractTempCount2++;
                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter1*5+1], areaExtractTempCount2++;
                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter1*5+2], areaExtractTempCount2++;
                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter1*5+3], areaExtractTempCount2++;
                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter1*5+4], areaExtractTempCount2++;
                        }
                    }
                    
                    int remainingCount = 0;
                    int endFind = 0;
                    int getCellNo = 0;
                    int getLingNo = 0;
                    int progenyNumberCount = 0;
                    int fluorescentHoldCount = 0;
                    int areaHoldCount = 0;
                    
                    int *lineageExtractTemp3 = new int [lineageExtractTempCount+500+(unsigned long)(totalNumberOfCells*2*9)];
                    int lineageExtractTempCount3 = 0;
                    
                    for (int counter1 = 0; counter1 < lineageExtractTempCount2/9; counter1++){
                        if (lineageExtractTemp2 [counter1*9+2] == lineageTimeDivHold){
                            remainingCount = 0;
                            endFind = 0;
                            
                            getCellNo = lineageExtractTemp2 [counter1*9+5];
                            getLingNo = lineageExtractTemp2 [counter1*9+6];
                            
                            for (int counter2 = counter1; counter2 < lineageExtractTempCount2/9; counter2++){
                                if (getLingNo == lineageExtractTemp2 [counter2*9+6] && getCellNo == lineageExtractTemp2 [counter2*9+5] && (lineageExtractTemp2 [counter2*9+3] == 32 || lineageExtractTemp2 [counter2*9+3] == 42 || lineageExtractTemp2 [counter2*9+3] == 52)){
                                    remainingCount++;
                                    
                                    endFind = 1;
                                    break;
                                }
                                else if (getLingNo == lineageExtractTemp2 [counter2*9+6] && getCellNo == lineageExtractTemp2 [counter2*9+5]) remainingCount++;
                            }
                            
                            if (endFind == 1 && remainingCount < 3){
                                int *progenyNumberHold = new int [10];
                                progenyNumberCount = 0;
                                
                                for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                    if (lineageExtractTemp2 [counter2*9+6] == getLingNo && lineageExtractTemp2 [counter2*9+4] == getCellNo && (lineageExtractTemp2 [counter2*9+3] == 31 || lineageExtractTemp2 [counter2*9+3] == 41 || lineageExtractTemp2 [counter2*9+3] == 51)){
                                        progenyNumberHold [progenyNumberCount] = lineageExtractTemp2 [counter2*9+5], progenyNumberCount++;
                                    }
                                }
                                
                                for (int counter2 = counter1; counter2 < lineageExtractTempCount2/9; counter2++){
                                    if (getCellNo == lineageExtractTemp2 [counter2*9+5] && getLingNo == lineageExtractTemp2 [counter2*9+6]){
                                        lineageExtractTemp2 [counter2*9] = -10;
                                        lineageExtractTemp2 [counter2*9+1] = -10;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < progenyNumberCount; counter2++){
                                    for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                        if (lineageExtractTemp2 [counter3*9+6] == getLingNo && lineageExtractTemp2 [counter3*9+5] == progenyNumberHold [counter2]){
                                            lineageExtractTempCount = 0;
                                            
                                            if (remainingCount >= 1){
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+1], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageTimeDivHold, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = 2, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+5], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+6], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+8], lineageExtractTempCount++;
                                                
                                                int *fluorescentHold = new int [70];
                                                fluorescentHoldCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < ifExtractTempCount2/22; counter4++){
                                                    if (ifExtractTemp2 [counter4*22] == progenyNumberHold [counter2] & ifExtractTemp2 [counter4*22+1] == getLingNo && ifExtractTemp2 [counter4*22+2] == lineageTimeDivHold){
                                                        fluorescentHold [fluorescentHoldCount] = progenyNumberHold [counter2], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+1], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = lineageTimeDivHold, fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+3], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+4], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+5], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+6], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+7], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+8], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+9], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+10], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+11], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+12], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+13], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+14], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+15], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+16], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+17], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+18], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+19], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+20], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+21], fluorescentHoldCount++;
                                                    }
                                                }
                                                
                                                //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                                                //    cout<<" lineageExtractTemp "<<counterA<<endl;
                                                //}
                                                
                                                if (fluorescentHoldCount != 0){
                                                    for (int counter4 = 0; counter4 < fluorescentHoldCount; counter4++) ifExtractTemp2 [ifExtractTempCount2] = fluorescentHold [counter4], ifExtractTempCount2++;
                                                }
                                                
                                                delete [] fluorescentHold;
                                                
                                                int *areaHold = new int [50];
                                                areaHoldCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < areaExtractTempCount2/5; counter4++){
                                                    if (areaExtractTemp2 [counter4*5] == getLingNo & areaExtractTemp2 [counter4*5+1] == progenyNumberHold [counter2] && areaExtractTemp2 [counter4*5+4] == lineageTimeDivHold){
                                                        areaHold [areaHoldCount] = areaExtractTemp2 [counter4*5], areaHoldCount++;
                                                        areaHold [areaHoldCount] = progenyNumberHold [counter2], areaHoldCount++;
                                                        areaHold [areaHoldCount] = areaExtractTemp2 [counter4*5+2], areaHoldCount++;
                                                        areaHold [areaHoldCount] = areaExtractTemp2 [counter4*5+3], areaHoldCount++;
                                                        areaHold [areaHoldCount] = lineageTimeDivHold, areaHoldCount++;
                                                        break;
                                                    }
                                                }
                                                
                                                for (int counter4 = 0; counter4 < areaHoldCount; counter4++) areaExtractTemp2 [areaExtractTempCount2] = areaHold [counter4], areaExtractTempCount2++;
                                                delete [] areaHold;
                                            }
                                            
                                            if (remainingCount == 2){
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+1], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageTimeDivHold+1, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = 2, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+5], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+6], lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                                                lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter3*9+8], lineageExtractTempCount++;
                                                
                                                int *fluorescentHold = new int [70];
                                                fluorescentHoldCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < ifExtractTempCount2/22; counter4++){
                                                    if (ifExtractTemp2 [counter4*22] == progenyNumberHold [counter2] & ifExtractTemp2 [counter4*22+1] == getLingNo && ifExtractTemp2 [counter4*22+2] == lineageTimeDivHold+1){
                                                        fluorescentHold [fluorescentHoldCount] = progenyNumberHold [counter2], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+1], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = lineageTimeDivHold+1, fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+3], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+4], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+5], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+6], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+7], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+8], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+9], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+10], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+11], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+12], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+13], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+14], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+15], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+16], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+17], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+18], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+19], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+20], fluorescentHoldCount++;
                                                        fluorescentHold [fluorescentHoldCount] = ifExtractTemp2 [counter4*22+21], fluorescentHoldCount++;
                                                    }
                                                }
                                                
                                                if (fluorescentHoldCount != 0){
                                                    for (int counter4 = 0; counter4 < fluorescentHoldCount; counter4++) ifExtractTemp2 [ifExtractTempCount2] = fluorescentHold [counter4], ifExtractTempCount2++;
                                                }
                                                
                                                //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                                                //    cout<<" lineageExtractTemp "<<counterA<<endl;
                                                //}
                                                
                                                delete [] fluorescentHold;
                                                
                                                int *areaHold = new int [50];
                                                areaHoldCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < areaExtractTempCount2/5; counter4++){
                                                    if (areaExtractTemp2 [counter4*5] == getLingNo & areaExtractTemp2 [counter4*5+1] == progenyNumberHold [counter2] && areaExtractTemp2 [counter4*5+4] == lineageTimeDivHold+1){
                                                        areaHold [areaHoldCount] = areaExtractTemp2 [counter4*5], areaHoldCount++;
                                                        areaHold [areaHoldCount] = progenyNumberHold [counter2], areaHoldCount++;
                                                        areaHold [areaHoldCount] = areaExtractTemp2 [counter4*5+2], areaHoldCount++;
                                                        areaHold [areaHoldCount] = areaExtractTemp2 [counter4*5+3], areaHoldCount++;
                                                        areaHold [areaHoldCount] = lineageTimeDivHold+1, areaHoldCount++;
                                                        break;
                                                    }
                                                }
                                                
                                                for (int counter4 = 0; counter4 < areaHoldCount; counter4++) areaExtractTemp2 [areaExtractTempCount2] = areaHold [counter4], areaExtractTempCount2++;
                                                delete [] areaHold;
                                            }
                                            
                                            for (int counter4 = 0; counter4 < lineageExtractTempCount2/9; counter4++){
                                                if (lineageExtractTemp2 [counter4*9+6] == getLingNo && lineageExtractTemp2 [counter4*9+5] == progenyNumberHold [counter2]){
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9], lineageExtractTempCount++;
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+1], lineageExtractTempCount++;
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+2], lineageExtractTempCount++;
                                                    
                                                    if (lineageExtractTemp2 [counter4*9+3] == 31 || lineageExtractTemp2 [counter4*9+3] == 41 || lineageExtractTemp2 [counter4*9+3] == 51){
                                                        lineageExtractTemp [lineageExtractTempCount] = 2, lineageExtractTempCount++;
                                                        lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                                                    }
                                                    else{
                                                        
                                                        lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+3], lineageExtractTempCount++;
                                                        lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+4], lineageExtractTempCount++;
                                                    }
                                                    
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+5], lineageExtractTempCount++;
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+6], lineageExtractTempCount++;
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+7], lineageExtractTempCount++;
                                                    lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter4*9+8], lineageExtractTempCount++;
                                                    
                                                    lineageExtractTemp2 [counter4*9+8] = -10;
                                                }
                                            }
                                            
                                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp [counter4], lineageExtractTempCount3++;
                                            
                                            //for (int counterA = 0; counterA < lineageExtractTempCount3/9; counterA++){
                                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp3 [counterA*9+counterB];
                                            //    cout<<" lineageExtractTemp3 "<<counterA<<endl;
                                            //}
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < ifExtractTempCount2/22; counter2++){
                                    if (ifExtractTemp2 [counter2*22] == getCellNo & ifExtractTemp2 [counter2*22+1] == getLingNo){
                                        ifExtractTemp2 [counter2*22+3] = -10;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < areaExtractTempCount2/5; counter2++){
                                    if (areaExtractTemp2 [counter2*5] == getLingNo && areaExtractTemp2 [counter2*5+1] == getCellNo){
                                        areaExtractTemp2 [counter2*5+2] = -10;
                                        areaExtractTemp2 [counter2*5+3] = -10;
                                    }
                                }
                                
                                delete [] progenyNumberHold;
                            }
                            else if (endFind == 0 && remainingCount < 3){
                                for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                    if (getCellNo == lineageExtractTemp2 [counter2*9+5] && getLingNo == lineageExtractTemp2 [counter2*9+6]){
                                        lineageExtractTemp3 [lineageExtractTempCount3] = -10, lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = -10, lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+2], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+3], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+4], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+5], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+6], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+7], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+8], lineageExtractTempCount3++;
                                        
                                        lineageExtractTemp2 [counter2*9+8] = -10;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < ifExtractTempCount2/22; counter2++){
                                    if (ifExtractTemp2 [counter2*22] == getCellNo & ifExtractTemp2 [counter2*22+1] == getLingNo){
                                        ifExtractTemp2 [counter2*22+3] = -10;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < areaExtractTempCount2/5; counter2++){
                                    if (areaExtractTemp2 [counter2*5] == getLingNo && areaExtractTemp2 [counter2*5+1] == getCellNo){
                                        areaExtractTemp2 [counter2*5+2] = -10;
                                        areaExtractTemp2 [counter2*5+3] = -10;
                                    }
                                }
                            }
                            else{
                                
                                for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                    if (getCellNo == lineageExtractTemp2 [counter2*9+5] && getLingNo == lineageExtractTemp2 [counter2*9+6]){
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+1], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+2], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+3], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+4], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+5], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+6], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+7], lineageExtractTempCount3++;
                                        lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+8], lineageExtractTempCount3++;
                                        
                                        lineageExtractTemp2 [counter2*9+8] = -10;
                                    }
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount3/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp3 [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp3 "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                        if (lineageExtractTemp2 [counter2*9+8] != -10){
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+1], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+2], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+3], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+4], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+5], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+6], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+7], lineageExtractTempCount3++;
                            lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2*9+8], lineageExtractTempCount3++;
                        }
                    }
                    
                    lineageExtractTempCount2 = 0;
                    
                    for (int counter2 = 0; counter2 < lineageExtractTempCount3; counter2++) lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp3 [counter2], lineageExtractTempCount2++;
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                    //}
                    
                    int mitosisFind = 0;
                    
                    for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                        if (lineageExtractTemp2 [counter2*9+2] == lineageTimeDivHold){
                            if (lineageExtractTemp2 [counter2*9] != -10 && lineageExtractTemp2 [counter2*9+1] != -10){
                                lineageExtractTemp2 [counter2*9+3] = 1;
                                lineageExtractTemp2 [counter2*9+4] = 0;
                                lineageExtractTemp2 [counter2*9+7] = 0;
                                
                                mitosisFind = 0;
                                endFind = 0;
                                
                                for (int counter3 = counter2; counter3 < lineageExtractTempCount2/9; counter3++){
                                    if (lineageExtractTemp2 [counter2*9+5] == lineageExtractTemp2 [counter3*9+5] && lineageExtractTemp2 [counter2*9+6] == lineageExtractTemp2 [counter3*9+6] && (lineageExtractTemp2 [counter3*9+3] == 32 || lineageExtractTemp2 [counter3*9+3] == 42 || lineageExtractTemp2 [counter3*9+3] == 52)){
                                        endFind = counter3;
                                        break;
                                    }
                                    else{
                                        
                                        if (lineageExtractTemp2 [counter3*9+3] == 6){
                                            mitosisFind = 1;
                                            break;
                                        }
                                    }
                                }
                                
                                if (endFind != 0 && mitosisFind == 0){
                                    lineageExtractTemp2 [(endFind-1)*9+3] = 6;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                    //}
                    
                    lineageExtractTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageExtractTempCount2/9; counter1++){
                        if (lineageExtractTemp2 [counter1*9] != -10 && lineageExtractTemp2 [counter1*9+1] != -10){
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+1], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+2], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+3], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+4], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+5], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+6], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+7], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp2 [counter1*9+8], lineageExtractTempCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp "<<counterA<<endl;
                    //}
                    
                    ifExtractTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < ifExtractTempCount2/22; counter1++){
                        if (ifExtractTemp2 [counter1*22+2] != -10){
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+1], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+2], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+3], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+4], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+5], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+6], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+7], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+8], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+9], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+10], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+11], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+12], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+13], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+14], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+15], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+16], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+17], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+18], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+19], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+20], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1*22+21], ifExtractTempCount++;
                        }
                    }
                    
                    areaExtractTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < areaExtractTempCount2/5; counter1++){
                        if (areaExtractTemp2 [counter1*5+2] != -10 && areaExtractTemp2 [counter1*5+3] != -10){
                            areaExtractTemp [areaExtractTempCount] = areaExtractTemp2 [counter1*5], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = areaExtractTemp2 [counter1*5+1], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = areaExtractTemp2 [counter1*5+2], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = areaExtractTemp2 [counter1*5+3], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = areaExtractTemp2 [counter1*5+4], areaExtractTempCount++;
                        }
                    }
                    
                    int cellNumberGet = 0;
                    int lineageNumberGet = 0;
                    int progenyCellNo = 0;
                    int newLineageNoCount = 1;
                    int cellNumberSend = 0;
                    int newCellNumber1 = 0;
                    int newCellNumber2 = 0;
                    int newCellNumber3 = 0;
                    int newCellNumber4 = 0;
                    int currentCellNumber1 = 0;
                    int currentCellNumber2 = 0;
                    int currentCellNumber3 = 0;
                    int currentCellNumber4 = 0;
                    int cellNumberDeleteHoldCount = 0;
                    int fusionFind = 0;
                    int currentSort [4];
                    int sortTemp [4];
                    int newSort [4];
                    int sortValue = 0;
                    int sortValuePosition = 0;
                    
                    lineageExtractTempCount3 = 0;
                    areaExtractTempCount2 = 0;
                    ifExtractTempCount2 = 0;
                    
                    for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                        if (lineageExtractTemp [counter1*9+2] == lineageTimeDivHold){
                            cellNumberGet = lineageExtractTemp [counter1*9+5];
                            lineageNumberGet = lineageExtractTemp [counter1*9+6];
                            
                            int *cellNumberDeleteHold = new int [totalNumberOfCells+50];
                            cellNumberDeleteHoldCount = 0;
                            
                            cellNumberDeleteHold2 = new int [totalNumberOfCells*2+50];
                            cellNumberDeleteHoldCount2 = 0;
                            
                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = cellNumberGet, cellNumberDeleteHoldCount2++;
                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = 0, cellNumberDeleteHoldCount2++;
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+4] == cellNumberGet && (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount++;
                                    cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount2++;
                                    cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = -1, cellNumberDeleteHoldCount2++;
                                }
                            }
                            
                            do {
                                
                                terminationFlag = 0;
                                
                                if (cellNumberDeleteHoldCount != 0){
                                    progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                    cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                    
                                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                        if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+4] == progenyCellNo && (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount2++;
                                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = -1, cellNumberDeleteHoldCount2++;
                                        }
                                    }
                                }
                                else terminationFlag = 1;
                                
                            } while (terminationFlag == 0);
                            
                            lineageExtractTempCount2 = 0;
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (lineageExtractTemp [counter2*9+5] == cellNumberDeleteHold2 [counter3*2] && lineageExtractTemp [counter2*9+6] == lineageNumberGet){
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+1], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+2], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+3], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+4], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+5], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+6], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+7], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+8], lineageExtractTempCount2++;
                                        break;
                                    }
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                if (cellNumberDeleteHold2 [counter3*2] == cellNumberGet){
                                    cellNumberDeleteHold2 [counter3*2+1] = 0;
                                    break;
                                }
                            }
                            
                            cellNumberDeleteHoldCount = 0;
                            
                            currentCellNumber1 = 0;
                            currentCellNumber2 = 0;
                            currentCellNumber3 = 0;
                            currentCellNumber4 = 0;
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                if (lineageExtractTemp2 [counter2*9+4] == cellNumberGet && (lineageExtractTemp2 [counter2*9+3] == 31 || lineageExtractTemp2 [counter2*9+3] == 41 || lineageExtractTemp2 [counter2*9+3] == 51)){
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp2 [counter2*9+5], cellNumberDeleteHoldCount++;
                                    
                                    if (currentCellNumber1 == 0) currentCellNumber1 = lineageExtractTemp2 [counter2*9+5];
                                    else if (currentCellNumber2 == 0) currentCellNumber2 = lineageExtractTemp2 [counter2*9+5];
                                    else if (currentCellNumber3 == 0) currentCellNumber3 = lineageExtractTemp2 [counter2*9+5];
                                    else if (currentCellNumber4 == 0) currentCellNumber4 = lineageExtractTemp2 [counter2*9+5];
                                }
                            }
                            
                            if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 == 0 && currentCellNumber4 == 0){
                                cellNumberProcessHold = 0;
                                
                                sortTemp [0] = currentCellNumber1;
                                sortTemp [1] = currentCellNumber2;
                                
                                if (sortTemp [0] < sortTemp [1]){
                                    currentSort [0] = sortTemp [1];
                                    currentSort [1] = sortTemp [0];
                                }
                                else{
                                    
                                    currentSort [0] = sortTemp [0];
                                    currentSort [1] = sortTemp [1];
                                }
                                
                                newCellNumber1 = [self primaryAddition];
                                newCellNumber2 = [self primarySubtract];
                                
                                sortTemp [0] = newCellNumber1;
                                sortTemp [1] = newCellNumber2;
                                
                                if (sortTemp [0] < sortTemp [1]){
                                    newSort [0] = sortTemp [1];
                                    newSort [1] = sortTemp [0];
                                }
                                else{
                                    
                                    newSort [0] = sortTemp [0];
                                    newSort [1] = sortTemp [1];
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                        break;
                                    }
                                }
                            }
                            
                            if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 == 0){
                                cellNumberProcessHold = 0;
                                
                                sortTemp [0] = currentCellNumber1;
                                sortTemp [1] = currentCellNumber2;
                                sortTemp [2] = currentCellNumber3;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 3; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 3; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    currentSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                newCellNumber1 = [self primaryAddition];
                                newCellNumber2 = [self primarySubtract];
                                newCellNumber3 = [self secondaryAddition];
                                
                                sortTemp [0] = newCellNumber1;
                                sortTemp [1] = newCellNumber2;
                                sortTemp [2] = newCellNumber3;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 3; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 3; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    newSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                        break;
                                    }
                                }
                            }
                            
                            if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 != 0){
                                cellNumberProcessHold = 0;
                                
                                sortTemp [0] = currentCellNumber1;
                                sortTemp [1] = currentCellNumber2;
                                sortTemp [2] = currentCellNumber3;
                                sortTemp [3] = currentCellNumber4;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 4; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 4; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    currentSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                newCellNumber1 = [self primaryAddition];
                                newCellNumber2 = [self primarySubtract];
                                newCellNumber3 = [self secondaryAddition];
                                newCellNumber4 = [self secondarySubtract];
                                
                                sortTemp [0] = newCellNumber1;
                                sortTemp [1] = newCellNumber2;
                                sortTemp [2] = newCellNumber3;
                                sortTemp [3] = newCellNumber4;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 4; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 4; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    newSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [3]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [3];
                                        break;
                                    }
                                }
                            }
                            
                            do {
                                
                                terminationFlag = 0;
                                
                                if (cellNumberDeleteHoldCount != 0){
                                    progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                    cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                    
                                    currentCellNumber1 = 0;
                                    currentCellNumber2 = 0;
                                    currentCellNumber3 = 0;
                                    currentCellNumber4 = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                        if (lineageExtractTemp2 [counter2*9+4] == progenyCellNo && (lineageExtractTemp2 [counter2*9+3] == 31 || lineageExtractTemp2 [counter2*9+3] == 41 || lineageExtractTemp2 [counter2*9+3] == 51)){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp2 [counter2*9+5], cellNumberDeleteHoldCount++;
                                            
                                            if (currentCellNumber1 == 0) currentCellNumber1 = lineageExtractTemp2 [counter2*9+5];
                                            else if (currentCellNumber2 == 0) currentCellNumber2 = lineageExtractTemp2 [counter2*9+5];
                                            else if (currentCellNumber3 == 0) currentCellNumber3 = lineageExtractTemp2 [counter2*9+5];
                                            else if (currentCellNumber4 == 0) currentCellNumber4 = lineageExtractTemp2 [counter2*9+5];
                                        }
                                    }
                                    
                                    cellNumberSend = 0;
                                    
                                    for (int counter2 = 0; counter2 < cellNumberDeleteHoldCount2/2; counter2++){
                                        if (progenyCellNo == cellNumberDeleteHold2 [counter2*2]){
                                            cellNumberSend = cellNumberDeleteHold2 [counter2*2+1];
                                            break;
                                        }
                                    }
                                    
                                    if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 == 0 && currentCellNumber4 == 0){
                                        cellNumberProcessHold = cellNumberSend;
                                        
                                        sortTemp [0] = currentCellNumber1;
                                        sortTemp [1] = currentCellNumber2;
                                        
                                        if (sortTemp [0] < sortTemp [1]){
                                            currentSort [0] = sortTemp [1];
                                            currentSort [1] = sortTemp [0];
                                        }
                                        else{
                                            
                                            currentSort [0] = sortTemp [0];
                                            currentSort [1] = sortTemp [1];
                                        }
                                        
                                        newCellNumber1 = [self primaryAddition];
                                        newCellNumber2 = [self primarySubtract];
                                        
                                        sortTemp [0] = newCellNumber1;
                                        sortTemp [1] = newCellNumber2;
                                        
                                        if (sortTemp [0] < sortTemp [1]){
                                            newSort [0] = sortTemp [1];
                                            newSort [1] = sortTemp [0];
                                        }
                                        else{
                                            
                                            newSort [0] = sortTemp [0];
                                            newSort [1] = sortTemp [1];
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 == 0){
                                        cellNumberProcessHold = cellNumberSend;
                                        
                                        sortTemp [0] = currentCellNumber1;
                                        sortTemp [1] = currentCellNumber2;
                                        sortTemp [2] = currentCellNumber3;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 3; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 3; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            currentSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        newCellNumber1 = [self primaryAddition];
                                        newCellNumber2 = [self primarySubtract];
                                        newCellNumber3 = [self secondaryAddition];
                                        
                                        sortTemp [0] = newCellNumber1;
                                        sortTemp [1] = newCellNumber2;
                                        sortTemp [2] = newCellNumber3;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 3; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 3; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            newSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                    }
                                    
                                    if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 != 0){
                                        cellNumberProcessHold = cellNumberSend;
                                        
                                        sortTemp [0] = currentCellNumber1;
                                        sortTemp [1] = currentCellNumber2;
                                        sortTemp [2] = currentCellNumber3;
                                        sortTemp [3] = currentCellNumber4;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 4; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 4; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            currentSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        newCellNumber1 = [self primaryAddition];
                                        newCellNumber2 = [self primarySubtract];
                                        newCellNumber3 = [self secondaryAddition];
                                        newCellNumber4 = [self secondarySubtract];
                                        
                                        sortTemp [0] = newCellNumber1;
                                        sortTemp [1] = newCellNumber2;
                                        sortTemp [2] = newCellNumber3;
                                        sortTemp [3] = newCellNumber4;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 4; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 4; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            newSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [3]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [3];
                                                break;
                                            }
                                        }
                                    }
                                }
                                else terminationFlag = 1;
                                
                            } while (terminationFlag == 0);
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (lineageExtractTemp2 [counter2*9+5] == cellNumberDeleteHold2 [counter3*2]){
                                        lineageExtractTemp2 [counter2*9+5] = cellNumberDeleteHold2 [counter3*2+1];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (lineageExtractTemp2 [counter2*9+4] == cellNumberDeleteHold2 [counter3*2]){
                                        if (lineageExtractTemp2 [counter2*9+3] != 91 && lineageExtractTemp2 [counter2*9+3] != 92){
                                            lineageExtractTemp2 [counter2*9+4] = cellNumberDeleteHold2 [counter3*2+1];
                                            break;
                                        }
                                    }
                                }
                                
                                fusionFind = 0;
                                
                                if (lineageExtractTemp2 [counter2*9+3] == 91 || lineageExtractTemp2 [counter2*9+3] == 92){
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (lineageExtractTemp2 [counter2*9+4] == cellNumberDeleteHold2 [counter3*2]){
                                            lineageExtractTemp2 [counter2*9+4] = cellNumberDeleteHold2 [counter3*2+1];
                                            lineageExtractTemp2 [counter2*9+7] = newLineageNoCount;
                                            fusionFind = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fusionFind == 0){
                                        lineageExtractTemp2 [counter2*9+4] = 0;
                                        lineageExtractTemp2 [counter2*9+7] = 0;
                                    }
                                }
                                
                                lineageExtractTemp2 [counter2*9+2] = lineageExtractTemp2 [counter2*9+2]-lineageTimeDivHold+1;
                                lineageExtractTemp2 [counter2*9+6] = newLineageNoCount;
                            }
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempCount2; counter2++) lineageExtractTemp3 [lineageExtractTempCount3] = lineageExtractTemp2 [counter2], lineageExtractTempCount3++;
                            
                            //for (int counterA = 0; counterA < lineageExtractTempCount3/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp3 [counterA*9+counterB];
                            //    cout<<" lineageExtractTemp3 "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                                if (ifExtractTemp [counter2*22+1] == lineageNumberGet){
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (ifExtractTemp [counter2*22] == cellNumberDeleteHold2 [counter3*2]){
                                            ifExtractTemp2 [ifExtractTempCount2] = cellNumberDeleteHold2 [counter3*2+1], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = newLineageNoCount, ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+2]-lineageTimeDivHold+1, ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+3], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+4], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+5], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+6], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+7], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+8], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+9], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+10], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+11], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+12], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+13], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+14], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+15], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+16], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+17], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+18], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+19], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+20], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+21], ifExtractTempCount2++;
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < areaExtractTempCount/5; counter2++){
                                if (areaExtractTemp [counter2*5] == lineageNumberGet){
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (areaExtractTemp [counter2*5+1] == cellNumberDeleteHold2 [counter3*2]){
                                            areaExtractTemp2 [areaExtractTempCount2] = newLineageNoCount, areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = cellNumberDeleteHold2 [counter3*2+1], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+2], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+3], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+4], areaExtractTempCount2++;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            newLineageNoCount++;
                            
                            delete [] cellNumberDeleteHold;
                            delete [] cellNumberDeleteHold2;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                    //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                    //}
                    
                    int *arrayIFTimeLineDataTemp2 = new int [arrayIFTimeLineDataTempCount+50];
                    int arrayIFTimeLineDataTempCount2 = 0;
                    
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                    
                    int newIFStart = 0;
                    
                    for (int counter1 = 0; counter1 < arrayIFTimeLineDataTempCount/9; counter1++){
                        if (counter1 >= lineageTimeDivHold){
                            if (arrayIFTimeLineDataTemp [counter1*9] != 0){
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9]-lineageTimeDivHold+1, arrayIFTimeLineDataTempCount2++;
                            }
                            else arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9], arrayIFTimeLineDataTempCount2++;
                            
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+1], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+2], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+3], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+4], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+5], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+6], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+7], arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter1*9+8], arrayIFTimeLineDataTempCount2++;
                            
                            if (arrayIFTimeLineDataTemp [counter1*9]-lineageTimeDivHold+1 != 0 && arrayIFTimeLineDataTemp [counter1*9+1] > 0 && newIFStart == 0){
                                newIFStart = arrayIFTimeLineDataTemp [counter1*9]-lineageTimeDivHold+1;
                            }
                        }
                    }
                    
                    lineageExtractTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < lineageExtractTempCount3; counter1++) lineageExtractTemp [lineageExtractTempCount] = lineageExtractTemp3 [counter1], lineageExtractTempCount++;
                    
                    delete [] lineageExtractTemp2;
                    delete [] lineageExtractTemp3;
                    
                    ifExtractTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < ifExtractTempCount2; counter1++) ifExtractTemp [ifExtractTempCount] = ifExtractTemp2 [counter1], ifExtractTempCount++;
                    
                    delete [] ifExtractTemp2;
                    
                    areaExtractTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < areaExtractTempCount2; counter1++) areaExtractTemp [areaExtractTempCount] = areaExtractTemp2 [counter1], areaExtractTempCount++;
                    
                    delete [] areaExtractTemp2;
                    
                    arrayIFTimeLineDataTempCount = 0;
                    
                    for (int counter1 = 0; counter1 < arrayIFTimeLineDataTempCount2; counter1++) arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineDataTemp2 [counter1], arrayIFTimeLineDataTempCount++;
                    
                    delete [] arrayIFTimeLineDataTemp2;
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                    //    cout<<" ifExtractTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                    //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                    //    cout<<" areaExtractTemp "<<counterA<<endl;
                    //}
                    
                    int timeDICEnd = 0;
                    
                    if (newIFStart == 0) timeDICEnd = arrayTableDetail [trimOperationTableCurrentRow][3]-lineageTimeDivHold+1;
                    else timeDICEnd = newIFStart-1;
                    
                    //----Detail table data: Array set----
                    int *arrayTableDetailTemp = new int [20];
                    
                    int noOfLing = 0;
                    int noOfCellStart = 0;
                    int noOfCellEnd = 0;
                    int noOfTotalCells = 0;
                    int noOfDD = 0;
                    int noOfTD = 0;
                    int noOfHD = 0;
                    int noOfMI = 0;
                    int noOfFU = 0;
                    int noOfCD = 0;
                    
                    int maxLineageNo = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                        if (lineageExtractTemp [counter3*9+2] == 1 && (lineageExtractTemp [counter3*9+5] == 0 || lineageExtractTemp [counter3*9+5] == -1)){
                            noOfLing++;
                        }
                        
                        if (maxLineageNo < lineageExtractTemp [counter3*9+6]) maxLineageNo = lineageExtractTemp [counter3*9+6]; //==
                        
                        if (lineageExtractTemp [counter3*9+2] == 1 && lineageExtractTemp [counter3*9+5] == 0){
                            noOfCellStart++;
                        }
                        
                        if ((lineageExtractTemp [counter3*9+3] == 1 || lineageExtractTemp [counter3*9+3] == 31 || lineageExtractTemp [counter3*9+3] == 41 || lineageExtractTemp [counter3*9+3] == 51)){
                            noOfTotalCells++;
                        }
                        
                        if (lineageExtractTemp [counter3*9+2] == timeDICEnd) noOfCellEnd++;
                        if (lineageExtractTemp [counter3*9+3] == 32) noOfDD++;
                        if (lineageExtractTemp [counter3*9+3] == 42) noOfTD++;
                        if (lineageExtractTemp [counter3*9+3] == 52) noOfHD++;
                        if (lineageExtractTemp [counter3*9+3] == 6) noOfMI++;
                        if (lineageExtractTemp [counter3*9+3] == 91) noOfFU++;
                        if (lineageExtractTemp [counter3*9+3] == 7) noOfCD++;
                    }
                    
                    arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                    arrayTableDetailTemp [1] = noOfLing;
                    arrayTableDetailTemp [2] = 1;
                    arrayTableDetailTemp [3] = timeDICEnd;
                    
                    if (newIFStart != 0){
                        arrayTableDetailTemp [4] = newIFStart;
                        arrayTableDetailTemp [5] = arrayTableDetail [trimOperationTableCurrentRow][5]-lineageTimeDivHold+1;
                    }
                    else{
                        
                        arrayTableDetailTemp [4] = 0;
                        arrayTableDetailTemp [5] = 0;
                    }
                    
                    arrayTableDetailTemp [6] = noOfCellStart;
                    arrayTableDetailTemp [7] = noOfCellEnd;
                    
                    double foldTemp = 0;
                    
                    if (noOfCellStart != 0){
                        foldTemp = noOfCellEnd/(double)noOfCellStart;
                        foldTemp = foldTemp*10+1;
                    }
                    else foldTemp = 1;
                    
                    arrayTableDetailTemp [8] = (int)foldTemp;
                    arrayTableDetailTemp [9] = noOfTotalCells;
                    arrayTableDetailTemp [10] = noOfDD;
                    arrayTableDetailTemp [11] = noOfTD;
                    arrayTableDetailTemp [12] = noOfHD;
                    arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                    arrayTableDetailTemp [14] = noOfMI;
                    arrayTableDetailTemp [15] = noOfFU;
                    arrayTableDetailTemp [16] = noOfCD;
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                    //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                    //}
                    
                    //----Link Data----
                    int lingNoTemp = 0;
                    int matchFind = 0;
                    int freeSpotFind = 0;
                    int previousLengthHold = 0;
                    int readingCount = 0;
                    int lengthExpansionFlag = 0;
                    int entryNo = 0;
                    int expansionNo = 0;
                    int findFlag = 0;
                    
                    int lineageLinkListLengthTemp = 4;
                    int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                    int lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                    
                    for (int counter1 = 0; counter1 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter1++) arrayLineageLinkTemp [counter1] = 0;
                    
                    for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                        if (lineageExtractTemp [counter1*9+3] == 31 || lineageExtractTemp [counter1*9+3] == 41 || lineageExtractTemp [counter1*9+3] == 51 || lineageExtractTemp [counter1*9+3] == 1){
                            lingNoTemp = lineageExtractTemp [counter1*9+6];
                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                        }
                    }
                    
                    for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                        lingNoTemp = lineageExtractTemp [counter1*9+6];
                        
                        if (lineageExtractTemp [counter1*9+7] != 0 && lineageExtractTemp [counter1*9+7] != lingNoTemp){
                            matchFind = 0;
                            freeSpotFind = 0;
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter2] == lineageExtractTemp [counter1*9+7]){
                                    matchFind = 1;
                                }
                                
                                if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter2] == 0 && freeSpotFind == 0){
                                    freeSpotFind = counter2;
                                }
                            }
                            
                            if (matchFind == 0){
                                if (freeSpotFind == 0){
                                    previousLengthHold = lineageLinkListLengthTemp;
                                    int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                    
                                    for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++) arrayUpDate [counter2] = arrayLineageLinkTemp [counter2];
                                    
                                    delete [] arrayLineageLinkTemp;
                                    lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                    arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                    lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                    
                                    readingCount = 0;
                                    
                                    for (int counter2 = 0; counter2 <= maxLineageNo; counter2++){
                                        for (int counter3 = 0; counter3 < previousLengthHold; counter3++){
                                            arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] = arrayUpDate [readingCount], readingCount++;
                                        }
                                        
                                        arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                        arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                    }
                                    
                                    delete [] arrayUpDate;
                                    
                                    freeSpotFind = previousLengthHold;
                                }
                                
                                arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = lineageExtractTemp [counter1*9+7];
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                    //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                    //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                    //}
                    
                    for (int counter1 = 1; counter1 <= maxLineageNo; counter1++){
                        if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+1] != 0){
                            freeSpotFind = -1;
                            
                            for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] == 0){
                                    freeSpotFind = counter2;
                                    break;
                                }
                            }
                            
                            if (freeSpotFind == -1) freeSpotFind = 4;
                            
                            do{
                                
                                terminationFlag = 1;
                                
                                for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                    if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                        lengthExpansionFlag = 0;
                                        
                                        for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                                            if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2]){
                                                entryNo = 0;
                                                
                                                for (int counter4 = 1; counter4 < lineageLinkListLengthTemp; counter4++){
                                                    findFlag = 0;
                                                    
                                                    for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                        if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] != 0 && (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter5] || arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == counter1)){
                                                            findFlag = 1;
                                                        }
                                                        else if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == 0) findFlag = 1;
                                                    }
                                                    
                                                    if (findFlag == 0) entryNo++;
                                                }
                                                
                                                if (entryNo != 0){
                                                    if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                        previousLengthHold = lineageLinkListLengthTemp;
                                                        int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                        
                                                        for (int counter4 = 0; counter4 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter4++) arrayUpDate [counter4] = arrayLineageLinkTemp [counter4];
                                                        
                                                        if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                        else expansionNo = freeSpotFind+entryNo;
                                                        
                                                        delete [] arrayLineageLinkTemp;
                                                        lineageLinkListLengthTemp = expansionNo+2;
                                                        arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                        lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                        
                                                        expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                        
                                                        readingCount = 0;
                                                        
                                                        for (int counter4 = 0; counter4 <= maxLineageNo; counter4++){
                                                            for (int counter5 = 0; counter5 < previousLengthHold; counter5++){
                                                                arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] = arrayUpDate [readingCount], readingCount++;
                                                            }
                                                            
                                                            for (int counter5 = 0; counter5 < expansionNo; counter5++){
                                                                arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+previousLengthHold+counter5] = 0;
                                                            }
                                                        }
                                                        
                                                        delete [] arrayUpDate;
                                                        
                                                        lengthExpansionFlag = 1;
                                                        
                                                        break;
                                                    }
                                                    else{
                                                        
                                                        for (int counter4 = 1; counter4 < lineageLinkListLengthTemp; counter4++){
                                                            findFlag = 0;
                                                            
                                                            for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                                if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] != 0 && (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter5] || arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == counter1)){
                                                                    findFlag = 1;
                                                                }
                                                                else if (arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] == 0) findFlag = 1;
                                                            }
                                                            
                                                            if (findFlag != 1){
                                                                arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4];
                                                                
                                                                freeSpotFind++;
                                                            }
                                                        }
                                                        
                                                        arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] = -1;
                                                        break;
                                                    }
                                                }
                                                else arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp] = -1;
                                            }
                                        }
                                        
                                        if (lengthExpansionFlag == 1){
                                            break;
                                        }
                                    }
                                    
                                    if (counter2 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                                }
                                
                            } while (terminationFlag == 1);
                        }
                    }
                    
                    //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                    //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                    //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                    //}
                    
                    int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                    int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                    int numberOfFusionEntry = 0;
                    int smallestEntry2 = 0;
                    int remainingFlag = 0;
                    int smallestEntry = 0;
                    int smallestEntryPosition = 0;
                    
                    for (int counter1 = 1; counter1 <= maxLineageNo; counter1++){
                        if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+1] != 0){
                            numberOfFusionEntry = 0;
                            
                            for (int counter2 = 0; counter2 < lineageLinkListLengthTemp; counter2++){
                                if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                    numberOfFusionEntry++;
                                }
                            }
                            
                            if (numberOfFusionEntry > 1){
                                for (int counter2 = 0; counter2 < lineageLinkListLengthTemp; counter2++){
                                    if (arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] != 0){
                                        numberOfEntryList [counter2] = arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2];
                                    }
                                    else numberOfEntryList [counter2] = 0;
                                    
                                    numberOfEntryList2 [counter2] = 0;
                                }
                                
                                smallestEntry2 = 1;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    remainingFlag = 0;
                                    smallestEntry = 100000;
                                    smallestEntryPosition = 0;
                                    
                                    for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                        if (numberOfEntryList [counter2] != 0 && numberOfEntryList [counter2] < smallestEntry){
                                            smallestEntry = numberOfEntryList [counter2];
                                            smallestEntryPosition = counter2;
                                            remainingFlag = 1;
                                        }
                                    }
                                    
                                    if (remainingFlag == 0) terminationFlag = 0;
                                    else{
                                        
                                        numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                        numberOfEntryList [smallestEntryPosition] = 0;
                                    }
                                    
                                } while (terminationFlag == 1);
                                
                                for (int counter2 = 1; counter2 < lineageLinkListLengthTemp; counter2++){
                                    arrayLineageLinkTemp [counter1*lineageLinkListLengthTemp+counter2] = numberOfEntryList2 [counter2];
                                }
                            }
                        }
                    }
                    
                    delete [] numberOfEntryList;
                    delete [] numberOfEntryList2;
                    
                    //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                    //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                    //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                    //}
                    
                    //----Lineage Data type: Array Set----
                    for (int counter3 = 0; counter3 < 7; counter3++){
                        arrayLineageDataType [lineageDataEntryCount][counter3] = arrayLineageDataType [trimOperationTableCurrentRow][counter3];
                    }
                    
                    arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                    arrayLineageDataType [lineageDataEntryCount][1] = "AN"+to_string(maxCategoryLingNo);
                    
                    //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                    //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" arrayLineageDataType "<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                    //}
                    
                    //----LineageFluorescentDataType: Array Set----
                    int fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                    
                    for (int counter3 = 0; counter3 < fluorescentDataEntryCount; counter3++){
                        if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                        
                        if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == trimOperationTableCurrentRow+1){
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter3][1];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter3][2];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter3][3];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter3][4];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter3][5];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter3][6];
                            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter3][7];
                            
                            lineageFluorescentDataTypeEntryCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                    //}
                    
                    //----Data save----
                    ofstream oin;
                    
                    string savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                    
                    oin.open(savePath.c_str(), ios::out);
                    oin<<to_string(lineageDataEntryCount+1)<<endl;
                    oin<<"AN"+to_string(maxCategoryLingNo)<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                    oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                    
                    for (int counter3 = 0; counter3 < lineageFluorescentDataTypeEntryCount; counter3++){
                        if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == lineageDataEntryCount+1){
                            oin<<arrayLineageFluorescentDataType [counter3][0]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][1]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][2]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][3]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][4]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][5]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][6]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter3][7]<<endl;
                        }
                    }
                    
                    oin.close();
                    
                    if (lineageDataEntryCount < 101){
                        delete [] arrayLineageData [lineageDataEntryCount];
                        delete [] arrayIFData [lineageDataEntryCount];
                        delete [] arrayIFTimeLineData [lineageDataEntryCount];
                        delete [] arrayTableMain [lineageDataEntryCount];
                        delete [] arrayIfTimeStatus [lineageDataEntryCount];
                        delete [] arrayAreaData [lineageDataEntryCount];
                        delete [] arrayLineageLink [lineageDataEntryCount];
                        
                        arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                        arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                        arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataTempCount+10];
                        arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [trimOperationTableCurrentRow]+10];
                        arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [trimOperationTableCurrentRow]+10];
                        arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                        arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                        
                        lineageDataEntryCount++;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Entry Limit Exceeded: 100"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    
                    if (lineageDataEntryCount-1 < 101){
                        for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) arrayLineageData [lineageDataEntryCount-1][counter3] = lineageExtractTemp [counter3];
                        
                        arrayLineageDataEntryHold [lineageDataEntryCount-1] = lineageExtractTempCount;
                        
                        //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                        //    cout<<" arrayLineageData "<<counterA<<endl;
                        //}
                        
                        for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) arrayIFData [lineageDataEntryCount-1][counter3] = ifExtractTemp [counter3];
                        
                        arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount;
                        
                        //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                        //    cout<<" arrayIFData "<<counterA<<endl;
                        //}
                        
                        for (int counter3 = 0; counter3 < arrayIFTimeLineDataTempCount; counter3++){
                            arrayIFTimeLineData [lineageDataEntryCount-1][counter3] = arrayIFTimeLineDataTemp [counter3];
                        }
                        
                        arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataTempCount;
                        
                        for (int counter3 = 0; counter3 < arrayTableMainHold [trimOperationTableCurrentRow]; counter3++) arrayTableMain [lineageDataEntryCount-1][counter3] = arrayTableMain [trimOperationTableCurrentRow][counter3];
                        
                        arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                        arrayTableMain [lineageDataEntryCount-1][1] = "AN";
                        arrayTableMain [lineageDataEntryCount-1][4] = "AN"+to_string(maxCategoryLingNo)+"-"+treatNameExtract;
                        
                        arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [trimOperationTableCurrentRow];
                        
                        for (int counter3 = 0; counter3 < 17; counter3++) arrayTableDetail [lineageDataEntryCount-1][counter3] = arrayTableDetailTemp [counter3];
                        
                        int ifStatusEntryCount = 0;
                        
                        if (arrayTableDetailTemp [4] != 0){
                            for (int counter1 = arrayTableDetailTemp [4]; counter1 <= arrayTableDetailTemp [5]; counter1++){
                                arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = counter1, ifStatusEntryCount++;
                                arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = 0, ifStatusEntryCount++;
                            }
                        }
                        
                        arrayIfTimeStatusHold [lineageDataEntryCount-1] = ifStatusEntryCount;
                        
                        for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) arrayAreaData [lineageDataEntryCount-1][counter3] = areaExtractTemp [counter3];
                        
                        arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount;
                        
                        //**********arrayLinkData**********
                        for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++){
                            arrayLineageLink [lineageDataEntryCount-1][counter3] = arrayLineageLinkTemp [counter3];
                        }
                        
                        arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                        
                        lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                        
                        savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                        
                        char *writingArray = new char [lineageExtractTempCount/9*28+100];
                        
                        long indexCount = 0;
                        int readBit [4];
                        int dataTemp;
                        
                        for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                            if (lineageExtractTemp [counter3*9] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9];
                            }
                            
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            if (lineageExtractTemp [counter3*9+1] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9+1]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9+1];
                            }
                            
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            dataTemp = lineageExtractTemp [counter3*9+2];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)lineageExtractTemp [counter3*9+3], indexCount++;
                            
                            if (lineageExtractTemp [counter3*9+4] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9+4]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9+4];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            if (lineageExtractTemp [counter3*9+5] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9+5]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = lineageExtractTemp [counter3*9+5];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            dataTemp = lineageExtractTemp [counter3*9+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = lineageExtractTemp [counter3*9+7];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = lineageExtractTemp [counter3*9+8];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter3 = 0; counter3 < 28; counter3++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile (savePath.c_str(), ofstream::binary);
                        outfile.write ((char*) writingArray, indexCount);
                        outfile.close();
                        
                        delete [] writingArray;
                        
                        savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<lineageExtractTempCount<<endl;
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"IFData";
                        
                        writingArray = new char [ifExtractTempCount/22*60+60];
                        
                        indexCount = 0;
                        
                        for (int counter3 = 0; counter3 < ifExtractTempCount/22; counter3++){
                            if (ifExtractTemp [counter3*22] < 0){
                                writingArray [indexCount] = 1, indexCount++;
                                dataTemp = ifExtractTemp [counter3*22]*-1;
                            }
                            else{
                                
                                writingArray [indexCount] = 0, indexCount++;
                                dataTemp = ifExtractTemp [counter3*22];
                            }
                            
                            readBit [0] = dataTemp/16777216;
                            dataTemp = dataTemp%16777216;
                            readBit [1] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [2] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [3] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            writingArray [indexCount] = (char)readBit [3], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+1];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+2];
                            readBit [0] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [1] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+3], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+4], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+5];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+6];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+7], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+8];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+9];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+10], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+11];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+12];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+13], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+14];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+15];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+16], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+17];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+18];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            writingArray [indexCount] = (char)ifExtractTemp [counter3*22+19], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+20];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                            
                            dataTemp = ifExtractTemp [counter3*22+21];
                            readBit [0] = dataTemp/65536;
                            dataTemp = dataTemp%65536;
                            readBit [1] = dataTemp/256;
                            dataTemp = dataTemp%256;
                            readBit [2] = dataTemp;
                            
                            writingArray [indexCount] = (char)readBit [0], indexCount++;
                            writingArray [indexCount] = (char)readBit [1], indexCount++;
                            writingArray [indexCount] = (char)readBit [2], indexCount++;
                        }
                        
                        for (int counter3 = 0; counter3 < 33; counter3++) writingArray [indexCount] = 0, indexCount++;
                        
                        ofstream outfile2 (savePath.c_str(), ofstream::binary);
                        outfile2.write ((char*) writingArray, indexCount);
                        outfile2.close();
                        
                        delete [] writingArray;
                        
                        savePath = imageDisplayPath+"/"+"IFDataEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<ifExtractTempCount<<endl;
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"IFTimeLine";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        
                        for (int counter3 = 0; counter3 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter3++){
                            oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter3]<<endl;
                        }
                        
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"MainTable";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        
                        for (int counter3 = 0; counter3 < arrayTableMainHold [lineageDataEntryCount-1]; counter3++){
                            oin<<arrayTableMain [lineageDataEntryCount-1][counter3]<<endl;
                        }
                        
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"MainTableEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"DetailTable";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        
                        for (int counter3 = 0; counter3 < 17; counter3++){
                            oin<<arrayTableDetail [lineageDataEntryCount-1][counter3]<<endl;
                        }
                        
                        oin.close();
                        
                        savePath = imageDisplayPath+"/IFDataStatus";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        
                        for (int counter3 = 0; counter3 < arrayIfTimeStatusHold [lineageDataEntryCount-1]; counter3++){
                            oin<<arrayIfTimeStatus [lineageDataEntryCount-1][counter3]<<endl;
                        }
                        
                        oin.close();
                        
                        savePath = imageDisplayPath+"/IFDataStatusEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<arrayIfTimeStatusHold [lineageDataEntryCount-1]<<endl;
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"AreaData";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        
                        for (int counter3 = 0; counter3 < arrayAreaDataHold [lineageDataEntryCount-1]; counter3++){
                            oin<<arrayAreaData [lineageDataEntryCount-1][counter3]<<endl;
                        }
                        
                        oin.close();
                        
                        savePath = imageDisplayPath+"/AreaDataEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                        oin.close();
                        
                        savePath = imageDisplayPath+"/"+"LinkData";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        
                        for (int counter3 = 0; counter3 < lineageLinkHold [lineageDataEntryCount-1]; counter3++){
                            oin<<arrayLineageLink [lineageDataEntryCount-1][counter3]<<endl;
                        }
                        
                        oin.close();
                        
                        savePath = imageDisplayPath+"/LinkDataEntry";
                        
                        oin.open(savePath.c_str(), ios::out | ios::binary);
                        oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                        oin.close();
                    }
                    
                    delete [] lineageExtractTemp;
                    delete [] ifExtractTemp;
                    delete [] areaExtractTemp;
                    delete [] arrayLineageLinkTemp;
                    delete [] arrayIFTimeLineDataTemp;
                    delete [] arrayTableDetailTemp;
                    
                    upLoadingFlag = 1;
                    
                    if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                    if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                    if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                    if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                    if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                    if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                    if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
                else if (lineageCutStatusHold == 1){
                    int totalNumberOfCells = arrayTableDetail [trimOperationTableCurrentRow][9];
                    
                    int *cellDoublingInformation = new int [totalNumberOfCells*5+50];
                    int cellDoublingInformationCount = 0;
                    
                    for (int counter3 = 0; counter3 < totalNumberOfCells*5+50; counter3++) cellDoublingInformation [counter3] = -1;
                    
                    int *lineageExtractTemp = new int [arrayLineageDataEntryHold [trimOperationTableCurrentRow]+500];
                    unsigned long lineageExtractTempCount = 0;
                    unsigned long lineageExtractTempLimit = arrayLineageDataEntryHold [trimOperationTableCurrentRow]+500;
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [trimOperationTableCurrentRow]/9; counter3++){
                        if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                            int *arrayUpDate = new int [lineageExtractTempCount+10];
                            
                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) arrayUpDate [counter4] = lineageExtractTemp [counter4];
                            
                            delete [] lineageExtractTemp;
                            lineageExtractTempLimit = lineageExtractTempCount+5000;
                            lineageExtractTemp = new int [lineageExtractTempLimit];
                            
                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) lineageExtractTemp [counter4] = arrayUpDate [counter4];
                            delete [] arrayUpDate;
                        }
                        
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+1], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+2], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+3], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+4], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+5], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+6], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+7], lineageExtractTempCount++;
                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+8], lineageExtractTempCount++;
                    }
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp "<<counterA<<endl;
                    //}
                    
                    //----Data sort----
                    int *lineageExtractTempSort = new int [lineageExtractTempCount+100];
                    int lineageExtractTempSortCount = 0;
                    int *lineageExtractTempSort2 = new int [lineageExtractTempCount+100];
                    int lineageExtractTempSortCount2 = 0;
                    
                    int *cellExtractTempSort = new int [totalNumberOfCells+100];
                    int cellExtractTempSortCount = 0;
                    int *cellExtractTempSort2 = new int [totalNumberOfCells+100];
                    int cellExtractTempSortCount2 = 0;
                    
                    int maxLineageSort = 0; //==
                    int maxCellSort = 0; //==
                    int sortFind = 0;
                    int sortFindPosition = 0;
                    int terminationFlag = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                        if (lineageExtractTemp [counter3*9+6] > maxLineageSort) maxLineageSort = lineageExtractTemp [counter3*9+6];
                    }
                    
                    for (int counter3 = 1; counter3 <= maxLineageSort; counter3++){
                        lineageExtractTempSortCount = 0;
                        
                        for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount/9; counter4++){
                            if (lineageExtractTemp [counter4*9+6] == counter3){
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+1], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+2], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+3], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+4], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+5], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+6], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+7], lineageExtractTempSortCount++;
                                lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+8], lineageExtractTempSortCount++;
                            }
                        }
                        
                        cellExtractTempSortCount = 0;
                        
                        for (int counter4 = 0; counter4 < lineageExtractTempSortCount/9; counter4++){
                            sortFind = 0;
                            
                            for (int counter5 = 0; counter5 < cellExtractTempSortCount; counter5++){
                                if (cellExtractTempSort [counter5] == lineageExtractTempSort [counter4*9+5]){
                                    sortFind = 1;
                                    break;
                                }
                            }
                            
                            if (sortFind == 0){
                                cellExtractTempSort [cellExtractTempSortCount] = lineageExtractTempSort [counter4*9+5], cellExtractTempSortCount++;
                            }
                        }
                        
                        cellExtractTempSortCount2 = 0;
                        
                        do{
                            
                            terminationFlag = 1;
                            maxCellSort = -999999999;
                            sortFindPosition = 0;
                            
                            for (int counter5 = 0; counter5 < cellExtractTempSortCount; counter5++){
                                if (cellExtractTempSort [counter5] > maxCellSort){
                                    maxCellSort = cellExtractTempSort [counter5];
                                    sortFindPosition = counter5;
                                }
                            }
                            
                            if (maxCellSort != -999999999){
                                cellExtractTempSort2 [cellExtractTempSortCount2] = maxCellSort, cellExtractTempSortCount2++;
                                cellExtractTempSort [sortFindPosition] = -999999999;
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        for (int counter4 = 0; counter4 < cellExtractTempSortCount2; counter4++){
                            for (int counter5 = 0; counter5 < lineageExtractTempSortCount/9; counter5++){
                                if (cellExtractTempSort2 [counter4] == lineageExtractTempSort [counter5*9+5]){
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+1], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+2], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+3], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+4], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+5], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+6], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+7], lineageExtractTempSortCount2++;
                                    lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+8], lineageExtractTempSortCount2++;
                                }
                            }
                        }
                    }
                    
                    lineageExtractTempCount = 0;
                    
                    for (int counter3 = 0; counter3 < lineageExtractTempSortCount2; counter3++) lineageExtractTemp [lineageExtractTempCount] = lineageExtractTempSort2 [counter3], lineageExtractTempCount++;
                    
                    delete [] lineageExtractTempSort;
                    delete [] lineageExtractTempSort2;
                    delete [] cellExtractTempSort;
                    delete [] cellExtractTempSort2;
                    
                    //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                    //    cout<<" lineageExtractTemp "<<counterA<<endl;
                    //}
                    
                    int cellNumberGet = 0;
                    int lineageNumberGet = 0;
                    int cellNumberDeleteHoldCount = 0;
                    int progenyCellNo = 0;
                    
                    for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                        if (lineageExtractTemp [counter1*9+5] == 0 && lineageExtractTemp [counter1*9+3] == 1){
                            cellNumberGet = lineageExtractTemp [counter1*9+5];
                            lineageNumberGet = lineageExtractTemp [counter1*9+6];
                            
                            int *cellNumberDeleteHold = new int [totalNumberOfCells+50];
                            cellNumberDeleteHoldCount = 0;
                            
                            cellDoublingInformation [cellDoublingInformationCount] = lineageNumberGet, cellDoublingInformationCount++; //----Ling----
                            cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Cell no----
                            cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Parent----
                            cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Generation----
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+5] == 0 && lineageExtractTemp [counter2*9+3] == 1){
                                    cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+2], cellDoublingInformationCount++; //----Time----
                                    break;
                                }
                            }
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+4] == cellNumberGet && (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount++;
                                    
                                    for (int counter3 = 0; counter3 < cellDoublingInformationCount/5; counter3++){
                                        if (cellDoublingInformation [counter3*5] == lineageNumberGet && cellDoublingInformation [counter3*5+1] == lineageExtractTemp [counter2*9+4]){
                                            cellDoublingInformation [cellDoublingInformationCount] = lineageNumberGet, cellDoublingInformationCount++; //----Ling----
                                            cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+5], cellDoublingInformationCount++; //----Cell no----
                                            cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+4], cellDoublingInformationCount++; //----Parent----
                                            cellDoublingInformation [cellDoublingInformationCount] = cellDoublingInformation [counter3*5+3]+1, cellDoublingInformationCount++; //----Generation----
                                            cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+2], cellDoublingInformationCount++; //----Time----
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            do {
                                
                                terminationFlag = 0;
                                
                                if (cellNumberDeleteHoldCount != 0){
                                    progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                    cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                    
                                    for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                        if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+4] == progenyCellNo && (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount++;
                                            
                                            for (int counter3 = 0; counter3 < cellDoublingInformationCount/5; counter3++){
                                                if (cellDoublingInformation [counter3*5] == lineageNumberGet && cellDoublingInformation [counter3*5+1] == lineageExtractTemp [counter2*9+4]){
                                                    cellDoublingInformation [cellDoublingInformationCount] = lineageNumberGet, cellDoublingInformationCount++; //----Ling----
                                                    cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+5], cellDoublingInformationCount++; //----Cell no----
                                                    cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+4], cellDoublingInformationCount++; //----Parent----
                                                    cellDoublingInformation [cellDoublingInformationCount] = cellDoublingInformation [counter3*5+3]+1, cellDoublingInformationCount++; //----Generation----
                                                    cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+2], cellDoublingInformationCount++; //----Generation----
                                                    
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                }
                                else terminationFlag = 1;
                                
                            } while (terminationFlag == 0);
                            
                            delete [] cellNumberDeleteHold;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < cellDoublingInformationCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<cellDoublingInformation [counterA*5+counterB];
                    //    cout<<" cellDoublingInformation "<<counterA<<endl;
                    //}
                    
                    int numberOfNewLing = 0;
                    
                    for (int counter3 = 0; counter3 < cellDoublingInformationCount/5; counter3++){
                        if (cellDoublingInformation [counter3*5+3] == lineageTimeDivHold){
                            numberOfNewLing++;
                        }
                    }
                    
                    int *startCellNoList = new int [numberOfNewLing*3+10];
                    int startCellNoListCount = 0;
                    
                    for (int counter3 = 0; counter3 < cellDoublingInformationCount/5; counter3++){
                        if (cellDoublingInformation [counter3*5+3] == lineageTimeDivHold){
                            startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*5], startCellNoListCount++;
                            startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*5+1], startCellNoListCount++;
                            startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*5+4], startCellNoListCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < startCellNoListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<startCellNoList [counterA*3+counterB];
                    //    cout<<" startCellNoList "<<counterA<<endl;
                    //}
                    
                    if (numberOfNewLing != 0){
                        //----IF data: Array set----
                        int *ifExtractTemp = new int [arrayIFDataEntryHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*22];
                        int ifExtractTempCount = 0;
                        int ifExtractTempLimit = arrayIFDataEntryHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*22;
                        
                        for (int counter3 = 0; counter3 < arrayIFDataEntryHold [trimOperationTableCurrentRow]/22; counter3++){
                            if (ifExtractTempCount+50 > ifExtractTempLimit){
                                int *arrayUpDate = new int [ifExtractTempCount+10];
                                
                                for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) arrayUpDate [counter4] = ifExtractTemp [counter4];
                                
                                delete [] ifExtractTemp;
                                ifExtractTempLimit = ifExtractTempCount+5000;
                                ifExtractTemp = new int [ifExtractTempLimit];
                                
                                for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) ifExtractTemp [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+1], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+2], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+3], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+4], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+5], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+6], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+7], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+8], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+9], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+10], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+11], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+12], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+13], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+14], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+15], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+16], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+17], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+18], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+19], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+20], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+21], ifExtractTempCount++;
                        }
                        
                        //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                        //    cout<<" ifExtractTemp "<<counterA<<endl;
                        //}
                        
                        int *arrayIFTimeLineDataTemp = new int [arrayIFTimeLineDataEntryHold [trimOperationTableCurrentRow]+50];
                        int arrayIFTimeLineDataTempCount = 0;
                        
                        for (int counter1 = 0; counter1 < arrayIFTimeLineDataEntryHold [trimOperationTableCurrentRow]/9; counter1++){
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+1], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+2], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+3], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+4], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+5], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+6], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+7], arrayIFTimeLineDataTempCount++;
                            arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+8], arrayIFTimeLineDataTempCount++;
                        }
                        
                        //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                        //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                        //}
                        
                        //----AreaData: Array set----
                        int *areaExtractTemp = new int [arrayAreaDataHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*5];
                        int areaExtractTempCount = 0;
                        int areaExtractTempLimit = arrayAreaDataHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*5;
                        
                        for (int counter3 = 0; counter3 < arrayAreaDataHold [trimOperationTableCurrentRow]/5; counter3++){
                            if (areaExtractTempCount+10 > areaExtractTempLimit){
                                int *arrayUpDate = new int [areaExtractTempCount+10];
                                
                                for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) arrayUpDate [counter4] = areaExtractTemp [counter4];
                                
                                delete [] areaExtractTemp;
                                areaExtractTempLimit = areaExtractTempCount+5000;
                                areaExtractTemp = new int [areaExtractTempLimit];
                                
                                for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) areaExtractTemp [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+1], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+2], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+3], areaExtractTempCount++;
                            areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+4], areaExtractTempCount++;
                        }
                        
                        int cellNumberSelect = 0;
                        int lingNoSelect = 0;
                        int maxCategoryLingNo = 0;
                        int lineageExtractTempCount2 = 0;
                        int ifExtractTempCount2 = 0;
                        int areaExtractTempCount2 = 0;
                        int cellNumberSend = 0;
                        int newCellNumber1 = 0;
                        int newCellNumber2 = 0;
                        int newCellNumber3 = 0;
                        int newCellNumber4 = 0;
                        int currentCellNumber1 = 0;
                        int currentCellNumber2 = 0;
                        int currentCellNumber3 = 0;
                        int currentCellNumber4 = 0;
                        int startTime = 0;
                        int arrayIFTimeLineDataTempCount2 = 0;
                        int newIFStart = 0;
                        int timeDICEnd = 0;
                        int noOfLing = 0;
                        int noOfCellStart = 0;
                        int noOfCellEnd = 0;
                        int noOfTotalCells = 0;
                        int noOfDD = 0;
                        int noOfTD = 0;
                        int noOfHD = 0;
                        int noOfMI = 0;
                        int noOfFU = 0;
                        int noOfCD = 0;
                        int maxLineageNo = 0;
                        int lingNoTemp = 0;
                        int matchFind = 0;
                        int freeSpotFind = 0;
                        int previousLengthHold = 0;
                        int readingCount = 0;
                        int lengthExpansionFlag = 0;
                        int entryNo = 0;
                        int expansionNo = 0;
                        int findFlag = 0;
                        int lineageLinkListLengthTemp = 0;
                        int lineageLinkListTempLimit = 0;
                        int numberOfFusionEntry = 0;
                        int smallestEntry2 = 0;
                        int remainingFlag = 0;
                        int smallestEntry = 0;
                        int smallestEntryPosition = 0;
                        int fluorescentDataEntryCount = 0;
                        int ifStatusEntryCount = 0;
                        int readBit [4];
                        int dataTemp = 0;
                        int currentSort [4];
                        int sortTemp [4];
                        int newSort [4];
                        int sortValue = 0;
                        int sortValuePosition = 0;
                        int fusionFind = 0;
                        int warningDisplayOnce = 0;
                        
                        long indexCount = 0;
                        double foldTemp = 0;
                        
                        string savePath;
                        string entry;
                        string imageDisplayPath;
                        string treatNameExtract;
                        
                        ofstream oin;
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        for (int counter1 = 0; counter1 < numberOfNewLing; counter1++){
                            maxCategoryLingNo = 0;
                            
                            imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [trimOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [trimOperationTableCurrentRow][3]+"_IDResults";
                            
                            dir = opendir(imageDisplayPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if ((int)entry.find("AN") != -1){
                                            if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxCategoryLingNo) maxCategoryLingNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            maxCategoryLingNo++;
                            
                            treatNameExtract = arrayTableMain [trimOperationTableCurrentRow][4].substr(arrayTableMain [trimOperationTableCurrentRow][4].find("-")+1, arrayTableMain [trimOperationTableCurrentRow][4].find("_Results")-arrayTableMain [trimOperationTableCurrentRow][4].find("-")-1);
                            
                            imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [trimOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [trimOperationTableCurrentRow][3]+"_IDResults/"+"AN"+to_string(maxCategoryLingNo)+"-"+treatNameExtract+"_Results";
                            
                            mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                            
                            cellNumberSelect = startCellNoList [counter1*3+1];
                            lingNoSelect = startCellNoList [counter1*3];
                            startTime = startCellNoList [counter1*3+2];
                            
                            int *cellNumberDeleteHold = new int [totalNumberOfCells+50];
                            cellNumberDeleteHoldCount = 0;
                            
                            cellNumberDeleteHold2 = new int [totalNumberOfCells*2+50];
                            cellNumberDeleteHoldCount2 = 0;
                            
                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = cellNumberSelect, cellNumberDeleteHoldCount2++;
                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = 0, cellNumberDeleteHoldCount2++;
                            
                            for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                                if (lineageExtractTemp [counter3*9+6] == lingNoSelect && lineageExtractTemp [counter3*9+4] == cellNumberSelect && (lineageExtractTemp [counter3*9+3] == 31 || lineageExtractTemp [counter3*9+3] == 41 || lineageExtractTemp [counter3*9+3] == 51)){
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount++;
                                    
                                    cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount2++;
                                    cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = -1, cellNumberDeleteHoldCount2++;
                                }
                            }
                            
                            do {
                                
                                terminationFlag = 0;
                                
                                if (cellNumberDeleteHoldCount != 0){
                                    progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                    cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                    
                                    for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                                        if (lineageExtractTemp [counter3*9+6] == lingNoSelect && lineageExtractTemp [counter3*9+4] == progenyCellNo && (lineageExtractTemp [counter3*9+3] == 31 || lineageExtractTemp [counter3*9+3] == 41 || lineageExtractTemp [counter3*9+3] == 51)){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount++;
                                            
                                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount2++;
                                            cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = -1, cellNumberDeleteHoldCount2++;
                                        }
                                    }
                                }
                                else terminationFlag = 1;
                                
                            } while (terminationFlag == 0);
                            
                            delete [] cellNumberDeleteHold;
                            
                            //for (int counterA = 0; counterA < cellNumberDeleteHoldCount2/2; counterA++){
                            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<cellNumberDeleteHold2 [counterA*2+counterB];
                            //    cout<<" cellNumberDeleteHold2 "<<counterA<<endl;
                            //}
                            
                            int *lineageExtractTemp2 = new int [lineageExtractTempCount+500];
                            lineageExtractTempCount2 = 0;
                            
                            int *ifExtractTemp2 = new int [ifExtractTempCount+500];
                            ifExtractTempCount2 = 0;
                            
                            int *areaExtractTemp2 = new int [areaExtractTempCount+500];
                            areaExtractTempCount2 = 0;
                            
                            for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (lingNoSelect == lineageExtractTemp [counter2*9+6] && cellNumberDeleteHold2 [counter3*2] == lineageExtractTemp [counter2*9+5]){
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+1], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+2], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+3], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+4], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+5], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+6], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+7], lineageExtractTempCount2++;
                                        lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+8], lineageExtractTempCount2++;
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                            //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (lingNoSelect == ifExtractTemp [counter2*22+1] && cellNumberDeleteHold2 [counter3*2] == ifExtractTemp [counter2*22]){
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+1], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+2], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+3], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+4], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+5], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+6], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+7], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+8], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+9], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+10], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+11], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+12], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+13], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+14], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+15], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+16], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+17], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+18], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+19], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+20], ifExtractTempCount2++;
                                        ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+21], ifExtractTempCount2++;
                                        
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < ifExtractTempCount2/13; counterA++){
                            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp2 [counterA*13+counterB];
                            //    cout<<" ifExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < areaExtractTempCount/5; counter2++){
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (lingNoSelect == areaExtractTemp [counter2*5] && cellNumberDeleteHold2 [counter3*2] == areaExtractTemp [counter2*5+1]){
                                        areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5], areaExtractTempCount2++;
                                        areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+1], areaExtractTempCount2++;
                                        areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+2], areaExtractTempCount2++;
                                        areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+3], areaExtractTempCount2++;
                                        areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+4], areaExtractTempCount2++;
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < areaExtractTempCount2/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp2 [counterA*5+counterB];
                            //    cout<<" areaExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                if (cellNumberDeleteHold2 [counter3*2] == cellNumberSelect){
                                    cellNumberDeleteHold2 [counter3*2+1] = 0;
                                    break;
                                }
                            }
                            
                            cellNumberDeleteHold = new int [totalNumberOfCells+50];
                            cellNumberDeleteHoldCount = 0;
                            
                            currentCellNumber1 = 0;
                            currentCellNumber2 = 0;
                            currentCellNumber3 = 0;
                            currentCellNumber4 = 0;
                            
                            for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                if (lineageExtractTemp2 [counter3*9+4] == cellNumberSelect && (lineageExtractTemp2 [counter3*9+3] == 31 || lineageExtractTemp2 [counter3*9+3] == 41 || lineageExtractTemp2 [counter3*9+3] == 51)){
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp2 [counter3*9+5], cellNumberDeleteHoldCount++;
                                    
                                    if (currentCellNumber1 == 0) currentCellNumber1 = lineageExtractTemp2 [counter3*9+5];
                                    else if (currentCellNumber2 == 0) currentCellNumber2 = lineageExtractTemp2 [counter3*9+5];
                                    else if (currentCellNumber3 == 0) currentCellNumber3 = lineageExtractTemp2 [counter3*9+5];
                                    else if (currentCellNumber4 == 0) currentCellNumber4 = lineageExtractTemp2 [counter3*9+5];
                                }
                            }
                            
                            if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 == 0 && currentCellNumber4 == 0){
                                cellNumberProcessHold = 0;
                                
                                sortTemp [0] = currentCellNumber1;
                                sortTemp [1] = currentCellNumber2;
                                
                                if (sortTemp [0] < sortTemp [1]){
                                    currentSort [0] = sortTemp [1];
                                    currentSort [1] = sortTemp [0];
                                }
                                else{
                                    
                                    currentSort [0] = sortTemp [0];
                                    currentSort [1] = sortTemp [1];
                                }
                                
                                newCellNumber1 = [self primaryAddition];
                                newCellNumber2 = [self primarySubtract];
                                
                                sortTemp [0] = newCellNumber1;
                                sortTemp [1] = newCellNumber2;
                                
                                if (sortTemp [0] < sortTemp [1]){
                                    newSort [0] = sortTemp [1];
                                    newSort [1] = sortTemp [0];
                                }
                                else{
                                    
                                    newSort [0] = sortTemp [0];
                                    newSort [1] = sortTemp [1];
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                        break;
                                    }
                                }
                            }
                            
                            if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 == 0){
                                cellNumberProcessHold = 0;
                                
                                sortTemp [0] = currentCellNumber1;
                                sortTemp [1] = currentCellNumber2;
                                sortTemp [2] = currentCellNumber3;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 3; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 3; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    currentSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                newCellNumber1 = [self primaryAddition];
                                newCellNumber2 = [self primarySubtract];
                                newCellNumber3 = [self secondaryAddition];
                                
                                sortTemp [0] = newCellNumber1;
                                sortTemp [1] = newCellNumber2;
                                sortTemp [2] = newCellNumber3;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 3; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 3; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    newSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                        break;
                                    }
                                }
                            }
                            
                            if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 != 0){
                                cellNumberProcessHold = 0;
                                
                                sortTemp [0] = currentCellNumber1;
                                sortTemp [1] = currentCellNumber2;
                                sortTemp [2] = currentCellNumber3;
                                sortTemp [3] = currentCellNumber4;
                                
                                //cout<<sortTemp [0] <<" "<<sortTemp [1]<<" "<<sortTemp [2] <<" "<<sortTemp [3] <<" numberA"<<endl;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 4; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 4; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    currentSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                newCellNumber1 = [self primaryAddition];
                                newCellNumber2 = [self primarySubtract];
                                newCellNumber3 = [self secondaryAddition];
                                newCellNumber4 = [self secondarySubtract];
                                
                                sortTemp [0] = newCellNumber1;
                                sortTemp [1] = newCellNumber2;
                                sortTemp [2] = newCellNumber3;
                                sortTemp [3] = newCellNumber4;
                                
                                sortValuePosition = 0;
                                
                                for (int counter2 = 0; counter2 < 4; counter2++){
                                    sortValue = -999999999;
                                    
                                    for (int counter3 = 0; counter3 < 4; counter3++){
                                        if (sortValue < sortTemp [counter3]){
                                            sortValue = sortTemp [counter3];
                                            sortValuePosition = counter3;
                                        }
                                    }
                                    
                                    newSort [counter2] = sortValue;
                                    sortTemp [sortValuePosition] = -999999999;
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                        break;
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == currentSort [3]){
                                        cellNumberDeleteHold2 [counter3*2+1] = newSort [3];
                                        break;
                                    }
                                }
                            }
                            
                            do {
                                
                                terminationFlag = 0;
                                
                                if (cellNumberDeleteHoldCount != 0){
                                    progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                    cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                    cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                    
                                    currentCellNumber1 = 0;
                                    currentCellNumber2 = 0;
                                    currentCellNumber3 = 0;
                                    currentCellNumber4 = 0;
                                    
                                    for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                        if (lineageExtractTemp2 [counter3*9+4] == progenyCellNo && (lineageExtractTemp2 [counter3*9+3] == 31 || lineageExtractTemp2 [counter3*9+3] == 41 || lineageExtractTemp2 [counter3*9+3] == 51)){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp2 [counter3*9+5], cellNumberDeleteHoldCount++;
                                            
                                            if (currentCellNumber1 == 0) currentCellNumber1 = lineageExtractTemp2 [counter3*9+5];
                                            else if (currentCellNumber2 == 0) currentCellNumber2 = lineageExtractTemp2 [counter3*9+5];
                                            else if (currentCellNumber3 == 0) currentCellNumber3 = lineageExtractTemp2 [counter3*9+5];
                                            else if (currentCellNumber4 == 0) currentCellNumber4 = lineageExtractTemp2 [counter3*9+5];
                                        }
                                    }
                                    
                                    cellNumberSend = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (progenyCellNo == cellNumberDeleteHold2 [counter3*2]){
                                            cellNumberSend = cellNumberDeleteHold2 [counter3*2+1];
                                            break;
                                        }
                                    }
                                    
                                    if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 == 0 && currentCellNumber4 == 0){
                                        cellNumberProcessHold = cellNumberSend;
                                        
                                        sortTemp [0] = currentCellNumber1;
                                        sortTemp [1] = currentCellNumber2;
                                        
                                        if (sortTemp [0] < sortTemp [1]){
                                            currentSort [0] = sortTemp [1];
                                            currentSort [1] = sortTemp [0];
                                        }
                                        else{
                                            
                                            currentSort [0] = sortTemp [0];
                                            currentSort [1] = sortTemp [1];
                                        }
                                        
                                        newCellNumber1 = [self primaryAddition];
                                        newCellNumber2 = [self primarySubtract];
                                        
                                        sortTemp [0] = newCellNumber1;
                                        sortTemp [1] = newCellNumber2;
                                        
                                        if (sortTemp [0] < sortTemp [1]){
                                            newSort [0] = sortTemp [1];
                                            newSort [1] = sortTemp [0];
                                        }
                                        else{
                                            
                                            newSort [0] = sortTemp [0];
                                            newSort [1] = sortTemp [1];
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 == 0){
                                        cellNumberProcessHold = cellNumberSend;
                                        
                                        sortTemp [0] = currentCellNumber1;
                                        sortTemp [1] = currentCellNumber2;
                                        sortTemp [2] = currentCellNumber3;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 3; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 3; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            currentSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        newCellNumber1 = [self primaryAddition];
                                        newCellNumber2 = [self primarySubtract];
                                        newCellNumber3 = [self secondaryAddition];
                                        
                                        sortTemp [0] = newCellNumber1;
                                        sortTemp [1] = newCellNumber2;
                                        sortTemp [2] = newCellNumber3;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 3; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 3; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            newSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 != 0){
                                        cellNumberProcessHold = cellNumberSend;
                                        
                                        sortTemp [0] = currentCellNumber1;
                                        sortTemp [1] = currentCellNumber2;
                                        sortTemp [2] = currentCellNumber3;
                                        sortTemp [3] = currentCellNumber4;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 4; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 4; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            currentSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        newCellNumber1 = [self primaryAddition];
                                        newCellNumber2 = [self primarySubtract];
                                        newCellNumber3 = [self secondaryAddition];
                                        newCellNumber4 = [self secondarySubtract];
                                        
                                        sortTemp [0] = newCellNumber1;
                                        sortTemp [1] = newCellNumber2;
                                        sortTemp [2] = newCellNumber3;
                                        sortTemp [3] = newCellNumber4;
                                        
                                        sortValuePosition = 0;
                                        
                                        for (int counter2 = 0; counter2 < 4; counter2++){
                                            sortValue = -999999999;
                                            
                                            for (int counter3 = 0; counter3 < 4; counter3++){
                                                if (sortValue < sortTemp [counter3]){
                                                    sortValue = sortTemp [counter3];
                                                    sortValuePosition = counter3;
                                                }
                                            }
                                            
                                            newSort [counter2] = sortValue;
                                            sortTemp [sortValuePosition] = -999999999;
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                                break;
                                            }
                                        }
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (cellNumberDeleteHold2 [counter3*2] == currentSort [3]){
                                                cellNumberDeleteHold2 [counter3*2+1] = newSort [3];
                                                break;
                                            }
                                        }
                                    }
                                }
                                else terminationFlag = 1;
                                
                            } while (terminationFlag == 0);
                            
                            delete [] cellNumberDeleteHold;
                            
                            //for (int counterA = 0; counterA < cellNumberDeleteHoldCount2/2; counterA++){
                            //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<cellNumberDeleteHold2 [counterA*2+counterB];
                            //    cout<<" cellNumberDeleteHold2 "<<counterA<<endl;
                            //}
                            
                            for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                    if (lineageExtractTemp2 [counter3*9+5] == cellNumberDeleteHold2 [counter4*2]){
                                        lineageExtractTemp2 [counter3*9+5] = cellNumberDeleteHold2 [counter4*2+1];
                                        break;
                                    }
                                }
                                
                                for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                    if (lineageExtractTemp2 [counter3*9+4] == cellNumberDeleteHold2 [counter4*2]){
                                        if (lineageExtractTemp2 [counter3*9+3] != 91 && lineageExtractTemp2 [counter3*9+3] != 92){
                                            lineageExtractTemp2 [counter3*9+4] = cellNumberDeleteHold2 [counter4*2+1];
                                            break;
                                        }
                                    }
                                }
                                
                                fusionFind = 0;
                                
                                if (lineageExtractTemp2 [counter3*9+3] == 91 || lineageExtractTemp2 [counter3*9+3] == 92){
                                    for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                        if (lineageExtractTemp2 [counter3*9+4] == cellNumberDeleteHold2 [counter4*2]){
                                            lineageExtractTemp2 [counter3*9+4] = cellNumberDeleteHold2 [counter4*2+1];
                                            lineageExtractTemp2 [counter3*9+7] = 1;
                                            fusionFind = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (fusionFind == 0){
                                        lineageExtractTemp2 [counter3*9+4] = 0;
                                        lineageExtractTemp2 [counter3*9+7] = 0;
                                    }
                                }
                                
                                lineageExtractTemp2 [counter3*9+2] = lineageExtractTemp2 [counter3*9+2]-startTime+1;
                                lineageExtractTemp2 [counter3*9+6] = 1;
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractTempCount3/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp3 [counterA*9+counterB];
                            //    cout<<" lineageExtractTemp3 "<<counterA<<endl;
                            //}
                            
                            for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                if (lineageExtractTemp2 [counter3*9+2] == 1 && lineageExtractTemp2 [counter3*9+5] == 0){
                                    lineageExtractTemp2 [counter3*9+3] = 1;
                                    lineageExtractTemp2 [counter3*9+4] = 0;
                                    lineageExtractTemp2 [counter3*9+7] = 0;
                                    break;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                            //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            for (int counter3 = 0; counter3 < ifExtractTempCount2/22; counter3++){
                                for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                    if (ifExtractTemp2 [counter3*22] == cellNumberDeleteHold2 [counter4*2]){
                                        ifExtractTemp2 [counter3*22] = cellNumberDeleteHold2 [counter4*2+1];
                                        ifExtractTemp2 [counter3*22+1] = 1;
                                        ifExtractTemp2 [counter3*22+2] = ifExtractTemp2 [counter3*22+2]-startTime+1;
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < ifExtractTempCount2/13; counterA++){
                            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp2 [counterA*13+counterB];
                            //    cout<<" ifExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            for (int counter3 = 0; counter3 < areaExtractTempCount2/5; counter3++){
                                for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                    if (areaExtractTemp2 [counter3*5+1] == cellNumberDeleteHold2 [counter4*2]){
                                        areaExtractTemp2 [counter3*5] = 1;
                                        areaExtractTemp2 [counter3*5+1] = cellNumberDeleteHold2 [counter4*2+1];
                                        areaExtractTemp2 [counter3*5+4] = areaExtractTemp2 [counter3*5+4]-startTime+1;
                                        break;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < areaExtractTempCount2/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp2 [counterA*5+counterB];
                            //    cout<<" areaExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                            //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                            //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                            //}
                            
                            int *arrayIFTimeLineDataTemp2 = new int [arrayIFTimeLineDataTempCount+50];
                            arrayIFTimeLineDataTempCount2 = 0;
                            
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                            
                            newIFStart = 0;
                            
                            for (int counter2 = 0; counter2 < arrayIFTimeLineDataTempCount/9; counter2++){
                                if (counter2 >= startTime){
                                    if (arrayIFTimeLineDataTemp [counter2*9] != 0){
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9]-startTime+1, arrayIFTimeLineDataTempCount2++;
                                    }
                                    else arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9], arrayIFTimeLineDataTempCount2++;
                                    
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+1], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+2], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+3], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+4], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+5], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+6], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+7], arrayIFTimeLineDataTempCount2++;
                                    arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+8], arrayIFTimeLineDataTempCount2++;
                                    
                                    if (arrayIFTimeLineDataTemp [counter2*9]-startTime+1 != 0 && arrayIFTimeLineDataTemp [counter2*9+1] > 0 && newIFStart == 0){
                                        newIFStart = arrayIFTimeLineDataTemp [counter2*9]-startTime+1;
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount2/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp2 [counterA*6+counterB];
                            //    cout<<" arrayIFTimeLineDataTemp2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                            //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                            //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                            //    cout<<" ifExtractTemp "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                            //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                            //    cout<<" areaExtractTemp "<<counterA<<endl;
                            //}
                            
                            if (newIFStart == 0) timeDICEnd = arrayTableDetail [trimOperationTableCurrentRow][3]-startTime+1;
                            else timeDICEnd = newIFStart-1;
                            
                            //----Detail table data: Array set----
                            int *arrayTableDetailTemp = new int [20];
                            
                            noOfLing = 0;
                            noOfCellStart = 0;
                            noOfCellEnd = 0;
                            noOfTotalCells = 0;
                            noOfDD = 0;
                            noOfTD = 0;
                            noOfHD = 0;
                            noOfMI = 0;
                            noOfFU = 0;
                            noOfCD = 0;
                            
                            maxLineageNo = 0;
                            
                            for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                if (lineageExtractTemp2 [counter3*9+2] == 1 && (lineageExtractTemp2 [counter3*9+5] == 0 || lineageExtractTemp2 [counter3*9+5] == -1)){
                                    noOfLing++;
                                }
                                
                                if (maxLineageNo < lineageExtractTemp2 [counter3*9+6]) maxLineageNo = lineageExtractTemp2 [counter3*9+6]; //==
                                
                                if (lineageExtractTemp2 [counter3*9+2] == 1 && lineageExtractTemp2 [counter3*9+5] == 0){
                                    noOfCellStart++;
                                }
                                
                                if ((lineageExtractTemp2 [counter3*9+3] == 1 || lineageExtractTemp2 [counter3*9+3] == 31 || lineageExtractTemp2 [counter3*9+3] == 41 || lineageExtractTemp2 [counter3*9+3] == 51)){
                                    noOfTotalCells++;
                                }
                                
                                if (lineageExtractTemp2 [counter3*9+2] == timeDICEnd) noOfCellEnd++;
                                if (lineageExtractTemp2 [counter3*9+3] == 32) noOfDD++;
                                if (lineageExtractTemp2 [counter3*9+3] == 42) noOfTD++;
                                if (lineageExtractTemp2 [counter3*9+3] == 52) noOfHD++;
                                if (lineageExtractTemp2 [counter3*9+3] == 6) noOfMI++;
                                if (lineageExtractTemp2 [counter3*9+3] == 91) noOfFU++;
                                if (lineageExtractTemp2 [counter3*9+3] == 7) noOfCD++;
                            }
                            
                            arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                            arrayTableDetailTemp [1] = noOfLing;
                            arrayTableDetailTemp [2] = 1;
                            arrayTableDetailTemp [3] = timeDICEnd;
                            
                            if (newIFStart != 0){
                                arrayTableDetailTemp [4] = newIFStart;
                                arrayTableDetailTemp [5] = arrayTableDetail [trimOperationTableCurrentRow][5]-startTime+1;
                            }
                            else{
                                
                                arrayTableDetailTemp [4] = 0;
                                arrayTableDetailTemp [5] = 0;
                            }
                            
                            arrayTableDetailTemp [6] = noOfCellStart;
                            arrayTableDetailTemp [7] = noOfCellEnd;
                            
                            if (noOfCellStart != 0){
                                foldTemp = noOfCellEnd/(double)noOfCellStart;
                                foldTemp = foldTemp*10+1;
                            }
                            else foldTemp = 1;
                            
                            arrayTableDetailTemp [8] = (int)foldTemp;
                            arrayTableDetailTemp [9] = noOfTotalCells;
                            arrayTableDetailTemp [10] = noOfDD;
                            arrayTableDetailTemp [11] = noOfTD;
                            arrayTableDetailTemp [12] = noOfHD;
                            arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                            arrayTableDetailTemp [14] = noOfMI;
                            arrayTableDetailTemp [15] = noOfFU;
                            arrayTableDetailTemp [16] = noOfCD;
                            
                            //for (int counterA = 0; counterA < 1; counterA++){
                            //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                            //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                            //}
                            
                            delete [] cellNumberDeleteHold2;
                            
                            //----Link Data----
                            
                            lineageLinkListLengthTemp = 4;
                            int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                            lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                            
                            for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter2++) arrayLineageLinkTemp [counter2] = 0;
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                if (lineageExtractTemp2 [counter2*9+3] == 31 || lineageExtractTemp2 [counter2*9+3] == 41 || lineageExtractTemp2 [counter2*9+3] == 51 || lineageExtractTemp2 [counter2*9+3] == 1){
                                    lingNoTemp = lineageExtractTemp2 [counter2*9+6];
                                    arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                }
                            }
                            
                            for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                lingNoTemp = lineageExtractTemp2 [counter2*9+6];
                                
                                if (lineageExtractTemp2 [counter2*9+7] != 0 && lineageExtractTemp2 [counter2*9+7] != lingNoTemp){
                                    matchFind = 0;
                                    freeSpotFind = 0;
                                    
                                    for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                        if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter3] == lineageExtractTemp2 [counter2*9+7]){
                                            matchFind = 1;
                                        }
                                        
                                        if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter3] == 0 && freeSpotFind == 0){
                                            freeSpotFind = counter3;
                                        }
                                    }
                                    
                                    if (matchFind == 0){
                                        if (freeSpotFind == 0){
                                            previousLengthHold = lineageLinkListLengthTemp;
                                            int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                            
                                            for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++) arrayUpDate [counter3] = arrayLineageLinkTemp [counter3];
                                            
                                            delete [] arrayLineageLinkTemp;
                                            lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                            arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                            lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                            
                                            readingCount = 0;
                                            
                                            for (int counter3 = 0; counter3 <= maxLineageNo; counter3++){
                                                for (int counter4 = 0; counter4 < previousLengthHold; counter4++){
                                                    arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] = arrayUpDate [readingCount], readingCount++;
                                                }
                                                
                                                arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                                arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                            }
                                            
                                            delete [] arrayUpDate;
                                            
                                            freeSpotFind = previousLengthHold;
                                        }
                                        
                                        arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                        arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = lineageExtractTemp2 [counter2*9+7];
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                            //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                            //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                            //}
                            
                            for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+1] != 0){
                                    freeSpotFind = -1;
                                    
                                    for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                        if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] == 0){
                                            freeSpotFind = counter3;
                                            break;
                                        }
                                    }
                                    
                                    if (freeSpotFind == -1) freeSpotFind = 4;
                                    
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                            if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                lengthExpansionFlag = 0;
                                                
                                                for (int counter4 = 1; counter4 <= maxLineageNo; counter4++){
                                                    if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3]){
                                                        entryNo = 0;
                                                        
                                                        for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                            findFlag = 0;
                                                            
                                                            for (int counter6 = 1; counter6 < lineageLinkListLengthTemp; counter6++){
                                                                if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0 && (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter6] || arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == counter2)){
                                                                    findFlag = 1;
                                                                }
                                                                else if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0) findFlag = 1;
                                                            }
                                                            
                                                            if (findFlag == 0) entryNo++;
                                                        }
                                                        
                                                        if (entryNo != 0){
                                                            if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                                previousLengthHold = lineageLinkListLengthTemp;
                                                                int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                                
                                                                for (int counter5 = 0; counter5 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter5++) arrayUpDate [counter5] = arrayLineageLinkTemp [counter5];
                                                                
                                                                if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                                else expansionNo = freeSpotFind+entryNo;
                                                                
                                                                delete [] arrayLineageLinkTemp;
                                                                lineageLinkListLengthTemp = expansionNo+2;
                                                                arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                                
                                                                expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                                
                                                                readingCount = 0;
                                                                
                                                                for (int counter5 = 0; counter5 <= maxLineageNo; counter5++){
                                                                    for (int counter6 = 0; counter6 < previousLengthHold; counter6++){
                                                                        arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+counter6] = arrayUpDate [readingCount], readingCount++;
                                                                    }
                                                                    
                                                                    for (int counter6 = 0; counter6 < expansionNo; counter6++){
                                                                        arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+previousLengthHold+counter6] = 0;
                                                                    }
                                                                }
                                                                
                                                                delete [] arrayUpDate;
                                                                
                                                                lengthExpansionFlag = 1;
                                                                
                                                                break;
                                                            }
                                                            else{
                                                                
                                                                for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                                    findFlag = 0;
                                                                    
                                                                    for (int counter6 = 1; counter6 < lineageLinkListLengthTemp; counter6++){
                                                                        if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0 && (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter6] || arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == counter2)){
                                                                            findFlag = 1;
                                                                        }
                                                                        else if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0) findFlag = 1;
                                                                    }
                                                                    
                                                                    if (findFlag != 1){
                                                                        arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5];
                                                                        
                                                                        freeSpotFind++;
                                                                    }
                                                                }
                                                                
                                                                arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] = -1;
                                                                break;
                                                            }
                                                        }
                                                        else arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] = -1;
                                                    }
                                                }
                                                
                                                if (lengthExpansionFlag == 1){
                                                    break;
                                                }
                                            }
                                            
                                            if (counter3 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                                        }
                                        
                                    } while (terminationFlag == 1);
                                }
                            }
                            
                            //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                            //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                            //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                            //}
                            
                            int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                            int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                            
                            for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+1] != 0){
                                    numberOfFusionEntry = 0;
                                    
                                    for (int counter3 = 0; counter3 < lineageLinkListLengthTemp; counter3++){
                                        if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                            numberOfFusionEntry++;
                                        }
                                    }
                                    
                                    if (numberOfFusionEntry > 1){
                                        for (int counter3 = 0; counter3 < lineageLinkListLengthTemp; counter3++){
                                            if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                numberOfEntryList [counter3] = arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3];
                                            }
                                            else numberOfEntryList [counter3] = 0;
                                            
                                            numberOfEntryList2 [counter3] = 0;
                                        }
                                        
                                        smallestEntry2 = 1;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            remainingFlag = 0;
                                            smallestEntry = 100000;
                                            smallestEntryPosition = 0;
                                            
                                            for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                if (numberOfEntryList [counter3] != 0 && numberOfEntryList [counter3] < smallestEntry){
                                                    smallestEntry = numberOfEntryList [counter3];
                                                    smallestEntryPosition = counter3;
                                                    remainingFlag = 1;
                                                }
                                            }
                                            
                                            if (remainingFlag == 0) terminationFlag = 0;
                                            else{
                                                
                                                numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                                numberOfEntryList [smallestEntryPosition] = 0;
                                            }
                                            
                                        } while (terminationFlag == 1);
                                        
                                        for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                            arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] = numberOfEntryList2 [counter3];
                                        }
                                    }
                                }
                            }
                            
                            delete [] numberOfEntryList;
                            delete [] numberOfEntryList2;
                            
                            //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                            //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                            //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                            //}
                            
                            //----Lineage Data type: Array Set----
                            for (int counter3 = 0; counter3 < 7; counter3++){
                                arrayLineageDataType [lineageDataEntryCount][counter3] = arrayLineageDataType [trimOperationTableCurrentRow][counter3];
                            }
                            
                            arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                            arrayLineageDataType [lineageDataEntryCount][1] = "AN"+to_string(maxCategoryLingNo);
                            
                            //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                            //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" arrayLineageDataType "<<endl;
                            //}
                            
                            //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                            //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                            //}
                            
                            //----LineageFluorescentDataType: Array Set----
                            fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                            
                            for (int counter3 = 0; counter3 < fluorescentDataEntryCount; counter3++){
                                if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                
                                if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == trimOperationTableCurrentRow+1){
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter3][1];
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter3][2];
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter3][3];
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter3][4];
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter3][5];
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter3][6];
                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter3][7];
                                    
                                    lineageFluorescentDataTypeEntryCount++;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                            //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                            //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                            //}
                            
                            //----Data save----
                            savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                            
                            oin.open(savePath.c_str(), ios::out);
                            oin<<to_string(lineageDataEntryCount+1)<<endl;
                            oin<<"AN"+to_string(maxCategoryLingNo)<<endl;
                            oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                            oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                            oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                            oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                            oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                            
                            for (int counter3 = 0; counter3 < lineageFluorescentDataTypeEntryCount; counter3++){
                                if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == lineageDataEntryCount+1){
                                    oin<<arrayLineageFluorescentDataType [counter3][0]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][1]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][2]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][3]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][4]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][5]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][6]<<endl;
                                    oin<<arrayLineageFluorescentDataType [counter3][7]<<endl;
                                }
                            }
                            
                            oin.close();
                            
                            if (lineageDataEntryCount < 101){
                                delete [] arrayLineageData [lineageDataEntryCount];
                                delete [] arrayIFData [lineageDataEntryCount];
                                delete [] arrayIFTimeLineData [lineageDataEntryCount];
                                delete [] arrayTableMain [lineageDataEntryCount];
                                delete [] arrayIfTimeStatus [lineageDataEntryCount];
                                delete [] arrayAreaData [lineageDataEntryCount];
                                delete [] arrayLineageLink [lineageDataEntryCount];
                                
                                arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                                arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                                arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataTempCount+10];
                                arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [trimOperationTableCurrentRow]+10];
                                arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [trimOperationTableCurrentRow]+10];
                                arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                                arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                                
                                lineageDataEntryCount++;
                            }
                            else if (warningDisplayOnce == 0){
                                NSAlert *alert = [[NSAlert alloc] init];
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Entry Limit Exceeded: 100"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                                
                                warningDisplayOnce = 1;
                            }
                            
                            if (lineageDataEntryCount-1 < 101){
                                for (int counter3 = 0; counter3 < lineageExtractTempCount2; counter3++) arrayLineageData [lineageDataEntryCount-1][counter3] = lineageExtractTemp2 [counter3];
                                
                                arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)lineageExtractTempCount2;
                                
                                //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                                //    cout<<" arrayLineageData "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount2; counter3++) arrayIFData [lineageDataEntryCount-1][counter3] = ifExtractTemp2 [counter3];
                                
                                arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount2;
                                
                                //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                                //    cout<<" arrayIFData "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < arrayIFTimeLineDataTempCount2; counter3++){
                                    arrayIFTimeLineData [lineageDataEntryCount-1][counter3] = arrayIFTimeLineDataTemp2 [counter3];
                                }
                                
                                arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataTempCount2;
                                
                                for (int counter3 = 0; counter3 < arrayTableMainHold [trimOperationTableCurrentRow]; counter3++) arrayTableMain [lineageDataEntryCount-1][counter3] = arrayTableMain [trimOperationTableCurrentRow][counter3];
                                
                                arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                arrayTableMain [lineageDataEntryCount-1][1] = "AN";
                                arrayTableMain [lineageDataEntryCount-1][4] = "AN"+to_string(maxCategoryLingNo)+"-"+treatNameExtract;
                                
                                arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [trimOperationTableCurrentRow];
                                
                                for (int counter3 = 0; counter3 < 17; counter3++) arrayTableDetail [lineageDataEntryCount-1][counter3] = arrayTableDetailTemp [counter3];
                                
                                ifStatusEntryCount = 0;
                                
                                if (arrayTableDetailTemp [4] != 0){
                                    for (int counter2 = arrayTableDetailTemp [4]; counter2 <= arrayTableDetailTemp [5]; counter2++){
                                        arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = counter2, ifStatusEntryCount++;
                                        arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = 0, ifStatusEntryCount++;
                                    }
                                }
                                
                                arrayIfTimeStatusHold [lineageDataEntryCount-1] = ifStatusEntryCount;
                                
                                for (int counter3 = 0; counter3 < areaExtractTempCount2; counter3++) arrayAreaData [lineageDataEntryCount-1][counter3] = areaExtractTemp2 [counter3];
                                
                                arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount2;
                                
                                //**********arrayLinkData**********
                                for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++){
                                    arrayLineageLink [lineageDataEntryCount-1][counter3] = arrayLineageLinkTemp [counter3];
                                }
                                
                                arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                                
                                lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                                
                                savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                                
                                char *writingArray = new char [lineageExtractTempCount2/9*28+100];
                                
                                indexCount = 0;
                                
                                for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                    if (lineageExtractTemp2 [counter3*9] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9];
                                    }
                                    
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    if (lineageExtractTemp2 [counter3*9+1] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9+1]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9+1];
                                    }
                                    
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp2 [counter3*9+2];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)lineageExtractTemp2 [counter3*9+3], indexCount++;
                                    
                                    if (lineageExtractTemp2 [counter3*9+4] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9+4]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9+4];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    if (lineageExtractTemp2 [counter3*9+5] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9+5]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp2 [counter3*9+5];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp2 [counter3*9+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp2 [counter3*9+7];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp2 [counter3*9+8];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 28; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile (savePath.c_str(), ofstream::binary);
                                outfile.write ((char*) writingArray, indexCount);
                                outfile.close();
                                
                                delete [] writingArray;
                                
                                savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<lineageExtractTempCount2<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"IFData";
                                
                                writingArray = new char [ifExtractTempCount2/22*60+60];
                                
                                indexCount = 0;
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount2/22; counter3++){
                                    if (ifExtractTemp2 [counter3*22] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = ifExtractTemp2 [counter3*22]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = ifExtractTemp2 [counter3*22];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+1];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+2];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+3], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+4], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+5];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+7], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+8];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+9];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+10], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+11];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+12];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+13], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+14];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+15];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+16], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+17];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+18];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+19], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+20];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp2 [counter3*22+21];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 33; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile2 (savePath.c_str(), ofstream::binary);
                                outfile2.write ((char*) writingArray, indexCount);
                                outfile2.close();
                                
                                delete [] writingArray;
                                
                                savePath = imageDisplayPath+"/"+"IFDataEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<ifExtractTempCount2<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"IFTimeLine";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"MainTable";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayTableMainHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayTableMain [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"MainTableEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"DetailTable";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < 17; counter3++){
                                    oin<<arrayTableDetail [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/IFDataStatus";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayIfTimeStatusHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayIfTimeStatus [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/IFDataStatusEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayIfTimeStatusHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"AreaData";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayAreaDataHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayAreaData [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/AreaDataEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"LinkData";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < lineageLinkHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayLineageLink [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/LinkDataEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                                oin.close();
                            }
                            
                            delete [] lineageExtractTemp2;
                            delete [] ifExtractTemp2;
                            delete [] areaExtractTemp2;
                            delete [] arrayIFTimeLineDataTemp2;
                            delete [] arrayLineageLinkTemp;
                            delete [] arrayTableDetailTemp;
                        }
                        
                        upLoadingFlag = 1;
                        
                        if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                        if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                        if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                        if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                        if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                        if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                        if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
                        
                        delete [] ifExtractTemp;
                        delete [] areaExtractTemp;
                        delete [] arrayIFTimeLineDataTemp;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Indicated Division Found"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                    
                    delete [] cellDoublingInformation;
                    delete [] lineageExtractTemp;
                    delete [] startCellNoList;
                }
                else if (lineageCutStatusHold == 2){
                    int valueRangeA1 = [rangeValueADisplay1 intValue];
                    int valueRangeA2 = [rangeValueADisplay2 intValue];
                    int valueRangeB1 = [rangeValueBDisplay1 intValue];
                    int valueRangeB2 = [rangeValueBDisplay2 intValue];
                    int valueRangeACH = [rangeValueCHDisplayA intValue];
                    int valueRangeBCH = [rangeValueCHDisplayB intValue];
                    
                    if (valueRangeA1 <= valueRangeA2 && valueRangeB1 <= valueRangeB2 && (valueRangeB1 > valueRangeA2 || valueRangeA1 > valueRangeB2) && valueRangeACH != 0){
                        if (valueRangeB1 < 0 && valueRangeB2 < 0 && valueRangeBCH == 0){
                            valueRangeB1 = -1;
                            valueRangeB2 = -1;
                            
                            [rangeValueBDisplay1 setStringValue:@""];
                            [rangeValueBDisplay2 setStringValue:@""];
                            [rangeValueCHDisplayB setStringValue:@""];
                        }
                        
                        int totalNumberOfCells = arrayTableDetail [trimOperationTableCurrentRow][9];
                        
                        int *cellDoublingInformation = new int [totalNumberOfCells*6+50];
                        int cellDoublingInformationCount = 0;
                        
                        for (int counter3 = 0; counter3 < totalNumberOfCells*6+50; counter3++) cellDoublingInformation [counter3] = -1;
                        
                        int *lineageExtractTemp = new int [arrayLineageDataEntryHold [trimOperationTableCurrentRow]+500];
                        unsigned long lineageExtractTempCount = 0;
                        unsigned long lineageExtractTempLimit = arrayLineageDataEntryHold [trimOperationTableCurrentRow]+500;
                        
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [trimOperationTableCurrentRow]/9; counter3++){
                            if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                                int *arrayUpDate = new int [lineageExtractTempCount+10];
                                
                                for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) arrayUpDate [counter4] = lineageExtractTemp [counter4];
                                
                                delete [] lineageExtractTemp;
                                lineageExtractTempLimit = lineageExtractTempCount+5000;
                                lineageExtractTemp = new int [lineageExtractTempLimit];
                                
                                for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) lineageExtractTemp [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+1], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+2], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+3], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+4], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+5], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+6], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+7], lineageExtractTempCount++;
                            lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [trimOperationTableCurrentRow][counter3*9+8], lineageExtractTempCount++;
                        }
                        
                        //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                        //    cout<<" lineageExtractTemp "<<counterA<<endl;
                        //}
                        
                        //----Data sort----
                        int *lineageExtractTempSort = new int [lineageExtractTempCount+100];
                        int lineageExtractTempSortCount = 0;
                        int *lineageExtractTempSort2 = new int [lineageExtractTempCount+100];
                        int lineageExtractTempSortCount2 = 0;
                        
                        int *cellExtractTempSort = new int [totalNumberOfCells+100];
                        int cellExtractTempSortCount = 0;
                        int *cellExtractTempSort2 = new int [totalNumberOfCells+100];
                        int cellExtractTempSortCount2 = 0;
                        
                        int maxLineageSort = 0; //==
                        int maxCellSort = 0; //==
                        int sortFind = 0;
                        int sortFindPosition = 0;
                        int terminationFlag = 0;
                        
                        for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                            if (lineageExtractTemp [counter3*9+6] > maxLineageSort) maxLineageSort = lineageExtractTemp [counter3*9+6];
                        }
                        
                        for (int counter3 = 1; counter3 <= maxLineageSort; counter3++){
                            lineageExtractTempSortCount = 0;
                            
                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount/9; counter4++){
                                if (lineageExtractTemp [counter4*9+6] == counter3){
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+1], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+2], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+3], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+4], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+5], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+6], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+7], lineageExtractTempSortCount++;
                                    lineageExtractTempSort [lineageExtractTempSortCount] = lineageExtractTemp [counter4*9+8], lineageExtractTempSortCount++;
                                }
                            }
                            
                            cellExtractTempSortCount = 0;
                            
                            for (int counter4 = 0; counter4 < lineageExtractTempSortCount/9; counter4++){
                                sortFind = 0;
                                
                                for (int counter5 = 0; counter5 < cellExtractTempSortCount; counter5++){
                                    if (cellExtractTempSort [counter5] == lineageExtractTempSort [counter4*9+5]){
                                        sortFind = 1;
                                        break;
                                    }
                                }
                                
                                if (sortFind == 0){
                                    cellExtractTempSort [cellExtractTempSortCount] = lineageExtractTempSort [counter4*9+5], cellExtractTempSortCount++;
                                }
                            }
                            
                            cellExtractTempSortCount2 = 0;
                            
                            do{
                                
                                terminationFlag = 1;
                                maxCellSort = -999999999;
                                sortFindPosition = 0;
                                
                                for (int counter5 = 0; counter5 < cellExtractTempSortCount; counter5++){
                                    if (cellExtractTempSort [counter5] > maxCellSort){
                                        maxCellSort = cellExtractTempSort [counter5];
                                        sortFindPosition = counter5;
                                    }
                                }
                                
                                if (maxCellSort != -999999999){
                                    cellExtractTempSort2 [cellExtractTempSortCount2] = maxCellSort, cellExtractTempSortCount2++;
                                    cellExtractTempSort [sortFindPosition] = -999999999;
                                }
                                else terminationFlag = 0;
                                
                            } while (terminationFlag == 1);
                            
                            for (int counter4 = 0; counter4 < cellExtractTempSortCount2; counter4++){
                                for (int counter5 = 0; counter5 < lineageExtractTempSortCount/9; counter5++){
                                    if (cellExtractTempSort2 [counter4] == lineageExtractTempSort [counter5*9+5]){
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+1], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+2], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+3], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+4], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+5], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+6], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+7], lineageExtractTempSortCount2++;
                                        lineageExtractTempSort2 [lineageExtractTempSortCount2] = lineageExtractTempSort [counter5*9+8], lineageExtractTempSortCount2++;
                                    }
                                }
                            }
                        }
                        
                        lineageExtractTempCount = 0;
                        
                        for (int counter3 = 0; counter3 < lineageExtractTempSortCount2; counter3++) lineageExtractTemp [lineageExtractTempCount] = lineageExtractTempSort2 [counter3], lineageExtractTempCount++;
                        
                        delete [] lineageExtractTempSort;
                        delete [] lineageExtractTempSort2;
                        delete [] cellExtractTempSort;
                        delete [] cellExtractTempSort2;
                        
                        int cellNumberGet = 0;
                        int lineageNumberGet = 0;
                        int cellNumberDeleteHoldCount = 0;
                        int progenyCellNo = 0;
                        
                        for (unsigned long counter1 = 0; counter1 < lineageExtractTempCount/9; counter1++){
                            if (lineageExtractTemp [counter1*9+5] == 0 && lineageExtractTemp [counter1*9+3] == 1){
                                cellNumberGet = lineageExtractTemp [counter1*9+5];
                                lineageNumberGet = lineageExtractTemp [counter1*9+6];
                                
                                int *cellNumberDeleteHold = new int [totalNumberOfCells+50];
                                cellNumberDeleteHoldCount = 0;
                                
                                cellDoublingInformation [cellDoublingInformationCount] = lineageNumberGet, cellDoublingInformationCount++; //----Ling----
                                cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Cell no----
                                cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Parent----
                                cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Generation----
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                    if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+5] == 0 && lineageExtractTemp [counter2*9+3] == 1){
                                        cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+2], cellDoublingInformationCount++; //----Time----
                                        break;
                                    }
                                }
                                
                                cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Fluorescent----
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                    if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+4] == cellNumberGet && (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount++;
                                        
                                        for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                                            if (cellDoublingInformation [counter3*6] == lineageNumberGet && cellDoublingInformation [counter3*6+1] == lineageExtractTemp [counter2*9+4]){
                                                cellDoublingInformation [cellDoublingInformationCount] = lineageNumberGet, cellDoublingInformationCount++; //----Ling----
                                                cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+5], cellDoublingInformationCount++; //----Cell no----
                                                cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+4], cellDoublingInformationCount++; //----Parent----
                                                cellDoublingInformation [cellDoublingInformationCount] = cellDoublingInformation [counter3*6+3]+1, cellDoublingInformationCount++; //----Generation----
                                                cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+2], cellDoublingInformationCount++; //----Time----
                                                cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----Fluorescent----
                                                
                                                break;
                                            }
                                        }
                                    }
                                }
                                
                                do {
                                    
                                    terminationFlag = 0;
                                    
                                    if (cellNumberDeleteHoldCount != 0){
                                        progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                        cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                        
                                        for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                            if (lineageExtractTemp [counter2*9+6] == lineageNumberGet && lineageExtractTemp [counter2*9+4] == progenyCellNo && (lineageExtractTemp [counter2*9+3] == 31 || lineageExtractTemp [counter2*9+3] == 41 || lineageExtractTemp [counter2*9+3] == 51)){
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter2*9+5], cellNumberDeleteHoldCount++;
                                                
                                                for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                                                    if (cellDoublingInformation [counter3*6] == lineageNumberGet && cellDoublingInformation [counter3*6+1] == lineageExtractTemp [counter2*9+4]){
                                                        cellDoublingInformation [cellDoublingInformationCount] = lineageNumberGet, cellDoublingInformationCount++; //----Ling----
                                                        cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+5], cellDoublingInformationCount++; //----Cell no----
                                                        cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+4], cellDoublingInformationCount++; //----Parent----
                                                        cellDoublingInformation [cellDoublingInformationCount] = cellDoublingInformation [counter3*6+3]+1, cellDoublingInformationCount++; //----Generation----
                                                        cellDoublingInformation [cellDoublingInformationCount] = lineageExtractTemp [counter2*9+2], cellDoublingInformationCount++; //----Generation----
                                                        cellDoublingInformation [cellDoublingInformationCount] = 0, cellDoublingInformationCount++; //----
                                                        
                                                        break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else terminationFlag = 1;
                                    
                                } while (terminationFlag == 0);
                                
                                delete [] cellNumberDeleteHold;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < cellDoublingInformationCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<cellDoublingInformation [counterA*6+counterB];
                        //    cout<<" cellDoublingInformation "<<counterA<<endl;
                        //}
                        
                        //----IF data: Array set----
                        int *ifExtractTemp = new int [arrayIFDataEntryHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*22];
                        int ifExtractTempCount = 0;
                        int ifExtractTempLimit = arrayIFDataEntryHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*22;
                        
                        for (int counter3 = 0; counter3 < arrayIFDataEntryHold [trimOperationTableCurrentRow]/22; counter3++){
                            if (ifExtractTempCount+50 > ifExtractTempLimit){
                                int *arrayUpDate = new int [ifExtractTempCount+10];
                                
                                for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) arrayUpDate [counter4] = ifExtractTemp [counter4];
                                
                                delete [] ifExtractTemp;
                                ifExtractTempLimit = ifExtractTempCount+5000;
                                ifExtractTemp = new int [ifExtractTempLimit];
                                
                                for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) ifExtractTemp [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+1], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+2], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+3], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+4], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+5], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+6], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+7], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+8], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+9], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+10], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+11], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+12], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+13], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+14], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+15], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+16], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+17], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+18], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+19], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+20], ifExtractTempCount++;
                            ifExtractTemp [ifExtractTempCount] = arrayIFData [trimOperationTableCurrentRow][counter3*22+21], ifExtractTempCount++;
                        }
                        
                        //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                        //    cout<<" ifExtractTemp "<<counterA<<endl;
                        //}
                        
                        for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                            if (ifExtractTemp [counter2*22+2] == lineageTimeDivHold){
                                for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                                    if (progenitorIncludeHold == 0 || progenitorIncludeHold == 2){
                                        if (ifExtractTemp [counter2*22] == cellDoublingInformation [counter3*6+1] && ifExtractTemp [counter2*22+1] == cellDoublingInformation [counter3*6]){
                                            if (valueRangeACH == 1){
                                                if (ifExtractTemp [counter2*22+5] >= valueRangeA1 && ifExtractTemp [counter2*22+5] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+5] >= valueRangeB1 && ifExtractTemp [counter2*22+5] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH == 2){
                                                if (ifExtractTemp [counter2*22+8] >= valueRangeA1 && ifExtractTemp [counter2*22+8] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+8] >= valueRangeB1 && ifExtractTemp [counter2*22+8] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH == 3){
                                                if (ifExtractTemp [counter2*22+11] >= valueRangeA1 && ifExtractTemp [counter2*22+11] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+11] >= valueRangeB1 && ifExtractTemp [counter2*22+11] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH == 4){
                                                if (ifExtractTemp [counter2*22+14] >= valueRangeA1 && ifExtractTemp [counter2*22+14] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+14] >= valueRangeB1 && ifExtractTemp [counter2*22+14] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH == 5){
                                                if (ifExtractTemp [counter2*22+17] >= valueRangeA1 && ifExtractTemp [counter2*22+17] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+17] >= valueRangeB1 && ifExtractTemp [counter2*22+17] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH == 6){
                                                if (ifExtractTemp [counter2*22+20] >= valueRangeA1 && ifExtractTemp [counter2*22+20] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+20] >= valueRangeB1 && ifExtractTemp [counter2*22+20] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                        }
                                    }
                                    else if (progenitorIncludeHold == 1 || progenitorIncludeHold == 3){
                                        if (ifExtractTemp [counter2*22] == cellDoublingInformation [counter3*6+1] && ifExtractTemp [counter2*22+1] == cellDoublingInformation [counter3*6]){
                                            if (valueRangeACH+6 == 7){
                                                if (ifExtractTemp [counter2*22+5] >= valueRangeA1 && ifExtractTemp [counter2*22+5] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+5] >= valueRangeB1 && ifExtractTemp [counter2*22+5] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH+6 == 8){
                                                if (ifExtractTemp [counter2*22+8] >= valueRangeA1 && ifExtractTemp [counter2*22+8] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+8] >= valueRangeB1 && ifExtractTemp [counter2*22+8] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH+6 == 9){
                                                if (ifExtractTemp [counter2*22+11] >= valueRangeA1 && ifExtractTemp [counter2*22+11] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+11] >= valueRangeB1 && ifExtractTemp [counter2*22+11] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH+6 == 10){
                                                if (ifExtractTemp [counter2*22+14] >= valueRangeA1 && ifExtractTemp [counter2*22+14] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+14] >= valueRangeB1 && ifExtractTemp [counter2*22+14] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH+6 == 11){
                                                if (ifExtractTemp [counter2*22+17] >= valueRangeA1 && ifExtractTemp [counter2*22+17] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+17] >= valueRangeB1 && ifExtractTemp [counter2*22+17] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                            else if (valueRangeACH+6 == 12){
                                                if (ifExtractTemp [counter2*22+20] >= valueRangeA1 && ifExtractTemp [counter2*22+20] <= valueRangeA2){
                                                    cellDoublingInformation [counter3*6+5] = 1;
                                                }
                                                if (ifExtractTemp [counter2*22+20] >= valueRangeB1 && ifExtractTemp [counter2*22+20] <= valueRangeB2){
                                                    cellDoublingInformation [counter3*6+5] = 2;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < cellDoublingInformationCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<cellDoublingInformation [counterA*6+counterB];
                        //    cout<<" cellDoublingInformation "<<counterA<<endl;
                        //}
                        
                        int maxGenerationNo = 0;
                        
                        for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                            if (cellDoublingInformation [counter3*6+3] > maxGenerationNo){
                                maxGenerationNo = cellDoublingInformation [counter3*6+3];
                            }
                        }
                        
                        for (int counter3 = maxGenerationNo; counter3 > 0; counter3--){
                            for (int counter4 = 0; counter4 < cellDoublingInformationCount/6; counter4++){
                                if (cellDoublingInformation [counter4*6+3] == counter3 && (cellDoublingInformation [counter4*6+5] == 1 || cellDoublingInformation [counter4*6+5] == 2 || cellDoublingInformation [counter4*6+5] == -1 || cellDoublingInformation [counter4*6+5] == 30)){
                                    for (int counter5 = 0; counter5 < cellDoublingInformationCount/6; counter5++){
                                        if (cellDoublingInformation [counter4*6] == cellDoublingInformation [counter5*6] && cellDoublingInformation [counter4*6+2] == cellDoublingInformation [counter5*6+1]){
                                            if (cellDoublingInformation [counter4*6+5] == 1){
                                                if (cellDoublingInformation [counter5*6+5] == 0){
                                                    cellDoublingInformation [counter5*6+5] = 1;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 1){
                                                    cellDoublingInformation [counter5*6+5] = 1;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 2){
                                                    if (progenitorIncludeHold == 2 || progenitorIncludeHold == 3){
                                                        cellDoublingInformation [counter5*6+5] = 30;
                                                    }
                                                    else cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                            }
                                            else if (cellDoublingInformation [counter4*6+5] == 2){
                                                if (cellDoublingInformation [counter5*6+5] == 0){
                                                    cellDoublingInformation [counter5*6+5] = 2;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 2){
                                                    cellDoublingInformation [counter5*6+5] = 2;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 1){
                                                    if (progenitorIncludeHold == 2 || progenitorIncludeHold == 3){
                                                        cellDoublingInformation [counter5*6+5] = 30;
                                                    }
                                                    else cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                            }
                                            else if (cellDoublingInformation [counter4*6+5] == 30){
                                                if (cellDoublingInformation [counter5*6+5] == 1){
                                                    cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 2){
                                                    cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 0){
                                                    cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                            }
                                            else if (cellDoublingInformation [counter4*6+5] == -1){
                                                if (cellDoublingInformation [counter5*6+5] == 0){
                                                    cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 1){
                                                    cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                                else if (cellDoublingInformation [counter5*6+5] == 2){
                                                    cellDoublingInformation [counter5*6+5] = -1;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < cellDoublingInformationCount/6; counterA++){
                                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<cellDoublingInformation [counterA*6+counterB];
                                            //    cout<<" cellDoublingInformation "<<counterA<<endl;
                                            //}
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        for (int counter3 = maxGenerationNo; counter3 > 0; counter3--){
                            for (int counter4 = 0; counter4 < cellDoublingInformationCount/6; counter4++){
                                if (cellDoublingInformation [counter4*6+3] == counter3 && (cellDoublingInformation [counter4*6+5] == 1 || cellDoublingInformation [counter4*6+5] == 2)){
                                    for (int counter5 = 0; counter5 < cellDoublingInformationCount/6; counter5++){
                                        if (cellDoublingInformation [counter4*6] == cellDoublingInformation [counter5*6] && cellDoublingInformation [counter4*6+2] == cellDoublingInformation [counter5*6+1]){
                                            if (cellDoublingInformation [counter5*6+5] == -1){
                                                if (cellDoublingInformation [counter4*6+5] == 1) cellDoublingInformation [counter4*6+5] = 10;
                                                else if (cellDoublingInformation [counter4*6+5] == 2) cellDoublingInformation [counter4*6+5] = 20;
                                                break;
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < cellDoublingInformationCount/6; counterA++){
                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<cellDoublingInformation [counterA*6+counterB];
                        //    cout<<" cellDoublingInformation "<<counterA<<endl;
                        //}
                        
                        int numberOfNewLing = 0;
                        
                        for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                            if (cellDoublingInformation [counter3*6+5] == 10 || cellDoublingInformation [counter3*6+5] == 20 || cellDoublingInformation [counter3*6+5] == 30 || (cellDoublingInformation [counter3*6+1] == 0 && (cellDoublingInformation [counter3*6+5] == 1 || cellDoublingInformation [counter3*6+5] == 2))){
                                numberOfNewLing++;
                            }
                        }
                        
                        int *startCellNoList = new int [numberOfNewLing*3+10];
                        int startCellNoListCount = 0;
                        
                        if (progenitorIncludeHold == 0 || progenitorIncludeHold == 1){
                            for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                                if (cellDoublingInformation [counter3*6+5] == 10 || cellDoublingInformation [counter3*6+5] == 20 || (cellDoublingInformation [counter3*6+1] == 0 && (cellDoublingInformation [counter3*6+5] == 1 || cellDoublingInformation [counter3*6+5] == 2))){
                                    startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*6], startCellNoListCount++;
                                    startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*6+1], startCellNoListCount++;
                                    startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*6+4], startCellNoListCount++;
                                }
                            }
                        }
                        else{
                            
                            for (int counter3 = 0; counter3 < cellDoublingInformationCount/6; counter3++){
                                if (cellDoublingInformation [counter3*6+5] == 30){
                                    startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*6], startCellNoListCount++;
                                    startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*6+1], startCellNoListCount++;
                                    startCellNoList [startCellNoListCount] = cellDoublingInformation [counter3*6+4], startCellNoListCount++;
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < startCellNoListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<startCellNoList [counterA*3+counterB];
                        //    cout<<" startCellNoList "<<counterA<<endl;
                        //}
                        
                        if (startCellNoListCount/3 != 0){
                            int *arrayIFTimeLineDataTemp = new int [arrayIFTimeLineDataEntryHold [trimOperationTableCurrentRow]+50];
                            int arrayIFTimeLineDataTempCount = 0;
                            
                            for (int counter1 = 0; counter1 < arrayIFTimeLineDataEntryHold [trimOperationTableCurrentRow]/9; counter1++){
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+1], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+2], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+3], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+4], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+5], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+6], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+7], arrayIFTimeLineDataTempCount++;
                                arrayIFTimeLineDataTemp [arrayIFTimeLineDataTempCount] = arrayIFTimeLineData [trimOperationTableCurrentRow][counter1*9+8], arrayIFTimeLineDataTempCount++;
                            }
                            
                            //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                            //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                            //}
                            
                            //----AreaData: Array set----
                            int *areaExtractTemp = new int [arrayAreaDataHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*5];
                            int areaExtractTempCount = 0;
                            int areaExtractTempLimit = arrayAreaDataHold [trimOperationTableCurrentRow]+500+totalNumberOfCells*2*5;
                            
                            for (int counter3 = 0; counter3 < arrayAreaDataHold [trimOperationTableCurrentRow]/5; counter3++){
                                if (areaExtractTempCount+10 > areaExtractTempLimit){
                                    int *arrayUpDate = new int [areaExtractTempCount+10];
                                    
                                    for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) arrayUpDate [counter4] = areaExtractTemp [counter4];
                                    
                                    delete [] areaExtractTemp;
                                    areaExtractTempLimit = areaExtractTempCount+5000;
                                    areaExtractTemp = new int [areaExtractTempLimit];
                                    
                                    for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) areaExtractTemp [counter4] = arrayUpDate [counter4];
                                    delete [] arrayUpDate;
                                }
                                
                                areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5], areaExtractTempCount++;
                                areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+1], areaExtractTempCount++;
                                areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+2], areaExtractTempCount++;
                                areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+3], areaExtractTempCount++;
                                areaExtractTemp [areaExtractTempCount] = arrayAreaData [trimOperationTableCurrentRow][counter3*5+4], areaExtractTempCount++;
                            }
                            
                            int cellNumberSelect = 0;
                            int lingNoSelect = 0;
                            int maxCategoryLingNo = 0;
                            int lineageExtractTempCount2 = 0;
                            int ifExtractTempCount2 = 0;
                            int areaExtractTempCount2 = 0;
                            int cellNumberSend = 0;
                            int newCellNumber1 = 0;
                            int newCellNumber2 = 0;
                            int newCellNumber3 = 0;
                            int newCellNumber4 = 0;
                            int currentCellNumber1 = 0;
                            int currentCellNumber2 = 0;
                            int currentCellNumber3 = 0;
                            int currentCellNumber4 = 0;
                            int startTime = 0;
                            int arrayIFTimeLineDataTempCount2 = 0;
                            int newIFStart = 0;
                            int timeDICEnd = 0;
                            int noOfLing = 0;
                            int noOfCellStart = 0;
                            int noOfCellEnd = 0;
                            int noOfTotalCells = 0;
                            int noOfDD = 0;
                            int noOfTD = 0;
                            int noOfHD = 0;
                            int noOfMI = 0;
                            int noOfFU = 0;
                            int noOfCD = 0;
                            int maxLineageNo = 0;
                            int lingNoTemp = 0;
                            int matchFind = 0;
                            int freeSpotFind = 0;
                            int previousLengthHold = 0;
                            int readingCount = 0;
                            int lengthExpansionFlag = 0;
                            int entryNo = 0;
                            int expansionNo = 0;
                            int findFlag = 0;
                            int lineageLinkListLengthTemp = 0;
                            int lineageLinkListTempLimit = 0;
                            int numberOfFusionEntry = 0;
                            int smallestEntry2 = 0;
                            int remainingFlag = 0;
                            int smallestEntry = 0;
                            int smallestEntryPosition = 0;
                            int fluorescentDataEntryCount = 0;
                            int ifStatusEntryCount = 0;
                            int readBit [4];
                            int dataTemp = 0;
                            int currentSort [4];
                            int sortTemp [4];
                            int newSort [4];
                            int sortValue = 0;
                            int sortValuePosition = 0;
                            int fusionFind = 0;
                            int warningDisplayOnce = 0;
                            
                            long indexCount = 0;
                            double foldTemp = 0;
                            
                            string savePath;
                            string entry;
                            string imageDisplayPath;
                            string treatNameExtract;
                            
                            ofstream oin;
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            for (int counter1 = 0; counter1 < startCellNoListCount/3; counter1++){
                                maxCategoryLingNo = 0;
                                
                                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [trimOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [trimOperationTableCurrentRow][3]+"_IDResults";
                                
                                dir = opendir(imageDisplayPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            if ((int)entry.find("AN") != -1){
                                                if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxCategoryLingNo) maxCategoryLingNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                maxCategoryLingNo++;
                                
                                treatNameExtract = arrayTableMain [trimOperationTableCurrentRow][4].substr(arrayTableMain [trimOperationTableCurrentRow][4].find("-")+1, arrayTableMain [trimOperationTableCurrentRow][4].find("_Results")-arrayTableMain [trimOperationTableCurrentRow][4].find("-")-1);
                                
                                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [trimOperationTableCurrentRow][2]+"_AnalysisResults"+"/"+arrayTableMain [trimOperationTableCurrentRow][3]+"_IDResults/"+"AN"+to_string(maxCategoryLingNo)+"-"+treatNameExtract+"_Results";
                                
                                mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                cellNumberSelect = startCellNoList [counter1*3+1];
                                lingNoSelect = startCellNoList [counter1*3];
                                startTime = startCellNoList [counter1*3+2];
                                
                                int *cellNumberDeleteHold = new int [totalNumberOfCells+50];
                                cellNumberDeleteHoldCount = 0;
                                
                                cellNumberDeleteHold2 = new int [totalNumberOfCells*2+50];
                                cellNumberDeleteHoldCount2 = 0;
                                
                                cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = cellNumberSelect, cellNumberDeleteHoldCount2++;
                                cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = 0, cellNumberDeleteHoldCount2++;
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                                    if (lineageExtractTemp [counter3*9+6] == lingNoSelect && lineageExtractTemp [counter3*9+4] == cellNumberSelect && (lineageExtractTemp [counter3*9+3] == 31 || lineageExtractTemp [counter3*9+3] == 41 || lineageExtractTemp [counter3*9+3] == 51)){
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount++;
                                        
                                        cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount2++;
                                        cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = -1, cellNumberDeleteHoldCount2++;
                                    }
                                }
                                
                                do {
                                    
                                    terminationFlag = 0;
                                    
                                    if (cellNumberDeleteHoldCount != 0){
                                        progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                        cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                        
                                        for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                                            if (lineageExtractTemp [counter3*9+6] == lingNoSelect && lineageExtractTemp [counter3*9+4] == progenyCellNo && (lineageExtractTemp [counter3*9+3] == 31 || lineageExtractTemp [counter3*9+3] == 41 || lineageExtractTemp [counter3*9+3] == 51)){
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount++;
                                                
                                                cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = lineageExtractTemp [counter3*9+5], cellNumberDeleteHoldCount2++;
                                                cellNumberDeleteHold2 [cellNumberDeleteHoldCount2] = -1, cellNumberDeleteHoldCount2++;
                                            }
                                        }
                                    }
                                    else terminationFlag = 1;
                                    
                                } while (terminationFlag == 0);
                                
                                delete [] cellNumberDeleteHold;
                                
                                //for (int counterA = 0; counterA < cellNumberDeleteHoldCount2/2; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<cellNumberDeleteHold2 [counterA*2+counterB];
                                //    cout<<" cellNumberDeleteHold2 "<<counterA<<endl;
                                //}
                                
                                int *lineageExtractTemp2 = new int [lineageExtractTempCount+500];
                                lineageExtractTempCount2 = 0;
                                
                                int *ifExtractTemp2 = new int [ifExtractTempCount+500];
                                ifExtractTempCount2 = 0;
                                
                                int *areaExtractTemp2 = new int [areaExtractTempCount+500];
                                areaExtractTempCount2 = 0;
                                
                                for (unsigned long counter2 = 0; counter2 < lineageExtractTempCount/9; counter2++){
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (lingNoSelect == lineageExtractTemp [counter2*9+6] && cellNumberDeleteHold2 [counter3*2] == lineageExtractTemp [counter2*9+5]){
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+1], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+2], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+3], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+4], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+5], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+6], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+7], lineageExtractTempCount2++;
                                            lineageExtractTemp2 [lineageExtractTempCount2] = lineageExtractTemp [counter2*9+8], lineageExtractTempCount2++;
                                            break;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                                //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < ifExtractTempCount/22; counter2++){
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (lingNoSelect == ifExtractTemp [counter2*22+1] && cellNumberDeleteHold2 [counter3*2] == ifExtractTemp [counter2*22]){
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+1], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+2], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+3], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+4], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+5], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+6], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+7], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+8], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+9], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+10], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+11], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+12], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+13], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+14], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+15], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+16], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+17], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+18], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+19], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+20], ifExtractTempCount2++;
                                            ifExtractTemp2 [ifExtractTempCount2] = ifExtractTemp [counter2*22+21], ifExtractTempCount2++;
                                            
                                            break;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < ifExtractTempCount2/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp2 [counterA*13+counterB];
                                //    cout<<" ifExtractTemp2 "<<counterA<<endl;
                                //}
                                
                                for (int counter2 = 0; counter2 < areaExtractTempCount/5; counter2++){
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (lingNoSelect == areaExtractTemp [counter2*5] && cellNumberDeleteHold2 [counter3*2] == areaExtractTemp [counter2*5+1]){
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+1], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+2], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+3], areaExtractTempCount2++;
                                            areaExtractTemp2 [areaExtractTempCount2] = areaExtractTemp [counter2*5+4], areaExtractTempCount2++;
                                            break;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < areaExtractTempCount2/5; counterA++){
                                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp2 [counterA*5+counterB];
                                //    cout<<" areaExtractTemp2 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                    if (cellNumberDeleteHold2 [counter3*2] == cellNumberSelect){
                                        cellNumberDeleteHold2 [counter3*2+1] = 0;
                                        break;
                                    }
                                }
                                
                                cellNumberDeleteHold = new int [totalNumberOfCells+50];
                                cellNumberDeleteHoldCount = 0;
                                
                                currentCellNumber1 = 0;
                                currentCellNumber2 = 0;
                                currentCellNumber3 = 0;
                                currentCellNumber4 = 0;
                                
                                for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                    if (lineageExtractTemp2 [counter3*9+4] == cellNumberSelect && (lineageExtractTemp2 [counter3*9+3] == 31 || lineageExtractTemp2 [counter3*9+3] == 41 || lineageExtractTemp2 [counter3*9+3] == 51)){
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp2 [counter3*9+5], cellNumberDeleteHoldCount++;
                                        
                                        if (currentCellNumber1 == 0) currentCellNumber1 = lineageExtractTemp2 [counter3*9+5];
                                        else if (currentCellNumber2 == 0) currentCellNumber2 = lineageExtractTemp2 [counter3*9+5];
                                        else if (currentCellNumber3 == 0) currentCellNumber3 = lineageExtractTemp2 [counter3*9+5];
                                        else if (currentCellNumber4 == 0) currentCellNumber4 = lineageExtractTemp2 [counter3*9+5];
                                    }
                                }
                                
                                if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 == 0 && currentCellNumber4 == 0){
                                    cellNumberProcessHold = 0;
                                    
                                    sortTemp [0] = currentCellNumber1;
                                    sortTemp [1] = currentCellNumber2;
                                    
                                    if (sortTemp [0] < sortTemp [1]){
                                        currentSort [0] = sortTemp [1];
                                        currentSort [1] = sortTemp [0];
                                    }
                                    else{
                                        
                                        currentSort [0] = sortTemp [0];
                                        currentSort [1] = sortTemp [1];
                                    }
                                    
                                    newCellNumber1 = [self primaryAddition];
                                    newCellNumber2 = [self primarySubtract];
                                    
                                    sortTemp [0] = newCellNumber1;
                                    sortTemp [1] = newCellNumber2;
                                    
                                    if (sortTemp [0] < sortTemp [1]){
                                        newSort [0] = sortTemp [1];
                                        newSort [1] = sortTemp [0];
                                    }
                                    else{
                                        
                                        newSort [0] = sortTemp [0];
                                        newSort [1] = sortTemp [1];
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                            break;
                                        }
                                    }
                                }
                                
                                if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 == 0){
                                    cellNumberProcessHold = 0;
                                    
                                    sortTemp [0] = currentCellNumber1;
                                    sortTemp [1] = currentCellNumber2;
                                    sortTemp [2] = currentCellNumber3;
                                    
                                    sortValuePosition = 0;
                                    
                                    for (int counter2 = 0; counter2 < 3; counter2++){
                                        sortValue = -999999999;
                                        
                                        for (int counter3 = 0; counter3 < 3; counter3++){
                                            if (sortValue < sortTemp [counter3]){
                                                sortValue = sortTemp [counter3];
                                                sortValuePosition = counter3;
                                            }
                                        }
                                        
                                        currentSort [counter2] = sortValue;
                                        sortTemp [sortValuePosition] = -999999999;
                                    }
                                    
                                    newCellNumber1 = [self primaryAddition];
                                    newCellNumber2 = [self primarySubtract];
                                    newCellNumber3 = [self secondaryAddition];
                                    
                                    sortTemp [0] = newCellNumber1;
                                    sortTemp [1] = newCellNumber2;
                                    sortTemp [2] = newCellNumber3;
                                    
                                    sortValuePosition = 0;
                                    
                                    for (int counter2 = 0; counter2 < 3; counter2++){
                                        sortValue = -999999999;
                                        
                                        for (int counter3 = 0; counter3 < 3; counter3++){
                                            if (sortValue < sortTemp [counter3]){
                                                sortValue = sortTemp [counter3];
                                                sortValuePosition = counter3;
                                            }
                                        }
                                        
                                        newSort [counter2] = sortValue;
                                        sortTemp [sortValuePosition] = -999999999;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                            break;
                                        }
                                    }
                                }
                                
                                if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 != 0){
                                    cellNumberProcessHold = 0;
                                    
                                    sortTemp [0] = currentCellNumber1;
                                    sortTemp [1] = currentCellNumber2;
                                    sortTemp [2] = currentCellNumber3;
                                    sortTemp [3] = currentCellNumber4;
                                    
                                    //cout<<sortTemp [0] <<" "<<sortTemp [1]<<" "<<sortTemp [2] <<" "<<sortTemp [3] <<" numberA"<<endl;
                                    
                                    sortValuePosition = 0;
                                    
                                    for (int counter2 = 0; counter2 < 4; counter2++){
                                        sortValue = -999999999;
                                        
                                        for (int counter3 = 0; counter3 < 4; counter3++){
                                            if (sortValue < sortTemp [counter3]){
                                                sortValue = sortTemp [counter3];
                                                sortValuePosition = counter3;
                                            }
                                        }
                                        
                                        currentSort [counter2] = sortValue;
                                        sortTemp [sortValuePosition] = -999999999;
                                    }
                                    
                                    newCellNumber1 = [self primaryAddition];
                                    newCellNumber2 = [self primarySubtract];
                                    newCellNumber3 = [self secondaryAddition];
                                    newCellNumber4 = [self secondarySubtract];
                                    
                                    sortTemp [0] = newCellNumber1;
                                    sortTemp [1] = newCellNumber2;
                                    sortTemp [2] = newCellNumber3;
                                    sortTemp [3] = newCellNumber4;
                                    
                                    sortValuePosition = 0;
                                    
                                    for (int counter2 = 0; counter2 < 4; counter2++){
                                        sortValue = -999999999;
                                        
                                        for (int counter3 = 0; counter3 < 4; counter3++){
                                            if (sortValue < sortTemp [counter3]){
                                                sortValue = sortTemp [counter3];
                                                sortValuePosition = counter3;
                                            }
                                        }
                                        
                                        newSort [counter2] = sortValue;
                                        sortTemp [sortValuePosition] = -999999999;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                        if (cellNumberDeleteHold2 [counter3*2] == currentSort [3]){
                                            cellNumberDeleteHold2 [counter3*2+1] = newSort [3];
                                            break;
                                        }
                                    }
                                }
                                
                                do {
                                    
                                    terminationFlag = 0;
                                    
                                    if (cellNumberDeleteHoldCount != 0){
                                        progenyCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                        cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-1;
                                        
                                        currentCellNumber1 = 0;
                                        currentCellNumber2 = 0;
                                        currentCellNumber3 = 0;
                                        currentCellNumber4 = 0;
                                        
                                        for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                            if (lineageExtractTemp2 [counter3*9+4] == progenyCellNo && (lineageExtractTemp2 [counter3*9+3] == 31 || lineageExtractTemp2 [counter3*9+3] == 41 || lineageExtractTemp2 [counter3*9+3] == 51)){
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = lineageExtractTemp2 [counter3*9+5], cellNumberDeleteHoldCount++;
                                                
                                                if (currentCellNumber1 == 0) currentCellNumber1 = lineageExtractTemp2 [counter3*9+5];
                                                else if (currentCellNumber2 == 0) currentCellNumber2 = lineageExtractTemp2 [counter3*9+5];
                                                else if (currentCellNumber3 == 0) currentCellNumber3 = lineageExtractTemp2 [counter3*9+5];
                                                else if (currentCellNumber4 == 0) currentCellNumber4 = lineageExtractTemp2 [counter3*9+5];
                                            }
                                        }
                                        
                                        cellNumberSend = 0;
                                        
                                        for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                            if (progenyCellNo == cellNumberDeleteHold2 [counter3*2]){
                                                cellNumberSend = cellNumberDeleteHold2 [counter3*2+1];
                                                break;
                                            }
                                        }
                                        
                                        if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 == 0 && currentCellNumber4 == 0){
                                            cellNumberProcessHold = cellNumberSend;
                                            
                                            sortTemp [0] = currentCellNumber1;
                                            sortTemp [1] = currentCellNumber2;
                                            
                                            if (sortTemp [0] < sortTemp [1]){
                                                currentSort [0] = sortTemp [1];
                                                currentSort [1] = sortTemp [0];
                                            }
                                            else{
                                                
                                                currentSort [0] = sortTemp [0];
                                                currentSort [1] = sortTemp [1];
                                            }
                                            
                                            newCellNumber1 = [self primaryAddition];
                                            newCellNumber2 = [self primarySubtract];
                                            
                                            sortTemp [0] = newCellNumber1;
                                            sortTemp [1] = newCellNumber2;
                                            
                                            if (sortTemp [0] < sortTemp [1]){
                                                newSort [0] = sortTemp [1];
                                                newSort [1] = sortTemp [0];
                                            }
                                            else{
                                                
                                                newSort [0] = sortTemp [0];
                                                newSort [1] = sortTemp [1];
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                    break;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 == 0){
                                            cellNumberProcessHold = cellNumberSend;
                                            
                                            sortTemp [0] = currentCellNumber1;
                                            sortTemp [1] = currentCellNumber2;
                                            sortTemp [2] = currentCellNumber3;
                                            
                                            sortValuePosition = 0;
                                            
                                            for (int counter2 = 0; counter2 < 3; counter2++){
                                                sortValue = -999999999;
                                                
                                                for (int counter3 = 0; counter3 < 3; counter3++){
                                                    if (sortValue < sortTemp [counter3]){
                                                        sortValue = sortTemp [counter3];
                                                        sortValuePosition = counter3;
                                                    }
                                                }
                                                
                                                currentSort [counter2] = sortValue;
                                                sortTemp [sortValuePosition] = -999999999;
                                            }
                                            
                                            newCellNumber1 = [self primaryAddition];
                                            newCellNumber2 = [self primarySubtract];
                                            newCellNumber3 = [self secondaryAddition];
                                            
                                            sortTemp [0] = newCellNumber1;
                                            sortTemp [1] = newCellNumber2;
                                            sortTemp [2] = newCellNumber3;
                                            
                                            sortValuePosition = 0;
                                            
                                            for (int counter2 = 0; counter2 < 3; counter2++){
                                                sortValue = -999999999;
                                                
                                                for (int counter3 = 0; counter3 < 3; counter3++){
                                                    if (sortValue < sortTemp [counter3]){
                                                        sortValue = sortTemp [counter3];
                                                        sortValuePosition = counter3;
                                                    }
                                                }
                                                
                                                newSort [counter2] = sortValue;
                                                sortTemp [sortValuePosition] = -999999999;
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                    break;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                    break;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        if (currentCellNumber1 != 0 && currentCellNumber2 != 0 && currentCellNumber3 != 0 && currentCellNumber4 != 0){
                                            cellNumberProcessHold = cellNumberSend;
                                            
                                            sortTemp [0] = currentCellNumber1;
                                            sortTemp [1] = currentCellNumber2;
                                            sortTemp [2] = currentCellNumber3;
                                            sortTemp [3] = currentCellNumber4;
                                            
                                            //cout<<sortTemp [0] <<" "<<sortTemp [1]<<" "<<sortTemp [2] <<" "<<sortTemp [3] <<" numberA"<<endl;
                                            
                                            sortValuePosition = 0;
                                            
                                            for (int counter2 = 0; counter2 < 4; counter2++){
                                                sortValue = -999999999;
                                                
                                                for (int counter3 = 0; counter3 < 4; counter3++){
                                                    if (sortValue < sortTemp [counter3]){
                                                        sortValue = sortTemp [counter3];
                                                        sortValuePosition = counter3;
                                                    }
                                                }
                                                
                                                currentSort [counter2] = sortValue;
                                                sortTemp [sortValuePosition] = -999999999;
                                            }
                                            
                                            newCellNumber1 = [self primaryAddition];
                                            newCellNumber2 = [self primarySubtract];
                                            newCellNumber3 = [self secondaryAddition];
                                            newCellNumber4 = [self secondarySubtract];
                                            
                                            sortTemp [0] = newCellNumber1;
                                            sortTemp [1] = newCellNumber2;
                                            sortTemp [2] = newCellNumber3;
                                            sortTemp [3] = newCellNumber4;
                                            
                                            sortValuePosition = 0;
                                            
                                            for (int counter2 = 0; counter2 < 4; counter2++){
                                                sortValue = -999999999;
                                                
                                                for (int counter3 = 0; counter3 < 4; counter3++){
                                                    if (sortValue < sortTemp [counter3]){
                                                        sortValue = sortTemp [counter3];
                                                        sortValuePosition = counter3;
                                                    }
                                                }
                                                
                                                newSort [counter2] = sortValue;
                                                sortTemp [sortValuePosition] = -999999999;
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [0]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [0];
                                                    break;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [1]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [1];
                                                    break;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [2]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [2];
                                                    break;
                                                }
                                            }
                                            
                                            for (int counter3 = 0; counter3 < cellNumberDeleteHoldCount2/2; counter3++){
                                                if (cellNumberDeleteHold2 [counter3*2] == currentSort [3]){
                                                    cellNumberDeleteHold2 [counter3*2+1] = newSort [3];
                                                    break;
                                                }
                                            }
                                        }
                                    }
                                    else terminationFlag = 1;
                                    
                                } while (terminationFlag == 0);
                                
                                delete [] cellNumberDeleteHold;
                                
                                //for (int counterA = 0; counterA < cellNumberDeleteHoldCount2/2; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<cellNumberDeleteHold2 [counterA*2+counterB];
                                //    cout<<" cellNumberDeleteHold2 "<<counterA <<" "<<lingNoSelect<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                    for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                        if (lineageExtractTemp2 [counter3*9+5] == cellNumberDeleteHold2 [counter4*2]){
                                            lineageExtractTemp2 [counter3*9+5] = cellNumberDeleteHold2 [counter4*2+1];
                                            break;
                                        }
                                    }
                                    
                                    for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                        if (lineageExtractTemp2 [counter3*9+4] == cellNumberDeleteHold2 [counter4*2]){
                                            if (lineageExtractTemp2 [counter3*9+3] != 91 && lineageExtractTemp2 [counter3*9+3] != 92){
                                                lineageExtractTemp2 [counter3*9+4] = cellNumberDeleteHold2 [counter4*2+1];
                                                break;
                                            }
                                        }
                                    }
                                    
                                    fusionFind = 0;
                                    
                                    if (lineageExtractTemp2 [counter3*9+3] == 91 || lineageExtractTemp2 [counter3*9+3] == 92){
                                        for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                            if (lineageExtractTemp2 [counter3*9+4] == cellNumberDeleteHold2 [counter4*2]){
                                                lineageExtractTemp2 [counter3*9+4] = cellNumberDeleteHold2 [counter4*2+1];
                                                lineageExtractTemp2 [counter3*9+7] = 1;
                                                fusionFind = 1;
                                                break;
                                            }
                                        }
                                        
                                        if (fusionFind == 0){
                                            lineageExtractTemp2 [counter3*9+4] = 0;
                                            lineageExtractTemp2 [counter3*9+7] = 0;
                                        }
                                    }
                                    
                                    lineageExtractTemp2 [counter3*9+2] = lineageExtractTemp2 [counter3*9+2]-startTime+1;
                                    lineageExtractTemp2 [counter3*9+6] = 1;
                                }
                                
                                //for (int counterA = 0; counterA < lineageExtractTempCount3/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp3 [counterA*9+counterB];
                                //    cout<<" lineageExtractTemp3 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                    if (lineageExtractTemp2 [counter3*9+2] == 1 && lineageExtractTemp2 [counter3*9+5] == 0){
                                        lineageExtractTemp2 [counter3*9+3] = 1;
                                        lineageExtractTemp2 [counter3*9+4] = 0;
                                        lineageExtractTemp2 [counter3*9+7] = 0;
                                        break;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                                //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount2/22; counter3++){
                                    for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                        if (ifExtractTemp2 [counter3*22] == cellNumberDeleteHold2 [counter4*2]){
                                            ifExtractTemp2 [counter3*22] = cellNumberDeleteHold2 [counter4*2+1];
                                            ifExtractTemp2 [counter3*22+1] = 1;
                                            ifExtractTemp2 [counter3*22+2] = ifExtractTemp2 [counter3*22+2]-startTime+1;
                                            break;
                                        }
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < areaExtractTempCount2/5; counter3++){
                                    for (int counter4 = 0; counter4 < cellNumberDeleteHoldCount2/2; counter4++){
                                        if (areaExtractTemp2 [counter3*5+1] == cellNumberDeleteHold2 [counter4*2]){
                                            areaExtractTemp2 [counter3*5] = 1;
                                            areaExtractTemp2 [counter3*5+1] = cellNumberDeleteHold2 [counter4*2+1];
                                            areaExtractTemp2 [counter3*5+4] = areaExtractTemp2 [counter3*5+4]-startTime+1;
                                            break;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < areaExtractTempCount2/5; counterA++){
                                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp2 [counterA*5+counterB];
                                //    cout<<" areaExtractTemp2 "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < lineageExtractTempCount2/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp2 [counterA*9+counterB];
                                //    cout<<" lineageExtractTemp2 "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                                //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                                //}
                                
                                int *arrayIFTimeLineDataTemp2 = new int [arrayIFTimeLineDataTempCount+50];
                                arrayIFTimeLineDataTempCount2 = 0;
                                
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = 0, arrayIFTimeLineDataTempCount2++;
                                
                                newIFStart = 0;
                                
                                for (int counter2 = 0; counter2 < arrayIFTimeLineDataTempCount/9; counter2++){
                                    if (counter2 >= startTime){
                                        if (arrayIFTimeLineDataTemp [counter2*9] != 0){
                                            arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9]-startTime+1, arrayIFTimeLineDataTempCount2++;
                                        }
                                        else arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9], arrayIFTimeLineDataTempCount2++;
                                        
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+1], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+2], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+3], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+4], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+5], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+6], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+7], arrayIFTimeLineDataTempCount2++;
                                        arrayIFTimeLineDataTemp2 [arrayIFTimeLineDataTempCount2] = arrayIFTimeLineDataTemp [counter2*9+8], arrayIFTimeLineDataTempCount2++;
                                        
                                        if (arrayIFTimeLineDataTemp [counter2*9]-startTime+1 != 0 && arrayIFTimeLineDataTemp [counter2*9+1] > 0 && newIFStart == 0){
                                            newIFStart = arrayIFTimeLineDataTemp [counter2*9]-startTime+1;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount2/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp2 [counterA*6+counterB];
                                //    cout<<" arrayIFTimeLineDataTemp2 "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                                //    cout<<" lineageExtractTemp "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                                //    cout<<" ifExtractTemp "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < arrayIFTimeLineDataTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                                //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                                //    cout<<" areaExtractTemp "<<counterA<<endl;
                                //}
                                
                                if (newIFStart == 0) timeDICEnd = arrayTableDetail [trimOperationTableCurrentRow][3]-startTime+1;
                                else timeDICEnd = newIFStart-1;
                                
                                //----Detail table data: Array set----
                                int *arrayTableDetailTemp = new int [20];
                                
                                noOfLing = 0;
                                noOfCellStart = 0;
                                noOfCellEnd = 0;
                                noOfTotalCells = 0;
                                noOfDD = 0;
                                noOfTD = 0;
                                noOfHD = 0;
                                noOfMI = 0;
                                noOfFU = 0;
                                noOfCD = 0;
                                
                                maxLineageNo = 0;
                                
                                for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                    if (lineageExtractTemp2 [counter3*9+2] == 1 && (lineageExtractTemp2 [counter3*9+5] == 0 || lineageExtractTemp2 [counter3*9+5] == -1)){
                                        noOfLing++;
                                    }
                                    
                                    if (maxLineageNo < lineageExtractTemp2 [counter3*9+6]) maxLineageNo = lineageExtractTemp2 [counter3*9+6]; //==
                                    
                                    if (lineageExtractTemp2 [counter3*9+2] == 1 && lineageExtractTemp2 [counter3*9+5] == 0){
                                        noOfCellStart++;
                                    }
                                    
                                    if ((lineageExtractTemp2 [counter3*9+3] == 1 || lineageExtractTemp2 [counter3*9+3] == 31 || lineageExtractTemp2 [counter3*9+3] == 41 || lineageExtractTemp2 [counter3*9+3] == 51)){
                                        noOfTotalCells++;
                                    }
                                    
                                    if (lineageExtractTemp2 [counter3*9+2] == timeDICEnd) noOfCellEnd++;
                                    if (lineageExtractTemp2 [counter3*9+3] == 32) noOfDD++;
                                    if (lineageExtractTemp2 [counter3*9+3] == 42) noOfTD++;
                                    if (lineageExtractTemp2 [counter3*9+3] == 52) noOfHD++;
                                    if (lineageExtractTemp2 [counter3*9+3] == 6) noOfMI++;
                                    if (lineageExtractTemp2 [counter3*9+3] == 91) noOfFU++;
                                    if (lineageExtractTemp2 [counter3*9+3] == 7) noOfCD++;
                                }
                                
                                arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                                arrayTableDetailTemp [1] = noOfLing;
                                arrayTableDetailTemp [2] = 1;
                                arrayTableDetailTemp [3] = timeDICEnd;
                                
                                if (newIFStart != 0){
                                    arrayTableDetailTemp [4] = newIFStart;
                                    arrayTableDetailTemp [5] = arrayTableDetail [trimOperationTableCurrentRow][5]-startTime+1;
                                }
                                else{
                                    
                                    arrayTableDetailTemp [4] = 0;
                                    arrayTableDetailTemp [5] = 0;
                                }
                                
                                arrayTableDetailTemp [6] = noOfCellStart;
                                arrayTableDetailTemp [7] = noOfCellEnd;
                                
                                if (noOfCellStart != 0){
                                    foldTemp = noOfCellEnd/(double)noOfCellStart;
                                    foldTemp = foldTemp*10+1;
                                }
                                else foldTemp = 1;
                                
                                arrayTableDetailTemp [8] = (int)foldTemp;
                                arrayTableDetailTemp [9] = noOfTotalCells;
                                arrayTableDetailTemp [10] = noOfDD;
                                arrayTableDetailTemp [11] = noOfTD;
                                arrayTableDetailTemp [12] = noOfHD;
                                arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                                arrayTableDetailTemp [14] = noOfMI;
                                arrayTableDetailTemp [15] = noOfFU;
                                arrayTableDetailTemp [16] = noOfCD;
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                                //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                                //}
                                
                                delete [] cellNumberDeleteHold2;
                                
                                //----Link Data----
                                lineageLinkListLengthTemp = 4;
                                int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                
                                for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter2++) arrayLineageLinkTemp [counter2] = 0;
                                
                                for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                    if (lineageExtractTemp2 [counter2*9+3] == 31 || lineageExtractTemp2 [counter2*9+3] == 41 || lineageExtractTemp2 [counter2*9+3] == 51 || lineageExtractTemp2 [counter2*9+3] == 1){
                                        lingNoTemp = lineageExtractTemp2 [counter2*9+6];
                                        arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                    }
                                }
                                
                                for (int counter2 = 0; counter2 < lineageExtractTempCount2/9; counter2++){
                                    lingNoTemp = lineageExtractTemp2 [counter2*9+6];
                                    
                                    if (lineageExtractTemp2 [counter2*9+7] != 0 && lineageExtractTemp2 [counter2*9+7] != lingNoTemp){
                                        matchFind = 0;
                                        freeSpotFind = 0;
                                        
                                        for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter3] == lineageExtractTemp2 [counter2*9+7]){
                                                matchFind = 1;
                                            }
                                            
                                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter3] == 0 && freeSpotFind == 0){
                                                freeSpotFind = counter3;
                                            }
                                        }
                                        
                                        if (matchFind == 0){
                                            if (freeSpotFind == 0){
                                                previousLengthHold = lineageLinkListLengthTemp;
                                                int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                
                                                for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++) arrayUpDate [counter3] = arrayLineageLinkTemp [counter3];
                                                
                                                delete [] arrayLineageLinkTemp;
                                                lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                                arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                                
                                                readingCount = 0;
                                                
                                                for (int counter3 = 0; counter3 <= maxLineageNo; counter3++){
                                                    for (int counter4 = 0; counter4 < previousLengthHold; counter4++){
                                                        arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] = arrayUpDate [readingCount], readingCount++;
                                                    }
                                                    
                                                    arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                                    arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                                }
                                                
                                                delete [] arrayUpDate;
                                                
                                                freeSpotFind = previousLengthHold;
                                            }
                                            
                                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = lineageExtractTemp2 [counter2*9+7];
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                                //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                                //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                                //}
                                
                                for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                    if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+1] != 0){
                                        freeSpotFind = -1;
                                        
                                        for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                            if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] == 0){
                                                freeSpotFind = counter3;
                                                break;
                                            }
                                        }
                                        
                                        if (freeSpotFind == -1) freeSpotFind = 4;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                    lengthExpansionFlag = 0;
                                                    
                                                    for (int counter4 = 1; counter4 <= maxLineageNo; counter4++){
                                                        if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3]){
                                                            entryNo = 0;
                                                            
                                                            for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                                findFlag = 0;
                                                                
                                                                for (int counter6 = 1; counter6 < lineageLinkListLengthTemp; counter6++){
                                                                    if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0 && (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter6] || arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == counter2)){
                                                                        findFlag = 1;
                                                                    }
                                                                    else if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0) findFlag = 1;
                                                                }
                                                                
                                                                if (findFlag == 0) entryNo++;
                                                            }
                                                            
                                                            if (entryNo != 0){
                                                                if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                                    previousLengthHold = lineageLinkListLengthTemp;
                                                                    int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                                    
                                                                    for (int counter5 = 0; counter5 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter5++) arrayUpDate [counter5] = arrayLineageLinkTemp [counter5];
                                                                    
                                                                    if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                                    else expansionNo = freeSpotFind+entryNo;
                                                                    
                                                                    delete [] arrayLineageLinkTemp;
                                                                    lineageLinkListLengthTemp = expansionNo+2;
                                                                    arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                                    lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                                    
                                                                    expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                                    
                                                                    readingCount = 0;
                                                                    
                                                                    for (int counter5 = 0; counter5 <= maxLineageNo; counter5++){
                                                                        for (int counter6 = 0; counter6 < previousLengthHold; counter6++){
                                                                            arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+counter6] = arrayUpDate [readingCount], readingCount++;
                                                                        }
                                                                        
                                                                        for (int counter6 = 0; counter6 < expansionNo; counter6++){
                                                                            arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+previousLengthHold+counter6] = 0;
                                                                        }
                                                                    }
                                                                    
                                                                    delete [] arrayUpDate;
                                                                    
                                                                    lengthExpansionFlag = 1;
                                                                    
                                                                    break;
                                                                }
                                                                else{
                                                                    
                                                                    for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                                        findFlag = 0;
                                                                        
                                                                        for (int counter6 = 1; counter6 < lineageLinkListLengthTemp; counter6++){
                                                                            if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0 && (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter6] || arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == counter2)){
                                                                                findFlag = 1;
                                                                            }
                                                                            else if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0) findFlag = 1;
                                                                        }
                                                                        
                                                                        if (findFlag != 1){
                                                                            arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5];
                                                                            
                                                                            freeSpotFind++;
                                                                        }
                                                                    }
                                                                    
                                                                    arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] = -1;
                                                                    break;
                                                                }
                                                            }
                                                            else arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] = -1;
                                                        }
                                                    }
                                                    
                                                    if (lengthExpansionFlag == 1){
                                                        break;
                                                    }
                                                }
                                                
                                                if (counter3 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                                            }
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                                //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                                //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                                //}
                                
                                int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                                int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                                
                                for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                    if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+1] != 0){
                                        numberOfFusionEntry = 0;
                                        
                                        for (int counter3 = 0; counter3 < lineageLinkListLengthTemp; counter3++){
                                            if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                numberOfFusionEntry++;
                                            }
                                        }
                                        
                                        if (numberOfFusionEntry > 1){
                                            for (int counter3 = 0; counter3 < lineageLinkListLengthTemp; counter3++){
                                                if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                    numberOfEntryList [counter3] = arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3];
                                                }
                                                else numberOfEntryList [counter3] = 0;
                                                
                                                numberOfEntryList2 [counter3] = 0;
                                            }
                                            
                                            smallestEntry2 = 1;
                                            
                                            do{
                                                
                                                terminationFlag = 1;
                                                remainingFlag = 0;
                                                smallestEntry = 100000;
                                                smallestEntryPosition = 0;
                                                
                                                for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                    if (numberOfEntryList [counter3] != 0 && numberOfEntryList [counter3] < smallestEntry){
                                                        smallestEntry = numberOfEntryList [counter3];
                                                        smallestEntryPosition = counter3;
                                                        remainingFlag = 1;
                                                    }
                                                }
                                                
                                                if (remainingFlag == 0) terminationFlag = 0;
                                                else{
                                                    
                                                    numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                                    numberOfEntryList [smallestEntryPosition] = 0;
                                                }
                                                
                                            } while (terminationFlag == 1);
                                            
                                            for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] = numberOfEntryList2 [counter3];
                                            }
                                        }
                                    }
                                }
                                
                                delete [] numberOfEntryList;
                                delete [] numberOfEntryList2;
                                
                                //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                                //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                                //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                                //}
                                
                                //----Lineage Data type: Array Set----
                                for (int counter3 = 0; counter3 < 7; counter3++){
                                    arrayLineageDataType [lineageDataEntryCount][counter3] = arrayLineageDataType [trimOperationTableCurrentRow][counter3];
                                }
                                
                                arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                                arrayLineageDataType [lineageDataEntryCount][1] = "AN"+to_string(maxCategoryLingNo);
                                
                                //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                                //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" arrayLineageDataType "<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                //}
                                
                                //----LineageFluorescentDataType: Array Set----
                                fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                                
                                for (int counter3 = 0; counter3 < fluorescentDataEntryCount; counter3++){
                                    if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                    
                                    if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == trimOperationTableCurrentRow+1){
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter3][1];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter3][2];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter3][3];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter3][4];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter3][5];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter3][6];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter3][7];
                                        
                                        lineageFluorescentDataTypeEntryCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                //}
                                
                                //----Data save----
                                savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                                
                                oin.open(savePath.c_str(), ios::out);
                                oin<<to_string(lineageDataEntryCount+1)<<endl;
                                oin<<"AN"+to_string(maxCategoryLingNo)<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                                
                                for (int counter3 = 0; counter3 < lineageFluorescentDataTypeEntryCount; counter3++){
                                    if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == lineageDataEntryCount+1){
                                        oin<<arrayLineageFluorescentDataType [counter3][0]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][1]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][2]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][3]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][4]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][5]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][6]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][7]<<endl;
                                    }
                                }
                                
                                oin.close();
                                
                                if (lineageDataEntryCount < 101){
                                    delete [] arrayLineageData [lineageDataEntryCount];
                                    delete [] arrayIFData [lineageDataEntryCount];
                                    delete [] arrayIFTimeLineData [lineageDataEntryCount];
                                    delete [] arrayTableMain [lineageDataEntryCount];
                                    delete [] arrayIfTimeStatus [lineageDataEntryCount];
                                    delete [] arrayAreaData [lineageDataEntryCount];
                                    delete [] arrayLineageLink [lineageDataEntryCount];
                                    
                                    arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                                    arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                                    arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataTempCount+10];
                                    arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [trimOperationTableCurrentRow]+10];
                                    arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [trimOperationTableCurrentRow]+10];
                                    arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                                    arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                                    
                                    lineageDataEntryCount++;
                                }
                                else if (warningDisplayOnce == 0){
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                    
                                    warningDisplayOnce = 1;
                                }
                                
                                if (lineageDataEntryCount-1 < 101){
                                    for (int counter3 = 0; counter3 < lineageExtractTempCount2; counter3++) arrayLineageData [lineageDataEntryCount-1][counter3] = lineageExtractTemp2 [counter3];
                                    
                                    arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)lineageExtractTempCount2;
                                    
                                    //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                                    //    cout<<" arrayLineageData "<<counterA<<endl;
                                    //}
                                    
                                    for (int counter3 = 0; counter3 < ifExtractTempCount2; counter3++) arrayIFData [lineageDataEntryCount-1][counter3] = ifExtractTemp2 [counter3];
                                    
                                    arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount2;
                                    
                                    //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                                    //    cout<<" arrayIFData "<<counterA<<endl;
                                    //}
                                    
                                    for (int counter3 = 0; counter3 < arrayIFTimeLineDataTempCount2; counter3++){
                                        arrayIFTimeLineData [lineageDataEntryCount-1][counter3] = arrayIFTimeLineDataTemp2 [counter3];
                                    }
                                    
                                    arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataTempCount2;
                                    
                                    for (int counter3 = 0; counter3 < arrayTableMainHold [trimOperationTableCurrentRow]; counter3++) arrayTableMain [lineageDataEntryCount-1][counter3] = arrayTableMain [trimOperationTableCurrentRow][counter3];
                                    
                                    arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                    arrayTableMain [lineageDataEntryCount-1][1] = "AN";
                                    arrayTableMain [lineageDataEntryCount-1][4] = "AN"+to_string(maxCategoryLingNo)+"-"+treatNameExtract;
                                    
                                    arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [trimOperationTableCurrentRow];
                                    
                                    for (int counter3 = 0; counter3 < 17; counter3++) arrayTableDetail [lineageDataEntryCount-1][counter3] = arrayTableDetailTemp [counter3];
                                    
                                    ifStatusEntryCount = 0;
                                    
                                    if (arrayTableDetailTemp [4] != 0){
                                        for (int counter2 = arrayTableDetailTemp [4]; counter2 <= arrayTableDetailTemp [5]; counter2++){
                                            arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = counter2, ifStatusEntryCount++;
                                            arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = 0, ifStatusEntryCount++;
                                        }
                                    }
                                    
                                    arrayIfTimeStatusHold [lineageDataEntryCount-1] = ifStatusEntryCount;
                                    
                                    for (int counter3 = 0; counter3 < areaExtractTempCount2; counter3++) arrayAreaData [lineageDataEntryCount-1][counter3] = areaExtractTemp2 [counter3];
                                    
                                    arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount2;
                                    
                                    //**********arrayLinkData**********
                                    for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++){
                                        arrayLineageLink [lineageDataEntryCount-1][counter3] = arrayLineageLinkTemp [counter3];
                                    }
                                    
                                    arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                                    
                                    lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                                    
                                    savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                                    
                                    char *writingArray = new char [lineageExtractTempCount2/9*28+100];
                                    
                                    indexCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < lineageExtractTempCount2/9; counter3++){
                                        if (lineageExtractTemp2 [counter3*9] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9];
                                        }
                                        
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        if (lineageExtractTemp2 [counter3*9+1] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9+1]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9+1];
                                        }
                                        
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        dataTemp = lineageExtractTemp2 [counter3*9+2];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        writingArray [indexCount] = (char)lineageExtractTemp2 [counter3*9+3], indexCount++;
                                        
                                        if (lineageExtractTemp2 [counter3*9+4] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9+4]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9+4];
                                        }
                                        
                                        readBit [0] = dataTemp/16777216;
                                        dataTemp = dataTemp%16777216;
                                        readBit [1] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [2] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [3] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                                        
                                        if (lineageExtractTemp2 [counter3*9+5] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9+5]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = lineageExtractTemp2 [counter3*9+5];
                                        }
                                        
                                        readBit [0] = dataTemp/16777216;
                                        dataTemp = dataTemp%16777216;
                                        readBit [1] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [2] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [3] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                                        
                                        dataTemp = lineageExtractTemp2 [counter3*9+6];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = lineageExtractTemp2 [counter3*9+7];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = lineageExtractTemp2 [counter3*9+8];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < 28; counter3++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile (savePath.c_str(), ofstream::binary);
                                    outfile.write ((char*) writingArray, indexCount);
                                    outfile.close();
                                    
                                    delete [] writingArray;
                                    
                                    savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<lineageExtractTempCount2<<endl;
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"IFData";
                                    
                                    writingArray = new char [ifExtractTempCount2/22*60+60];
                                    
                                    indexCount = 0;
                                    
                                    for (int counter3 = 0; counter3 < ifExtractTempCount2/22; counter3++){
                                        if (ifExtractTemp2 [counter3*22] < 0){
                                            writingArray [indexCount] = 1, indexCount++;
                                            dataTemp = ifExtractTemp2 [counter3*22]*-1;
                                        }
                                        else{
                                            
                                            writingArray [indexCount] = 0, indexCount++;
                                            dataTemp = ifExtractTemp2 [counter3*22];
                                        }
                                        
                                        readBit [0] = dataTemp/16777216;
                                        dataTemp = dataTemp%16777216;
                                        readBit [1] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [2] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [3] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        writingArray [indexCount] = (char)readBit [3], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+1];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+2];
                                        readBit [0] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [1] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+3], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+4], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+5];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+6];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+7], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+8];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+9];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+10], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+11];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+12];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+13], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+14];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+15];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+16], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+17];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+18];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        writingArray [indexCount] = (char)ifExtractTemp2 [counter3*22+19], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+20];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                        
                                        dataTemp = ifExtractTemp2 [counter3*22+21];
                                        readBit [0] = dataTemp/65536;
                                        dataTemp = dataTemp%65536;
                                        readBit [1] = dataTemp/256;
                                        dataTemp = dataTemp%256;
                                        readBit [2] = dataTemp;
                                        
                                        writingArray [indexCount] = (char)readBit [0], indexCount++;
                                        writingArray [indexCount] = (char)readBit [1], indexCount++;
                                        writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    }
                                    
                                    for (int counter3 = 0; counter3 < 33; counter3++) writingArray [indexCount] = 0, indexCount++;
                                    
                                    ofstream outfile2 (savePath.c_str(), ofstream::binary);
                                    outfile2.write ((char*) writingArray, indexCount);
                                    outfile2.close();
                                    
                                    delete [] writingArray;
                                    
                                    savePath = imageDisplayPath+"/"+"IFDataEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<ifExtractTempCount2<<endl;
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"IFTimeLine";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    
                                    for (int counter3 = 0; counter3 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter3++){
                                        oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter3]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"MainTable";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    
                                    for (int counter3 = 0; counter3 < arrayTableMainHold [lineageDataEntryCount-1]; counter3++){
                                        oin<<arrayTableMain [lineageDataEntryCount-1][counter3]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"MainTableEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"DetailTable";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    
                                    for (int counter3 = 0; counter3 < 17; counter3++){
                                        oin<<arrayTableDetail [lineageDataEntryCount-1][counter3]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/IFDataStatus";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    
                                    for (int counter3 = 0; counter3 < arrayIfTimeStatusHold [lineageDataEntryCount-1]; counter3++){
                                        oin<<arrayIfTimeStatus [lineageDataEntryCount-1][counter3]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/IFDataStatusEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<arrayIfTimeStatusHold [lineageDataEntryCount-1]<<endl;
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"AreaData";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    
                                    for (int counter3 = 0; counter3 < arrayAreaDataHold [lineageDataEntryCount-1]; counter3++){
                                        oin<<arrayAreaData [lineageDataEntryCount-1][counter3]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/AreaDataEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/"+"LinkData";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    
                                    for (int counter3 = 0; counter3 < lineageLinkHold [lineageDataEntryCount-1]; counter3++){
                                        oin<<arrayLineageLink [lineageDataEntryCount-1][counter3]<<endl;
                                    }
                                    
                                    oin.close();
                                    
                                    savePath = imageDisplayPath+"/LinkDataEntry";
                                    
                                    oin.open(savePath.c_str(), ios::out | ios::binary);
                                    oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                                    oin.close();
                                }
                                
                                delete [] lineageExtractTemp2;
                                delete [] ifExtractTemp2;
                                delete [] areaExtractTemp2;
                                delete [] arrayIFTimeLineDataTemp2;
                                delete [] arrayLineageLinkTemp;
                                delete [] arrayTableDetailTemp;
                            }
                            
                            upLoadingFlag = 1;
                            
                            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
                            
                            delete [] areaExtractTemp;
                            delete [] arrayIFTimeLineDataTemp;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"No Matching Data Found"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                        
                        delete [] ifExtractTemp;
                        delete [] cellDoublingInformation;
                        delete [] lineageExtractTemp;
                        delete [] startCellNoList;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"Value Range: T1 Value <= T2 Value, CH > 0"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                        
                        [rangeValueADisplay1 setStringValue:@""];
                        [rangeValueADisplay2 setStringValue:@""];
                        [rangeValueCHDisplayA setStringValue:@""];
                        [rangeValueBDisplay1 setStringValue:@""];
                        [rangeValueBDisplay2 setStringValue:@""];
                        [rangeValueCHDisplayB setStringValue:@""];
                    }
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Start < End and IntervalIn > IntervalOut And IntervalIn = IntervalOut*X"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"SO File Cannot Be Processed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Entry Limit Exceeded: 100 Or No Entry"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)primaryAddition{
    string cellNumberExtract = to_string(cellNumberProcessHold);
    int cellNumberTempInt = atoi(cellNumberExtract.c_str());
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = -100000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt+10000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt+1000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt+100000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt+10000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt+1000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt+100;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt+10;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt+1;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"700";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"700";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)primarySubtract{
    string cellNumberExtract = to_string(cellNumberProcessHold);
    int cellNumberTempInt = cellNumberProcessHold;
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = 100000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt-10000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt-1000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt-100000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt-10000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt-1000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt-100;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt-10;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt-1;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"300";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"300";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)secondaryAddition{
    string cellNumberExtract = to_string(cellNumberProcessHold);
    int cellNumberTempInt = cellNumberProcessHold;
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = -200000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt+20000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt+2000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt+200000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt+20000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt+2000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt+200;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt+20;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt+2;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"600";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"600";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(int)secondarySubtract{
    string cellNumberExtract = to_string(cellNumberProcessHold);
    int cellNumberTempInt = cellNumberProcessHold;
    int numberLength = (int)cellNumberExtract.length();
    int zeroPoint = -1;
    int digitNumber = 0;
    int checkFlag = 0;
    int newCellNumber = 0;
    
    if (cellNumberTempInt == 0) newCellNumber = 200000000;
    else{
        
        string digitExtract;
        
        for (int counter1 = 0; counter1 < numberLength; counter1++){
            digitExtract = cellNumberExtract.substr((unsigned long)counter1, 1);
            
            if (checkFlag == 0 && digitExtract == "0"){
                zeroPoint = counter1;
                checkFlag = 1;
            }
            else if (checkFlag == 1 && digitExtract != "0"){
                zeroPoint = -1;
                checkFlag = 0;
            }
        }
        
        if (zeroPoint != -1){
            digitNumber = numberLength-zeroPoint;
            
            if (digitNumber == 8) newCellNumber = cellNumberTempInt-20000000;
            else if (digitNumber == 7) newCellNumber = cellNumberTempInt-2000000;
            else if (digitNumber == 6) newCellNumber = cellNumberTempInt-200000;
            else if (digitNumber == 5) newCellNumber = cellNumberTempInt-20000;
            else if (digitNumber == 4) newCellNumber = cellNumberTempInt-2000;
            else if (digitNumber == 3) newCellNumber = cellNumberTempInt-200;
            else if (digitNumber == 2) newCellNumber = cellNumberTempInt-20;
            else if (digitNumber == 1) newCellNumber = cellNumberTempInt-2;
        }
        else{
            
            if (cellNumberExtract.substr(0,1) == "-" && (int)cellNumberExtract.length() == 9){
                cellNumberExtract = "-0"+cellNumberExtract.substr(1);
            }
            else if (cellNumberExtract.substr(0,1) != "-" && (int)cellNumberExtract.length() == 8){
                cellNumberExtract = "0"+cellNumberExtract;
            }
            
            int cellExtensionEntry = 0;
            
            if (cellNumberTempInt > 0){
                if (cellNumberExtract.substr(0, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "30000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "3000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "300"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "30"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "3"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "1" || cellNumberExtract.substr(0, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "40000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "4000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "400"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "40"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "4"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "5"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "50000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "5000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "500"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "50"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "5"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(0, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(0, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "60000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "6000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "600"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "60"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "6"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
            else{
                
                if (cellNumberExtract.substr(1, 1) == "0"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "3"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-30000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-3000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-300"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-30"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-3"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "1" || cellNumberExtract.substr(1, 1) == "2"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-40000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-4000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-400"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-40"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-4"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "3"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "4"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-50000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-5000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-500"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-50"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-5"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
                
                if (cellNumberExtract.substr(1, 1) == "4"){
                    for (int counter1 = 0; counter1 < cellNumberDeleteHoldCount2/2; counter1++){
                        if ((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(1, 1) == "6"){
                            if (atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str()) > cellExtensionEntry){
                                cellExtensionEntry = atoi((to_string(cellNumberDeleteHold2 [counter1*2+1])).substr(2, 5).c_str());
                            }
                        }
                    }
                    
                    cellExtensionEntry++;
                    
                    string newExtensionEntryNo = to_string(cellExtensionEntry);
                    
                    if (newExtensionEntryNo.length() == 1) newExtensionEntryNo = "-60000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 2) newExtensionEntryNo = "-6000"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 3) newExtensionEntryNo = "-600"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 4) newExtensionEntryNo = "-60"+newExtensionEntryNo+"400";
                    else if (newExtensionEntryNo.length() == 5) newExtensionEntryNo = "-6"+newExtensionEntryNo+"400";
                    
                    newCellNumber = atoi(newExtensionEntryNo.c_str());
                }
            }
        }
    }
    
    return newCellNumber;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

@end
