//
//  Controller.mm
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/11/19.
//  Copyright 2010 Masahiko Sato. All rights reserved.
//

#import "Controller.h"

//----Basic info----
int sourceStatusHold;
int tableViewCall;
int tableCurrentRowHold;
int progressTiming;
int progressValue;
int upLoadingProgress;
int upLoadingFlag;
string pathNameString;
string trackDataFolderPath;
string analysisDataFolderPath;
string seriesName;
string analysisID;
string treatName;

//----Arrays----
string *arrayDirectoryInfo;
int directoryInfoCount;
int directoryInfoLimit;
int **arrayLineageData;
unsigned long *arrayLineageDataEntryHold;
int **arrayIFData;
int *arrayIFDataEntryHold;
int **arrayIFTimeLineData;
int *arrayIFTimeLineDataEntryHold;
string **arrayTableMain;
int *arrayTableMainHold;
int **arrayTableDetail;
int **arrayIfTimeStatus;
int *arrayIfTimeStatusHold;
int **arrayAreaData;
int *arrayAreaDataHold;
int **arrayLineageLink;
int *lineageLinkHold;
int lineageDataEntryCount;
int firstReadFlag;
int initialArraySet;
int *arraySelectedLing;

//----Type Definition----
string *arrayTypeDefinitionHold;
int typeDefinitionCount;
int typeDefinitionLimit;
string *arrayTypeDefinitionHold2;
int typeDefinitionCount2;
int typeDefinitionLimit2;
int typeDefTimerAdjustOperation;

//----Lineage Data Set----
string **arrayLineageDataType;
string **arrayLineageFluorescentDataType;
int lineageFluorescentDataTypeEntryCount;
int lineageFluorescentDataTypeEntryLimit;
int lineageDataAdjustOperation;
int noOfFluorescentDisplay;
int displayEntryNo;
int lineageDataOpen;

//----Data uploading----
string analysisIDSelect;
int analysisLoadOperation;
string sourceAnalysisPath;
string analysisSeriesNameSelect;
string analysisImageNameSelect;

//----Main Lineage Draw----
int *arrayLineageExtract;
unsigned long lineageExtractCount;
unsigned long lineageExtractLimit;
int *arrayLineageLinkList;
int lineageLinkListCount;
int lineageLinkListLimit;
int lineageLinkListLength;
int lineageDisplayPosition;
int maxLingNo;
int liveCurrentCHNo;
int *ifDataExtract;
int ifDataExtractCount;
int ifDataExtractLimit;
int *ifValueExtract;
int ifValueExtractCount;
int ifValueExtractLimit;
int *ifTimeExtract;
int ifTimeExtractCount;
int ifTimeExtractLimit;
int ifCurrentCHNo;
int ifCurrentTime;
int *areaExtract;
int areaExtractCount;
int areaExtractLimit;

int *holdReviseLineage;
unsigned long holdReviseLineageCount;
unsigned long holdReviseLineageLimit;
int holdReviseLineageStatus;
int *holdReviseIfData;
int holdReviseIfDataCount;
int holdReviseIfDataLimit;
int holdReviseIfDataStatus;
int *holdReviseAreaData;
int holdReviseAreaDataCount;
int holdReviseAreaDataLimit;
int holdReviseAreaDataStatus;

int averageTotalFlag;
int includeExcludeFlag;
int includeExcludeModification;
int lineageModification;
int blueLineFlag;
int cellNumberFlag;
int lineWidthFlag;
int endNumberFlag;
int markSizeFlag;

//----Others----
string *arrayFileDelete;
int fileDeleteCount;
int fileDeleteLimit;
CGFloat *arrayColorRange;
CGFloat *arrayColorRange2;
int exportTiming;
int exportFlag1;
int exportFlag3;
int exportFlag5;
int exportFlag6;
int exportFlag7;
int exportFlag8;
int exportFlag9;
int exportFlag10;

//----Search----
int searchWindowOperation;
string *arraySearchResultsHold;
int searchResultsHoldStatus;
int searchResultsHoldCount;
int searchResultsHoldLimit;
string *arrayDisplayForSearch;
int displayForSearchStatus;
int displayForSearchCount;
int displayForSearchLimit;
string searchStatus1;
string searchStatus2;
string searchStatus3;
string searchStatus4;
string typeSearchName;
string seriesSearchName;
string analysisSearchName;
string treatSearchName;
int searchOperationTableCount;
int rowSearchOperationTable;
int searchOperationTableCurrentRow;

//----Lineage list display----
int lineageWindowOperation;
int liveDisplayHold;
int ifOneAllHold;
int averageTotalSetHold;
int blueLineDisplayHold;
int lingLineWidthHold;
int lineageOpen;
string typeLing;
string seriesLing;
string analysisLing;
string treatLing;
string displayNameCellLing;
string displayNameTreatLing;
string displayNameSeriesLing;
string ifRangeLing;
int ifRangeHigh;
int ifRangeLow;
int ifStepperHold;
int *arrayNoOfChList;
int noOfChListStatus;
int noOfChListCount;
int selectCurrentLineage;
int lineageCurrentPosition;
int lineageCurrentPositionHold;
int lingNo1;
int lingNo2;
int lingNo3;
int lingNo4;
int lingNo5;
int lingNo6;
int lingNo7;
int lingNo8;
int chNo1;
int siblingLingHold;
int colorOptionLingHold;
int lineageListCall;
int saveFlag;
int *arrayLineageLinkListLGL;
int lineageLinkListLGLCount;
int lineageLinkListLGLLimit;
int lineageLinkListLGLLength;

//----Growth curve----
int growthCurveWindowOperation;
int verticalScaleLowHold;
int verticalScaleHighHold;
int horizontalScaleLowHold;
int horizontalScaleHighHold;
int individualOverLayHold;
int normalizeStatusHold;
int verticalScaleMaxHold;
int horizontalScaleMaxHold;
int growthCurveCall;
int growthCurveOpen;
string exportResultPath;

//----Cell Division----
int cellDivisionWindowOperation;
int horizontalScaleLowDivisionHold;
int horizontalScaleHighDivisionHold;
int verticalScaleHighUpDivisionHold;
int verticalScaleHighDownDivisionHold;
int belowDisplayType;
int verticalScaleMaxUpDivisionHold;
int verticalScaleMaxDownDivisionHold;
int horizontalScaleMaxDivisionHold;
int cellDivisionCall;
int cellDivisionOpen;
int maxDDNumberHold;
int maxOtherHold;

//----Doubling time----
int doublingTimeWindowOperation;
int horizontalScaleLowDoublingTimeHold;
int horizontalScaleHighDoublingTimeHold;
int verticalScaleHighDoublingHold;
int verticalScaleMaxDoublingTimeHold;
int horizontalScaleMaxDoublingTimeHold;
int doublingTimeCall;
int doublingTimeOpen;
int rangeDoubleSt1;
int rangeDoubleSt2;
int rangeDoubleSt3;
int rangeDoubleSt4;
int rangeDoubleEd1;
int rangeDoubleEd2;
int rangeDoubleEd3;
int rangeDoubleEd4;

//----Progeny No----
int progenyNoWindowOperation;
string *arrayCategoryResultsHold;
int categoryResultsHoldStatus;
int categoryResultsHoldCount;
int categoryResultsHoldLimit;
int *arrayCategoryRangeHold;
int categoryRangeHoldStatus;
int categoryRangeHoldCount;

//----Progeny Analysis----
int progenyAnalysisWindowOperation;
string *arrayProgenyAnalysisResultsHold;
int progenyAnalysisResultsHoldStatus;
int progenyAnalysisResultsHoldCount;
int progenyAnalysisResultsHoldLimit;
int *arrayProgenyAnalysisRangeHold;
int progenyAnalysisRangeHoldStatus;
int progenyAnalysisRangeHoldCount;

//----Trim and merge----
int trimWindowOperation;
string *arrayTrimResultsHold;
int trimResultsHoldStatus;
int trimResultsHoldCount;
string *arrayMergeResultsHold;
int mergeResultsHoldStatus;
int mergeResultsHoldCount;
int trimOperationTableCount;
int rowTrimOperationTable;
int trimOperationTableCurrentRow;
int mergeOperationTableCount;
int rowMergeOperationTable;
int mergeOperationTableCurrentRow;
int trimCall;
int trimOpen;
int includeTDHDStatusHold;
int doublingTimeSimulateHold;
int lineageCutStatusHold;
int progenitorIncludeHold;

//----Event Analysis----
int eventAnalysisWindowOperation;
string *arrayEventAnalysisResultsHold;
int eventAnalysisResultsHoldStatus;
int eventAnalysisResultsHoldCount;
int eventAnalysisResultsHoldLimit;

//----Lineage select----
int lineageSelectWindowOperation;
string *arrayLineageSelectHold;
int lineageSelectHoldStatus;
int lineageSelectHoldCount;
int *arrayLineageSelectLineageHold;
int lineageSelectLineageHoldStatus;
int lineageSelectLineageHoldCount;
int lineageSelectLineageHoldLimit;
int lineageSelectOperationTableCount;
int rowLineageSelectOperationTable;
int lineageSelectOperationTableCurrentRow;
int lineageSelectNonSelOperationTableCount;
int rowLineageSelectNonOperationTable;
int lineageSelectNonOperationTableCurrentRow;
int lineageSelectSelOperationTableCount;
int rowLineageSelectSelOperationTable;
int lineageSelectSelOperationTableCurrentRow;
int lineageSelectCall;
int lineageSelectOpen;
int fusionMoveStatus;

string ascIIstring;

//----Main Window Magnification ----
int mainWindowMagOperation;
int lineageDisplayOption;
int lowXlow;
int highXhigh;
int lowXhigh;
int valueUK;
int mainWindowMagOpen;
int drawingOptionHold;
int unknownOptionHold;
int unknownPriorityHold;

//----Doubling time comparison ----
int doubCompOperation;
int *arrayDoubleCompRangeHold;
int progenyDoubleCompHoldStatus;
int progenyDoubleCompHoldCount;
string *arrayProgenyDoubleCompResultsHold;
int progenyDoubleCompResultsHoldStatus;
int progenyDoubleCompResultsHoldCount;
int progenyDoubleCompResultsHoldLimit;

//----Motility ----
int motilityOperation;
string *arrayMotilityResultsHold; 
int motilityResultsHoldStatus;
int motilityResultsHoldCount;
int motilityResultsHoldLimit;
int motilityColorHold;
int markerStartColorHold;
int markerEndColorHold; 
int markerMidColorHold;
int markerMidValueHold;
int motilityColorStatusHold;
int motilityDisplayScaleMaxHold;
int motilityVerticalStartHold;
int motilityHorizontalStartHold;
int motilityTimeStartHold;
int motilityTimeEndHold;
int motilityTableCategoryHold;
string motilityLineageHold;
int motilityCellNoHold;
int motilityAnalysisPerformHold;
string motilityTreatmentHold;
int motilityOperationTableCount;
int rowMotilityOperationTable;
int motilityOperationTableCurrentRow;
string motilityRangeVertical;
string motilityRangeHorizontal;

int activationStatus;
int displayOptionStatus;
int fixSizeHold;
double shiftX;
double shiftY;
int lingLineWidthMortHold;
int lingLineWidthDisplayMortHold;

//----SIMULATION ----
int simulationOperation;
double fitA1Hold;
double fitA2Hold;
double fitA3Hold;
double fitA4Hold;
double fitB1Hold;
double fitB2Hold;
double fitB3Hold;
double fitB4Hold;
int fitCycleHold;
double fitRangeBEndHold;
int fitTimeStartHold;
int fitModeStatusHold;
int colorNoSimHold;
int *simColorDataHold;
int simColorDataHoldStatus;
int simStartModeHold;
double *simProcessDataBaseHold;
double *simProcessDataMiddleHold;
double *simProcessDataProgHold;
double *simProcessDataAddHold;
int simProcessDataHoldStatus;
int growthProgTimeStartHold;
int growthProgTimeEndHold;
int growthMidTimeStartHold;
int growthCycleHold;
int growthInitHold;
string *arraySimListHold;
int simListHoldStatus;
int simListHoldCount;
int simOperationTableCurrentRow;
double *arrayFitDataHold;
int fitDataHoldStatus;
int fitDataHoldCount;
int processSimType;
int limitSimType;
int simulationCall;
int simulationOpen;
int *simulationDistributionData;
int simulationDistributionDataCount;
int *simulationFluorescentData;
int simulationFluorescentDataCount;
int *simulationDistributionProgData;
int simulationDistributionProgDataCount;
int *simulationDistributionMidData;
int simulationDistributionMidDataCount;
int *simulationDistributionAddData;
int simulationDistributionAddDataCount;
int simulationDistributionDataStatus;
int simulationFluorescentDataStatus;
int recoveryCalculationPercentHold;
int *activeCellStatusList;
int activeCellStatusListCount;
int activeCellStatusListLimitHold;
int *cellLineageTempArray;
unsigned long cellLineageTempArrayCount;
unsigned long cellLineageTempArrayLimit;
long *cellLineageSummaryArray;
unsigned long cellLineageSummaryArrayCount;
unsigned long cellLineageSummaryArrayLimit;
int performDataStatus;
int *activeCellStatusListKeep;
unsigned long activeCellStatusListKeepCount;
unsigned long activeCellStatusListKeepLimit;
int *cellNoLingNoList;
unsigned long cellNoLingNoListCount;
unsigned long cellNoLingNoListLimit;
int terminateSimFlag;
int terminateSimFlag2;
int backSaveOn;
int backSaveOn2;
int simulationProgress;
string processingStatus;
int processingStatusCall;
string processingStatus2;
int processingStatusCall2;
string processingStatus3;
int processingStatusCall3;
string processingStatus4;
int processingStatusCall4;
string messageStringSim;
string messageStringSim2;
string messageStringSim3;
string messageStringSim4;
int *cellGrowthCount;
int *cellNoListForSelectLing;
int cellNoListForSelectLingCount;
int cellGrowthCountTimeEnd;
int timingSimCount;
int simDimension;
string displayImageAllPath;
string displayImageSavePath;
int **mapPositionHeld;
int **mapCellNoHeld;
int **mapLingNoHeld;
int *cellEventTypeListTime;
int cellEventTypeListTimeCount;
int movieDistanceSet;
int movieDistanceHold;
int movieDistanceHold2;
int movieDistanceHold3;
int movieDistanceTime2;
int movieDistanceTime3;
int movieDistanceRedStatus;
int circleSizeHold;
int circleSizeRedStatus;
int videoColorStatus;
int *lingNoAssignSim;

int doseSimStatusHold;
double doseBaseHold;
double doseMiddleHold;
double doseTargetHold;
double endVariationHold;
int selectLingNoHold;
int lingSetDisplayCall;
int lingNoAssignSimCount;
int lingNoAssignSimStatus;
string messageLingSim;
string messageLingSim2;
string messageLingSim3;
string messageLingSim4;
string messageLingSim5;
string messageLingSim6;
string messageLingSim7;
string messageLingSim8;
int databaseLoadOptionHold;
int circleMinHold;
int simGraphModeHold;
int titleFontExport;
int videoImageSizeHold;
int videoImageSizeOptionHold;
int colorToneChangeTimeHold;
int colorToneChangeOptionHold;

int imageSimNoCount;
int drawFlag;
int lingNoSim;
double *lingColorListSim;
int fluorescentSimSetNo;
int fluorescentDropHold;

int maxEntryNoList;
int listEntryNoList;

@implementation Controller

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSString *currentDirectoryPathNSString = [[NSBundle mainBundle] bundlePath];
        string userPathNameString = [currentDirectoryPathNSString cStringUsingEncoding:NSUTF8StringEncoding];
        
        if (userPathNameString.length() == 0) exit (0);
        else if ((int)userPathNameString.find("/Users/") == -1) exit (0);
        else{
            
            string pathName2 = userPathNameString.substr((unsigned long)userPathNameString.find("/Users/")+7);
            pathNameString = pathName2.substr(0, (unsigned long)pathName2.find("/"));
        }
        
        sourceStatusHold = 1;
        tableViewCall = 0;
        tableCallCount = 0;
        rowIndexHold = 0;
        tableCurrentRowHold = 0;
        progressTiming = 0;
        progressValue = 0;
        upLoadingProgress = 0;
        upLoadingFlag = 0;
        
        lineageDataEntryCount = 0;
        firstReadFlag = 0;
        initialArraySet = 0;
        setStatus2 = 0;
        
        typeDefTimerAdjustOperation = 0;
        
        lineageDataAdjustOperation = 0;
        noOfFluorescentDisplay = 0;
        displayEntryNo = 0;
        lineageDataOpen = 0;
        
        analysisLoadOperation = 0;
        
        holdReviseLineageStatus = 0;
        holdReviseIfDataStatus = 0;
        holdReviseAreaDataStatus = 0;
        averageTotalFlag = 0;
        includeExcludeFlag = 0;
        includeExcludeModification = 0;
        blueLineFlag = 0;
        cellNumberFlag = 0;
        lineWidthFlag = 0;
        endNumberFlag = 0;
        markSizeFlag = 0;
        
        exportFlag1 = 0;
        exportFlag3 = 0;
        exportFlag5 = 0;
        exportFlag6 = 0;
        exportFlag7 = 0;
        exportFlag8 = 0;
        exportFlag9 = 0;
        exportFlag10 = 0;
        exportTiming = 0;
        
        searchWindowOperation = 0;
        searchResultsHoldStatus = 0;
        displayForSearchStatus = 0;
        typeSearchName = "nil";
        seriesSearchName = "nil";
        analysisSearchName = "nil";
        treatSearchName = "nil";
        searchOperationTableCount = 0;
        rowSearchOperationTable = 0;
        searchOperationTableCurrentRow = 0;
        
        lineageWindowOperation = 0;
        liveDisplayHold = 0;
        ifOneAllHold = -1;
        averageTotalSetHold = 0;
        blueLineDisplayHold = 0;
        lingLineWidthHold = 1;
        lineageOpen = 0;
        displayNameCellLing = "nil";
        displayNameTreatLing = "nil";
        displayNameSeriesLing = "nil";
        noOfChListStatus = 0;
        selectCurrentLineage = -1;
        lineageListCall = 0;
        
        growthCurveWindowOperation = 0;
        growthCurveCall = 0;
        growthCurveOpen = 0;
        
        cellDivisionWindowOperation = 0;
        cellDivisionCall = 0;
        cellDivisionOpen = 0;
        
        doublingTimeWindowOperation = 0;
        doublingTimeCall = 0;
        doublingTimeOpen = 0;
        
        progenyNoWindowOperation = 0;
        categoryResultsHoldStatus = 0;
        categoryRangeHoldStatus = 0;
        
        progenyAnalysisWindowOperation = 0;
        progenyAnalysisResultsHoldStatus = 0;
        progenyAnalysisRangeHoldStatus = 0;
        
        trimWindowOperation = 0;
        trimResultsHoldStatus = 0;
        mergeResultsHoldStatus = 0;
        trimOperationTableCount = 0;
        rowTrimOperationTable = 0;
        trimOperationTableCurrentRow = 0;
        mergeOperationTableCount = 0;
        rowMergeOperationTable = 0;
        mergeOperationTableCurrentRow = 0;
        trimCall = 0;
        trimOpen = 0;
        lineageCutStatusHold = 0;
        progenitorIncludeHold = 0;
        
        eventAnalysisResultsHoldStatus = 0;
        
        lineageSelectHoldStatus = 0;
        lineageSelectLineageHoldStatus = 0;
        lineageSelectOperationTableCount = 0;
        rowLineageSelectOperationTable = 0;
        lineageSelectOperationTableCurrentRow = 0;
        lineageSelectNonSelOperationTableCount = 0;
        rowLineageSelectNonOperationTable = 0;
        lineageSelectNonOperationTableCurrentRow = 0;
        lineageSelectSelOperationTableCount = 0;
        rowLineageSelectSelOperationTable = 0;
        lineageSelectSelOperationTableCurrentRow = 0;
        lineageSelectCall = 0;
        lineageSelectOpen = 0;
        
        mainWindowMagOperation = 0;
        mainWindowMagOpen = 0;
        drawingOptionHold = 0;
        unknownOptionHold = 0;
        unknownPriorityHold = 0;
        
        doubCompOperation = 0;
        progenyDoubleCompHoldStatus = 0;
        progenyDoubleCompResultsHoldStatus= 0;
        
        motilityResultsHoldStatus = 0;
        motilityOperation = 0;
        motilityOperationTableCount = 0;
        rowMotilityOperationTable = 0;
        motilityOperationTableCurrentRow = 0;
        activationStatus = 0;
        displayOptionStatus = 0;
        
        simulationOperation = 0;
        simColorDataHoldStatus = 0;
        simProcessDataHoldStatus = 0;
        simListHoldStatus = 0;
        simOperationTableCurrentRow = 0;
        fitDataHoldStatus = 0;
        processSimType = 0;
        simulationCall = 0;
        simulationOpen = 0;
        simulationDistributionDataStatus = 0;
        simulationFluorescentDataStatus = 0;
        performDataStatus = 0;
        terminateSimFlag = 0;
        terminateSimFlag2 = 0;
        backSaveOn = 0;
        backSaveOn2 = 0;
        simulationProgress = 0;
        processingStatusCall = 0;
        processingStatusCall2 = 0;
        processingStatusCall3 = 0;
        processingStatusCall4 = 0;
        messageStringSim = "nil";
        messageStringSim2 = "nil";
        messageStringSim3 = "nil";
        messageStringSim4 = "nil";
        cellGrowthCountTimeEnd = 0;
        timingSimCount = 0;
        movieDistanceSet = 0;
        movieDistanceHold = 1;
        movieDistanceHold2 = 0;
        movieDistanceHold3 = 0;
        movieDistanceTime2 = 0;
        movieDistanceTime3 = 0;
        movieDistanceRedStatus =0;
        circleSizeHold = 20;
        circleSizeRedStatus = 0;
        videoColorStatus = 0;
        doseSimStatusHold = 0;
        doseBaseHold = -1;
        doseMiddleHold = -1;
        doseTargetHold = -1;
        endVariationHold = 30;
        selectLingNoHold = 0;
        cellNoListForSelectLingCount = 0;
        lingSetDisplayCall = 0;
        lingNoAssignSimCount = 0;
        lingNoAssignSimStatus = 0;
        databaseLoadOptionHold = 0;
        circleMinHold = 20;
        simGraphModeHold = 0;
        titleFontExport = 1;
        videoImageSizeHold = 0;
        videoImageSizeOptionHold = 0;
        colorToneChangeTimeHold = 0;
        colorToneChangeOptionHold = 0;
        fluorescentSimSetNo = 0;
        fluorescentDropHold = 0;
        
        
        maxEntryNoList = 0;
        listEntryNoList = 0;
    }
    
    return self;
}

-(void)applicationDidFinishLaunching:(NSNotification*)notification{
    trackDataFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"07_Cell_Tracking_Data";
    analysisDataFolderPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"08_Cell_Tracking_Analysis_Data";
    string typeDefinitionPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/TypeDefinitionData";
    
    string getString;
    
    int terminationFlag = 0;
    int typeDefinitionEntry = 0;
    
    ifstream fin;
    
    fin.open(typeDefinitionPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            terminationFlag = 1;
            getline(fin, getString);
            
            if (getString == "") terminationFlag = 0;
            else{
                
                typeDefinitionEntry++;
                getline(fin, getString);
                typeDefinitionEntry++;
            }
            
        } while (terminationFlag == 1);
        
        fin.close();
    }
    
    arrayTypeDefinitionHold = new string [typeDefinitionEntry+50]; //----Hold Type Definition----
    typeDefinitionCount = 0;
    typeDefinitionLimit = typeDefinitionEntry+50;
    
    arrayTypeDefinitionHold2 = new string [typeDefinitionEntry+50]; //----Hold Type Definition----
    typeDefinitionCount2 = 0;
    typeDefinitionLimit2 = typeDefinitionEntry+50;
    
    for (int counter1 = 0; counter1 < typeDefinitionEntry+50; counter1++){
        arrayTypeDefinitionHold [counter1] = "nil";
        arrayTypeDefinitionHold2 [counter1] = "nil";
    }
    
    fin.open(typeDefinitionPath.c_str(), ios::in);
    
    if (fin.is_open()){
        do{
            
            terminationFlag = 1;
            getline(fin, getString);
            
            if (getString == "") terminationFlag = 0;
            else{
                
                typeDefinitionEntry++;
                arrayTypeDefinitionHold [typeDefinitionCount] = getString, typeDefinitionCount++;
                arrayTypeDefinitionHold2 [typeDefinitionCount2] = getString, typeDefinitionCount2++;
                getline(fin, getString);
                arrayTypeDefinitionHold [typeDefinitionCount] = getString, typeDefinitionCount++;
                arrayTypeDefinitionHold2 [typeDefinitionCount2] = getString, typeDefinitionCount2++;
                typeDefinitionEntry++;
            }
            
        } while (terminationFlag == 1);
        
        fin.close();
    }
    else{
        
        arrayTypeDefinitionHold [0] = "SO";
        arrayTypeDefinitionHold [1] = "Source";
        arrayTypeDefinitionHold [2] = "AN";
        arrayTypeDefinitionHold [3] = "Analysis";
        arrayTypeDefinitionHold [4] = "SE";
        arrayTypeDefinitionHold [5] = "Search";
        arrayTypeDefinitionHold [6] = "LN";
        arrayTypeDefinitionHold [7] = "Lineage list";
    }
    
    arrayColorRange = new CGFloat [150];
    arrayColorRange [0] = 16/(double)255, arrayColorRange [1] = 22/(double)255, arrayColorRange [2] = 255/(double)255;
    arrayColorRange [3] = 31/(double)255, arrayColorRange [4] = 49/(double)255, arrayColorRange [5] = 237/(double)255;
    arrayColorRange [6] = 54/(double)255, arrayColorRange [7] = 88/(double)255, arrayColorRange [8] = 255/(double)255;
    arrayColorRange [9] = 43/(double)255, arrayColorRange [10] = 136/(double)255, arrayColorRange [11] = 255/(double)255;
    arrayColorRange [12] = 65/(double)255, arrayColorRange [13] = 178/(double)255, arrayColorRange [14] = 236/(double)255;
    arrayColorRange [15] = 77/(double)255, arrayColorRange [16] = 228/(double)255, arrayColorRange [17] = 249/(double)255;
    arrayColorRange [18] = 109/(double)255, arrayColorRange [19] = 250/(double)255, arrayColorRange [20] = 234/(double)255;
    arrayColorRange [21] = 104/(double)255, arrayColorRange [22] = 250/(double)255, arrayColorRange [23] = 203/(double)255;
    arrayColorRange [24] = 105/(double)255, arrayColorRange [25] = 247/(double)255, arrayColorRange [26] = 175/(double)255;
    arrayColorRange [27] = 104/(double)255, arrayColorRange [28] = 242/(double)255, arrayColorRange [29] = 119/(double)255;
    arrayColorRange [30] = 102/(double)255, arrayColorRange [31] = 242/(double)255, arrayColorRange [32] = 93/(double)255;
    arrayColorRange [33] = 108/(double)255, arrayColorRange [34] = 244/(double)255, arrayColorRange [35] = 58/(double)255;
    arrayColorRange [36] = 120/(double)255, arrayColorRange [37] = 242/(double)255, arrayColorRange [38] = 33/(double)255;
    arrayColorRange [39] = 110/(double)255, arrayColorRange [40] = 250/(double)255, arrayColorRange [41] = 53/(double)255;
    arrayColorRange [42] = 132/(double)255, arrayColorRange [43] = 255/(double)255, arrayColorRange [44] = 43/(double)255;
    arrayColorRange [45] = 166/(double)255, arrayColorRange [46] = 254/(double)255, arrayColorRange [47] = 46/(double)255;
    arrayColorRange [48] = 199/(double)255, arrayColorRange [49] = 255/(double)255, arrayColorRange [50] = 72/(double)255;
    arrayColorRange [51] = 244/(double)255, arrayColorRange [52] = 251/(double)255, arrayColorRange [53] = 51/(double)255;
    arrayColorRange [54] = 234/(double)255, arrayColorRange [55] = 225/(double)255, arrayColorRange [56] = 58/(double)255;
    arrayColorRange [57] = 234/(double)255, arrayColorRange [58] = 185/(double)255, arrayColorRange [59] = 44/(double)255;
    arrayColorRange [60] = 240/(double)255, arrayColorRange [61] = 136/(double)255, arrayColorRange [62] = 39/(double)255;
    arrayColorRange [63] = 229/(double)255, arrayColorRange [64] = 93/(double)255, arrayColorRange [65] = 41/(double)255;
    arrayColorRange [66] = 222/(double)255, arrayColorRange [67] = 64/(double)255, arrayColorRange [68] = 25/(double)255;
    arrayColorRange [69] = 246/(double)255, arrayColorRange [70] = 20/(double)255, arrayColorRange [71] = 40/(double)255;
    
    arrayColorRange [72] = 255/(double)255, arrayColorRange [73] = 0/(double)255, arrayColorRange [74] = 0/(double)255;
    arrayColorRange [75] = 255/(double)255, arrayColorRange [76] = 96/(double)255, arrayColorRange [77] = 208/(double)255;
    arrayColorRange [78] = 160/(double)255, arrayColorRange [79] = 32/(double)255, arrayColorRange [80] = 55/(double)255;
    arrayColorRange [81] = 80/(double)255, arrayColorRange [82] = 208/(double)255, arrayColorRange [83] = 255/(double)255;
    arrayColorRange [84] = 0/(double)255, arrayColorRange [85] = 32/(double)255, arrayColorRange [86] = 255/(double)255;
    arrayColorRange [87] = 96/(double)255, arrayColorRange [88] = 255/(double)255, arrayColorRange [89] = 128/(double)255;
    arrayColorRange [90] = 0/(double)255, arrayColorRange [91] = 192/(double)255, arrayColorRange [92] = 0/(double)255;
    arrayColorRange [93] = 255/(double)255, arrayColorRange [94] = 224/(double)255, arrayColorRange [95] = 32/(double)255;
    arrayColorRange [96] = 255/(double)255, arrayColorRange [97] = 160/(double)255, arrayColorRange [98] = 16/(double)255;
    arrayColorRange [99] = 160/(double)255, arrayColorRange [100] = 128/(double)255, arrayColorRange [101] = 96/(double)255;
    arrayColorRange [102] = 255/(double)255, arrayColorRange [103] = 208/(double)255, arrayColorRange [104] = 160/(double)255;
    arrayColorRange [105] = 0/(double)255, arrayColorRange [106] = 0/(double)255, arrayColorRange [107] = 0/(double)255;
    
    arrayColorRange2 = new CGFloat [150];
    arrayColorRange2 [0] = 0/(double)255, arrayColorRange2 [1] = 0/(double)255, arrayColorRange2 [2] = 0/(double)255;
    arrayColorRange2 [3] = 88/(double)255, arrayColorRange2 [4] = 88/(double)255, arrayColorRange2 [5] = 88/(double)255;
    arrayColorRange2 [6] = 139/(double)255, arrayColorRange2 [7] = 139/(double)255, arrayColorRange2 [8] = 139/(double)255;
    arrayColorRange2 [9] = 199/(double)255, arrayColorRange2 [10] = 199/(double)255, arrayColorRange2 [11] = 199/(double)255;
    arrayColorRange2 [12] = 225/(double)255, arrayColorRange2 [13] = 225/(double)255, arrayColorRange2 [14] = 225/(double)255;
    arrayColorRange2 [15] = 0/(double)255, arrayColorRange2 [16] = 46/(double)255, arrayColorRange2 [17] = 238/(double)255;
    arrayColorRange2 [18] = 159/(double)255, arrayColorRange2 [19] = 113/(double)255, arrayColorRange2 [20] = 61/(double)255;
    arrayColorRange2 [21] = 0/(double)255, arrayColorRange2 [22] = 238/(double)255, arrayColorRange2 [23] = 238/(double)255;
    arrayColorRange2 [24] = 0/(double)255, arrayColorRange2 [25] = 238/(double)255, arrayColorRange2 [26] = 0/(double)255;
    arrayColorRange2 [27] = 238/(double)255, arrayColorRange2 [28] = 60/(double)255, arrayColorRange2 [29] = 238/(double)255;
    arrayColorRange2 [30] = 238/(double)255, arrayColorRange2 [31] = 132/(double)255, arrayColorRange2 [32] = 0/(double)255;
    arrayColorRange2 [33] = 141/(double)255, arrayColorRange2 [34] = 30/(double)255, arrayColorRange2 [35] = 141/(double)255;
    arrayColorRange2 [36] = 238/(double)255, arrayColorRange2 [37] = 0/(double)255, arrayColorRange2 [38] = 0/(double)255;
    arrayColorRange2 [39] = 241/(double)255, arrayColorRange2 [40] = 241/(double)255, arrayColorRange2 [41] = 0/(double)255;
    arrayColorRange2 [42] = 140/(double)255, arrayColorRange2 [43] = 21/(double)255, arrayColorRange2 [44] = 77/(double)255;
    arrayColorRange2 [45] = 241/(double)255, arrayColorRange2 [46] = 44/(double)255, arrayColorRange2 [47] = 137/(double)255;
    
    arrayFileDelete = new string [100];
    fileDeleteCount = 0;
    fileDeleteLimit = 100;
    
    arrayLineageExtract = new int [500];
    lineageExtractCount = 0;
    lineageExtractLimit = 500;
    
    arrayLineageLinkList = new int [1000];
    lineageLinkListCount = 0;
    lineageLinkListLimit = 1000;
    lineageLinkListLength = 4;
    
    arrayLineageLinkListLGL = new int [1000];
    lineageLinkListLGLCount = 0;
    lineageLinkListLGLLimit = 1000;
    lineageLinkListLGLLength = 4;
    
    ifDataExtract = new int [100];
    ifDataExtractCount = 0;
    ifDataExtractLimit = 100;
    
    ifValueExtract = new int [100];
    ifValueExtractCount = 0;
    ifValueExtractLimit = 100;
    
    ifTimeExtract = new int [100];
    ifTimeExtractCount = 0;
    ifTimeExtractLimit = 100;
    
    areaExtract = new int [100];
    areaExtractCount = 0;
    areaExtractLimit = 100;
    
    [sourceStatus setStringValue:@"Analysis"];
    [listBrowser reloadColumn:1];
    
    setStatus2 = 1;
    
    timerLA = [NSTimer scheduledTimerWithTimeInterval:0.1 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [controller frame];
    
    CGFloat windowHeight = windowSize.size.height;
    CGFloat displayX = 20;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    [controller setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [listBrowser setTarget:self];
    [listBrowser setDoubleAction:@selector(browserDoubleClick:)];
    [tableViewList setDataSource:self];
    
    [progressIndicator startAnimation:self];
    [progressIndicator setHidden:YES];
}

-(void)display{
    if (tableViewCall == 1){
        tableViewCall = 0;
        [tableViewList reloadData];
    }
    
    //----Table View for controller----
    if (setStatus2 == 1){
        setStatus2 = 0;
        [listBrowser reloadColumn:0];
    }
    
    if (tableCallCount == 1){
        tableCallCount = 0;
        rowIndexHold = tableCurrentRowHold;
    }
    
    if (tableCallCount > 1) tableCallCount = 0;
    
    //----Progress indicator----
    if (progressTiming == 1){
        [progressIndicator setMinValue:0];
        [progressIndicator setMaxValue:progressValue];
        [progressIndicator startAnimation:self];
        [progressIndicator setHidden:NO];
        
        double bValue = [progressIndicator maxValue];
        
        if (progressIndicator){
            if (bValue == progressValue){
                progressTiming = 2;
            }
        }
    }
    else if (progressTiming == 3){
        [progressIndicator setDoubleValue:progressValue];
        [progressIndicator displayIfNeeded];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == progressValue){
            progressTiming = 4;
        }
    }
    else if (progressTiming == 5){
        [progressIndicator setDoubleValue:0];
        [progressIndicator displayIfNeeded];
        [progressIndicator stopAnimation:self];
        [progressIndicator setHidden:YES];
        
        double bValue = [progressIndicator doubleValue];
        
        if (bValue == 0){
            progressTiming = 0;
        }
    }
    
    //----Send up-dated data to Main image etc----
    if (upLoadingFlag == 1){
        upLoadingFlag = 0;
        
        tableViewCall = 1;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
        
        if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
    }
    
    //----Table View for search----
    if (searchOperationTableCount == 1){
        searchOperationTableCount = 0;
        rowSearchOperationTable = searchOperationTableCurrentRow;
    }
    
    if (searchOperationTableCount > 1) searchOperationTableCount = 0;
    
    if (lineageListCall == 1){
        lineageListCall = 0;
        selectCurrentLineage = -1;
        saveFlag = 0;
        
        lingNo1 = -1;
        lingNo2 = -1;
        lingNo3 = -1;
        lingNo4 = -1;
        lingNo5 = -1;
        lingNo6 = -1;
        lingNo7 = -1;
        lingNo8 = -1;
        
        chNo1 = 1;
        siblingLingHold = 0;
        colorOptionLingHold = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (arraySelectedLing [counter1] == 1){
                selectCurrentLineage = counter1;
                break;
            }
        }
        
        if (selectCurrentLineage != -1){
            typeLing = arrayTableMain [selectCurrentLineage][1];
            seriesLing = arrayTableMain [selectCurrentLineage][2];
            analysisLing = arrayTableMain [selectCurrentLineage][3];
            treatLing = arrayTableMain [selectCurrentLineage][4];
            
            if (typeLing != "LN"){
                displayNameTreatLing = "nil";
            }
            else{
                
                string lineageKListPath = analysisDataFolderPath+"/"+seriesLing+"_AnalysisResults"+"/"+analysisLing+"_IDResults/"+treatLing+"_Results/"+"DisplayNames";
                string getString;
                
                ifstream fin;
                
                fin.open(lineageKListPath.c_str(), ios::in);
                
                if (fin.is_open()){
                    getline(fin, getString);
                    if (getString != "nil" && displayNameCellLing == "nil") displayNameCellLing = getString;
                    
                    getline(fin, getString);
                    
                    if (getString != "nil") displayNameTreatLing = getString;
                    else displayNameTreatLing = "nil";
                    
                    fin.close();
                }
            }
            
            liveDisplayHold = 0;
            
            int ifNoOfEntry = atoi(arrayTableMain [selectCurrentLineage][9].c_str());
            
            ifOneAllHold = -1;
            
            if (arrayTableDetail [selectCurrentLineage][4] != 0){
                ifRangeLing = to_string(arrayTableDetail [selectCurrentLineage][4])+"-"+to_string(arrayTableDetail [selectCurrentLineage][5]);
                
                ifRangeHigh = arrayTableDetail [selectCurrentLineage][5];
                ifRangeLow = arrayTableDetail [selectCurrentLineage][4];
            }
            else{
                
                ifRangeLing = "nil-nil";
                ifRangeHigh = 0;
                ifRangeLow = 0;
            }
            
            if (noOfChListStatus == 0){
                arrayNoOfChList = new int [ifNoOfEntry*2+10];
                noOfChListStatus = 1;
                noOfChListCount = 0;
            }
            else{
                
                delete [] arrayNoOfChList;
                arrayNoOfChList = new int [ifNoOfEntry*2+10];
                noOfChListStatus = 1;
                noOfChListCount = 0;
            }
            
            for (int counter1 = 0; counter1 < arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9; counter1++){
                if (arrayIFTimeLineData [selectCurrentLineage][counter1*9+2] != 0 && arrayIFTimeLineData [selectCurrentLineage][counter1*9+1] >= 1){
                    for (int counter2 = 0; counter2 < arrayIfTimeStatusHold [selectCurrentLineage]/2; counter2++){
                        if (arrayIFTimeLineData [selectCurrentLineage][counter1*9] == arrayIfTimeStatus [selectCurrentLineage][counter2*2] && arrayIfTimeStatus [selectCurrentLineage][counter2*2+1] == 0){
                            arrayNoOfChList [noOfChListCount] = arrayIfTimeStatus [selectCurrentLineage][counter2*2], noOfChListCount++;
                            arrayNoOfChList [noOfChListCount] = arrayIFTimeLineData [selectCurrentLineage][counter1*9+2], noOfChListCount++;
                        }
                    }
                }
            }
            
            lineageCurrentPosition = 1;
            int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
            
            for (int counter1 = 1; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                    lineageCurrentPosition = counter1;
                    break;
                }
            }
            
            lineageCurrentPositionHold = lineageCurrentPosition;
            
            int displayCount = 0;
            int lastCounterPosition = -1;
            
            for (int counter1 = 1; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                    lastCounterPosition = counter1;
                    
                    if (displayCount == 0) lingNo1 = counter1, displayCount++;
                    else if (displayCount == 1) lingNo2 = counter1, displayCount++;
                    else if (displayCount == 2) lingNo3 = counter1, displayCount++;
                    else if (displayCount == 3) lingNo4 = counter1, displayCount++;
                    else if (displayCount == 4) lingNo5 = counter1, displayCount++;
                    else if (displayCount == 5) lingNo6 = counter1, displayCount++;
                    else if (displayCount == 6) lingNo7 = counter1, displayCount++;
                    else if (displayCount == 7){
                        lingNo8 = counter1;
                        displayCount++;
                        break;
                    }
                }
            }
            
            if (lastCounterPosition != -1) lineageCurrentPosition = lastCounterPosition;
            
            int maxLingNoTemp = 0;
            
            for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [selectCurrentLineage]/9; counter1++){
                if (maxLingNoTemp < arrayLineageData [selectCurrentLineage][counter1*9+6]) maxLingNoTemp = arrayLineageData [selectCurrentLineage][counter1*9+6];
            }
            
            lineageLinkListLGLLength = arrayLineageLink [selectCurrentLineage][0];
            
            delete [] arrayLineageLinkListLGL;
            arrayLineageLinkListLGL = new int [(maxLingNoTemp+1)*lineageLinkListLGLLength+11];
            lineageLinkListLGLCount = 0;
            lineageLinkListLGLLimit = (maxLingNoTemp+1)*lineageLinkListLGLLength+11;
            
            for (int counter1 = 0; counter1 < (maxLingNoTemp+1)*lineageLinkListLGLLength+11; counter1++) arrayLineageLinkListLGL [counter1] = 0;
            
            for (int counter1 = 0; counter1 < lineageLinkHold [selectCurrentLineage]; counter1++){
                arrayLineageLinkListLGL [lineageLinkListLGLCount] = arrayLineageLink [selectCurrentLineage][counter1], lineageLinkListLGLCount++;
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageListCondition object:self];
        }
    }
    
    if (growthCurveCall == 1){
        growthCurveCall = 0;
        
        int timeMax = 0;
        int maxEntry = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (arraySelectedLing [counter1] == 1 && maxEntry < 32){
                if (timeMax < arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str())){
                    timeMax = arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str());
                    maxEntry++;
                }
            }
        }
        
        if (timeMax != 0 && normalizeStatusHold == 0){
            verticalScaleLowHold = 0;
            verticalScaleHighHold = 0;
            horizontalScaleLowHold = 0;
            horizontalScaleHighHold = 0;
            
            horizontalScaleMaxHold = timeMax+50;
            horizontalScaleHighHold = horizontalScaleMaxHold;
            
            int *cellNumberHold = new int [horizontalScaleHighHold+50];
            int actualTime = 0;
            int maxCellNo = 0;
            int timeEnd = 0;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    for (int counter3 = 0; counter3 < horizontalScaleHighHold+50; counter3++){
                        cellNumberHold [counter3] = 0;
                    }
                    
                    timeEnd = arrayTableDetail [counter2][3];
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        actualTime = arrayLineageData [counter2][counter3*9+2]*atoi(arrayLineageDataType [counter2][5].c_str());
                        
                        if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                            cellNumberHold [actualTime]++;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < horizontalScaleHighHold+50; counter3++){
                        if (cellNumberHold [counter3] > maxCellNo) maxCellNo = cellNumberHold [counter3] ;
                    }
                }
            }
            
            delete [] cellNumberHold;
            
            if (maxCellNo < 100) verticalScaleMaxHold = 500;
            else verticalScaleMaxHold = maxCellNo+50;
            
            verticalScaleHighHold = verticalScaleMaxHold;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToGrowthCurveAddition object:self];
        }
    }
    
    if (cellDivisionCall == 1){
        cellDivisionCall = 0;
        
        horizontalScaleLowDivisionHold = 0;
        horizontalScaleHighDivisionHold = 0;
        verticalScaleHighUpDivisionHold = 0;
        verticalScaleHighDownDivisionHold = 0;
        maxDDNumberHold = 0;
        maxOtherHold = 0;
        
        int timeMax = 0;
        int maxEntry = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (arraySelectedLing [counter1] == 1 && maxEntry < 8){
                if (timeMax < arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str())){
                    timeMax = arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str());
                    maxEntry++;
                }
            }
        }
        
        if (timeMax != 0){
            horizontalScaleMaxDivisionHold = timeMax+50;
            horizontalScaleHighDivisionHold = horizontalScaleMaxDivisionHold;
            
            int *cellNumberHold = new int [horizontalScaleHighDivisionHold+50];
            int *cellNumberHold2 = new int [horizontalScaleHighDivisionHold+50];
            int actualTime = 0;
            int maxCellNoDD = 0;
            int maxCellNoOther = 0;
            int timeEnd = 0;
            maxEntry = 0;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 8){
                    for (int counter3 = 0; counter3 < horizontalScaleHighDivisionHold+50; counter3++){
                        cellNumberHold [counter3] = 0;
                        cellNumberHold2 [counter3] = 0;
                    }
                    
                    timeEnd = arrayTableDetail [counter2][3];
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        actualTime = arrayLineageData [counter2][counter3*9+2]*atoi(arrayLineageDataType [counter2][5].c_str());
                        
                        if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                            if (arrayLineageData [counter2][counter3*9+3] == 31){
                                cellNumberHold [actualTime]++;
                            }
                            
                            if (arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51 || arrayLineageData [counter2][counter3*9+3] == 7 || arrayLineageData [counter2][counter3*9+3] == 91){
                                cellNumberHold2 [actualTime]++;
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < horizontalScaleHighDivisionHold+50; counter3++){
                        if (cellNumberHold [counter3] > maxCellNoDD) maxCellNoDD = cellNumberHold [counter3];
                        if (cellNumberHold2 [counter3] > maxCellNoOther) maxCellNoOther = cellNumberHold2 [counter3];
                    }
                }
            }
            
            delete [] cellNumberHold;
            delete [] cellNumberHold2;
            
            if (maxCellNoDD < 20) maxDDNumberHold = 20;
            else maxDDNumberHold = maxCellNoDD+10;
            
            if (maxCellNoOther < 10) maxOtherHold = 10;
            else maxOtherHold = maxCellNoOther+10;
            
            verticalScaleMaxUpDivisionHold = maxDDNumberHold;
            verticalScaleHighUpDivisionHold = verticalScaleMaxUpDivisionHold;
            
            verticalScaleMaxDownDivisionHold = maxOtherHold;
            verticalScaleHighDownDivisionHold = verticalScaleMaxDownDivisionHold;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellDivisionAddition object:self];
        }
    }
    
    if (doublingTimeCall == 1){
        doublingTimeCall = 0;
        
        horizontalScaleLowDoublingTimeHold = 0;
        horizontalScaleHighDoublingTimeHold = 0;
        verticalScaleHighDoublingHold = 0;
        
        int timeMax = 0;
        int maxEntry = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (arraySelectedLing [counter1] == 1 && maxEntry < 12){
                if (timeMax < arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str())){
                    timeMax = arrayTableDetail [counter1][3]*atoi(arrayLineageDataType [counter1][5].c_str());
                    maxEntry++;
                }
            }
        }
        
        int *cellNumberHold = new int [timeMax+50];
        int endTime = 0;
        maxEntry = 0;
        
        int maxTimeSet = 0;
        int maxTimeSetHold = 0;
        int maxEntrySet = 0;
        int maxEntrySetHold = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1 && maxEntry < 12){
                for (int counter3 = 0; counter3 < timeMax+50; counter3++){
                    cellNumberHold [counter3] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51){
                        endTime = 0;
                        
                        for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                            if (arrayLineageData [counter2][counter3*9+5] == arrayLineageData [counter2][counter4*9+5] && arrayLineageData [counter2][counter3*9+6] == arrayLineageData [counter2][counter4*9+6] && (arrayLineageData [counter2][counter4*9+3] == 32 || arrayLineageData [counter2][counter4*9+3] == 42 || arrayLineageData [counter2][counter4*9+3] == 52)){
                                endTime = arrayLineageData [counter2][counter4*9+2];
                            }
                            else if (arrayLineageData [counter2][counter3*9+5] != arrayLineageData [counter2][counter4*9+5] || arrayLineageData [counter2][counter3*9+6] != arrayLineageData [counter2][counter4*9+6]){
                                break;
                            }
                        }
                        
                        if (endTime != 0){
                            cellNumberHold [(endTime-arrayLineageData [counter2][counter3*9+2])*atoi(arrayLineageDataType [counter2][5].c_str())]++;
                        }
                    }
                }
                
                for (int counter3 = timeMax; counter3 > 0; counter3--){
                    if (cellNumberHold [counter3] != 0){
                        maxTimeSet = counter3;
                        break;
                    }
                }
                
                if (maxTimeSet > maxTimeSetHold) maxTimeSetHold = maxTimeSet;
                
                maxEntrySet = 0;
                
                for (int counter3 = 0; counter3 <= timeMax; counter3++){
                    if (cellNumberHold [counter3] > maxEntrySet){
                        maxEntrySet = cellNumberHold [counter3];
                    }
                }
                
                if (maxEntrySet > maxEntrySetHold) maxEntrySetHold = maxEntrySet;
                
                maxEntry++;
            }
        }
        
        horizontalScaleMaxDoublingTimeHold = maxTimeSetHold+50;
        horizontalScaleHighDoublingTimeHold = maxTimeSetHold+50;
        verticalScaleMaxDoublingTimeHold = maxEntrySetHold+10;
        verticalScaleHighDoublingHold = maxEntrySetHold+10;
        
        delete [] cellNumberHold;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoublingTimeAddition object:self];
    }
    
    //----Trim call----
    if (trimCall == 1){
        trimCall = 0;
        
        trimResultsHoldCount = 0;
        mergeResultsHoldCount = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][1], trimResultsHoldCount++;
            arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][2], trimResultsHoldCount++;
            arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][3], trimResultsHoldCount++;
            arrayTrimResultsHold [trimResultsHoldCount] = arrayTableMain [counter2][4], trimResultsHoldCount++;
            arrayTrimResultsHold [trimResultsHoldCount] = to_string(arrayTableDetail [counter2][3]), trimResultsHoldCount++;
            arrayTrimResultsHold [trimResultsHoldCount] = "", trimResultsHoldCount++;
            
            arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][1], mergeResultsHoldCount++;
            arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][2], mergeResultsHoldCount++;
            arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][3], mergeResultsHoldCount++;
            arrayMergeResultsHold [mergeResultsHoldCount] = arrayTableMain [counter2][4], mergeResultsHoldCount++;
            arrayMergeResultsHold [mergeResultsHoldCount] = to_string(arrayTableDetail [counter2][3]), mergeResultsHoldCount++;
            arrayMergeResultsHold [mergeResultsHoldCount] = "", mergeResultsHoldCount++;
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrimTable object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTrimTable2 object:self];
    }
    
    //----Trim table----
    if (trimOperationTableCount == 1){
        trimOperationTableCount = 0;
        rowTrimOperationTable = trimOperationTableCurrentRow;
    }
    
    if (trimOperationTableCount > 1) trimOperationTableCount = 0;
    
    //----Merge Table----
    if (mergeOperationTableCount == 1){
        mergeOperationTableCount = 0;
        mergeOperationTableCurrentRow = mergeOperationTableCurrentRow;
    }
    
    if (mergeOperationTableCount > 1) mergeOperationTableCount = 0;
    
    //----Ling select table----
    if (lineageSelectOperationTableCount == 1){
        lineageSelectOperationTableCount = 0;
        rowLineageSelectOperationTable = lineageSelectOperationTableCurrentRow;
    }
    
    if (lineageSelectOperationTableCount > 1) lineageSelectOperationTableCount = 0;
    
    //----Ling select non selected table----
    if (lineageSelectNonSelOperationTableCount == 1){
        lineageSelectNonSelOperationTableCount = 0;
        rowLineageSelectNonOperationTable = lineageSelectNonOperationTableCurrentRow;
    }
    
    if (lineageSelectNonSelOperationTableCount > 1) lineageSelectNonSelOperationTableCount = 0;
    
    //----Ling select selected table----
    if (lineageSelectSelOperationTableCount == 1){
        lineageSelectSelOperationTableCount = 0;
        rowLineageSelectSelOperationTable = lineageSelectSelOperationTableCurrentRow;
    }
    
    if (lineageSelectSelOperationTableCount > 1) lineageSelectSelOperationTableCount = 0;
    
    //----Motility table----
    if (motilityOperationTableCount == 1){
        motilityOperationTableCount = 0;
        rowMotilityOperationTable = motilityOperationTableCurrentRow;
    }
    
    if (trimOperationTableCount > 1) trimOperationTableCount = 0;
    
    //----Lineage select call----
    if (lineageSelectCall == 1){
        lineageSelectCall = 0;
        
        lineageSelectHoldCount = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][1], lineageSelectHoldCount++;
            arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][2], lineageSelectHoldCount++;
            arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][3], lineageSelectHoldCount++;
            arrayLineageSelectHold [lineageSelectHoldCount] = arrayTableMain [counter2][4], lineageSelectHoldCount++;
        }
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
    }
    
    if (exportTiming == 101){
        exportTiming = 102;
        
        [backSave startAnimation:self];
        
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Map";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
        string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
        string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
        string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-LMALL";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("LMALL")+5);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string path = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Map/"+nameString+to_string(maxEntryNo);
        mkdir(path.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        lineageCurrentPosition = 0;
        listEntryNo = 1;
        exportTiming = 103;
    }
    else if (exportTiming >= 103 && exportTiming < 110){
        exportTiming++;
    }
    else if (exportTiming == 110){
        exportTiming = 111;
        exportFlag1 = 1;
        
        string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
        string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
        string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
        string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-LMALL";
        string path = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Map/"+nameString+to_string(maxEntryNo);
        
        int proceedFlag = 0;
        int extractCount = 0;
        int lineageNoFind = 0;
        int matchFind = 0;
        int ifEntryCount = 0;
        int areaEntryCount = 0;
        
        proceedFlag = 0;
        
        for (int counter1 = lineageDisplayPosition+1; counter1 <= maxLingNo; counter1++){
            if (arrayLineageLinkList [counter1*lineageLinkListLength] > 0){
                lineageDisplayPosition = counter1;
                proceedFlag = 1;
                break;
            }
        }
        
        if (proceedFlag == 1){
            extractCount = 0;
            
            int *lineageSelect = new int [lineageLinkListLength+5];
            
            lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength];
            extractCount++;
            
            for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                if (arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2] != 0){
                    lineageSelect [extractCount] = arrayLineageLinkList [lineageDisplayPosition*lineageLinkListLength+counter2];
                    extractCount++;
                }
            }
            
            matchFind = 0;
            
            for (int counter1 = 0; counter1 < extractCount; counter1++){
                lineageNoFind = lineageSelect [counter1];
                
                for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                    if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                        matchFind = 1;
                    }
                }
            }
            
            if (matchFind == 1){
                lineageExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
                        if (holdReviseLineage [counter2*9+6] == lineageNoFind){
                            if (lineageExtractCount+10 > lineageExtractLimit){
                                int *arrayUpDate = new int [lineageExtractCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                
                                delete [] arrayLineageExtract;
                                lineageExtractLimit = lineageExtractCount+(unsigned long)holdReviseLineageCount+5000;
                                arrayLineageExtract = new int [lineageExtractLimit];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+1], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+2], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+3], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+4], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+5], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+6], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+7], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = holdReviseLineage [counter2*9+8], lineageExtractCount++;
                        }
                    }
                }
                
                ifValueExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < holdReviseIfDataCount/22; counter2++){
                        if (holdReviseIfData [counter2*22+1] == lineageNoFind){
                            if (ifValueExtractCount+50 > ifValueExtractLimit){
                                int *arrayUpDate = new int [ifValueExtractCount+20];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                
                                delete [] ifValueExtract;
                                ifValueExtractLimit = ifValueExtractCount+5000;
                                ifValueExtract = new int [ifValueExtractLimit];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+1], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+2], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+3], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+4], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+5], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+6], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+7], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+8], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+9], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+10], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+11], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+12], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+13], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+14], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+15], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+16], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+17], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+18], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+19], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+20], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = holdReviseIfData [counter2*22+21], ifValueExtractCount++;
                        }
                    }
                }
                
                areaExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < holdReviseAreaDataCount/5; counter2++){
                        if (holdReviseAreaData [counter2*5] == lineageNoFind){
                            if (areaExtractCount+10 > areaExtractLimit){
                                int *arrayUpDate = new int [areaExtractCount+10];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                
                                delete [] areaExtract;
                                areaExtractLimit = areaExtractCount+5000;
                                areaExtract = new int [areaExtractLimit];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5], areaExtractCount++;
                            areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+1], areaExtractCount++;
                            areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+2], areaExtractCount++;
                            areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+3], areaExtractCount++;
                            areaExtract [areaExtractCount] = holdReviseAreaData [counter2*5+4], areaExtractCount++;
                        }
                    }
                }
            }
            else{
                
                lineageExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter2++){
                        if (arrayLineageData [tableCurrentRowHold][counter2*9+6] == lineageNoFind){
                            if (lineageExtractCount+10 > lineageExtractLimit){
                                int *arrayUpDate = new int [lineageExtractCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                
                                delete [] arrayLineageExtract;
                                lineageExtractLimit = lineageExtractCount+arrayLineageDataEntryHold [tableCurrentRowHold]+5000;
                                arrayLineageExtract = new int [lineageExtractLimit];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+1], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+2], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+3], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+4], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+5], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+6], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+7], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+8], lineageExtractCount++;
                        }
                    }
                }
                
                //========Load IF data========
                ifEntryCount = arrayIFDataEntryHold [tableCurrentRowHold];
                
                ifValueExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < ifEntryCount/22; counter2++){
                        if (arrayIFData [tableCurrentRowHold][counter2*22+1] == lineageNoFind){
                            if (ifValueExtractCount+50 > ifValueExtractLimit){
                                int *arrayUpDate = new int [ifValueExtractCount+40];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                
                                delete [] ifValueExtract;
                                ifValueExtractLimit = ifValueExtractCount+5000;
                                ifValueExtract = new int [ifValueExtractLimit];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+1], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+2], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+3], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+4], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+5], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+6], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+7], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+8], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+9], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+10], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+11], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+12], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+13], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+14], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+15], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+17], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+18], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+19], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+20], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+21], ifValueExtractCount++;
                        }
                    }
                }
                
                //**********arrayAreaData**********
                areaEntryCount = arrayAreaDataHold [tableCurrentRowHold];
                
                areaExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < areaEntryCount/5; counter2++){
                        if (arrayAreaData [tableCurrentRowHold][counter2*5] == lineageNoFind){
                            if (areaExtractCount+10 > areaExtractLimit){
                                int *arrayUpDate = new int [areaExtractCount+10];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                
                                delete [] areaExtract;
                                areaExtractLimit = areaExtractCount+5000;
                                areaExtract = new int [areaExtractLimit];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+1], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+2], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+3], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+4], areaExtractCount++;
                        }
                    }
                }
            }
            
            delete [] lineageSelect;
            
            exportResultPath = path +"/"+nameString+to_string(listEntryNo)+".tif";
            
            listEntryNo++;
            
            exportTiming = 112;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
        }
        else exportTiming = 150;
    }
    else if (exportTiming >= 113 && exportTiming < 120){
        exportTiming++;
    }
    else if (exportTiming == 120){
        exportTiming = 121;
    }
    else if (exportTiming == 121){
        exportTiming = 110;
    }
    else if (exportTiming == 150){
        exportTiming = 0;
        exportFlag1 = 2;
        
        [backSave stopAnimation:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    
    if (simulationCall == 1){
        simulationCall = 2;
        simListHoldCount = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            arraySimListHold [simListHoldCount] = arrayTableMain [counter2][3], simListHoldCount++;
            arraySimListHold [simListHoldCount] = arrayTableMain [counter2][4], simListHoldCount++;
        }
        
        simOperationTableCurrentRow = lineageDataEntryCount-1;
        
        simulationCall = 3;
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSimulationTable object:nil];
    }
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0){
        if (sourceStatusHold == 0){
            dir = opendir(trackDataFolderPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Series") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            
                            entry = entry.substr(0, entry.find("_Series"));
                            arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
        else if (sourceStatusHold == 1){
            dir = opendir(analysisDataFolderPath.c_str());
            
            if (dir != NULL){
                string entry;
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_AnalysisResults") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            
                            entry = entry.substr(0, entry.find("_AnalysisResults"));
                            arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
        else if (sourceStatusHold == 2){
            if (lineageDataEntryCount != 0){
                if (arrayTableMain [tableCurrentRowHold][5] != "0"){
                    if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                    arrayDirectoryInfo [directoryInfoCount] = "Live", directoryInfoCount++;
                }
                
                if (arrayTableMain [tableCurrentRowHold][12] != "0"){
                    int noOfEntry = atoi(arrayTableMain [tableCurrentRowHold][12].c_str());
                    
                    for (int counter1 = 0; counter1 < noOfEntry; counter1++){
                        if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                        
                        arrayDirectoryInfo [directoryInfoCount] = "Round "+to_string(counter1+1), directoryInfoCount++;
                    }
                }
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        if (sourceStatusHold == 0){
            string imageFolderPath = trackDataFolderPath+[path UTF8String]+"_Series";
            string imageFolderPath2 = "";
            string imageNameTemp = [path UTF8String];
            
            if (imageNameTemp != ""){
                imageNameTemp = imageNameTemp.substr(1);
                
                dir = opendir(imageFolderPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_TrackData") != -1){
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                
                                entry = entry.substr(0, entry.find("_TrackData"));
                                arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
        else if (sourceStatusHold == 1){
            string imageFolderPath = analysisDataFolderPath+[path UTF8String]+"_AnalysisResults";
            string imageFolderPath2 = "";
            string imageNameTemp = [path UTF8String];
            
            if (imageNameTemp != ""){
                imageNameTemp = imageNameTemp.substr(1);
                
                dir = opendir(imageFolderPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_IDResults") != -1){
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                
                                entry = entry.substr(0, entry.find("_IDResults"));
                                arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
        else if (sourceStatusHold == 2){
            if (lineageDataEntryCount != 0){
                string imageNameTemp = [path UTF8String];
                imageNameTemp = imageNameTemp.substr(1);
                
                if (imageNameTemp == "Live"){
                    if (directoryInfoCount+3 > directoryInfoLimit) [self directoryInfoUpDate];
                    
                    arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][6], directoryInfoCount++;
                    
                    if (arrayTableMain [tableCurrentRowHold][7] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][7], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][8] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][8], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][9] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][9], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][10] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][10], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][11] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][11], directoryInfoCount++;
                    }
                }
                
                if ((int)imageNameTemp.find("Round") != -1){
                    string roundString = imageNameTemp.substr(5);
                    int roundInt = atoi(roundString.c_str());
                    
                    if (directoryInfoCount+3 > directoryInfoLimit) [self directoryInfoUpDate];
                    
                    arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][15+(roundInt-1)*8], directoryInfoCount++;
                    
                    if (arrayTableMain [tableCurrentRowHold][16+(roundInt-1)*8] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][16+(roundInt-1)*8], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][17+(roundInt-1)*8] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][17+(roundInt-1)*8], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][18+(roundInt-1)*8] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][18+(roundInt-1)*8], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][19+(roundInt-1)*8] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][19+(roundInt-1)*8], directoryInfoCount++;
                    }
                    
                    if (arrayTableMain [tableCurrentRowHold][20+(roundInt-1)*8] != "nil"){
                        arrayDirectoryInfo [directoryInfoCount] = arrayTableMain [tableCurrentRowHold][20+(roundInt-1)*8], directoryInfoCount++;
                    }
                }
            }
        }
    }
    
    if (column == 2){
        NSString *path;
        path = [sender path];
        
        if (sourceStatusHold == 0){
            string stringExtract = [path UTF8String];
            stringExtract = stringExtract.substr(1);
            string analysisIDExtract = stringExtract.substr(stringExtract.find("/")+1);
            string seriesExtract = stringExtract.substr(0, stringExtract.find("/"));
            string imageFolderPath = trackDataFolderPath+"/"+seriesExtract+"_Series/"+analysisIDExtract+"_TrackData";
            string imageFolderPath2 = "";
            string imageNameTemp = [path UTF8String];
            
            if (imageNameTemp != ""){
                imageNameTemp = imageNameTemp.substr(1);
                
                dir = opendir(imageFolderPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Connect") != -1){
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                
                                entry = entry.substr(0, entry.find("_Connect"));
                                arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
        else if (sourceStatusHold == 1){
            string stringExtract = [path UTF8String];
            stringExtract = stringExtract.substr(1);
            string analysisIDExtract = stringExtract.substr(stringExtract.find("/")+1);
            string seriesExtract = stringExtract.substr(0, stringExtract.find("/"));
            string imageFolderPath = analysisDataFolderPath+"/"+seriesExtract+"_AnalysisResults/"+analysisIDExtract+"_IDResults";
            string imageFolderPath2 = "";
            string imageNameTemp = [path UTF8String];
            
            if (imageNameTemp != ""){
                imageNameTemp = imageNameTemp.substr(1);
                
                dir = opendir(imageFolderPath.c_str());
                
                if (dir != NULL){
                    string entry;
                    
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Results") != -1){
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                
                                entry = entry.substr(0, entry.find("_Results"));
                                arrayDirectoryInfo [directoryInfoCount] = entry, directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    
    if (column == 1){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        
        if (sourceStatusHold == 0 || sourceStatusHold == 1) [cell setLoaded:YES];
        else [cell setLeaf:YES];
    }
    
    if (column == 2){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLeaf:YES];
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    if (upLoadingProgress == 0){
        NSString *nodePath = [browser path];
        string nodePathString = "";
        nodePathString = [nodePath UTF8String];
        
        if (nodePathString != ""){
            nodePathString = nodePathString.substr(1);
            
            seriesName = "";
            analysisID = "";
            treatName = "";
            string extractTemp = "";
            string extractTemp2 = "";
            
            if ((int)nodePathString.find("/") != -1){
                seriesName = nodePathString.substr(0, nodePathString.find("/"));
                extractTemp = nodePathString.substr(nodePathString.find("/")+1);
            }
            else seriesName = nodePathString;
            
            if (extractTemp != ""){
                if ((int)extractTemp.find("/") != -1){
                    analysisID = extractTemp.substr(0, extractTemp.find("/"));
                    extractTemp2 = extractTemp.substr(extractTemp.find("/")+1);
                }
                else analysisID = extractTemp;
            }
            
            if (extractTemp2 != "") treatName = extractTemp2.substr(0, extractTemp2.find("/"));
            
            if (seriesName != "" && analysisID == "" && treatName == ""){
                sourceS = [[SourceS alloc] init];
                [sourceS sourceMain];
            }
            else if (seriesName != "" && analysisID != "" && treatName == ""){
                sourceSA = [[SourceSA alloc] init];
                [sourceSA sourceMain];
            }
            else if (seriesName != "" && analysisID != "" && treatName != ""){
                sourceSAT = [[SourceSAT alloc] init];
                [sourceSAT sourceMain];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Lineage Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = lineageDataEntryCount;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = arrayTableMain [rowIndex][0];
        string displayData2 = arrayTableMain [rowIndex][1];
        string displayData3 = arrayTableMain [rowIndex][2];
        string displayData4 = arrayTableMain [rowIndex][3];
        string displayData5 = arrayTableMain [rowIndex][4];
        string displayData6 = arrayTableMain [rowIndex][5];
        string displayData7 = arrayTableMain [rowIndex][12];
        
        if (arraySelectedLing [rowIndex] == 1) displayData1 = displayData1+"<";
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor magentaColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData6.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData7.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL6"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL7"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallCount++;
    tableCurrentRowHold = rowIndex;
    
    if (tableCallCount == 2){
        if (upLoadingProgress == 0){
            tableCurrentRowHold = rowIndexHold;
            
            if (arraySelectedLing [tableCurrentRowHold] == 0 && lineageDataEntryCount >= tableCurrentRowHold){
                arraySelectedLing [tableCurrentRowHold] = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (arraySelectedLing [tableCurrentRowHold] != 0 && lineageDataEntryCount >= tableCurrentRowHold){
                arraySelectedLing [tableCurrentRowHold] = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            if (lineageDataEntryCount >= tableCurrentRowHold){
                maxLingNo = 0;
                
                for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter1++){
                    if (maxLingNo < arrayLineageData [tableCurrentRowHold][counter1*9+6]) maxLingNo = arrayLineageData [tableCurrentRowHold][counter1*9+6];
                }
                
                lineageLinkListLength = arrayLineageLink [tableCurrentRowHold][0];
                
                delete [] arrayLineageLinkList;
                arrayLineageLinkList = new int [(maxLingNo+1)*lineageLinkListLength+11];
                lineageLinkListCount = 0;
                lineageLinkListLimit = (maxLingNo+1)*lineageLinkListLength+11;
                
                for (int counter1 = 0; counter1 < (maxLingNo+1)*lineageLinkListLength+11; counter1++) arrayLineageLinkList [counter1] = 0;
                
                for (int counter1 = 0; counter1 < lineageLinkHold [tableCurrentRowHold]; counter1++){
                    arrayLineageLinkList [lineageLinkListCount] = arrayLineageLink [tableCurrentRowHold][counter1], lineageLinkListCount++;
                }
                
                //for (int counterA = 0; counterA < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [tableCurrentRowHold][counterA*9+counterB];
                //    cout<<" arrayLineageData "<<counterA<<endl;
                //}
                
                lineageExtractCount = 0;
                lineageDisplayPosition = 0;
                int extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkListLength+5];
                
                for (int counter1 = 1; counter1 <= maxLingNo; counter1++){
                    if (arrayLineageLinkList [counter1*lineageLinkListLength] > 0){
                        lineageSelect [extractCount] = arrayLineageLinkList [counter1*lineageLinkListLength];
                        extractCount++;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                            if (arrayLineageLinkList [counter1*lineageLinkListLength+counter2] != 0){
                                lineageSelect [extractCount] = arrayLineageLinkList [counter1*lineageLinkListLength+counter2];
                                extractCount++;
                            }
                        }
                        
                        lineageDisplayPosition = counter1;
                        
                        break;
                    }
                }
                
                int lineageNoFind = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter2++){
                        if (arrayLineageData [tableCurrentRowHold][counter2*9+6] == lineageNoFind){
                            if (lineageExtractCount+10 > lineageExtractLimit){
                                int *arrayUpDate = new int [lineageExtractCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                
                                delete [] arrayLineageExtract;
                                lineageExtractLimit = lineageExtractCount+arrayLineageDataEntryHold [tableCurrentRowHold]+5000;
                                arrayLineageExtract = new int [lineageExtractLimit];
                                
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+1], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+2], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+3], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+4], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+5], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+6], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+7], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+8], lineageExtractCount++;
                        }
                    }
                }
                
                int ifStartTime = arrayTableDetail [tableCurrentRowHold][4];
                int ifEndTime = arrayTableDetail [tableCurrentRowHold][5];
                
                if (ifStartTime != 0 && (ifEndTime-ifStartTime+1)*7+7 > ifDataExtractLimit){
                    delete [] ifDataExtract;
                    ifDataExtractCount = 7;
                    ifDataExtractLimit = (ifEndTime-ifStartTime+1)*7+7+70;
                    ifDataExtract = new int [ifDataExtractLimit];
                }
                else ifDataExtractCount = 7;
                
                ifDataExtract [0] = 0; //----Live 0----
                ifDataExtract [1] = 0; //----Ch1 no----
                ifDataExtract [2] = 0; //----Ch2 no----
                ifDataExtract [3] = 0; //----Ch3 no----
                ifDataExtract [5] = 0; //----Ch4 no----
                ifDataExtract [6] = 0; //----Ch5 no----
                ifDataExtract [7] = 0; //----Ch6 no----
                
                if (ifStartTime != 0){
                    for (int counter1 = ifStartTime; counter1 <= ifEndTime; counter1++){
                        ifDataExtract [ifDataExtractCount] = counter1, ifDataExtractCount++; //----Time----
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++; //----Ch1 no----
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++; //----Ch2 no----
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++; //----Ch3 no----
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++; //----Ch4 no----
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++; //----Ch5 no----
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++; //----Ch6 no----
                    }
                }
                
                int ifEntryCount = arrayIFDataEntryHold [tableCurrentRowHold];
                
                //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                //    cout<<" arrayIFData "<<counterA<<endl;
                //}
                
                
                //**********arrayIFData**********
                //1. Cell Number (1+-4 bytes)
                //2. Cell Lineage No (3)
                //3. Time Point (2)
                //4. Live/IF: Live: 1, IF: 2 (1), Simulation 3
                //5. CH1-no (1)
                //6. CH1-Value (3)
                //7. CH1-Area (3)
                //8. CH2-no (1)
                //9. CH2-Value (3)
                //10. CH2-Area (3)
                //11. CH3-no (1)
                //12. CH3-Value (3)
                //13. CH3-Area (3)
                //14. CH4-no (1)
                //15. CH4-Value (3)
                //16. CH4-Area (3)
                //17. CH5-no (1)
                //18. CH5-Value (3)
                //19. CH5-Area (3)
                //20. CH6-no (1)
                //21. CH6-Value (3)
                //22. CH6-Area (3)
                
                if (ifEntryCount != 0){
                    for (int counter1 = 0; counter1 < ifEntryCount/22; counter1++){
                        if (arrayIFData [tableCurrentRowHold][counter1*22+3] == 1 || arrayIFData [tableCurrentRowHold][counter1*22+3] == 3){
                            ifDataExtract [1] = arrayIFData [tableCurrentRowHold][counter1*22+4];
                            ifDataExtract [2] = arrayIFData [tableCurrentRowHold][counter1*22+7];
                            ifDataExtract [3] = arrayIFData [tableCurrentRowHold][counter1*22+10];
                            ifDataExtract [4] = arrayIFData [tableCurrentRowHold][counter1*22+13];
                            ifDataExtract [5] = arrayIFData [tableCurrentRowHold][counter1*22+16];
                            ifDataExtract [6] = arrayIFData [tableCurrentRowHold][counter1*22+19];
                        }
                        else if (arrayIFData [tableCurrentRowHold][counter1*22+3] == 2){
                            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                                if (arrayIFData [tableCurrentRowHold][counter1*22+2] == ifDataExtract [counter2*7]){
                                    ifDataExtract [counter2*7+1] = arrayIFData [tableCurrentRowHold][counter1*22+4];
                                    ifDataExtract [counter2*7+2] = arrayIFData [tableCurrentRowHold][counter1*22+7];
                                    ifDataExtract [counter2*7+3] = arrayIFData [tableCurrentRowHold][counter1*22+10];
                                    ifDataExtract [counter2*7+4] = arrayIFData [tableCurrentRowHold][counter1*22+13];
                                    ifDataExtract [counter2*7+5] = arrayIFData [tableCurrentRowHold][counter1*22+16];
                                    ifDataExtract [counter2*7+6] = arrayIFData [tableCurrentRowHold][counter1*22+19];
                                    break;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < ifDataExtractCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<ifDataExtract [counterA*4+counterB];
                //    cout<<" ifDataExtract "<<counterA<<endl;
                //}
                
                ifValueExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < ifEntryCount/22; counter2++){
                        if (arrayIFData [tableCurrentRowHold][counter2*22+1] == lineageNoFind){
                            if (ifValueExtractCount+50 > ifValueExtractLimit){
                                int *arrayUpDate = new int [ifValueExtractCount+40];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                
                                delete [] ifValueExtract;
                                ifValueExtractLimit = ifValueExtractCount+5000;
                                ifValueExtract = new int [ifValueExtractLimit];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+1], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+2], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+3], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+4], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+5], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+6], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+7], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+8], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+9], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+10], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+11], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+12], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+13], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+14], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+15], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+17], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+18], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+19], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+20], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+21], ifValueExtractCount++;
                        }
                    }
                }
                
                int ifTimeEntryCount = arrayIfTimeStatusHold [tableCurrentRowHold];
                
                if (ifTimeEntryCount+10 > ifTimeExtractLimit){
                    delete [] ifTimeExtract;
                    ifTimeExtractCount = 0;
                    ifTimeExtractLimit = ifTimeEntryCount+10;
                    ifTimeExtract = new int [ifTimeExtractLimit];
                }
                else ifTimeExtractCount = 0;
                
                for (int counter1 = 0; counter1 < ifTimeEntryCount; counter1++) ifTimeExtract [counter1] = arrayIfTimeStatus [tableCurrentRowHold][counter1], ifTimeExtractCount++;
                
                if (ifTimeExtract [1] == 0) includeExcludeFlag = 0;
                else includeExcludeFlag = 1;
                
                //**********arrayAreaData**********
                int areaEntryCount = arrayAreaDataHold [tableCurrentRowHold];
                
                areaExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < areaEntryCount/5; counter2++){
                        if (arrayAreaData [tableCurrentRowHold][counter2*5] == lineageNoFind){
                            if (areaExtractCount+10 > areaExtractLimit){
                                int *arrayUpDate = new int [areaExtractCount+10];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                
                                delete [] areaExtract;
                                areaExtractLimit = areaExtractCount+5000;
                                areaExtract = new int [areaExtractLimit];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+1], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+2], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+3], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+4], areaExtractCount++;
                        }
                    }
                }
                
                delete [] lineageSelect;
                
                ifCurrentCHNo = 0;
                ifCurrentTime = 0;
                liveCurrentCHNo = 0;
                includeExcludeModification = 0;
                holdReviseLineageCount = 0;
                holdReviseIfDataCount = 0;
                holdReviseAreaDataCount = 0;
                lineageModification = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
                
                if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            }
            
            [listBrowser loadColumnZero];
            [listBrowser reloadColumn:1];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            tableCurrentRowHold = rowIndex;
            
            if (arraySelectedLing [rowIndex] == 0 && lineageDataEntryCount >= rowIndex){
                arraySelectedLing [tableCurrentRowHold] = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else if (arraySelectedLing [rowIndex] != 0 && lineageDataEntryCount >= rowIndex){
                arraySelectedLing [rowIndex] = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            
            if (lineageDataEntryCount >= tableCurrentRowHold){
                maxLingNo = 0;
                
                for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter1++){
                    if (maxLingNo < arrayLineageData [tableCurrentRowHold][counter1*9+6]) maxLingNo = arrayLineageData [tableCurrentRowHold][counter1*9+6];
                }
                
                lineageLinkListLength = arrayLineageLink [tableCurrentRowHold][0];
                
                delete [] arrayLineageLinkList;
                arrayLineageLinkList = new int [(maxLingNo+1)*lineageLinkListLength+11];
                lineageLinkListCount = 0;
                lineageLinkListLimit = (maxLingNo+1)*lineageLinkListLength+11;
                
                for (int counter1 = 0; counter1 < (maxLingNo+1)*lineageLinkListLength+11; counter1++) arrayLineageLinkList [counter1] = 0;
                
                for (int counter1 = 0; counter1 < lineageLinkHold [tableCurrentRowHold]; counter1++){
                    arrayLineageLinkList [lineageLinkListCount] = arrayLineageLink [tableCurrentRowHold][counter1], lineageLinkListCount++;
                }
                
                //for (int counterA = 0; counterA < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [tableCurrentRowHold][counterA*9+counterB];
                //    cout<<" arrayLineageData "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                //}
                
                lineageExtractCount = 0;
                lineageDisplayPosition = 0;
                int extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkListLength+5];
                
                for (int counter1 = 1; counter1 <= maxLingNo; counter1++){
                    if (arrayLineageLinkList [counter1*lineageLinkListLength] > 0){
                        lineageSelect [extractCount] = arrayLineageLinkList [counter1*lineageLinkListLength];
                        extractCount++;
                        
                        for (int counter2 = 1; counter2 < lineageLinkListLength; counter2++){
                            if (arrayLineageLinkList [counter1*lineageLinkListLength+counter2] != 0){
                                lineageSelect [extractCount] = arrayLineageLinkList [counter1*lineageLinkListLength+counter2];
                                extractCount++;
                            }
                        }
                        
                        lineageDisplayPosition = counter1;
                        
                        break;
                    }
                }
                
                int lineageNoFind = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter2++){
                        if (arrayLineageData [tableCurrentRowHold][counter2*9+6] == lineageNoFind){
                            if (lineageExtractCount+10 > lineageExtractLimit){
                                int *arrayUpDate = new int [lineageExtractCount+10];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayUpDate [counter3] = arrayLineageExtract [counter3];
                                
                                delete [] arrayLineageExtract;
                                lineageExtractLimit = lineageExtractCount+arrayLineageDataEntryHold [tableCurrentRowHold]+500;
                                arrayLineageExtract = new int [lineageExtractLimit+500];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractCount; counter3++) arrayLineageExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+1], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+2], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+3], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+4], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+5], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+6], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+7], lineageExtractCount++;
                            arrayLineageExtract [lineageExtractCount] = arrayLineageData [tableCurrentRowHold][counter2*9+8], lineageExtractCount++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < lineageExtractCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageExtract [counterA*9+counterB];
                //    cout<<" arrayLineageExtract "<<counterA<<endl;
                //}
                
                int ifStartTime = arrayTableDetail [tableCurrentRowHold][4];
                int ifEndTime = arrayTableDetail [tableCurrentRowHold][5];
                
                if (ifStartTime != 0 && (ifEndTime-ifStartTime+1)*7+7 > ifDataExtractLimit){
                    delete [] ifDataExtract;
                    ifDataExtractCount = 7;
                    ifDataExtractLimit = (ifEndTime-ifStartTime+1)*7+7+70;
                    ifDataExtract = new int [ifDataExtractLimit];
                }
                else ifDataExtractCount = 7;
                
                ifDataExtract [0] = 0;
                ifDataExtract [1] = 0;
                ifDataExtract [2] = 0;
                ifDataExtract [3] = 0;
                ifDataExtract [4] = 0;
                ifDataExtract [5] = 0;
                ifDataExtract [6] = 0;
                
                if (ifStartTime != 0){
                    for (int counter1 = ifStartTime; counter1 <= ifEndTime; counter1++){
                        ifDataExtract [ifDataExtractCount] = counter1, ifDataExtractCount++;
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++;
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++;
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++;
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++;
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++;
                        ifDataExtract [ifDataExtractCount] = 0, ifDataExtractCount++;
                    }
                }
                
                int ifEntryCount = arrayIFDataEntryHold [tableCurrentRowHold];
                
                //for (int counterA = 0; counterA < ifEntryCount/22; counterA++){
                //    for (int counterB = 0; counterB < 22; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*22+counterB];
                //    cout<<" arrayIFData "<<counterA<<endl;
                //}
                
                if (ifEntryCount != 0){
                    for (int counter1 = 0; counter1 < ifEntryCount/22; counter1++){
                        if (arrayIFData [tableCurrentRowHold][counter1*22+3] == 1 || arrayIFData [tableCurrentRowHold][counter1*22+3] == 3){
                            ifDataExtract [1] = arrayIFData [tableCurrentRowHold][counter1*22+4];
                            ifDataExtract [2] = arrayIFData [tableCurrentRowHold][counter1*22+7];
                            ifDataExtract [3] = arrayIFData [tableCurrentRowHold][counter1*22+10];
                            ifDataExtract [4] = arrayIFData [tableCurrentRowHold][counter1*22+13];
                            ifDataExtract [5] = arrayIFData [tableCurrentRowHold][counter1*22+16];
                            ifDataExtract [6] = arrayIFData [tableCurrentRowHold][counter1*22+19];
                        }
                        else if (arrayIFData [tableCurrentRowHold][counter1*22+3] == 2){
                            for (int counter2 = 1; counter2 < ifDataExtractCount/7; counter2++){
                                if (arrayIFData [tableCurrentRowHold][counter1*22+2] == ifDataExtract [counter2*7]){
                                    ifDataExtract [counter2*7+1] = arrayIFData [tableCurrentRowHold][counter1*22+4];
                                    ifDataExtract [counter2*7+2] = arrayIFData [tableCurrentRowHold][counter1*22+7];
                                    ifDataExtract [counter2*7+3] = arrayIFData [tableCurrentRowHold][counter1*22+10];
                                    ifDataExtract [counter2*7+4] = arrayIFData [tableCurrentRowHold][counter1*22+13];
                                    ifDataExtract [counter2*7+5] = arrayIFData [tableCurrentRowHold][counter1*22+16];
                                    ifDataExtract [counter2*7+6] = arrayIFData [tableCurrentRowHold][counter1*22+19];
                                    break;
                                }
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < ifDataExtractCount/7; counterA++){
                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<ifDataExtract [counterA*7+counterB];
                //    cout<<" ifDataExtract "<<counterA<<endl;
                //}
                
                //**********arrayIFData**********
                ifValueExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < ifEntryCount/22; counter2++){
                        if (arrayIFData [tableCurrentRowHold][counter2*22+1] == lineageNoFind){
                            if (ifValueExtractCount+50 > ifValueExtractLimit){
                                int *arrayUpDate = new int [ifValueExtractCount+40];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) arrayUpDate [counter3] = ifValueExtract [counter3];
                                
                                delete [] ifValueExtract;
                                ifValueExtractLimit = ifValueExtractCount+5000;
                                ifValueExtract = new int [ifValueExtractLimit];
                                
                                for (int counter3 = 0; counter3 < ifValueExtractCount; counter3++) ifValueExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+1], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+2], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+3], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+4], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+5], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+6], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+7], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+8], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+9], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+10], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+11], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+12], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+13], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+14], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+15], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+16], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+17], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+18], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+19], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+20], ifValueExtractCount++;
                            ifValueExtract [ifValueExtractCount] = arrayIFData [tableCurrentRowHold][counter2*22+21], ifValueExtractCount++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < ifValueExtractCount/22; counterA++){
                //    for (int counterB = 0; counterB < 22; counterB++) cout<<" "<<ifValueExtract [counterA*22+counterB];
                //    cout<<" ifValueExtract "<<counterA<<endl;
                //}
                
                int ifTimeEntryCount = arrayIfTimeStatusHold [tableCurrentRowHold];
                
                if (ifTimeEntryCount+10 > ifTimeExtractLimit){
                    delete [] ifTimeExtract;
                    ifTimeExtractCount = 0;
                    ifTimeExtractLimit = ifTimeEntryCount+10;
                    ifTimeExtract = new int [ifTimeExtractLimit];
                }
                else ifTimeExtractCount = 0;
                
                for (int counter1 = 0; counter1 < ifTimeEntryCount; counter1++) ifTimeExtract [counter1] = arrayIfTimeStatus [tableCurrentRowHold][counter1], ifTimeExtractCount++;
                
                if (ifTimeExtract [1] == 0) includeExcludeFlag = 0;
                else includeExcludeFlag = 1;
                
                //**********arrayAreaData**********
                int areaEntryCount = arrayAreaDataHold [tableCurrentRowHold];
                
                areaExtractCount = 0;
                
                for (int counter1 = 0; counter1 < extractCount; counter1++){
                    lineageNoFind = lineageSelect [counter1];
                    
                    for (int counter2 = 0; counter2 < areaEntryCount/5; counter2++){
                        if (arrayAreaData [tableCurrentRowHold][counter2*5] == lineageNoFind){
                            if (areaExtractCount+10 > areaExtractLimit){
                                int *arrayUpDate = new int [areaExtractCount+10];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) arrayUpDate [counter3] = areaExtract [counter3];
                                
                                delete [] areaExtract;
                                areaExtractLimit = areaExtractCount+5000;
                                areaExtract = new int [areaExtractLimit];
                                
                                for (int counter3 = 0; counter3 < areaExtractCount; counter3++) areaExtract [counter3] = arrayUpDate [counter3];
                                delete [] arrayUpDate;
                            }
                            
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+1], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+2], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+3], areaExtractCount++;
                            areaExtract [areaExtractCount] = arrayAreaData [tableCurrentRowHold][counter2*5+4], areaExtractCount++;
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < areaExtractCount/5; counterA++){
                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtract [counterA*5+counterB];
                //    cout<<" areaExtract "<<counterA<<endl;
                //}
                
                delete [] lineageSelect;
                
                ifCurrentCHNo = 0;
                ifCurrentTime = 0;
                liveCurrentCHNo = 0;
                includeExcludeModification = 0;
                holdReviseLineageCount = 0;
                holdReviseIfDataCount = 0;
                holdReviseAreaDataCount = 0;
                lineageModification = 0;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
                
                if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            }
            
            [listBrowser loadColumnZero];
            [listBrowser reloadColumn:1];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(IBAction)sourceAnalysisSet:(id)sender{
    if (upLoadingProgress == 0){
        if (sourceStatusHold == 0){
            sourceStatusHold = 1;
            
            [sourceStatus setStringValue:@"Analysis"];
            
            [listBrowser loadColumnZero];
            [listBrowser reloadColumn:0];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (sourceStatusHold == 1){
            sourceStatusHold = 2;
            
            [sourceStatus setStringValue:@"IF Info"];
            
            [listBrowser loadColumnZero];
            [listBrowser reloadColumn:0];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else if (sourceStatusHold == 2){
            sourceStatusHold = 0;
            
            [sourceStatus setStringValue:@"Source"];
            
            [listBrowser loadColumnZero];
            [listBrowser reloadColumn:0];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearAll:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            for (int counter1 = 0; counter1 < 101; counter1++){
                delete [] arrayLineageData [counter1];
                delete [] arrayIFData [counter1];
                delete [] arrayIFTimeLineData [counter1];
                delete [] arrayTableMain [counter1];
                delete [] arrayTableDetail [counter1];
                delete [] arrayLineageDataType [counter1];
                delete [] arrayIfTimeStatus [counter1];
                delete [] arrayAreaData [counter1];
                delete [] arrayLineageLink [counter1];
            }
            
            delete [] arrayLineageData;
            delete [] arrayIFData;
            delete [] arrayIFTimeLineData;
            delete [] arrayTableMain;
            delete [] arrayTableDetail;
            delete [] arrayLineageDataType;
            delete [] arrayIfTimeStatus;
            delete [] arrayAreaData;
            delete [] arrayLineageLink;
            
            delete [] arrayLineageDataEntryHold;
            delete [] arrayIFDataEntryHold;
            delete [] arrayIFTimeLineDataEntryHold;
            delete [] arrayTableMainHold;
            delete [] arraySelectedLing;
            delete [] arrayIfTimeStatusHold;
            delete [] arrayAreaDataHold;
            delete [] lineageLinkHold;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                delete [] arrayLineageFluorescentDataType [counter1];
            }
            
            delete [] arrayLineageFluorescentDataType;
            
            initialArraySet = 0;
            firstReadFlag = 0;
            lineageDataEntryCount = 0;
            lineageFluorescentDataTypeEntryCount = 0;
            
            lineageExtractCount = 0;
            lineageLinkListCount = 0;
            ifDataExtractCount = 0;
            ifValueExtractCount = 0;
            ifTimeExtractCount = 0;
            areaExtractCount = 0;
            lineageLinkListCount = 0;
            
            ifCurrentCHNo = 0;
            ifCurrentTime = 0;
            liveCurrentCHNo = 0;
            includeExcludeModification = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            tableViewCall = 1;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
            
            if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
            
            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearSelect:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (lineageDataEntryCount > 1){
                int deleteRoundNo = arrayTableMainHold [tableCurrentRowHold];
                
                int **arrayLineageDataTemp = new int *[101];
                int **arrayIFDataTemp = new int *[101];
                int **arrayIFTimeLineDataTemp = new int *[101];
                string **arrayTableMainTemp = new string *[101];
                int **arrayTableDetailTemp = new int *[101];
                string **arrayLineageDataTypeTemp = new string *[101];
                int **arrayIfTimeStatusTemp = new int *[101];
                int **arrayAreaDataTemp = new int *[101];
                int **arrayLineageLinkTemp = new int *[101];
                
                for (int counter1 = 0; counter1 < 101; counter1++){
                    arrayLineageDataTemp [counter1] = new int [10];
                    arrayIFDataTemp [counter1] = new int [10];
                    arrayIFTimeLineDataTemp [counter1] = new int [10];
                    arrayTableMainTemp [counter1] = new string [10];
                    arrayTableDetailTemp [counter1] = new int [18];
                    arrayLineageDataTypeTemp [counter1] = new string [8];
                    arrayIfTimeStatusTemp [counter1] = new int [10];
                    arrayAreaDataTemp [counter1] = new int [10];
                    arrayLineageLinkTemp [counter1] = new int [10];
                }
                
                unsigned long entryLength = 0;
                int entryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (counter1 != tableCurrentRowHold){
                        entryLength = arrayLineageDataEntryHold [counter1];
                        
                        delete [] arrayLineageDataTemp [entryCount];
                        arrayLineageDataTemp [entryCount] = new int [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayLineageDataTemp [entryCount][counter2] = arrayLineageData [counter1][counter2];
                        }
                        
                        entryLength = (unsigned long)arrayIFDataEntryHold [counter1];
                        
                        delete [] arrayIFDataTemp [entryCount];
                        arrayIFDataTemp [entryCount] = new int [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayIFDataTemp [entryCount][counter2] = arrayIFData [counter1][counter2];
                        }
                        
                        entryLength = (unsigned long)arrayIFTimeLineDataEntryHold [counter1];
                        
                        delete [] arrayIFTimeLineDataTemp [entryCount];
                        arrayIFTimeLineDataTemp [entryCount] = new int [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayIFTimeLineDataTemp [entryCount][counter2] = arrayIFTimeLineData [counter1][counter2];
                        }
                        
                        entryLength = (unsigned long)arrayTableMainHold [counter1];
                        
                        delete [] arrayTableMainTemp [entryCount];
                        arrayTableMainTemp [entryCount] = new string [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayTableMainTemp [entryCount][counter2] = arrayTableMain [counter1][counter2];
                        }
                        
                        for (int counter2 = 0; counter2 < 17; counter2++){
                            arrayTableDetailTemp [entryCount][counter2] = arrayTableDetail [counter1][counter2];
                        }
                        
                        for (int counter2 = 0; counter2 < 7; counter2++){
                            arrayLineageDataTypeTemp [entryCount][counter2] = arrayLineageDataType [counter1][counter2];
                        }
                        
                        entryLength = (unsigned long)arrayIfTimeStatusHold [counter1];
                        
                        delete [] arrayIfTimeStatusTemp [entryCount];
                        arrayIfTimeStatusTemp [entryCount] = new int [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayIfTimeStatusTemp [entryCount][counter2] = arrayIfTimeStatus [counter1][counter2];
                        }
                        
                        entryLength = (unsigned long)arrayAreaDataHold [counter1];
                        
                        delete [] arrayAreaDataTemp [entryCount];
                        arrayAreaDataTemp [entryCount] = new int [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayAreaDataTemp [entryCount][counter2] = arrayAreaData [counter1][counter2];
                        }
                        
                        entryLength = (unsigned long)lineageLinkHold [counter1];
                        
                        delete [] arrayLineageLinkTemp [entryCount];
                        arrayLineageLinkTemp [entryCount] = new int [entryLength+50];
                        
                        for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                            arrayLineageLinkTemp [entryCount][counter2] = arrayLineageLink [counter1][counter2];
                        }
                        
                        entryCount++;
                    }
                }
                
                string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                    arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
                }
                
                int lineageFluorescentEntryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) != deleteRoundNo){
                        for (int counter2 = 0; counter2 < 8; counter2++){
                            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
                        }
                        
                        lineageFluorescentEntryCount++;
                    }
                }
                
                entryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (counter1 != tableCurrentRowHold){
                        arrayLineageDataEntryHold [entryCount] = arrayLineageDataEntryHold [counter1];
                        arrayIFDataEntryHold [entryCount] = arrayIFDataEntryHold [counter1];
                        arrayIFTimeLineDataEntryHold [entryCount] = arrayIFTimeLineDataEntryHold [counter1];
                        arrayTableMainHold [entryCount] = arrayTableMainHold [counter1];
                        arraySelectedLing [entryCount] = arraySelectedLing [counter1];
                        arrayIfTimeStatusHold [entryCount] = arrayIfTimeStatusHold [counter1];
                        arrayAreaDataHold [entryCount] = arrayAreaDataHold [counter1];
                        lineageLinkHold [entryCount] = lineageLinkHold [counter1];
                        entryCount++;
                    }
                }
                
                for (int counter1 = 0; counter1 < 101; counter1++){
                    delete [] arrayLineageData [counter1];
                    delete [] arrayIFData [counter1];
                    delete [] arrayIFTimeLineData [counter1];
                    delete [] arrayTableMain [counter1];
                    delete [] arrayIfTimeStatus [counter1];
                    delete [] arrayAreaData [counter1];
                    delete [] arrayLineageLink [counter1];
                }
                
                delete [] arrayLineageData;
                delete [] arrayIFData;
                delete [] arrayIFTimeLineData;
                delete [] arrayTableMain;
                delete [] arrayIfTimeStatus;
                delete [] arrayAreaData;
                delete [] arrayLineageLink;
                
                arrayLineageData = new int *[101];
                arrayIFData = new int *[101];
                arrayIFTimeLineData = new int *[101];
                arrayTableMain = new string *[101];
                arrayIfTimeStatus = new int *[101];
                arrayAreaData = new int *[101];
                arrayLineageLink = new int *[101];
                
                for (int counter1 = 0; counter1 < 101; counter1++){
                    arrayLineageData [counter1] = new int [10];
                    arrayIFData [counter1] = new int [10];
                    arrayIFTimeLineData [counter1] = new int [10];
                    arrayTableMain [counter1] = new string [10];
                    arrayIfTimeStatus [counter1] = new int [10];
                    arrayAreaData [counter1] = new int [10];
                    arrayLineageLink [counter1] = new int [10];
                }
                
                lineageDataEntryCount--;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    entryLength = arrayLineageDataEntryHold [counter1];
                    
                    delete [] arrayLineageData [counter1];
                    arrayLineageData [counter1] = new int [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayLineageData [counter1][counter2] = arrayLineageDataTemp [counter1][counter2];
                    }
                    
                    entryLength = (unsigned long)arrayIFDataEntryHold [counter1];
                    
                    delete [] arrayIFData [counter1];
                    arrayIFData [counter1] = new int [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayIFData [counter1][counter2] = arrayIFDataTemp [counter1][counter2];
                    }
                    
                    entryLength = (unsigned long)arrayIFTimeLineDataEntryHold [counter1];
                    
                    delete [] arrayIFTimeLineData [counter1];
                    arrayIFTimeLineData [counter1] = new int [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayIFTimeLineData [counter1][counter2] = arrayIFTimeLineDataTemp [counter1][counter2];
                    }
                    
                    entryLength = (unsigned long)arrayTableMainHold [counter1];
                    
                    delete [] arrayTableMain [counter1];
                    arrayTableMain [counter1] = new string [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayTableMain [counter1][counter2] = arrayTableMainTemp [counter1][counter2];
                    }
                    
                    for (int counter2 = 0; counter2 < 17; counter2++){
                        arrayTableDetail [counter1][counter2] = arrayTableDetailTemp [counter1][counter2];
                    }
                    
                    for (int counter2 = 0; counter2 < 7; counter2++){
                        arrayLineageDataType [entryCount][counter2] = arrayLineageDataTypeTemp [counter1][counter2];
                    }
                    
                    entryLength = (unsigned long)arrayIfTimeStatusHold [counter1];
                    
                    delete [] arrayIfTimeStatus [counter1];
                    arrayIfTimeStatus [counter1] = new int [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayIfTimeStatus [counter1][counter2] = arrayIfTimeStatusTemp [counter1][counter2];
                    }
                    
                    entryLength = (unsigned long)arrayAreaDataHold [counter1];
                    
                    delete [] arrayAreaData [counter1];
                    arrayAreaData [counter1] = new int [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayAreaData [counter1][counter2] = arrayAreaDataTemp [counter1][counter2];
                    }
                    
                    entryLength = (unsigned long)lineageLinkHold [counter1];
                    
                    delete [] arrayLineageLink [counter1];
                    arrayLineageLink [counter1] = new int [entryLength+50];
                    
                    for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                        arrayLineageLink [counter1][counter2] = arrayLineageLinkTemp [counter1][counter2];
                    }
                }
                
                lineageFluorescentDataTypeEntryCount = 0;
                
                for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
                    for (int counter2 = 0; counter2 < 8; counter2++){
                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
                    }
                    
                    lineageFluorescentDataTypeEntryCount++;
                }
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    arrayTableMain [counter1][0] = to_string(counter1+1);
                    arrayTableDetail [counter1][0] = counter1+1;
                }
                
                for (int counter1 = 0; counter1 < 101; counter1++){
                    delete [] arrayLineageDataTemp [counter1];
                    delete [] arrayIFDataTemp [counter1];
                    delete [] arrayIFTimeLineDataTemp [counter1];
                    delete [] arrayTableMainTemp [counter1];
                    delete [] arrayTableDetailTemp [counter1];
                    delete [] arrayLineageDataTypeTemp [counter1];
                    delete [] arrayIfTimeStatusTemp [counter1];
                    delete [] arrayAreaDataTemp [counter1];
                    delete [] arrayLineageLinkTemp [counter1];
                }
                
                delete [] arrayLineageDataTemp;
                delete [] arrayIFDataTemp;
                delete [] arrayIFTimeLineDataTemp;
                delete [] arrayTableMainTemp;
                delete [] arrayTableDetailTemp;
                delete [] arrayLineageDataTypeTemp;
                delete [] arrayIfTimeStatusTemp;
                delete [] arrayAreaDataTemp;
                delete [] arrayLineageLinkTemp;
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                    delete [] arrayLineageFluorescentDataTypeTemp [counter1];
                }
                
                delete [] arrayLineageFluorescentDataTypeTemp;
                
                lineageExtractCount = 0;
                lineageLinkListCount = 0;
                ifDataExtractCount = 0;
                ifValueExtractCount = 0;
                ifTimeExtractCount = 0;
                areaExtractCount = 0;
                lineageLinkListCount = 0;
                
                ifCurrentCHNo = 0;
                ifCurrentTime = 0;
                liveCurrentCHNo = 0;
                includeExcludeModification = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
                
                if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
                
                if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            }
            else{
                
                for (int counter1 = 0; counter1 < 101; counter1++){
                    delete [] arrayLineageData [counter1];
                    delete [] arrayIFData [counter1];
                    delete [] arrayIFTimeLineData [counter1];
                    delete [] arrayTableMain [counter1];
                    delete [] arrayTableDetail [counter1];
                    delete [] arrayLineageDataType [counter1];
                    delete [] arrayIfTimeStatus [counter1];
                    delete [] arrayAreaData [counter1];
                    delete [] arrayLineageLink [counter1];
                }
                
                delete [] arrayLineageData;
                delete [] arrayIFData;
                delete [] arrayIFTimeLineData;
                delete [] arrayTableMain;
                delete [] arrayTableDetail;
                delete [] arrayLineageDataType;
                delete [] arrayIfTimeStatus;
                delete [] arrayAreaData;
                delete [] arrayLineageLink;
                
                delete [] arrayLineageDataEntryHold;
                delete [] arrayIFDataEntryHold;
                delete [] arrayIFTimeLineDataEntryHold;
                delete [] arrayTableMainHold;
                delete [] arraySelectedLing;
                delete [] arrayIfTimeStatusHold;
                delete [] arrayAreaDataHold;
                delete [] lineageLinkHold;
                
                for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                    delete [] arrayLineageFluorescentDataType [counter1];
                }
                
                delete [] arrayLineageFluorescentDataType;
                
                initialArraySet = 0;
                firstReadFlag = 0;
                lineageDataEntryCount = 0;
                lineageFluorescentDataTypeEntryCount = 0;
                
                lineageExtractCount = 0;
                lineageLinkListCount = 0;
                ifDataExtractCount = 0;
                ifValueExtractCount = 0;
                ifTimeExtractCount = 0;
                areaExtractCount = 0;
                lineageLinkListCount = 0;
                
                ifCurrentCHNo = 0;
                ifCurrentTime = 0;
                liveCurrentCHNo = 0;
                includeExcludeModification = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
                
                if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
                
                if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearType:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (lineageDataEntryCount > 1){
                string analysisNameSetTemp = [[clearTypeInput stringValue] UTF8String];
                [clearTypeInput setStringValue:@""];
                
                if (analysisNameSetTemp.length() == 2){
                    int matchCount = 0;
                    
                    int *arrayForDeleteNo = new int [lineageDataEntryCount+1];
                    
                    for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++) arrayForDeleteNo [counter1] = 0;
                    
                    for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                        if (arrayTableMain [counter1][1] == analysisNameSetTemp){
                            arrayForDeleteNo [counter1] = atoi(arrayTableMain [counter1][0].c_str());
                            matchCount++;
                        }
                        else arrayForDeleteNo [counter1] = atoi(arrayTableMain [counter1][0].c_str())*-1;
                    }
                    
                    if (matchCount != 0 && lineageDataEntryCount-matchCount != 0){
                        int **arrayLineageDataTemp = new int *[101];
                        int **arrayIFDataTemp = new int *[101];
                        int **arrayIFTimeLineDataTemp = new int *[101];
                        string **arrayTableMainTemp = new string *[101];
                        int **arrayTableDetailTemp = new int *[101];
                        string **arrayLineageDataTypeTemp = new string *[101];
                        int **arrayIfTimeStatusTemp = new int *[101];
                        int **arrayAreaDataTemp = new int *[101];
                        int **arrayLineageLinkTemp = new int *[101];
                        
                        for (int counter1 = 0; counter1 < 101; counter1++){
                            arrayLineageDataTemp [counter1] = new int [10];
                            arrayIFDataTemp [counter1] = new int [10];
                            arrayIFTimeLineDataTemp [counter1] = new int [10];
                            arrayTableMainTemp [counter1] = new string [10];
                            arrayTableDetailTemp [counter1] = new int [18];
                            arrayLineageDataTypeTemp [counter1] = new string [8];
                            arrayIfTimeStatusTemp [counter1] = new int [10];
                            arrayAreaDataTemp [counter1] = new int [10];
                            arrayLineageLinkTemp [counter1] = new int [10];
                        }
                        
                        unsigned long entryLength = 0;
                        int entryCount = 0;
                        int lineageDataEntryCountTemp = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                            if (arrayForDeleteNo [counter1] < 0){
                                entryLength = arrayLineageDataEntryHold [counter1];
                                
                                delete [] arrayLineageDataTemp [entryCount];
                                arrayLineageDataTemp [entryCount] = new int [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayLineageDataTemp [entryCount][counter2] = arrayLineageData [counter1][counter2];
                                }
                                
                                entryLength = (unsigned long)arrayIFDataEntryHold [counter1];
                                
                                delete [] arrayIFDataTemp [entryCount];
                                arrayIFDataTemp [entryCount] = new int [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayIFDataTemp [entryCount][counter2] = arrayIFData [counter1][counter2];
                                }
                                
                                entryLength = (unsigned long)arrayIFTimeLineDataEntryHold [counter1];
                                
                                delete [] arrayIFTimeLineDataTemp [entryCount];
                                arrayIFTimeLineDataTemp [entryCount] = new int [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayIFTimeLineDataTemp [entryCount][counter2] = arrayIFTimeLineData [counter1][counter2];
                                }
                                
                                entryLength = (unsigned long)arrayTableMainHold [counter1];
                                
                                delete [] arrayTableMainTemp [entryCount];
                                arrayTableMainTemp [entryCount] = new string [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayTableMainTemp [entryCount][counter2] = arrayTableMain [counter1][counter2];
                                }
                                
                                for (int counter2 = 0; counter2 < 17; counter2++){
                                    arrayTableDetailTemp [entryCount][counter2] = arrayTableDetail [counter1][counter2];
                                }
                                
                                for (int counter2 = 0; counter2 < 7; counter2++){
                                    arrayLineageDataTypeTemp [entryCount][counter2] = arrayLineageDataType [counter1][counter2];
                                }
                                
                                entryLength = (unsigned long)arrayIfTimeStatusHold [counter1];
                                
                                delete [] arrayIfTimeStatusTemp [entryCount];
                                arrayIfTimeStatusTemp [entryCount] = new int [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayIfTimeStatusTemp [entryCount][counter2] = arrayIfTimeStatus [counter1][counter2];
                                }
                                
                                entryLength = (unsigned long)arrayAreaDataHold [counter1];
                                
                                delete [] arrayAreaDataTemp [entryCount];
                                arrayAreaDataTemp [entryCount] = new int [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayAreaDataTemp [entryCount][counter2] = arrayAreaData [counter1][counter2];
                                }
                                
                                entryLength = (unsigned long)lineageLinkHold [counter1];
                                
                                delete [] arrayLineageLinkTemp [entryCount];
                                arrayLineageLinkTemp [entryCount] = new int [entryLength+50];
                                
                                for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                    arrayLineageLinkTemp [entryCount][counter2] = arrayLineageLink [counter1][counter2];
                                }
                                
                                entryCount++;
                                lineageDataEntryCountTemp++;
                            }
                        }
                        
                        string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
                        
                        for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                            arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
                        }
                        
                        int lineageFluorescentEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                            if (arrayForDeleteNo [counter1] < 0){
                                for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                                    if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) != arrayForDeleteNo [counter1]*-1){
                                        for (int counter3 = 0; counter3 < 8; counter3++){
                                            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter3] = arrayLineageFluorescentDataType [counter2][counter3];
                                        }
                                        
                                        lineageFluorescentEntryCount++;
                                    }
                                }
                            }
                        }
                        
                        entryCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                            if (arrayForDeleteNo [counter1] == 0){
                                arrayLineageDataEntryHold [entryCount] = arrayLineageDataEntryHold [counter1];
                                arrayIFDataEntryHold [entryCount] = arrayIFDataEntryHold [counter1];
                                arrayIFTimeLineDataEntryHold [entryCount] = arrayIFTimeLineDataEntryHold [counter1];
                                arrayTableMainHold [entryCount] = arrayTableMainHold [counter1];
                                arraySelectedLing [entryCount] = arraySelectedLing [counter1];
                                arrayIfTimeStatusHold [entryCount] = arrayIfTimeStatusHold [counter1];
                                arrayAreaDataHold [entryCount] = arrayAreaDataHold [counter1];
                                lineageLinkHold [entryCount] = lineageLinkHold [counter1];
                                entryCount++;
                            }
                        }
                        
                        for (int counter1 = 0; counter1 < 101; counter1++){
                            delete [] arrayLineageData [counter1];
                            delete [] arrayIFData [counter1];
                            delete [] arrayIFTimeLineData [counter1];
                            delete [] arrayTableMain [counter1];
                            delete [] arrayIfTimeStatus [counter1];
                            delete [] arrayAreaData [counter1];
                            delete [] arrayLineageLink [counter1];
                        }
                        
                        delete [] arrayLineageData;
                        delete [] arrayIFData;
                        delete [] arrayIFTimeLineData;
                        delete [] arrayTableMain;
                        delete [] arrayIfTimeStatus;
                        delete [] arrayAreaData;
                        delete [] arrayLineageLink;
                        
                        arrayLineageData = new int *[101];
                        arrayIFData = new int *[101];
                        arrayIFTimeLineData = new int *[101];
                        arrayTableMain = new string *[101];
                        arrayIfTimeStatus = new int *[101];
                        arrayAreaData = new int *[101];
                        arrayLineageLink = new int *[101];
                        
                        for (int counter1 = 0; counter1 < 101; counter1++){
                            arrayLineageData [counter1] = new int [10];
                            arrayIFData [counter1] = new int [10];
                            arrayIFTimeLineData [counter1] = new int [10];
                            arrayTableMain [counter1] = new string [10];
                            arrayIfTimeStatus [counter1] = new int [10];
                            arrayAreaData [counter1] = new int [10];
                            arrayLineageLink [counter1] = new int [10];
                        }
                        
                        lineageDataEntryCount = lineageDataEntryCountTemp;
                        
                        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                            entryLength = arrayLineageDataEntryHold [counter1];
                            
                            delete [] arrayLineageData [counter1];
                            arrayLineageData [counter1] = new int [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayLineageData [counter1][counter2] = arrayLineageDataTemp [counter1][counter2];
                            }
                            
                            entryLength = (unsigned long)arrayIFDataEntryHold [counter1];
                            
                            delete [] arrayIFData [counter1];
                            arrayIFData [counter1] = new int [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayIFData [counter1][counter2] = arrayIFDataTemp [counter1][counter2];
                            }
                            
                            entryLength = (unsigned long)arrayIFTimeLineDataEntryHold [counter1];
                            
                            delete [] arrayIFTimeLineData [counter1];
                            arrayIFTimeLineData [counter1] = new int [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayIFTimeLineData [counter1][counter2] = arrayIFTimeLineDataTemp [counter1][counter2];
                            }
                            
                            entryLength = (unsigned long)arrayTableMainHold [counter1];
                            
                            delete [] arrayTableMain [counter1];
                            arrayTableMain [counter1] = new string [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayTableMain [counter1][counter2] = arrayTableMainTemp [counter1][counter2];
                            }
                            
                            for (int counter2 = 0; counter2 < 17; counter2++){
                                arrayTableDetail [counter1][counter2] = arrayTableDetailTemp [counter1][counter2];
                            }
                            
                            for (int counter2 = 0; counter2 < 7; counter2++){
                                arrayLineageDataType [entryCount][counter2] = arrayLineageDataTypeTemp [counter1][counter2];
                            }
                            
                            entryLength = (unsigned long)arrayIfTimeStatusHold [counter1];
                            
                            delete [] arrayIfTimeStatus [counter1];
                            arrayIfTimeStatus [counter1] = new int [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayIfTimeStatus [counter1][counter2] = arrayIfTimeStatusTemp [counter1][counter2];
                            }
                            
                            entryLength = (unsigned long)arrayAreaDataHold [counter1];
                            
                            delete [] arrayAreaData [counter1];
                            arrayAreaData [counter1] = new int [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayAreaData [counter1][counter2] = arrayAreaDataTemp [counter1][counter2];
                            }
                            
                            entryLength = (unsigned long)lineageLinkHold [counter1];
                            
                            delete [] arrayLineageLink [counter1];
                            arrayLineageLink [counter1] = new int [entryLength+50];
                            
                            for (unsigned long counter2 = 0; counter2 < entryLength; counter2++){
                                arrayLineageLink [counter1][counter2] = arrayLineageLinkTemp [counter1][counter2];
                            }
                        }
                        
                        lineageFluorescentDataTypeEntryCount = 0;
                        
                        for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
                            for (int counter2 = 0; counter2 < 8; counter2++){
                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
                            }
                            
                            lineageFluorescentDataTypeEntryCount++;
                        }
                        
                        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                            arrayTableMain [counter1][0] = to_string(counter1+1);
                            arrayTableDetail [counter1][0] = counter1+1;
                        }
                        
                        for (int counter1 = 0; counter1 < 101; counter1++){
                            delete [] arrayLineageDataTemp [counter1];
                            delete [] arrayIFDataTemp [counter1];
                            delete [] arrayIFTimeLineDataTemp [counter1];
                            delete [] arrayTableMainTemp [counter1];
                            delete [] arrayTableDetailTemp [counter1];
                            delete [] arrayLineageDataTypeTemp [counter1];
                            delete [] arrayIfTimeStatusTemp [counter1];
                            delete [] arrayAreaDataTemp [counter1];
                            delete [] arrayLineageLinkTemp [counter1];
                        }
                        
                        delete [] arrayLineageDataTemp;
                        delete [] arrayIFDataTemp;
                        delete [] arrayIFTimeLineDataTemp;
                        delete [] arrayTableMainTemp;
                        delete [] arrayTableDetailTemp;
                        delete [] arrayLineageDataTypeTemp;
                        delete [] arrayIfTimeStatusTemp;
                        delete [] arrayAreaDataTemp;
                        delete [] arrayLineageLinkTemp;
                        
                        for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                            delete [] arrayLineageFluorescentDataTypeTemp [counter1];
                        }
                        
                        delete [] arrayLineageFluorescentDataTypeTemp;
                        
                        lineageExtractCount = 0;
                        lineageLinkListCount = 0;
                        ifDataExtractCount = 0;
                        ifValueExtractCount = 0;
                        ifTimeExtractCount = 0;
                        areaExtractCount = 0;
                        lineageLinkListCount = 0;
                        
                        ifCurrentCHNo = 0;
                        ifCurrentTime = 0;
                        liveCurrentCHNo = 0;
                        includeExcludeModification = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
                        
                        if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
                        
                        if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                        if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                        if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                        if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                        if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                        if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                        if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
                    }
                    else{
                        
                        for (int counter1 = 0; counter1 < 101; counter1++){
                            delete [] arrayLineageData [counter1];
                            delete [] arrayIFData [counter1];
                            delete [] arrayIFTimeLineData [counter1];
                            delete [] arrayTableMain [counter1];
                            delete [] arrayTableDetail [counter1];
                            delete [] arrayLineageDataType [counter1];
                            delete [] arrayIfTimeStatus [counter1];
                            delete [] arrayAreaData [counter1];
                            delete [] arrayLineageLink [counter1];
                        }
                        
                        delete [] arrayLineageData;
                        delete [] arrayIFData;
                        delete [] arrayIFTimeLineData;
                        delete [] arrayTableMain;
                        delete [] arrayTableDetail;
                        delete [] arrayLineageDataType;
                        delete [] arrayIfTimeStatus;
                        delete [] arrayAreaData;
                        delete [] arrayLineageLink;
                        
                        delete [] arrayLineageDataEntryHold;
                        delete [] arrayIFDataEntryHold;
                        delete [] arrayIFTimeLineDataEntryHold;
                        delete [] arrayTableMainHold;
                        delete [] arraySelectedLing;
                        delete [] arrayIfTimeStatusHold;
                        delete [] arrayAreaDataHold;
                        delete [] lineageLinkHold;
                        
                        for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                            delete [] arrayLineageFluorescentDataType [counter1];
                        }
                        
                        delete [] arrayLineageFluorescentDataType;
                        
                        initialArraySet = 0;
                        firstReadFlag = 0;
                        lineageDataEntryCount = 0;
                        lineageFluorescentDataTypeEntryCount = 0;
                        
                        lineageExtractCount = 0;
                        lineageLinkListCount = 0;
                        ifDataExtractCount = 0;
                        ifValueExtractCount = 0;
                        ifTimeExtractCount = 0;
                        areaExtractCount = 0;
                        lineageLinkListCount = 0;
                        
                        ifCurrentCHNo = 0;
                        ifCurrentTime = 0;
                        liveCurrentCHNo = 0;
                        includeExcludeModification = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
                        
                        if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
                        
                        if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                        if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                        if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                        if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                        if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                        if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                        if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
                    }
                }
                else{
                    
                    [clearTypeInput setStringValue:@""];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Maximum Two Characters"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                [clearTypeInput setStringValue:@""];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Unable To Delete Last Entry"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [clearTypeInput setStringValue:@""];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)activateAll:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                arraySelectedLing [counter1] = 1;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            tableViewCall = 1;
            
            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)clearActive:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                arraySelectedLing [counter1] = 0;
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            tableViewCall = 1;
            
            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)activateType:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            string analysisNameSetTemp = [[activateTypeInput stringValue] UTF8String];
            [activateTypeInput setStringValue:@""];
            
            if (analysisNameSetTemp.length() == 2){
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (arrayTableMain [counter1][1] == analysisNameSetTemp){
                        arraySelectedLing [counter1] = 1;
                    }
                }
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
                
                if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
                if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
                if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
                if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
                if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
                if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
                if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Maximum Two Characters"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)typeDefinitionSet:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (typeDefTimerAdjustOperation == 0){
                typeDefTimerAdjustOperation = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToTypeDefinition object:self];
            }
            
            if (typeDefTimerAdjustOperation == 2) typeDefTimerAdjustOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageDataTypeSet:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (lineageDataAdjustOperation == 0){
                lineageDataAdjustOperation = 1;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataType object:self];
            }
            
            if (lineageDataAdjustOperation == 2) lineageDataAdjustOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)analysisDataLoad:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (analysisLoadOperation == 0){
                analysisLoadOperation = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDataUploading object:self];
            }
            if (analysisLoadOperation == 2) analysisLoadOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveMain:(id)sender{
    if (upLoadingProgress == 0){
        if (includeExcludeModification == 1 || lineageModification == 1){
            string typeFind = "";
            
            if (arrayTableMain [tableCurrentRowHold][1] == "SO") typeFind = "SO";
            else typeFind = arrayTableMain [tableCurrentRowHold][4].substr(0, arrayTableMain [tableCurrentRowHold][4].find("-"));
            
            if (typeFind != "SO" && typeFind != "AN1"){
                [self dataSave];
                
                lineageModification = 0;
                includeExcludeModification = 0;
                holdReviseLineageCount = 0;
                holdReviseIfDataCount = 0;
                holdReviseAreaDataCount = 0;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewCall = 1;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
            }
            else if (typeFind == "SO" || typeFind == "AN1"){
                if (lineageDataEntryCount+1 < 101){
                    string analysisIDPath = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults";
                    
                    string typeNo = typeFind.substr(0, 2);
                    typeFind = typeFind.substr(2);
                    
                    string treatNameSave = arrayTableMain [tableCurrentRowHold][4].substr(arrayTableMain [tableCurrentRowHold][4].find("-")+1);
                    
                    DIR *dir;
                    struct dirent *dent;
                    
                    string entry;
                    string extractString;
                    maxEntryNo = 0;
                    
                    dir = opendir(analysisIDPath.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(treatNameSave) != -1 && (int)entry.find("AN") != -1){
                                extractString = entry.substr(2, entry.find("-")-2);
                                
                                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    maxEntryNo++;
                    
                    string messageString = "SO/AN1 do not allow to change-Save as AN"+to_string(maxEntryNo);
                    
                    NSString *message = @(messageString.c_str());
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert addButtonWithTitle:@"Cancel"];
                    [alert setMessageText:message];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    
                    if ([alert runModal] == NSAlertFirstButtonReturn){
                        string savePath = analysisIDPath+"/AN"+to_string(maxEntryNo)+"-"+treatNameSave+"_Results";
                        mkdir(savePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                        
                        string analysisIDPathSource = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults/"+arrayTableMain [tableCurrentRowHold][4]+"_Results";
                        
                        string analysisIDPathSource2;
                        string savePath2;
                        long sizeForCopy;
                        
                        struct stat sizeOfFile;
                        
                        dir = opendir(analysisIDPathSource.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    analysisIDPathSource2 = analysisIDPathSource+"/"+entry;
                                    savePath2 = savePath+"/"+entry;
                                    
                                    if (stat(analysisIDPathSource2.c_str(), &sizeOfFile) == 0){
                                        sizeForCopy = sizeOfFile.st_size;
                                        
                                        ifstream infile (analysisIDPathSource2.c_str(), ifstream::binary);
                                        ofstream outfile (savePath2.c_str(), ofstream::binary);
                                        
                                        char *buffer = new char[sizeForCopy];
                                        infile.read (buffer, sizeForCopy);
                                        outfile.write (buffer, sizeForCopy);
                                        delete [] buffer;
                                        
                                        outfile.close();
                                        infile.close();
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        int type = 1;
                        int number = maxEntryNo;
                        
                        [self dataSave2:type:number];
                        
                        lineageModification = 0;
                        includeExcludeModification = 0;
                        holdReviseLineageCount = 0;
                        holdReviseIfDataCount = 0;
                        holdReviseAreaDataCount = 0;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        tableViewCall = 1;
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
                        
                        if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Data Unchanged"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveAsMain:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount+1 < 101){
            if (includeExcludeModification == 1 || lineageModification == 1){
                string analysisIDPath = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults";
                string typeFind = arrayTableMain [tableCurrentRowHold][4].substr(0, 2);
                string treatNameSave = arrayTableMain [tableCurrentRowHold][4].substr(arrayTableMain [tableCurrentRowHold][4].find("-")+1);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                maxEntryNo = 0;
                
                dir = opendir(analysisIDPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(treatNameSave) != -1 && (int)entry.find(typeFind) != -1){
                            extractString = entry.substr(2, entry.find("-")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string messageString = "Data will be saved as "+typeFind+to_string(maxEntryNo);
                
                NSString *message = @(messageString.c_str());
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert addButtonWithTitle:@"Cancel"];
                [alert setMessageText:message];
                [alert setAlertStyle:NSAlertStyleWarning];
                
                if ([alert runModal] == NSAlertFirstButtonReturn){
                    string savePath = analysisIDPath+"/"+typeFind+to_string(maxEntryNo)+"-"+treatNameSave+"_Results";
                    
                    mkdir(savePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                    
                    string analysisIDPathSource = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults/"+arrayTableMain [tableCurrentRowHold][4]+"_Results";
                    
                    string analysisIDPathSource2;
                    string savePath2;
                    long sizeForCopy;
                    
                    struct stat sizeOfFile;
                    
                    dir = opendir(analysisIDPathSource.c_str());
                    
                    if (dir != NULL){
                        while ((dent = readdir(dir))){
                            entry = dent -> d_name;
                            
                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                analysisIDPathSource2 = analysisIDPathSource+"/"+entry;
                                savePath2 = savePath+"/"+entry;
                                
                                if (stat(analysisIDPathSource2.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                    
                                    ifstream infile (analysisIDPathSource2.c_str(), ifstream::binary);
                                    ofstream outfile (savePath2.c_str(), ofstream::binary);
                                    
                                    char *buffer = new char[sizeForCopy];
                                    infile.read (buffer, sizeForCopy);
                                    outfile.write (buffer, sizeForCopy);
                                    delete [] buffer;
                                    
                                    outfile.close();
                                    infile.close();
                                }
                            }
                        }
                        
                        closedir(dir);
                    }
                    
                    int type = 2;
                    int number = maxEntryNo;
                    
                    [self dataSave2:type:number];
                    
                    lineageModification = 0;
                    includeExcludeModification = 0;
                    holdReviseLineageCount = 0;
                    holdReviseIfDataCount = 0;
                    holdReviseAreaDataCount = 0;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    tableViewCall = 1;
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
                    
                    if (lineageDataOpen == 1) [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDataTable object:self];
                    
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDetailTable object:self];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Data Unchanged"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Entry Limit Exceeded: 100"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)quitAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        if (firstReadFlag == 1){
            for (int counter1 = 0; counter1 < 101; counter1++){
                delete [] arrayLineageData [counter1];
                delete [] arrayIFData [counter1];
                delete [] arrayIFTimeLineData [counter1];
                delete [] arrayTableMain [counter1];
                delete [] arrayTableDetail [counter1];
                delete [] arrayLineageDataType [counter1];
                delete [] arrayIfTimeStatus [counter1];
                delete [] arrayAreaData [counter1];
                delete [] arrayLineageLink [counter1];
            }
            
            delete [] arrayLineageData;
            delete [] arrayIFData;
            delete [] arrayIFTimeLineData;
            delete [] arrayTableMain;
            delete [] arrayTableDetail;
            delete [] arrayLineageDataType;
            delete [] arrayIfTimeStatus;
            delete [] arrayAreaData;
            delete [] arrayLineageLink;
            
            delete [] arrayLineageDataEntryHold;
            delete [] arrayIFDataEntryHold;
            delete [] arrayIFTimeLineDataEntryHold;
            delete [] arrayTableMainHold;
            delete [] arraySelectedLing;
            delete [] arrayIfTimeStatusHold;
            delete [] arrayAreaDataHold;
            delete [] lineageLinkHold;
            
            for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
                delete [] arrayLineageFluorescentDataType [counter1];
            }
            
            delete [] arrayLineageFluorescentDataType;
        }
        
        delete [] arrayTypeDefinitionHold;
        delete [] arrayTypeDefinitionHold2;
        delete [] arrayFileDelete;
        delete [] arrayColorRange;
        delete [] arrayColorRange2;
        delete [] arrayLineageExtract;
        delete [] arrayLineageLinkList;
        delete [] arrayLineageLinkListLGL;
        delete [] ifDataExtract;
        delete [] ifValueExtract;
        delete [] ifTimeExtract;
        delete [] areaExtract;
        
        if (simColorDataHoldStatus == 1) delete [] simColorDataHold;
        
        if (simProcessDataHoldStatus == 1){
            delete [] simProcessDataBaseHold;
            delete [] simProcessDataMiddleHold;
            delete [] simProcessDataProgHold;
            delete [] simProcessDataAddHold;
        }
        
        if (simulationDistributionDataStatus == 1){
            delete [] simulationDistributionData;
            delete [] simulationDistributionProgData;
            delete [] simulationDistributionMidData;
            delete [] simulationDistributionAddData;
        }
        
        if (simulationDistributionDataStatus == 1){
            delete [] simulationFluorescentData;
        }
        
        if (performDataStatus == 1){
            delete [] cellGrowthCount;
            delete [] cellEventTypeListTime;
            delete [] cellNoListForSelectLing;
        }
        
        if (lingNoAssignSimStatus == 0){
            delete [] lingNoAssignSim;
        }
        
        if (holdReviseLineageStatus == 1) delete [] holdReviseLineage;
        if (holdReviseIfDataStatus == 1) delete [] holdReviseIfData;
        if (holdReviseAreaDataStatus == 1) delete [] holdReviseAreaData;
        if (searchResultsHoldStatus == 1) delete [] arraySearchResultsHold;
        if (displayForSearchStatus == 1) delete [] arrayDisplayForSearch;
        if (noOfChListStatus == 1) delete [] arrayNoOfChList;
        
        if (categoryResultsHoldStatus == 1) delete [] arrayCategoryResultsHold;
        if (categoryRangeHoldStatus == 1) delete [] arrayCategoryRangeHold;
        
        if (progenyAnalysisResultsHoldStatus == 1) delete [] arrayProgenyAnalysisResultsHold;
        if (progenyAnalysisRangeHoldStatus == 1) delete [] arrayProgenyAnalysisRangeHold;
        
        if (trimResultsHoldStatus == 1) delete [] arrayTrimResultsHold;
        if (mergeResultsHoldStatus == 1) delete [] arrayMergeResultsHold;
        
        if (eventAnalysisResultsHoldStatus == 1) delete [] arrayEventAnalysisResultsHold;
        
        if (lineageSelectHoldStatus == 1) delete [] arrayLineageSelectHold;
        if (lineageSelectLineageHoldStatus == 1) delete [] arrayLineageSelectLineageHold;
        
        if (progenyDoubleCompHoldStatus == 1) delete [] arrayDoubleCompRangeHold;
        
        if (progenyDoubleCompResultsHoldStatus == 1) delete [] arrayProgenyDoubleCompResultsHold;
        
        if (motilityResultsHoldStatus == 1) delete [] arrayMotilityResultsHold;
        
        if (simListHoldStatus == 1) delete [] arraySimListHold;
        if (fitDataHoldStatus == 1) delete [] arrayFitDataHold;
        
        if (directoryInfoLimit != 0) delete [] arrayDirectoryInfo;
        
        exit (0);
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)dataSave{
    string analysisIDPath = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults/"+arrayTableMain [tableCurrentRowHold][4]+"_Results";
    
    string savePath;
    
    ofstream oin;
    
    if (includeExcludeModification == 1){
        for (int counter1 = 0; counter1 < ifTimeExtractCount; counter1++) arrayIfTimeStatus [tableCurrentRowHold][counter1] = ifTimeExtract [counter1];
        
        savePath = analysisIDPath+"/IFDataStatus";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < ifTimeExtractCount; counter1++){
            oin<<arrayIfTimeStatus [tableCurrentRowHold][counter1]<<endl;
        }
        
        oin.close();
    }
    
    if (lineageModification == 1){
        int *lineageList1 = new int [maxLingNo+1];
        int *lineageList2 = new int [maxLingNo+1];
        int lineageListCount2 = 0;
        
        for (int counter1 = 0; counter1 < maxLingNo+1; counter1++){
            lineageList1 [counter1] = 0;
            lineageList2 [counter1] = 0;
        }
        
        for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
            lineageList1 [holdReviseLineage [counter2*9+6]]++;
        }
        
        for (int counter2 = 1; counter2 < maxLingNo+1; counter2++){
            if (lineageList1 [counter2] != 0){
                lineageList2 [lineageListCount2] = counter2, lineageListCount2++;
            }
        }
        
        int *lineageExtractTemp = new int [arrayLineageDataEntryHold [tableCurrentRowHold]+50];
        int lineageExtractTempCount = 0;
        int findFlag = 0;
        
        for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter1++){
            findFlag = 0;
            
            for (int counter2 = 0; counter2 < lineageListCount2; counter2++){
                if (arrayLineageData [tableCurrentRowHold][counter1*9+6] == lineageList2 [counter2]){
                    findFlag = 1;
                    break;
                }
            }
            
            if (findFlag == 0){
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+1], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+2], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+3], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+4], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+5], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+6], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+7], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+8], lineageExtractTempCount++;
            }
        }
        
        for (unsigned long counter1 = 0; counter1 < holdReviseLineageCount/9; counter1++){
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+1], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+2], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+3], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+4], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+5], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+6], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+7], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+8], lineageExtractTempCount++;
        }
        
        for (int counter1 = 0; counter1 < lineageExtractTempCount; counter1++) arrayLineageData [tableCurrentRowHold][counter1] = lineageExtractTemp [counter1];
        
        savePath = analysisIDPath+"/"+"LineageDataAnalysis";
        
        char *writingArray = new char [arrayLineageDataEntryHold [tableCurrentRowHold]/9*28+100];
        
        long indexCount = 0;
        int readBit [4];
        int dataTemp;
        
        for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter1++){
            if (arrayLineageData [tableCurrentRowHold][counter1*9] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9];
            }
            
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            if (arrayLineageData [tableCurrentRowHold][counter1*9+1] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+1]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+1];
            }
            
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+2];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayLineageData [tableCurrentRowHold][counter1*9+3], indexCount++;
            
            if (arrayLineageData [tableCurrentRowHold][counter1*9+4] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+4]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+4];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            if (arrayLineageData [tableCurrentRowHold][counter1*9+5] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+5]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+5];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+7];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayLineageData [tableCurrentRowHold][counter1*9+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 28; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile (savePath.c_str(), ofstream::binary);
        outfile.write ((char*) writingArray, indexCount);
        outfile.close();
        
        delete [] writingArray;
        delete [] lineageExtractTemp;
        
        int *ifExtractTemp = new int [arrayIFDataEntryHold [tableCurrentRowHold]+50];
        int ifExtractTempCount = 0;
        
        for (int counter1 = 0; counter1 < arrayIFDataEntryHold [tableCurrentRowHold]/22; counter1++){
            findFlag = 0;
            
            for (int counter2 = 0; counter2 < lineageListCount2; counter2++){
                if (arrayIFData [tableCurrentRowHold][counter1*22+1] == lineageList2 [counter2]){
                    findFlag = 1;
                    break;
                }
            }
            
            if (findFlag == 0){
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+1], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+2], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+3], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+4], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+5], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+6], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+7], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+8], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+9], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+10], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+11], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+12], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+13], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+14], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+15], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+16], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+17], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+18], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+19], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+20], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+21], ifExtractTempCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < holdReviseIfDataCount/22; counter1++){
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+1], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+2], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+3], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+4], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+5], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+6], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+7], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+8], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+9], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+10], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+11], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+12], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+13], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+14], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+15], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+16], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+17], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+18], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+19], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+20], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+21], ifExtractTempCount++;
        }
        
        for (int counter1 = 0; counter1 < ifExtractTempCount; counter1++) arrayIFData [tableCurrentRowHold][counter1] = ifExtractTemp [counter1];
        
        savePath = analysisIDPath+"/"+"IFData";
        
        writingArray = new char [arrayIFDataEntryHold [tableCurrentRowHold]/22*60+60];
        
        indexCount = 0;
        
        for (int counter1 = 0; counter1 < arrayIFDataEntryHold [tableCurrentRowHold]/22; counter1++){
            if (arrayIFData [tableCurrentRowHold][counter1*22] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayIFData [tableCurrentRowHold][counter1*22]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayIFData [tableCurrentRowHold][counter1*22];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+1];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+2];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+3], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+4], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+5];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+7], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+9];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+10], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+11];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+12];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+13], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+14];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+15];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+16], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+17];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+18];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [tableCurrentRowHold][counter1*22+19], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+20];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [tableCurrentRowHold][counter1*22+21];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 33; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (savePath.c_str(), ofstream::binary);
        outfile2.write ((char*) writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
        delete [] ifExtractTemp;
        
        int *areaExtractTemp = new int [arrayAreaDataHold [tableCurrentRowHold]+50];
        int areaExtractTempCount = 0;
        
        for (int counter1 = 0; counter1 < arrayAreaDataHold [tableCurrentRowHold]/5; counter1++){
            findFlag = 0;
            
            for (int counter2 = 0; counter2 < lineageListCount2; counter2++){
                if (arrayAreaData [tableCurrentRowHold][counter1*5] == lineageList2 [counter2]){
                    findFlag = 1;
                    break;
                }
            }
            
            if (findFlag == 0){
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+1], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+2], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+3], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+4], areaExtractTempCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < holdReviseAreaDataCount/5; counter1++){
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+1], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+2], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+3], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+4], areaExtractTempCount++;
        }
        
        for (int counter1 = 0; counter1 < areaExtractTempCount; counter1++) arrayAreaData [tableCurrentRowHold][counter1] = areaExtractTemp [counter1];
        
        savePath = analysisIDPath+"/"+"AreaData";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < arrayAreaDataHold [tableCurrentRowHold]; counter1++){
            oin<<arrayAreaData [tableCurrentRowHold][counter1]<<endl;
        }
        
        oin.close();
        
        delete [] areaExtractTemp;
        
        for (int counter1 = 0; counter1 < lineageLinkHold [counter1]; counter1++){
            arrayLineageLink [tableCurrentRowHold][counter1] = arrayLineageLinkList [counter1];
        }
        
        savePath = analysisIDPath+"/"+"LinkData";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < lineageLinkHold [tableCurrentRowHold]; counter1++){
            oin<<arrayLineageLink [tableCurrentRowHold][counter1]<<endl;
        }
        
        oin.close();
        
        delete [] lineageList1;
        delete [] lineageList2;
    }
}

-(void)dataSave2:(int)type :(int)number{
    string analysisIDPath;
    string typeFind;
    string treatNameSave;
    
    if (type == 1){
        typeFind = "AN";
        
        treatNameSave = arrayTableMain [tableCurrentRowHold][4].substr(arrayTableMain [tableCurrentRowHold][4].find("-")+1);
        analysisIDPath = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults/"+"AN"+to_string(number)+"-"+treatNameSave+"_Results";
        
    }
    else if (type == 2){
        typeFind = arrayTableMain [tableCurrentRowHold][4].substr(0, 2);
        treatNameSave = arrayTableMain [tableCurrentRowHold][4].substr(arrayTableMain [tableCurrentRowHold][4].find("-")+1);
        
        analysisIDPath = analysisDataFolderPath+"/"+arrayTableMain [tableCurrentRowHold][2]+"_AnalysisResults/"+arrayTableMain [tableCurrentRowHold][3]+"_IDResults/"+typeFind+to_string(number)+"-"+treatNameSave+"_Results";
    }
    
    if (lineageDataEntryCount+1 < 101){
        //----Lineage data: Array set----
        delete [] arrayLineageData [lineageDataEntryCount];
        arrayLineageData [lineageDataEntryCount] = new int [arrayLineageDataEntryHold [tableCurrentRowHold]+10];
        
        int *lineageList1 = new int [maxLingNo+1];
        int *lineageList2 = new int [maxLingNo+1];
        int lineageListCount2 = 0;
        
        for (int counter1 = 0; counter1 < maxLingNo+1; counter1++){
            lineageList1 [counter1] = 0;
            lineageList2 [counter1] = 0;
        }
        
        //for (int counterA = 0; counterA < holdReviseLineageCount/9; counterA++){
        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<holdReviseLineage [counterA*9+counterB];
        //    cout<<" holdReviseLineage "<<counterA<<endl;
        //}
        
        for (unsigned long counter2 = 0; counter2 < holdReviseLineageCount/9; counter2++){
            lineageList1 [holdReviseLineage [counter2*9+6]]++;
        }
        
        for (int counter2 = 1; counter2 < maxLingNo+1; counter2++){
            if (lineageList1 [counter2] != 0){
                lineageList2 [lineageListCount2] = counter2, lineageListCount2++;
            }
        }
        
        int *lineageExtractTemp = new int [arrayLineageDataEntryHold [tableCurrentRowHold]+50];
        int lineageExtractTempCount = 0;
        int findFlag = 0;
        
        for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [tableCurrentRowHold]/9; counter1++){
            findFlag = 0;
            
            for (int counter2 = 0; counter2 < lineageListCount2; counter2++){
                if (arrayLineageData [tableCurrentRowHold][counter1*9+6] == lineageList2 [counter2]){
                    findFlag = 1;
                    break;
                }
            }
            
            if (findFlag == 0){
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+1], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+2], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+3], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+4], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+5], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+6], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+7], lineageExtractTempCount++;
                lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [tableCurrentRowHold][counter1*9+8], lineageExtractTempCount++;
            }
        }
        
        for (unsigned long counter1 = 0; counter1 < holdReviseLineageCount/9; counter1++){
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+1], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+2], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+3], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+4], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+5], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+6], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+7], lineageExtractTempCount++;
            lineageExtractTemp [lineageExtractTempCount] = holdReviseLineage [counter1*9+8], lineageExtractTempCount++;
        }
        
        //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
        //    cout<<" lineageExtractTemp"<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < lineageExtractTempCount; counter1++) arrayLineageData [lineageDataEntryCount][counter1] = lineageExtractTemp [counter1];
        
        arrayLineageDataEntryHold [lineageDataEntryCount] = arrayLineageDataEntryHold [tableCurrentRowHold];
        
        //----IF data: Array set----
        delete [] arrayIFData [lineageDataEntryCount];
        arrayIFData [lineageDataEntryCount] = new int [arrayIFDataEntryHold [tableCurrentRowHold]+10];
        
        int *ifExtractTemp = new int [arrayIFDataEntryHold [tableCurrentRowHold]+50];
        int ifExtractTempCount = 0;
        
        for (int counter1 = 0; counter1 < arrayIFDataEntryHold [tableCurrentRowHold]/22; counter1++){
            findFlag = 0;
            
            for (int counter2 = 0; counter2 < lineageListCount2; counter2++){
                if (arrayIFData [tableCurrentRowHold][counter1*22+1] == lineageList2 [counter2]){
                    findFlag = 1;
                    break;
                }
            }
            
            if (findFlag == 0){
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+1], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+2], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+3], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+4], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+5], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+6], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+7], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+8], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+9], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+10], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+11], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+12], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+13], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+14], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+15], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+16], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+17], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+18], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+19], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+20], ifExtractTempCount++;
                ifExtractTemp [ifExtractTempCount] = arrayIFData [tableCurrentRowHold][counter1*22+21], ifExtractTempCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < holdReviseIfDataCount/22; counter1++){
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+1], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+2], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+3], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+4], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+5], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+6], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+7], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+8], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+9], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+10], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+11], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+12], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+13], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+14], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+15], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+16], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+17], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+18], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+19], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+20], ifExtractTempCount++;
            ifExtractTemp [ifExtractTempCount] = holdReviseIfData [counter1*22+21], ifExtractTempCount++;
        }
        
        //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
        //    cout<<" ifExtractTemp "<<counterA<<endl;
        //}
        
        for (int counter1 = 0; counter1 < ifExtractTempCount; counter1++) arrayIFData [lineageDataEntryCount][counter1] = ifExtractTemp [counter1];
        
        arrayIFDataEntryHold [lineageDataEntryCount] = arrayIFDataEntryHold [tableCurrentRowHold];
        
        //----IF Time line data: Array set----
        delete [] arrayIFTimeLineData [lineageDataEntryCount];
        arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataEntryHold [tableCurrentRowHold]+10];
        
        for (int counter1 = 0; counter1 < arrayIFTimeLineDataEntryHold [tableCurrentRowHold]; counter1++){
            arrayIFTimeLineData [lineageDataEntryCount][counter1] = arrayIFTimeLineData [tableCurrentRowHold][counter1];
        }
        
        arrayIFTimeLineDataEntryHold [lineageDataEntryCount] = arrayIFTimeLineDataEntryHold [tableCurrentRowHold];
        
        //----Main table data: Array set----
        delete [] arrayTableMain [lineageDataEntryCount];
        arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [tableCurrentRowHold]+10];
        
        for (int counter1 = 0; counter1 < arrayTableMainHold [tableCurrentRowHold]; counter1++) arrayTableMain [lineageDataEntryCount][counter1] = arrayTableMain [tableCurrentRowHold][counter1];
        
        arrayTableMain [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
        arrayTableMain [lineageDataEntryCount][4] = typeFind+to_string(number)+"-"+treatNameSave;
        
        arrayTableMainHold [lineageDataEntryCount] = arrayTableMainHold [tableCurrentRowHold];
        
        //----Detail table data: Array set----
        for (int counter1 = 0; counter1 < 17; counter1++) arrayTableDetail [lineageDataEntryCount][counter1] = arrayTableDetail [tableCurrentRowHold][counter1];
        
        arrayTableDetail [lineageDataEntryCount][0] = lineageDataEntryCount+1;
        
        //----IFTimeStatus table data: Array set----
        delete [] arrayIfTimeStatus [lineageDataEntryCount];
        arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [tableCurrentRowHold]+10];
        
        for (int counter1 = 0; counter1 < arrayIfTimeStatusHold [tableCurrentRowHold]; counter1++) arrayIfTimeStatus [lineageDataEntryCount][counter1] = ifTimeExtract [counter1];
        
        arrayIfTimeStatusHold [lineageDataEntryCount] = arrayIfTimeStatusHold [tableCurrentRowHold];
        
        //----AreaData: Array set----
        delete [] arrayAreaData [lineageDataEntryCount];
        arrayAreaData [lineageDataEntryCount] = new int [arrayAreaDataHold [tableCurrentRowHold]+10];
        
        int *areaExtractTemp = new int [arrayAreaDataHold [tableCurrentRowHold]+50];
        int areaExtractTempCount = 0;
        
        for (int counter1 = 0; counter1 < arrayAreaDataHold [tableCurrentRowHold]/5; counter1++){
            findFlag = 0;
            
            for (int counter2 = 0; counter2 < lineageListCount2; counter2++){
                if (arrayAreaData [tableCurrentRowHold][counter1*5] == lineageList2 [counter2]){
                    findFlag = 1;
                    break;
                }
            }
            
            if (findFlag == 0){
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+1], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+2], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+3], areaExtractTempCount++;
                areaExtractTemp [areaExtractTempCount] = arrayAreaData [tableCurrentRowHold][counter1*5+4], areaExtractTempCount++;
            }
        }
        
        for (int counter1 = 0; counter1 < holdReviseAreaDataCount/5; counter1++){
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+1], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+2], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+3], areaExtractTempCount++;
            areaExtractTemp [areaExtractTempCount] = holdReviseAreaData [counter1*5+4], areaExtractTempCount++;
        }
        
        for (int counter1 = 0; counter1 < areaExtractTempCount; counter1++) arrayAreaData [lineageDataEntryCount][counter1] = areaExtractTemp [counter1];
        
        //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
        //    cout<<" areaExtractTemp "<<counterA<<endl;
        //}
        
        arrayAreaDataHold [lineageDataEntryCount] = arrayAreaDataHold [tableCurrentRowHold];
        
        //----LinkData: Array set----
        delete [] arrayLineageLink [lineageDataEntryCount];
        arrayLineageLink [lineageDataEntryCount] = new int [lineageLinkHold [tableCurrentRowHold]+10];
        
        for (int counter1 = 0; counter1 < lineageLinkHold [tableCurrentRowHold]; counter1++){
            arrayLineageLink [lineageDataEntryCount][counter1] = arrayLineageLinkList [counter1];
        }
        
        //for (int counterA = 0; counterA < lineageLinkHold [tableCurrentRowHold]/arrayLineageLink [lineageDataEntryCount][0]; counterA++){
        //    for (int counterB = 0; counterB < arrayLineageLink [lineageDataEntryCount][0]; counterB++) cout<<" "<<arrayLineageLink [lineageDataEntryCount][counterA*arrayLineageLink [lineageDataEntryCount][0]+counterB];
        //    cout<<"  arrayLineageLink  "<<counterA<<endl;
        //}
        
        lineageLinkHold [lineageDataEntryCount] = lineageLinkHold [tableCurrentRowHold];
        
        //----Lineage Data type: Array Set----
        for (int counter1 = 0; counter1 < 7; counter1++){
            arrayLineageDataType [lineageDataEntryCount][counter1] = arrayLineageDataType [tableCurrentRowHold][counter1];
        }
        
        arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
        arrayLineageDataType [lineageDataEntryCount][1] = typeFind;
        
        //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
        //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" LingType" <<endl;
        //}
        
        //----LineageFluorescentDataType: Array Set----
        int fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
        
        for (int counter1 = 0; counter1 < fluorescentDataEntryCount; counter1++){
            if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
            
            if (atoi(arrayLineageFluorescentDataType [counter1][0].c_str()) == tableCurrentRowHold){
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter1][1];
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter1][2];
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter1][3];
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter1][4];
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter1][5];
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter1][6];
                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter1][7];
                
                lineageFluorescentDataTypeEntryCount++;
            }
        }
        
        //----Data save----
        ofstream oin;
        
        string savePath = analysisIDPath+"/"+"*LineageDataAddition.dat";
        
        oin.open(savePath.c_str(), ios::out);
        oin<<arrayLineageDataType [lineageDataEntryCount][0]<<endl;
        oin<<typeFind<<endl;
        oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
        oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
        oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
        oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
        oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
        
        for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
            if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == lineageDataEntryCount+1){
                oin<<arrayLineageFluorescentDataType [counter2][0]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][1]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][2]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][3]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][4]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][5]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][6]<<endl;
                oin<<arrayLineageFluorescentDataType [counter2][7]<<endl;
            }
        }
        
        oin.close();
        
        savePath = analysisIDPath+"/IFDataStatus";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < ifTimeExtractCount; counter1++){
            oin<<arrayIfTimeStatus [lineageDataEntryCount][counter1]<<endl;
        }
        
        oin.close();
        
        savePath = analysisIDPath+"/"+"LineageDataAnalysis";
        
        char *writingArray = new char [arrayLineageDataEntryHold [lineageDataEntryCount]/9*28+100];
        
        long indexCount = 0;
        int readBit [4];
        int dataTemp;
        
        for (unsigned long counter1 = 0; counter1 < arrayLineageDataEntryHold [lineageDataEntryCount]/9; counter1++){
            if (arrayLineageData [lineageDataEntryCount][counter1*9] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9];
            }
            
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            if (arrayLineageData [lineageDataEntryCount][counter1*9+1] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+1]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+1];
            }
            
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+2];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayLineageData [lineageDataEntryCount][counter1*9+3], indexCount++;
            
            if (arrayLineageData [lineageDataEntryCount][counter1*9+4] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+4]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+4];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            if (arrayLineageData [lineageDataEntryCount][counter1*9+5] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+5]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+5];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+7];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayLineageData [lineageDataEntryCount][counter1*9+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 28; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile (savePath.c_str(), ofstream::binary);
        outfile.write ((char*) writingArray, indexCount);
        outfile.close();
        
        delete [] writingArray;
        
        savePath = analysisIDPath+"/"+"IFData";
        
        writingArray = new char [arrayIFDataEntryHold [lineageDataEntryCount]/22*60+60];
        
        indexCount = 0;
        
        for (int counter1 = 0; counter1 < arrayIFDataEntryHold [lineageDataEntryCount]/22; counter1++){
            if (arrayIFData [lineageDataEntryCount][counter1*22] < 0){
                writingArray [indexCount] = 1, indexCount++;
                dataTemp = arrayIFData [lineageDataEntryCount][counter1*22]*-1;
            }
            else{
                
                writingArray [indexCount] = 0, indexCount++;
                dataTemp = arrayIFData [lineageDataEntryCount][counter1*22];
            }
            
            readBit [0] = dataTemp/16777216;
            dataTemp = dataTemp%16777216;
            readBit [1] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [2] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [3] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            writingArray [indexCount] = (char)readBit [3], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+1];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+2];
            readBit [0] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [1] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+3], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+4], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+5];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+6];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+7], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+8];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+9];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+10], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+11];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+12];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+13], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+14];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+15];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+16], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+17];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+18];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount][counter1*22+19], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+20];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
            
            dataTemp = arrayIFData [lineageDataEntryCount][counter1*22+21];
            readBit [0] = dataTemp/65536;
            dataTemp = dataTemp%65536;
            readBit [1] = dataTemp/256;
            dataTemp = dataTemp%256;
            readBit [2] = dataTemp;
            
            writingArray [indexCount] = (char)readBit [0], indexCount++;
            writingArray [indexCount] = (char)readBit [1], indexCount++;
            writingArray [indexCount] = (char)readBit [2], indexCount++;
        }
        
        for (int counter1 = 0; counter1 < 33; counter1++) writingArray [indexCount] = 0, indexCount++;
        
        ofstream outfile2 (savePath.c_str(), ofstream::binary);
        outfile2.write ((char*) writingArray, indexCount);
        outfile2.close();
        
        delete [] writingArray;
        
        savePath = analysisIDPath+"/"+"AreaData";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < arrayAreaDataHold [lineageDataEntryCount]; counter1++){
            oin<<arrayAreaData [lineageDataEntryCount][counter1]<<endl;
        }
        
        oin.close();
        
        savePath = analysisIDPath+"/"+"LinkData";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < lineageLinkHold [lineageDataEntryCount]; counter1++){
            oin<<arrayLineageLink [lineageDataEntryCount][counter1]<<endl;
        }
        
        oin.close();
        
        savePath = analysisIDPath+"/"+"MainTable";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < arrayTableMainHold [lineageDataEntryCount]; counter1++){
            oin<<arrayTableMain [lineageDataEntryCount][counter1]<<endl;
        }
        
        oin.close();
        
        savePath = analysisIDPath+"/"+"DetailTable";
        
        oin.open(savePath.c_str(), ios::out | ios::binary);
        
        for (int counter1 = 0; counter1 < 17; counter1++){
            oin<<arrayTableDetail [lineageDataEntryCount][counter1]<<endl;
        }
        
        oin.close();
        
        delete [] lineageExtractTemp;
        delete [] ifExtractTemp;
        delete [] areaExtractTemp;
        delete [] lineageList1;
        delete [] lineageList2;
        
        arraySelectedLing [lineageDataEntryCount] = 1;
        tableCurrentRowHold = lineageDataEntryCount;
        
        lineageDataEntryCount++;
    }
}

-(IBAction)searchOperationStart:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (searchWindowOperation == 0){
                searchWindowOperation = 1;
                
                if (searchResultsHoldStatus == 0){
                    arraySearchResultsHold = new string [600];
                    searchResultsHoldStatus = 1;
                    searchResultsHoldCount = 0;
                    searchResultsHoldLimit = 600;
                }
                
                if (displayForSearchStatus == 0){
                    arrayDisplayForSearch = new string [600];
                    displayForSearchStatus = 1;
                    displayForSearchCount = 0;
                    displayForSearchLimit = 600;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToSearchController object:self];
            }
            
            if (searchWindowOperation == 2) searchWindowOperation = 3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)printPDF:(id)sender{
    if (initialArraySet == 1){
        exportFlag1 = 1;
        
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Map";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
        string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
        string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
        string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-LM";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("LM")+2, entry.find(".tif")-entry.find("LM")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        exportResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".tif";
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainLineage object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)printAllPDF:(id)sender{
    if (initialArraySet == 1){
        if (exportFlag1 == 0) exportTiming = 101;
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageLowDataExport:(id)sender{
    if (initialArraySet == 1){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Data";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
        string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
        string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
        string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-DA";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("DA")+2, entry.find(".txt")-entry.find("DA")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string lowLingResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
        
        int currentSeriesNo = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (arraySelectedLing [counter1] == 1){
                currentSeriesNo = counter1;
                break;
            }
        }
        
        double *arrayLineageDataLing = new double [5000];
        
        ofstream oin;
        oin.open(lowLingResultPath.c_str(), ios::out | ios::binary);
        
        int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "X Position";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Y Position";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Time";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Event type";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Parent cell-Fused cell No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Cell No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Ling No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Fused ling No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        oin.put(13);
        oin.put(10);
        
        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [currentSeriesNo]/9; counter3++){
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+1]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+2]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+4]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+5]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+6]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayLineageData [currentSeriesNo][counter3*9+7]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        oin.close();
        
        delete [] arrayLineageDataLing;
        
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageFluorescentDataExport:(id)sender{
    if (initialArraySet == 1){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Fluorescent_Data";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
        string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
        string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
        string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-FA";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("FA")+2, entry.find(".txt")-entry.find("FA")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string lowLingResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
        
        int currentSeriesNo = 0;
        
        for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
            if (arraySelectedLing [counter1] == 1){
                currentSeriesNo = counter1;
                break;
            }
        }
        
        //========Fluorescent data=======
        long *cellEventTypeList = new long [20000000];
        int cellEventTypeListCount = 0;
        int cellEventTypeListLimit = 20000000;
        
        int cellNoTemp = 0;
        int lingNoTemp = 0;
        int firstTimeFlag = 0;
        
        for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [currentSeriesNo]/9; counter2++){
            if ((cellNoTemp != arrayLineageData [currentSeriesNo][counter2*9+5] || lingNoTemp != arrayLineageData [currentSeriesNo][counter2*9+6]) && firstTimeFlag == 0){
                cellNoTemp = arrayLineageData [currentSeriesNo][counter2*9+5];
                lingNoTemp = arrayLineageData [currentSeriesNo][counter2*9+6];
                firstTimeFlag = 1;
                
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //---Type
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+6], cellEventTypeListCount++; //---Ling
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+5], cellEventTypeListCount++; //---Cell
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+3], cellEventTypeListCount++; //---Event start
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //---Event end
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+2], cellEventTypeListCount++; //---Time start
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //---Time end
                
                if (arrayLineageData [currentSeriesNo][counter2*9+3] == 1) cellEventTypeList [cellEventTypeListCount] = -1, cellEventTypeListCount++;
                else cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+4], cellEventTypeListCount++; //---Parent Cell no
                
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //---Fusion 92 mark
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //Sorting mark
                
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //Partner Ling-Fuse
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++; //Partner Cell-Fuse
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
            }
            else if (cellNoTemp == arrayLineageData [currentSeriesNo][counter2*9+5] && lingNoTemp == arrayLineageData [currentSeriesNo][counter2*9+6] && arrayLineageData [currentSeriesNo][counter2*9+3] == 92 && firstTimeFlag == 1){
                cellEventTypeList [cellEventTypeListCount-5] = 1;
            }
            else if ((cellNoTemp != arrayLineageData [currentSeriesNo][counter2*9+5] || lingNoTemp != arrayLineageData [currentSeriesNo][counter2*9+6]) && firstTimeFlag == 1){
                cellEventTypeList [cellEventTypeListCount-9] = arrayLineageData [currentSeriesNo][(counter2-1)*9+3];
                cellEventTypeList [cellEventTypeListCount-7] = arrayLineageData [currentSeriesNo][(counter2-1)*9+2];
                
                if (arrayLineageData [currentSeriesNo][(counter2-1)*9+3] == 91){
                    cellEventTypeList [cellEventTypeListCount-3] = arrayLineageData [currentSeriesNo][(counter2-1)*9+7];
                    cellEventTypeList [cellEventTypeListCount-2] = arrayLineageData [currentSeriesNo][(counter2-1)*9+4];
                }
                
                cellNoTemp = arrayLineageData [currentSeriesNo][counter2*9+5];
                lingNoTemp = arrayLineageData [currentSeriesNo][counter2*9+6];
                
                if (cellEventTypeListCount+50 > cellEventTypeListLimit){
                    long *arrayUpDate = new long [cellEventTypeListCount+12];
                    
                    for (int counter3 = 0; counter3 < cellEventTypeListCount; counter3++) arrayUpDate [counter3] = cellEventTypeList [counter3];
                    
                    delete [] cellEventTypeList;
                    cellEventTypeList = new long [cellEventTypeListLimit+1000000];
                    cellEventTypeListLimit = cellEventTypeListLimit+1000000;
                    
                    for (int counter3 = 0; counter3 < cellEventTypeListCount; counter3++) cellEventTypeList [counter3] = arrayUpDate [counter3];
                    delete [] arrayUpDate;
                }
                
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+6], cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+5], cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+3], cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+2], cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                
                if (arrayLineageData [currentSeriesNo][counter2*9+3] == 1) cellEventTypeList [cellEventTypeListCount] = -1, cellEventTypeListCount++;
                else cellEventTypeList [cellEventTypeListCount] = arrayLineageData [currentSeriesNo][counter2*9+4], cellEventTypeListCount++; //---Parent Cell no
                
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
            }
            else if (counter2 == arrayLineageDataEntryHold [currentSeriesNo]/9-1 && firstTimeFlag == 1){
                cellEventTypeList [cellEventTypeListCount-9] = arrayLineageData [currentSeriesNo][counter2*9+3];
                cellEventTypeList [cellEventTypeListCount-7] = arrayLineageData [currentSeriesNo][counter2*9+2];
                
                if (arrayLineageData [currentSeriesNo][counter2*9+3] == 91){
                    cellEventTypeList [cellEventTypeListCount-3] = arrayLineageData [currentSeriesNo][counter2*9+7];
                    cellEventTypeList [cellEventTypeListCount-2] = arrayLineageData [currentSeriesNo][counter2*9+4];
                }
            }
        }
        
        //for (int counterA = 0; counterA < cellEventTypeListCount/13; counterA++){
        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<cellEventTypeList [counterA*13+counterB];
        //    cout<<" cellEventTypeList "<<counterA<<endl;
        //}
        
        //=======Sort array based on the lineage number=====
        //1.Type
        //2.Ling
        //3.Cell
        //4.Event start
        //5.Event end
        //6.Time start
        //7.Time end
        //8.Parent
        //9.Fusion92/fluorescent value entry count/cells status, 1: time one use, 2: non time one, 3: not use, 4: necrotic
        //10.Fluorescent set mark/saturation
        //11.Fluorescent value
        //12.C fluorescent color no select
        //13.T.color no select
        //14.F.color no select
        //15.TB.color no select
        //16.Fluorescent ch color no Heat Map
        //17.Ling color RGB255
        //18.Ling color RGB255
        //19.Ling color RGB255
        //20.Nature
        //21.Open
        //22.Open
        //23.Open
        
        double *lingTemp = new double [cellEventTypeListCount+20];
        double *cellTemp = new double [cellEventTypeListCount+20];
        
        double *cellEventTypeListTemp = new double [cellEventTypeListCount+20];
        int cellEventTypeListTempCount = 0;
        
        int lineageEntry = 0;
        int cellEntry = 0;
        int terminationFlag = 0;
        int terminationFlag2 = 0;
        int findFlag2 = 0;
        int lingTempCount = 0;
        int cellTempCount = 0;
        int terminationFlag3 = 0;
        int findFlag3 = 0;
        int lowestCellNo = 0;
        int lowestCellNoPosition = 0;
        
        do{
            
            terminationFlag2 = 0;
            findFlag2 = 0;
            lingTempCount = 0;
            
            lineageEntry++;
            
            for (int counter3 = 0; counter3 < cellEventTypeListCount/13; counter3++){
                if (cellEventTypeList [counter3*13+12] != 1 && cellEventTypeList [counter3*13+1] == lineageEntry){
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+1], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+2], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+3], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+4], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+5], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+6], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+7], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+8], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+9], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+10], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+11], lingTempCount++;
                    lingTemp [lingTempCount] = cellEventTypeList [counter3*13+12], lingTempCount++;
                    
                    cellEventTypeList [counter3*13+12] = 1;
                }
            }
            
            //for (int counterA = 0; counterA < lingTempCount/13; counterA++){
            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<lingTemp [counterA*13+counterB];
            //    cout<<" lingTemp "<<counterA<<endl;
            //}
            
            for (int counter3 = 0; counter3 < cellEventTypeListCount/13; counter3++){
                if (cellEventTypeList [counter3*13+12] == 0) findFlag2 = 1;
            }
            
            if (findFlag2 == 0) terminationFlag2 = 1;
            
            if (lingTempCount != 0){
                cellTempCount = 0;
                
                do{
                    
                    terminationFlag3 = 0;
                    findFlag3 = 0;
                    
                    cellEntry++;
                    
                    lowestCellNo = 999999999;
                    lowestCellNoPosition = -1;
                    
                    for (int counter3 = 0; counter3 < lingTempCount/13; counter3++){
                        if (lingTemp [counter3*13+12] != 1){
                            if (lingTemp [counter3*13+2] < lowestCellNo){
                                lowestCellNo = (int)lingTemp [counter3*13+2];
                                lowestCellNoPosition = counter3;
                            }
                        }
                    }
                    
                    if (lowestCellNoPosition != -1){
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+1], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+2], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+3], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+4], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+5], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+6], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+7], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+8], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+9], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+10], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+11], cellTempCount++;
                        cellTemp [cellTempCount] = lingTemp [lowestCellNoPosition*13+12], cellTempCount++;
                        
                        lingTemp [lowestCellNoPosition*13+12] = 1;
                    }
                    
                    //for (int counterA = 0; counterA < cellTempCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<cellTemp [counterA*13+counterB];
                    //    cout<<" cellTemp "<<counterA<<endl;
                    //}
                    
                    for (int counter3 = 0; counter3 < lingTempCount/13; counter3++){
                        if (lingTemp [counter3*13+12] == 0) findFlag3 = 1;
                    }
                    
                    if (findFlag3 == 0){
                        terminationFlag3 = 1;
                        
                        for (int counter3 = 0; counter3 < cellTempCount/13; counter3++){
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+1], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+2], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+3], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+4], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+5], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+6], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+7], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+8], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+9], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+10], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+11], cellEventTypeListTempCount++;
                            cellEventTypeListTemp [cellEventTypeListTempCount] = cellTemp [counter3*13+12], cellEventTypeListTempCount++;
                            
                            //for (int counterA = 0; counterA < cellEventTypeListTempCount/13; counterA++){
                            //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<cellEventTypeListTemp [counterA*13+counterB];
                            //    cout<<" cellEventTypeListTemp "<<counterA<<endl;
                            //}
                        }
                    }
                    
                } while (terminationFlag3 == 0);
            }
            
        } while (terminationFlag2 == 0);
        
        cellEventTypeListCount = 0;
        
        for (int counter1 = 0; counter1 < cellEventTypeListTempCount; counter1++) cellEventTypeList [cellEventTypeListCount] = (long)cellEventTypeListTemp [counter1], cellEventTypeListCount++;
        
        //for (int counterA = 0; counterA < cellEventTypeListCount/13; counterA++){
        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<cellEventTypeList [counterA*13+counterB];
        //    cout<<" cellEventTypeList "<<counterA<<endl;
        //}
        
        delete [] lingTemp;
        delete [] cellTemp;
        delete [] cellEventTypeListTemp;
        
        long *cellEventTypeList2 = new long [cellEventTypeListCount*3+30];
        int cellEventTypeListCount2 = 0;
        
        int totalNumberOfLing = 0;
        int totalNumberOfCells = 0;
        
        for (int counter1 = 0; counter1 < cellEventTypeListCount/13; counter1++){
            if (cellEventTypeList [counter1*13+9] == 0 && cellEventTypeList [counter1*13+3] != 13){
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+1], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+2], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+3], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+4], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+5], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+6], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+7], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+8], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+10], cellEventTypeListCount2++;
                cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter1*13+11], cellEventTypeListCount2++;
                
                cellEventTypeList [counter1*13+9] = 1;
                
                totalNumberOfLing++;
                totalNumberOfCells++;
                
                for (int counter2 = 0; counter2 < cellEventTypeListCount/12; counter2++){
                    if (cellEventTypeList [counter2*13+9] == 0 && cellEventTypeList [counter2*13+3] != 13 && cellEventTypeList [counter2*13] == cellEventTypeList [counter1*13] && cellEventTypeList [counter2*13+1] == cellEventTypeList [counter1*13+1]){
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+1], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+2], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+3], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+4], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+5], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+6], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+7], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+8], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                        
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++; //cc color set, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = -1, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = 0, cellEventTypeListCount2++;
                        
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+10], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList [counter2*13+11], cellEventTypeListCount2++;
                        
                        cellEventTypeList [counter2*13+9] = 1;
                        
                        totalNumberOfCells++;
                    }
                }
            }
        }
        
        //for (int counterA = 0; counterA < cellEventTypeListCount2/23; counterA++){
        //    for (int counterB = 0; counterB < 23; counterB++) cout<<" "<<cellEventTypeList2 [counterA*23+counterB];
        //    cout<<" cellEventTypeList2 "<<counterA<<endl;
        //}
        
        delete [] cellEventTypeList;
        
        long *cellEventTypeList3 = new long [cellEventTypeListCount*3+30];
        int cellEventTypeListCount3 = 0;
        
        for (int counter1 = 0; counter1 < cellEventTypeListCount2; counter1++) cellEventTypeList3 [cellEventTypeListCount3] = cellEventTypeList2 [counter1], cellEventTypeListCount3++;
        
        int maxLineageNo = 0;
        int maxTimePoint = 0;
        
        for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++){
            if (cellEventTypeList2 [counter1*23+1] > maxLineageNo) maxLineageNo = (int)cellEventTypeList2 [counter1*23+1];
            if (cellEventTypeList2 [counter1*23+6] > maxTimePoint) maxTimePoint = (int)cellEventTypeList2 [counter1*23+6];
        }
        
        int *lineageListExp = new int [(maxLineageNo+1)*9*12+10];
        int lineageListExpCount = 0;
        
        for (int counter1 = 0; counter1 <= maxLineageNo; counter1++){
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 100000, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
            lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
        }
        
        //for (int counterA = 0; counterA < lineageListExpCount/3; counterA++){
        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<<lineageListExp [counterA*3+counterB];
        //    cout<<" lineageListExp "<<counterA<<endl;
        //}
        
        //========Event color set, 12, 13, 14========
        int lineageNumberTrack = 0;
        int lineageStartPosition = 0;
        int lineageEndPosition = 0;
        
        int *fluorescentChData = new int [13];
        
        for (int counter1 = 0; counter1 < 13; counter1++) fluorescentChData [counter1] = 0;
        
        //========IF Fluorescent color set========
        
        //----Determine max value of each CH----
        for (int counter2 = 0; counter2 < arrayIFDataEntryHold [currentSeriesNo]/22; counter2++){
            if (arrayIFData [currentSeriesNo][counter2*22+3] == 1){
                if (arrayIFData [currentSeriesNo][counter2*22+5] > fluorescentChData [1]) fluorescentChData [1] = arrayIFData [currentSeriesNo][counter2*22+5];
                if (arrayIFData [currentSeriesNo][counter2*22+8] > fluorescentChData [2]) fluorescentChData [2] = arrayIFData [currentSeriesNo][counter2*22+8];
                if (arrayIFData [currentSeriesNo][counter2*22+11] > fluorescentChData [3]) fluorescentChData [3] = arrayIFData [currentSeriesNo][counter2*22+11];
                if (arrayIFData [currentSeriesNo][counter2*22+14] > fluorescentChData [4]) fluorescentChData [4] = arrayIFData [currentSeriesNo][counter2*22+14];
                if (arrayIFData [currentSeriesNo][counter2*22+17] > fluorescentChData [5]) fluorescentChData [5] = arrayIFData [currentSeriesNo][counter2*22+17];
                if (arrayIFData [currentSeriesNo][counter2*22+20] > fluorescentChData [6]) fluorescentChData [6] = arrayIFData [currentSeriesNo][counter2*22+20];
            }
            
            if (arrayIFData [currentSeriesNo][counter2*22+3] == 2){
                if (arrayIFData [currentSeriesNo][counter2*22+5] > fluorescentChData [7]) fluorescentChData [7] = arrayIFData [currentSeriesNo][counter2*22+5];
                if (arrayIFData [currentSeriesNo][counter2*22+8] > fluorescentChData [8]) fluorescentChData [8] = arrayIFData [currentSeriesNo][counter2*22+8];
                if (arrayIFData [currentSeriesNo][counter2*22+11] > fluorescentChData [9]) fluorescentChData [9] = arrayIFData [currentSeriesNo][counter2*22+11];
                if (arrayIFData [currentSeriesNo][counter2*22+14] > fluorescentChData [10]) fluorescentChData [10] = arrayIFData [currentSeriesNo][counter2*22+14];
                if (arrayIFData [currentSeriesNo][counter2*22+17] > fluorescentChData [11]) fluorescentChData [11] = arrayIFData [currentSeriesNo][counter2*22+17];
                if (arrayIFData [currentSeriesNo][counter2*22+20] > fluorescentChData [12]) fluorescentChData [12] = arrayIFData [currentSeriesNo][counter2*22+20];
            }
        }
        
        //for (int counterA = 0; counterA < arrayIFDataEntryHold [currentSeriesNo]/22; counterA++){
        //    for (int counterB = 0; counterB < 22; counterB++) cout<<" "<<arrayIFData [currentSeriesNo] [counterA*22+counterB];
        //    cout<<" arrayIFData "<<counterA<<endl;
        //}
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        ofstream oin;
        oin.open(lowLingResultPath.c_str(), ios::out | ios::binary);
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        int firstEntry = 0;
        int liveIFType = 0;
        int siblingsCount = 0;
        int siblingsCheck = 0;
        int parentCellPosition = 0;
        int tempInfoHoldCount = 0;
        int tempValueHold = 0;
        int tempValueHold2 = 0;
        
        //----Assign fluorescent values to each cell; if more than two entries, sum the values and mark entry count as 8----
        for (int counter0 = 1; counter0 <= 12; counter0++){
            if (fluorescentChData [counter0] != 0){
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++) cellEventTypeList2 [counter1*23+8] = 0;
                
                firstTimeFlag = 0;
                
                if (counter0 <= 6) liveIFType = 1;
                else liveIFType = 2;
                
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++){
                    if (firstTimeFlag == 0){
                        firstTimeFlag = 1;
                        lineageStartPosition = counter1;
                    }
                    else if (counter1 == cellEventTypeListCount2/23-1 && firstTimeFlag == 1){
                        if (counter1 == cellEventTypeListCount2/23-1) lineageEndPosition = counter1;
                        else lineageEndPosition = counter1-1;
                        
                        if (counter0 > 0){
                            for (int counter2 = 0; counter2 < arrayIFDataEntryHold [currentSeriesNo]/22; counter2++){
                                for (int counter3 = lineageStartPosition; counter3 <= lineageEndPosition; counter3++){
                                    if (arrayIFData [currentSeriesNo][counter2*22] == cellEventTypeList2 [counter3*23+2] && arrayIFData [currentSeriesNo][counter2*22+1] == cellEventTypeList2 [counter3*23+1] && arrayIFData [currentSeriesNo][counter2*22+3] == liveIFType){
                                        
                                        if (cellEventTypeList2 [counter3*23+10] == -1) cellEventTypeList2 [counter3*23+10] = 0;
                                        
                                        if (counter0 == 1 || counter0 == 7){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [counter3*23+10]+arrayIFData [currentSeriesNo][counter2*22+5];
                                        }
                                        else if (counter0 == 2 || counter0 == 8){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [counter3*23+10]+arrayIFData [currentSeriesNo][counter2*22+8];
                                        }
                                        else if (counter0 == 3 || counter0 == 9){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [counter3*23+10]+arrayIFData [currentSeriesNo][counter2*22+11];
                                        }
                                        else if (counter0 == 4 || counter0 == 10){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [counter3*23+10]+arrayIFData [currentSeriesNo][counter2*22+14];
                                        }
                                        else if (counter0 == 5 || counter0 == 11){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [counter3*23+10]+arrayIFData [currentSeriesNo][counter2*22+17];
                                        }
                                        else if (counter0 == 6 || counter0 == 12){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [counter3*23+10]+arrayIFData [currentSeriesNo][counter2*22+20];
                                        }
                                        
                                        cellEventTypeList2 [counter3*23+8]++;
                                        break;
                                    }
                                }
                            }
                            
                            for (int counter3 = lineageStartPosition; counter3 <= lineageEndPosition; counter3++){
                                if (cellEventTypeList2 [counter3*23+8] > 0){
                                    cellEventTypeList2 [counter3*23+10] = (int)(cellEventTypeList2 [counter3*23+10]/(double)cellEventTypeList2 [counter3*23+8]);
                                }
                            }
                        }
                        
                        lineageStartPosition = counter1;
                    }
                }
                
                //for (int counterA = 0; counterA < cellEventTypeListCount2/23; counterA++){
                //    for (int counterB = 0; counterB < 23; counterB++) cout<<" "<<cellEventTypeList2 [counterA*23+counterB];
                //    cout<<" cellEventTypeList2 "<<counterA<<endl;
                //}
                
                //----If the end is CD, OF, FU91, or time end 2 (no fluorescent value), enter 0 and mark 10----
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++){
                    if (cellEventTypeList2 [counter1*23+10] != -1) cellEventTypeList2 [counter1*23+9] = 1; //IF value set
                    else cellEventTypeList2 [counter1*23+9] = 0; //No value set
                    
                    if (cellEventTypeList2 [counter1*23+4] == 7 || cellEventTypeList2 [counter1*23+4] == 8 || cellEventTypeList2 [counter1*23+4] == 91){
                        if (cellEventTypeList2 [counter1*23+10] == -1){
                            cellEventTypeList2 [counter1*23+10] = 0;
                            cellEventTypeList2 [counter1*23+9] = 10; //CD/OF/FU temp value set
                        }
                    }
                    
                    if (cellEventTypeList2 [counter1*23+4] == 2 && cellEventTypeList2 [counter1*23+10] == -1){
                        cellEventTypeList2 [counter1*23+10] = 0;
                        cellEventTypeList2 [counter1*23+9] = 10; //end no IF
                    }
                }
                
                //for (int counterA = 0; counterA < cellEventTypeListCount2/23; counterA++){
                //    for (int counterB = 0; counterB < 23; counterB++) cout<<" "<<cellEventTypeList2 [counterA*23+counterB];
                //    cout<<" cellEventTypeList2 "<<counterA<<endl;
                //}
                
                //---- Trace backwards to find siblings and calculate value for parent. If a parent already has a value, do not change it----
                //----If all siblings have no value (mark as 10), keep as zero and mark as 11; if any sibling has a value, take that value and mark as -3----
                
                lineageNumberTrack = 0;
                firstTimeFlag = 0;
                siblingsCount = 0;
                
                int *tempInfoHold = new int [15];
                
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++){
                    if (cellEventTypeList2 [counter1*23+1] != lineageNumberTrack && firstTimeFlag == 0){
                        lineageNumberTrack = (int)cellEventTypeList2 [counter1*23+1];
                        firstTimeFlag = 1;
                        lineageStartPosition = counter1;
                    }
                    else if ((cellEventTypeList2 [counter1*23+1] != lineageNumberTrack || counter1 == cellEventTypeListCount2/23-1) && firstTimeFlag == 1){
                        if (counter1 == cellEventTypeListCount2/23-1) lineageEndPosition = counter1;
                        else lineageEndPosition = counter1-1;
                        
                        do{
                            
                            terminationFlag = 0;
                            
                            for (int counter3 = lineageStartPosition; counter3 <= lineageEndPosition; counter3++){
                                if (cellEventTypeList2 [counter3*23+9] == 1 || cellEventTypeList2 [counter3*23+9] == 10){
                                    if (cellEventTypeList2 [counter3*23+7] == -1){
                                        cellEventTypeList2 [counter3*23+9] = -3;
                                    }
                                    else{
                                        
                                        if (cellEventTypeList2 [counter3*23+3] == 31) siblingsCount = 2;
                                        else if (cellEventTypeList2 [counter3*23+3] == 41) siblingsCount = 3;
                                        else if (cellEventTypeList2 [counter3*23+3] == 51) siblingsCount = 4;
                                        
                                        siblingsCheck = 0;
                                        parentCellPosition = 0;
                                        
                                        for (int counter4 = lineageStartPosition; counter4 <= lineageEndPosition; counter4++){
                                            if (cellEventTypeList2 [counter3*23+7] == cellEventTypeList2 [counter4*23+7] && (cellEventTypeList2 [counter4*23+9] == 1 || cellEventTypeList2 [counter4*23+9] == 10)){
                                                siblingsCheck++;
                                            }
                                            
                                            if (cellEventTypeList2 [counter3*23+7] == cellEventTypeList2 [counter4*23+2]){
                                                parentCellPosition = counter4;
                                            }
                                        }
                                        
                                        if (siblingsCheck == siblingsCount){
                                            siblingsCheck = 0;
                                            tempInfoHoldCount = 0;
                                            
                                            for (int counter4 = lineageStartPosition; counter4 <= lineageEndPosition; counter4++){
                                                if (cellEventTypeList2 [counter3*23+7] == cellEventTypeList2 [counter4*23+7] && (cellEventTypeList2 [counter3*23+9] == 1 || cellEventTypeList2 [counter3*23+9] == 10)){
                                                    tempInfoHold [tempInfoHoldCount] = (int)cellEventTypeList2 [counter4*23+10], tempInfoHoldCount++;
                                                    tempInfoHold [tempInfoHoldCount] = (int)cellEventTypeList2 [counter4*23+9], tempInfoHoldCount++;
                                                    tempInfoHold [tempInfoHoldCount] = counter4, tempInfoHoldCount++;
                                                    
                                                    siblingsCheck++;
                                                    
                                                    if (siblingsCheck == siblingsCount){
                                                        break;
                                                    }
                                                }
                                            }
                                            
                                            siblingsCheck = 0;
                                            tempValueHold = 0;
                                            
                                            for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                if (tempInfoHold [counter4*3+1] == 10) siblingsCheck++;
                                                else tempValueHold = tempValueHold+tempInfoHold [counter4*3];
                                            }
                                            
                                            if (siblingsCount == 2){
                                                if (siblingsCheck == 2){
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = 11;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = 0;
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 10;
                                                    }
                                                }
                                                else if (siblingsCheck == 1){
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        if (tempInfoHold [counter4*3+1] == 10){
                                                            cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+10] = tempValueHold;
                                                        }
                                                        
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = tempValueHold;
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 1;
                                                    }
                                                }
                                                else{
                                                    
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = (int)(tempValueHold/(double)2);
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 1;
                                                    }
                                                }
                                            }
                                            else if (siblingsCount == 3){
                                                if (siblingsCheck == 3){
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = 11;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = 0;
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 10;
                                                    }
                                                }
                                                else if (siblingsCheck == 1 || siblingsCheck == 2){
                                                    if (siblingsCheck == 1){
                                                        for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                            if (tempInfoHold [counter4*3+1] == 10){
                                                                cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+10] = (int)(tempValueHold/(double)2);
                                                            }
                                                            
                                                            cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                        }
                                                        
                                                        tempValueHold2 = (int)(tempValueHold/(double)2);
                                                    }
                                                    else{
                                                        
                                                        for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                            if (tempInfoHold [counter4*3+1] == 10){
                                                                cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+10] = tempValueHold;
                                                            }
                                                            
                                                            cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                        }
                                                        
                                                        tempValueHold2 = tempValueHold;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = tempValueHold2;
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 1;
                                                    }
                                                }
                                                else{
                                                    
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = (int)(tempValueHold/(double)3);
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 1;
                                                    }
                                                }
                                            }
                                            else if (siblingsCount == 4){
                                                if (siblingsCheck == 4){
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = 11;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = 0;
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 10;
                                                    }
                                                }
                                                else if (siblingsCheck == 1 || siblingsCheck == 2 || siblingsCheck == 3){
                                                    if (siblingsCheck == 1){
                                                        for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                            if (tempInfoHold [counter4*3+1] == 10){
                                                                cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+10] = (int)(tempValueHold/(double)3);
                                                            }
                                                            
                                                            cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                        }
                                                        
                                                        tempValueHold2 = (int)(tempValueHold/(double)3);
                                                    }
                                                    else if (siblingsCheck == 2){
                                                        for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                            if (tempInfoHold [counter4*3+1] == 10){
                                                                cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+10] = (int)(tempValueHold/(double)2);
                                                            }
                                                            
                                                            cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                        }
                                                        
                                                        tempValueHold2 = (int)(tempValueHold/(double)2);
                                                    }
                                                    else{
                                                        
                                                        for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                            if (tempInfoHold [counter4*3+1] == 10){
                                                                cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+10] = tempValueHold;
                                                            }
                                                            
                                                            cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                        }
                                                        
                                                        tempValueHold2 = tempValueHold;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = tempValueHold2;
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 1;
                                                    }
                                                }
                                                else{
                                                    
                                                    for (int counter4 = 0; counter4 < tempInfoHoldCount/3; counter4++){
                                                        cellEventTypeList2 [tempInfoHold [counter4*3+2]*23+9] = -3;
                                                    }
                                                    
                                                    if (cellEventTypeList2 [parentCellPosition*23+9] == 0){
                                                        cellEventTypeList2 [parentCellPosition*23+10] = (int)(tempValueHold/(double)4);
                                                        cellEventTypeList2 [parentCellPosition*23+9] = 1;
                                                    }
                                                }
                                            }
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            for (int counter3 = lineageStartPosition; counter3 <= lineageEndPosition; counter3++){
                                if (cellEventTypeList2 [counter3*23+9] == 1 || cellEventTypeList2 [counter3*23+9] == 0 || cellEventTypeList2 [counter3*23+9] == 10){
                                    terminationFlag = 1;
                                    break;
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        lineageNumberTrack = (int)cellEventTypeList2 [counter1*23+1];
                        lineageStartPosition = counter1;
                    }
                }
                
                //for (int counterA = 0; counterA < cellEventTypeListCount2/23; counterA++){
                //    for (int counterB = 0; counterB < 23; counterB++) cout<<" "<<cellEventTypeList2 [counterA*23+counterB];
                //    cout<<" cellEventTypeList2 "<<counterA<<endl;
                //}
                
                delete [] tempInfoHold;
                
                //----Trace forward and take parent's value----
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++){
                    if (cellEventTypeList2 [counter1*23+1] != lineageNumberTrack && firstTimeFlag == 0){
                        lineageNumberTrack = (int)cellEventTypeList2 [counter1*23+1];
                        firstTimeFlag = 1;
                        lineageStartPosition = counter1;
                    }
                    else if ((cellEventTypeList2 [counter1*23+1] != lineageNumberTrack || counter1 == cellEventTypeListCount2/23-1) && firstTimeFlag == 1){
                        if (counter1 == cellEventTypeListCount2/23-1) lineageEndPosition = counter1;
                        else lineageEndPosition = counter1-1;
                        
                        do{
                            
                            terminationFlag = 0;
                            
                            for (int counter3 = lineageStartPosition; counter3 <= lineageEndPosition; counter3++){
                                if (cellEventTypeList2 [counter3*23+9] == 11){
                                    parentCellPosition = 0;
                                    
                                    for (int counter4 = lineageStartPosition; counter4 <= lineageEndPosition; counter4++){
                                        if (cellEventTypeList2 [counter3*23+7] == cellEventTypeList2 [counter4*23+2]){
                                            parentCellPosition = counter4;
                                            break;
                                        }
                                    }
                                    
                                    if (cellEventTypeList2 [parentCellPosition*23+9] == -3){
                                        cellEventTypeList2 [counter3*23+9] = -3;
                                        
                                        if (cellEventTypeList2 [counter3*23+10] != -1){
                                            cellEventTypeList2 [counter3*23+10] = cellEventTypeList2 [parentCellPosition*23+10];
                                        }
                                    }
                                }
                            }
                            
                            for (int counter3 = lineageStartPosition; counter3 <= lineageEndPosition; counter3++){
                                if (cellEventTypeList2 [counter3*23+9] == 11){
                                    terminationFlag = 1;
                                    break;
                                }
                            }
                            
                        } while (terminationFlag == 1);
                        
                        lineageNumberTrack = (int)cellEventTypeList2 [counter1*23+1];
                        lineageStartPosition = counter1;
                    }
                }
                
                //for (int counterA = 0; counterA < cellEventTypeListCount2/23; counterA++){
                //    for (int counterB = 0; counterB < 23; counterB++) cout<<" "<<cellEventTypeList2 [counterA*23+counterB];
                //    cout<<" cellEventTypeList2 "<<counterA<<endl;
                //}
                
                if (firstEntry  == 0){
                    ascIIstring = "Ling No";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+1]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "Cell No";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+2]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "ch "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+10]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "dub >minus for incomplete"+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        
                        if ((cellEventTypeList2 [counter2*23+3] == 31 && cellEventTypeList2 [counter2*23+4] == 32) || (cellEventTypeList2 [counter2*23+3] == 41 && cellEventTypeList2 [counter2*23+4] == 42) || (cellEventTypeList2 [counter2*23+3] == 51 && cellEventTypeList2 [counter2*23+4] == 52)){
                            
                            ascIIstring = to_string(cellEventTypeList2 [counter2*23+6]-cellEventTypeList2 [counter2*23+5]);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        }
                        else{
                            
                            ascIIstring = to_string((cellEventTypeList2 [counter2*23+6]-cellEventTypeList2 [counter2*23+5])*-1);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        }
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "Start Event "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+3]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "End Event "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+4]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                }
                else{
                    
                    ascIIstring = "ch "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+10]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "dub >minus for incomplete"+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        if ((cellEventTypeList2 [counter2*23+3] == 31 && cellEventTypeList2 [counter2*23+4] == 32) || (cellEventTypeList2 [counter2*23+3] == 41 && cellEventTypeList2 [counter2*23+4] == 42) || (cellEventTypeList2 [counter2*23+3] == 51 && cellEventTypeList2 [counter2*23+4] == 52)){
                            
                            ascIIstring = to_string(cellEventTypeList2 [counter2*23+6]-cellEventTypeList2 [counter2*23+5]);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        }
                        else{
                            
                            ascIIstring = to_string((cellEventTypeList2 [counter2*23+6]-cellEventTypeList2 [counter2*23+5])*-1);
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        }
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "Start Event "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+3]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "End Event "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount2/23; counter2++){
                        ascIIstring = to_string(cellEventTypeList2 [counter2*23+4]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                }
                
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/23; counter1++){
                    lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9] = lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9]+(int)cellEventTypeList2 [counter1*23+10];
                    lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+1]++;
                    lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+2] = lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+2]+(int)(cellEventTypeList2 [counter1*23+9]-cellEventTypeList2 [counter1*23+9]);
                    
                    if (cellEventTypeList2 [counter1*23+10] > lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+3]) lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+3] = (int)cellEventTypeList2 [counter1*23+10];
                    
                    if (cellEventTypeList2 [counter1*23+10] < lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+4]) lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+4] = (int)cellEventTypeList2 [counter1*23+10];
                    
                    if (cellEventTypeList2 [counter1*23+9] == maxTimePoint){
                        lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+5] = lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+5]+(int)cellEventTypeList2 [counter1*23+10];
                    }
                    
                    if (cellEventTypeList2 [counter1*23+4] == 7){
                        lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+6]++;
                    }
                    
                    if (cellEventTypeList2 [counter1*23+3] == 41 || cellEventTypeList2 [counter1*23+3] == 51){
                        lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+7]++;
                    }
                    
                    if (cellEventTypeList2 [counter1*23+4] == 91){
                        lineageListExp [(int)cellEventTypeList2 [counter1*23+1]*9+8]++;
                    }
                }
                
                if (firstEntry  == 0){
                    ascIIstring = "Ling No";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(counter2);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "ch "+to_string(counter0)+" total no of cell";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+1]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "ch "+to_string(counter0)+" total fluorescent";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "dub "+to_string(counter0)+" total";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+2]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "max "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+3]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "min "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+4]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "max-min "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+3]-lineageListExp [counter2*9+4]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "Fluorescent at the end "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+5]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "No of CD "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+6]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "No of MD "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+7]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "No of CF "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+8]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    firstEntry = 1;
                }
                else{
                    
                    ascIIstring = "ch "+to_string(counter0)+" total no of cell";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+1]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "ch "+to_string(counter0)+" total fluorescent";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "dub "+to_string(counter0)+" total";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+2]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "max "+to_string(counter0)+" total";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+3]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "min "+to_string(counter0)+" total";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*6+4]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "max-min "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+3]-lineageListExp [counter2*9+4]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "Fluorescent at the end "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+5]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "No of CD "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+6]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "No of MD "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+7]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                    
                    ascIIstring = "No of CF "+to_string(counter0);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                        ascIIstring = to_string(lineageListExp [counter2*9+8]);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                    }
                    
                    oin.put(13);
                    oin.put(10);
                }
                
                lineageListExpCount = 0;
                
                for (int counter2 = 0; counter2 <= maxLineageNo; counter2++){
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 100000, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                    lineageListExp [lineageListExpCount] = 0, lineageListExpCount++;
                }
                
                cellEventTypeListCount2 = 0;
                
                for (int counter1 = 0; counter1 < cellEventTypeListCount3; counter1++) cellEventTypeList2 [cellEventTypeListCount2] = cellEventTypeList3 [counter1], cellEventTypeListCount2++;
            }
        }
        
        delete [] fluorescentChData;
        delete [] cellEventTypeList2;
        delete [] cellEventTypeList3;
        delete [] arrayAscIIintData;
        delete [] lineageListExp;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageFluorescentDataExport2:(id)sender{
    if (initialArraySet == 1){
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_Fluorescent_Data";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [tableCurrentRowHold][1];
        string seriesNameExport = arrayTableMain [tableCurrentRowHold][2];
        string analysisNameExport = arrayTableMain [tableCurrentRowHold][3];
        string treatNameExportSave = arrayTableMain [tableCurrentRowHold][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-FB";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNo = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("FB")+2, entry.find(".txt")-entry.find("FB")-2);
                    
                    if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNo++;
        
        string lowLingResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".txt";
        
        int *arrayAscIIintData = new int [100];
        int ascIIintDataCount = 0;
        
        //1. Cell Number (1+-4 bytes)
        //2. Cell Lineage No (3)
        //3. Time Point (2)
        //4. Live/IF: Live: 1, IF: 2 (1)
        //5. CH1-no (1)
        //6. CH1-Value (3)
        //7. CH1-Area (3)
        //8. CH2-no (1)
        //9. CH2-Value (3)
        //10. CH2-Area (3)
        //11. CH3-no (1)
        //12. CH3-Value (3)
        //13. CH3-Area (3)
        //14. CH4-no (1)
        //15. CH4-Value (3)
        //16. CH4-Area (3)
        //17. CH5-no (1)
        //18. CH5-Value (3)
        //19. CH5-Area (3)
        //20. CH6-no (1)
        //21. CH6-Value (3)
        //22. CH6-Area (3)
        
        ofstream oin;
        oin.open(lowLingResultPath.c_str(), ios::out | ios::binary);
        
        ascIIconversion = [[ASCIIconversion alloc] init];
        
        ascIIstring = "Ling No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Cell No";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Time";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "Live-IF";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no1";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no1 value";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no1 area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no2";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no2 value";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no2 area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no3";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no3 value";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no3 area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no4";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no4 value";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no4 area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no5";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no5 value";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no5 area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no6";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no6 value";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        ascIIstring = "CH no6 area";
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        oin.put(13);
        oin.put(10);
        
        //----Determine max value of each CH----
        for (int counter2 = 0; counter2 < arrayIFDataEntryHold [tableCurrentRowHold]/22; counter2++){
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+1]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+2]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+3]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+4]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+5]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+6]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+7]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+8]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+9]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+10]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+11]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+12]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+13]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+14]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+15]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+16]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+17]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+18]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+19]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+20]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            ascIIstring = to_string(arrayIFData [tableCurrentRowHold] [counter2*22+21]);
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
            
            oin.put(9);
            
            oin.put(13);
            oin.put(10);
        }
        
        //for (int counterA = 0; counterA < arrayIFDataEntryHold [currentSeriesNo]/22; counterA++){
        //    for (int counterB = 0; counterB < 22; counterB++) cout<<" "<<arrayIFData [currentSeriesNo] [counterA*22+counterB];
        //    cout<<" arrayIFData "<<counterA<<endl;
        //}
        
        delete [] arrayAscIIintData;
        
        oin.close();
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)directoryInfoUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)dealloc{
    if (timerLA) [timerLA invalidate];
}

@end
