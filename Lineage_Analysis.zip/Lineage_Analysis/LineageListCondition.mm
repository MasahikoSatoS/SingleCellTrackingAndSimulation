//
//  LineageListCondition.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/26/16.
//
//

#import "LineageListCondition.h"

NSString *notificationToLineageListCondition = @"notificationExecuteLineageListCondition";

@implementation LineageListCondition

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageListCondition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [typeDisplayLing setStringValue:@(typeLing.c_str())];
    [seriesDisplayLing setStringValue:@(seriesLing.c_str())];
    [analysisDisplayLing setStringValue:@(analysisLing.c_str())];
    [treatDisplayLing setStringValue:@(treatLing.c_str())];
    
    if (liveDisplayHold == 1){
        [liveDisplayLing setStringValue:@"Live"];
    }
    else if (liveDisplayHold == 2){
        [liveDisplayLing setStringValue:@"Live/Ex"];
    }
    else if (liveDisplayHold == 3){
        [liveDisplayLing setStringValue:@"IF"];
    }
    else if (liveDisplayHold == 4){
        [liveDisplayLing setStringValue:@"IF/Ex"];
    }
    else if (liveDisplayHold == 0){
        [liveDisplayLing setStringValue:@"None"];
    }
    
    [channelDisplayLing setIntegerValue:chNo1];
    
    if (siblingLingHold == 1){
        [siblingDisplayLing setStringValue:@"Sibling"];
    }
    else if (siblingLingHold == 1){
        [siblingDisplayLing setStringValue:@"Zero"];
    }
    
    if (colorOptionLingHold == 1){
        [colorOptionDisplayLing setStringValue:@"Manual"];
    }
    else if (colorOptionLingHold == 2){
        [colorOptionDisplayLing setStringValue:@"Heat"];
    }
    
    if (ifOneAllHold == -1) [ifOneAllLing setStringValue:@"nil"];
    else if (ifOneAllHold > 0) [ifOneAllLing setIntegerValue:ifOneAllHold];
    
    [cellNameForDisplay setStringValue:@(displayNameCellLing.c_str())];
    [treatNameForDisplay setStringValue:@(displayNameTreatLing.c_str())];
    [ifRangeForDisplay setStringValue:@(ifRangeLing.c_str())];
    
    ifStepperHold = 0;
    
    for (int counter1 = ifRangeLow; counter1 <= ifRangeHigh; counter1++){
        for (int counter2 = 0; counter2 < arrayIfTimeStatusHold [selectCurrentLineage]/2; counter2++){
            if (arrayIfTimeStatus [selectCurrentLineage][counter2*2] == counter1 && arrayIfTimeStatus [selectCurrentLineage][counter2*2+1] == 0){
                ifStepperHold = counter1;
                break;
            }
        }
        
        if (ifStepperHold != 0){
            break;
        }
    }
    
    [stepperTime setMinValue:ifRangeLow];
    [stepperTime setMaxValue:ifRangeHigh];
}

-(IBAction)stepperActionTime:(id)sender{
    if ([stepperTime intValue] >= ifRangeLow && [stepperTime intValue] <= ifRangeHigh){
        ifStepperHold = [stepperTime intValue];
        
        if (ifOneAllHold != -1){
            int timeFind = 0;
            
            for (int counter1 = 0; counter1 < arrayIfTimeStatusHold [selectCurrentLineage]/2; counter1++){
                if (arrayIfTimeStatus [selectCurrentLineage][counter1*2] == ifStepperHold && arrayIfTimeStatus [selectCurrentLineage][counter1*2+1] == 0){
                    timeFind = 1;
                    break;
                }
            }
            
            if (timeFind == 1){
                [ifOneAllLing setTextColor:[NSColor blackColor]];
                [ifOneAllLing setIntegerValue:ifStepperHold];
                ifOneAllHold = ifStepperHold;
            }
        }
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageListCondition object:nil];
}

@end
