//
//  ProgenyAnalysisTable2.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-22.
//
//

#ifndef PROGENYANALYSISTABLE2_H
#define PROGENYANALYSISTABLE2_H
#import "Controller.h" 
#endif

@interface ProgenyAnalysisTable2 : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *progenyAnalysisProgenyTable2;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
