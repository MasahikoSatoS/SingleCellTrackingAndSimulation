//
//  TypeDefinitionSet.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/2/16.
//
//

#ifndef TYPEDEFINITIONSET_H
#define TYPEDEFINITIONSET_H
#import "Controller.h" 
#endif

@interface TypeDefinitionSet : NSObject <NSTableViewDataSource>{
    int tableCallTDCount; //Table operation
    int tableCurrentTDRowHold; //Table operation
    int rowIndexTDHold; //Table operation
    int tableViewTDCall; //Table operation
    
    IBOutlet NSTableView *tableViewTDList;
    IBOutlet NSWindow *typeDefinitionWindow;
    
    NSTimer *typeDefTimer;
    NSTimer *typeDefTimer2;
    
    NSWindowController *typeDefinitionWindowController;
}

-(id)init;
-(void)dealloc;
-(void)display;
-(void)reDisplayWindow;
-(void)typeDefinitionHoldUpDate;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

-(IBAction)deleteEntry:(id)sender;
-(IBAction)saveEntry:(id)sender;
-(IBAction)closeWindow:(id)sender;

@end
