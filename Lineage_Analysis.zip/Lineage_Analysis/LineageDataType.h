//
//  LineageDataType.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/2/16.
//
//

#ifndef LINEAGEDATATYPE_H
#define LINEAGEDATATYPE_H
#import "Controller.h" 
#endif

@interface LineageDataType : NSObject <NSTableViewDataSource>{
    IBOutlet NSWindow *lineageDataWindow;
    
    NSTimer *lineageDataTimer;
    
    NSWindowController *lineageDataWindowController;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)saveEntry:(id)sender;
-(IBAction)closeWindow:(id)sender;

@end
