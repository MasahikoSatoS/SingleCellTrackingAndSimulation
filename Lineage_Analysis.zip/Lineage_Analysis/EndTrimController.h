//
//  EndTrimController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-31.
//
//

#ifndef ENDTRIMCONTROLLER_H
#define ENDTRIMCONTROLLER_H
#import "Controller.h" 
#endif

@interface EndTrimController : NSObject <NSTextFieldDelegate>{
    int trimTimeHold; //Trim time
    int ifRemoveTimeHold; //IF remove
    int liveRemoveStatusHold; //Live remove
    int fusionBetweenIncHold; //Fusion between inc
    int nonDivIncHold; //Non div inc
    
    IBOutlet NSTextField *trimTimeDisplay;
    IBOutlet NSTextField *ifRemoveTimeDisplay;
    IBOutlet NSTextField *nonDivIncHoldDisplay;
    IBOutlet NSTextField *fusionBetweenIncHoldDisplay;
    IBOutlet NSTextField *newNameDisplay;
    IBOutlet NSTextField *simulateTDHoldDisplay;
    IBOutlet NSTextField *startTimeDisplay;
    IBOutlet NSTextField *endTimeDisplay;
    IBOutlet NSTextField *outIntervalDisplay;
    IBOutlet NSTextField *inIntervalDisplay;
    IBOutlet NSTextField *lineageCutDisplay;
    IBOutlet NSTextField *progenitorIncludeDisplay;
    IBOutlet NSTextField *doubleExtendDisplay;
    
    IBOutlet NSWindow *trimWindow;
    
    NSWindowController *trimWindowController;
    
    NSTimer *trimTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)lineageFluorescentDataTypeUpDate;
-(void)mergeProcess;
-(void)fileDeleteUpDate;

-(IBAction)closeWindow:(id)sender;
-(IBAction)performTrim:(id)sender;
-(IBAction)performMerge:(id)sender;
-(IBAction)performIFRemove:(id)sender;
-(IBAction)nonDivLingStatusHold:(id)sender;
-(IBAction)fusionBetweenIncHold:(id)sender;
-(IBAction)performSynchronize:(id)sender;
-(IBAction)setFirstPointToOne:(id)sender;
-(IBAction)newNameSet:(id)sender;
-(IBAction)deleteAnalysisData:(id)sender;
-(IBAction)simulateCDCFRemove:(id)sender;
-(IBAction)simulateTDHold:(id)sender;
-(IBAction)doubleKeepHoldSet:(id)sender;
-(IBAction)timeLengthAdjust:(id)sender;
-(IBAction)lineageSet:(id)sender;
-(IBAction)progenitorIncludeSet:(id)sender;

@end
