//
//  LineageController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/9/16.
//
//

#import "LineageController.h"

NSString *notificationToLineageController = @"notificationExecuteLineageController";

@implementation LineageController

-(id)init{
    self = [super init];
    
    if (self != nil){
        saveFlag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    lineageWindowController = [[NSWindowController alloc] initWithWindowNibName:@"LineageAnalysis"];
    [lineageWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageListCondition object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDisplay object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [lineageWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [lineageWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    lineageTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (exportTiming == 1){
        exportTiming = 2;
        
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_List";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [selectCurrentLineage][1];
        string seriesNameExport = arrayTableMain [selectCurrentLineage][2];
        string analysisNameExport = arrayTableMain [selectCurrentLineage][3];
        string treatNameExportSave = arrayTableMain [selectCurrentLineage][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-ALL";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNoList = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("ALL")+3);
                    
                    if (maxEntryNoList < atoi(extractString.c_str())) maxEntryNoList = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNoList++;
        
        string path = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_List/"+nameString+to_string(maxEntryNoList);
        mkdir(path.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        lineageCurrentPosition = 0;
        listEntryNoList = 1;
        exportTiming = 3;
    }
    else if (exportTiming == 3){
        [backSave startAnimation:self];
        exportTiming = 4;
    }
    else if (exportTiming >= 4 && exportTiming < 10){
        exportTiming++;
    }
    else if (exportTiming == 10){
        [backSave startAnimation:self];
        
        exportTiming = 11;
        exportFlag3 = 1;
        
        string sourceNameExport = arrayTableMain [selectCurrentLineage][1];
        string seriesNameExport = arrayTableMain [selectCurrentLineage][2];
        string analysisNameExport = arrayTableMain [selectCurrentLineage][3];
        string treatNameExportSave = arrayTableMain [selectCurrentLineage][5];
        
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-ALL";
        string path = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_List/"+nameString+to_string(maxEntryNoList);
        
        int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
        int newPositionFind = 0;
        
        for (int counter1 = lineageCurrentPosition+1; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
            if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                newPositionFind = counter1;
                break;
            }
        }
        
        if (newPositionFind != 0){
            lineageCurrentPosition = newPositionFind;
            
            lingNo1 = -1;
            lingNo2 = -1;
            lingNo3 = -1;
            lingNo4 = -1;
            lingNo5 = -1;
            lingNo6 = -1;
            lingNo7 = -1;
            lingNo8 = -1;
            
            int displayCount = 0;
            int lastCounterPosition = -1;
            
            for (int counter1 = lineageCurrentPosition; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                    lastCounterPosition = counter1;
                    
                    if (displayCount == 0) lingNo1 = counter1, displayCount++;
                    else if (displayCount == 1) lingNo2 = counter1, displayCount++;
                    else if (displayCount == 2) lingNo3 = counter1, displayCount++;
                    else if (displayCount == 3) lingNo4 = counter1, displayCount++;
                    else if (displayCount == 4) lingNo5 = counter1, displayCount++;
                    else if (displayCount == 5) lingNo6 = counter1, displayCount++;
                    else if (displayCount == 6) lingNo7 = counter1, displayCount++;
                    else if (displayCount == 7){
                        lingNo8 = counter1;
                        displayCount++;
                        break;
                    }
                }
            }
            
            if (lastCounterPosition != -1) lineageCurrentPosition = lastCounterPosition;
            
            exportResultPath = path +"/"+nameString+to_string(listEntryNoList)+".tif";
            
            //cout<<lingNo1<<" "<<lingNo2<<" "<<lingNo3<<" "<<lingNo4<<" "<<lingNo5<<" "<<lingNo6<<" "<<lingNo7<<" "<<lingNo8<<" LingNo"<<endl;
            
            listEntryNoList++;
            
            exportTiming = 12;
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDisplay object:self];
        }
        else exportTiming = 90;
    }
    else if (exportTiming >= 13 && exportTiming < 80){
        exportTiming++;
    }
    else if (exportTiming == 80){
        exportTiming = 81;
    }
    else if (exportTiming == 81){
        exportTiming = 10;
    }
    else if (exportTiming == 90){
        exportTiming = 91;
        [backSave stopAnimation:self];
    }
    else if (exportTiming >= 91 && exportTiming < 1000){
        exportTiming++;
    }
    else if (exportTiming == 100){
        exportTiming = 0;
        exportFlag3 = 2;
        
        [backSave stopAnimation:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
}

-(IBAction)liveDisplaySet:(id)sender{
    if (selectCurrentLineage != -1){
        if (arrayTableMain [selectCurrentLineage][5] != "0"){
            if (liveDisplayHold == 0){
                liveDisplayHold = 1;
                [liveDisplayLing setStringValue:@"Live"];
            }
            else if (liveDisplayHold == 1){
                liveDisplayHold = 2;
                [liveDisplayLing setStringValue:@"Live/Ex"];
            }
            else if (liveDisplayHold == 2){
                liveDisplayHold = 3;
                [liveDisplayLing setStringValue:@"IF"];
            }
            else if (liveDisplayHold == 3){
                liveDisplayHold = 4;
                [liveDisplayLing setStringValue:@"IF/Ex"];
            }
            else if (liveDisplayHold == 4){
                liveDisplayHold = 0;
                [liveDisplayLing setStringValue:@"None"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Live Fluorescent Images Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)channelSet:(id)sender{
    if (selectCurrentLineage != -1){
        if (chNo1 == 1){
            chNo1 = 2;
            [channelDisplayLing setIntegerValue:chNo1];
        }
        else if (chNo1 == 2){
            chNo1 = 3;
            [channelDisplayLing setIntegerValue:chNo1];
        }
        else if (chNo1 == 3){
            chNo1 = 4;
            [channelDisplayLing setIntegerValue:chNo1];
        }
        else if (chNo1 == 4){
            chNo1 = 5;
            [channelDisplayLing setIntegerValue:chNo1];
        }
        else if (chNo1 == 5){
            chNo1 = 6;
            [channelDisplayLing setIntegerValue:chNo1];
        }
        else if (chNo1 == 6){
            chNo1 = 1;
            [channelDisplayLing setIntegerValue:chNo1];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)siblingSet:(id)sender{
    if (selectCurrentLineage != -1){
        if (siblingLingHold == 0){
            siblingLingHold = 1;
            [siblingDisplayLing setStringValue:@"Sibling"];
        }
        else if (siblingLingHold == 1){
            siblingLingHold = 0;
            [siblingDisplayLing setStringValue:@"Zero"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)colorOptionSet:(id)sender{
    if (selectCurrentLineage != -1){
        if (colorOptionLingHold == 0){
            colorOptionLingHold = 1;
            [colorOptionDisplayLing setStringValue:@"Manual"];
        }
        else if (colorOptionLingHold == 1){
            colorOptionLingHold = 0;
            [colorOptionDisplayLing setStringValue:@"Heat"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)averageTotalSet:(id)sender{
    if (selectCurrentLineage != -1){
        if (arrayTableMain [selectCurrentLineage][12] != "0" || arrayTableMain [selectCurrentLineage][5] != "0"){
            if (averageTotalSetHold == 0){
                averageTotalSetHold = 1;
                [averageTotalSetLing setStringValue:@"Total"];
            }
            else{
                
                averageTotalSetHold = 0;
                [averageTotalSetLing setStringValue:@"Average"];
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No IF Images Found"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)ifOneAllSet:(id)sender{
    if (selectCurrentLineage != -1){
        if (ifOneAllHold == -1 && ifStepperHold != 0){
            ifOneAllHold = ifStepperHold;
            [ifOneAllLing setIntegerValue:ifOneAllHold];
        }
        else{
            
            ifOneAllHold = -1;
            [ifOneAllLing setStringValue:@"nil"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)displayCellSet:(id)sender{
    if (selectCurrentLineage != -1){
        string inputData = [[displayInfoInput stringValue] UTF8String];
        [displayInfoInput setStringValue:@""];
        
        if (inputData.length() >= 3 && inputData.length() < 50){
            saveFlag = 1;
            displayNameCellLing = inputData;
            [cellNameForDisplay setStringValue:@(displayNameCellLing.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Minimum 3 Chs./Length Limit Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)displayTreatSet:(id)sender{
    if (selectCurrentLineage != -1){
        string inputData = [[displayInfoInput stringValue] UTF8String];
        [displayInfoInput setStringValue:@""];
        
        if (inputData.length() >= 3 && inputData.length() < 50){
            saveFlag = 1;
            displayNameTreatLing = inputData;
            [treatNameForDisplay setStringValue:@(displayNameTreatLing.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Minimum 3 Chs./Length Limit Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)displaySeriesSet:(id)sender{
    if (selectCurrentLineage != -1){
        string inputData = [[displayInfoInput stringValue] UTF8String];
        [displayInfoInput setStringValue:@""];
        
        if (inputData.length() >= 3 && inputData.length() < 50){
            saveFlag = 1;
            displayNameSeriesLing = inputData;
            [seriesNameForDisplay setStringValue:@(displayNameSeriesLing.c_str())];
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Minimum 3 Chs./Length Limit Exceeded"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)blueLineDisplaySet:(id)sender{
    if (selectCurrentLineage != -1){
        if (blueLineDisplayHold == 0){
            blueLineDisplayHold = 1;
            [blueLineSetDisplay setStringValue:@"Off"];
        }
        else{
            
            blueLineDisplayHold = 0;
            [blueLineSetDisplay setStringValue:@"On"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineWidthSet:(id)sender{
    if (selectCurrentLineage != -1){
        if (lingLineWidthHold == 5){
            lingLineWidthHold = 1;
            [lineWidthSetDisplay setIntegerValue:1];
        }
        else if (lingLineWidthHold == 1){
            lingLineWidthHold = 2;
            [lineWidthSetDisplay setIntegerValue:2];
        }
        else if (lingLineWidthHold == 2){
            lingLineWidthHold = 3;
            [lineWidthSetDisplay setIntegerValue:3];
        }
        else if (lingLineWidthHold == 3){
            lingLineWidthHold = 4;
            [lineWidthSetDisplay setIntegerValue:4];
        }
        else if (lingLineWidthHold == 4){
            lingLineWidthHold = 5;
            [lineWidthSetDisplay setIntegerValue:5];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lingDataSave:(id)sender{
    if (saveFlag == 1){
        if (upLoadingProgress == 0){
            string analysisIDPath = analysisDataFolderPath+"/"+arrayTableMain [selectCurrentLineage][2]+"_AnalysisResults/"+arrayTableMain [selectCurrentLineage][3]+"_IDResults";
            
            string typeFind = "LN";
            string treatNameSave = arrayTableMain [selectCurrentLineage][4].substr(arrayTableMain [selectCurrentLineage][4].find("-")+1);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            maxEntryNo = 0;
            
            dir = opendir(analysisIDPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(treatNameSave) != -1 && (int)entry.find(typeFind) != -1){
                        extractString = entry.substr(2, entry.find("-")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string messageString = "Data will be saved as "+typeFind+to_string(maxEntryNo);
            
            NSString *message = @(messageString.c_str());
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert addButtonWithTitle:@"Cancel"];
            [alert setMessageText:message];
            [alert setAlertStyle:NSAlertStyleWarning];
            
            if ([alert runModal] == NSAlertFirstButtonReturn){
                string savePath = analysisIDPath+"/"+typeFind+to_string(maxEntryNo)+"-"+treatNameSave+"_Results";
                
                mkdir(savePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string analysisIDPathSource = analysisDataFolderPath+"/"+arrayTableMain [selectCurrentLineage][2]+"_AnalysisResults/"+arrayTableMain [selectCurrentLineage][3]+"_IDResults/"+arrayTableMain [selectCurrentLineage][4]+"_Results";
                
                string analysisIDPathSource2;
                string savePath2;
                long sizeForCopy = 0;
                
                struct stat sizeOfFile;
                
                dir = opendir(analysisIDPathSource.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            analysisIDPathSource2 = analysisIDPathSource+"/"+entry;
                            savePath2 = savePath+"/"+entry;
                            
                            if (stat(analysisIDPathSource2.c_str(), &sizeOfFile) == 0){
                                sizeForCopy = sizeOfFile.st_size;
                                
                                ifstream infile (analysisIDPathSource2.c_str(), ifstream::binary);
                                ofstream outfile (savePath2.c_str(), ofstream::binary);
                                
                                char *buffer = new char[sizeForCopy];
                                infile.read (buffer, sizeForCopy);
                                outfile.write (buffer, sizeForCopy);
                                delete [] buffer;
                                
                                outfile.close();
                                infile.close();
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                
                analysisIDPathSource2 = savePath+"/*LineageDataAddition.dat";
                
                ofstream oin;
                
                oin.open(analysisIDPathSource2.c_str(), ios::out | ios::binary);
                
                if (oin.is_open()){
                    oin<<arrayLineageDataType [selectCurrentLineage][0]<<endl;
                    oin<<"LN"<<endl;
                    oin<<arrayLineageDataType [selectCurrentLineage][2]<<endl;
                    oin<<arrayLineageDataType [selectCurrentLineage][3]<<endl;
                    oin<<arrayLineageDataType [selectCurrentLineage][4]<<endl;
                    oin<<arrayLineageDataType [selectCurrentLineage][5]<<endl;
                    oin<<arrayLineageDataType [selectCurrentLineage][6]<<endl;
                    
                    for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == selectCurrentLineage){
                            oin<<arrayLineageFluorescentDataType [counter2][0]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][1]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][2]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][3]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][4]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][5]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][6]<<endl;
                            oin<<arrayLineageFluorescentDataType [counter2][7]<<endl;
                        }
                    }
                    
                    oin.close();
                }
                
                analysisIDPathSource2 = savePath+"/MainTable";
                
                oin.open(analysisIDPathSource2.c_str(), ios::out | ios::binary);
                
                for (int counter1 = 0; counter1 < arrayTableMainHold [selectCurrentLineage]; counter1++){
                    if (counter1 == 1) oin<<"LN"<<endl;
                    else if (counter1 == 4) oin<<"LN"+to_string(maxEntryNo)+"-"+treatNameSave<<endl;
                    else oin<<arrayTableMain [selectCurrentLineage][counter1]<<endl;
                }
                
                oin.close();
                
                savePath = analysisIDPath+"/"+typeFind+to_string(maxEntryNo)+"-"+treatNameSave+"_Results/DisplayNames";
                
                oin.open(savePath.c_str(), ios::out | ios::binary);
                
                oin<<displayNameCellLing<<endl;
                oin<<displayNameTreatLing<<endl;
                oin<<displayNameSeriesLing<<endl;
                
                oin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Display Data Unchanged"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createPDF:(id)sender{
    if (selectCurrentLineage != -1){
        exportFlag3 = 1;
        
        string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
        mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Lineage_List";
        mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
        
        string sourceNameExport = arrayTableMain [selectCurrentLineage][1];
        string seriesNameExport = arrayTableMain [selectCurrentLineage][2];
        string analysisNameExport = arrayTableMain [selectCurrentLineage][3];
        string treatNameExportSave = arrayTableMain [selectCurrentLineage][5];
        string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-LL";
        
        DIR *dir;
        struct dirent *dent;
        
        string entry;
        string extractString;
        maxEntryNoList = 0;
        
        dir = opendir(resultSavePath2.c_str());
        
        if (dir != NULL){
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                    extractString = entry.substr(entry.find("LL")+2, entry.find(".tif")-entry.find("LL")-2);
                    
                    if (maxEntryNoList < atoi(extractString.c_str())) maxEntryNoList = atoi(extractString.c_str());
                }
            }
            
            closedir(dir);
        }
        
        maxEntryNoList++;
        
        exportResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNoList)+".tif";
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageDisplay object:self];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createAllPDF:(id)sender{
    if (selectCurrentLineage != -1){
        if (exportFlag3 == 0) exportTiming = 1;
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [lineageWindow orderOut:self];
    lineageWindowOperation = 2;
    lineageTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (lineageWindowOperation == 3){
        [lineageWindow makeKeyAndOrderFront:self];
        lineageWindowOperation = 1;
        [lineageTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageController object:nil];
}

@end
