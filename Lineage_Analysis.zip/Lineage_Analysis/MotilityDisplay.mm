//
//  MotilityDisplay.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#import "MotilityDisplay.h"

NSString *notificationToMotilityDisplay = @"notificationExecuteMotilityDisplay";

@implementation MotilityDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        mouseDragFlag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMotilityDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    xPositionDisplay = 0;
    yPositionDisplay = 0;
    xPositionAdjustDisplay = 0;
    yPositionAdjustDisplay = 0;
    magnificationDisplay = 10;
    
    if (motilityDisplayScaleMaxHold < 100){
        motilityDisplayScaleMaxHold = 100;
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDataSet object:nil];
    }
    
    imageWidthDisplay = motilityDisplayScaleMaxHold;
    imageHeightDisplay = motilityDisplayScaleMaxHold;
    
    //----Window size and Position re-adjust----
    int vertical = 539+78;
    int horizontal = 539;
    
    windowWidthDisplay = imageWidthDisplay/(double)horizontal;
    windowHeightDisplay = imageHeightDisplay/(double)(vertical-78);
    
    xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
    yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
    
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownDisplay = clickPoint.x;
    yPointDownDisplay = clickPoint.y;
    
    if (upLoadingProgress == 0){
        if (xPointDownDisplay > 488 && xPointDownDisplay < 532 && yPointDownDisplay > 515 && yPointDownDisplay < 569){
            if (motilityDisplayScaleMaxHold < 100){
                motilityDisplayScaleMaxHold = 100;
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDataSet object:nil];
            }
            
            imageWidthDisplay = motilityDisplayScaleMaxHold;
            imageHeightDisplay = motilityDisplayScaleMaxHold;
            
            //----Window size and Position re-adjust----
            int vertical = 539+78;
            int horizontal = 539;
            
            windowWidthDisplay = imageWidthDisplay/(double)horizontal;
            windowHeightDisplay = imageHeightDisplay/(double)(vertical-78);
            
            xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        
        if (clickPoint.x > 438 && clickPoint.x < 482 && clickPoint.y >515 && clickPoint.y < 569){
            if (initialArraySet == 1){
                exportFlag9 = 1;
                
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Motility";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                int lineageSelectNo = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10].c_str());
                
                string sourceNameExport = arrayTableMain [lineageSelectNo][1];
                string seriesNameExport = arrayTableMain [lineageSelectNo][2];
                string analysisNameExport = arrayTableMain [lineageSelectNo][3];
                string treatNameExportSave = arrayTableMain [lineageSelectNo][5];
                string nameString = sourceNameExport+"_"+seriesNameExport+"_"+analysisNameExport+"_"+treatNameExportSave+"-MBL";
                string entry;
                string extractString;
                
                DIR *dir;
                struct dirent *dent;
                
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                            extractString = entry.substr(entry.find("MBL")+3, entry.find(".tif")-entry.find("MBL")-3);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                exportResultPath = resultSavePath2+"/"+nameString+to_string(maxEntryNo)+".tif";
                
                if (motilityDisplayScaleMaxHold < 100){
                    motilityDisplayScaleMaxHold = 100;
                    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDataSet object:nil];
                }
                
                imageWidthDisplay = motilityDisplayScaleMaxHold;
                imageHeightDisplay = motilityDisplayScaleMaxHold;
                
                //----Window size and Position re-adjust----
                int vertical = 539+78;
                int horizontal = 539;
                
                windowWidthDisplay = imageWidthDisplay/(double)horizontal;
                windowHeightDisplay = imageHeightDisplay/(double)(vertical-78);
                
                xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
                yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (exportFlag9 == 2){
            exportFlag9 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)mouseUp:(NSEvent *)event{
    if (upLoadingProgress == 0){
        xPositionDisplay = xPositionDisplay+xPositionMoveDisplay;
        yPositionDisplay = yPositionDisplay+yPositionMoveDisplay;
        xPositionMoveDisplay = 0;
        yPositionMoveDisplay = 0;
        mouseDragFlag = 0;
        [self setNeedsDisplay:YES];
    }
}

- (void)mouseDraged:(NSEvent *)event{
    if (upLoadingProgress == 0){
        NSPoint clickPoint= [self convertPoint:[event locationInWindow] fromView:nil];
        xPointDragDisplay = clickPoint.x;
        yPointDragDisplay = clickPoint.y;
        xPositionMoveDisplay = (xPointDownDisplay-xPointDragDisplay)*windowWidthDisplay/(double)(magnificationDisplay*0.1);
        yPositionMoveDisplay = (yPointDownDisplay-yPointDragDisplay)*windowHeightDisplay/(double)(magnificationDisplay*0.1);
        mouseDragFlag = 1;
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    if (upLoadingProgress == 0){
        int keyCode = [event keyCode];
        int proceedFlag = 0;
        
        if (motilityDisplayScaleMaxHold < 100){
            motilityDisplayScaleMaxHold = 100;
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMotilityDataSet object:nil];
        }
        
        //----Original size----
        if (keyCode == 6){
            proceedFlag = 1;
            xPositionDisplay = 0;
            yPositionDisplay = 0;
            xPositionAdjustDisplay = 0;
            yPositionAdjustDisplay = 0;
            magnificationDisplay = 10;
        }
        
        //----Magnification Magnify----
        if (keyCode == 125){
            if (magnificationDisplay >= 12 && magnificationDisplay <= 500){
                proceedFlag = 1;
                
                if (magnificationDisplay-10 < 12) magnificationDisplay = 10;
                else magnificationDisplay = magnificationDisplay-10;
                
                xPositionAdjustDisplay = -1*(imageWidthDisplay/(double)(magnificationDisplay*0.1)-imageWidthDisplay)/(double)2;
                yPositionAdjustDisplay = -1*(imageHeightDisplay/(double)(magnificationDisplay*0.1)-imageHeightDisplay)/(double)2;
            }
        }
        
        //----Magnification Reduction----
        if (keyCode == 126){
            if (magnificationDisplay >= 10 && magnificationDisplay <= 498){
                proceedFlag = 1;
                
                if (magnificationDisplay+10 > 498) magnificationDisplay = 498;
                else magnificationDisplay = magnificationDisplay+10;
                
                xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
                yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
            }
        }
        
        //----Magnification space bar----
        if (keyCode == 49){
            proceedFlag = 1;
            magnificationDisplay = (int)(200/((double)(50/(double)imageWidthDisplay)*(double)500)*(double)10);
            xPositionAdjustDisplay = (imageWidthDisplay-imageWidthDisplay/(double)(magnificationDisplay*0.1))/(double)2;
            yPositionAdjustDisplay = (imageHeightDisplay-imageHeightDisplay/(double)(magnificationDisplay*0.1))/(double)2;
        }
        
        if (proceedFlag == 1) [self setNeedsDisplay:YES];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (exportFlag9 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 537, 537)];
        [path fill];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(488, 515, 44, 14)];
        [path stroke];
        
        string ifString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 490;
        pointA.y = 515;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(438, 515, 44, 14)];
        [path stroke];
        
        ifString = "Export";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 440;
        pointA.y = 515;
        [attrStrA drawAtPoint:pointA];
        
        NSRect srcRect;
        srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
        srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
        srcRect.size.width = imageWidthDisplay/(double)(magnificationDisplay*0.1);
        srcRect.size.height = imageHeightDisplay/(double)(magnificationDisplay*0.1);
        
        if (motilityAnalysisPerformHold == 2 && mouseDragFlag == 0){
            double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
            double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
            double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
            double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
            
            int lineageSelectNo = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10].c_str());
            int timeStart = motilityTimeStartHold;
            int timeEnd = motilityTimeEndHold;
            
            if (timeEnd > arrayTableDetail [lineageSelectNo][3]) timeEnd = arrayTableDetail [lineageSelectNo][3];
            
            int *arrayMotilityBasicInfo = new int [(arrayLineageDataEntryHold [lineageSelectNo]/9)*6+100];
            int *arrayCellLineageTemp = new int [(arrayLineageDataEntryHold [lineageSelectNo]/9)*9+100];
            
            for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [lineageSelectNo]/9)*6+100; counter3++){
                arrayMotilityBasicInfo [counter3] = 0;
            }
            
            for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [lineageSelectNo]/9)*9+100; counter3++){
                arrayCellLineageTemp [counter3] = 0;
            }
            
            int displayFrequency = 1;
            
            if (arrayLineageDataEntryHold [lineageSelectNo] >= 10000000){
                if (magnificationDisplay == 10) displayFrequency = 15;
                else if (magnificationDisplay >= 12 && magnificationDisplay < 15) displayFrequency = 13;
                else if (magnificationDisplay >= 15 && magnificationDisplay < 17) displayFrequency = 11;
                else if (magnificationDisplay >= 17 && magnificationDisplay < 19) displayFrequency = 9;
                else if (magnificationDisplay >= 19 && magnificationDisplay < 21) displayFrequency = 7;
                else if (magnificationDisplay >= 21 && magnificationDisplay < 23) displayFrequency = 5;
                else if (magnificationDisplay >= 23 && magnificationDisplay < 25) displayFrequency = 3;
                else if (magnificationDisplay >= 25) displayFrequency = 1;
            }
            else if (arrayLineageDataEntryHold [lineageSelectNo] < 10000000 && arrayLineageDataEntryHold [lineageSelectNo] >= 5000000){
                if (magnificationDisplay == 10) displayFrequency = 8;
                else if (magnificationDisplay >= 12 && magnificationDisplay < 15) displayFrequency = 7;
                else if (magnificationDisplay >= 15 && magnificationDisplay < 17) displayFrequency = 6;
                else if (magnificationDisplay >= 17 && magnificationDisplay < 19) displayFrequency = 5;
                else if (magnificationDisplay >= 19 && magnificationDisplay < 21) displayFrequency = 4;
                else if (magnificationDisplay >= 21 && magnificationDisplay < 23) displayFrequency = 3;
                else if (magnificationDisplay >= 23 && magnificationDisplay < 25) displayFrequency = 2;
                else if (magnificationDisplay >= 25) displayFrequency = 1;
            }
            else if (arrayLineageDataEntryHold [lineageSelectNo] < 5000000 && arrayLineageDataEntryHold [lineageSelectNo] >= 200000){
                if (magnificationDisplay == 10) displayFrequency = 4;
                else if (magnificationDisplay >= 12 && magnificationDisplay < 15) displayFrequency = 3;
                else if (magnificationDisplay >= 15 && magnificationDisplay < 17) displayFrequency = 2;
                else if (magnificationDisplay >= 17) displayFrequency = 1;
            }
            
            int motilityBasicInfoCount = 0;
            int xPositionMotility = 0;
            int yPositionMotility = 0;
            int lingNoHoldMotility = 0;
            int cellNoHoldMotility = 0;
            int maxLineageNo = 0;
            int cellDataSortCount = 0;
            int lineageDataSortCount = 0;
            int cellNoExtractCount = 0;
            int cellNoExtractCount2 = 0;
            int dataSetStart = 0;
            int cellLineageTempCount = 0;
           
            if (activationStatus == 1){
                int timePoint = 0;
                int lineageNoTemp = 0;
                int cellNoTemp = -1;
                int eventType = 0;
                unsigned long typeMarkFound = 0;
                unsigned long currentPosition = 0;
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [lineageSelectNo]/9; counter3++){
                    if ((arrayLineageData [lineageSelectNo][counter3*9+5] != cellNoTemp || arrayLineageData [lineageSelectNo][counter3*9+6] != lineageNoTemp) && timePoint == 0){
                        timePoint = arrayLineageData [lineageSelectNo][counter3*9+2];
                        lineageNoTemp = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoTemp = arrayLineageData [lineageSelectNo][counter3*9+5];
                        eventType = arrayLineageData [lineageSelectNo][counter3*9+3];
                        currentPosition = counter3;
                    }
                    else if ((arrayLineageData [lineageSelectNo][counter3*9+5] != cellNoTemp || arrayLineageData [lineageSelectNo][counter3*9+6] != lineageNoTemp) && timePoint != 0){
                        if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                            for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        else{
                            
                            for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        
                        typeMarkFound = 0;
                        
                        timePoint = arrayLineageData [lineageSelectNo][counter3*9+2];
                        lineageNoTemp = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoTemp = arrayLineageData [lineageSelectNo][counter3*9+5];
                        eventType = arrayLineageData [lineageSelectNo][counter3*9+3];
                        currentPosition = counter3;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+3] == 10 && eventType == 1){
                        typeMarkFound = counter3;
                    }
                    else if (counter3 == arrayLineageDataEntryHold [lineageSelectNo]/9-1 && timePoint != 0){
                        if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                            for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        else{
                            
                            for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        
                        typeMarkFound = 0;
                    }
                }
                
                motilityBasicInfoCount = 0;
                maxLineageNo = 0;
                dataSetStart = 0;
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [lineageSelectNo]/9; counter3++){
                    if (maxLineageNo < arrayCellLineageTemp [counter3*9+6]) maxLineageNo = arrayCellLineageTemp [counter3*9+6];
                    
                    if (arrayCellLineageTemp [counter3*9+2] >= timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && dataSetStart == 0){
                        xPositionMotility = arrayCellLineageTemp [counter3*9];
                        yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                        
                        lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                        cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 1;
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] > timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                        
                        xPositionMotility = arrayCellLineageTemp [counter3*9];
                        yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] == timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 0;
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] > timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && lingNoHoldMotility != arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility != arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        xPositionMotility = arrayCellLineageTemp [counter3*9];
                        yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                        
                        lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                        cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] == timeEnd && lingNoHoldMotility != arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility != arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        dataSetStart = 0;
                    }
                }
            }
            else{
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [lineageSelectNo]/9; counter3++){
                    if (maxLineageNo < arrayLineageData [lineageSelectNo][counter3*9+6]) maxLineageNo = arrayLineageData [lineageSelectNo][counter3*9+6];
                    
                    if (arrayLineageData [lineageSelectNo][counter3*9+2] >= timeStart && arrayLineageData [lineageSelectNo][counter3*9+2] < timeEnd && dataSetStart == 0){
                        xPositionMotility = arrayLineageData [lineageSelectNo][counter3*9];
                        yPositionMotility = arrayLineageData [lineageSelectNo][counter3*9+1];
                        
                        lingNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 1;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] > timeStart && arrayLineageData [lineageSelectNo][counter3*9+2] < timeEnd && lingNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                        
                        xPositionMotility = arrayLineageData [lineageSelectNo][counter3*9];
                        yPositionMotility = arrayLineageData [lineageSelectNo][counter3*9+1];
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] == timeEnd && lingNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 0;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] > timeStart && arrayLineageData [lineageSelectNo][counter3*9+2] < timeEnd && lingNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        xPositionMotility = arrayLineageData [lineageSelectNo][counter3*9];
                        yPositionMotility = arrayLineageData [lineageSelectNo][counter3*9+1];
                        
                        lingNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] == timeEnd && lingNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        dataSetStart = 0;
                    }
                }
            }
            
            delete [] arrayCellLineageTemp;
            
            if (displayOptionStatus == 2 || displayOptionStatus == 3){
                int *motilityTemp = new int [motilityBasicInfoCount+50];
                int motilityTempCount = 0;
                
                double xPositionDiff = 0;
                double yPositionDiff = 0;
                int lineageNoTempHold = 0;
                int cellNoTempHold = 0;
                int firstFind = 0;
                int distanceTempCount = 0;
                int adjustStart = 0;
                int adjustEnd = 0;
                int lineagePositionHold = 0;
                int entryCount = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (lineageNoTempHold != arrayMotilityBasicInfo [counter3*6] && cellNoTempHold != arrayMotilityBasicInfo [counter3*6+1] && firstFind == 0){
                        lineageNoTempHold = arrayMotilityBasicInfo [counter3*6];
                        cellNoTempHold = arrayMotilityBasicInfo [counter3*6+1];
                        
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+2], motilityTempCount++;
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+3], motilityTempCount++;
                        
                        firstFind = 1;
                        lineagePositionHold = counter3;
                    }
                    else if (lineageNoTempHold == arrayMotilityBasicInfo [counter3*6] && cellNoTempHold == arrayMotilityBasicInfo [counter3*6+1] && firstFind == 1){
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+2], motilityTempCount++;
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+3], motilityTempCount++;
                    }
                    else if (((lineageNoTempHold != arrayMotilityBasicInfo [counter3*6] || cellNoTempHold != arrayMotilityBasicInfo [counter3*6+1]) || counter3 == motilityBasicInfoCount/6-1) && firstFind == 1){
                        distanceTempCount = 0;
                        
                        double *distanceTemp = new double [motilityTempCount/2+10];
                        distanceTemp [0] = -1, distanceTempCount++;
                        xPositionDiff = motilityTemp [0];
                        yPositionDiff = motilityTemp [1];
                        
                        for (int counter4 = 1; counter4 < motilityTempCount/2; counter4++){
                            distanceTemp [distanceTempCount] = sqrt((xPositionDiff-motilityTemp [counter4*2])*(xPositionDiff-motilityTemp [counter4*2])+(yPositionDiff-motilityTemp [counter4*2+1])*(yPositionDiff-motilityTemp [counter4*2+1])), distanceTempCount++;
                            
                            xPositionDiff = motilityTemp [counter4*2];
                            yPositionDiff = motilityTemp [counter4*2+1];
                        }
                        
                        adjustStart = 0;
                        adjustEnd = 0;
                        
                        for (int counter4 = 0; counter4 < distanceTempCount; counter4++){
                            if (distanceTemp  [counter4] == 0 && adjustStart == 0){
                                adjustStart = counter4;
                            }
                            else if (distanceTemp [counter4] != 0 && adjustStart != 0){
                                adjustEnd = counter4;
                            }
                            
                            if (adjustStart != 0 && adjustEnd != 0){
                                adjustStart--;
                                
                                xPositionDiff = (motilityTemp [adjustEnd*2]-motilityTemp [adjustStart*2])/(double)(adjustEnd-adjustStart);
                                yPositionDiff = (motilityTemp [adjustEnd*2+1]-motilityTemp [adjustStart*2+1])/(double)(adjustEnd-adjustStart);
                                
                                entryCount = 1;
                                
                                for (int counter5 = adjustStart+1; counter5 < adjustEnd-1; counter5++){
                                    motilityTemp [counter5*2] = motilityTemp [counter5*2]+(int)(xPositionDiff*entryCount);
                                    motilityTemp [counter5*2+1] = motilityTemp [counter5*2+1]+(int)(yPositionDiff*entryCount);
                                    entryCount++;
                                }
                                
                                adjustStart = 0;
                                adjustEnd = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < motilityTempCount/2; counterA++){
                        //  for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< motilityTemp [counterA*2+counterB];
                        //   cout<<"  motilityTemp "<<counterA<<endl;
                        //}
                        
                        for (int counter4 = 0; counter4 < motilityTempCount/2; counter4++){
                            arrayMotilityBasicInfo [lineagePositionHold*6+2] = motilityTemp [counter4*2];
                            arrayMotilityBasicInfo [lineagePositionHold*6+3] = motilityTemp [counter4*2+1];
                        }
                        
                        if (counter3 != motilityBasicInfoCount/6-1){
                            motilityTempCount = 0;
                            
                            motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+2], motilityTempCount++;
                            motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+3], motilityTempCount++;
                            
                            lineagePositionHold = counter3;
                            lineageNoTempHold = arrayMotilityBasicInfo [counter3*6];
                            cellNoTempHold = arrayMotilityBasicInfo [counter3*6+1];
                        }
                        
                        delete [] distanceTemp;
                    }
                }
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    arrayMotilityBasicInfo [counter3*6+2] = arrayMotilityBasicInfo [counter3*6+2]+(int)(shiftX*arrayMotilityBasicInfo [counter3*6+5]);
                    arrayMotilityBasicInfo [counter3*6+3] = arrayMotilityBasicInfo [counter3*6+3]+(int)(shiftY*arrayMotilityBasicInfo [counter3*6+5]);
                }
                
                delete [] motilityTemp;
            }
            
            if ((displayOptionStatus == 1 || displayOptionStatus == 3) && (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3)){
                int *motilityTemp = new int [motilityBasicInfoCount+50];
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    motilityTemp [counter3*5] = arrayMotilityBasicInfo [counter3*6];
                    motilityTemp [counter3*5+1] = arrayMotilityBasicInfo [counter3*6+1];
                    motilityTemp [counter3*5+2] = arrayMotilityBasicInfo [counter3*6+2];
                    motilityTemp [counter3*5+3] = arrayMotilityBasicInfo [counter3*6+3];
                    motilityTemp [counter3*5+4] = arrayMotilityBasicInfo [counter3*6+4];
                }
                
                int lineageNoTempHold = 0;
                int xPositionDiff = 0;
                int yPositionDiff = 0;
                int firstFind = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (lineageNoTempHold != motilityTemp [counter3*5] && firstFind == 0){
                        lineageNoTempHold = motilityTemp [counter3*5];
                        xPositionDiff = motilityTemp [counter3*5+2];
                        yPositionDiff = motilityTemp [counter3*5+3];
                        
                        motilityTemp [counter3*5+2] = 0;
                        motilityTemp [counter3*5+3] = 0;
                        
                        firstFind = 1;
                    }
                    else if (lineageNoTempHold == motilityTemp [counter3*5] && firstFind == 1){
                        motilityTemp [counter3*5+2] = motilityTemp [counter3*5+2]-xPositionDiff;
                        motilityTemp [counter3*5+3] = motilityTemp [counter3*5+3]-yPositionDiff;
                    }
                    else if (lineageNoTempHold != motilityTemp [counter3*5] && firstFind == 1){
                        lineageNoTempHold = motilityTemp [counter3*5];
                        xPositionDiff = motilityTemp [counter3*5+2];
                        yPositionDiff = motilityTemp [counter3*5+3];
                        
                        motilityTemp [counter3*5+2] = 0;
                        motilityTemp [counter3*5+3] = 0;
                    }
                }
                
                int adjustXMin = 0;
                int adjustYMin = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (adjustXMin > motilityTemp [counter3*5+2]) adjustXMin = motilityTemp [counter3*5+2];
                    if (adjustYMin > motilityTemp [counter3*5+3]) adjustYMin = motilityTemp [counter3*5+3];
                }
                
                int adjustFinal = 0;
                
                if (adjustXMin < adjustYMin) adjustFinal = adjustXMin;
                else adjustFinal = adjustYMin;
                
                if (adjustFinal < 0){
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                        motilityTemp [counter3*5+2] = motilityTemp [counter3*5+2]-adjustFinal+10;
                        motilityTemp [counter3*5+3] = motilityTemp [counter3*5+3]-adjustFinal+10;
                    }
                }
                
                int centeringX = ((motilityDisplayScaleMaxHold-20)/2)-motilityTemp [2];
                int centeringY = ((motilityDisplayScaleMaxHold-20)/2)-motilityTemp [3];
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    motilityTemp [counter3*5+2] = motilityTemp [counter3*5+2]+centeringX;
                    motilityTemp [counter3*5+3] = motilityTemp [counter3*5+3]+centeringY;
                }
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    arrayMotilityBasicInfo [counter3*6+2] = motilityTemp [counter3*5+2];
                    arrayMotilityBasicInfo [counter3*6+3] = motilityTemp [counter3*5+3];
                }
                
                delete [] motilityTemp;
            }
            
            //for (int counterA = 0; counterA < motilityBasicInfoCount/6; counterA++){
            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*6+counterB];
            //   cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
            //}
            
            CGFloat *cellDataSort = new CGFloat [(motilityBasicInfoCount/6)*5+100];
            cellDataSortCount = 0;
            
            CGFloat *lineageDataSort = new CGFloat [maxLineageNo*10+100];
            lineageDataSortCount = 0;
            
            int *cellNoExtract = new int [arrayTableDetail [lineageSelectNo][9]+10];
            int *cellNoExtract2 = new int [arrayTableDetail [lineageSelectNo][9]+10];
            
            int cellNoFind = 0;
            int terminationFlag = 0;
            int smallestCellNo = 0;
            int smallestCellPosition = 0;
            
            for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                cellNoExtractCount = 0;
                
                for (int counter4 = 0; counter4 < motilityBasicInfoCount/6; counter4++){
                    if (counter3 == arrayMotilityBasicInfo [counter4*6]){
                        cellNoFind = 0;
                        
                        for (int counter5 = 0; counter5 < cellNoExtractCount; counter5++){
                            if (cellNoExtract [counter5] == arrayMotilityBasicInfo [counter4*6+1]){
                                cellNoFind = 1;
                                break;
                            }
                        }
                        
                        if (cellNoFind == 0){
                            cellNoExtract [cellNoExtractCount] = arrayMotilityBasicInfo [counter4*6+1], cellNoExtractCount++;
                        }
                    }
                }
                
                if (cellNoExtractCount != 0){
                    cellNoExtractCount2 = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        smallestCellNo = 999999999;
                        smallestCellPosition = 0;
                        
                        for (int counter4 = 0; counter4 < cellNoExtractCount; counter4++){
                            if (cellNoExtract [counter4] < smallestCellNo && cellNoExtract [counter4] != -2){
                                smallestCellNo = cellNoExtract [counter4];
                                smallestCellPosition = counter4;
                            }
                        }
                        
                        if (smallestCellNo != 999999999){
                            cellNoExtract2 [cellNoExtractCount2] = cellNoExtract [smallestCellPosition], cellNoExtractCount2++;
                            cellNoExtract [smallestCellPosition] = -2;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    for (int counter4 = 0; counter4 < cellNoExtractCount2; counter4++){
                        cellDataSort [cellDataSortCount] = counter3, cellDataSortCount++; //----Ling no
                        cellDataSort [cellDataSortCount] = cellNoExtract2 [counter4], cellDataSortCount++; //----Cell no
                        cellDataSort [cellDataSortCount] = 0, cellDataSortCount++;
                        cellDataSort [cellDataSortCount] = 0, cellDataSortCount++;
                        cellDataSort [cellDataSortCount] = 0, cellDataSortCount++;
                    }
                }
            }
            
            srand((unsigned)time(NULL));
            
            for (int counter1 = 0; counter1 < cellDataSortCount/5; counter1++){
                cellDataSort [counter1*5+2] = (rand()%255)/(double)255;
                cellDataSort [counter1*5+3] = (rand()%255)/(double)255;
                cellDataSort [counter1*5+4] = (rand()%255)/(double)255;
            }
            
            if (motilityColorStatusHold == 2){
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    for (int counter4 = 0; counter4 < cellDataSortCount/5; counter4++){
                        if (cellDataSort [counter4*5] == arrayMotilityBasicInfo [counter3*6] && cellDataSort [counter4*5+1] == arrayMotilityBasicInfo [counter3*6+1]){
                            arrayMotilityBasicInfo [counter3*6+4] = counter4;
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellDataSortCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< to_string(cellDataSort [counterA*7+counterB]);
            //    cout<<"  cellDataSort "<<counterA<<endl;
            //}
            
            srand((unsigned)time(NULL));
            
            for (int counter3 = 0; counter3 < cellDataSortCount/5; counter3++){
                cellNoFind = 0;
                
                for (int counter4 = 0; counter4 < lineageDataSortCount/4; counter4++){
                    if (cellDataSort [counter3*5] == lineageDataSort [counter4*4]){
                        cellNoFind = 1;
                        break;
                    }
                }
                
                if (cellNoFind == 0){
                    lineageDataSort [lineageDataSortCount] = cellDataSort [counter3*5], lineageDataSortCount++;
                    lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                    lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                    lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                }
            }
            
            srand((unsigned)time(NULL));
            
            for (int counter1 = 0; counter1 < lineageDataSortCount/4; counter1++){
                lineageDataSort [counter1*4+1] = (rand()%255)/(double)255;
                lineageDataSort [counter1*4+2] = (rand()%255)/(double)255;
                lineageDataSort [counter1*4+3] = (rand()%255)/(double)255;
            }
            
            if (motilityColorStatusHold == 1){
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    for (int counter4 = 0; counter4 < lineageDataSortCount/4; counter4++){
                        if (lineageDataSort [counter4*4] == arrayMotilityBasicInfo [counter3*6]){
                            arrayMotilityBasicInfo [counter3*6+4] = counter4;
                            break;
                        }
                    }
                }
            }
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            if ((displayOptionStatus == 1 || displayOptionStatus == 3) && (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3)){
                int horizontalLine = arrayMotilityBasicInfo [2]-motilityVerticalStartHold;
                int verticalLine = arrayMotilityBasicInfo [3]-motilityHorizontalStartHold;
                
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:2];
                
                positionAA.x = (int)(((10-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                positionAA.y = (int)(((imageHeightDisplay-horizontalLine)-yPositionAdj)*(double)yCalValue);
                positionBB.x = (int)((((motilityDisplayScaleMaxHold-10)-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                positionBB.y = (int)(((imageHeightDisplay-horizontalLine)-yPositionAdj)*(double)yCalValue);
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = (int)((verticalLine-xPositionAdj)*(double)xCalValue);
                positionAA.y = (int)(((imageHeightDisplay-(10-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                positionBB.x = (int)((verticalLine-xPositionAdj)*(double)xCalValue);
                positionBB.y = (int)(((imageHeightDisplay-((motilityDisplayScaleMaxHold-10)-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [NSBezierPath setDefaultLineWidth:lingLineWidthDisplayMortHold];
            
            if (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3){
                int lineageStart = 0;
                int cellStart = -1;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3 = counter3+displayFrequency){
                    if ((arrayMotilityBasicInfo [counter3*6] != lineageStart || arrayMotilityBasicInfo [counter3*6+1] != cellStart) && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1){
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                        
                        lineageStart = arrayMotilityBasicInfo [counter3*6];
                        cellStart = arrayMotilityBasicInfo [counter3*6+1];
                    }
                    else if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart){
                        if ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue) > 0 && (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue) > 0 && (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue) < 537 && (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue) < 537){
                            if (motilityColorStatusHold == 0){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 1){
                                [[NSColor colorWithCalibratedRed:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+1] green:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+2] blue:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+3] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 2){
                                [[NSColor colorWithCalibratedRed:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+2] green:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+3] blue:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+4] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                    }
                }
            }
            else if (motilityTableCategoryHold == 1 || motilityTableCategoryHold == 4){
                int lineageStart = atoi(motilityLineageHold.substr(1).c_str());
                int cellStart = -1;
                int startCirclePosition = 0;
                int endCirclePosition = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] != cellStart && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1){
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                        cellStart = arrayMotilityBasicInfo [counter3*6+1];
                        
                        startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                        endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                       
                        [[NSColor colorWithCalibratedRed:arrayColorRange [markerStartColorHold] green:arrayColorRange [markerStartColorHold+1] blue:arrayColorRange [markerStartColorHold+2] alpha:1] set];
                        path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(startCirclePosition, endCirclePosition, 13, 13)];
                        [path fill];
                    }
                    else if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1){
                        if ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue) > 0 && (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue) > 0 && (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue) < 537 && (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue) < 537){
                            
                            if (motilityColorStatusHold == 0){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 1){
                                [[NSColor colorWithCalibratedRed:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+1] green:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+2] blue:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+3] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 2){
                                [[NSColor colorWithCalibratedRed:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+2] green:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+3] blue:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+4] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                           
                            if (markerMidValueHold > 0 && markerMidValueHold == arrayMotilityBasicInfo [counter3*6+5]){
                                startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [markerMidColorHold] green:arrayColorRange [markerMidColorHold+1] blue:arrayColorRange [markerMidColorHold+2] alpha:1] set];
                                path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(startCirclePosition, endCirclePosition, 13, 13)];
                                [path fill];
                            }
                        }
                        
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                    }
                }
                
                startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                
                [[NSColor colorWithCalibratedRed:arrayColorRange [markerEndColorHold] green:arrayColorRange [markerEndColorHold+1] blue:arrayColorRange [markerEndColorHold+2] alpha:1] set];
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(startCirclePosition, endCirclePosition, 13, 13)];
                [path fill];
            }
            else if (motilityTableCategoryHold == 2 || motilityTableCategoryHold == 5){
                int lineageStart = atoi(motilityLineageHold.substr(1).c_str());
                int cellStart = motilityCellNoHold;
                int firstEntry = 0;
                int startCirclePosition = 0;
                int endCirclePosition = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1 && firstEntry == 0){
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                        
                        startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                        endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                       
                        path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(startCirclePosition, endCirclePosition, 13, 13)];
                        [path fill];
                        
                        firstEntry = 1;
                    }
                    else if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart && firstEntry == 1){
                        if ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue) > 0 && (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue) > 0 && (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue) < 537 && (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue) < 537){
                            if (motilityColorStatusHold == 0){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 1){
                                [[NSColor colorWithCalibratedRed:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+1] green:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+2] blue:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+3] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 2){
                                [[NSColor colorWithCalibratedRed:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+2] green:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+3] blue:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+4] alpha:1] set];
                                
                                positionAA.x = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue);
                                positionAA.y = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue);
                                positionBB.x = (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue);
                                positionBB.y = (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue);
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                    }
                }
            }
            
            delete [] arrayMotilityBasicInfo;
            delete [] cellDataSort;
            delete [] lineageDataSort;
            delete [] cellNoExtract;
            delete [] cellNoExtract2;
        }
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:539*magFactor pixelsHigh:539*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:539*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 539*magFactor, 539*magFactor)];
        [path fill];
        
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:12*magFactor] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        NSRect srcRect;
        srcRect.origin.x = xPositionDisplay+xPositionAdjustDisplay+xPositionMoveDisplay;
        srcRect.origin.y = yPositionDisplay+yPositionAdjustDisplay+yPositionMoveDisplay;
        srcRect.size.width = imageWidthDisplay/(double)(magnificationDisplay*0.1);
        srcRect.size.height = imageHeightDisplay/(double)(magnificationDisplay*0.1);
        
        if (motilityAnalysisPerformHold == 2 && mouseDragFlag == 0){
            double xPositionAdj = xPositionAdjustDisplay+xPositionDisplay;
            double yPositionAdj = yPositionAdjustDisplay+yPositionDisplay;
            double xCalValue = 1/(double)windowWidthDisplay*magnificationDisplay*0.1;
            double yCalValue = 1/(double)windowHeightDisplay*magnificationDisplay*0.1;
            
            int lineageSelectNo = atoi(arrayMotilityResultsHold [motilityOperationTableCurrentRow*10].c_str());
            int timeStart = motilityTimeStartHold;
            int timeEnd = motilityTimeEndHold;
            
            if (timeEnd > arrayTableDetail [lineageSelectNo][3]) timeEnd = arrayTableDetail [lineageSelectNo][3];
            
            int *arrayMotilityBasicInfo = new int [(arrayLineageDataEntryHold [lineageSelectNo]/9)*6+100];
            int *arrayCellLineageTemp = new int [(arrayLineageDataEntryHold [lineageSelectNo]/9)*9+100];
            
            for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [lineageSelectNo]/9)*6+100; counter3++){
                arrayMotilityBasicInfo [counter3] = 0;
            }
            
            for (unsigned long counter3 = 0; counter3 < (arrayLineageDataEntryHold [lineageSelectNo]/9)*9+100; counter3++){
                arrayCellLineageTemp [counter3] = 0;
            }
            
            int displayFrequency = 1;
            
            if (arrayLineageDataEntryHold [lineageSelectNo] >= 10000000){
                if (magnificationDisplay == 10) displayFrequency = 15;
                else if (magnificationDisplay >= 12 && magnificationDisplay < 15) displayFrequency = 13;
                else if (magnificationDisplay >= 15 && magnificationDisplay < 17) displayFrequency = 11;
                else if (magnificationDisplay >= 17 && magnificationDisplay < 19) displayFrequency = 9;
                else if (magnificationDisplay >= 19 && magnificationDisplay < 21) displayFrequency = 7;
                else if (magnificationDisplay >= 21 && magnificationDisplay < 23) displayFrequency = 5;
                else if (magnificationDisplay >= 23 && magnificationDisplay < 25) displayFrequency = 3;
                else if (magnificationDisplay >= 25) displayFrequency = 1;
            }
            else if (arrayLineageDataEntryHold [lineageSelectNo] < 10000000 && arrayLineageDataEntryHold [lineageSelectNo] >= 5000000){
                if (magnificationDisplay == 10) displayFrequency = 8;
                else if (magnificationDisplay >= 12 && magnificationDisplay < 15) displayFrequency = 7;
                else if (magnificationDisplay >= 15 && magnificationDisplay < 17) displayFrequency = 6;
                else if (magnificationDisplay >= 17 && magnificationDisplay < 19) displayFrequency = 5;
                else if (magnificationDisplay >= 19 && magnificationDisplay < 21) displayFrequency = 4;
                else if (magnificationDisplay >= 21 && magnificationDisplay < 23) displayFrequency = 3;
                else if (magnificationDisplay >= 23 && magnificationDisplay < 25) displayFrequency = 2;
                else if (magnificationDisplay >= 25) displayFrequency = 1;
            }
            else if (arrayLineageDataEntryHold [lineageSelectNo] < 5000000 && arrayLineageDataEntryHold [lineageSelectNo] >= 200000){
                if (magnificationDisplay == 10) displayFrequency = 4;
                else if (magnificationDisplay >= 12 && magnificationDisplay < 15) displayFrequency = 3;
                else if (magnificationDisplay >= 15 && magnificationDisplay < 17) displayFrequency = 2;
                else if (magnificationDisplay >= 17) displayFrequency = 1;
            }
            
            int motilityBasicInfoCount = 0;
            int xPositionMotility = 0;
            int yPositionMotility = 0;
            int lingNoHoldMotility = 0;
            int cellNoHoldMotility = 0;
            int maxLineageNo = 0;
            int cellDataSortCount = 0;
            int lineageDataSortCount = 0;
            int cellNoExtractCount = 0;
            int cellNoExtractCount2 = 0;
            int dataSetStart = 0;
            int cellLineageTempCount = 0;
            
            if (activationStatus == 1){
                int timePoint = 0;
                int lineageNoTemp = 0;
                int cellNoTemp = -1;
                int eventType = 0;
                unsigned long typeMarkFound = 0;
                unsigned long currentPosition = 0;
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [lineageSelectNo]/9; counter3++){
                    if ((arrayLineageData [lineageSelectNo][counter3*9+5] != cellNoTemp || arrayLineageData [lineageSelectNo][counter3*9+6] != lineageNoTemp) && timePoint == 0){
                        timePoint = arrayLineageData [lineageSelectNo][counter3*9+2];
                        lineageNoTemp = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoTemp = arrayLineageData [lineageSelectNo][counter3*9+5];
                        eventType = arrayLineageData [lineageSelectNo][counter3*9+3];
                        currentPosition = counter3;
                    }
                    else if ((arrayLineageData [lineageSelectNo][counter3*9+5] != cellNoTemp || arrayLineageData [lineageSelectNo][counter3*9+6] != lineageNoTemp) && timePoint != 0){
                        if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                            for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        else{
                            
                            for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        
                        typeMarkFound = 0;
                        
                        timePoint = arrayLineageData [lineageSelectNo][counter3*9+2];
                        lineageNoTemp = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoTemp = arrayLineageData [lineageSelectNo][counter3*9+5];
                        eventType = arrayLineageData [lineageSelectNo][counter3*9+3];
                        currentPosition = counter3;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+3] == 10 && eventType == 1){
                        typeMarkFound = counter3;
                    }
                    else if (counter3 == arrayLineageDataEntryHold [lineageSelectNo]/9-1 && timePoint != 0){
                        if (typeMarkFound != 0 && counter3-2 != typeMarkFound){
                            for (unsigned long counter4 = typeMarkFound; counter4 <= counter3-1; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        else{
                            
                            for (unsigned long counter4 = currentPosition; counter4 < counter3; counter4++){
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+1], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+2], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+3], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+4], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+5], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+6], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+7], cellLineageTempCount++;
                                arrayCellLineageTemp [cellLineageTempCount] = arrayLineageData [lineageSelectNo][counter4*9+8], cellLineageTempCount++;
                            }
                        }
                        
                        typeMarkFound = 0;
                    }
                }
                
                motilityBasicInfoCount = 0;
                maxLineageNo = 0;
                dataSetStart = 0;
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [lineageSelectNo]/9; counter3++){
                    if (maxLineageNo < arrayCellLineageTemp [counter3*9+6]) maxLineageNo = arrayCellLineageTemp [counter3*9+6];
                    
                    if (arrayCellLineageTemp [counter3*9+2] >= timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && dataSetStart == 0){
                        xPositionMotility = arrayCellLineageTemp [counter3*9];
                        yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                        
                        lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                        cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 1;
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] > timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                        
                        xPositionMotility = arrayCellLineageTemp [counter3*9];
                        yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] == timeEnd && lingNoHoldMotility == arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility == arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 0;
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] > timeStart && arrayCellLineageTemp [counter3*9+2] < timeEnd && lingNoHoldMotility != arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility != arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        xPositionMotility = arrayCellLineageTemp [counter3*9];
                        yPositionMotility = arrayCellLineageTemp [counter3*9+1];
                        
                        lingNoHoldMotility = arrayCellLineageTemp [counter3*9+6];
                        cellNoHoldMotility = arrayCellLineageTemp [counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayCellLineageTemp [counter3*9+2], motilityBasicInfoCount++;
                    }
                    else if (arrayCellLineageTemp [counter3*9+2] == timeEnd && lingNoHoldMotility != arrayCellLineageTemp [counter3*9+5] && cellNoHoldMotility != arrayCellLineageTemp [counter3*9+6] && dataSetStart == 1){
                        dataSetStart = 0;
                    }
                }
            }
            else{
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [lineageSelectNo]/9; counter3++){
                    if (maxLineageNo < arrayLineageData [lineageSelectNo][counter3*9+6]) maxLineageNo = arrayLineageData [lineageSelectNo][counter3*9+6];
                    
                    if (arrayLineageData [lineageSelectNo][counter3*9+2] >= timeStart && arrayLineageData [lineageSelectNo][counter3*9+2] < timeEnd && dataSetStart == 0){
                        xPositionMotility = arrayLineageData [lineageSelectNo][counter3*9];
                        yPositionMotility = arrayLineageData [lineageSelectNo][counter3*9+1];
                        
                        lingNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 1;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] > timeStart && arrayLineageData [lineageSelectNo][counter3*9+2] < timeEnd && lingNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                        
                        xPositionMotility = arrayLineageData [lineageSelectNo][counter3*9];
                        yPositionMotility = arrayLineageData [lineageSelectNo][counter3*9+1];
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] == timeEnd && lingNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility == arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                        
                        dataSetStart = 0;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] > timeStart && arrayLineageData [lineageSelectNo][counter3*9+2] < timeEnd && lingNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        xPositionMotility = arrayLineageData [lineageSelectNo][counter3*9];
                        yPositionMotility = arrayLineageData [lineageSelectNo][counter3*9+1];
                        
                        lingNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+6];
                        cellNoHoldMotility = arrayLineageData [lineageSelectNo][counter3*9+5];
                        
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+6], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+5], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+1], motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = -1, motilityBasicInfoCount++;
                        arrayMotilityBasicInfo [motilityBasicInfoCount] = arrayLineageData [lineageSelectNo][counter3*9+2], motilityBasicInfoCount++;
                    }
                    else if (arrayLineageData [lineageSelectNo][counter3*9+2] == timeEnd && lingNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+5] && cellNoHoldMotility != arrayLineageData [lineageSelectNo][counter3*9+6] && dataSetStart == 1){
                        dataSetStart = 0;
                    }
                }
            }
            
            delete [] arrayCellLineageTemp;
            
            if (displayOptionStatus == 2 || displayOptionStatus == 3){
                int *motilityTemp = new int [motilityBasicInfoCount+50];
                int motilityTempCount = 0;
                
                double xPositionDiff = 0;
                double yPositionDiff = 0;
                int lineageNoTempHold = 0;
                int cellNoTempHold = 0;
                int firstFind = 0;
                int distanceTempCount = 0;
                int adjustStart = 0;
                int adjustEnd = 0;
                int lineagePositionHold = 0;
                int entryCount = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (lineageNoTempHold != arrayMotilityBasicInfo [counter3*6] && cellNoTempHold != arrayMotilityBasicInfo [counter3*6+1] && firstFind == 0){
                        lineageNoTempHold = arrayMotilityBasicInfo [counter3*6];
                        cellNoTempHold = arrayMotilityBasicInfo [counter3*6+1];
                        
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+2], motilityTempCount++;
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+3], motilityTempCount++;
                        
                        firstFind = 1;
                        lineagePositionHold = counter3;
                    }
                    else if (lineageNoTempHold == arrayMotilityBasicInfo [counter3*6] && cellNoTempHold == arrayMotilityBasicInfo [counter3*6+1] && firstFind == 1){
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+2], motilityTempCount++;
                        motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+3], motilityTempCount++;
                    }
                    else if (((lineageNoTempHold != arrayMotilityBasicInfo [counter3*6] || cellNoTempHold != arrayMotilityBasicInfo [counter3*6+1]) || counter3 == motilityBasicInfoCount/6-1) && firstFind == 1){
                        distanceTempCount = 0;
                        
                        double *distanceTemp = new double [motilityTempCount/2+10];
                        distanceTemp [0] = -1, distanceTempCount++;
                        xPositionDiff = motilityTemp [0];
                        yPositionDiff = motilityTemp [1];
                        
                        for (int counter4 = 1; counter4 < motilityTempCount/2; counter4++){
                            distanceTemp [distanceTempCount] = sqrt((xPositionDiff-motilityTemp [counter4*2])*(xPositionDiff-motilityTemp [counter4*2])+(yPositionDiff-motilityTemp [counter4*2+1])*(yPositionDiff-motilityTemp [counter4*2+1])), distanceTempCount++;
                            
                            xPositionDiff = motilityTemp [counter4*2];
                            yPositionDiff = motilityTemp [counter4*2+1];
                        }
                        
                        adjustStart = 0;
                        adjustEnd = 0;
                        
                        for (int counter4 = 0; counter4 < distanceTempCount; counter4++){
                            if (distanceTemp  [counter4] == 0 && adjustStart == 0){
                                adjustStart = counter4;
                            }
                            else if (distanceTemp [counter4] != 0 && adjustStart != 0){
                                adjustEnd = counter4;
                            }
                            
                            if (adjustStart != 0 && adjustEnd != 0){
                                adjustStart--;
                                
                                xPositionDiff = (motilityTemp [adjustEnd*2]-motilityTemp [adjustStart*2])/(double)(adjustEnd-adjustStart);
                                yPositionDiff = (motilityTemp [adjustEnd*2+1]-motilityTemp [adjustStart*2+1])/(double)(adjustEnd-adjustStart);
                                
                                entryCount = 1;
                                
                                for (int counter5 = adjustStart+1; counter5 < adjustEnd-1; counter5++){
                                    motilityTemp [counter5*2] = motilityTemp [counter5*2]+(int)(xPositionDiff*entryCount);
                                    motilityTemp [counter5*2+1] = motilityTemp [counter5*2+1]+(int)(yPositionDiff*entryCount);
                                    entryCount++;
                                }
                                
                                adjustStart = 0;
                                adjustEnd = 0;
                            }
                        }
                        
                        //for (int counterA = 0; counterA < motilityTempCount/2; counterA++){
                        //  for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< motilityTemp [counterA*2+counterB];
                        //   cout<<"  motilityTemp "<<counterA<<endl;
                        //}
                        
                        for (int counter4 = 0; counter4 < motilityTempCount/2; counter4++){
                            arrayMotilityBasicInfo [lineagePositionHold*6+2] = motilityTemp [counter4*2];
                            arrayMotilityBasicInfo [lineagePositionHold*6+3] = motilityTemp [counter4*2+1];
                        }
                        
                        if (counter3 != motilityBasicInfoCount/6-1){
                            motilityTempCount = 0;
                            
                            motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+2], motilityTempCount++;
                            motilityTemp [motilityTempCount] = arrayMotilityBasicInfo [counter3*6+3], motilityTempCount++;
                            
                            lineagePositionHold = counter3;
                            lineageNoTempHold = arrayMotilityBasicInfo [counter3*6];
                            cellNoTempHold = arrayMotilityBasicInfo [counter3*6+1];
                        }
                        
                        delete [] distanceTemp;
                    }
                }
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    arrayMotilityBasicInfo [counter3*6+2] = arrayMotilityBasicInfo [counter3*6+2]+(int)(shiftX*arrayMotilityBasicInfo [counter3*6+5]);
                    arrayMotilityBasicInfo [counter3*6+3] = arrayMotilityBasicInfo [counter3*6+3]+(int)(shiftY*arrayMotilityBasicInfo [counter3*6+5]);
                }
                
                delete [] motilityTemp;
            }
            
            if ((displayOptionStatus == 1 || displayOptionStatus == 3) && (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3)){
                int *motilityTemp = new int [motilityBasicInfoCount+50];
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    motilityTemp [counter3*5] = arrayMotilityBasicInfo [counter3*6];
                    motilityTemp [counter3*5+1] = arrayMotilityBasicInfo [counter3*6+1];
                    motilityTemp [counter3*5+2] = arrayMotilityBasicInfo [counter3*6+2];
                    motilityTemp [counter3*5+3] = arrayMotilityBasicInfo [counter3*6+3];
                    motilityTemp [counter3*5+4] = arrayMotilityBasicInfo [counter3*6+4];
                }
                
                int lineageNoTempHold = 0;
                int xPositionDiff = 0;
                int yPositionDiff = 0;
                int firstFind = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (lineageNoTempHold != motilityTemp [counter3*5] && firstFind == 0){
                        lineageNoTempHold = motilityTemp [counter3*5];
                        xPositionDiff = motilityTemp [counter3*5+2];
                        yPositionDiff = motilityTemp [counter3*5+3];
                        
                        motilityTemp [counter3*5+2] = 0;
                        motilityTemp [counter3*5+3] = 0;
                        
                        firstFind = 1;
                    }
                    else if (lineageNoTempHold == motilityTemp [counter3*5] && firstFind == 1){
                        motilityTemp [counter3*5+2] = motilityTemp [counter3*5+2]-xPositionDiff;
                        motilityTemp [counter3*5+3] = motilityTemp [counter3*5+3]-yPositionDiff;
                        
                    }
                    else if (lineageNoTempHold != motilityTemp [counter3*5] && firstFind == 1){
                        lineageNoTempHold = motilityTemp [counter3*5];
                        xPositionDiff = motilityTemp [counter3*5+2];
                        yPositionDiff = motilityTemp [counter3*5+3];
                        
                        motilityTemp [counter3*5+2] = 0;
                        motilityTemp [counter3*5+3] = 0;
                    }
                }
                
                int adjustXMin = 0;
                int adjustYMin = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (adjustXMin > motilityTemp [counter3*5+2]) adjustXMin = motilityTemp [counter3*5+2];
                    if (adjustYMin > motilityTemp [counter3*5+3]) adjustYMin = motilityTemp [counter3*5+3];
                }
                
                int adjustFinal = 0;
                
                if (adjustXMin < adjustYMin) adjustFinal = adjustXMin;
                else adjustFinal = adjustYMin;
                
                
                if (adjustFinal < 0){
                    for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                        motilityTemp [counter3*5+2] = motilityTemp [counter3*5+2]-adjustFinal+10;
                        motilityTemp [counter3*5+3] = motilityTemp [counter3*5+3]-adjustFinal+10;
                    }
                }
                
                int centeringX = ((motilityDisplayScaleMaxHold-20)/2)-motilityTemp [2];
                int centeringY = ((motilityDisplayScaleMaxHold-20)/2)-motilityTemp [3];
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    motilityTemp [counter3*5+2] = motilityTemp [counter3*5+2]+centeringX;
                    motilityTemp [counter3*5+3] = motilityTemp [counter3*5+3]+centeringY;
                }
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    arrayMotilityBasicInfo [counter3*6+2] = motilityTemp [counter3*5+2];
                    arrayMotilityBasicInfo [counter3*6+3] = motilityTemp [counter3*5+3];
                }
                
                delete [] motilityTemp;
            }
            
            //for (int counterA = 0; counterA < motilityBasicInfoCount/5; counterA++){
            //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< arrayMotilityBasicInfo [counterA*5+counterB];
            //    cout<<"  arrayMotilityBasicInfo "<<counterA<<endl;
            //}
            
            CGFloat *cellDataSort = new CGFloat [(motilityBasicInfoCount/6)*5+100];
            cellDataSortCount = 0;
            
            CGFloat *lineageDataSort = new CGFloat [maxLineageNo*10+100];
            lineageDataSortCount = 0;
            
            int *cellNoExtract = new int [arrayTableDetail [lineageSelectNo][9]+10];
            int *cellNoExtract2 = new int [arrayTableDetail [lineageSelectNo][9]+10];
            
            int cellNoFind = 0;
            int terminationFlag = 0;
            int smallestCellNo = 0;
            int smallestCellPosition = 0;
            
            for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                cellNoExtractCount = 0;
                
                for (int counter4 = 0; counter4 < motilityBasicInfoCount/6; counter4++){
                    if (counter3 == arrayMotilityBasicInfo [counter4*6]){
                        cellNoFind = 0;
                        
                        for (int counter5 = 0; counter5 < cellNoExtractCount; counter5++){
                            if (cellNoExtract [counter5] == arrayMotilityBasicInfo [counter4*6+1]){
                                cellNoFind = 1;
                                break;
                            }
                        }
                        
                        if (cellNoFind == 0){
                            cellNoExtract [cellNoExtractCount] = arrayMotilityBasicInfo [counter4*6+1], cellNoExtractCount++;
                        }
                    }
                }
                
                if (cellNoExtractCount != 0){
                    cellNoExtractCount2 = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        smallestCellNo = 999999999;
                        smallestCellPosition = 0;
                        
                        for (int counter4 = 0; counter4 < cellNoExtractCount; counter4++){
                            if (cellNoExtract [counter4] < smallestCellNo && cellNoExtract [counter4] != -2){
                                smallestCellNo = cellNoExtract [counter4];
                                smallestCellPosition = counter4;
                            }
                        }
                        
                        if (smallestCellNo != 999999999){
                            cellNoExtract2 [cellNoExtractCount2] = cellNoExtract [smallestCellPosition], cellNoExtractCount2++;
                            cellNoExtract [smallestCellPosition] = -2;
                        }
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    for (int counter4 = 0; counter4 < cellNoExtractCount2; counter4++){
                        cellDataSort [cellDataSortCount] = counter3, cellDataSortCount++; //----Ling no
                        cellDataSort [cellDataSortCount] = cellNoExtract2 [counter4], cellDataSortCount++; //----Cell no
                        cellDataSort [cellDataSortCount] = 0, cellDataSortCount++;
                        cellDataSort [cellDataSortCount] = 0, cellDataSortCount++;
                        cellDataSort [cellDataSortCount] = 0, cellDataSortCount++;
                    }
                }
            }
            
            srand((unsigned)time(NULL));
            
            for (int counter1 = 0; counter1 < cellDataSortCount/5; counter1++){
                cellDataSort [counter1*5+2] = (rand()%255)/(double)255;
                cellDataSort [counter1*5+3] = (rand()%255)/(double)255;
                cellDataSort [counter1*5+4] = (rand()%255)/(double)255;
            }
            
            if (motilityColorStatusHold == 2){
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    for (int counter4 = 0; counter4 < cellDataSortCount/5; counter4++){
                        if (cellDataSort [counter4*5] == arrayMotilityBasicInfo [counter3*6] && cellDataSort [counter4*5+1] == arrayMotilityBasicInfo [counter3*6+1]){
                            arrayMotilityBasicInfo [counter3*6+4] = counter4;
                            break;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellDataSortCount/7; counterA++){
            //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< to_string(cellDataSort [counterA*7+counterB]);
            //    cout<<"  cellDataSort "<<counterA<<endl;
            //}
            
            srand((unsigned)time(NULL));
            
            for (int counter3 = 0; counter3 < cellDataSortCount/5; counter3++){
                cellNoFind = 0;
                
                for (int counter4 = 0; counter4 < lineageDataSortCount/4; counter4++){
                    if (cellDataSort [counter3*5] == lineageDataSort [counter4*4]){
                        cellNoFind = 1;
                        break;
                    }
                }
                
                if (cellNoFind == 0){
                    lineageDataSort [lineageDataSortCount] = cellDataSort [counter3*5], lineageDataSortCount++;
                    lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                    lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                    lineageDataSort [lineageDataSortCount] = 0, lineageDataSortCount++;
                }
            }
            
            srand((unsigned)time(NULL));
            
            for (int counter1 = 0; counter1 < lineageDataSortCount/4; counter1++){
                lineageDataSort [counter1*4+1] = (rand()%255)/(double)255;
                lineageDataSort [counter1*4+2] = (rand()%255)/(double)255;
                lineageDataSort [counter1*4+3] = (rand()%255)/(double)255;
            }
            
            if (motilityColorStatusHold == 1){
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    for (int counter4 = 0; counter4 < lineageDataSortCount/4; counter4++){
                        if (lineageDataSort [counter4*4] == arrayMotilityBasicInfo [counter3*6]){
                            arrayMotilityBasicInfo [counter3*6+4] = counter4;
                            break;
                        }
                    }
                }
            }
            
            NSPoint positionAA;
            NSPoint positionBB;
            
            if ((displayOptionStatus == 1 || displayOptionStatus == 3) && (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3)){
                int horizontalLine = arrayMotilityBasicInfo [2]-motilityVerticalStartHold;
                int verticalLine = arrayMotilityBasicInfo [3]-motilityHorizontalStartHold;
                
                [[NSColor blackColor] set];
                
                [NSBezierPath setDefaultLineWidth:2*magFactor];
                
                positionAA.x = ((int)(((10-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                positionAA.y = ((int)(((imageHeightDisplay-horizontalLine)-yPositionAdj)*(double)yCalValue))*magFactor;
                positionBB.x = ((int)((((motilityDisplayScaleMaxHold-10)-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue*magFactor))*magFactor;
                positionBB.y = ((int)(((imageHeightDisplay-horizontalLine)-yPositionAdj)*(double)yCalValue))*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                positionAA.x = ((int)((verticalLine-xPositionAdj)*(double)xCalValue))*magFactor;
                positionAA.y = ((int)(((imageHeightDisplay-(10-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                positionBB.x = ((int)((verticalLine-xPositionAdj)*(double)xCalValue))*magFactor;
                positionBB.y = ((int)(((imageHeightDisplay-((motilityDisplayScaleMaxHold-10)-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
            }
            
            [NSBezierPath setDefaultLineWidth:1*magFactor*lingLineWidthMortHold];
            
            if (motilityTableCategoryHold == 0 || motilityTableCategoryHold == 3){
                int lineageStart = 0;
                int cellStart = -1;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3 = counter3+displayFrequency){
                    if ((arrayMotilityBasicInfo [counter3*6] != lineageStart || arrayMotilityBasicInfo [counter3*6+1] != cellStart) && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1){
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                        
                        lineageStart = arrayMotilityBasicInfo [counter3*6];
                        cellStart = arrayMotilityBasicInfo [counter3*6+1];
                    }
                    else if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart){
                        if ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue) > 0 && (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue) > 0 && (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue) < 537 && (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue) < 537){
                            if (motilityColorStatusHold == 0){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 1){
                                [[NSColor colorWithCalibratedRed:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+1] green:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+2] blue:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+3] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 2){
                                [[NSColor colorWithCalibratedRed:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+2] green:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+3] blue:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+4] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                    }
                }
            }
            else if (motilityTableCategoryHold == 1 || motilityTableCategoryHold == 4){
                int lineageStart = atoi(motilityLineageHold.substr(1).c_str());
                int cellStart = -1;
                int startCirclePosition = 0;
                int endCirclePosition = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] != cellStart && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1){
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                        cellStart = arrayMotilityBasicInfo [counter3*6+1];
                        
                        startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue)*magFactor;
                        endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue)*magFactor;
                       
                        [[NSColor colorWithCalibratedRed:arrayColorRange [markerStartColorHold] green:arrayColorRange [markerStartColorHold+1] blue:arrayColorRange [markerStartColorHold+2] alpha:1] set];
                        path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(startCirclePosition, endCirclePosition, 13*magFactor, 13*magFactor)];
                        [path fill];
                    }
                    else if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1){
                        if ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue) > 0 && (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue) > 0 && (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue) < 537 && (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue) < 537){
                            if (motilityColorStatusHold == 0){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 1){
                                [[NSColor colorWithCalibratedRed:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+1] green:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+2] blue:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+3] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 2){
                                [[NSColor colorWithCalibratedRed:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+2] green:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+3] blue:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+4] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            
                            if (markerMidValueHold > 0 && markerMidValueHold == arrayMotilityBasicInfo [counter3*6+5]){
                                startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue)*magFactor;
                                endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue)*magFactor;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [markerMidColorHold] green:arrayColorRange [markerMidColorHold+1] blue:arrayColorRange [markerMidColorHold+2] alpha:1] set];
                                path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(startCirclePosition, endCirclePosition, 13*magFactor, 13*magFactor)];
                                [path fill];
                            }
                        }
                        
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                    }
                }
                
                startCirclePosition = (int)((xPositionMotility-xPositionAdj)*(double)xCalValue)*magFactor;
                endCirclePosition = (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue)*magFactor;
                
                [[NSColor colorWithCalibratedRed:arrayColorRange [markerEndColorHold] green:arrayColorRange [markerEndColorHold+1] blue:arrayColorRange [markerEndColorHold+2] alpha:1] set];
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(startCirclePosition, endCirclePosition, 13*magFactor, 13*magFactor)];
                [path fill];
            }
            else if (motilityTableCategoryHold == 2 || motilityTableCategoryHold == 5){
                int lineageStart = atoi(motilityLineageHold.substr(1).c_str());
                int cellStart = motilityCellNoHold;
                int firstEntry = 0;
                
                for (int counter3 = 0; counter3 < motilityBasicInfoCount/6; counter3++){
                    if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart && arrayMotilityBasicInfo [counter3*6+2] != -1 && arrayMotilityBasicInfo [counter3*6+3] != -1 && firstEntry == 0){
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                        
                        firstEntry = 1;
                    }
                    else if (arrayMotilityBasicInfo [counter3*6] == lineageStart && arrayMotilityBasicInfo [counter3*6+1] == cellStart && firstEntry == 1){
                        if ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue) > 0 && (int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue) > 0 && (int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue) < 537 && (int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue) < 537){
                            if (motilityColorStatusHold == 0){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [motilityColorHold] green:arrayColorRange [motilityColorHold+1] blue:arrayColorRange [motilityColorHold+2] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 1){
                                [[NSColor colorWithCalibratedRed:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+1] green:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+2] blue:lineageDataSort [arrayMotilityBasicInfo [counter3*6+4]*4+3] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else if (motilityColorStatusHold == 2){
                                [[NSColor colorWithCalibratedRed:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+2] green:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+3] blue:cellDataSort [arrayMotilityBasicInfo [counter3*6+4]*5+4] alpha:1] set];
                                
                                positionAA.x = ((int)((xPositionMotility-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionAA.y = ((int)(((imageHeightDisplay-yPositionMotility)-yPositionAdj)*(double)yCalValue))*magFactor;
                                positionBB.x = ((int)(((arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold)-xPositionAdj)*(double)xCalValue))*magFactor;
                                positionBB.y = ((int)(((imageHeightDisplay-(arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold))-yPositionAdj)*(double)yCalValue))*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        
                        xPositionMotility = arrayMotilityBasicInfo [counter3*6+2]-motilityHorizontalStartHold;
                        yPositionMotility = arrayMotilityBasicInfo [counter3*6+3]-motilityVerticalStartHold;
                    }
                }
            }
            
            delete [] arrayMotilityBasicInfo;
            delete [] cellDataSort;
            delete [] lineageDataSort;
            delete [] cellNoExtract;
            delete [] cellNoExtract2;
        }
        
        [NSGraphicsContext restoreGraphicsState];
       
        if (motilityTableCategoryHold == 1 || motilityTableCategoryHold == 4){
            if ((int)exportResultPath.find("§§") == -1){
                exportResultPath = exportResultPath.substr(0, exportResultPath.find(".tif"));
                exportResultPath = exportResultPath+motilityLineageHold+"§§"+to_string(markerMidValueHold);
            }
        }
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        exportFlag9 = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMotilityDisplay object:nil];
}

@end
