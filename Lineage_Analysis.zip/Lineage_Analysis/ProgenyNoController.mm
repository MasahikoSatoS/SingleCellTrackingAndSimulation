//
//  ProgenyNoController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-10.
//
//

#import "ProgenyNoController.h"

NSString *notificationToProgenyNoController = @"notificationExecuteProgenyNoController";

@implementation ProgenyNoController

-(id)init{
    self = [super init];
    
    if (self != nil){
        categoryTimeHold = 1000;
        categoryRangeHold = 10;
        categoryGroupHold = 5;
        categoryZeroInclude = 0;
        categoryHold = 0;
        sdCalculationHold = 0;
        normalizeHold = 100;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToProgenyNoController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    categoryProgenyWindowController = [[NSWindowController alloc] initWithWindowNibName:@"ProgenyNo"];
    [categoryProgenyWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable object:self];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable2 object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [categoryProgenyWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [categoryProgenyWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [categoryTimeDisplay setDelegate:self];
    [categoryRangeDisplay setDelegate:self];
    [categoryGroupDisplay setDelegate:self];
    [normalizeDisplay setDelegate:self];
    
    [categoryTimeDisplay setStringValue:@"1000"];
    [categoryRangeDisplay setStringValue:@"10"];
    [categoryGroupDisplay setStringValue:@"5"];
    [normalizeDisplay setStringValue:@"100"];
    [zeroIncludeDisplay setStringValue:@"No"];
    [sdModeDisplay setStringValue:@"No"];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == categoryTimeDisplay){
            if ([categoryTimeDisplay intValue] >= 1 && [categoryTimeDisplay intValue] < 100000){
                categoryTimeHold = [categoryTimeDisplay intValue];
            }
        }
        
        if ([aNotification object] == categoryRangeDisplay){
            if ([categoryRangeDisplay intValue] >= 1 && [categoryRangeDisplay intValue] < 100000){
                categoryRangeHold = [categoryRangeDisplay intValue];
                
                categoryRangeHoldCount = 0;
                
                if (categoryZeroInclude == 0){
                    arrayCategoryRangeHold [0] = 1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [1] = 0, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [2] = 0, categoryRangeHoldCount++;
                    
                    int rangeStart = 1;
                    int rangeEnd = categoryRangeHold;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= categoryGroupHold; counter1++){
                        arrayCategoryRangeHold [counter1*3] = counter1+1, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [counter1*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+categoryRangeHold;
                    }
                    
                    arrayCategoryRangeHold [categoryRangeHoldCount] = categoryGroupHold+2, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-categoryRangeHold+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
                }
                else{
                    
                    int rangeStart = 0;
                    int rangeEnd = categoryRangeHold-1;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= categoryGroupHold; counter1++){
                        arrayCategoryRangeHold [(counter1-1)*3] = counter1, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [(counter1-1)*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+categoryRangeHold;
                    }
                    
                    arrayCategoryRangeHold [categoryRangeHoldCount] = categoryGroupHold+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-categoryRangeHold+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable2 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == categoryGroupDisplay){
            if ([categoryGroupDisplay intValue] >= 3 && [categoryGroupDisplay intValue] < 100){
                categoryGroupHold = [categoryGroupDisplay intValue];
                
                categoryRangeHoldCount = 0;
                
                if (categoryZeroInclude == 0){
                    int rangeStart = 1;
                    int rangeEnd = categoryRangeHold;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= categoryGroupHold; counter1++){
                        arrayCategoryRangeHold [counter1*3] = counter1+1, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [counter1*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+categoryRangeHold;
                    }
                    
                    arrayCategoryRangeHold [categoryRangeHoldCount] = categoryGroupHold+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-categoryRangeHold*2+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
                }
                else{
                    
                    int rangeStart = 0;
                    int rangeEnd = categoryRangeHold-1;
                    int rangeIncrement = 0;
                    
                    for (int counter1 = 1; counter1 <= categoryGroupHold; counter1++){
                        arrayCategoryRangeHold [(counter1-1)*3] = counter1, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                        arrayCategoryRangeHold [(counter1-1)*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                        
                        rangeIncrement = rangeIncrement+categoryRangeHold;
                    }
                    
                    arrayCategoryRangeHold [categoryRangeHoldCount] = categoryGroupHold+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-categoryRangeHold+1, categoryRangeHoldCount++;
                    arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
                }
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable2 object:self];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if ([aNotification object] == normalizeDisplay){
            if ([normalizeDisplay intValue] >= 100 && [normalizeDisplay intValue] < 1000000){
                normalizeHold = [normalizeDisplay intValue];
            }
        }
    }
}

-(IBAction)setDD:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 1;
        
        [categoryDDDisplay setStringValue:@"Yes"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"BD"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setTD:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 2;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"Yes"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"TD"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setHD:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 3;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"Yes"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"HD"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setOF:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 4;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"Yes"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"OF"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setCD:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 5;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"Yes"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"CD"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setIP:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 6;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"Yes"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"IP"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setMI:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 7;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"Yes"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"MI"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setCF:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 8;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"Yes"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"CF"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setPG:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 9;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"Yes"];
        [categoryTODisplay setStringValue:@"No"];
        
        [categoryDisplay setStringValue:@"PG"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setTO:(id)sender{
    if (lineageDataEntryCount != 0){
        categoryHold = 10;
        
        [categoryDDDisplay setStringValue:@"No"];
        [categoryTDDisplay setStringValue:@"No"];
        [categoryHDDisplay setStringValue:@"No"];
        [categoryOFDisplay setStringValue:@"No"];
        [categoryCDDisplay setStringValue:@"No"];
        [categoryCFDisplay setStringValue:@"No"];
        [categoryIPDisplay setStringValue:@"No"];
        [categoryMIDisplay setStringValue:@"No"];
        [categoryPGDisplay setStringValue:@"No"];
        [categoryTODisplay setStringValue:@"Yes"];
        
        [categoryDisplay setStringValue:@"TO"];
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)zeroStatusHold:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryZeroInclude == 0){
            categoryZeroInclude = 1;
            
            categoryRangeHoldCount = 0;
            
            int rangeStart = 0;
            int rangeEnd = categoryRangeHold-1;
            int rangeIncrement = 0;
            
            for (int counter1 = 1; counter1 <= categoryGroupHold; counter1++){
                arrayCategoryRangeHold [(counter1-1)*3] = counter1, categoryRangeHoldCount++;
                arrayCategoryRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                arrayCategoryRangeHold [(counter1-1)*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                
                rangeIncrement = rangeIncrement+categoryRangeHold;
            }
            
            arrayCategoryRangeHold [categoryRangeHoldCount] = categoryGroupHold+2, categoryRangeHoldCount++;
            arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-categoryRangeHold+1, categoryRangeHoldCount++;
            arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
            
            [zeroIncludeDisplay setStringValue:@"Yes"];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable2 object:self];
        }
        else{
            
            categoryZeroInclude = 0;
            categoryRangeHoldCount = 0;
            
            arrayCategoryRangeHold [0] = 1, categoryRangeHoldCount++;
            arrayCategoryRangeHold [1] = 0, categoryRangeHoldCount++;
            arrayCategoryRangeHold [2] = 0, categoryRangeHoldCount++;
            
            int rangeStart = 1;
            int rangeEnd = categoryRangeHold;
            int rangeIncrement = 0;
            
            for (int counter1 = 1; counter1 <= categoryGroupHold; counter1++){
                arrayCategoryRangeHold [counter1*3] = counter1+1, categoryRangeHoldCount++;
                arrayCategoryRangeHold [counter1*3+1] = rangeStart+rangeIncrement, categoryRangeHoldCount++;
                arrayCategoryRangeHold [counter1*3+2] = rangeEnd+rangeIncrement, categoryRangeHoldCount++;
                
                rangeIncrement = rangeIncrement+categoryRangeHold;
            }
            
            arrayCategoryRangeHold [categoryRangeHoldCount] = categoryGroupHold+2, categoryRangeHoldCount++;
            arrayCategoryRangeHold [categoryRangeHoldCount] = rangeEnd+rangeIncrement-categoryRangeHold+1, categoryRangeHoldCount++;
            arrayCategoryRangeHold [categoryRangeHoldCount] = 100000000, categoryRangeHoldCount++;
            
            [zeroIncludeDisplay setStringValue:@"No"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable2 object:self];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)analysisStart:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold != 0){
            [self analysisSet];
            
            lineageComparisonStatusHold = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Category Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)analysisSet{
    categoryResultsHoldCount = 0;
    
    int lineageEntryNo = 0;
    unsigned long lineageEntrySize = 0;
    int totalEventCount = 0;
    int percentEventIntCount = 0;
    int lineageProcessCount = 0;
    double percentEventCount = 0;
    
    string percentString;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            lineageProcessCount++;
        }
    }
    
    if (sdCalculationHold == 0 || (sdCalculationHold == 1 && lineageProcessCount < 3)){
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                //    cout<<"  arrayTableMain "<<counterA<<endl;
                //}
                
                lineageEntrySize = arrayLineageDataEntryHold [counter2];
                
                lineageEntryNo = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                    }
                }
                
                int *categoryLineageList = new int [lineageEntryNo+10];
                
                for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) categoryLineageList [counter3] = -1;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    categoryLineageList [arrayLineageData [counter2][counter3*9+6]] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (categoryHold == 1){
                        if (arrayLineageData [counter2][counter3*9+3] == 32 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 2){
                        if (arrayLineageData [counter2][counter3*9+3] == 42 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 3){
                        if (arrayLineageData [counter2][counter3*9+3] == 52 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 4){
                        if (arrayLineageData [counter2][counter3*9+3] == 8 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 5){
                        if (arrayLineageData [counter2][counter3*9+3] == 7 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 6){
                        if (arrayLineageData [counter2][counter3*9+3] == 11 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 7){
                        if (arrayLineageData [counter2][counter3*9+3] == 6 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 8){
                        if ((arrayLineageData [counter2][counter3*9+3] == 91 || arrayLineageData [counter2][counter3*9+3] == 92) && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 9){
                        if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 10){
                        if ((arrayLineageData [counter2][counter3*9+3] == 1 || arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51) && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                }
                
                //for (int counterA = 1; counterA <= lineageEntryNo; counterA++){
                //    cout<<counterA<<" "<<categoryLineageList [counterA]<<" categoryLineageList"<<endl;
                //}
                
                arrayCategoryResultsHold [categoryResultsHoldCount] = arrayTableMain [counter2][2], categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = arrayTableMain [counter2][3], categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = arrayTableMain [counter2][4], categoryResultsHoldCount++;
                
                //for (int counterA = 0; counterA < categoryRangeHoldCount/3; counterA++){
                //    cout<<counterA<<" "<<arrayCategoryRangeHold [counterA*3]<<" "<<arrayCategoryRangeHold [counterA*3+1]<<" "<<arrayCategoryRangeHold [counterA*3+2]<<" rrayCategoryRangeHold"<<endl;
                //}
                
                int *categorySort = new int [categoryRangeHoldCount+10];
                
                totalEventCount = 0;
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount+10; counter3++) categorySort [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                    if (categoryLineageList [counter3] != -1){
                        for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                            if (categoryLineageList [counter3] != -1 && categoryLineageList [counter3] >= arrayCategoryRangeHold [counter4*3+1] && categoryLineageList [counter3] <= arrayCategoryRangeHold [counter4*3+2]){
                                categorySort [counter4]++;
                                totalEventCount++;
                                break;
                            }
                        }
                    }
                    else if (categoryLineageList [counter3] == 0){
                        categorySort [0]++;
                        totalEventCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < categoryRangeHoldCount/3; counterA++){
                //    cout<<counterA<<" "<<categorySort [counterA]<<" categorySort"<<endl;
                //}
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                    if (categoryResultsHoldCount+10 > categoryResultsHoldLimit){
                        string *arrayUpDate = new string [categoryResultsHoldCount+10];
                        
                        for (int counter4 = 0; counter4 < categoryResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayCategoryResultsHold [counter4];
                        
                        delete [] arrayCategoryResultsHold;
                        arrayCategoryResultsHold = new string [categoryResultsHoldLimit+350*3+500];
                        categoryResultsHoldLimit = categoryResultsHoldLimit+350*3+500;
                        
                        for (int counter4 = 0; counter4 < categoryResultsHoldCount; counter4++) arrayCategoryResultsHold [counter4] = arrayUpDate [counter4];
                        delete [] arrayUpDate;
                    }
                    
                    if (arrayCategoryRangeHold [counter3*3+1] == 0 && arrayCategoryRangeHold [counter3*3+2] == 0){
                        arrayCategoryResultsHold [categoryResultsHoldCount] = "0", categoryResultsHoldCount++;
                    }
                    else if (arrayCategoryRangeHold [counter3*3+2] == 100000000) arrayCategoryResultsHold [categoryResultsHoldCount] = ">="+to_string(arrayCategoryRangeHold [counter3*3+1]), categoryResultsHoldCount++;
                    else arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(arrayCategoryRangeHold [counter3*3+1])+"-"+to_string(arrayCategoryRangeHold [counter3*3+2]), categoryResultsHoldCount++;
                    
                    arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(categorySort [counter3]), categoryResultsHoldCount++;
                    
                    if (totalEventCount != 0)  percentEventCount = categorySort [counter3]/(double)totalEventCount;
                    else percentEventCount = 0;
                    
                    percentEventIntCount = (int)(percentEventCount*100000);
                    percentEventCount = percentEventIntCount/(double)1000;
                    
                    stringstream extension1;
                    extension1 << percentEventCount;
                    percentString = extension1.str();
                    
                    arrayCategoryResultsHold [categoryResultsHoldCount] = percentString, categoryResultsHoldCount++;
                }
                
                arrayCategoryResultsHold [categoryResultsHoldCount] = "Total", categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(totalEventCount), categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = "100", categoryResultsHoldCount++;
                
                arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                
                delete [] categorySort;
            }
        }
    }
    else{
        
        double **dataHold = new double *[lineageProcessCount+1];
        double **dataHold2 = new double *[lineageProcessCount+1];
        int *totalHold = new int [lineageProcessCount+1];
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            dataHold [counter2] = new double [categoryRangeHoldCount/3+10];
            dataHold2 [counter2] = new double [categoryRangeHoldCount/3+10];
            totalHold [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            for (int counter3 = 0; counter3 < categoryRangeHoldCount/3+10; counter3++){
                dataHold [counter2][counter3] = 0;
                dataHold2 [counter2][counter3] = 0;
            }
        }
        
        int lineageEntryCount = 0;
        
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                
                //for (int counterA = 0; counterA < 1; counterA++){
                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                //    cout<<"  arrayTableMain "<<counterA<<endl;
                //}
                
                lineageEntrySize = arrayLineageDataEntryHold [counter2];
                
                lineageEntryNo = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                    }
                }
                
                int *categoryLineageList = new int [lineageEntryNo+10];
                
                for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) categoryLineageList [counter3] = -1;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    categoryLineageList [arrayLineageData [counter2][counter3*9+6]] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (categoryHold == 1){
                        if (arrayLineageData [counter2][counter3*9+3] == 32 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 2){
                        if (arrayLineageData [counter2][counter3*9+3] == 42 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 3){
                        if (arrayLineageData [counter2][counter3*9+3] == 52 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 4){
                        if (arrayLineageData [counter2][counter3*9+3] == 8 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 5){
                        if (arrayLineageData [counter2][counter3*9+3] == 7 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 6){
                        if (arrayLineageData [counter2][counter3*9+3] == 11 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 7){
                        if (arrayLineageData [counter2][counter3*9+3] == 6 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 8){
                        if ((arrayLineageData [counter2][counter3*9+3] == 91 || arrayLineageData [counter2][counter3*9+3] == 92) && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 9){
                        if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    else if (categoryHold == 10){
                        if ((arrayLineageData [counter2][counter3*9+3] == 1 || arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51) && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                            categoryLineageList [arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                }
                
                totalEventCount = 0;
                
                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                    if (categoryLineageList [counter3] != -1){
                        for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                            if (categoryLineageList [counter3] != -1 && categoryLineageList [counter3] >= arrayCategoryRangeHold [counter4*3+1] && categoryLineageList [counter3] <= arrayCategoryRangeHold [counter4*3+2]){
                                dataHold [lineageEntryCount][counter4]++;
                                totalEventCount++;
                                break;
                            }
                        }
                    }
                    else if (categoryLineageList [counter3] == 0){
                        dataHold [counter2][0]++;
                        totalEventCount++;
                    }
                }
                
                totalHold [lineageEntryCount] = totalEventCount;
                
                delete [] categoryLineageList;
                
                lineageEntryCount++;
            }
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                if (totalHold [counter2] != 0){
                    dataHold2 [counter2][counter3] = (double)((dataHold [counter2][counter3]/(double)totalHold [counter2])*100);
                    dataHold [counter2][counter3] = (double)((dataHold [counter2][counter3]/(double)totalHold [counter2])*normalizeHold);
                }
            }
        }
        
        double *averageHold = new double [categoryRangeHoldCount/3+10];
        double *sdHold = new double [categoryRangeHoldCount/3+10];
        
        double *averagePercentHold = new double [categoryRangeHoldCount/3+10];
        double *sdPercentHold = new double [categoryRangeHoldCount/3+10];
        
        for (int counter2 = 0; counter2 < categoryRangeHoldCount/3+10; counter2++){
            averageHold [counter2] = 0;
            sdHold [counter2] = 0;
            averagePercentHold [counter2] = 0;
            sdPercentHold [counter2] = 0;
        }
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                averageHold [counter3] = averageHold [counter3]+dataHold [counter2][counter3];
                averagePercentHold [counter3] = averagePercentHold [counter3]+dataHold2 [counter2][counter3];
            }
        }
        
        //for (int counterA = 0; counterA < categoryRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averageHold [counterA]<<" "<<averagePercentHold [counterA]<<" averagePercentHold"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < categoryRangeHoldCount/3; counter2++){
            if (lineageProcessCount != 0){
                averageHold [counter2] = averageHold [counter2]/(double)lineageProcessCount;
                averagePercentHold [counter2] = averagePercentHold [counter2]/(double)lineageProcessCount;
            }
        }
        
        //for (int counterA = 0; counterA < categoryRangeHoldCount/3; counterA++){
        //    cout<<counterA<<" "<<averageHold [counterA]<<" "<<averagePercentHold [counterA]<<" averagePercentHold"<<endl;
        //}
        
        for (int counter2 = 0; counter2 < lineageProcessCount; counter2++){
            for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                sdHold [counter3] = sdHold [counter3]+(dataHold [counter2][counter3]-averageHold [counter3])*(dataHold [counter2][counter3]-averageHold [counter3]);
                sdPercentHold [counter3] = sdPercentHold [counter3]+(dataHold2 [counter2][counter3]-averagePercentHold [counter3])*(dataHold2 [counter2][counter3]-averagePercentHold [counter3]);
            }
        }
        
        for (int counter2 = 0; counter2 < categoryRangeHoldCount/3; counter2++){
            if (lineageProcessCount != 0){
                sdHold [counter2] = sqrt(sdHold [counter2]/(double)lineageProcessCount);
                sdPercentHold [counter2] = sqrt(sdPercentHold [counter2]/(double)lineageProcessCount);
            }
        }
        
        double avEventCount = 0;
        double sdEventCount = 0;
        int avEventIntCount = 0;
        int sdEventIntCount = 0;
        
        string avString;
        string sdString;
        
        for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
            if (arrayCategoryRangeHold [counter3*3+1] == 0 && arrayCategoryRangeHold [counter3*3+2] == 0){
                arrayCategoryResultsHold [categoryResultsHoldCount] = "0", categoryResultsHoldCount++;
            }
            else if (arrayCategoryRangeHold [counter3*3+2] == 100000000) arrayCategoryResultsHold [categoryResultsHoldCount] = ">="+to_string(arrayCategoryRangeHold [counter3*3+1]), categoryResultsHoldCount++;
            else arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(arrayCategoryRangeHold [counter3*3+1])+"-"+to_string(arrayCategoryRangeHold [counter3*3+2]), categoryResultsHoldCount++;
            
            if (averageHold [counter3] != 0) avEventCount = averageHold [counter3];
            else avEventCount = 0;
            
            avEventIntCount = (int)(avEventCount*1000);
            avEventCount = avEventIntCount/(double)1000;
            
            stringstream extension1;
            extension1 << avEventCount;
            avString = extension1.str();
            
            if (sdHold [counter3] != 0) sdEventCount = sdHold [counter3];
            else sdEventCount = 0;
            
            sdEventIntCount = (int)(sdEventCount*1000);
            sdEventCount = sdEventIntCount/(double)1000;
            
            stringstream extension2;
            extension2 << sdEventCount;
            sdString = extension2.str();
            
            arrayCategoryResultsHold [categoryResultsHoldCount] = avString+" ± "+sdString, categoryResultsHoldCount++;
            
            if (averagePercentHold [counter3] != 0) avEventCount = averagePercentHold [counter3];
            else avEventCount = 0;
            
            avEventIntCount = (int)(avEventCount*1000);
            avEventCount = avEventIntCount/(double)1000;
            
            stringstream extension3;
            extension3 << avEventCount;
            avString = extension3.str();
            
            if (sdPercentHold [counter3] != 0) sdEventCount = sdPercentHold [counter3];
            else sdEventCount = 0;
            
            sdEventIntCount = (int)(sdEventCount*1000);
            sdEventCount = sdEventIntCount/(double)1000;
            
            stringstream extension4;
            extension4 << sdEventCount;
            sdString = extension4.str();
            
            arrayCategoryResultsHold [categoryResultsHoldCount] = avString+" ± "+sdString, categoryResultsHoldCount++;
        }
        
        arrayCategoryResultsHold [categoryResultsHoldCount] = "Total", categoryResultsHoldCount++;
        arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(normalizeHold), categoryResultsHoldCount++;
        arrayCategoryResultsHold [categoryResultsHoldCount] = "100", categoryResultsHoldCount++;
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            delete [] dataHold [counter2];
        }
        
        delete [] dataHold;
        
        delete [] totalHold;
        delete [] averageHold;
        delete [] sdHold;
        
        for (int counter2 = 0; counter2 < lineageProcessCount+1; counter2++){
            delete [] dataHold2 [counter2];
        }
        
        delete [] dataHold2;
        
        delete [] averagePercentHold;
        delete [] sdPercentHold;
    }
}

-(IBAction)createExcelFile:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold != 0){
            if (categoryResultsHoldCount != 0 && lineageComparisonStatusHold == 0){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Categorization";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Categorization") != -1){
                            extractString = entry.substr(entry.find("CA")+2, entry.find(".txt")-entry.find("CA")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string path = resultSavePath2+"/Categorization-CA"+to_string(maxEntryNo)+".txt";
                
                [self analysisSet];
                
                string categoryString = "";
                
                if (categoryHold == 1) categoryString = "BD";
                else if (categoryHold == 2) categoryString = "TD";
                else if (categoryHold == 3) categoryString = "HD";
                else if (categoryHold == 4) categoryString = "OF";
                else if (categoryHold == 5) categoryString = "CD";
                else if (categoryHold == 6) categoryString = "IP";
                else if (categoryHold == 7) categoryString = "MI";
                else if (categoryHold == 8) categoryString = "CF";
                else if (categoryHold == 9) categoryString = "PG";
                else if (categoryHold == 10) categoryString = "TO";
                
                ofstream oin;
                oin.open(path.c_str(), ios::out | ios::binary);
                
                int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
                
                ascIIconversion = [[ASCIIconversion alloc] init];
                
                if (sdCalculationHold == 0){
                    ascIIstring = categoryString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Cut Off Time";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(categoryTimeHold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter1 = 0; counter1 < categoryResultsHoldCount/3; counter1++){
                        ascIIstring = arrayCategoryResultsHold [counter1*3];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayCategoryResultsHold [counter1*3+1];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayCategoryResultsHold [counter1*3+2];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                    }
                }
                else{
                    
                    ascIIstring = categoryString;
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Cut Off Time";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(categoryTimeHold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    oin.put(9);
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    oin.put(9);
                    
                    ascIIstring = "Total AV";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Total SD";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Percent";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Percent SD";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter1 = 0; counter1 < categoryResultsHoldCount/3; counter1++){
                        ascIIstring = arrayCategoryResultsHold [counter1*3];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayCategoryResultsHold [counter1*3+1].substr(0, arrayCategoryResultsHold [counter1*3+1].find("±")-1);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayCategoryResultsHold [counter1*3+1].substr(arrayCategoryResultsHold [counter1*3+1].find("±")+1);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayCategoryResultsHold [counter1*3+2].substr(0, arrayCategoryResultsHold [counter1*3+2].find("±")-1);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayCategoryResultsHold [counter1*3+2].substr(arrayCategoryResultsHold [counter1*3+2].find("±")+1);
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                    }
                }
                
                delete [] arrayAscIIintData;
                
                oin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Analysis Performed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Category Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFile2:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold != 0){
            if (categoryResultsHoldCount != 0 && lineageComparisonStatusHold == 0){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Categorization";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Categorization") != -1){
                            extractString = entry.substr(entry.find("CA")+2, entry.find(".txt")-entry.find("CA")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string path = resultSavePath2+"/CategorizationList-CA"+to_string(maxEntryNo)+".txt";
                
                int maxLingNoEx = 0;
                int lingEntryEx = 0;
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1){
                        if (arrayTableDetail [counter2][1] > maxLingNoEx) maxLingNoEx = arrayTableDetail [counter2][1];
                        
                        lingEntryEx++;
                    }
                }
                
                int *cellNumberHold = new int [maxLingNoEx+10];
                
                unsigned long lineageEntrySizeEx = 0;
                int lineageEntryNo = 0;
                int headingEntry = 0;
                
                ofstream oin;
                oin.open(path.c_str(), ios::out | ios::binary);
                
                int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
                
                ascIIconversion = [[ASCIIconversion alloc] init];
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1){
                        lineageEntrySizeEx = arrayLineageDataEntryHold [counter2];
                        
                        for (int counter3 = 0; counter3 < maxLingNoEx+10; counter3++){
                            cellNumberHold [counter3] = -1;
                        }
                        
                        lineageEntryNo = arrayTableDetail [counter2][1];
                        
                        for (unsigned long counter3 = 0; counter3 < lineageEntrySizeEx/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                                if (cellNumberHold [arrayLineageData [counter2][counter3*9+6]] == -1){
                                    cellNumberHold [arrayLineageData [counter2][counter3*9+6]] = 1;
                                }
                                else cellNumberHold [arrayLineageData [counter2][counter3*9+6]]++;
                            }
                        }
                        
                        if (headingEntry == 0){
                            ascIIstring = "ID-Treat";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                            
                            oin.put(9);
                            
                            for (int counter3 = 1; counter3 < maxLingNoEx; counter3++){
                                ascIIstring = to_string(counter3);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            headingEntry = 1;
                        }
                        
                        ascIIstring = arrayTableMain [counter2][3]+" "+arrayTableMain [counter2][4];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter3 = 1; counter3 < maxLingNoEx; counter3++){
                            ascIIstring = " ";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter4 = 1; counter4 <= maxLingNoEx; counter4++){
                            if (lineageEntryNo >= counter4){
                                if (cellNumberHold [counter4] != -1){
                                    ascIIstring = to_string(cellNumberHold [counter4]);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                }
                                else{
                                    
                                    ascIIstring = "0";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                }
                            }
                            else{
                                
                                ascIIstring = " ";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                            }
                            
                            oin.put(9);
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter4 = 0; counter4 < maxLingNoEx; counter4++){
                            ascIIstring = " ";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                            
                            oin.put(9);
                        }
                        
                        oin.put(13);
                        oin.put(10);
                    }
                }
                
                oin.close();
                
                delete [] cellNumberHold;
                delete [] arrayAscIIintData;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Analysis Performed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Category Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)sdCalculationHoldSet:(id)sender{
    if (lineageDataEntryCount != 0){
        if (sdCalculationHold == 0){
            sdCalculationHold = 1;
            [sdModeDisplay setStringValue:@"Yes"];
        }
        else{
            
            sdCalculationHold = 0;
            [sdModeDisplay setStringValue:@"No"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)categorySave:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold != 0){
            if (categoryResultsHoldCount != 0 && lineageComparisonStatusHold == 0){
                unsigned long lineageExtractTempCount = 0;
                unsigned long lineageExtractTempLimit = 0;
                int ifExtractTempCount = 0;
                int ifExtractTempLimit = 0;
                int findFlag = 0;
                int noOfLing = 0;
                int noOfCellStart = 0;
                int noOfCellEnd = 0;
                int noOfTotalCells = 0;
                int noOfDD = 0;
                int noOfTD = 0;
                int noOfHD = 0;
                int noOfMI = 0;
                int noOfFU = 0;
                int noOfCD = 0;
                int maxLineageNo = 0;
                int areaExtractTempCount = 0;
                int areaExtractTempLimit = 0;
                int lineageLinkListLengthTemp = 0;
                int lingNoTemp = 0;
                unsigned long lineageEntrySize = 0;
                int lineageEntryNo = 0;
                int maxCategoryLingNo = 0;
                int categorySortCount = 0;
                int matchFind = 0;
                int freeSpotFind = 0;
                int previousLengthHold = 0;
                int readingCount = 0;
                int terminationFlag = 0;
                int lengthExpansionFlag = 0;
                int entryNo = 0;
                int expansionNo = 0;
                int lineageLinkListTempLimit = 0;
                double foldTemp = 0;
                
                string savePath;
                string treatNameExtract;
                string imageDisplayPath;
                string entry;
                
                ofstream oin;
                
                for (int counter1 = 0; counter1 < lineageDataEntryCount; counter1++){
                    if (arraySelectedLing [counter1] == 1){
                        if (lineageDataEntryCount-1 < 101){
                            
                            //for (int counterA = 0; counterA < 1; counterA++){
                            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                            //    cout<<"  arrayTableMain "<<counterA<<endl;
                            //}
                            
                            lineageEntrySize = arrayLineageDataEntryHold [counter1];
                            
                            lineageEntryNo = 0;
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                if (arrayLineageData [counter1][counter3*9+6] > lineageEntryNo){
                                    lineageEntryNo = arrayLineageData [counter1][counter3*9+6];
                                }
                            }
                            
                            int *categoryLineageList = new int [lineageEntryNo+10];
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) categoryLineageList [counter3] = -1;
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                categoryLineageList [arrayLineageData [counter1][counter3*9+6]] = 0;
                            }
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                if (categoryHold == 1){
                                    if (arrayLineageData [counter1][counter3*9+3] == 32 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 2){
                                    if (arrayLineageData [counter1][counter3*9+3] == 42 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 3){
                                    if (arrayLineageData [counter1][counter3*9+3] == 52 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 4){
                                    if (arrayLineageData [counter1][counter3*9+3] == 8 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 5){
                                    if (arrayLineageData [counter1][counter3*9+3] == 7 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 6){
                                    if (arrayLineageData [counter1][counter3*9+3] == 11 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 7){
                                    if (arrayLineageData [counter1][counter3*9+3] == 6 && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 8){
                                    if ((arrayLineageData [counter1][counter3*9+3] == 91 || arrayLineageData [counter1][counter3*9+3] == 92) && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 9){
                                    if (arrayLineageData [counter1][counter3*9+2] == categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                                else if (categoryHold == 10){
                                    if ((arrayLineageData [counter1][counter3*9+3] == 1 || arrayLineageData [counter1][counter3*9+3] == 31 || arrayLineageData [counter1][counter3*9+3] == 41 || arrayLineageData [counter1][counter3*9+3] == 51) && arrayLineageData [counter1][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter1][counter3*9+6]]++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 1; counterA <= lineageEntryNo; counterA++){
                            //    cout<<counterA<<" "<<categoryLineageList [counterA]<<" categoryLineageList"<<endl;
                            //}
                            
                            for (int counter2 = 0; counter2 < categoryRangeHoldCount/3; counter2++){
                                DIR *dir;
                                struct dirent *dent;
                                maxCategoryLingNo = 0;
                                
                                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [counter1][2]+"_AnalysisResults"+"/"+arrayTableMain [counter1][3]+"_IDResults";
                                
                                dir = opendir(imageDisplayPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            if ((int)entry.find("CA") != -1){
                                                if (atoi(entry.substr(2, entry.find("-")-2).c_str()) > maxCategoryLingNo) maxCategoryLingNo = atoi(entry.substr(2, entry.find("-")-2).c_str());
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                }
                                
                                maxCategoryLingNo++;
                                
                                treatNameExtract = arrayTableMain [counter1][4].substr(arrayTableMain [counter1][4].find("-")+1, arrayTableMain [counter1][4].find("_Results")-arrayTableMain [counter1][4].find("-")-1);
                                
                                imageDisplayPath = analysisDataFolderPath+"/"+arrayTableMain [counter1][2]+"_AnalysisResults"+"/"+arrayTableMain [counter1][3]+"_IDResults/"+"CA"+to_string(maxCategoryLingNo)+"-"+treatNameExtract+"_Results";
                                
                                mkdir(imageDisplayPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                int *categorySort = new int [lineageEntryNo+10];
                                categorySortCount = 0;
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++) categorySort [counter3] = 0;
                                
                                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                                    if (categoryLineageList [counter3] != -1){
                                        if (categoryLineageList [counter3] != -1 && categoryLineageList [counter3] >= arrayCategoryRangeHold [counter2*3+1] && categoryLineageList [counter3] <= arrayCategoryRangeHold [counter2*3+2]){
                                            categorySort [categorySortCount] = counter3, categorySortCount++;
                                        }
                                    }
                                    else if (counter2 == 0 && categoryLineageList [counter3] == 0){
                                        categorySort [categorySortCount] = counter3, categorySortCount++;
                                    }
                                }
                                
                                int *lineageExtractTemp = new int [arrayLineageDataEntryHold [counter1]+500];
                                lineageExtractTempCount = 0;
                                lineageExtractTempLimit = arrayLineageDataEntryHold [counter1]+500;
                                
                                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter1]/9; counter3++){
                                    findFlag = 0;
                                    
                                    for (int counter4 = 0; counter4 < categorySortCount; counter4++){
                                        if (categorySort [counter4] != 0 && arrayLineageData [counter1][counter3*9+6] == categorySort [counter4]){
                                            findFlag = 1;
                                        }
                                    }
                                    
                                    if (findFlag == 1){
                                        if (lineageExtractTempCount+10 > lineageExtractTempLimit){
                                            int *arrayUpDate = new int [lineageExtractTempCount+10];
                                            
                                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) arrayUpDate [counter4] = lineageExtractTemp [counter4];
                                            
                                            delete [] lineageExtractTemp;
                                            lineageExtractTempLimit = lineageExtractTempCount+5000;
                                            lineageExtractTemp = new int [lineageExtractTempLimit];
                                            
                                            for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount; counter4++) lineageExtractTemp [counter4] = arrayUpDate [counter4];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9], lineageExtractTempCount++;
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+1], lineageExtractTempCount++;
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+2], lineageExtractTempCount++;
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+3], lineageExtractTempCount++;
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+4], lineageExtractTempCount++;
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+5], lineageExtractTempCount++;
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+6], lineageExtractTempCount++;
                                        
                                        if (arrayLineageData [counter1][counter3*9+7] != 0 && arrayLineageData [counter1][counter3*9+7] != arrayLineageData [counter1][counter3*9+6]){
                                            lineageExtractTemp [lineageExtractTempCount] = 0, lineageExtractTempCount++;
                                        }
                                        else lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+7], lineageExtractTempCount++;
                                        
                                        lineageExtractTemp [lineageExtractTempCount] = arrayLineageData [counter1][counter3*9+8], lineageExtractTempCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageExtractTempCount/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<lineageExtractTemp [counterA*9+counterB];
                                //    cout<<" lineageExtractTemp"<<counterA<<endl;
                                //}
                                
                                //----IF data: Array set----
                                int *ifExtractTemp = new int [arrayIFDataEntryHold [counter1]+500];
                                ifExtractTempCount = 0;
                                ifExtractTempLimit = arrayIFDataEntryHold [counter1]+500;
                                
                                for (int counter3 = 0; counter3 < arrayIFDataEntryHold [counter1]/22; counter3++){
                                    findFlag = 0;
                                    
                                    for (int counter4 = 0; counter4 < categorySortCount; counter4++){
                                        if (arrayIFData [counter1][counter3*22+1] == categorySort [counter4]){
                                            findFlag = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (findFlag == 1){
                                        if (ifExtractTempCount+50 > ifExtractTempLimit){
                                            int *arrayUpDate = new int [ifExtractTempCount+10];
                                            
                                            for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) arrayUpDate [counter4] = ifExtractTemp [counter4];
                                            
                                            delete [] ifExtractTemp;
                                            ifExtractTempLimit = ifExtractTempCount+5000;
                                            ifExtractTemp = new int [ifExtractTempLimit];
                                            
                                            for (int counter4 = 0; counter4 < ifExtractTempCount; counter4++) ifExtractTemp [counter4] = arrayUpDate [counter4];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+1], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+2], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+3], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+4], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+5], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+6], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+7], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+8], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+9], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+10], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+11], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+12], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+13], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+14], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+15], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+16], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+17], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+18], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+19], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+20], ifExtractTempCount++;
                                        ifExtractTemp [ifExtractTempCount] = arrayIFData [counter1][counter3*22+21], ifExtractTempCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < ifExtractTempCount/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<ifExtractTemp [counterA*13+counterB];
                                //    cout<<" ifExtractTemp "<<counterA<<endl;
                                //}
                                
                                //----Detail table data: Array set----
                                int *arrayTableDetailTemp = new int [20];
                                
                                noOfLing = 0;
                                noOfCellStart = 0;
                                noOfCellEnd = 0;
                                noOfTotalCells = 0;
                                noOfDD = 0;
                                noOfTD = 0;
                                noOfHD = 0;
                                noOfMI = 0;
                                noOfFU = 0;
                                noOfCD = 0;
                                
                                maxLineageNo = 0;
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                                    if (lineageExtractTemp [counter3*9+2] == arrayTableDetail[counter1][2] && (lineageExtractTemp [counter3*9+5] == 0 || lineageExtractTemp [counter3*9+5] == -1)){
                                        noOfLing++;
                                    }
                                    
                                    if (maxLineageNo < lineageExtractTemp [counter3*9+6]) maxLineageNo = lineageExtractTemp [counter3*9+6]; //==
                                    
                                    if (lineageExtractTemp [counter3*9+2] == arrayTableDetail[counter1][2] && lineageExtractTemp [counter3*9+5] == 0){
                                        noOfCellStart++;
                                    }
                                    
                                    if ((lineageExtractTemp [counter3*9+3] == 1 || lineageExtractTemp [counter3*9+3] == 31 || lineageExtractTemp [counter3*9+3] == 41 || lineageExtractTemp [counter3*9+3] == 51)){
                                        noOfTotalCells++;
                                    }
                                    
                                    if (lineageExtractTemp [counter3*9+2] == arrayTableDetail[counter1][3]) noOfCellEnd++;
                                    if (lineageExtractTemp [counter3*9+3] == 32) noOfDD++;
                                    if (lineageExtractTemp [counter3*9+3] == 42) noOfTD++;
                                    if (lineageExtractTemp [counter3*9+3] == 52) noOfHD++;
                                    if (lineageExtractTemp [counter3*9+3] == 6) noOfMI++;
                                    if (lineageExtractTemp [counter3*9+3] == 91) noOfFU++;
                                    if (lineageExtractTemp [counter3*9+3] == 7) noOfCD++;
                                }
                                
                                arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                                arrayTableDetailTemp [1] = noOfLing;
                                arrayTableDetailTemp [2] = arrayTableDetail[counter1][2];
                                arrayTableDetailTemp [3] = arrayTableDetail[counter1][3];
                                arrayTableDetailTemp [4] = arrayTableDetail[counter1][4];
                                arrayTableDetailTemp [5] = arrayTableDetail[counter1][5];
                                arrayTableDetailTemp [6] = noOfCellStart;
                                arrayTableDetailTemp [7] = noOfCellEnd;
                                
                                if (noOfCellStart != 0){
                                    foldTemp = noOfCellEnd/(double)noOfCellStart;
                                    foldTemp = foldTemp*10+1;
                                }
                                else foldTemp = 1;
                                
                                arrayTableDetailTemp [8] = (int)foldTemp;
                                arrayTableDetailTemp [9] = noOfTotalCells;
                                arrayTableDetailTemp [10] = noOfDD;
                                arrayTableDetailTemp [11] = noOfTD;
                                arrayTableDetailTemp [12] = noOfHD;
                                arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                                arrayTableDetailTemp [14] = noOfMI;
                                arrayTableDetailTemp [15] = noOfFU;
                                arrayTableDetailTemp [16] = noOfCD;
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                                //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                                //}
                                
                                //----AreaData: Array set----
                                int *areaExtractTemp = new int [arrayAreaDataHold [counter1]+500];
                                areaExtractTempCount = 0;
                                areaExtractTempLimit = arrayAreaDataHold [counter1]+500;
                                
                                for (int counter3 = 0; counter3 < arrayAreaDataHold [counter1]/5; counter3++){
                                    findFlag = 0;
                                    
                                    for (int counter4 = 0; counter4 < categorySortCount; counter4++){
                                        if (arrayAreaData [counter1][counter3*5] == categorySort [counter4]){
                                            findFlag = 1;
                                            break;
                                        }
                                    }
                                    
                                    if (findFlag == 1){
                                        if (areaExtractTempCount+10 > areaExtractTempLimit){
                                            int *arrayUpDate = new int [areaExtractTempCount+10];
                                            
                                            for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) arrayUpDate [counter4] = areaExtractTemp [counter4];
                                            
                                            delete [] areaExtractTemp;
                                            areaExtractTempLimit = areaExtractTempCount+5000;
                                            areaExtractTemp = new int [areaExtractTempLimit];
                                            
                                            for (int counter4 = 0; counter4 < areaExtractTempCount; counter4++) areaExtractTemp [counter4] = arrayUpDate [counter4];
                                            delete [] arrayUpDate;
                                        }
                                        
                                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter3*5], areaExtractTempCount++;
                                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter3*5+1], areaExtractTempCount++;
                                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter3*5+2], areaExtractTempCount++;
                                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter3*5+3], areaExtractTempCount++;
                                        areaExtractTemp [areaExtractTempCount] = arrayAreaData [counter1][counter3*5+4], areaExtractTempCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < areaExtractTempCount/5; counterA++){
                                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<areaExtractTemp [counterA*5+counterB];
                                //    cout<<" areaExtractTemp "<<counterA<<endl;
                                //}
                                
                                //----Link Data----
                                lineageLinkListLengthTemp = 4;
                                int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                
                                for (int counter4 = 0; counter4 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter4++) arrayLineageLinkTemp [counter4] = 0;
                                
                                for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount/9; counter4++){
                                    if (lineageExtractTemp [counter4*9+3] == 31 || lineageExtractTemp [counter4*9+3] == 41 || lineageExtractTemp [counter4*9+3] == 51 || lineageExtractTemp [counter4*9+3] == 1){
                                        lingNoTemp = lineageExtractTemp [counter4*9+6];
                                        arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                    }
                                }
                                
                                for (unsigned long counter4 = 0; counter4 < lineageExtractTempCount/9; counter4++){
                                    lingNoTemp = lineageExtractTemp [counter4*9+6];
                                    
                                    if (lineageExtractTemp [counter4*9+7] != 0 && lineageExtractTemp [counter4*9+7] != lingNoTemp){
                                        matchFind = 0;
                                        freeSpotFind = 0;
                                        
                                        for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter5] == lineageExtractTemp [counter4*9+7]){
                                                matchFind = 1;
                                            }
                                            
                                            if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter5] == 0 && freeSpotFind == 0){
                                                freeSpotFind = counter5;
                                            }
                                        }
                                        
                                        if (matchFind == 0){
                                            if (freeSpotFind == 0){
                                                previousLengthHold = lineageLinkListLengthTemp;
                                                int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                
                                                for (int counter5 = 0; counter5 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter5++) arrayUpDate [counter5] = arrayLineageLinkTemp [counter5];
                                                
                                                delete [] arrayLineageLinkTemp;
                                                lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                                arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                                lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                                
                                                readingCount = 0;
                                                
                                                for (int counter5 = 0; counter5 <= maxLineageNo; counter5++){
                                                    for (int counter6 = 0; counter6 < previousLengthHold; counter6++){
                                                        arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+counter6] = arrayUpDate [readingCount], readingCount++;
                                                    }
                                                    
                                                    arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                                    arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                                }
                                                
                                                delete [] arrayUpDate;
                                                
                                                freeSpotFind = previousLengthHold;
                                            }
                                            
                                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                            arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = lineageExtractTemp [counter4*9+7];
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                                //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                                //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                                //}
                                
                                for (int counter4 = 1; counter4 <= maxLineageNo; counter4++){
                                    if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+1] != 0){
                                        freeSpotFind = -1;
                                        
                                        for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                            if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0){
                                                freeSpotFind = counter5;
                                                break;
                                            }
                                        }
                                        
                                        if (freeSpotFind == -1) freeSpotFind = 4;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0){
                                                    lengthExpansionFlag = 0;
                                                    
                                                    for (int counter6 = 1; counter6 <= maxLineageNo; counter6++){
                                                        if (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5]){
                                                            entryNo = 0;
                                                            
                                                            for (int counter7 = 1; counter7 < lineageLinkListLengthTemp; counter7++){
                                                                findFlag = 0;
                                                                
                                                                for (int counter8 = 1; counter8 < lineageLinkListLengthTemp; counter8++){
                                                                    if (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] != 0 && (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] == arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter8] || arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] == counter4)){
                                                                        findFlag = 1;
                                                                    }
                                                                    else if (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] == 0) findFlag = 1;
                                                                }
                                                                
                                                                if (findFlag == 0) entryNo++;
                                                            }
                                                            
                                                            if (entryNo != 0){
                                                                if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                                    previousLengthHold = lineageLinkListLengthTemp;
                                                                    int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                                    
                                                                    for (int counter7 = 0; counter7 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter7++) arrayUpDate [counter7] = arrayLineageLinkTemp [counter7];
                                                                    
                                                                    if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                                    else expansionNo = freeSpotFind+entryNo;
                                                                    
                                                                    delete [] arrayLineageLinkTemp;
                                                                    lineageLinkListLengthTemp = expansionNo+2;
                                                                    arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                                    lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                                    
                                                                    expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                                    
                                                                    readingCount = 0;
                                                                    
                                                                    for (int counter7 = 0; counter7 <= maxLineageNo; counter7++){
                                                                        for (int counter8 = 0; counter8 < previousLengthHold; counter8++){
                                                                            arrayLineageLinkTemp [counter7*lineageLinkListLengthTemp+counter8] = arrayUpDate [readingCount], readingCount++;
                                                                        }
                                                                        
                                                                        for (int counter8 = 0; counter8 < expansionNo; counter8++){
                                                                            arrayLineageLinkTemp [counter7*lineageLinkListLengthTemp+previousLengthHold+counter8] = 0;
                                                                        }
                                                                    }
                                                                    
                                                                    delete [] arrayUpDate;
                                                                    
                                                                    lengthExpansionFlag = 1;
                                                                    
                                                                    break;
                                                                }
                                                                else{
                                                                    
                                                                    for (int counter7 = 1; counter7 < lineageLinkListLengthTemp; counter7++){
                                                                        findFlag = 0;
                                                                        
                                                                        for (int counter8 = 1; counter8 < lineageLinkListLengthTemp; counter8++){
                                                                            if (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] != 0 && (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] == arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter8] || arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] == counter4)){
                                                                                findFlag = 1;
                                                                            }
                                                                            else if (arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7] == 0) findFlag = 1;
                                                                        }
                                                                        
                                                                        if (findFlag != 1){
                                                                            arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp+counter7];
                                                                            
                                                                            freeSpotFind++;
                                                                        }
                                                                    }
                                                                    
                                                                    arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp] = -1;
                                                                    break;
                                                                }
                                                            }
                                                            else arrayLineageLinkTemp [counter6*lineageLinkListLengthTemp] = -1;
                                                        }
                                                    }
                                                    
                                                    if (lengthExpansionFlag == 1){
                                                        break;
                                                    }
                                                }
                                                
                                                if (counter5 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                                            }
                                            
                                        } while (terminationFlag == 1);
                                    }
                                }
                                
                                //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                                //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                                //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                                //}
                                
                                int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                                int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                                int numberOfFusionEntry = 0;
                                int smallestEntry2 = 0;
                                int remainingFlag = 0;
                                int smallestEntry = 0;
                                int smallestEntryPosition = 0;
                                
                                for (int counter4 = 1; counter4 <= maxLineageNo; counter4++){
                                    if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+1] != 0){
                                        numberOfFusionEntry = 0;
                                        
                                        for (int counter5 = 0; counter5 < lineageLinkListLengthTemp; counter5++){
                                            if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0){
                                                numberOfFusionEntry++;
                                            }
                                        }
                                        
                                        if (numberOfFusionEntry > 1){
                                            for (int counter5 = 0; counter5 < lineageLinkListLengthTemp; counter5++){
                                                if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0){
                                                    numberOfEntryList [counter5] = arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5];
                                                }
                                                else numberOfEntryList [counter5] = 0;
                                                
                                                numberOfEntryList2 [counter5] = 0;
                                            }
                                            
                                            smallestEntry2 = 1;
                                            
                                            do{
                                                
                                                terminationFlag = 1;
                                                remainingFlag = 0;
                                                smallestEntry = 100000;
                                                smallestEntryPosition = 0;
                                                
                                                for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                    if (numberOfEntryList [counter5] != 0 && numberOfEntryList [counter5] < smallestEntry){
                                                        smallestEntry = numberOfEntryList [counter5];
                                                        smallestEntryPosition = counter5;
                                                        remainingFlag = 1;
                                                    }
                                                }
                                                
                                                if (remainingFlag == 0) terminationFlag = 0;
                                                else{
                                                    
                                                    numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                                    numberOfEntryList [smallestEntryPosition] = 0;
                                                }
                                                
                                            } while (terminationFlag == 1);
                                            
                                            for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] = numberOfEntryList2 [counter5];
                                            }
                                        }
                                    }
                                }
                                
                                delete [] numberOfEntryList;
                                delete [] numberOfEntryList2;
                                
                                //----Lineage Data type: Array Set----
                                for (int counter3 = 0; counter3 < 7; counter3++){
                                    arrayLineageDataType [lineageDataEntryCount][counter3] = arrayLineageDataType [counter1][counter3];
                                }
                                
                                arrayLineageDataType [lineageDataEntryCount][0] = to_string(lineageDataEntryCount+1);
                                arrayLineageDataType [lineageDataEntryCount][1] = "CA"+to_string(maxCategoryLingNo);
                                
                                //for (int counterA = 0; counterA <= lineageDataEntryCount; counterA++){
                                //    cout<<" "<<arrayLineageDataType [counterA][0]<<" "<<arrayLineageDataType [counterA][1]<<" "<<arrayLineageDataType [counterA][2]<<" "<<arrayLineageDataType [counterA][3]<<" "<<arrayLineageDataType [counterA][4]<<" "<<arrayLineageDataType [counterA][5]<<" "<<arrayLineageDataType [counterA][6]<<" "<<arrayLineageDataType [counterA][7]<<" LingType" <<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                //}
                                
                                //----LineageFluorescentDataType: Array Set----
                                int fluorescentDataEntryCount = lineageFluorescentDataTypeEntryCount;
                                
                                for (int counter3 = 0; counter3 < fluorescentDataEntryCount; counter3++){
                                    if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                    
                                    if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == counter1+1){
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount+1);
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = arrayLineageFluorescentDataType [counter3][1];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayLineageFluorescentDataType [counter3][2];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = arrayLineageFluorescentDataType [counter3][3];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = arrayLineageFluorescentDataType [counter3][4];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = arrayLineageFluorescentDataType [counter3][5];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = arrayLineageFluorescentDataType [counter3][6];
                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = arrayLineageFluorescentDataType [counter3][7];
                                        
                                        lineageFluorescentDataTypeEntryCount++;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                //}
                                
                                //----Data save----
                                savePath = imageDisplayPath+"/"+"*LineageDataAddition.dat";
                                
                                oin.open(savePath.c_str(), ios::out);
                                oin<<to_string(lineageDataEntryCount+1)<<endl;
                                oin<<"CA"+to_string(maxCategoryLingNo)<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][2]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][3]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][4]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][5]<<endl;
                                oin<<arrayLineageDataType [lineageDataEntryCount][6]<<endl;
                                
                                for (int counter3 = 0; counter3 < lineageFluorescentDataTypeEntryCount; counter3++){
                                    if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == lineageDataEntryCount+1){
                                        oin<<arrayLineageFluorescentDataType [counter3][0]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][1]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][2]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][3]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][4]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][5]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][6]<<endl;
                                        oin<<arrayLineageFluorescentDataType [counter3][7]<<endl;
                                    }
                                }
                                
                                oin.close();
                                
                                delete [] arrayLineageData [lineageDataEntryCount];
                                delete [] arrayIFData [lineageDataEntryCount];
                                delete [] arrayIFTimeLineData [lineageDataEntryCount];
                                delete [] arrayTableMain [lineageDataEntryCount];
                                delete [] arrayIfTimeStatus [lineageDataEntryCount];
                                delete [] arrayAreaData [lineageDataEntryCount];
                                delete [] arrayLineageLink [lineageDataEntryCount];
                                
                                arrayLineageData [lineageDataEntryCount] = new int [lineageExtractTempCount+10];
                                arrayIFData [lineageDataEntryCount] = new int [ifExtractTempCount+10];
                                arrayIFTimeLineData [lineageDataEntryCount] = new int [arrayIFTimeLineDataEntryHold [counter1]+10];
                                arrayTableMain [lineageDataEntryCount] = new string [arrayTableMainHold [counter1]+10];
                                arrayIfTimeStatus [lineageDataEntryCount] = new int [arrayIfTimeStatusHold [counter1]+10];
                                arrayAreaData [lineageDataEntryCount] = new int [areaExtractTempCount+10];
                                arrayLineageLink [lineageDataEntryCount] = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                                
                                lineageDataEntryCount++;
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount; counter3++) arrayLineageData [lineageDataEntryCount-1][counter3] = lineageExtractTemp [counter3];
                                
                                arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)lineageExtractTempCount;
                                
                                //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageData [lineageDataEntryCount-1][counterA*9+counterB];
                                //    cout<<" arrayLineageData "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount; counter3++) arrayIFData [lineageDataEntryCount-1][counter3] = ifExtractTemp [counter3];
                                
                                arrayIFDataEntryHold [lineageDataEntryCount-1] = ifExtractTempCount;
                                
                                //for (int counterA = 0; counterA < arrayIFDataEntryHold [lineageDataEntryCount-1]/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [lineageDataEntryCount-1][counterA*13+counterB];
                                //    cout<<" arrayIFData "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < arrayIFTimeLineDataEntryHold [counter1]; counter3++){
                                    arrayIFTimeLineData [lineageDataEntryCount-1][counter3] = arrayIFTimeLineData [counter1][counter3];
                                }
                                
                                arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = arrayIFTimeLineDataEntryHold [counter1];
                                
                                for (int counter3 = 0; counter3 < arrayTableMainHold [counter1]; counter3++) arrayTableMain [lineageDataEntryCount-1][counter3] = arrayTableMain [counter1][counter3];
                                
                                arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                arrayTableMain [lineageDataEntryCount-1][1] = "CA";
                                arrayTableMain [lineageDataEntryCount-1][4] = "CA"+to_string(maxCategoryLingNo)+"-"+treatNameExtract;
                                
                                arrayTableMainHold [lineageDataEntryCount-1] = arrayTableMainHold [counter1];
                                
                                for (int counter3 = 0; counter3 < 17; counter3++) arrayTableDetail [lineageDataEntryCount-1][counter3] = arrayTableDetailTemp [counter3];
                                
                                for (int counter3 = 0; counter3 < arrayIfTimeStatusHold [counter1]; counter3++) arrayIfTimeStatus [lineageDataEntryCount-1][counter3] = ifTimeExtract [counter3];
                                
                                arrayIfTimeStatusHold [lineageDataEntryCount-1] = arrayIfTimeStatusHold [counter1];
                                
                                for (int counter3 = 0; counter3 < areaExtractTempCount; counter3++) arrayAreaData [lineageDataEntryCount-1][counter3] = areaExtractTemp [counter3];
                                
                                arrayAreaDataHold [lineageDataEntryCount-1] = areaExtractTempCount;
                                
                                //**********arrayLinkData**********
                                for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++){
                                    arrayLineageLink [lineageDataEntryCount-1][counter3] = arrayLineageLinkTemp [counter3];
                                }
                                
                                arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                                
                                lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                                
                                savePath = imageDisplayPath+"/"+"LineageDataAnalysis";
                                
                                char *writingArray = new char [lineageExtractTempCount/9*28+100];
                                
                                long indexCount = 0;
                                int readBit [4];
                                int dataTemp;
                                
                                for (unsigned long counter3 = 0; counter3 < lineageExtractTempCount/9; counter3++){
                                    if (lineageExtractTemp [counter3*9] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9];
                                    }
                                    
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    if (lineageExtractTemp [counter3*9+1] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9+1]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9+1];
                                    }
                                    
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp [counter3*9+2];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)lineageExtractTemp [counter3*9+3], indexCount++;
                                    
                                    if (lineageExtractTemp [counter3*9+4] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9+4]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9+4];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    if (lineageExtractTemp [counter3*9+5] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9+5]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = lineageExtractTemp [counter3*9+5];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp [counter3*9+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp [counter3*9+7];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = lineageExtractTemp [counter3*9+8];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 28; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile (savePath.c_str(), ofstream::binary);
                                outfile.write ((char*) writingArray, indexCount);
                                outfile.close();
                                
                                delete [] writingArray;
                                
                                savePath = imageDisplayPath+"/"+"LineageDataAnalysisEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<lineageExtractTempCount<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"IFData";
                                
                                writingArray = new char [ifExtractTempCount/22*60+60];
                                
                                indexCount = 0;
                                
                                for (int counter3 = 0; counter3 < ifExtractTempCount/22; counter3++){
                                    if (ifExtractTemp [counter3*22] < 0){
                                        writingArray [indexCount] = 1, indexCount++;
                                        dataTemp = ifExtractTemp [counter3*22]*-1;
                                    }
                                    else{
                                        
                                        writingArray [indexCount] = 0, indexCount++;
                                        dataTemp = ifExtractTemp [counter3*22];
                                    }
                                    
                                    readBit [0] = dataTemp/16777216;
                                    dataTemp = dataTemp%16777216;
                                    readBit [1] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [2] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [3] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    writingArray [indexCount] = (char)readBit [3], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+1];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+2];
                                    readBit [0] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [1] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+3], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+4], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+5];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+6];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+7], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+8];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+9];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+10], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+11];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+12];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+13], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+14];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+15];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+16], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+17];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+18];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    writingArray [indexCount] = (char)ifExtractTemp [counter3*22+19], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+20];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                    
                                    dataTemp = ifExtractTemp [counter3*22+21];
                                    readBit [0] = dataTemp/65536;
                                    dataTemp = dataTemp%65536;
                                    readBit [1] = dataTemp/256;
                                    dataTemp = dataTemp%256;
                                    readBit [2] = dataTemp;
                                    
                                    writingArray [indexCount] = (char)readBit [0], indexCount++;
                                    writingArray [indexCount] = (char)readBit [1], indexCount++;
                                    writingArray [indexCount] = (char)readBit [2], indexCount++;
                                }
                                
                                for (int counter3 = 0; counter3 < 33; counter3++) writingArray [indexCount] = 0, indexCount++;
                                
                                ofstream outfile2 (savePath.c_str(), ofstream::binary);
                                outfile2.write ((char*) writingArray, indexCount);
                                outfile2.close();
                                
                                delete [] writingArray;
                                
                                savePath = imageDisplayPath+"/"+"IFDataEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<ifExtractTempCount<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"IFTimeLine";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"IFTimeLineEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"MainTable";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayTableMainHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayTableMain [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"MainTableEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"DetailTable";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < 17; counter3++){
                                    oin<<arrayTableDetail [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/IFDataStatus";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < ifTimeExtractCount; counter3++){
                                    oin<<arrayIfTimeStatus [counter1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/IFDataStatusEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayIfTimeStatusHold [counter1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"AreaData";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < arrayAreaDataHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayAreaData [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/AreaDataEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                                oin.close();
                                
                                savePath = imageDisplayPath+"/"+"LinkData";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                
                                for (int counter3 = 0; counter3 < lineageLinkHold [lineageDataEntryCount-1]; counter3++){
                                    oin<<arrayLineageLink [lineageDataEntryCount-1][counter3]<<endl;
                                }
                                
                                oin.close();
                                
                                savePath = imageDisplayPath+"/LinkDataEntry";
                                
                                oin.open(savePath.c_str(), ios::out | ios::binary);
                                oin<<lineageLinkHold [lineageDataEntryCount-1] <<endl;
                                oin.close();
                                
                                delete [] lineageExtractTemp;
                                delete [] ifExtractTemp;
                                delete [] areaExtractTemp;
                                delete [] arrayLineageLinkTemp;
                                delete [] categorySort;
                                delete [] arrayTableDetailTemp;
                            }
                            
                            delete [] categoryLineageList;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Entry Limit Exceeded: 100"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                            
                            break;
                        }
                    }
                }
                
                upLoadingFlag = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Analysis Performed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Category Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lineageComparison:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold == 9){
            categoryResultsHoldCount = 0;
            
            int lineageEntryNo = 0;
            unsigned long lineageEntrySize = 0;
            int totalEventCount = 0;
            int lineageProcessCount = 0;
            
            string percentString;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1) lineageProcessCount++;
            }
            
            if (lineageProcessCount >= 2){
                int maxLineageNo = 0;
                int processCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1){
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+6] > maxLineageNo){
                                maxLineageNo = arrayLineageData [counter2][counter3*9+6];
                            }
                        }
                        
                        processCount++;
                        
                        if (processCount == 2){
                            break;
                        }
                    }
                }
                
                int *categoryLineageList = new int [maxLineageNo*2+10];
                int *categoryLineageListTD = new int [maxLineageNo*2+10];
                int *categoryLineageListCD = new int [maxLineageNo*2+10];
                int *categoryLineageListCF = new int [maxLineageNo*2+10];
                int *categoryLineageList2 = new int [maxLineageNo*2+10];
                
                for (int counter3 = 0; counter3 < maxLineageNo*2+10; counter3++){
                    categoryLineageList [counter3] = -1;
                    categoryLineageListTD [counter3] = -1;
                    categoryLineageListCD [counter3] = -1;
                    categoryLineageListCF [counter3] = -1;
                    categoryLineageList2 [counter3] = -1;
                }
                
                string nameHold1 = "";
                string nameHold2 = "";
                
                processCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1){
                        processCount++;
                        
                        //for (int counterA = 0; counterA < 1; counterA++){
                        //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                        //    cout<<"  arrayTableMain "<<counterA<<endl;
                        //}
                        
                        lineageEntrySize = arrayLineageDataEntryHold [counter2];
                        
                        lineageEntryNo = 0;
                        
                        for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                                lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                            }
                        }
                        
                        if (processCount == 1){
                            nameHold1 = arrayTableMain [counter2][3];
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                categoryLineageList [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                categoryLineageListTD [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                categoryLineageListCD [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                categoryLineageListCF [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                            }
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                if (arrayLineageData [counter2][counter3*9+3] == 42 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                    categoryLineageListTD [arrayLineageData [counter2][counter3*9+6]*2]++;
                                }
                                
                                if (arrayLineageData [counter2][counter3*9+3] == 7 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                    categoryLineageListCD [arrayLineageData [counter2][counter3*9+6]*2]++;
                                }
                                
                                if (arrayLineageData [counter2][counter3*9+3] == 91 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                    categoryLineageListCF [arrayLineageData [counter2][counter3*9+6]*2]++;
                                }
                                
                                if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                                    categoryLineageList [arrayLineageData [counter2][counter3*9+6]*2]++;
                                }
                            }
                        }
                        else{
                            
                            nameHold2 = arrayTableMain [counter2][3];
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                categoryLineageList2 [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                            }
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                                    categoryLineageList2 [arrayLineageData [counter2][counter3*9+6]*2]++;
                                }
                            }
                            
                            break;
                        }
                    }
                }
                
                //for (int counterA = 1; counterA <= maxLineageNo; counterA++){
                //    cout<<counterA<<" "<<categoryLineageListCD [counterA*2]<<" "<<categoryLineageListCD [counterA*2+1]<<" categoryLineageListCD"<<endl;
                //}
                
                arrayCategoryResultsHold [categoryResultsHoldCount] = nameHold1, categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = nameHold2, categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = "No of Ling.", categoryResultsHoldCount++;
                
                //for (int counterA = 0; counterA < categoryRangeHoldCount/3; counterA++){
                //    cout<<counterA<<" "<<arrayCategoryRangeHold [counterA*3]<<" "<<arrayCategoryRangeHold [counterA*3+1]<<" "<<arrayCategoryRangeHold [counterA*3+2]<<" rrayCategoryRangeHold"<<endl;
                //}
                
                int *categorySort1 = new int [categoryRangeHoldCount+10];
                
                totalEventCount = 0;
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount+10; counter3++) categorySort1 [counter3] = 0;
                
                for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                    if (categoryLineageList [counter3*2] != -1){
                        for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                            if (categoryLineageList [counter3*2] != -1 && categoryLineageList [counter3*2] >= arrayCategoryRangeHold [counter4*3+1] && categoryLineageList [counter3*2] <= arrayCategoryRangeHold [counter4*3+2]){
                                categorySort1 [counter4]++;
                                totalEventCount++;
                                break;
                            }
                        }
                    }
                    else if (categoryLineageList [counter3*2] == 0){
                        categorySort1 [0]++;
                        totalEventCount++;
                    }
                }
                
                for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                    if (categoryLineageList [counter3*2] != -1){
                        for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                            if (categoryLineageList [counter3*2] != -1 && categoryLineageList [counter3*2] >= arrayCategoryRangeHold [counter4*3+1] && categoryLineageList [counter3*2] <= arrayCategoryRangeHold [counter4*3+2]){
                                categoryLineageList [counter3*2+1] = counter4;
                                break;
                            }
                        }
                    }
                }
                
                for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                    if (categoryLineageList2 [counter3*2] != -1){
                        for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                            if (categoryLineageList2 [counter3*2] != -1 && categoryLineageList2 [counter3*2] >= arrayCategoryRangeHold [counter4*3+1] && categoryLineageList2 [counter3*2] <= arrayCategoryRangeHold [counter4*3+2]){
                                categoryLineageList2 [counter3*2+1] = counter4;
                                break;
                            }
                        }
                    }
                }
                
                int **lingMatchFind = new int *[categoryRangeHoldCount/3+10];
                int **lingMatchFindTD = new int *[categoryRangeHoldCount/3+10];
                int **lingMatchFindCD = new int *[categoryRangeHoldCount/3+10];
                int **lingMatchFindCF = new int *[categoryRangeHoldCount/3+10];
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                    lingMatchFind [counter3] = new int [categoryRangeHoldCount/3+10];
                    lingMatchFindTD [counter3] = new int [categoryRangeHoldCount/3+10];
                    lingMatchFindCD [counter3] = new int [categoryRangeHoldCount/3+10];
                    lingMatchFindCF [counter3] = new int [categoryRangeHoldCount/3+10];
                }
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                    for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                        lingMatchFind [counter3][counter4] = 0;
                        lingMatchFindTD [counter3][counter4] = 0;
                        lingMatchFindCD [counter3][counter4] = 0;
                        lingMatchFindCF [counter3][counter4] = 0;
                    }
                }
                
                for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                    if (categoryLineageList [counter3*2] != -1){
                        if (categoryLineageList2 [counter3*2] != -1){
                            lingMatchFind [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]]++;
                            lingMatchFindTD [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]] = lingMatchFindTD [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]]+categoryLineageListTD [counter3*2];
                            lingMatchFindCD [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]] = lingMatchFindCD [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]]+categoryLineageListCD [counter3*2];
                            lingMatchFindCF [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]] = lingMatchFindCF [categoryLineageList [counter3*2+1]][categoryLineageList2 [counter3*2+1]]+categoryLineageListCF [counter3*2];
                        }
                    }
                }
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                    if (categoryResultsHoldCount+10 > categoryResultsHoldLimit){
                        string *arrayUpDate = new string [categoryResultsHoldCount+10];
                        
                        for (int counter4 = 0; counter4 < categoryResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayCategoryResultsHold [counter4];
                        
                        delete [] arrayCategoryResultsHold;
                        arrayCategoryResultsHold = new string [categoryResultsHoldLimit+350*3+500];
                        categoryResultsHoldLimit = categoryResultsHoldLimit+350*3+500;
                        
                        for (int counter4 = 0; counter4 < categoryResultsHoldCount; counter4++) arrayCategoryResultsHold [counter4] = arrayUpDate [counter4];
                        delete [] arrayUpDate;
                    }
                    
                    if (arrayCategoryRangeHold [counter3*3+1] == 0 && arrayCategoryRangeHold [counter3*3+2] == 0){
                        arrayCategoryResultsHold [categoryResultsHoldCount] = "0", categoryResultsHoldCount++;
                    }
                    else if (arrayCategoryRangeHold [counter3*3+2] == 100000000) arrayCategoryResultsHold [categoryResultsHoldCount] = ">="+to_string(arrayCategoryRangeHold [counter3*3+1]), categoryResultsHoldCount++;
                    else arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(arrayCategoryRangeHold [counter3*3+1])+"-"+to_string(arrayCategoryRangeHold [counter3*3+2]), categoryResultsHoldCount++;
                    
                    arrayCategoryResultsHold [categoryResultsHoldCount] = "Total", categoryResultsHoldCount++;
                    
                    arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(categorySort1 [counter3]), categoryResultsHoldCount++;
                    
                    for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                        arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                        
                        if (arrayCategoryRangeHold [counter4*3+1] == 0 && arrayCategoryRangeHold [counter4*3+2] == 0){
                            arrayCategoryResultsHold [categoryResultsHoldCount] = "0", categoryResultsHoldCount++;
                        }
                        else if (arrayCategoryRangeHold [counter4*3+2] == 100000000) arrayCategoryResultsHold [categoryResultsHoldCount] = ">="+to_string(arrayCategoryRangeHold [counter4*3+1]), categoryResultsHoldCount++;
                        else arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(arrayCategoryRangeHold [counter4*3+1])+"-"+to_string(arrayCategoryRangeHold [counter4*3+2]), categoryResultsHoldCount++;
                        
                        arrayCategoryResultsHold [categoryResultsHoldCount] = to_string(lingMatchFind [counter3][counter4])+"-T"+to_string(lingMatchFindTD [counter3][counter4])+"-C"+to_string(lingMatchFindCD [counter3][counter4])+"-F"+to_string(lingMatchFindCF [counter3][counter4]), categoryResultsHoldCount++;
                    }
                    
                    arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                    arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                    arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                }
                
                arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                arrayCategoryResultsHold [categoryResultsHoldCount] = "", categoryResultsHoldCount++;
                
                delete [] categoryLineageList;
                delete [] categoryLineageListTD;
                delete [] categoryLineageListCD;
                delete [] categoryLineageListCF;
                delete [] categoryLineageList2;
                
                delete [] categorySort1;
                
                for (int counter3 = 0; counter3 < categoryRangeHoldCount/3; counter3++){
                    delete [] lingMatchFind [counter3];
                    delete [] lingMatchFindTD [counter3];
                    delete [] lingMatchFindCD [counter3];
                    delete [] lingMatchFindCF [counter3];
                }
                
                delete [] lingMatchFind;
                delete [] lingMatchFindTD;
                delete [] lingMatchFindCD;
                delete [] lingMatchFindCF;
                
                lineageComparisonStatusHold = 1;
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToProgenyNoTable object:self];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Set PG"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFileComp:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold != 0){
            if (categoryResultsHoldCount != 0 && lineageComparisonStatusHold == 1){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Categorization";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Categorization") != -1){
                            extractString = entry.substr(entry.find("CP")+2, entry.find(".txt")-entry.find("CP")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string path = resultSavePath2+"/Categorization-CP"+to_string(maxEntryNo)+".txt";
                
                ofstream oin;
                oin.open(path.c_str(), ios::out | ios::binary);
                
                int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
                
                ascIIconversion = [[ASCIIconversion alloc] init];
                
                ascIIstring = "Comparison";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = "Cut Off Time";
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = to_string(categoryTimeHold);
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
                
                for (int counter1 = 0; counter1 < categoryResultsHoldCount/3; counter1++){
                    ascIIstring = arrayCategoryResultsHold [counter1*3];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayCategoryResultsHold [counter1*3+1];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = arrayCategoryResultsHold [counter1*3+2];
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                }
                
                delete [] arrayAscIIintData;
                
                oin.close();
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Analysis Performed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Category Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFileComp2:(id)sender{
    if (lineageDataEntryCount != 0){
        if (categoryHold != 0){
            if (categoryResultsHoldCount != 0 && lineageComparisonStatusHold == 1){
                string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
                mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Categorization";
                mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                
                DIR *dir;
                struct dirent *dent;
                
                string entry;
                string extractString;
                int maxEntryNo = 0;
                
                dir = opendir(resultSavePath2.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Categorization") != -1){
                            extractString = entry.substr(entry.find("CP")+2, entry.find(".txt")-entry.find("CP")-2);
                            
                            if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                        }
                    }
                    
                    closedir(dir);
                }
                
                maxEntryNo++;
                
                string path = resultSavePath2+"/Categorization-CP"+to_string(maxEntryNo)+".txt";
                
                int lineageEntryNo = 0;
                unsigned long lineageEntrySize = 0;
                int lineageProcessCount = 0;
                
                string percentString;
                
                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                    if (arraySelectedLing [counter2] == 1) lineageProcessCount++;
                }
                
                if (lineageProcessCount >= 2){
                    int maxLineageNo = 0;
                    int processCount = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                        if (arraySelectedLing [counter2] == 1){
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                                if (arrayLineageData [counter2][counter3*9+6] > maxLineageNo){
                                    maxLineageNo = arrayLineageData [counter2][counter3*9+6];
                                }
                            }
                            
                            processCount++;
                            
                            if (processCount == 2){
                                break;
                            }
                        }
                    }
                    
                    int *categoryLineageList = new int [maxLineageNo*2+10];
                    int *categoryLineageListDD = new int [maxLineageNo*2+10];
                    int *categoryLineageListTD = new int [maxLineageNo*2+10];
                    int *categoryLineageListCD = new int [maxLineageNo*2+10];
                    int *categoryLineageListCF = new int [maxLineageNo*2+10];
                    int *categoryLineageList2 = new int [maxLineageNo*2+10];
                    
                    for (int counter3 = 0; counter3 < maxLineageNo*2+10; counter3++){
                        categoryLineageList [counter3] = -1;
                        categoryLineageListDD [counter3] = -1;
                        categoryLineageListTD [counter3] = -1;
                        categoryLineageListCD [counter3] = -1;
                        categoryLineageListCF [counter3] = -1;
                        categoryLineageList2 [counter3] = -1;
                    }
                    
                    string nameHold1 = "";
                    string nameHold2 = "";
                    
                    processCount = 0;
                    
                    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                        if (arraySelectedLing [counter2] == 1){
                            processCount++;
                            
                            //for (int counterA = 0; counterA < 1; counterA++){
                            //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                            //    cout<<"  arrayTableMain "<<counterA<<endl;
                            //}
                            
                            lineageEntrySize = arrayLineageDataEntryHold [counter2];
                            
                            lineageEntryNo = 0;
                            
                            for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                                    lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                                }
                            }
                            
                            if (processCount == 1){
                                nameHold1 = arrayTableMain [counter2][3];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                    categoryLineageList [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                    categoryLineageListDD [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                    categoryLineageListTD [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                    categoryLineageListCD [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                    categoryLineageListCF [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                    if (arrayLineageData [counter2][counter3*9+3] == 32 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageListDD [arrayLineageData [counter2][counter3*9+6]*2]++;
                                    }
                                    if (arrayLineageData [counter2][counter3*9+3] == 42 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageListTD [arrayLineageData [counter2][counter3*9+6]*2]++;
                                    }
                                    if (arrayLineageData [counter2][counter3*9+3] == 7 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageListCD [arrayLineageData [counter2][counter3*9+6]*2]++;
                                    }
                                    if (arrayLineageData [counter2][counter3*9+3] == 91 && arrayLineageData [counter2][counter3*9+2] <= categoryTimeHold){
                                        categoryLineageListCF [arrayLineageData [counter2][counter3*9+6]*2]++;
                                    }
                                    if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                                        categoryLineageList [arrayLineageData [counter2][counter3*9+6]*2]++;
                                    }
                                }
                            }
                            else{
                                
                                nameHold2 = arrayTableMain [counter2][3];
                                
                                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                    categoryLineageList2 [arrayLineageData [counter2][counter3*9+6]*2] = 0;
                                }
                                
                                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                                    if (arrayLineageData [counter2][counter3*9+2] == categoryTimeHold){
                                        categoryLineageList2 [arrayLineageData [counter2][counter3*9+6]*2]++;
                                    }
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= maxLineageNo; counterA++){
                    // cout<<counterA<<" "<<categoryLineageList2 [counterA*2]<<" "<<categoryLineageList2 [counterA*2+1]<<" "<<categoryLineageListDD [counterA*2+1]<<" categoryLineageListDD"<<endl;
                    // }
                    
                    //for (int counterA = 0; counterA < categoryRangeHoldCount/3; counterA++){
                    //    cout<<counterA<<" "<<categoryLineageList2 [counterA*3]<<" "<<arrayCategoryRangeHold [counterA*3+1]<<" "<<arrayCategoryRangeHold [counterA*3+2]<<" arrayCategoryRangeHold"<<endl;
                    //}
                    
                    for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                        if (categoryLineageList2 [counter3*2] != -1){
                            for (int counter4 = 0; counter4 < categoryRangeHoldCount/3; counter4++){
                                if (categoryLineageList2 [counter3*2] != -1 && categoryLineageList2 [counter3*2] >= arrayCategoryRangeHold [counter4*3+1] && categoryLineageList2 [counter3*2] <= arrayCategoryRangeHold [counter4*3+2]){
                                    categoryLineageList2 [counter3*2+1] = counter4;
                                    break;
                                }
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= maxLineageNo; counterA++){
                    //    cout<<counterA<<" "<<categoryLineageList2 [counterA*2]<<" "<<categoryLineageList2 [counterA*2+1]<<" "<<categoryLineageListDD [counterA*2]<<" categoryLineageListDD"<<endl;
                    //}
                    
                    ofstream oin;
                    oin.open(path.c_str(), ios::out | ios::binary);
                    
                    int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
                    
                    ascIIconversion = [[ASCIIconversion alloc] init];
                    
                    ascIIstring = "Simulation BD";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Cut Off Time";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(categoryTimeHold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    string rangeString;
                    
                    for (int counter1 = 0; counter1 < categoryRangeHoldCount/3; counter1++){
                        if (arrayCategoryRangeHold [counter1*3+1] == 0 && arrayCategoryRangeHold [counter1*3+2] == 0){
                            rangeString = "0";
                        }
                        else if (arrayCategoryRangeHold [counter1*3+2] == 100000000) rangeString = ">="+to_string(arrayCategoryRangeHold [counter1*3+1]);
                        else rangeString = to_string(arrayCategoryRangeHold [counter1*3+1])+"-"+to_string(arrayCategoryRangeHold [counter1*3+2]);
                        
                        ascIIstring = rangeString;
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                            if (categoryLineageList2 [counter3*2] != -1 && categoryLineageList2 [counter3*2+1] == counter1){
                                ascIIstring = to_string(categoryLineageListDD [counter3*2]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                    }
                    
                    ascIIstring = "Simulation TD";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Cut Off Time";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(categoryTimeHold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter1 = 0; counter1 < categoryRangeHoldCount/3; counter1++){
                        if (arrayCategoryRangeHold [counter1*3+1] == 0 && arrayCategoryRangeHold [counter1*3+2] == 0){
                            rangeString = "0";
                        }
                        else if (arrayCategoryRangeHold [counter1*3+2] == 100000000) rangeString = ">="+to_string(arrayCategoryRangeHold [counter1*3+1]);
                        else rangeString = to_string(arrayCategoryRangeHold [counter1*3+1])+"-"+to_string(arrayCategoryRangeHold [counter1*3+2]);
                        
                        ascIIstring = rangeString;
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                            if (categoryLineageList2 [counter3*2] != -1 && categoryLineageList2 [counter3*2+1] == counter1){
                                ascIIstring = to_string(categoryLineageListTD [counter3*2]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                    }
                    
                    ascIIstring = "Simulation CD";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Cut Off Time";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(categoryTimeHold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter1 = 0; counter1 < categoryRangeHoldCount/3; counter1++){
                        if (arrayCategoryRangeHold [counter1*3+1] == 0 && arrayCategoryRangeHold [counter1*3+2] == 0){
                            rangeString = "0";
                        }
                        else if (arrayCategoryRangeHold [counter1*3+2] == 100000000) rangeString = ">="+to_string(arrayCategoryRangeHold [counter1*3+1]);
                        else rangeString = to_string(arrayCategoryRangeHold [counter1*3+1])+"-"+to_string(arrayCategoryRangeHold [counter1*3+2]);
                        
                        ascIIstring = rangeString;
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                            if (categoryLineageList2 [counter3*2] != -1 && categoryLineageList2 [counter3*2+1] == counter1){
                                ascIIstring = to_string(categoryLineageListCD [counter3*2]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                    }
                    
                    ascIIstring = "Simulation CF";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = "Cut Off Time";
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    ascIIstring = to_string(categoryTimeHold);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                    
                    oin.put(9);
                    
                    oin.put(13);
                    oin.put(10);
                    
                    for (int counter1 = 0; counter1 < categoryRangeHoldCount/3; counter1++){
                        if (arrayCategoryRangeHold [counter1*3+1] == 0 && arrayCategoryRangeHold [counter1*3+2] == 0){
                            rangeString = "0";
                        }
                        else if (arrayCategoryRangeHold [counter1*3+2] == 100000000) rangeString = ">="+to_string(arrayCategoryRangeHold [counter1*3+1]);
                        else rangeString = to_string(arrayCategoryRangeHold [counter1*3+1])+"-"+to_string(arrayCategoryRangeHold [counter1*3+2]);
                        
                        ascIIstring = rangeString;
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        for (int counter3 = 1; counter3 <= maxLineageNo; counter3++){
                            if (categoryLineageList2 [counter3*2] != -1 && categoryLineageList2 [counter3*2+1] == counter1){
                                ascIIstring = to_string(categoryLineageListCF [counter3*2]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                    }
                    
                    delete [] arrayAscIIintData;
                    
                    oin.close();
                    
                    delete [] categoryLineageList;
                    delete [] categoryLineageListDD;
                    delete [] categoryLineageListTD;
                    delete [] categoryLineageListCD;
                    delete [] categoryLineageListCF;
                    delete [] categoryLineageList2;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                }
            }
            else{
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Analysis Performed"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Category Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [categoryProgenyWindow orderOut:self];
    progenyNoWindowOperation = 2;
    categoryProgenyTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (progenyNoWindowOperation == 3){
        [categoryProgenyWindow makeKeyAndOrderFront:self];
        progenyNoWindowOperation = 1;
        [categoryProgenyTimer invalidate];
    }
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToProgenyNoController object:nil];
}

@end
