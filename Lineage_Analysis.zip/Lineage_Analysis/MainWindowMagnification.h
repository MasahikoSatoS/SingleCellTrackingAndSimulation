//
//  MainWindowMagnification.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-12-05.
//
//

#ifndef MAINWINDOWMAGNIFICATION_H
#define MAINWINDOWMAGNIFICATION_H
#import "Controller.h" 
#endif

@interface MainWindowMagnification : NSView{
    double xPointDownDisplay; //X Position Mouse Down
    double yPointDownDisplay; //Y Position Mouse Down
    
    IBOutlet NSWindow *mainWindowMagWindow;
}

@end
