//
//  CellGrowthDisplay.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/2/16.
//
//

#import "CellGrowthDisplay.h"

NSString *notificationToGrowthCurveDisplay = @"notificationExecuteGrowthCurveDisplay";

@implementation CellGrowthDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToGrowthCurveDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    
    if (upLoadingProgress == 0){
        if (clickPoint.x > 718 && clickPoint.x < 760 && clickPoint.y >573 && clickPoint.y < 587){
            if (verticalScaleHighHold-verticalScaleLowHold < 100 || horizontalScaleHighHold-horizontalScaleLowHold < 100){
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"Check Range"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                [self setNeedsDisplay:YES];
            }
        }
        
        if (clickPoint.x > 668 && clickPoint.x < 710 && clickPoint.y >573 && clickPoint.y < 587){
            exportFlag5 = 1;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Growth_Curve";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Growth_Curve") != -1){
                        extractString = entry.substr(entry.find("GC")+2, entry.find(".tif")-entry.find("GC")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            exportResultPath = resultSavePath2+"/Growth_Curve-GC"+to_string(maxEntryNo)+".tif";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        
        if (exportFlag5 == 2){
            exportFlag5 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (exportFlag5 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767, 591)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(718, 573, 42, 14)];
        [path stroke];
        
        string reloadString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 720;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(668, 573, 42, 14)];
        [path stroke];
        
        reloadString = "Export";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 670;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        if (individualOverLayHold == 0){
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:1.5];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(80, 100, 650, 300)];
            [path stroke];
            
            //----Horizontal Label----
            int horizontalTime = horizontalScaleHighHold-horizontalScaleLowHold;
            string timeString = "Time (hr)";
            
            NSString *timeNSstring = @(timeString.c_str());
            
            NSFont *font = [NSFont boldSystemFontOfSize:11];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
            pointA.x = 80+325-(size2/(double)2);
            pointA.y = 100-40;
            [attrStrA drawAtPoint:pointA];
            
            double horizontalTimeHr = horizontalTime/(double)60;
            
            //----Horizontal Scale----
            double lengthDivision = horizontalTimeHr/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
            else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
            else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
            else if (lengthDivision > 5000) lengthDivisionInt = 1000;
            
            double lengthPix = ((650-10)/(double)horizontalTimeHr)*lengthDivisionInt;
            int numberOfDivision = (int)((650-10)/(double)lengthPix)+1;
            
            int horizontalLowInt = (int)(horizontalScaleLowHold/(double)60);
            
            double sift = 0;
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint pointA2;
            
            for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                positionAA.x = 80+lengthPix*counter2;
                positionAA.y = 100;
                positionBB.x = 80+lengthPix*counter2;
                positionBB.y = 100+5;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+horizontalLowInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter2*lengthDivision == 0) sift = 0;
                else if (counter2*lengthDivision < 1000) sift = 1;
                
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                pointA2.x = (80+lengthPix*counter2)-(size2/(double)2)-sift;
                pointA2.y = 100-20;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            //----Vertical Scale----
            int verticalNo = verticalScaleHighHold-verticalScaleLowHold;
            
            double lengthDivision2 = verticalNo/(double)5;
            int lengthDivisionInt2 = 0;
            
            if (lengthDivision2 <= 25) lengthDivisionInt2 = 25;
            else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
            else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
            else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
            else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
            else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
            else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
            else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
            else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
            else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
            else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
            else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
            else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
            else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
            
            double lengthPix2 = ((300-10)/(double)verticalNo)*lengthDivisionInt2;
            int numberOfDivision2 = (int)((300-10)/(double)lengthPix2)+1;
            
            int lowestXPosition = 1000;
            
            for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                positionAA.x = 80;
                positionAA.y = 100+lengthPix2*counter2;
                positionBB.x = 80+5;
                positionBB.y = 100+lengthPix2*counter2;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2+verticalScaleLowHold).c_str());
                NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                size2 = [attrStrS3 size].width;
                
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                pointA2.x = 80-size2-10;
                pointA2.y = 100+lengthPix2*counter2-5;
                [attrStrA2 drawAtPoint:pointA2];
                
                if (lowestXPosition > 80-size2-10) lowestXPosition = (int)(80-size2-10);
            }
            
            //----Vertical Label----
            NSString *verticalNSstring = @"Number of Cells";
            
            NSFont *font2 = [NSFont boldSystemFontOfSize:11];
            NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
            NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
            size2 = [attrStrS2 size].width;
            
            NSGraphicsContext *context = [NSGraphicsContext currentContext];
            NSAffineTransform *transform = [NSAffineTransform transform];
            [transform rotateByDegrees:+90];
            
            [context saveGraphicsState];
            [transform concat];
            
            NSAttributedString *attrStrB;
            NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
            NSString *titleStringB = @"Number of Cells";
            
            [attributesB setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
            
            pointA.x = 100+(150-size2/(double)2);
            pointA.y = (lowestXPosition-10)*-1;
            [attrStrB drawAtPoint:pointA];
            
            [context restoreGraphicsState];
            
            [NSBezierPath setDefaultLineWidth:1.0];
            
            int *cellNumberHold = new int [horizontalScaleMaxHold+50];
            int actualTime = 0;
            int timeEnd = 0;
            int colorCount = 0;
            int lineVertical = 540;
            int lineHorizontal = 80;
            int rgbA1 = 255;
            int rgbB1 = 0;
            int rgbA2 = 255;
            int rgbB2 = 153;
            int rgbA3 = 255;
            int rgbB3 = 255;
            int rgbA4 = 255;
            int rgbB4 = 255;
            int rgbA5 = 255;
            int rgbB5 = 255;
            int rgbA6 = 0;
            int rgbB6 = 0;
            int rgbA7 = 255;
            int rgbB7 = 255;
            int rgbA8 = 255;
            int rgbB8 = 0;
            int initialValue = 0;
            double xPositionCenter = 0;
            double yPositionCenter = 0;
            string treatNameGR;
            
            NSAttributedString *attrStrA3;
            NSMutableDictionary *attributesA3 = [NSMutableDictionary dictionary];
            [attributesA3 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
            [attributesA3 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            int checkTime = 0;
            int checkTime2 = 0;
            int checkLing = 0;
            int checkCell = 0;
            
            int *oldNewData = new int [lineageDataEntryCount+1];
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount+1; counter2++){
                oldNewData [counter2] = 0;
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    checkTime = 0;
                    checkTime2 = 0;
                    checkLing = 0;
                    checkCell = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+3] == 32){
                            checkTime = arrayLineageData [counter2][counter3*9+2];
                            checkLing = arrayLineageData [counter2][counter3*9+6];
                            checkCell = arrayLineageData [counter2][counter3*9+5];
                            break;
                        }
                    }
                    
                    if (checkTime != 0){
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+3] == 31 && arrayLineageData [counter2][counter3*9+4] == checkCell && arrayLineageData [counter2][counter3*9+6] == checkLing){
                                checkTime2 = arrayLineageData [counter2][counter3*9+2];
                                break;
                            }
                        }
                        
                        if (checkTime == checkTime2){
                            oldNewData [counter2] = 1;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    for (int counter3 = 0; counter3 < horizontalScaleMaxHold+50; counter3++){
                        cellNumberHold [counter3] = 0;
                    }
                    
                    timeEnd = arrayTableDetail [counter2][3];
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        actualTime = (arrayLineageData [counter2][counter3*9+2]-1)*atoi(arrayLineageDataType [counter2][5].c_str());
                        
                        if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                            if (oldNewData [counter2] == 0){
                                cellNumberHold [actualTime]++;
                            }
                            else if (arrayLineageData [counter2][counter3*9+3] != 32 && arrayLineageData [counter2][counter3*9+3] != 42 && arrayLineageData [counter2][counter3*9+3] != 52){
                                cellNumberHold [actualTime]++;
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= horizontalScaleMaxHold; counterA++){
                    //    cout<<counterA<<" "<<cellNumberHold [counterA]<<" cellNo"<<endl;
                    //}
                    
                    if (normalizeStatusHold == 1){
                        for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                            if (cellNumberHold [counter3] != 0){
                                initialValue = cellNumberHold [counter3];
                                break;
                            }
                        }
                        
                        if (initialValue != 0 && initialValue > 1){
                            for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                                cellNumberHold [counter3] = (int)((cellNumberHold [counter3]/(double)initialValue)*100);
                            }
                        }
                    }
                    
                    [NSBezierPath setDefaultLineWidth:2.0];
                    
                    if (colorCount == 0){
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbB1/(double)255) blue:(CGFloat)(rgbA1/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbB1/(double)255) blue:(CGFloat)(rgbA1/(double)255) alpha:1] set];
                        
                        rgbA1 = rgbA1-50;
                        rgbB1 = rgbB1+50;
                    }
                    else if (colorCount == 1){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA2/(double)255) green:(CGFloat)(rgbB2/(double)255) blue:0 alpha:1] set];
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA2/(double)255) green:(CGFloat)(rgbB2/(double)255) blue:0 alpha:1] set];
                        
                        rgbA2 = rgbA2-50;
                        rgbB2 = rgbB2-20;
                    }
                    else if (colorCount == 2){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA3/(double)255) green:(CGFloat)(rgbB3/(double)255) blue:0 alpha:1] set];
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA3/(double)255) green:(CGFloat)(rgbB3/(double)255) blue:0 alpha:1] set];
                        
                        rgbA3 = rgbA3-50;
                        rgbB3 = rgbB3-20;
                    }
                    else if (colorCount == 3){
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbA4/(double)255) blue:(CGFloat)(rgbB4/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbA4/(double)255) blue:(CGFloat)(rgbB4/(double)255) alpha:1] set];
                        
                        rgbA4 = rgbA4-50;
                        rgbB4 = rgbB4-50;
                    }
                    else if (colorCount == 4){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA5/(double)255) green:0 blue:(CGFloat)(rgbB5/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA5/(double)255) green:0 blue:(CGFloat)(rgbB5/(double)255) alpha:1] set];
                        
                        rgbA5 = rgbA5-50;
                        rgbB5 = rgbB5-50;
                    }
                    else if (colorCount == 5){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA6/(double)255) green:0 blue:(CGFloat)(rgbB6/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA6/(double)255) green:0 blue:(CGFloat)(rgbB6/(double)255) alpha:1] set];
                        
                        rgbA6 = rgbA6+50;
                        rgbB6 = rgbB6+50;
                    }
                    else if (colorCount == 6){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA7/(double)255) green:0 blue:(CGFloat)(rgbB7/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA7/(double)255) green:0 blue:(CGFloat)(rgbB7/(double)255) alpha:1] set];
                        
                        rgbA7 = rgbA7-50;
                        rgbB7 = rgbB7-50;
                    }
                    else if (colorCount == 7){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA8/(double)255) green:(CGFloat)(rgbB8/(double)255) blue:0 alpha:1] set];
                        positionAA.x = lineHorizontal;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal+20;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal+25;
                        pointA2.y = lineVertical-6;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        colorCount = 0;
                        lineVertical = 540;
                        lineHorizontal = lineHorizontal+160;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA8/(double)255) green:(CGFloat)(rgbB8/(double)255) blue:0 alpha:1] set];
                        
                        rgbA8 = rgbA8-50;
                        rgbB8 = rgbB8+50;
                    }
                    
                    [NSBezierPath setDefaultLineWidth:1.0];
                    
                    for (int counter3 = 1; counter3 <= horizontalScaleMaxHold; counter3++){
                        xPositionCenter = (640/(double)horizontalTime)*(counter3-horizontalScaleLowHold)+80;
                        yPositionCenter = (290/(double)verticalNo)*(cellNumberHold [counter3]-verticalScaleLowHold)+100;
                        
                        if (xPositionCenter > 80 && xPositionCenter < 80+640 && yPositionCenter > 100 && yPositionCenter < 100+290){
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                            [path stroke];
                        }
                    }
                }
            }
            
            delete [] cellNumberHold;
            delete [] oldNewData;
        }
        else if (individualOverLayHold == 1){
            int entryNumberCount = 0;
            int maxEntry = 0;
            
            int *entryNumberTempHold = new int [40];
            int entryNumberTempHoldCount = 0;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 32){
                    entryNumberCount++;
                    entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    
                    maxEntry++;
                }
            }
            
            int checkTime = 0;
            int checkTime2 = 0;
            int checkLing = 0;
            int checkCell = 0;
            int entryCount = 0;
            
            int *oldNewData = new int [40];
            
            for (int counter2 = 0; counter2 < 40; counter2++){
                oldNewData [counter2] = 0;
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && entryCount < 32){
                    checkTime = 0;
                    checkTime2 = 0;
                    checkLing = 0;
                    checkCell = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+3] == 32){
                            checkTime = arrayLineageData [counter2][counter3*9+2];
                            checkLing = arrayLineageData [counter2][counter3*9+6];
                            checkCell = arrayLineageData [counter2][counter3*9+5];
                            break;
                        }
                    }
                    
                    if (checkTime != 0){
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+3] == 31 && arrayLineageData [counter2][counter3*9+4] == checkCell && arrayLineageData [counter2][counter3*9+6] == checkLing){
                                checkTime2 = arrayLineageData [counter2][counter3*9+2];
                                break;
                            }
                        }
                        
                        if (checkTime == checkTime2){
                            oldNewData [entryCount] = 1;
                        }
                    }
                    
                    entryCount++;
                }
            }
            
            int displayItem1 = 0;
            int displayItem2 = 0;
            int displayItem3 = 0;
            int displayItem4 = 0;
            
            if (entryNumberCount == 1) displayItem1 = 1;
            else if (entryNumberCount == 2){
                displayItem1 = 1;
                displayItem2 = 1;
            }
            else if (entryNumberCount == 3){
                displayItem1 = 1;
                displayItem2 = 1;
                displayItem3 = 1;
            }
            else if (entryNumberCount == 4){
                displayItem1 = 1;
                displayItem2 = 1;
                displayItem3 = 1;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 5){
                displayItem1 = 2;
                displayItem2 = 1;
                displayItem3 = 1;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 6){
                displayItem1 = 2;
                displayItem2 = 2;
                displayItem3 = 1;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 7){
                displayItem1 = 2;
                displayItem2 = 2;
                displayItem3 = 2;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 8){
                displayItem1 = 2;
                displayItem2 = 2;
                displayItem3 = 2;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 9){
                displayItem1 = 3;
                displayItem2 = 2;
                displayItem3 = 2;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 10){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 2;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 11){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 12){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 13){
                displayItem1 = 4;
                displayItem2 = 3;
                displayItem3 = 3;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 14){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 3;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 15){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 16){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 17){
                displayItem1 = 5;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 18){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 19){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 20){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 21){
                displayItem1 = 6;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 22){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 5;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 23){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 24){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 25){
                displayItem1 = 7;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 26){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 6;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 27){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 28){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 29){
                displayItem1 = 8;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 30){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 7;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 31){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 8;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 32){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 8;
                displayItem4 = 8;
            }
            
            int rotateNumber = 0;
            int displayFlag = 0;
            int xStart = 0;
            int yStart = 0;
            int drawingStart = 0;
            int horizontalTime = 0;
            int lengthDivisionInt = 0;
            int numberOfDivision = 0;
            int verticalNo = 0;
            int lengthDivisionInt2 = 0;
            int numberOfDivision2 = 0;
            int lowestXPosition = 1000;
            int actualTime = 0;
            int timeEnd = 0;
            int colorCount = 0;
            int lineVertical = 0;
            int lineHorizontal = 0;
            int initialValue = 0;
            int rotateCount = 0;
            int roundCountTemp = 0;
            
            double lengthDivision = 0;
            double lengthPix = 0;
            double sift = 0;
            double lengthDivision2 = 0;
            double lengthPix2 = 0;
            double xPositionCenter = 0;
            double yPositionCenter = 0;
            double horizontalTimeHr = 0;
            
            string treatNameGR;
            string timeString;
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint pointA2;
            
            CGFloat size2 = 0;
            
            for (int counter1 = 0; counter1 < 4; counter1++){
                displayFlag = 0;
                
                if (counter1 == 0 && displayItem1 > 0){
                    rotateNumber = displayItem1;
                    displayFlag = 1;
                    xStart = 60;
                    yStart = 330;
                }
                else if (counter1 == 1 && displayItem2 > 0){
                    rotateNumber = displayItem2;
                    displayFlag = 1;
                    xStart = 410;
                    yStart = 330;
                }
                else if (counter1 == 2 && displayItem3 > 0){
                    rotateNumber = displayItem3;
                    displayFlag = 1;
                    xStart = 60;
                    yStart = 40;
                }
                else if (counter1 == 3 && displayItem4 > 0){
                    rotateNumber = displayItem4;
                    displayFlag = 1;
                    xStart = 410;
                    yStart = 40;
                }
                
                if (displayFlag == 1){
                    [[NSColor blackColor] set];
                    [NSBezierPath setDefaultLineWidth:1.5];
                    
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart, yStart, 340, 220)];
                    [path stroke];
                    
                    //----Horizontal Label----
                    horizontalTime = horizontalScaleHighHold-horizontalScaleLowHold;
                    timeString = "Time (hr)";
                    
                    NSString *timeNSstring = @(timeString.c_str());
                    
                    NSFont *font = [NSFont boldSystemFontOfSize:10];
                    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                    size2 = [attrStrS size].width;
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                    pointA.x = xStart+170-size2/(double)2;
                    pointA.y = yStart-25;
                    [attrStrA drawAtPoint:pointA];
                    
                    horizontalTimeHr = horizontalTime/(double)60;
                    
                    //----Horizontal Scale----
                    lengthDivision = horizontalTimeHr/(double)5;
                    lengthDivisionInt = 0;
                    
                    if (lengthDivision <= 25) lengthDivisionInt = 25;
                    else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                    else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                    else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                    else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                    else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                    else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                    else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                    else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                    else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                    else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
                    else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
                    else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
                    else if (lengthDivision > 5000) lengthDivisionInt = 1000;
                    
                    lengthPix = ((340-10)/(double)horizontalTimeHr)*lengthDivisionInt;
                    numberOfDivision = (int)((340-10)/(double)lengthPix)+1;
                    
                    int horizontalLowInt = (int)(horizontalScaleLowHold/(double)60);
                    
                    sift = 0;
                    
                    for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                        positionAA.x = xStart+lengthPix*counter2;
                        positionAA.y = yStart;
                        positionBB.x = xStart+lengthPix*counter2;
                        positionBB.y = yStart+5;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+horizontalLowInt).c_str());
                        NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                        NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                        size2 = [attrStrS2 size].width;
                        
                        if (counter2*lengthDivision == 0) sift = 0;
                        else if (counter2*lengthDivision < 1000) sift = 1;
                        
                        NSAttributedString *attrStrA2;
                        NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                        
                        [attributesA2 setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
                        [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        
                        attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                        pointA2.x = (xStart+lengthPix*counter2)-size2/(double)2-sift;
                        pointA2.y = yStart-15;
                        [attrStrA2 drawAtPoint:pointA2];
                    }
                    
                    //----Vertical Scale----
                    verticalNo = verticalScaleHighHold-verticalScaleLowHold;
                    lengthDivision2 = verticalNo/(double)5;
                    lengthDivisionInt2 = 0;
                    
                    if (lengthDivision2 <= 25) lengthDivisionInt2 = 25;
                    else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                    else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                    else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                    else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                    else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                    else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                    else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                    else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                    else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                    else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                    else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                    else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                    else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                    
                    lengthPix2 = ((220-10)/(double)verticalNo)*lengthDivisionInt2;
                    numberOfDivision2 = (int)((220-10)/(double)lengthPix2)+1;
                    
                    lowestXPosition = 1000;
                    
                    for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                        positionAA.x = xStart;
                        positionAA.y = yStart+lengthPix2*counter2;
                        positionBB.x = xStart+5;
                        positionBB.y = yStart+lengthPix2*counter2;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (counter1 == 0 || counter1 == 2){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2+verticalScaleLowHold).c_str());
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart-size2-10;
                            pointA2.y = yStart+lengthPix2*counter2-5;
                            [attrStrA2 drawAtPoint:pointA2];
                            
                            if (lowestXPosition > xStart-size2-10) lowestXPosition = (int)(xStart-size2-10);
                        }
                    }
                    
                    if (counter1 == 0 || counter1 == 2){
                        //----Vertical Label----
                        NSString *verticalNSstring = @"Number of Cells";
                        
                        NSFont *font2 = [NSFont boldSystemFontOfSize:10];
                        NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                        NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                        size2 = [attrStrS2 size].width;
                        
                        NSGraphicsContext *context = [NSGraphicsContext currentContext];
                        NSAffineTransform *transform = [NSAffineTransform transform];
                        [transform rotateByDegrees:+90];
                        
                        [context saveGraphicsState];
                        [transform concat];
                        
                        NSAttributedString *attrStrB;
                        NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                        NSString *titleStringB = @"Number of Cells";
                        
                        [attributesB setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                        
                        pointA.x = yStart+(110-size2/(double)2);
                        pointA.y = (lowestXPosition-5)*-1;
                        [attrStrB drawAtPoint:pointA];
                        
                        [context restoreGraphicsState];
                    }
                    
                    [NSBezierPath setDefaultLineWidth:1.0];
                    
                    int *cellNumberHold = new int [horizontalScaleMaxHold+50];
                    colorCount = 0;
                    lineVertical = yStart+220+30;
                    lineHorizontal = xStart;
                    rotateCount = 0;
                    
                    NSAttributedString *attrStrA3;
                    NSMutableDictionary *attributesA3 = [NSMutableDictionary dictionary];
                    [attributesA3 setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
                    [attributesA3 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    for (int counter2 = drawingStart; counter2 < entryNumberTempHoldCount; counter2++){
                        if (rotateNumber > rotateCount){
                            roundCountTemp = entryNumberTempHold [counter2];
                            rotateCount++;
                            
                            for (int counter3 = 0; counter3 < horizontalScaleMaxHold+50; counter3++){
                                cellNumberHold [counter3] = 0;
                            }
                            
                            timeEnd = arrayTableDetail [roundCountTemp][3];
                            
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [roundCountTemp]/9; counter3++){
                                actualTime = (arrayLineageData [roundCountTemp][counter3*9+2]-1)*atoi(arrayLineageDataType [roundCountTemp][5].c_str());
                                
                                if (arrayLineageData [roundCountTemp][counter3*9+2] <= timeEnd){
                                    if (oldNewData [counter2] == 0){
                                        cellNumberHold [actualTime]++;
                                    }
                                    else if (arrayLineageData [roundCountTemp][counter3*9+3] != 32 && arrayLineageData [roundCountTemp][counter3*9+3] != 42 && arrayLineageData [roundCountTemp][counter3*9+3] != 52){
                                        cellNumberHold [actualTime]++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 1; counterA <= horizontalScaleMaxHold; counterA++){
                            //    cout<<counterA<<" "<<cellNumberHold [counterA]<<" cellNo"<<endl;
                            //}
                            
                            if (normalizeStatusHold == 1){
                                initialValue = 0;
                                
                                for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                                    if (cellNumberHold [counter3] != 0){
                                        initialValue = cellNumberHold [counter3];
                                        break;
                                    }
                                }
                                
                                if (initialValue != 0 && initialValue > 1){
                                    for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                                        cellNumberHold [counter3] = (int)((cellNumberHold [counter3]/(double)initialValue)*100);
                                    }
                                }
                            }
                            
                            [NSBezierPath setDefaultLineWidth:2.0];
                            
                            if (colorCount == 0){
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 1){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(153/(double)255) blue:0 alpha:1] set];
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                colorCount++;
                                lineHorizontal = lineHorizontal+80;
                                lineVertical = yStart+220+30;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(153/(double)255) blue:0 alpha:1] set];
                            }
                            else if (colorCount == 2){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(255/(double)255) blue:0 alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(255/(double)255) blue:0 alpha:1] set];
                            }
                            else if (colorCount == 3){
                                [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(255/(double)255) blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                colorCount++;
                                lineHorizontal = lineHorizontal+80;
                                lineVertical = yStart+220+30;
                                
                                [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(255/(double)255) blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 4){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 5){
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                colorCount++;
                                lineHorizontal = lineHorizontal+80;
                                lineVertical = yStart+220+30;
                                
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1] set];
                            }
                            else if (colorCount == 6){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 7){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:0 alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15;
                                pointA2.y = lineVertical-6;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:0 alpha:1] set];
                            }
                            
                            [NSBezierPath setDefaultLineWidth:1.0];
                            
                            for (int counter3 = 1; counter3 <= horizontalScaleMaxHold; counter3++){
                                xPositionCenter = (340/(double)horizontalTime)*(counter3-horizontalScaleLowHold)+xStart;
                                yPositionCenter = (220/(double)verticalNo)*(cellNumberHold [counter3]-verticalScaleLowHold)+yStart;
                                
                                if (xPositionCenter > xStart && xPositionCenter < xStart+340 && yPositionCenter > yStart && yPositionCenter < yStart+220){
                                    path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                    [path stroke];
                                }
                            }
                        }
                        else{
                            
                            drawingStart = drawingStart+rotateCount;
                            
                            break;
                        }
                    }
                    
                    delete [] cellNumberHold;
                }
            }
            
            delete [] oldNewData;
            delete [] entryNumberTempHold;
        }
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:767*magFactor pixelsHigh:591*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:767*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767*magFactor, 591*magFactor)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        if (individualOverLayHold == 0){
            [[NSColor blackColor] set];
            [NSBezierPath setDefaultLineWidth:1.5*magFactor];
            
            path = [NSBezierPath bezierPathWithRect: NSMakeRect(80*magFactor, 100*magFactor, 650*magFactor, 300*magFactor)];
            [path stroke];
            
            //----Horizontal Label----
            int horizontalTime = horizontalScaleHighHold-horizontalScaleLowHold;
            string timeString = "Time (hr)";
            
            NSString *timeNSstring = @(timeString.c_str());
            
            NSFont *font = [NSFont boldSystemFontOfSize:11*magFactor];
            NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
            NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
            CGFloat size2 = [attrStrS size].width;
            
            [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
            [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
            pointA.x = 80*magFactor+325*magFactor-size2/(double)2;
            pointA.y = 100*magFactor-40*magFactor;
            [attrStrA drawAtPoint:pointA];
            
            double horizontalTimeHr = horizontalTime/(double)60;
            
            //----Horizontal Scale----
            double lengthDivision = horizontalTimeHr/(double)5;
            int lengthDivisionInt = 0;
            
            if (lengthDivision <= 25) lengthDivisionInt = 25;
            else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
            else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
            else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
            else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
            else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
            else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
            else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
            else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
            else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
            else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
            else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
            else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
            else if (lengthDivision > 5000) lengthDivisionInt = 1000;
            
            double lengthPix = ((650-10)/(double)horizontalTimeHr)*lengthDivisionInt;
            int numberOfDivision = (int)((650-10)/(double)lengthPix)+1;
            
            int horizontalLowInt = (int)(horizontalScaleLowHold/(double)60);
            
            double sift = 0;
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint pointA2;
            
            for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                positionAA.x = 80*magFactor+lengthPix*counter2*magFactor;
                positionAA.y = 100*magFactor;
                positionBB.x = 80*magFactor+lengthPix*counter2*magFactor;
                positionBB.y = 100*magFactor+5*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+horizontalLowInt).c_str());
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                if (counter2*lengthDivision == 0) sift = 0;
                else if (counter2*lengthDivision < 1000) sift = 1;
                
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                pointA2.x = (80*magFactor+lengthPix*counter2*magFactor)-size2/(double)2-sift*magFactor;
                pointA2.y = 100*magFactor-20*magFactor;
                [attrStrA2 drawAtPoint:pointA2];
            }
            
            //----Vertical Scale----
            int verticalNo = verticalScaleHighHold-verticalScaleLowHold;
            
            double lengthDivision2 = verticalNo/(double)5;
            int lengthDivisionInt2 = 0;
            
            if (lengthDivision2 <= 25) lengthDivisionInt2 = 25;
            else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
            else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
            else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
            else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
            else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
            else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
            else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
            else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
            else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
            else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
            else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
            else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
            else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
            
            double lengthPix2 = ((300-10)/(double)verticalNo)*lengthDivisionInt2;
            int numberOfDivision2 = (int)((300-10)/(double)lengthPix2)+1;
            
            int lowestXPosition = 1000;
            
            for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                positionAA.x = 80*magFactor;
                positionAA.y = 100*magFactor+lengthPix2*counter2*magFactor;
                positionBB.x = 80*magFactor+5*magFactor;
                positionBB.y = 100*magFactor+lengthPix2*counter2*magFactor;
                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                
                NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2+verticalScaleLowHold).c_str());
                NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                size2 = [attrStrS3 size].width;
                
                NSAttributedString *attrStrA2;
                NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                
                [attributesA2 setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                pointA2.x = 80*magFactor-size2-10*magFactor;
                pointA2.y = 100*magFactor+lengthPix2*counter2*magFactor-5*magFactor;
                [attrStrA2 drawAtPoint:pointA2];
                
                if (lowestXPosition > 80*magFactor-size2-10*magFactor) lowestXPosition = (int)(80*magFactor-size2-10*magFactor);
            }
            
            //----Vertical Label----
            NSString *verticalNSstring = @"Number of Cells";
            
            NSFont *font2 = [NSFont boldSystemFontOfSize:11*magFactor];
            NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
            NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
            size2 = [attrStrS2 size].width;
            
            NSGraphicsContext *context = [NSGraphicsContext currentContext];
            NSAffineTransform *transform = [NSAffineTransform transform];
            [transform rotateByDegrees:+90];
            
            [context saveGraphicsState];
            [transform concat];
            
            NSAttributedString *attrStrB;
            NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
            NSString *titleStringB = @"Number of Cells";
            
            [attributesB setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
            [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
            
            pointA.x = 100*magFactor+(150*magFactor-size2/(double)2);
            pointA.y = (lowestXPosition-10)*-1;
            [attrStrB drawAtPoint:pointA];
            
            [context restoreGraphicsState];
            
            [NSBezierPath setDefaultLineWidth:1.0*magFactor];
            
            int *cellNumberHold = new int [horizontalScaleMaxHold+50];
            int actualTime = 0;
            int timeEnd = 0;
            int colorCount = 0;
            int lineVertical = 540;
            int lineHorizontal = 80;
            int rgbA1 = 255;
            int rgbB1 = 0;
            int rgbA2 = 255;
            int rgbB2 = 153;
            int rgbA3 = 255;
            int rgbB3 = 255;
            int rgbA4 = 255;
            int rgbB4 = 255;
            int rgbA5 = 255;
            int rgbB5 = 255;
            int rgbA6 = 0;
            int rgbB6 = 0;
            int rgbA7 = 255;
            int rgbB7 = 255;
            int rgbA8 = 255;
            int rgbB8 = 0;
            int initialValue = 0;
            double xPositionCenter = 0;
            double yPositionCenter = 0;
            string treatNameGR;
            
            NSAttributedString *attrStrA3;
            NSMutableDictionary *attributesA3 = [NSMutableDictionary dictionary];
            [attributesA3 setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
            [attributesA3 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            
            int checkTime = 0;
            int checkTime2 = 0;
            int checkLing = 0;
            int checkCell = 0;
            
            int *oldNewData = new int [lineageDataEntryCount+1];
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount+1; counter2++){
                oldNewData [counter2] = 0;
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    checkTime = 0;
                    checkTime2 = 0;
                    checkLing = 0;
                    checkCell = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+3] == 32){
                            checkTime = arrayLineageData [counter2][counter3*9+2];
                            checkLing = arrayLineageData [counter2][counter3*9+6];
                            checkCell = arrayLineageData [counter2][counter3*9+5];
                            break;
                        }
                    }
                    
                    if (checkTime != 0){
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+3] == 31 && arrayLineageData [counter2][counter3*9+4] == checkCell && arrayLineageData [counter2][counter3*9+6] == checkLing){
                                checkTime2 = arrayLineageData [counter2][counter3*9+2];
                                break;
                            }
                        }
                        
                        if (checkTime == checkTime2){
                            oldNewData [counter2] = 1;
                        }
                    }
                }
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    for (int counter3 = 0; counter3 < horizontalScaleMaxHold+50; counter3++){
                        cellNumberHold [counter3] = 0;
                    }
                    
                    timeEnd = arrayTableDetail [counter2][3];
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        actualTime = (arrayLineageData [counter2][counter3*9+2]-1)*atoi(arrayLineageDataType [counter2][5].c_str());
                        
                        if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                            if (oldNewData [counter2] == 0){
                                cellNumberHold [actualTime]++;
                            }
                            else if (arrayLineageData [counter2][counter3*9+3] != 32 && arrayLineageData [counter2][counter3*9+3] != 42 && arrayLineageData [counter2][counter3*9+3] != 52){
                                cellNumberHold [actualTime]++;
                            }
                        }
                    }
                    
                    //for (int counterA = 1; counterA <= horizontalScaleMaxHold; counterA++){
                    //    cout<<counterA<<" "<<cellNumberHold [counterA]<<" cellNo"<<endl;
                    //}
                    
                    if (normalizeStatusHold == 1){
                        for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                            if (cellNumberHold [counter3] != 0){
                                initialValue = cellNumberHold [counter3];
                                break;
                            }
                        }
                        
                        if (initialValue != 0 && initialValue > 1){
                            for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                                cellNumberHold [counter3] = (int)((cellNumberHold [counter3]/(double)initialValue)*100);
                            }
                        }
                    }
                    
                    [NSBezierPath setDefaultLineWidth:2.0*magFactor];
                    
                    if (colorCount == 0){
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbB1/(double)255) blue:(CGFloat)(rgbA1/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical*magFactor;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical*magFactor-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical*magFactor-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbB1/(double)255) blue:(CGFloat)(rgbA1/(double)255) alpha:1] set];
                        
                        rgbA1 = rgbA1-50;
                        rgbB1 = rgbB1+50;
                    }
                    else if (colorCount == 1){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA2/(double)255) green:(CGFloat)(rgbB2/(double)255) blue:0 alpha:1] set];
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA2/(double)255) green:(CGFloat)(rgbB2/(double)255) blue:0 alpha:1] set];
                        
                        rgbA2 = rgbA2-50;
                        rgbB2 = rgbB2-20;
                    }
                    else if (colorCount == 2){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA3/(double)255) green:(CGFloat)(rgbB3/(double)255) blue:0 alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA3/(double)255) green:(CGFloat)(rgbB3/(double)255) blue:0 alpha:1] set];
                        
                        rgbA3 = rgbA3-50;
                        rgbB3 = rgbB3-20;
                    }
                    else if (colorCount == 3){
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbA4/(double)255) blue:(CGFloat)(rgbB4/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(rgbA4/(double)255) blue:(CGFloat)(rgbB4/(double)255) alpha:1] set];
                        
                        rgbA4 = rgbA4-50;
                        rgbB4 = rgbB4-50;
                    }
                    else if (colorCount == 4){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA5/(double)255) green:0 blue:(CGFloat)(rgbB5/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA5/(double)255) green:0 blue:(CGFloat)(rgbB5/(double)255) alpha:1] set];
                        
                        rgbA5 = rgbA5-50;
                        rgbB5 = rgbB5-50;
                    }
                    else if (colorCount == 5){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA6/(double)255) green:0 blue:(CGFloat)(rgbB6/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA6/(double)255) green:0 blue:(CGFloat)(rgbB6/(double)255) alpha:1] set];
                        
                        rgbA6 = rgbA6+50;
                        rgbB6 = rgbB6+50;
                    }
                    else if (colorCount == 6){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA7/(double)255) green:0 blue:(CGFloat)(rgbB7/(double)255) alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        lineVertical = lineVertical-17*magFactor;
                        
                        colorCount++;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA7/(double)255) green:0 blue:(CGFloat)(rgbB7/(double)255) alpha:1] set];
                        
                        rgbA7 = rgbA7-50;
                        rgbB7 = rgbB7-50;
                    }
                    else if (colorCount == 7){
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA8/(double)255) green:(CGFloat)(rgbB8/(double)255) blue:0 alpha:1] set];
                        
                        positionAA.x = lineHorizontal*magFactor;
                        positionAA.y = lineVertical;
                        positionBB.x = lineHorizontal*magFactor+20*magFactor;
                        positionBB.y = lineVertical;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4];
                        
                        if ((int) treatNameGR.length() > 17){
                            treatNameGR = treatNameGR.substr(0, 16)+"..";
                        }
                        
                        attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                        pointA2.x = lineHorizontal*magFactor+25*magFactor;
                        pointA2.y = lineVertical-6*magFactor;
                        [attrStrA3 drawAtPoint:pointA2];
                        
                        colorCount = 0;
                        lineVertical = 540;
                        lineHorizontal = lineHorizontal+160;
                        
                        [[NSColor colorWithCalibratedRed:(CGFloat)(rgbA8/(double)255) green:(CGFloat)(rgbB8/(double)255) blue:0 alpha:1] set];
                        
                        rgbA8 = rgbA8-50;
                        rgbB8 = rgbB8+50;
                    }
                    
                    [NSBezierPath setDefaultLineWidth:1.0];
                    
                    for (int counter3 = 1; counter3 <= horizontalScaleMaxHold; counter3++){
                        xPositionCenter = (640/(double)horizontalTime)*(counter3*magFactor-horizontalScaleLowHold*magFactor)+80*magFactor;
                        yPositionCenter = (290/(double)verticalNo)*(cellNumberHold [counter3]*magFactor-verticalScaleLowHold*magFactor)+100*magFactor;
                        
                        if (xPositionCenter > 80*magFactor && xPositionCenter < 80*magFactor+640*magFactor && yPositionCenter > 100*magFactor && yPositionCenter < 100*magFactor+290*magFactor){
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 2*magFactor, 2*magFactor)];
                            [path fill];
                        }
                    }
                }
            }
            
            delete [] cellNumberHold;
            delete [] oldNewData;
        }
        else if (individualOverLayHold == 1){
            int entryNumberCount = 0;
            int maxEntry = 0;
            
            int *entryNumberTempHold = new int [40];
            int entryNumberTempHoldCount = 0;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 32){
                    entryNumberCount++;
                    entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    
                    maxEntry++;
                }
            }
            
            int checkTime = 0;
            int checkTime2 = 0;
            int checkLing = 0;
            int checkCell = 0;
            int entryCount = 0;
            
            int *oldNewData = new int [40];
            
            for (int counter2 = 0; counter2 < 40; counter2++){
                oldNewData [counter2] = 0;
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && entryCount < 32){
                    checkTime = 0;
                    checkTime2 = 0;
                    checkLing = 0;
                    checkCell = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+3] == 32){
                            checkTime = arrayLineageData [counter2][counter3*9+2];
                            checkLing = arrayLineageData [counter2][counter3*9+6];
                            checkCell = arrayLineageData [counter2][counter3*9+5];
                            break;
                        }
                    }
                    
                    if (checkTime != 0){
                        for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                            if (arrayLineageData [counter2][counter3*9+3] == 31 && arrayLineageData [counter2][counter3*9+4] == checkCell && arrayLineageData [counter2][counter3*9+6] == checkLing){
                                checkTime2 = arrayLineageData [counter2][counter3*9+2];
                                break;
                            }
                        }
                        
                        if (checkTime == checkTime2){
                            oldNewData [entryCount] = 1;
                        }
                    }
                    
                    entryCount++;
                }
            }
            
            int displayItem1 = 0;
            int displayItem2 = 0;
            int displayItem3 = 0;
            int displayItem4 = 0;
            
            if (entryNumberCount == 1) displayItem1 = 1;
            else if (entryNumberCount == 2){
                displayItem1 = 1;
                displayItem2 = 1;
            }
            else if (entryNumberCount == 3){
                displayItem1 = 1;
                displayItem2 = 1;
                displayItem3 = 1;
            }
            else if (entryNumberCount == 4){
                displayItem1 = 1;
                displayItem2 = 1;
                displayItem3 = 1;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 5){
                displayItem1 = 2;
                displayItem2 = 1;
                displayItem3 = 1;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 6){
                displayItem1 = 2;
                displayItem2 = 2;
                displayItem3 = 1;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 7){
                displayItem1 = 2;
                displayItem2 = 2;
                displayItem3 = 2;
                displayItem4 = 1;
            }
            else if (entryNumberCount == 8){
                displayItem1 = 2;
                displayItem2 = 2;
                displayItem3 = 2;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 9){
                displayItem1 = 3;
                displayItem2 = 2;
                displayItem3 = 2;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 10){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 2;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 11){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
                displayItem4 = 2;
            }
            else if (entryNumberCount == 12){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 13){
                displayItem1 = 4;
                displayItem2 = 3;
                displayItem3 = 3;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 14){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 3;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 15){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 3;
            }
            else if (entryNumberCount == 16){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 17){
                displayItem1 = 5;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 18){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 19){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 20){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 21){
                displayItem1 = 6;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 22){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 5;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 23){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 5;
            }
            else if (entryNumberCount == 24){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 25){
                displayItem1 = 7;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 26){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 6;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 27){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 6;
            }
            else if (entryNumberCount == 28){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 29){
                displayItem1 = 8;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 30){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 7;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 31){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 8;
                displayItem4 = 7;
            }
            else if (entryNumberCount == 32){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 8;
                displayItem4 = 8;
            }
            
            int rotateNumber = 0;
            int displayFlag = 0;
            int xStart = 0;
            int yStart = 0;
            int drawingStart = 0;
            int horizontalTime = 0;
            int lengthDivisionInt = 0;
            int numberOfDivision = 0;
            int verticalNo = 0;
            int lengthDivisionInt2 = 0;
            int numberOfDivision2 = 0;
            int lowestXPosition = 1000;
            int actualTime = 0;
            int timeEnd = 0;
            int colorCount = 0;
            int lineVertical = 0;
            int lineHorizontal = 0;
            int initialValue = 0;
            int rotateCount = 0;
            int roundCountTemp = 0;
            
            double lengthDivision = 0;
            double lengthPix = 0;
            double sift = 0;
            double lengthDivision2 = 0;
            double lengthPix2 = 0;
            double xPositionCenter = 0;
            double yPositionCenter = 0;
            double horizontalTimeHr = 0;
            
            string treatNameGR;
            string timeString;
            
            NSPoint positionAA;
            NSPoint positionBB;
            NSPoint pointA2;
            
            CGFloat size2 = 0;
            
            for (int counter1 = 0; counter1 < 4; counter1++){
                displayFlag = 0;
                
                if (counter1 == 0 && displayItem1 > 0){
                    rotateNumber = displayItem1;
                    displayFlag = 1;
                    xStart = 60;
                    yStart = 330;
                }
                else if (counter1 == 1 && displayItem2 > 0){
                    rotateNumber = displayItem2;
                    displayFlag = 1;
                    xStart = 410;
                    yStart = 330;
                }
                else if (counter1 == 2 && displayItem3 > 0){
                    rotateNumber = displayItem3;
                    displayFlag = 1;
                    xStart = 60;
                    yStart = 40;
                }
                else if (counter1 == 3 && displayItem4 > 0){
                    rotateNumber = displayItem4;
                    displayFlag = 1;
                    xStart = 410;
                    yStart = 40;
                }
                
                if (displayFlag == 1){
                    [[NSColor blackColor] set];
                    [NSBezierPath setDefaultLineWidth:1.5*magFactor];
                    
                    path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor, yStart*magFactor, 340*magFactor, 220*magFactor)];
                    [path stroke];
                    
                    //----Horizontal Label----
                    horizontalTime = horizontalScaleHighHold-horizontalScaleLowHold;
                    timeString = "Time (hr)";
                    
                    NSString *timeNSstring = @(timeString.c_str());
                    
                    NSFont *font = [NSFont boldSystemFontOfSize:10*magFactor];
                    NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                    size2 = [attrStrS size].width;
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:10*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                    pointA.x = xStart*magFactor+170*magFactor-size2/(double)2;
                    pointA.y = yStart*magFactor-25*magFactor;
                    [attrStrA drawAtPoint:pointA];
                    
                    horizontalTimeHr = horizontalTime/(double)60;
                    
                    //----Horizontal Scale----
                    lengthDivision = horizontalTimeHr/(double)5;
                    lengthDivisionInt = 0;
                    
                    if (lengthDivision <= 25) lengthDivisionInt = 25;
                    else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                    else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                    else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                    else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                    else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                    else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                    else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                    else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                    else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                    else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
                    else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
                    else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
                    else if (lengthDivision > 5000) lengthDivisionInt = 1000;
                    
                    lengthPix = ((340-10)/(double)horizontalTimeHr)*lengthDivisionInt;
                    numberOfDivision = (int)((340-10)/(double)lengthPix)+1;
                    
                    int horizontalLowInt = (int)(horizontalScaleLowHold/(double)60);
                    
                    sift = 0;
                    
                    for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                        positionAA.x = xStart*magFactor+lengthPix*counter2*magFactor;
                        positionAA.y = yStart*magFactor;
                        positionBB.x = xStart*magFactor+lengthPix*counter2*magFactor;
                        positionBB.y = yStart*magFactor+5*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+horizontalLowInt).c_str());
                        NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                        NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                        size2 = [attrStrS2 size].width;
                        
                        if (counter2*lengthDivision == 0) sift = 0;
                        else if (counter2*lengthDivision < 1000) sift = 1;
                        
                        NSAttributedString *attrStrA2;
                        NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                        
                        [attributesA2 setObject:[NSFont boldSystemFontOfSize:10*magFactor] forKey:NSFontAttributeName];
                        [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        
                        attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                        pointA2.x = (xStart*magFactor+lengthPix*counter2*magFactor)-size2/(double)2-sift*magFactor;
                        pointA2.y = yStart*magFactor-15*magFactor;
                        [attrStrA2 drawAtPoint:pointA2];
                    }
                    
                    //----Vertical Scale----
                    verticalNo = verticalScaleHighHold-verticalScaleLowHold;
                    lengthDivision2 = verticalNo/(double)5;
                    lengthDivisionInt2 = 0;
                    
                    if (lengthDivision2 <= 25) lengthDivisionInt2 = 25;
                    else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                    else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                    else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                    else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                    else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                    else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                    else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                    else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                    else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                    else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                    else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                    else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                    else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                    
                    lengthPix2 = ((220-10)/(double)verticalNo)*lengthDivisionInt2;
                    numberOfDivision2 = (int)((220-10)/(double)lengthPix2)+1;
                    
                    lowestXPosition = 1000;
                    
                    for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                        positionAA.x = xStart*magFactor;
                        positionAA.y = yStart*magFactor+lengthPix2*counter2*magFactor;
                        positionBB.x = xStart*magFactor+5*magFactor;
                        positionBB.y = yStart*magFactor+lengthPix2*counter2*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (counter1 == 0 || counter1 == 2){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2+verticalScaleLowHold).c_str());
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:10*magFactor] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart*magFactor-size2-10*magFactor;
                            pointA2.y = yStart*magFactor+lengthPix2*counter2*magFactor-5*magFactor;
                            [attrStrA2 drawAtPoint:pointA2];
                            
                            if (lowestXPosition > xStart*magFactor-size2-10*magFactor) lowestXPosition = (int)(xStart*magFactor-size2-10*magFactor);
                        }
                    }
                    
                    if (counter1 == 0 || counter1 == 2){
                        //----Vertical Label----
                        NSString *verticalNSstring = @"Number of Cells";
                        
                        NSFont *font2 = [NSFont boldSystemFontOfSize:10*magFactor];
                        NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                        NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                        size2 = [attrStrS2 size].width;
                        
                        NSGraphicsContext *context = [NSGraphicsContext currentContext];
                        NSAffineTransform *transform = [NSAffineTransform transform];
                        [transform rotateByDegrees:+90];
                        
                        [context saveGraphicsState];
                        [transform concat];
                        
                        NSAttributedString *attrStrB;
                        NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                        NSString *titleStringB = @"Number of Cells";
                        
                        [attributesB setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                        [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                        
                        pointA.x = yStart*magFactor+(110*magFactor-size2/(double)2);
                        pointA.y = (lowestXPosition-5)*-1;
                        [attrStrB drawAtPoint:pointA];
                        
                        [context restoreGraphicsState];
                    }
                    
                    [NSBezierPath setDefaultLineWidth:1.0];
                    
                    int *cellNumberHold = new int [horizontalScaleMaxHold+50];
                    colorCount = 0;
                    lineVertical = yStart*magFactor+220*magFactor+30*magFactor;
                    lineHorizontal = xStart*magFactor;
                    rotateCount = 0;
                    
                    NSAttributedString *attrStrA3;
                    NSMutableDictionary *attributesA3 = [NSMutableDictionary dictionary];
                    [attributesA3 setObject:[NSFont boldSystemFontOfSize:10*magFactor] forKey:NSFontAttributeName];
                    [attributesA3 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    for (int counter2 = drawingStart; counter2 < entryNumberTempHoldCount; counter2++){
                        if (rotateNumber > rotateCount){
                            roundCountTemp = entryNumberTempHold [counter2];
                            rotateCount++;
                            
                            for (int counter3 = 0; counter3 < horizontalScaleMaxHold+50; counter3++){
                                cellNumberHold [counter3] = 0;
                            }
                            
                            timeEnd = arrayTableDetail [roundCountTemp][3];
                            
                            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [roundCountTemp]/9; counter3++){
                                actualTime = (arrayLineageData [roundCountTemp][counter3*9+2]-1)*atoi(arrayLineageDataType [roundCountTemp][5].c_str());
                                
                                if (arrayLineageData [roundCountTemp][counter3*9+2] <= timeEnd){
                                    if (oldNewData [counter2] == 0){
                                        cellNumberHold [actualTime]++;
                                    }
                                    else if (arrayLineageData [roundCountTemp][counter3*9+3] != 32 && arrayLineageData [roundCountTemp][counter3*9+3] != 42 && arrayLineageData [roundCountTemp][counter3*9+3] != 52){
                                        cellNumberHold [actualTime]++;
                                    }
                                }
                            }
                            
                            //for (int counterA = 1; counterA <= horizontalScaleMaxHold; counterA++){
                            //    cout<<counterA<<" "<<cellNumberHold [counterA]<<" cellNo"<<endl;
                            //}
                            
                            if (normalizeStatusHold == 1){
                                initialValue = 0;
                                
                                for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                                    if (cellNumberHold [counter3] != 0){
                                        initialValue = cellNumberHold [counter3];
                                        break;
                                    }
                                }
                                
                                if (initialValue != 0 && initialValue > 1){
                                    for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                                        cellNumberHold [counter3] = (int)((cellNumberHold [counter3]/(double)initialValue)*100);
                                    }
                                }
                            }
                            
                            [NSBezierPath setDefaultLineWidth:2.0*magFactor];
                            
                            if (colorCount == 0){
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17*magFactor;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 1){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(153/(double)255) blue:0 alpha:1] set];
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                colorCount++;
                                lineHorizontal = lineHorizontal+80*magFactor;
                                lineVertical = yStart*magFactor+220*magFactor+30*magFactor;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(153/(double)255) blue:0 alpha:1] set];
                            }
                            else if (colorCount == 2){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(255/(double)255) blue:0 alpha:1] set];
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17*magFactor;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:(CGFloat)(255/(double)255) blue:0 alpha:1] set];
                            }
                            else if (colorCount == 3){
                                [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(255/(double)255) blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                colorCount++;
                                lineHorizontal = lineHorizontal+80*magFactor;
                                lineVertical = yStart*magFactor+220*magFactor+30*magFactor;
                                
                                [[NSColor colorWithCalibratedRed:0 green:(CGFloat)(255/(double)255) blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 4){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17*magFactor;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 5){
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                colorCount++;
                                lineHorizontal = lineHorizontal+80*magFactor;
                                lineVertical = yStart*magFactor+220*magFactor+30*magFactor;
                                
                                [[NSColor colorWithCalibratedRed:0 green:0 blue:0 alpha:1] set];
                            }
                            else if (colorCount == 6){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                                
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17*magFactor;
                                
                                colorCount++;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:(CGFloat)(255/(double)255) alpha:1] set];
                            }
                            else if (colorCount == 7){
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:0 alpha:1] set];
                                positionAA.x = lineHorizontal;
                                positionAA.y = lineVertical;
                                positionBB.x = lineHorizontal+10*magFactor;
                                positionBB.y = lineVertical;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                
                                treatNameGR = arrayTableMain [counter2][0]+": "+arrayTableMain [counter2][4].substr(arrayTableMain [counter2][4].find("-")+1);
                                
                                if ((int) treatNameGR.length() > 10){
                                    treatNameGR = treatNameGR.substr(0, 9)+"..";
                                }
                                
                                attrStrA3 = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA3];
                                pointA2.x = lineHorizontal+15*magFactor;
                                pointA2.y = lineVertical-6*magFactor;
                                [attrStrA3 drawAtPoint:pointA2];
                                
                                lineVertical = lineVertical-17*magFactor;
                                
                                [[NSColor colorWithCalibratedRed:(CGFloat)(255/(double)255) green:0 blue:0 alpha:1] set];
                            }
                            
                            [NSBezierPath setDefaultLineWidth:1.0*magFactor];
                            
                            for (int counter3 = 1; counter3 <= horizontalScaleMaxHold; counter3++){
                                xPositionCenter = (340/(double)horizontalTime)*(counter3*magFactor-horizontalScaleLowHold*magFactor)+xStart*magFactor;
                                yPositionCenter = (220/(double)verticalNo)*(cellNumberHold [counter3]*magFactor-verticalScaleLowHold*magFactor)+yStart*magFactor;
                                
                                if (xPositionCenter > xStart*magFactor && xPositionCenter < xStart*magFactor+340*magFactor && yPositionCenter > yStart*magFactor && yPositionCenter < yStart*magFactor+220*magFactor){
                                    path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 2*magFactor, 2*magFactor)];
                                    [path fill];
                                }
                            }
                        }
                        else{
                            
                            drawingStart = drawingStart+rotateCount;
                            
                            break;
                        }
                    }
                    
                    delete [] cellNumberHold;
                }
            }
            
            delete [] oldNewData;
            delete [] entryNumberTempHold;
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        exportFlag5 = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToGrowthCurveDisplay object:nil];
}

@end
