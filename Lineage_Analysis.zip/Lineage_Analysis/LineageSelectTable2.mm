//
//  LineageSelectTable2.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#import "LineageSelectTable2.h"

NSString *notificationToLineageSelectTable2 = @"notificationExecuteLineageSelectTable2";

@implementation LineageSelectTable2

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageSelectTable2 object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [lineageSelectTable2 setDataSource:self];
    [lineageSelectTable2 reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    //--Ling No--
    //--Mark: 0, not exist: 1, non selected,: 2, selected
    
    int tableViewContent = lineageSelectLineageHoldCount/2;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        int dataType = 0;
        string displayData1;
        
        if (arrayLineageSelectLineageHold [rowIndex*2+1] == 0){
            displayData1 = "L----";
            dataType = 0;
        }
        else if (arrayLineageSelectLineageHold [rowIndex*2+1] == 1){
            displayData1 = to_string(arrayLineageSelectLineageHold [rowIndex*2]);
            
            if (displayData1.length() == 1) displayData1 = "L0000"+displayData1;
            else if (displayData1.length() == 2) displayData1 = "L000"+displayData1;
            else if (displayData1.length() == 3) displayData1 = "L00"+displayData1;
            else if (displayData1.length() == 4) displayData1 = "L0"+displayData1;
            else if (displayData1.length() == 5) displayData1 = "L"+displayData1;
            
            dataType = 1;
        }
        else if (arrayLineageSelectLineageHold [rowIndex*2+1] == 2){
            displayData1 = "";
            dataType = 2;
        }
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"] && dataType == 0){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && dataType == 1){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL1"] && dataType == 2){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    lineageSelectNonSelOperationTableCount++;
    lineageSelectNonOperationTableCurrentRow = rowIndex;
    
    if (lineageSelectNonSelOperationTableCount == 2){
        if (upLoadingProgress == 0){
            lineageSelectNonOperationTableCurrentRow = rowLineageSelectNonOperationTable;
            
            if (fusionMoveStatus == 1){
                if (arrayLineageSelectLineageHold [lineageSelectNonOperationTableCurrentRow*2+1] == 1) arrayLineageSelectLineageHold [lineageSelectNonOperationTableCurrentRow*2+1] = 2;
            }
            else{
                
                unsigned long lineageEntrySize = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow];
                int lineageEntryNo = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6];
                    }
                }
                
                int lineageSelectedNo = arrayLineageSelectLineageHold [lineageSelectNonOperationTableCurrentRow*2];
                int lineageLinkListLengthNonSel = arrayLineageLink [lineageSelectOperationTableCurrentRow][0];
                
                int *fuseLingList = new int [lineageLinkListLengthNonSel+1];
                int fuseLingListCount = 0;
                
                int breakFlag = 0;
                
                for (int counter1 = 1; counter1 <= lineageEntryNo; counter1++){
                    if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength] != -1){
                        for (int counter2 = 0; counter2 < lineageLinkListLengthNonSel; counter2++){
                            if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter2] == lineageSelectedNo){
                                for (int counter3 = 0; counter3 < lineageLinkListLengthNonSel; counter3++){
                                    if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter3] != 0){
                                        fuseLingList [fuseLingListCount] = arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter3], fuseLingListCount++;
                                    }
                                }
                                
                                breakFlag = 1;
                                break;
                            }
                        }
                        
                        if (breakFlag == 1){
                            break;
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < fuseLingListCount; counter1++){
                    if (arrayLineageSelectLineageHold [(fuseLingList [counter1]-1)*2+1] == 1) arrayLineageSelectLineageHold [(fuseLingList [counter1]-1)*2+1] = 2;
                }
                
                delete [] fuseLingList;
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            lineageSelectNonOperationTableCurrentRow = rowIndex;
            
            if (fusionMoveStatus == 1){
                if (arrayLineageSelectLineageHold [lineageSelectNonOperationTableCurrentRow*2+1] == 1) arrayLineageSelectLineageHold [lineageSelectNonOperationTableCurrentRow*2+1] = 2;
            }
            else{
                
                unsigned long lineageEntrySize = arrayLineageDataEntryHold [lineageSelectOperationTableCurrentRow];
                
                int lineageEntryNo = 0;
                
                for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                    if (arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6] > lineageEntryNo){
                        lineageEntryNo = arrayLineageData [lineageSelectOperationTableCurrentRow][counter3*9+6];
                    }
                }
                
                int lineageSelectedNo = arrayLineageSelectLineageHold [lineageSelectNonOperationTableCurrentRow*2];
                int lineageLinkListLengthNonSel = arrayLineageLink [lineageSelectOperationTableCurrentRow][0];
                
                int *fuseLingList = new int [lineageLinkListLengthNonSel+1];
                int fuseLingListCount = 0;
                
                int breakFlag = 0;
                
                for (int counter1 = 1; counter1 <= lineageEntryNo; counter1++){
                    if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength] != -1){
                        for (int counter2 = 0; counter2 < lineageLinkListLengthNonSel; counter2++){
                            if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter2] == lineageSelectedNo){
                                for (int counter3 = 0; counter3 < lineageLinkListLengthNonSel; counter3++){
                                    if (arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter3] != 0){
                                        fuseLingList [fuseLingListCount] = arrayLineageLink [lineageSelectOperationTableCurrentRow][counter1*lineageLinkListLength+counter3], fuseLingListCount++;
                                    }
                                }
                                
                                breakFlag = 1;
                                break;
                            }
                        }
                        
                        if (breakFlag == 1){
                            break;
                        }
                    }
                }
                
                for (int counter1 = 0; counter1 < fuseLingListCount; counter1++){
                    if (arrayLineageSelectLineageHold [(fuseLingList [counter1]-1)*2+1] == 1) arrayLineageSelectLineageHold [(fuseLingList [counter1]-1)*2+1] = 2;
                }
                
                //for (int counterA = 0; counterA < fuseLingListCount; counterA++) cout<<fuseLingList [counterA]<<" fuse"<<endl;
                
                //for (int counterA = 0; counterA <= lineageEntryNo; counterA++){
                //    for (int counterB = 0; counterB < lineageLinkListLengthNonSel; counterB++) cout<<" "<<arrayLineageLink [lineageSelectOperationTableCurrentRow][counterA*lineageLinkListLength+counterB];
                //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                //}
                
                delete [] fuseLingList;
            }
            
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable2 object:self];
            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToLineageSelectTable3 object:self];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageSelectTable2 object:nil];
}

@end
