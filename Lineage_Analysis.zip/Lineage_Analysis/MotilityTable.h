//
//  MotilityTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#ifndef MOTILITYTABLE_H
#define MOTILITYTABLE_H
#import "Controller.h" 
#endif

@interface MotilityTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *motilityTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
