//
//  SearchController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/9/16.
//
//

#ifndef SEARCHCONTROLLER_H
#define SEARCHCONTROLLER_H
#import "Controller.h" 
#endif

@interface SearchController : NSObject{
    int lingSearchPosition; //Search position
    int logicStatus1; //Logic status
    int logicStatus2; //Logic status
    int logicStatus3; //Logic status
    
    IBOutlet NSTextField *eventSL1;
    IBOutlet NSTextField *eventSL2;
    IBOutlet NSTextField *eventSL3;
    IBOutlet NSTextField *eventSL4;
    IBOutlet NSTextField *logicSL1;
    IBOutlet NSTextField *logicSL2;
    IBOutlet NSTextField *logicSL3;
    IBOutlet NSTextField *typeSL;
    IBOutlet NSTextField *seriesSL;
    IBOutlet NSTextField *analysisSL;
    IBOutlet NSTextField *treatSL;
    
    IBOutlet NSWindow *searchWindow;
    
    NSWindowController *searchWindowController;
    
    NSTimer *searchTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)lineageFluorescentDataTypeUpDate;

-(IBAction)closeWindow:(id)sender;
-(IBAction)searchSave:(id)sender;
-(IBAction)setClear:(id)sender;

-(IBAction)logicSet1:(id)sender;
-(IBAction)logicSet2:(id)sender;
-(IBAction)logicSet3:(id)sender;
-(IBAction)clear1:(id)sender;
-(IBAction)clear2:(id)sender;
-(IBAction)clear3:(id)sender;
-(IBAction)clear4:(id)sender;
-(IBAction)search:(id)sender;
-(IBAction)setIN:(id)sender;
-(IBAction)setDD:(id)sender;
-(IBAction)setTD:(id)sender;
-(IBAction)setHD:(id)sender;
-(IBAction)setOF:(id)sender;
-(IBAction)setCD:(id)sender;
-(IBAction)setIP:(id)sender;
-(IBAction)setMI:(id)sender;
-(IBAction)setCF:(id)sender;
-(IBAction)setFM:(id)sender;

@end
