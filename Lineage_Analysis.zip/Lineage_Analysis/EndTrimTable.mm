//
//  EndTrimTable.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-31.
//
//

#import "EndTrimTable.h"

NSString *notificationToTrimTable = @"notificationExecuteTrimTable";

@implementation EndTrimTable

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTrimTable object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [endTrimTable setDataSource:self];
    [endTrimTable reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = trimResultsHoldCount/6;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1;
        string displayData2;
        string displayData3;
        string displayData4;
        string displayData5;
        string displayData6;
        
        if (arrayTrimResultsHold [rowIndex*6] == "-1") displayData1 = "";
        else displayData1 = arrayTrimResultsHold [rowIndex*6];
        
        if (arrayTrimResultsHold [rowIndex*6+1] == "-1") displayData2 = "";
        else displayData2 = arrayTrimResultsHold [rowIndex*6+1];
        
        if (arrayTrimResultsHold [rowIndex*6+2] == "-1") displayData3 = "";
        else displayData3 = arrayTrimResultsHold [rowIndex*6+2];
        
        if (arrayTrimResultsHold [rowIndex*6+3] == "-1") displayData4 = "";
        else displayData4 = arrayTrimResultsHold [rowIndex*6+3];
        
        if (arrayTrimResultsHold [rowIndex*6+4] == "-1") displayData5 = "";
        else displayData5 = arrayTrimResultsHold [rowIndex*6+4];
        
        if (arrayTrimResultsHold [rowIndex*6+5] == "-1") displayData6 = "";
        else displayData6 = arrayTrimResultsHold [rowIndex*6+5];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    trimOperationTableCount++;
    trimOperationTableCurrentRow = rowIndex;
    
    if (trimOperationTableCount == 2){
        if (upLoadingProgress == 0){
            trimOperationTableCurrentRow = rowTrimOperationTable;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            trimOperationTableCurrentRow = rowIndex;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTrimTable object:nil];
}

@end
