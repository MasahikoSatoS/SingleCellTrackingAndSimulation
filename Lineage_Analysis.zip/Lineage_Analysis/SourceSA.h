//
//  SourceSA.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/21/16.
//
//

#ifndef SOURCESA_H
#define SOURCESA_H
#import "Controller.h"
#endif

@interface SourceSA : NSObject{
}

-(void)sourceMain;
-(void)lineageFluorescentDataTypeUpDate;
-(void)fileDeleteUpDate;

@end
