//
//  DoubCompTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-01-30.
//
//

#ifndef DOUBCOMPTABLE_H
#define DOUBCOMPTABLE_H
#import "Controller.h" 
#endif

@interface DoubCompTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *doubCompTable;
    
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
