//
//  SimulationPerform.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-11-24.
//

#ifndef SIMULATIONPERFORM_H
#define SIMULATIONPERFORM_H
#import "Controller.h" 
#endif

@interface SimulationPerform : NSObject{
    int *expandFirstDVList; //First DV
    int expandFirstDVListCount;
    int *expandDoubLingDoubBD; //Expand doubling BD
    int expandDoubLingDoubBDCount;
    int *expandDoubLingDoubTD; //Expand doubling TD
    int expandDoubLingDoubTDCount;
    int *expandDoubLingDoubCF; //Expand CF
    int expandDoubLingDoubCFCount;
    
    int *expandBDCD; //Expand BDCD
    int expandBDCDCount;
    int *expandBDCF; //Expand BDCF
    int expandBDCFCount;
    int *expandNonCD; //Expand nonCD
    int expandNonCDCount;
    int *expandBDCFCD; //Expand BDCFCD
    int expandBDCFCDCount;
    
    int *expandTDCF; //Expand TDCF
    int expandTDCFCount;
    int *expandTDCFCD; //Expand TDCFCD
    int expandTDCFCDCount;
    int *expandTDCD; //Expand TDCD
    int expandTDCDCount;
    
    int *firstEventList; //First event
    int *secondEventBDList; //Second event BD
    int *secondEventBDCFList; //Second event BDCF
    int *secondEventTDList; //Second event TD
    int *secondEventTDCFList; //Second event TDCF
    
    int randBDRangeA; //Rand BD
    int randBDRangeB; //Rand BD
    int randCDRangeA; //Rand CD
    int randCDRangeB; //Rand CD
    
    int totalNoOfNonDivCD; //Total no of non div CD
    
    int *expandFirstDVListSel; //First DV selected
    int expandFirstDVListSelCount;
    int *expandDoubLingDoubBDSel; //Expand doubling BD selected
    int expandDoubLingDoubBDSelCount;
    int *expandDoubLingDoubTDSel; //Expand doubling TD selected
    int expandDoubLingDoubTDSelCount;
    int *expandDoubLingDoubCFSel; //Expand CF selected
    int expandDoubLingDoubCFSelCount;
    
    int *expandBDCDSel; //Expand BDCD selected
    int expandBDCDSelCount;
    int *expandBDCFSel; //Expand BDCF selected
    int expandBDCFSelCount;
    int *expandNonCDSel; //Expand nonCD selected
    int expandNonCDSelCount;
    int *expandBDCFCDSel; //Expand BDCFCD selected
    int expandBDCFCDSelCount;
    
    int *expandTDCFSel; //Expand TDCF selected
    int expandTDCFSelCount;
    int *expandTDCFCDSel; //Expand TDCFCD selected
    int expandTDCFCDSelCount;
    int *expandTDCDSel; //Expand TDCD selected
    int expandTDCDSelCount;
    
    int *firstEventListSel; //First event selected
    int *secondEventBDListSel; //Second event BD selected
    int *secondEventBDCFListSel; //Second event BDCF selected
    int *secondEventTDListSel; //Second event TD selected
    int *secondEventTDCFListSel; //Second event TDCF selected
    
    int randBDRangeSelA; //Rand BD selected
    int randBDRangeSelB; //Rand BD selected
    int randCDRangeSelA; //Rand CD selected
    int randCDRangeSelB; //Rand CD selected
    
    int totalNoOfNonDivCDSel; //Total no of non div CD selected
    int selArraySet; //Array set for selected
    
    id performMid;
    id performProg;
    id createNewCellNo;
}

-(IBAction)growthPerformSet:(id)sender;
-(void)arraysRedetermine;
-(void)secondArraySet;

@end
