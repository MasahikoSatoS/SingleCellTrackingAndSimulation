//
//  DoublingTimeController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/16/16.
//
//

#ifndef DOUBLINGTIMECONTROLLER_H
#define DOUBLINGTIMECONTROLLER_H
#import "Controller.h" 
#endif

@interface DoublingTimeController : NSObject <NSTextFieldDelegate>{
    int pointConvert; //Point convert
    int minConvert; //Min convert
    int everyConvert; //Every convert
    double hrConvert; //HR convert
    
    IBOutlet NSTextField *horizontalLow;
    IBOutlet NSTextField *horizontalHigh;
    IBOutlet NSTextField *rangeDoubleStDisplay1;
    IBOutlet NSTextField *rangeDoubleStDisplay2;
    IBOutlet NSTextField *rangeDoubleStDisplay3;
    IBOutlet NSTextField *rangeDoubleStDisplay4;
    IBOutlet NSTextField *rangeDoubleEdDisplay1;
    IBOutlet NSTextField *rangeDoubleEdDisplay2;
    IBOutlet NSTextField *rangeDoubleEdDisplay3;
    IBOutlet NSTextField *rangeDoubleEdDisplay4;
    IBOutlet NSTextField *pointConvertDisplay;
    IBOutlet NSTextField *minConvertDisplay;
    IBOutlet NSTextField *hrConvertDisplay;
    IBOutlet NSTextField *everyConvertDisplay;
    IBOutlet NSTextField *verticalHigh;
    
    IBOutlet NSWindow *doublingTimeWindow;
    
    NSTimer *doublingTimeTimer;
    
    NSWindowController *doublingTimeWindowController;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFileStatistics:(id)sender;
-(IBAction)createExcelFileDoubleAtATime:(id)sender;
-(IBAction)closeWindow:(id)sender;
-(IBAction)rangeClearSet:(id)sender;

@end
