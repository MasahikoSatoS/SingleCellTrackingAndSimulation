//
//  DetailTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 8/31/16.
//
//

#ifndef DETAILTABLE_H
#define DETAILTABLE_H
#import "Controller.h"
#endif

@interface DetailTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *detailViewList;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
