//
//  SimulationDisplay.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-10-29.
//

#ifndef SIMULATIONDIAPLAY_H
#define SIMULATIONDIAPLAY_H
#import "Controller.h" 
#endif

@interface SimulationDisplay : NSView{
    IBOutlet NSWindow *simulationWindow;
    
    NSTimer *simDisplayTimer;
}

-(void)mouseDown:(NSEvent *)event;
-(void)display;
-(void)keyDown:(NSEvent *)event;

-(void)dealloc;
-(BOOL)acceptsFirstResponder;

@end
