//
//  CellDivisionController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/15/16.
//
//

#import "CellDivisionController.h"

NSString *notificationToCellDivisionController = @"notificationExecuteCellDivisionController";

@implementation CellDivisionController

-(id)init{
    self = [super init];
    
    if (self != nil){
        everyConvert = 10;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCellDivisionController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    cellDivisionWindowController = [[NSWindowController alloc] initWithWindowNibName:@"CellDivision"];
    [cellDivisionWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToCellDivisionDisplay object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [cellDivisionWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [cellDivisionWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [verticalHigh setDelegate:self];
    [verticalDownHigh setDelegate:self];
    [horizontalLow setDelegate:self];
    [horizontalHigh setDelegate:self];
    [pointConvertDisplay setDelegate:self];
    [minConvertDisplay setDelegate:self];
    [hrConvertDisplay setDelegate:self];
    [everyConvertDisplay setDelegate:self];
    
    [verticalHigh setIntegerValue:verticalScaleHighUpDivisionHold];
    [verticalDownHigh setIntegerValue:verticalScaleHighDownDivisionHold];
    [horizontalLow setIntegerValue:horizontalScaleLowDivisionHold];
    [horizontalHigh setIntegerValue:horizontalScaleHighDivisionHold];
    [pointConvertDisplay setIntegerValue:0];
    [minConvertDisplay setIntegerValue:0];
    [hrConvertDisplay setIntegerValue:0];
    [everyConvertDisplay setIntegerValue:10];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == verticalHigh){
            if ([verticalHigh intValue] > 0 && [verticalHigh intValue] <= verticalScaleMaxUpDivisionHold){
                verticalScaleHighUpDivisionHold = [verticalHigh intValue];
                [verticalHigh setIntegerValue:verticalScaleHighUpDivisionHold];
            }
            else{
                
                verticalScaleHighUpDivisionHold = verticalScaleMaxUpDivisionHold;
                [verticalHigh setIntegerValue:verticalScaleHighUpDivisionHold];
            }
        }
        
        if ([aNotification object] == verticalDownHigh){
            if ([verticalDownHigh intValue] > 0 && [verticalDownHigh intValue] <= verticalScaleMaxDownDivisionHold){
                verticalScaleHighDownDivisionHold = [verticalDownHigh intValue];
                [verticalDownHigh setIntegerValue:verticalScaleHighDownDivisionHold];
            }
            else{
                
                verticalScaleHighDownDivisionHold = verticalScaleMaxDownDivisionHold;
                [verticalDownHigh setIntegerValue:verticalScaleHighDownDivisionHold];
            }
        }
        
        if ([aNotification object] == horizontalLow){
            if ([horizontalLow intValue] >= 0 && [horizontalLow intValue] < horizontalScaleHighDivisionHold){
                horizontalScaleLowDivisionHold = [horizontalLow intValue];
                [horizontalLow setIntegerValue:horizontalScaleLowDivisionHold];
            }
        }
        
        if ([aNotification object] == horizontalHigh){
            if ([horizontalHigh intValue] >= 0 && [horizontalHigh intValue] <= horizontalScaleMaxDivisionHold){
                horizontalScaleHighDivisionHold = [horizontalHigh intValue];
                [horizontalHigh setIntegerValue:horizontalScaleHighDivisionHold];
            }
            else{
                
                horizontalScaleHighDivisionHold = horizontalScaleMaxDivisionHold;
                [horizontalHigh setIntegerValue:horizontalScaleHighDivisionHold];
            }
        }
        
        if ([aNotification object] == everyConvertDisplay){
            if ([everyConvertDisplay intValue] > 0 && [everyConvertDisplay intValue] <= 100){
                everyConvert = [everyConvertDisplay intValue];
                [everyConvertDisplay setIntegerValue:everyConvert];
                
                minConvert = pointConvert*everyConvert;
                hrConvert = (pointConvert*everyConvert)/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [minConvertDisplay setIntegerValue:minConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [everyConvertDisplay setIntegerValue:everyConvert];
        }
        
        if ([aNotification object] == pointConvertDisplay){
            if ([pointConvertDisplay intValue] >= 0 && [pointConvertDisplay intValue] <= 10000){
                pointConvert = [pointConvertDisplay intValue];
                [pointConvertDisplay setIntegerValue:pointConvert];
                
                minConvert = pointConvert*everyConvert;
                hrConvert = (pointConvert*everyConvert)/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [minConvertDisplay setIntegerValue:minConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [pointConvertDisplay setIntegerValue:pointConvert];
        }
        
        if ([aNotification object] == minConvertDisplay){
            if ([minConvertDisplay intValue] >= 0 && [minConvertDisplay intValue] <= 100000){
                minConvert = [minConvertDisplay intValue];
                [minConvertDisplay setIntegerValue:minConvert];
                
                pointConvert = (int)(minConvert/(double)everyConvert);
                hrConvert = minConvert/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [pointConvertDisplay setIntegerValue:pointConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [minConvertDisplay setIntegerValue:minConvert];
        }
        
        if ([aNotification object] == hrConvertDisplay){
            if ([hrConvertDisplay intValue] >= 0 && [hrConvertDisplay intValue] <= 10000){
                hrConvert = [hrConvertDisplay intValue];
                [hrConvertDisplay setDoubleValue:hrConvert];
                
                pointConvert = (int)((hrConvert*60)/(double)everyConvert);
                minConvert = (int)(hrConvert*60);
                
                [pointConvertDisplay setIntegerValue:pointConvert];
                [minConvertDisplay setIntegerValue:minConvert];
            }
            else [hrConvertDisplay setDoubleValue:hrConvert];
        }
    }
}

-(IBAction)createExcelFile:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Cell_Division";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Cell_Division") != -1){
                extractString = entry.substr(entry.find("CD")+2, entry.find(".txt")-entry.find("CD")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Cell_Division-CD"+to_string(maxEntryNo)+".txt";
    
    int **cellNumberHold = new int *[50];
    
    for (int counter2 = 0; counter2 < 50; counter2++){
        cellNumberHold [counter2] = new int [horizontalScaleMaxDivisionHold+50];
    }
    
    for (int counter2 = 0; counter2 < 50; counter2++){
        for (int counter3 = 0; counter3 < horizontalScaleMaxDivisionHold+50; counter3++){
            cellNumberHold [counter2][counter3] = -1;
        }
    }
    
    for (int counter3 = 0; counter3 <= horizontalScaleMaxDivisionHold; counter3++){
        cellNumberHold [0][counter3] = counter3;
    }
    
    string **nameHold = new string *[50];
    
    for (int counter2 = 0; counter2 < 3; counter2++){
        nameHold [counter2] = new string [50];
    }
    
    for (int counter2 = 0; counter2 < 3; counter2++){
        for (int counter3 = 0; counter3 < 50; counter3++){
            nameHold [counter2][counter3] = "nil";
        }
    }
    
    nameHold [0][0] = "Time min";
    
    int actualTime = 0;
    int maxEntry = 0;
    int entryCount = 0;
    string treatNameGR;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1 && maxEntry < 8){
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                actualTime = arrayLineageData [counter2][counter3*9+2]*atoi(arrayLineageDataType [counter2][5].c_str());
                
                if (arrayLineageData [counter2][counter3*9+3] == 32){
                    if (cellNumberHold [entryCount*5+1][actualTime] == -1) cellNumberHold [entryCount*5+1][actualTime] = 1;
                    else cellNumberHold [entryCount*5+1][actualTime]++;
                }
                
                if (arrayLineageData [counter2][counter3*9+3] == 42){
                    if (cellNumberHold [entryCount*5+2][actualTime] == -1) cellNumberHold [entryCount*5+2][actualTime] = 1;
                    else cellNumberHold [entryCount*5+2][actualTime]++;
                }
                
                if (arrayLineageData [counter2][counter3*9+3] == 52){
                    if (cellNumberHold [entryCount*5+3][actualTime] == -1) cellNumberHold [entryCount*5+3][actualTime] = 1;
                    else cellNumberHold [entryCount*5+3][actualTime]++;
                }
                
                if (arrayLineageData [counter2][counter3*9+3] == 7){
                    if (cellNumberHold [entryCount*5+4][actualTime] == -1) cellNumberHold [entryCount*5+4][actualTime] = 1;
                    else cellNumberHold [entryCount*5+4][actualTime]++;
                }
                
                if (arrayLineageData [counter2][counter3*9+3] == 91){
                    if (cellNumberHold [entryCount*5+5][actualTime] == -1) cellNumberHold [entryCount*5+5][actualTime] = 1;
                    else cellNumberHold [entryCount*5+5][actualTime]++;
                }
            }
            
            nameHold [0][entryCount*5+1] = arrayTableMain [counter2][3]+" "+arrayTableMain [counter2][4];
            nameHold [1][entryCount*5+1] = "BD";
            nameHold [1][entryCount*5+2] = "TD";
            nameHold [1][entryCount*5+3] = "HD";
            nameHold [1][entryCount*5+4] = "CD";
            nameHold [1][entryCount*5+5] = "FU";
            
            entryCount++;
            maxEntry++;
        }
    }
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    for (int counter2 = 0; counter2 < entryCount*5+1; counter2++){
        //0D--13
        //***09***09***0D0A
        //***09***09
        
        ascIIstring = nameHold [0][counter2];
       
        if (nameHold [0][counter2] != "nil"){
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        }
        
        oin.put(9);
    }
    
    oin.put(13);
    oin.put(10);
    
    for (int counter2 = 0; counter2 < entryCount*5+1; counter2++){
        //0D--13
        //***09***09***0D0A
        //***09***09
        
        ascIIstring = nameHold [1][counter2];
        
        if (nameHold [1][counter2] != "nil"){
            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
            
            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        }
        
        oin.put(9);
    }
    
    oin.put(13);
    oin.put(10);
    
    int entryCheck = 0;
    
    for (int counter1 = 0; counter1 <= horizontalScaleMaxDivisionHold; counter1++){
        entryCheck = 0;
        
        for (int counter2 = 1; counter2 < entryCount*5+1; counter2++){
            if (cellNumberHold [counter2][counter1] != -1) entryCheck = 1;
        }
        
        if (entryCheck == 1){
            for (int counter2 = 0; counter2 < entryCount*5+1; counter2++){
                if (cellNumberHold [counter2][counter1] != -1){
                    ascIIstring = to_string(cellNumberHold [counter2][counter1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                }
                
                oin.put(9);
            }
            
            oin.put(13);
            oin.put(10);
        }
    }
    
    oin.close();
    
    for (int counter2 = 0; counter2 < 50; counter2++){
        delete [] cellNumberHold [counter2];
    }
    
    delete [] cellNumberHold;
    
    for (int counter2 = 0; counter2 < 3; counter2++){
        delete [] nameHold [counter2];
    }
    
    delete [] nameHold;
    delete [] arrayAscIIintData;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)belowTypeSelect:(id)sender{
    if (belowDisplayType == 0){
        belowDisplayType = 1;
        [belowTypeDisplay setStringValue:@"HD"];
    }
    else if (belowDisplayType == 1){
        belowDisplayType = 2;
        [belowTypeDisplay setStringValue:@"TD+HD"];
    }
    else if (belowDisplayType == 2){
        belowDisplayType = 3;
        [belowTypeDisplay setStringValue:@"CD"];
    }
    else if (belowDisplayType == 3){
        belowDisplayType = 4;
        [belowTypeDisplay setStringValue:@"FU"];
    }
    else if (belowDisplayType == 4){
        belowDisplayType = 0;
        [belowTypeDisplay setStringValue:@"TD"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)closeWindow:(id)sender{
    [cellDivisionWindow orderOut:self];
    cellDivisionWindowOperation = 2;
    cellDivisionTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (cellDivisionWindowOperation == 3){
        [cellDivisionWindow makeKeyAndOrderFront:self];
        cellDivisionWindowOperation = 1;
        [cellDivisionTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCellDivisionController object:nil];
}

@end
