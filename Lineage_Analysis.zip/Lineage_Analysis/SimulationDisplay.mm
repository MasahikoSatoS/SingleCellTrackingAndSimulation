//
//  SimulationDisplay.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-10-29.
//

#import "SimulationDisplay.h"

NSString *notificationToSimulationDisplay = @"notificationExecuteSimDisplay";

@implementation SimulationDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        imageSimNoCount = 0;
        drawFlag = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToSimulationDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    simDisplayTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    
    [self setNeedsDisplay:YES];
}

-(void)display{
    if (timingSimCount == 1){
        timingSimCount = 2;
        backSaveOn2 = 1;
        
        int totalNumberOfCells = cellGrowthCount [cellGrowthCountTimeEnd*12];
        
        simDimension = (int)(sqrt(totalNumberOfCells*20)*1.1);
        
        if (simDimension < 500) simDimension = 500;
        
        if (videoImageSizeOptionHold == 1){
            if (videoImageSizeHold >= 500 && videoImageSizeHold  <= 10000){
                simDimension = videoImageSizeHold;
            }
        }
        
        imageSimNoCount = 1;
        drawFlag = 0;
        
        if (movieDistanceHold > 100) movieDistanceHold = 100;
        if (movieDistanceHold2 > 100) movieDistanceHold2 = 100;
        if (movieDistanceHold3 > 100) movieDistanceHold3 = 100;
        
        if (movieDistanceTime2 == 0 || movieDistanceHold2 == 0){
            movieDistanceTime2 = 0;
            movieDistanceHold2 = 0;
        }
        
        if (movieDistanceTime3 == 0 || movieDistanceHold3 == 0){
            movieDistanceTime3 = 0;
            movieDistanceHold3 = 0;
        }
        
        if (movieDistanceTime2 != 0 &&  movieDistanceTime3 != 0 && movieDistanceTime2 >= movieDistanceTime3){
            movieDistanceTime3 = 0;
            movieDistanceHold3 = 0;
        }
        
        if (circleSizeHold > 100) circleSizeHold = 100;
        
        mapPositionHeld = new int *[simDimension+1];
        mapCellNoHeld = new int *[simDimension+1];
        mapLingNoHeld = new int *[simDimension+1];
        
        for (int counter1 = 0; counter1 < simDimension+1; counter1++){
            mapPositionHeld [counter1] = new int [simDimension+1];
            mapCellNoHeld [counter1] = new int [simDimension+1];
            mapLingNoHeld [counter1] = new int [simDimension+1];
        }
        
        for (int counter1 = 0; counter1 < simDimension; counter1++){
            for (int counter2 = 0; counter2 < simDimension; counter2++){
                mapPositionHeld [counter1][counter2] = 0;
                mapCellNoHeld [counter1][counter2] = 0;
                mapLingNoHeld [counter1][counter2] = 0;
            }
        }
        
        //1. Ling no
        //2. Cell no
        //3. Array start
        //4. Array end
        //5. Start event
        //6. End event
        //7. Fusion event (92)
        //8. Parent Cell no
        //9. Paint pattern1 BD --10
        //10. Paint pattern2 TD --9
        //11. Paint pattern3 BDCF --8
        //12. Paint pattern4 BDCFBD --7
        //13. Paint pattern5 BDCFTD --5
        //14. Paint pattern6 TDCF --6
        //15. Paint pattern7 TDCFBD --3
        //16. Paint pattern8 TDCFTD --4
        //17. Paint pattern9 TDBD --1
        //18. Paint pattern10 TDTD --2
        //19. Paint pattern11 non --11
        
        //BD 0, 1
        //TD 2, 3
        //BD-CF 4, 5
        //BD-CF-BD 6, 7
        //BD-CF-TD 8, 9
        //TD-CF 10,11
        //TD-CF-BD, 12, 13
        //TD-CF-TD, 14, 15
        //TD-BD, 16, 17
        //TD-TD, 18, 19
        //no 20, 21
        
        for (int counter2 = 0; counter2 < cellEventTypeListTimeCount/19; counter2++){
            if (cellEventTypeListTime [counter2*19+16] != 0) cellEventTypeListTime [counter2*19+8] = 17;
            else if (cellEventTypeListTime [counter2*19+17] != 0) cellEventTypeListTime [counter2*19+8] = 19;
            else if (cellEventTypeListTime [counter2*19+14] != 0) cellEventTypeListTime [counter2*19+8] = 13;
            else if (cellEventTypeListTime [counter2*19+15] != 0) cellEventTypeListTime [counter2*19+8] = 15;
            else if (cellEventTypeListTime [counter2*19+12] != 0) cellEventTypeListTime [counter2*19+8] = 9;
            else if (cellEventTypeListTime [counter2*19+13] != 0) cellEventTypeListTime [counter2*19+8] = 11;
            else if (cellEventTypeListTime [counter2*19+11] != 0) cellEventTypeListTime [counter2*19+8] = 7;
            else if (cellEventTypeListTime [counter2*19+10] != 0) cellEventTypeListTime [counter2*19+8] = 5;
            else if (cellEventTypeListTime [counter2*19+9] != 0) cellEventTypeListTime [counter2*19+8] = 3;
            else if (cellEventTypeListTime [counter2*19+8] != 0) cellEventTypeListTime [counter2*19+8] = 1;
            else if (cellEventTypeListTime [counter2*19+18] != 0) cellEventTypeListTime [counter2*19+8] = 21;
            else cellEventTypeListTime [counter2*19+8] = 0;
            
            cellEventTypeListTime [counter2*19+17] = 0;
            cellEventTypeListTime [counter2*19+18] = 0;
        }
        
        //for (int counterA = 0; counterA < cellEventTypeListTimeCount/19; counterA++){
        //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeListTime [counterA*19+counterB];
        //    cout<<" cellEventTypeListTime "<<counterA<<endl;
        //}
        
        if (videoColorStatus == 1){
            srand((unsigned)time(NULL));
            
            lingColorListSim = new double [(lingNoSim+1)*4+10];
            
            for (int counter2 = 1; counter2 <= lingNoSim; counter2++){
                lingColorListSim  [counter2*4] = (rand()%255)/(double)255;
                lingColorListSim  [counter2*4+1] = (rand()%255)/(double)255;
                lingColorListSim  [counter2*4+2] = (rand()%255)/(double)255;
                lingColorListSim  [counter2*4+3] = 0;
            }
        }
        else if (videoColorStatus == 2){
            int simLingFind = 0;
            
            lingColorListSim = new double [(lingNoSim+1)*4+10];
            
            for (int counter2 = 1; counter2 <= lingNoSim; counter2++){
                simLingFind = 0;
                
                for (int counter3 = 0; counter3 < cellNoListForSelectLingCount; counter3++){
                    if (cellNoListForSelectLing [counter3] == counter2){
                        simLingFind = 1;
                        break;
                    }
                }
                
                if (simLingFind == 1){
                    lingColorListSim  [counter2*4] = arrayColorRange2 [colorNoSimHold*3];
                    lingColorListSim  [counter2*4+1] = arrayColorRange2 [colorNoSimHold*3+1];
                    lingColorListSim  [counter2*4+2] = arrayColorRange2 [colorNoSimHold*3+2];
                    lingColorListSim  [counter2*4+3] = 1;
                }
                else{
                    
                    lingColorListSim  [counter2*4] = 199/(double)255;
                    lingColorListSim  [counter2*4+1] = 199/(double)255;
                    lingColorListSim  [counter2*4+2] = 199/(double)255;
                    lingColorListSim  [counter2*4+3] = 0;
                }
            }
        }
        
        timingSimCount = 3;
    }
    else if (timingSimCount == 3){
        timingSimCount = 4;
        
        string extension = to_string(imageSimNoCount);
        
        if (extension.length() == 1) extension = "0000"+extension;
        else if (extension.length() == 2) extension = "000"+extension;
        else if (extension.length() == 3) extension = "00"+extension;
        else if (extension.length() == 4) extension = "0"+extension;
        
        displayImageSavePath = displayImageAllPath+"/Simulation-SL"+extension+".tif";
        
        movieDistanceSet = movieDistanceHold;
        
        if (movieDistanceRedStatus == 0){
            if (movieDistanceTime2 != 0 && movieDistanceHold2 != 0 && movieDistanceTime2 < imageSimNoCount) movieDistanceSet = movieDistanceHold2;
            if (movieDistanceTime3 != 0 && movieDistanceHold3 != 0 && movieDistanceTime3 < imageSimNoCount) movieDistanceSet = movieDistanceHold3;
        }
        
        timingSimCount = 5;
    }
    else if (timingSimCount == 5 && drawFlag == 0){
        [self setNeedsDisplay:YES];
    }
    else if (timingSimCount == 5 && drawFlag == 2){
        timingSimCount = 7;
    }
    else if (timingSimCount == 7){
        if (imageSimNoCount <= cellGrowthCountTimeEnd && terminateSimFlag2 == 0){
            imageSimNoCount++;
            timingSimCount = 3;
            drawFlag = 0;
        }
        else{
            
            timingSimCount = 0;
            imageSimNoCount = 0;
            terminateSimFlag2 = 0;
            exportFlag10 = 2;
            backSaveOn2 = 3;
            
            for (int counter1 = 0; counter1 < simDimension; counter1++){
                delete [] mapPositionHeld [counter1];
                delete [] mapCellNoHeld [counter1];
                delete [] mapLingNoHeld [counter1];
            }
            
            delete [] mapPositionHeld;
            delete [] mapCellNoHeld;
            delete [] mapLingNoHeld;
            
            delete [] lingColorListSim;
        }
    }
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    
    //----Fit export----
    if (processSimType == 1 && clickPoint.x > 488 && clickPoint.x < 532 && clickPoint.y > 515 && clickPoint.y < 569){
        if (fitDataHoldCount != 0){
            exportFlag10 = 1;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string entry;
            string extractString;
            
            DIR *dir;
            struct dirent *dent;
            
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        extractString = entry.substr(entry.find("FI")+2, entry.find(".tif")-entry.find("FI")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            exportResultPath = resultSavePath2+"/"+"Line_Fitting-FI"+to_string(maxEntryNo)+".tif";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    //----Video----
    if (clickPoint.x > 435 && clickPoint.x < 479 && clickPoint.y > 515 && clickPoint.y < 569){
        if (performDataStatus == 1){
            exportFlag10 = 100;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string nameString = "Simulation-SL";
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find(nameString) != -1){
                        extractString = entry.substr(entry.find("SL")+2);
                        
                        if ((int)extractString.find(".tif") == -1) extractString = extractString.substr(0, entry.find(".tif"));
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            displayImageAllPath = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation/"+nameString+to_string(maxEntryNo);
            mkdir(displayImageAllPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            timingSimCount = 1;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Perform Reload To Set Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    //----Simulation export----
    if (clickPoint.x > 382 && clickPoint.x < 426 && clickPoint.y > 515 && clickPoint.y < 569){
        if (performDataStatus == 1){
            exportFlag10 = 1;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Simulation";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string entry;
            string extractString;
            
            DIR *dir;
            struct dirent *dent;
            
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        extractString = entry.substr(entry.find("SL")+2, entry.find(".tif")-entry.find("SL")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            exportResultPath = resultSavePath2+"/"+"Simulation-SL"+to_string(maxEntryNo)+".tif";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Perform Reload To Set Data"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    //----Simulation reload----
    if ((processSimType == 0 || processSimType == 2) && clickPoint.x > 329 && clickPoint.x < 373 && clickPoint.y > 515 && clickPoint.y < 569){
        processSimType = 2;
        [self setNeedsDisplay:YES];
    }
    
    if (exportFlag10 == 2){
        exportFlag10 = 0;
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
        
        [self setNeedsDisplay:YES];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    
    if (keyCode == 17){
        if (timingSimCount != 0){
            terminateSimFlag2 = 1;
        }
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

- (void)drawRect:(NSRect)dirtyRect {
    drawFlag = 1;
    
    if (exportFlag10 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 537, 537)];
        [path fill];
        
        [NSBezierPath setDefaultLineWidth:1.0];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:12] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(488, 515, 44, 14)];
        [path stroke];
        
        string ifString = "Ex.Fit";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 493;
        pointA.y = 515;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(435, 515, 44, 14)];
        [path stroke];
        
        ifString = "Video";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 439;
        pointA.y = 515;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(382, 515, 44, 14)];
        [path stroke];
        
        ifString = "Ex.Sim";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 384;
        pointA.y = 515;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(329, 515, 44, 14)];
        [path stroke];
        
        ifString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(ifString.c_str()) attributes:attributesA];
        pointA.x = 331;
        pointA.y = 515;
        [attrStrA drawAtPoint:pointA];
        
        if (simulationOperation != 0){
            if (processSimType == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(60, 50, 450, 450)];
                [path stroke];
                
                //----Horizontal Label----
                int horizontalTime = fitDataHoldCount/4-1;
                
                //----Horizontal Scale----
                double lengthDivision = horizontalTime/(double)5;
                int lengthDivisionInt = (int)lengthDivision;
                
                string lengthDivisionString = to_string(lengthDivisionInt).substr(0, 1);
                int lengthOfDiv = (int)(to_string(lengthDivisionInt).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt = atoi(lengthDivisionString.c_str());
                
                int scaleAdjust = 0;
                
                if (lengthDivisionInt >= 1000) scaleAdjust = 1;
                if (lengthDivisionInt >= 10000) scaleAdjust = 2;
                
                string timeString = "Time";
                
                if (scaleAdjust == 1) timeString = "Time (x10)";
                else if (scaleAdjust == 2) timeString = "Time (x100)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:11];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                CGFloat size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = 60+225-(size2/(double)2);
                pointA.y = 50-40;
                [attrStrA drawAtPoint:pointA];
                
                double lengthPix = ((450-10)/(double)horizontalTime)*lengthDivisionInt;
                int numberOfDivision = (int)((450-10)/(double)lengthPix)+1;
                
                double sift = 0;
                int lengthDivisionIntTemp = 0;
                
                NSPoint positionAA;
                NSPoint positionBB;
                NSPoint pointA2;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = 60+lengthPix*counter2;
                    positionAA.y = 50;
                    positionBB.x = 60+lengthPix*counter2;
                    positionBB.y = 50+5;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    lengthDivisionIntTemp = lengthDivisionInt;
                    
                    if (scaleAdjust == 1) lengthDivisionIntTemp = lengthDivisionInt/10;
                    else if (scaleAdjust == 2) lengthDivisionIntTemp = lengthDivisionInt/100;
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (60+lengthPix*counter2)-(size2/(double)2)-sift;
                    pointA2.y = 50-20;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                double maxVertical = 0;
                
                for (int counter2 = 1; counter2 < fitDataHoldCount/4; counter2++){
                    if (maxVertical < arrayFitDataHold [counter2*4]) maxVertical = arrayFitDataHold [counter2*4];
                    if (arrayFitDataHold [1] == -1 && maxVertical < arrayFitDataHold [counter2*4+1]) maxVertical = arrayFitDataHold [counter2*4+1];
                    if (arrayFitDataHold [2] == -1 && maxVertical < arrayFitDataHold [counter2*4+2]) maxVertical = arrayFitDataHold [counter2*4+2];
                    if (arrayFitDataHold [3] == -1 && maxVertical < arrayFitDataHold [counter2*4+3]) maxVertical = arrayFitDataHold [counter2*4+3];
                }
                
                //for (int counterA = 0; counterA < fitCycleHold; counterA++){
                //    cout<<counterA<<" "<<arrayFitDataHold [counterA*4]<<" "<<arrayFitDataHold [counterA*4+1]<<" "<<arrayFitDataHold [counterA*4+2]<<" "<<arrayFitDataHold [counterA*4+3]<<" arrayFitDataHold"<<endl;
                //}
                
                //----Vertical Scale----
                unsigned long verticalNo = (unsigned long)(maxVertical*1.2);
                
                if (verticalNo < 10) verticalNo = 10;
                
                unsigned long lengthDivisionInt2 = (unsigned long)(verticalNo/(double)5);
                
                lengthDivisionString = to_string(lengthDivisionInt2).substr(0, 1);
                lengthOfDiv = (int)(to_string(lengthDivisionInt2).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt2 = (unsigned long)(atof(lengthDivisionString.c_str()));
                
                int maxLength = (int)(to_string(verticalNo).length());
                int scaleAdjustVer = 0;
                if (maxLength >= 4) scaleAdjustVer = maxLength-2;
                
                string lengthDivisionString2 = "1";
                
                for (int counter2 = 0; counter2 < scaleAdjustVer; counter2++){
                    lengthDivisionString2 = lengthDivisionString2+"0";
                }
                
                unsigned long verticalValueDiv = lengthDivisionInt2;
                
                if (scaleAdjustVer != 0) verticalValueDiv = (unsigned long)(atof(lengthDivisionString2.c_str()));
                
                double lengthPix2 = ((450-10)/(double)verticalNo)*lengthDivisionInt2;
                int numberOfDivision2 = (int)((450-10)/(double)lengthPix2)+1;
                int lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    positionAA.x = 60;
                    positionAA.y = 50+lengthPix2*counter2;
                    positionBB.x = 60+5;
                    positionBB.y = 50+lengthPix2*counter2;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    if (scaleAdjustVer == 0) lengthDivisionIntTemp = (int)verticalValueDiv;
                    else lengthDivisionIntTemp = (int)(lengthDivisionInt2/verticalValueDiv);
                    
                    NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                    size2 = [attrStrS3 size].width;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                    pointA2.x = 60-size2-10;
                    pointA2.y = 50+lengthPix2*counter2-5;
                    [attrStrA2 drawAtPoint:pointA2];
                    
                    if (lowestXPosition > 60-size2-10) lowestXPosition = (int)(60-size2-10);
                }
                
                //----Vertical Label----
                string labelDisplay = "Number of Cells";
                
                if (lengthDivisionString2.length() == 2) labelDisplay = "Number of Cells (x10)";
                else if (lengthDivisionString2.length() == 3) labelDisplay = "Number of Cells (x100)";
                else if (lengthDivisionString2.length() == 4) labelDisplay = "Number of Cells (x1000)";
                else if (lengthDivisionString2.length() >= 4){
                    int lengthTemp = (int)lengthDivisionString2.length()-1;
                    
                    labelDisplay = "Number of Cells (xe"+to_string(lengthTemp)+")";
                }
                
                NSString *verticalNSstring = @(labelDisplay.c_str());
                
                NSFont *font2 = [NSFont boldSystemFontOfSize:11];
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                NSGraphicsContext *context = [NSGraphicsContext currentContext];
                NSAffineTransform *transform = [NSAffineTransform transform];
                [transform rotateByDegrees:+90];
                
                [context saveGraphicsState];
                [transform concat];
                
                NSAttributedString *attrStrB;
                NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                NSString *titleStringB = @(labelDisplay.c_str());
                
                [attributesB setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                
                pointA.x = 50+(225-size2/(double)2);
                pointA.y = (lowestXPosition-10)*-1;
                [attrStrB drawAtPoint:pointA];
                
                [context restoreGraphicsState];
                
                double xPositionCenter = 0;
                double yPositionCenter = 0;
                string treatNameGR;
                
                [NSBezierPath setDefaultLineWidth:1.0];
                
                for (int counter2 = 0; counter2 < 4; counter2++){
                    if (counter2 == 0) [[NSColor blueColor] set];
                    else if (counter2 == 1) [[NSColor redColor] set];
                    else if (counter2 == 2) [[NSColor orangeColor] set];
                    else if (counter2 == 3) [[NSColor brownColor] set];
                    
                    for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                        xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                        yPositionCenter = ((450-10)/(double)verticalNo)*(double)arrayFitDataHold [counter3*4+counter2]+50;
                        
                        if (xPositionCenter > 60 && xPositionCenter < 60+450 && yPositionCenter > 50 && yPositionCenter < 50+450 && arrayFitDataHold [counter3*4+counter2] != -2){
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                            [path stroke];
                        }
                    }
                }
            }
            else if (processSimType == 2){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(60, 50, 450, 450)];
                [path stroke];
                
                long *cellEventTypeList = new long [20000000];
                int cellEventTypeListCount = 0;
                int cellEventTypeListLimit = 20000000;
                
                int noOfLing = 0;
                int noOfCellStart = 0;
                int noOfTotalCells = 0;
                int timeEnd = 0;
                int cellNoTemp = 0;
                int lingNoTemp = 0;
                int firstTimeFlag = 0;
                int parentCellNo = 0;
                int lineagePositionNo = 0; //----Take the last entry----
                
                lineagePositionNo = simOperationTableCurrentRow;
                
                //for (int counterA = 0; counterA < arrayLineageDataEntryHold [lineagePositionNo]/9; counterA++){
                //    if (arrayLineageData [lineagePositionNo][counterA*9+6] == 470){
                //        for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< arrayLineageData [lineagePositionNo][counterA*9+counterB];
                //        cout<<" arrayLineageData "<<counterA<<endl;
                //    }
                //}
                
                cellNoListForSelectLingCount = 0;
                
                for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineagePositionNo]/9; counter2++){
                    if ((cellNoTemp != arrayLineageData [lineagePositionNo][counter2*9+5] || lingNoTemp != arrayLineageData [lineagePositionNo][counter2*9+6]) && firstTimeFlag == 0){
                        cellNoTemp = arrayLineageData [lineagePositionNo][counter2*9+5];
                        lingNoTemp = arrayLineageData [lineagePositionNo][counter2*9+6];
                        firstTimeFlag = 1;
                        
                        cellEventTypeList [cellEventTypeListCount] = arrayLineageData [lineagePositionNo][counter2*9+6], cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = arrayLineageData [lineagePositionNo][counter2*9+5], cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = (long)counter2, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = arrayLineageData [lineagePositionNo][counter2*9+3], cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        
                        if (arrayLineageData [lineagePositionNo][counter2*9+3] == 31 || arrayLineageData [lineagePositionNo][counter2*9+3] == 41 || arrayLineageData [lineagePositionNo][counter2*9+3] == 51) parentCellNo = arrayLineageData [lineagePositionNo][counter2*9+4];
                    }
                    else if (cellNoTemp == arrayLineageData [lineagePositionNo][counter2*9+5] && lingNoTemp == arrayLineageData [lineagePositionNo][counter2*9+6] && arrayLineageData [lineagePositionNo][counter2*9+3] == 92 && firstTimeFlag == 1){
                        cellEventTypeList [cellEventTypeListCount-13] = 1;
                    }
                    else if ((cellNoTemp != arrayLineageData [lineagePositionNo][counter2*9+5] || lingNoTemp != arrayLineageData [lineagePositionNo][counter2*9+6]) && firstTimeFlag == 1){
                        cellEventTypeList [cellEventTypeListCount-16] = (int)counter2-1;
                        cellEventTypeList [cellEventTypeListCount-14] = arrayLineageData [lineagePositionNo][(counter2-1)*9+3];
                        cellEventTypeList [cellEventTypeListCount-12] = parentCellNo;
                        
                        cellNoTemp = arrayLineageData [lineagePositionNo][counter2*9+5];
                        lingNoTemp = arrayLineageData [lineagePositionNo][counter2*9+6];
                        
                        if (cellEventTypeListCount+50 > cellEventTypeListLimit){
                            long *arrayUpDate = new long [cellEventTypeListCount+10];
                            
                            for (int counter3 = 0; counter3 < cellEventTypeListCount; counter3++) arrayUpDate [counter3] = cellEventTypeList [counter3];
                            
                            delete [] cellEventTypeList;
                            cellEventTypeList = new long [cellEventTypeListLimit+1000000];
                            cellEventTypeListLimit = cellEventTypeListLimit+1000000;
                            
                            for (int counter3 = 0; counter3 < cellEventTypeListCount; counter3++) cellEventTypeList [counter3] = arrayUpDate [counter3];
                            delete [] arrayUpDate;
                        }
                        
                        cellEventTypeList [cellEventTypeListCount] = arrayLineageData [lineagePositionNo][counter2*9+6], cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = arrayLineageData [lineagePositionNo][counter2*9+5], cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = (long)counter2, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = arrayLineageData [lineagePositionNo][counter2*9+3], cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        cellEventTypeList [cellEventTypeListCount] = 0, cellEventTypeListCount++;
                        
                        if (arrayLineageData [lineagePositionNo][counter2*9+3] == 31 || arrayLineageData [lineagePositionNo][counter2*9+3] == 41 || arrayLineageData [lineagePositionNo][counter2*9+3] == 51) parentCellNo = arrayLineageData [lineagePositionNo][counter2*9+4];
                    }
                    else if (counter2 == arrayLineageDataEntryHold [lineagePositionNo]/9-1 && firstTimeFlag == 1){
                        cellEventTypeList [cellEventTypeListCount-16] = (long)counter2;
                        cellEventTypeList [cellEventTypeListCount-14] = arrayLineageData [lineagePositionNo][counter2*9+3];
                        cellEventTypeList [cellEventTypeListCount-12] = parentCellNo;
                    }
                    
                    if (arrayLineageData [lineagePositionNo][counter2*9+2] == 1 && (arrayLineageData [lineagePositionNo][counter2*9+5] == 0 || arrayLineageData [lineagePositionNo][counter2*9+5] == -1)){
                        noOfLing++;
                    }
                    
                    if (timeEnd < arrayLineageData [lineagePositionNo][counter2*9+2]) timeEnd = arrayLineageData [lineagePositionNo][counter2*9+2]; //==
                    
                    if (arrayLineageData [lineagePositionNo][counter2*9+2] == 1 && arrayLineageData [lineagePositionNo][counter2*9+5] == 0){
                        noOfCellStart++;
                    }
                    
                    if ((arrayLineageData [lineagePositionNo][counter2*9+3] == 1 || arrayLineageData [lineagePositionNo][counter2*9+3] == 31 || arrayLineageData [lineagePositionNo][counter2*9+3] == 41 || arrayLineageData [lineagePositionNo][counter2*9+3] == 51)){
                        noOfTotalCells++;
                    }
                    
                    if (arrayLineageData [lineagePositionNo][counter2*9] == 20 && arrayLineageData [lineagePositionNo][counter2*9+3] == 1) cellNoListForSelectLingCount++;
                }
                
                //for (int counterA = 0; counterA < cellEventTypeListCount/19; counterA++){
                //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeList [counterA*19+counterB];
                //    cout<<" cellEventTypeList "<<counterA<<endl;
                //}
                
                int numberOfCellEnd = 0;
                
                for (int counter2 = 0; counter2 < cellEventTypeListCount/19; counter2++){
                    if (arrayLineageData [lineagePositionNo][cellEventTypeList [counter2*19+3]*9+2] == timeEnd) numberOfCellEnd++;
                }
                
                //1. Ling no
                //2. Cell no
                //3. Array start
                //4. Array end
                //5. Start event
                //6. End event
                //7. Fusion event (92)
                //8. Parent Cell no
                //9. Paint pattern1 BD
                //10. Paint pattern2 TD
                //11. Paint pattern3 BDCF
                //12. Paint pattern4 BDCFBD
                //13. Paint pattern5 BDCFTD
                //14. Paint pattern6 TDCF
                //15. Paint pattern7 TDCFBD
                //16. Paint pattern8 TDCFTD
                //17. Paint pattern9 TDBD
                //18. Paint pattern10 TDTD
                //19. Paint pattern11 non
                
                //BD 0, 1
                //TD 2, 3
                //BD-CF 4, 5
                //BD-CF-BD 6, 7
                //BD-CF-TD 8, 9
                //TD-CF 10,11
                //TD-CF-BD, 12, 13
                //TD-CF-TD, 14, 15
                //TD-BD, 16, 17
                //TD-TD, 18, 19
                //no 20, 21
                
                long *cellEventTypeList2 = new long [cellEventTypeListCount+50];
                int cellEventTypeListCount2 = 0;
                
                long *cellPerLing = new long [cellEventTypeListCount+50];
                int cellPerLingCount = 0;
                
                long *cellNoTempList = new long [100];
                int cellNoTempListCount = 0;
                
                long *cellNoTempList2 = new long [100];
                int cellNoTempListCount2 = 0;
                
                int terminationFlag = 0;
                int entryTemp = 0;
                int nonDivBDFlag = 0;
                
                for (int counter1 = 1; counter1 <= noOfLing; counter1++){
                    cellPerLingCount = 0;
                    
                    for (int counter2 = 0; counter2 < cellEventTypeListCount/19; counter2++){
                        if (cellEventTypeList [counter2*19] == counter1){
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+1], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+2], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+3], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+4], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+5], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+6], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+7], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+8], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+9], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+10], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+11], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+12], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+13], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+14], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+15], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+16], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+17], cellPerLingCount++;
                            cellPerLing [cellPerLingCount] = cellEventTypeList [counter2*19+18], cellPerLingCount++;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < cellPerLingCount/19; counterA++){
                    //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellPerLing [counterA*19+counterB];
                    //    cout<<" cellPerLing "<<counterA<<endl;
                    //}
                    
                    delete [] cellNoTempList;
                    cellNoTempList = new long [(cellPerLingCount/19)*2+20];
                    cellNoTempListCount = 0;
                    
                    delete [] cellNoTempList2;
                    cellNoTempList2 = new long [(cellPerLingCount/19)*2+20];
                    
                    nonDivBDFlag = 0;
                    
                    for (int counter2 = 0; counter2 < cellPerLingCount/19; counter2++){
                        if (cellPerLing [counter2*19+4] == 1){
                            if (cellPerLingCount/19== 1){
                                cellPerLing [counter2*19+18] = 21;
                                nonDivBDFlag = 1;
                                break;
                            }
                            else if (cellPerLing [counter2*19+5] == 32){
                                cellNoTempList [cellNoTempListCount] = 0, cellNoTempListCount++;
                                cellNoTempList [cellNoTempListCount] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+4] != 1 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                if (cellPerLing [counter4*19+1] != 0) cellPerLing [counter4*19+8] = 1;
                                                
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                    
                    if (nonDivBDFlag == 0){
                        for (int counter2 = 0; counter2 < cellPerLingCount/19; counter2++){
                            if (cellPerLing [counter2*19+4] == 41 || cellPerLing [counter2*19+4] == 51){
                                cellPerLing [counter2*19+9] = 3;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+9] = 3;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < entryTemp/2; counterA++){
                                    //    cout<<counterA<<" "<<cellNoTempList [counterA*2]<<" "<<cellNoTempList [counterA*2+1]<<" cellNoTempList"<<endl;
                                    //}
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if (cellPerLing [counter2*19+4] == 31 && cellPerLing [counter2*19+6] == 1){
                                cellPerLing [counter2*19+10] = 5;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+10] = 5;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    //for (int counterA = 0; counterA < cellNoTempListCount/2; counterA++){
                                    //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<<cellNoTempList [counterA*2+counterB];
                                    //    cout<<" cellNoTempList "<<counterA<<endl;
                                    //}
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if (cellPerLing [counter2*19+4] == 31 && cellPerLing [counter2*19+6] == 1 && cellPerLing [counter2*19+5] == 32){
                                cellPerLing [counter2*19+11] = 7;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+11] = 7;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if (cellPerLing [counter2*19+4] == 31 && cellPerLing [counter2*19+6] == 1 && (cellPerLing [counter2*19+5] == 42 || cellPerLing [counter2*19+5] == 52)){
                                cellPerLing [counter2*19+12] = 9;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+12] = 9;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if ((cellPerLing [counter2*19+4] == 41 || cellPerLing [counter2*19+4] == 51) && cellPerLing [counter2*19+6] == 1){
                                cellPerLing [counter2*19+13] = 11;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+13] = 11;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if ((cellPerLing [counter2*19+4] == 41 || cellPerLing [counter2*19+4] == 51) && cellPerLing [counter2*19+6] == 1 && cellPerLing [counter2*19+5] == 32){
                                cellPerLing [counter2*19+14] = 13;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+14] = 13;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if ((cellPerLing [counter2*19+4] == 41 || cellPerLing [counter2*19+4] == 51) && cellPerLing [counter2*19+6] == 1 && (cellPerLing [counter2*19+5] == 42 || cellPerLing [counter2*19+5] == 52)){
                                cellPerLing [counter2*19+15] = 15;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+15] = 15;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if ((cellPerLing [counter2*19+4] == 41 || cellPerLing [counter2*19+4] == 51) && cellPerLing [counter2*19+6] == 0 && cellPerLing [counter2*19+5] == 32){
                                cellPerLing [counter2*19+15] = 17;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+16] = 17;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                            if ((cellPerLing [counter2*19+4] == 41 || cellPerLing [counter2*19+4] == 51) && cellPerLing [counter2*19+6] == 0 && (cellPerLing [counter2*19+5] == 42 || cellPerLing [counter2*19+5] == 52)){
                                cellPerLing [counter2*19+17] = 19;
                                
                                cellNoTempList [0] = cellPerLing [counter2*19+1], cellNoTempListCount++;
                                cellNoTempList [1] = 0, cellNoTempListCount++;
                                
                                do{
                                    
                                    terminationFlag = 1;
                                    cellNoTempListCount2 = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        for (int counter4 = 0; counter4 < cellPerLingCount/19; counter4++){
                                            if (cellPerLing [counter4*19+1] != 0 && cellNoTempList [counter3*2] == cellPerLing [counter4*19+7]){
                                                cellPerLing [counter4*19+17] = 19;
                                                cellNoTempList2 [cellNoTempListCount2] = cellPerLing [counter4*19+1], cellNoTempListCount2++;
                                                cellNoTempList2 [cellNoTempListCount2] = 0, cellNoTempListCount2++;
                                            }
                                        }
                                        
                                        cellNoTempList [counter3*2+1] = 1;
                                    }
                                    
                                    entryTemp = 0;
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount/2; counter3++){
                                        if (cellNoTempList [counter3*2+1] == 0){
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2], entryTemp++;
                                            cellNoTempList [entryTemp] = cellNoTempList [counter3*2+1], entryTemp++;
                                        }
                                    }
                                    
                                    for (int counter3 = 0; counter3 < cellNoTempListCount2/2; counter3++){
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2], entryTemp++;
                                        cellNoTempList [entryTemp] = cellNoTempList2 [counter3*2+1], entryTemp++;
                                    }
                                    
                                    if (entryTemp != 0) cellNoTempListCount = entryTemp;
                                    else terminationFlag = 0;
                                    
                                } while (terminationFlag == 1);
                            }
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < cellPerLingCount/19; counter3++){
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+1], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+2], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+3], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+4], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+5], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+6], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+7], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+8], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+9], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+10], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+11], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+12], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+13], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+14], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+15], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+16], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+17], cellEventTypeListCount2++;
                        cellEventTypeList2 [cellEventTypeListCount2] = cellPerLing [counter3*19+18], cellEventTypeListCount2++;
                    }
                    
                    //for (int counterA = 0; counterA < cellEventTypeListCount2/19; counterA++){
                    //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeList2 [counterA*19+counterB];
                    //    cout<<" cellEventTypeList2 "<<counterA<<endl;
                    //}
                }
                
                delete [] cellEventTypeList;
                delete [] cellPerLing;
                delete [] cellNoTempList;
                delete [] cellNoTempList2;
                
                //for (int counterA = 0; counterA < cellEventTypeListCount2/19; counterA++){
                //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeList2 [counterA*19+counterB];
                //    cout<<" cellEventTypeList2 "<<counterA<<endl;
                //}
                
                if (performDataStatus == 1){
                    delete [] cellEventTypeListTime;
                    delete [] cellGrowthCount;
                    delete [] cellNoListForSelectLing;
                }
                else performDataStatus = 1;
                
                cellGrowthCount = new int [timeEnd*12+100];
                cellNoListForSelectLing = new int [cellNoListForSelectLingCount+10];
                cellGrowthCountTimeEnd = timeEnd;
                lingNoSim = noOfLing;
                
                for (int counter1 = 0; counter1 < timeEnd*12+100; counter1++) cellGrowthCount [counter1] = 0;
                
                cellEventTypeListTime = new int [cellEventTypeListCount2+10];
                cellEventTypeListTimeCount = 0;
                
                for (int counter1 = 0; counter1 < cellEventTypeListCount2; counter1++) cellEventTypeListTime [cellEventTypeListTimeCount] = (int)cellEventTypeList2 [counter1], cellEventTypeListTimeCount++;
                
                //for (int counterA = 0; counterA < cellEventTypeListTimeCount/19; counterA++){
                //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeListTime [counterA*19+counterB];
                //    cout<<" cellEventTypeListTime "<<counterA<<endl;
                //}
                
                cellNoListForSelectLingCount = 0;
                
                for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineagePositionNo]/9; counter2++){
                    if (arrayLineageData [lineagePositionNo][counter2*9] == 20 && arrayLineageData [lineagePositionNo][counter2*9+3] == 1){
                        cellNoListForSelectLing [cellNoListForSelectLingCount] = arrayLineageData [lineagePositionNo][counter2*9+6], cellNoListForSelectLingCount++;
                    }
                }
                
                int timeSetTemp = 0;
                
                for (int counter1 = 0; counter1 < cellEventTypeListCount2/19; counter1++){
                    for (long counter2 = cellEventTypeList2 [counter1*19+2]; counter2 <= cellEventTypeList2 [counter1*19+3]; counter2++){
                        timeSetTemp = arrayLineageData [lineagePositionNo][counter2*9+2];
                        cellGrowthCount [timeSetTemp*12]++;
                        
                        if (cellEventTypeList2 [counter1*19+8] != 0) cellGrowthCount [timeSetTemp*12+1]++;
                        if (cellEventTypeList2 [counter1*19+9] != 0) cellGrowthCount [timeSetTemp*12+2]++;
                        if (cellEventTypeList2 [counter1*19+10] != 0) cellGrowthCount [timeSetTemp*12+3]++;
                        if (cellEventTypeList2 [counter1*19+11] != 0) cellGrowthCount [timeSetTemp*12+4]++;
                        if (cellEventTypeList2 [counter1*19+12] != 0) cellGrowthCount [timeSetTemp*12+5]++;
                        if (cellEventTypeList2 [counter1*19+13] != 0) cellGrowthCount [timeSetTemp*12+6]++;
                        if (cellEventTypeList2 [counter1*19+14] != 0) cellGrowthCount [timeSetTemp*12+7]++;
                        if (cellEventTypeList2 [counter1*19+15] != 0) cellGrowthCount [timeSetTemp*12+8]++;
                        if (cellEventTypeList2 [counter1*19+16] != 0) cellGrowthCount [timeSetTemp*12+9]++;
                        if (cellEventTypeList2 [counter1*19+17] != 0) cellGrowthCount [timeSetTemp*12+10]++;
                        if (cellEventTypeList2 [counter1*19+18] != 0) cellGrowthCount [timeSetTemp*12+11]++;
                    }
                    
                    cellEventTypeListTime [counter1*19+2] = arrayLineageData [lineagePositionNo][cellEventTypeListTime [counter1*19+2]*9+2];
                    cellEventTypeListTime [counter1*19+3] = arrayLineageData [lineagePositionNo][cellEventTypeListTime [counter1*19+3]*9+2];
                }
                
                //for (int counterA = 0; counterA < timeEnd; counterA++){
                //    for (int counterB = 0; counterB < 12; counterB++) cout<<" "<<cellGrowthCount [counterA*12+counterB];
                //    cout<<" cellGrowthCount "<<counterA<<endl;
                //}
                
                //for (int counterA = 0; counterA < cellEventTypeListTimeCount/19; counterA++){
                //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeListTime [counterA*19+counterB];
                //    cout<<" cellEventTypeListTime "<<counterA<<endl;
                //}
                
                delete [] cellEventTypeList2;
                
                //----Horizontal Label----
                int horizontalTime = timeEnd;
                
                //----Horizontal Scale----
                double lengthDivision = horizontalTime/(double)5;
                int lengthDivisionInt = (int)lengthDivision;
                
                string lengthDivisionString = to_string(lengthDivisionInt).substr(0, 1);
                int lengthOfDiv = (int)(to_string(lengthDivisionInt).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt = atoi(lengthDivisionString.c_str());
                
                int scaleAdjust = 0;
                
                if (lengthDivisionInt >= 1000) scaleAdjust = 1;
                if (lengthDivisionInt >= 10000) scaleAdjust = 2;
                
                string timeString = "Time";
                
                if (scaleAdjust == 1) timeString = "Time (x10)";
                else if (scaleAdjust == 2) timeString = "Time (x100)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:11];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                CGFloat size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = 60+225-(size2/(double)2);
                pointA.y = 50-40;
                [attrStrA drawAtPoint:pointA];
                
                double lengthPix = ((450-10)/(double)horizontalTime)*lengthDivisionInt;
                int numberOfDivision = (int)((450-10)/(double)lengthPix)+1;
                
                double sift = 0;
                int lengthDivisionIntTemp = 0;
                
                NSPoint positionAA;
                NSPoint positionBB;
                NSPoint pointA2;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = 60+lengthPix*counter2;
                    positionAA.y = 50;
                    positionBB.x = 60+lengthPix*counter2;
                    positionBB.y = 50+5;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    lengthDivisionIntTemp = lengthDivisionInt;
                    
                    if (scaleAdjust == 1) lengthDivisionIntTemp = lengthDivisionInt/10;
                    else if (scaleAdjust == 2) lengthDivisionIntTemp = lengthDivisionInt/100;
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (60+lengthPix*counter2)-(size2/(double)2)-sift;
                    pointA2.y = 50-20;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                double maxVertical = (double)numberOfCellEnd;
                
                //for (int counterA = 0; counterA < fitCycleHold; counterA++){
                //    cout<<counterA<<" "<<arrayFitDataHold [counterA*4]<<" "<<arrayFitDataHold [counterA*4+1]<<" "<<arrayFitDataHold [counterA*4+2]<<" "<<arrayFitDataHold [counterA*4+3]<<" arrayFitDataHold"<<endl;
                //}
                
                //cout<<maxVertical<<" max"<<endl;
                
                //----Vertical Scale----
                unsigned long verticalNo = (unsigned long)(maxVertical*1.2);
                
                if (verticalNo < 10) verticalNo = 10;
                
                unsigned long lengthDivisionInt2 = (unsigned long)(verticalNo/(double)5);
                
                lengthDivisionString = to_string(lengthDivisionInt2).substr(0, 1);
                lengthOfDiv = (int)(to_string(lengthDivisionInt2).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt2 = (unsigned long)(atof(lengthDivisionString.c_str()));
                
                int maxLength = (int)(to_string(verticalNo).length());
                int scaleAdjustVer = 0;
                if (maxLength >= 4) scaleAdjustVer = maxLength-2;
                
                string lengthDivisionString2 = "1";
                
                for (int counter2 = 0; counter2 < scaleAdjustVer; counter2++){
                    lengthDivisionString2 = lengthDivisionString2+"0";
                }
                
                unsigned long verticalValueDiv = lengthDivisionInt2;
                
                if (scaleAdjustVer != 0) verticalValueDiv = (unsigned long)(atof(lengthDivisionString2.c_str()));
                
                double lengthPix2 = ((450-10)/(double)verticalNo)*lengthDivisionInt2;
                int numberOfDivision2 = (int)((450-10)/(double)lengthPix2)+1;
                int lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    positionAA.x = 60;
                    positionAA.y = 50+lengthPix2*counter2;
                    positionBB.x = 60+5;
                    positionBB.y = 50+lengthPix2*counter2;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    if (scaleAdjustVer == 0) lengthDivisionIntTemp = (int)verticalValueDiv;
                    else lengthDivisionIntTemp = (int)(lengthDivisionInt2/verticalValueDiv);
                    
                    NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                    size2 = [attrStrS3 size].width;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                    pointA2.x = 60-size2-10;
                    pointA2.y = 50+lengthPix2*counter2-5;
                    [attrStrA2 drawAtPoint:pointA2];
                    
                    if (lowestXPosition > 60-size2-10) lowestXPosition = (int)(60-size2-10);
                }
                
                //----Vertical Label----
                string labelDisplay = "Number of Cells";
                
                if (lengthDivisionString2.length() == 2) labelDisplay = "Number of Cells (x10)";
                else if (lengthDivisionString2.length() == 3) labelDisplay = "Number of Cells (x100)";
                else if (lengthDivisionString2.length() == 4) labelDisplay = "Number of Cells (x1000)";
                else if (lengthDivisionString2.length() >= 4){
                    int lengthTemp = (int)lengthDivisionString2.length()-1;
                    
                    labelDisplay = "Number of Cells (xe"+to_string(lengthTemp)+")";
                }
                
                NSString *verticalNSstring = @(labelDisplay.c_str());
                
                NSFont *font2 = [NSFont boldSystemFontOfSize:11];
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                NSGraphicsContext *context = [NSGraphicsContext currentContext];
                NSAffineTransform *transform = [NSAffineTransform transform];
                [transform rotateByDegrees:+90];
                
                [context saveGraphicsState];
                [transform concat];
                
                NSAttributedString *attrStrB;
                NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                NSString *titleStringB = @(labelDisplay.c_str());
                
                [attributesB setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                
                pointA.x = 50+(225-size2/(double)2);
                pointA.y = (lowestXPosition-10)*-1;
                [attrStrB drawAtPoint:pointA];
                
                [context restoreGraphicsState];
                
                double xPositionCenter = 0;
                double yPositionCenter = 0;
                string treatNameGR;
                
                [NSBezierPath setDefaultLineWidth:1.0];
                
                int colorDisplayCount = 1;
                int colorNumber = 1;
                
                if (simGraphModeHold == 0){
                    for (int counter2 = 1; counter2 <= 21; counter2 = counter2+2){
                        if (counter2 == 1){
                            [[NSColor blackColor] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellGrowthCount [counter3*12]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                [path stroke];
                            }
                        }
                        
                        if (simColorDataHold [counter2] != 0 && simColorDataHold [counter2] != 3){
                            colorNumber = simColorDataHold [counter2];
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNumber*3] green:arrayColorRange2 [colorNumber*3+1] blue:arrayColorRange2 [colorNumber*3+2] alpha:1] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellGrowthCount [counter3*12+colorDisplayCount]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                [path stroke];
                            }
                        }
                        
                        colorDisplayCount++;
                    }
                }
                else{
                    
                    int *cellNoList = new int [horizontalTime*2+10];
                    
                    for (int counter2 = 0; counter2 < horizontalTime*2+10; counter2++) cellNoList [counter2] = 0;
                    
                    int findFlag = 0;
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineagePositionNo]/9; counter2++){
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListForSelectLingCount; counter3++){
                            if (cellNoListForSelectLing [counter3] == arrayLineageData [lineagePositionNo][counter2*9+6]){
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 1){
                            cellNoList [arrayLineageData [lineagePositionNo][counter2*9+2]*2+1]++;
                        }
                        else{
                            
                            cellNoList [arrayLineageData [lineagePositionNo][counter2*9+2]*2]++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < 2; counter2++){
                        if (counter2 == 0){
                            [[NSColor blackColor] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellNoList [counter3*2]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                [path stroke];
                            }
                        }
                        
                        if (counter2 == 1){
                            colorNumber = colorNoSimHold;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNumber*3] green:arrayColorRange2 [colorNumber*3+1] blue:arrayColorRange2 [colorNumber*3+2] alpha:1] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellNoList [counter3*2+1]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                [path stroke];
                            }
                        }
                    }
                    
                    delete [] cellNoList;
                }
            }
        }
    }
    else if (exportFlag10 == 1){
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:539*magFactor pixelsHigh:539*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:539*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 537*magFactor, 537*magFactor)];
        [path fill];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:12*magFactor] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        if (simulationOperation != 0){
            if (processSimType == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5*magFactor];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(60*magFactor, 50*magFactor, 450*magFactor, 450*magFactor)];
                [path stroke];
                
                //----Horizontal Label----
                int horizontalTime = fitDataHoldCount/4-1;
                
                //----Horizontal Scale----
                double lengthDivision = horizontalTime/(double)5;
                int lengthDivisionInt = (int)lengthDivision;
                
                string lengthDivisionString = to_string(lengthDivisionInt).substr(0, 1);
                int lengthOfDiv = (int)(to_string(lengthDivisionInt).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt = atoi(lengthDivisionString.c_str());
                
                int scaleAdjust = 0;
                
                if (lengthDivisionInt >= 1000) scaleAdjust = 1;
                if (lengthDivisionInt >= 10000) scaleAdjust = 2;
                
                string timeString = "Time";
                
                if (scaleAdjust == 1) timeString = "Time (x10)";
                else if (scaleAdjust == 2) timeString = "Time (x100)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:11];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                CGFloat size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = 60*magFactor+225*magFactor-(size2/(double)2);
                pointA.y = 50*magFactor-40*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                double lengthPix = ((450-10)/(double)horizontalTime)*lengthDivisionInt;
                int numberOfDivision = (int)((450-10)/(double)lengthPix)+1;
                
                double sift = 0;
                int lengthDivisionIntTemp = 0;
                
                NSPoint positionAA;
                NSPoint positionBB;
                NSPoint pointA2;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = 60*magFactor+lengthPix*counter2*magFactor;
                    positionAA.y = 50*magFactor;
                    positionBB.x = 60*magFactor+lengthPix*counter2*magFactor;
                    positionBB.y = 50*magFactor+5*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    lengthDivisionIntTemp = lengthDivisionInt;
                    
                    if (scaleAdjust == 1) lengthDivisionIntTemp = lengthDivisionInt/10;
                    else if (scaleAdjust == 2) lengthDivisionIntTemp = lengthDivisionInt/100;
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (60*magFactor+lengthPix*counter2*magFactor)-(size2/(double)2)*magFactor-sift*magFactor;
                    pointA2.y = 50*magFactor-20*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                double maxVertical = 0;
                
                for (int counter2 = 1; counter2 < fitDataHoldCount/4; counter2++){
                    if (maxVertical < arrayFitDataHold [counter2*4]) maxVertical = arrayFitDataHold [counter2*4];
                    if (arrayFitDataHold [1] == -1 && maxVertical < arrayFitDataHold [counter2*4+1]) maxVertical = arrayFitDataHold [counter2*4+1];
                    if (arrayFitDataHold [2] == -1 && maxVertical < arrayFitDataHold [counter2*4+2]) maxVertical = arrayFitDataHold [counter2*4+2];
                    if (arrayFitDataHold [3] == -1 && maxVertical < arrayFitDataHold [counter2*4+3]) maxVertical = arrayFitDataHold [counter2*4+3];
                }
                
                //for (int counterA = 0; counterA < fitCycleHold; counterA++){
                //    cout<<counterA<<" "<<arrayFitDataHold [counterA*4]<<" "<<arrayFitDataHold [counterA*4+1]<<" "<<arrayFitDataHold [counterA*4+2]<<" "<<arrayFitDataHold [counterA*4+3]<<" arrayFitDataHold"<<endl;
                //}
                
                //cout<<maxVertical<<" max"<<endl;
                
                //----Vertical Scale----
                unsigned long verticalNo = (unsigned long)(maxVertical*1.2);
                
                if (verticalNo < 10) verticalNo = 10;
                
                unsigned long lengthDivisionInt2 = (unsigned long)(verticalNo/(double)5);
                
                lengthDivisionString = to_string(lengthDivisionInt2).substr(0, 1);
                lengthOfDiv = (int)(to_string(lengthDivisionInt2).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt2 = (unsigned long)(atof(lengthDivisionString.c_str()));
                
                int maxLength = (int)(to_string(verticalNo).length());
                int scaleAdjustVer = 0;
                if (maxLength >= 4) scaleAdjustVer = maxLength-2;
                
                string lengthDivisionString2 = "1";
                
                for (int counter2 = 0; counter2 < scaleAdjustVer; counter2++){
                    lengthDivisionString2 = lengthDivisionString2+"0";
                }
                
                unsigned long verticalValueDiv = lengthDivisionInt2;
                
                if (scaleAdjustVer != 0) verticalValueDiv = (unsigned long)(atof(lengthDivisionString2.c_str()));
                
                double lengthPix2 = ((450-10)/(double)verticalNo)*lengthDivisionInt2;
                int numberOfDivision2 = (int)((450-10)/(double)lengthPix2)+1;
                int lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    positionAA.x = 60*magFactor;
                    positionAA.y = 50*magFactor+lengthPix2*counter2*magFactor;
                    positionBB.x = 60*magFactor+5*magFactor;
                    positionBB.y = 50*magFactor+lengthPix2*counter2*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    if (scaleAdjustVer == 0) lengthDivisionIntTemp = (int)verticalValueDiv;
                    else lengthDivisionIntTemp = (int)(lengthDivisionInt2/verticalValueDiv);
                    
                    NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                    size2 = [attrStrS3 size].width;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                    pointA2.x = 60*magFactor-size2*magFactor-10*magFactor;
                    pointA2.y = 50*magFactor+lengthPix2*counter2*magFactor-5*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                    
                    if (lowestXPosition > 60-size2-10) lowestXPosition = (int)(60-size2-10);
                }
                
                //----Vertical Label----
                string labelDisplay = "Number of Cells";
                
                if (lengthDivisionString2.length() == 2) labelDisplay = "Number of Cells (x10)";
                else if (lengthDivisionString2.length() == 3) labelDisplay = "Number of Cells (x100)";
                else if (lengthDivisionString2.length() == 4) labelDisplay = "Number of Cells (x1000)";
                else if (lengthDivisionString2.length() >= 4){
                    int lengthTemp = (int)lengthDivisionString2.length()-1;
                    
                    labelDisplay = "Number of Cells (xe"+to_string(lengthTemp)+")";
                }
                
                NSString *verticalNSstring = @(labelDisplay.c_str());
                
                NSFont *font2 = [NSFont boldSystemFontOfSize:11*magFactor];
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                NSGraphicsContext *context = [NSGraphicsContext currentContext];
                NSAffineTransform *transform = [NSAffineTransform transform];
                [transform rotateByDegrees:+90];
                
                [context saveGraphicsState];
                [transform concat];
                
                NSAttributedString *attrStrB;
                NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                NSString *titleStringB = @(labelDisplay.c_str());
                
                [attributesB setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                
                pointA.x = 50*magFactor+(225*magFactor-size2/(double)2);
                pointA.y = ((lowestXPosition-10)*-1)*magFactor;
                [attrStrB drawAtPoint:pointA];
                
                [context restoreGraphicsState];
                
                double xPositionCenter = 0;
                double yPositionCenter = 0;
                string treatNameGR;
                
                [NSBezierPath setDefaultLineWidth:1.0*magFactor];
                
                for (int counter2 = 0; counter2 < 4; counter2++){
                    if (counter2 == 0) [[NSColor blueColor] set];
                    else if (counter2 == 1) [[NSColor redColor] set];
                    else if (counter2 == 2) [[NSColor orangeColor] set];
                    else if (counter2 == 3) [[NSColor brownColor] set];
                    
                    for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                        xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                        yPositionCenter = ((450-10)/(double)verticalNo)*(double)arrayFitDataHold [counter3*4+counter2]+50;
                        
                        if (xPositionCenter > 60 && xPositionCenter < 60+450 && yPositionCenter > 50 && yPositionCenter < 50+450 && arrayFitDataHold [counter3*4+counter2] != -2){
                            path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter*magFactor, yPositionCenter*magFactor, 1*magFactor, 1*magFactor)];
                            [path stroke];
                        }
                    }
                }
            }
            else if (processSimType == 2){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5*magFactor];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(60*magFactor, 50*magFactor, 450*magFactor, 450*magFactor)];
                [path stroke];
                
                //----Horizontal Label----
                int horizontalTime = cellGrowthCountTimeEnd;
                
                //----Horizontal Scale----
                double lengthDivision = horizontalTime/(double)5;
                int lengthDivisionInt = (int)lengthDivision;
                
                string lengthDivisionString = to_string(lengthDivisionInt).substr(0, 1);
                int lengthOfDiv = (int)(to_string(lengthDivisionInt).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt = atoi(lengthDivisionString.c_str());
                
                int scaleAdjust = 0;
                
                if (lengthDivisionInt >= 1000) scaleAdjust = 1;
                if (lengthDivisionInt >= 10000) scaleAdjust = 2;
                
                string timeString = "Time";
                
                if (scaleAdjust == 1) timeString = "Time (x10)";
                else if (scaleAdjust == 2) timeString = "Time (x100)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:11];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                CGFloat size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = 60*magFactor+225*magFactor-(size2/(double)2);
                pointA.y = 50*magFactor-40*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                double lengthPix = ((450-10)/(double)horizontalTime)*lengthDivisionInt;
                int numberOfDivision = (int)((450-10)/(double)lengthPix)+1;
                
                double sift = 0;
                int lengthDivisionIntTemp = 0;
                
                NSPoint positionAA;
                NSPoint positionBB;
                NSPoint pointA2;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = 60*magFactor+lengthPix*counter2*magFactor;
                    positionAA.y = 50*magFactor;
                    positionBB.x = 60*magFactor+lengthPix*counter2*magFactor;
                    positionBB.y = 50*magFactor+5*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    lengthDivisionIntTemp = lengthDivisionInt;
                    
                    if (scaleAdjust == 1) lengthDivisionIntTemp = lengthDivisionInt/10;
                    else if (scaleAdjust == 2) lengthDivisionIntTemp = lengthDivisionInt/100;
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (60*magFactor+lengthPix*counter2*magFactor)-(size2/(double)2)*magFactor-sift*magFactor;
                    pointA2.y = 50*magFactor-20*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                double maxVertical = (double)cellGrowthCount [cellGrowthCountTimeEnd*12];
                
                //cout<<maxVertical<<" max"<<endl;
                
                //----Vertical Scale----
                unsigned long verticalNo = (unsigned long)(maxVertical*1.2);
                
                if (verticalNo < 10) verticalNo = 10;
                
                unsigned long lengthDivisionInt2 = (unsigned long)(verticalNo/(double)5);
                
                lengthDivisionString = to_string(lengthDivisionInt2).substr(0, 1);
                lengthOfDiv = (int)(to_string(lengthDivisionInt2).length());
                
                for (int counter2 = 0; counter2 < lengthOfDiv-1; counter2++){
                    lengthDivisionString = lengthDivisionString+"0";
                }
                
                lengthDivisionInt2 = (unsigned long)(atof(lengthDivisionString.c_str()));
                
                int maxLength = (int)(to_string(verticalNo).length());
                int scaleAdjustVer = 0;
                if (maxLength >= 4) scaleAdjustVer = maxLength-2;
                
                string lengthDivisionString2 = "1";
                
                for (int counter2 = 0; counter2 < scaleAdjustVer; counter2++){
                    lengthDivisionString2 = lengthDivisionString2+"0";
                }
                
                unsigned long verticalValueDiv = lengthDivisionInt2;
                
                if (scaleAdjustVer != 0) verticalValueDiv = (unsigned long)(atof(lengthDivisionString2.c_str()));
                
                double lengthPix2 = ((450-10)/(double)verticalNo)*lengthDivisionInt2;
                int numberOfDivision2 = (int)((450-10)/(double)lengthPix2)+1;
                int lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    positionAA.x = 60*magFactor;
                    positionAA.y = 50*magFactor+lengthPix2*counter2*magFactor;
                    positionBB.x = 60*magFactor+5*magFactor;
                    positionBB.y = 50*magFactor+lengthPix2*counter2*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    if (scaleAdjustVer == 0) lengthDivisionIntTemp = (int)verticalValueDiv;
                    else lengthDivisionIntTemp = (int)(lengthDivisionInt2/verticalValueDiv);
                    
                    NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionIntTemp).c_str());
                    NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                    size2 = [attrStrS3 size].width;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                    pointA2.x = 60*magFactor-size2*magFactor-10*magFactor;
                    pointA2.y = 50*magFactor+lengthPix2*counter2*magFactor-5*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                    
                    if (lowestXPosition > 60-size2-10) lowestXPosition = (int)(60-size2-10);
                }
                
                //----Vertical Label----
                string labelDisplay = "Number of Cells";
                
                if (lengthDivisionString2.length() == 2) labelDisplay = "Number of Cells (x10)";
                else if (lengthDivisionString2.length() == 3) labelDisplay = "Number of Cells (x100)";
                else if (lengthDivisionString2.length() == 4) labelDisplay = "Number of Cells (x1000)";
                else if (lengthDivisionString2.length() >= 4){
                    int lengthTemp = (int)lengthDivisionString2.length()-1;
                    
                    labelDisplay = "Number of Cells (xe"+to_string(lengthTemp)+")";
                }
                
                NSString *verticalNSstring = @(labelDisplay.c_str());
                
                NSFont *font2 = [NSFont boldSystemFontOfSize:11*magFactor];
                NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                size2 = [attrStrS2 size].width;
                
                NSGraphicsContext *context = [NSGraphicsContext currentContext];
                NSAffineTransform *transform = [NSAffineTransform transform];
                [transform rotateByDegrees:+90];
                
                [context saveGraphicsState];
                [transform concat];
                
                NSAttributedString *attrStrB;
                NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                NSString *titleStringB = @(labelDisplay.c_str());
                
                [attributesB setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                
                pointA.x = 50*magFactor+(225*magFactor-size2/(double)2);
                pointA.y = ((lowestXPosition-10)*-1)*magFactor;
                [attrStrB drawAtPoint:pointA];
                
                [context restoreGraphicsState];
                
                double xPositionCenter = 0;
                double yPositionCenter = 0;
                string treatNameGR;
                
                [NSBezierPath setDefaultLineWidth:1.0*magFactor];
                
                int colorDisplayCount = 1;
                int colorNumber = 1;
                
                if (simGraphModeHold == 0){
                    for (int counter2 = 1; counter2 <= 21; counter2 = counter2+2){
                        if (counter2 == 1){
                            [[NSColor blackColor] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellGrowthCount [counter3*12]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter*magFactor, yPositionCenter*magFactor, 1*magFactor, 1*magFactor)];
                                [path stroke];
                            }
                        }
                        
                        if (simColorDataHold [counter2] != 0 && simColorDataHold [counter2] != 3){
                            colorNumber = simColorDataHold [counter2];
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNumber*3] green:arrayColorRange2 [colorNumber*3+1] blue:arrayColorRange2 [colorNumber*3+2] alpha:1] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellGrowthCount [counter3*12+colorDisplayCount]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter*magFactor, yPositionCenter*magFactor, 1*magFactor, 1*magFactor)];
                                [path stroke];
                            }
                        }
                        
                        colorDisplayCount++;
                    }
                }
                else{
                    
                    int lineagePositionNo = simOperationTableCurrentRow;
                    
                    int *cellNoList = new int [horizontalTime*2+10];
                    
                    for (int counter2 = 0; counter2 < horizontalTime*2+10; counter2++) cellNoList [counter2] = 0;
                    
                    int findFlag = 0;
                    
                    for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineagePositionNo]/9; counter2++){
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListForSelectLingCount; counter3++){
                            if (cellNoListForSelectLing [counter3] == arrayLineageData [lineagePositionNo][counter2*9+6]){
                                findFlag = 1;
                                break;
                            }
                        }
                        
                        if (findFlag == 1){
                            cellNoList [arrayLineageData [lineagePositionNo][counter2*9+2]*2+1]++;
                        }
                        else{
                            
                            cellNoList [arrayLineageData [lineagePositionNo][counter2*9+2]*2]++;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < 2; counter2++){
                        if (counter2 == 0){
                            [[NSColor blackColor] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellNoList [counter3*2]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                [path stroke];
                            }
                        }
                        
                        if (counter2 == 1){
                            colorNumber = colorNoSimHold;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange2 [colorNumber*3] green:arrayColorRange2 [colorNumber*3+1] blue:arrayColorRange2 [colorNumber*3+2] alpha:1] set];
                            
                            for (int counter3 = 1; counter3 <= horizontalTime; counter3++){
                                xPositionCenter = ((450-10)/(double)horizontalTime)*counter3+60;
                                yPositionCenter = ((450-10)/(double)verticalNo)*(double)cellNoList [counter3*2+1]+50;
                                
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xPositionCenter, yPositionCenter, 1, 1)];
                                [path stroke];
                            }
                        }
                    }
                    
                    delete [] cellNoList;
                }
            }
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        exportFlag10 = 2;
    }
    else if (exportFlag10 == 100){
        if (imageSimNoCount == 1){
            int randInit = 0;
            
            int dimensionPercent10 = (int)(simDimension*(double)0.1);
            int newDimension = (simDimension-dimensionPercent10*2)/10;
            
            int *dimensionList = new int [newDimension*newDimension*6+10];
            int newDimensionCount = 0;
            int newDimensionCountHold = 0;
            int entryCount = 0;
            
            for (int counter1 = 0; counter1 < newDimension; counter1++){
                for (int counter2 = 0; counter2 < newDimension; counter2++){
                    dimensionList [newDimensionCount] = counter1, newDimensionCount++;
                    dimensionList [newDimensionCount] = counter2, newDimensionCount++;
                    dimensionList [newDimensionCount] = entryCount, newDimensionCount++;
                    dimensionList [newDimensionCount] = 0, newDimensionCount++; //---Ling
                    dimensionList [newDimensionCount] = 0, newDimensionCount++; //--Cell
                    dimensionList [newDimensionCount] = 0, newDimensionCount++; //--Type
                    
                    entryCount++;
                }
            }
            
            newDimensionCountHold = newDimensionCount/6;
            
            int newCount = 0;
            int maxCount = newDimensionCount/6;
            
            if (maxCount != 0){
                for (int counter2 = 0; counter2 < cellEventTypeListTimeCount/19; counter2++){
                    if (cellEventTypeListTime [counter2*19+2] == 1){
                        randInit = rand() % maxCount + 0;
                        
                        for (int counter3 = 0; counter3 < newDimensionCountHold; counter3++){
                            if (dimensionList [counter3*6+2] == randInit){
                                dimensionList [counter3*6+3] = cellEventTypeListTime [counter2*19]; //---Ling
                                dimensionList [counter3*6+4] = cellEventTypeListTime [counter2*19+1]; //--Cell
                                dimensionList [counter3*6+5] = cellEventTypeListTime [counter2*19+8]; //--Type
                                
                                dimensionList [counter3*6+2] = -1;
                                newCount = randInit;
                                
                                for (int counter4 = counter3+1; counter4 < newDimensionCountHold; counter4++){
                                    if (dimensionList [counter4*6+2] != -1){
                                        dimensionList [counter4*6+2] = newCount;
                                        newCount++;
                                    }
                                }
                                
                                maxCount--;
                                break;
                            }
                        }
                        
                        if (maxCount == 0){
                            break;
                        }
                    }
                }
                
                int positionX = 0;
                int positionY = 0;
                
                for (int counter1 = 0; counter1 < newDimensionCountHold; counter1++){
                    if (dimensionList [counter1*6+2] == -1){
                        positionX = dimensionList [counter1*6+1]*10+dimensionPercent10;
                        positionY = dimensionList [counter1*6]*10+dimensionPercent10;
                        
                        if (dimensionList [counter1*6+5] == 0){
                            mapPositionHeld [positionY][positionX] = -1;
                        }
                        else mapPositionHeld [positionY][positionX] = dimensionList [counter1*6+5];
                        
                        mapCellNoHeld [positionY][positionX] = dimensionList [counter1*6+4];
                        mapLingNoHeld [positionY][positionX] = dimensionList [counter1*6+3];
                    }
                }
            }
            
            delete [] dimensionList;
        }
        else{
            
            int moveLimit = movieDistanceSet;
            
            if (movieDistanceRedStatus == 1){
                moveLimit = (int)(movieDistanceSet-((movieDistanceSet-1)/(double)cellGrowthCountTimeEnd)*imageSimNoCount);
                
                if (moveLimit < 1) moveLimit = 1;
            }
            
            int newDimensionCount = 0;
            int newDimensionCountHold = 0;
            int entryCount = 0;
            int randInit = 0;
            
            int *dimensionList = new int [((moveLimit+20)*2)*((moveLimit+20)*2)*3+10];
            
            for (int counter2 = 0; counter2 < simDimension; counter2++){
                for (int counter3 = 0; counter3 < simDimension; counter3++){
                    if (mapPositionHeld [counter2][counter3] != 0){
                        entryCount = 0;
                        newDimensionCount = 0;
                        
                        for (int counter4 = counter2-moveLimit; counter4 <= counter2+moveLimit; counter4++){
                            for (int counter5 = counter3-moveLimit; counter5 <= counter3+moveLimit; counter5++){
                                if (counter4 > 1 && counter4 < simDimension-1 && counter5 > 1 && counter5 < simDimension-1){
                                    if (mapPositionHeld [counter4][counter5] == 0){
                                        dimensionList [newDimensionCount] = counter4, newDimensionCount++;
                                        dimensionList [newDimensionCount] = counter5, newDimensionCount++;
                                        dimensionList [newDimensionCount] = entryCount, newDimensionCount++;
                                        entryCount++;
                                    }
                                }
                            }
                        }
                        
                        newDimensionCountHold = entryCount;
                        
                        if (entryCount != 0){
                            randInit = rand() % newDimensionCountHold + 0;
                            mapPositionHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = mapPositionHeld [counter2][counter3];
                            mapCellNoHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = mapCellNoHeld [counter2][counter3];
                            mapLingNoHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = mapLingNoHeld [counter2][counter3];
                            
                            mapPositionHeld [counter2][counter3] = 0;
                            mapCellNoHeld [counter2][counter3] = 0;
                            mapLingNoHeld [counter2][counter3] = 0;
                        }
                    }
                }
            }
            
            //for (int counterA = 0; counterA < cellEventTypeListTimeCount/19; counterA++){
            //    for (int counterB = 0; counterB < 19; counterB++) cout<<" "<<cellEventTypeListTime [counterA*19+counterB];
            //    cout<<" cellEventTypeListTime "<<counterA<<endl;
            //}
            
            int breakFlag = 0;
            int positionX = 0;
            int positionY = 0;
            string lastDigit;
            
            for (int counter2 = 0; counter2 < cellEventTypeListTimeCount/19; counter2++){
                if (cellEventTypeListTime [counter2*19+2] == imageSimNoCount){
                    if (cellEventTypeListTime [counter2*19+4] == 31 || cellEventTypeListTime [counter2*19+4] == 41 || cellEventTypeListTime [counter2*19+4] == 51){
                        positionX = 0;
                        positionY = 0;
                        
                        for (int counter3 = 0; counter3 < cellEventTypeListTimeCount/19; counter3++){
                            if (cellEventTypeListTime [counter2*19+7] == cellEventTypeListTime [counter3*19+1] && cellEventTypeListTime [counter2*19] == cellEventTypeListTime [counter3*19]){
                                positionX = cellEventTypeListTime [counter3*19+17];
                                positionY = cellEventTypeListTime [counter3*19+18];
                                break;
                            }
                        }
                        
                        entryCount = 0;
                        newDimensionCount = 0;
                        
                        for (int counter4 = positionY-moveLimit; counter4 <= positionY+moveLimit; counter4++){
                            for (int counter5 = positionX-moveLimit; counter5 <= positionX+moveLimit; counter5++){
                                if (counter4 > 1 && counter4 < simDimension-1 && counter5 > 1 && counter5 < simDimension-1){
                                    if (mapPositionHeld [counter4][counter5] == 0){
                                        dimensionList [newDimensionCount] = counter4, newDimensionCount++;
                                        dimensionList [newDimensionCount] = counter5, newDimensionCount++;
                                        dimensionList [newDimensionCount] = entryCount, newDimensionCount++;
                                        entryCount++;
                                    }
                                }
                            }
                        }
                        
                        newDimensionCountHold = entryCount;
                        
                        if (entryCount != 0){
                            randInit = rand() % newDimensionCountHold + 0;
                            
                            if (cellEventTypeListTime [counter2*19+8] == 0) mapPositionHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = -1;
                            else mapPositionHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = cellEventTypeListTime [counter2*19+8];
                            
                            mapCellNoHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = cellEventTypeListTime [counter2*19+1];
                            mapLingNoHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = cellEventTypeListTime [counter2*19];
                        }
                        else{
                            
                            entryCount = 0;
                            newDimensionCount = 0;
                            
                            delete [] dimensionList;
                            dimensionList = new int [((moveLimit*2+20)*2)*((moveLimit*2+20)*2)*3+10];
                            
                            for (int counter4 = positionY-moveLimit-moveLimit; counter4 <= positionY+moveLimit+moveLimit; counter4++){
                                for (int counter5 = positionX-moveLimit-moveLimit; counter5 <= positionX+moveLimit+moveLimit; counter5++){
                                    if (counter4 > 1 && counter4 < simDimension-1 && counter5 > 1 && counter5 < simDimension-1){
                                        if (mapPositionHeld [counter4][counter5] == 0){
                                            dimensionList [newDimensionCount] = counter4, newDimensionCount++;
                                            dimensionList [newDimensionCount] = counter5, newDimensionCount++;
                                            dimensionList [newDimensionCount] = entryCount, newDimensionCount++;
                                            entryCount++;
                                        }
                                    }
                                }
                            }
                            
                            newDimensionCountHold = entryCount;
                            
                            if (entryCount != 0){
                                randInit = rand() % newDimensionCountHold + 0;
                                
                                if (cellEventTypeListTime [counter2*19+8] == 0) mapPositionHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = -1;
                                else mapPositionHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = cellEventTypeListTime [counter2*19+8];
                                
                                mapCellNoHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = cellEventTypeListTime [counter2*19+1];
                                mapLingNoHeld [dimensionList [randInit*3]][dimensionList [randInit*3+1]] = cellEventTypeListTime [counter2*19];
                            }
                        }
                    }
                }
                
                if (cellEventTypeListTime [counter2*19+3] == imageSimNoCount){
                    if (cellEventTypeListTime [counter2*19+5] == 32 || cellEventTypeListTime [counter2*19+5] == 42 || cellEventTypeListTime [counter2*19+5] == 52){
                        breakFlag = 0;
                        
                        for (int counter3 = 0; counter3 < simDimension; counter3++){
                            for (int counter4 = 0; counter4 < simDimension; counter4++){
                                if (mapCellNoHeld [counter3][counter4] == cellEventTypeListTime [counter2*19+1] && mapLingNoHeld [counter3][counter4] == cellEventTypeListTime [counter2*19]){
                                    if (mapPositionHeld [counter3][counter4] == -1) mapPositionHeld [counter3][counter4] = -500;
                                    else mapPositionHeld [counter3][counter4] = mapPositionHeld [counter3][counter4]+500;
                                    
                                    cellEventTypeListTime [counter2*19+17] = counter4;
                                    cellEventTypeListTime [counter2*19+18] = counter3;
                                    
                                    breakFlag = 1;
                                    break;
                                }
                            }
                            
                            if (breakFlag == 1){
                                break;
                            }
                        }
                    }
                    else if (cellEventTypeListTime [counter2*19+5] == 7 || cellEventTypeListTime [counter2*19+5] == 8 || cellEventTypeListTime [counter2*19+5] == 91){
                        for (int counter3 = 0; counter3 < simDimension; counter3++){
                            for (int counter4 = 0; counter4 < simDimension; counter4++){
                                breakFlag = 0;
                                
                                if (mapCellNoHeld [counter3][counter4] == cellEventTypeListTime [counter2*19+1] && mapLingNoHeld [counter3][counter4] == cellEventTypeListTime [counter2*19]){
                                    if (cellEventTypeListTime [counter2*19+5] != 7){
                                        mapPositionHeld [counter3][counter4] = 0;
                                        mapCellNoHeld [counter3][counter4] = 0;
                                        mapLingNoHeld [counter3][counter4] = 0;
                                        breakFlag = 1;
                                        break;
                                    }
                                    else{
                                        
                                        if (mapPositionHeld [counter3][counter4] > 0){
                                            if (mapPositionHeld [counter3][counter4] == -1) mapPositionHeld [counter3][counter4] = mapPositionHeld [counter3][counter4]*1000-9;
                                            else mapPositionHeld [counter3][counter4] = mapPositionHeld [counter3][counter4]*1000+9;
                                            
                                            breakFlag = 1;
                                            break;
                                        }
                                        else{
                                            
                                            mapPositionHeld [counter3][counter4] = 0;
                                            mapCellNoHeld [counter3][counter4] = 0;
                                            mapLingNoHeld [counter3][counter4] = 0;
                                            breakFlag = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            if (breakFlag == 1){
                                break;
                            }
                        }
                    }
                }
            }
            
            delete [] dimensionList;
            
            for (int counter3 = 0; counter3 < simDimension; counter3++){
                for (int counter4 = 0; counter4 < simDimension; counter4++){
                    if (mapPositionHeld [counter3][counter4] < -1000 || mapPositionHeld [counter3][counter4] > 1000){
                        lastDigit = to_string(mapPositionHeld [counter3][counter4]);
                        lastDigit = lastDigit.substr(lastDigit.length()-1);
                        
                        if (atoi(lastDigit.c_str()) > 1){
                            if (mapPositionHeld [counter3][counter4] < -1000) mapPositionHeld [counter3][counter4] = mapPositionHeld [counter3][counter4]+1;
                            else mapPositionHeld [counter3][counter4] = mapPositionHeld [counter3][counter4]-1;
                        }
                        else{
                            
                            mapPositionHeld [counter3][counter4] = 0;
                            mapCellNoHeld [counter3][counter4] = 0;
                            mapLingNoHeld [counter3][counter4] = 0;
                        }
                    }
                }
            }
        }
        
        int colorNumber = 0;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:simDimension pixelsHigh:simDimension bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:simDimension*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, simDimension, simDimension)];
        [path fill];
        
        CGFloat circleSizeDetermine = circleSizeHold;
        
        if (circleSizeRedStatus == 1 && circleSizeHold > circleMinHold){
            if (circleMinHold == 0) circleMinHold = 1;
            
            circleSizeDetermine = (CGFloat)((circleSizeHold-((circleSizeHold-circleMinHold)/(double)cellGrowthCountTimeEnd)*imageSimNoCount));
            
            if (circleSizeDetermine < 1) circleSizeDetermine = 1;
        }
        
        int otherColorFound = 0;
        int *topColorFind = new int [50];
        
        CGFloat arrayColorRangeR = 0;
        CGFloat arrayColorRangeG = 0;
        CGFloat arrayColorRangeB = 0;
        double addSub = 0;
        
        if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 3) addSub = 20/(double)255;
        else if (colorToneChangeOptionHold == 2 || colorToneChangeOptionHold == 4) addSub = 40/(double)255;
        
        for (int counter3 = 0; counter3 < 50; counter3++) topColorFind [counter3] = 0;
        
        for (int counter3 = 0; counter3 < simDimension; counter3++){
            for (int counter4 = 0; counter4 < simDimension; counter4++){
                if (mapPositionHeld [counter3][counter4] < 1000 && mapPositionHeld [counter3][counter4] > -1000 && mapPositionHeld [counter3][counter4] != 0 && mapPositionHeld [counter3][counter4] != 500){
                    if (videoColorStatus == 0){
                        if (mapPositionHeld [counter3][counter4] == -1) colorNumber = 3;
                        else if (mapPositionHeld [counter3][counter4] == -500) colorNumber = 3;
                        else if (mapPositionHeld [counter3][counter4] > 500) colorNumber = simColorDataHold [mapPositionHeld [counter3][counter4]-500-1];
                        else if (mapPositionHeld [counter3][counter4] < 1000) colorNumber = simColorDataHold [mapPositionHeld [counter3][counter4]-1];
                        else colorNumber = -1;
                        
                        if (colorNumber != -1){
                            if (colorNumber == 0) colorNumber = 3;
                            if (colorNumber != 3) otherColorFound = 1;
                            
                            topColorFind [colorNumber]++;
                            
                            arrayColorRangeR = arrayColorRange2 [colorNumber*3];
                            arrayColorRangeG = arrayColorRange2 [colorNumber*3+1];
                            arrayColorRangeB = arrayColorRange2 [colorNumber*3+2];
                            
                            if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                    if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                    else arrayColorRangeR = 1.0;
                                    
                                    if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                    else arrayColorRangeG = 1.0;
                                    
                                    if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                    else arrayColorRangeB = 1.0;
                                }
                                else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                    if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                    else arrayColorRangeR = 0;
                                    
                                    if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                    else arrayColorRangeG = 0;
                                    
                                    if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                    else arrayColorRangeB = 0;
                                }
                            }
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                        }
                    }
                    else{
                        
                        if (colorNumber != 3 && videoColorStatus == 2) otherColorFound = 1;
                        
                        arrayColorRangeR = lingColorListSim [mapLingNoHeld [counter3][counter4]*4];
                        arrayColorRangeG = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+1];
                        arrayColorRangeB = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+2];
                        
                        if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                            if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                else arrayColorRangeR = 1.0;
                                
                                if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                else arrayColorRangeG = 1.0;
                                
                                if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                else arrayColorRangeB = 1.0;
                            }
                            else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                else arrayColorRangeR = 0;
                                
                                if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                else arrayColorRangeG = 0;
                                
                                if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                else arrayColorRangeB = 0;
                            }
                        }
                        
                        [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                    }
                    
                    path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(counter4, counter3, circleSizeDetermine, circleSizeDetermine)];
                    [path fill];
                }
            }
        }
        
        int topColorNumber = 0;
        int topColorCount = 10000;
        
        for (int counter3 = 0; counter3 < 50; counter3++){
            if (topColorFind [counter3] != 0 && topColorFind [counter3] < topColorCount && counter3 != 3){
                topColorNumber = counter3;
                topColorCount = topColorFind [counter3];
            }
        }
        
        delete [] topColorFind;
        
        string lastDigit;
        int colorCodeExt = 0;
        int circleSizePix = (int)(circleSizeDetermine*2*1.25);
        int *flashPosition = new int [circleSizePix*circleSizePix*3+1000];
        int flashPositionCount = 0;
        int randInit = 0;
        CGFloat circleSizeDetermine2 = 0;
        
        if ((videoColorStatus == 0 || videoColorStatus == 2) && otherColorFound == 1){
            //----Redraw color circles on the top of gray----
            for (int counter3 = 0; counter3 < simDimension; counter3++){
                for (int counter4 = 0; counter4 < simDimension; counter4++){
                    if (mapPositionHeld [counter3][counter4] != 0){
                        if (mapPositionHeld [counter3][counter4] < 1000 && mapPositionHeld [counter3][counter4] > -1000 && mapPositionHeld [counter3][counter4] != 0 && mapPositionHeld [counter3][counter4] != 500){
                            if (videoColorStatus == 0){
                                if (mapPositionHeld [counter3][counter4] == -1) colorNumber = 3;
                                else if (mapPositionHeld [counter3][counter4] == -500) colorNumber = 3;
                                else if (mapPositionHeld [counter3][counter4] > 500) colorNumber = simColorDataHold [mapPositionHeld [counter3][counter4]-500-1];
                                else if (mapPositionHeld [counter3][counter4] < 1000) colorNumber = simColorDataHold [mapPositionHeld [counter3][counter4]-1];
                                
                                if (colorNumber == 0) colorNumber = 3;
                                
                                if (colorNumber != 3){
                                    arrayColorRangeR = arrayColorRange2 [colorNumber*3];
                                    arrayColorRangeG = arrayColorRange2 [colorNumber*3+1];
                                    arrayColorRangeB = arrayColorRange2 [colorNumber*3+2];
                                    
                                    if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                        if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                            if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                            else arrayColorRangeR = 1.0;
                                            
                                            if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                            else arrayColorRangeG = 1.0;
                                            
                                            if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                            else arrayColorRangeB = 1.0;
                                        }
                                        else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                            if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                            else arrayColorRangeR = 0;
                                            
                                            if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                            else arrayColorRangeG = 0;
                                            
                                            if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                            else arrayColorRangeB = 0;
                                        }
                                    }
                                    
                                    [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                                    path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(counter4, counter3, circleSizeDetermine, circleSizeDetermine)];
                                    [path fill];
                                }
                            }
                            else if (videoColorStatus == 2){
                                if (lingColorListSim [mapLingNoHeld [counter3][counter4]*4+3] == 1){
                                    arrayColorRangeR = lingColorListSim [mapLingNoHeld [counter3][counter4]*4];
                                    arrayColorRangeG = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+1];
                                    arrayColorRangeB = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+2];
                                    
                                    if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                        if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                            if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                            else arrayColorRangeR = 1.0;
                                            
                                            if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                            else arrayColorRangeG = 1.0;
                                            
                                            if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                            else arrayColorRangeB = 1.0;
                                        }
                                        else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                            if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                            else arrayColorRangeR = 0;
                                            
                                            if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                            else arrayColorRangeG = 0;
                                            
                                            if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                            else arrayColorRangeB = 0;
                                        }
                                    }
                                    
                                    [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                                    path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(counter4, counter3, circleSizeDetermine, circleSizeDetermine)];
                                    [path fill];
                                }
                            }
                        }
                        else if (mapPositionHeld [counter3][counter4] != 0 && mapPositionHeld [counter3][counter4] != 500){
                            lastDigit = to_string(mapPositionHeld [counter3][counter4]);
                            lastDigit = lastDigit.substr(0, lastDigit.length()-1);
                            colorCodeExt = atoi(lastDigit.c_str())/100;
                            
                            double radius = circleSizeDetermine*1.25;
                            double diameterCal = 0;
                            
                            flashPositionCount = 0;
                            
                            for (int counter5 = counter3-(int)(circleSizeDetermine*1.25); counter5 < counter3+(int)(circleSizeDetermine*1.25); counter5++){
                                for (int counter6 = counter4-(int)(circleSizeDetermine*1.25); counter6 < counter4+(int)(circleSizeDetermine*1.25); counter6++){
                                    diameterCal = (counter5-counter3)*(counter5-counter3)+(counter6-counter4)*(counter6-counter4);
                                    
                                    if (sqrt(diameterCal) <= radius){
                                        flashPosition [flashPositionCount] = counter6, flashPositionCount++;
                                        flashPosition [flashPositionCount] = counter5, flashPositionCount++;
                                        flashPosition [flashPositionCount] = 0, flashPositionCount++;
                                    }
                                }
                            }
                            
                            if (flashPositionCount != 0){
                                for (int counter5 = 0; counter5 < 15; counter5++){
                                    randInit = rand() % flashPositionCount/3 + 0;
                                    flashPosition [randInit*3+2] = 1;
                                }
                                
                                if (colorCodeExt == -1) colorNumber = 3;
                                else colorNumber = simColorDataHold [colorCodeExt-1];
                                
                                if (colorNumber == 0) colorNumber = 3;
                                
                                for (int counter5 = 0; counter5 < flashPositionCount/3; counter5++){
                                    if (flashPosition [counter5*3+2] == 1){
                                        randInit = rand() % (int)(circleSizeDetermine*0.5) + 1;
                                        circleSizeDetermine2 = randInit;
                                        
                                        if (videoColorStatus == 0){
                                            arrayColorRangeR = arrayColorRange2 [colorNumber*3];
                                            arrayColorRangeG = arrayColorRange2 [colorNumber*3+1];
                                            arrayColorRangeB = arrayColorRange2 [colorNumber*3+2];
                                            
                                            if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                                if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                                    if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                                    else arrayColorRangeR = 1.0;
                                                    
                                                    if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                                    else arrayColorRangeG = 1.0;
                                                    
                                                    if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                                    else arrayColorRangeB = 1.0;
                                                }
                                                else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                                    if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                                    else arrayColorRangeR = 0;
                                                    
                                                    if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                                    else arrayColorRangeG = 0;
                                                    
                                                    if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                                    else arrayColorRangeB = 0;
                                                }
                                            }
                                            
                                            [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                                            path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(flashPosition [counter5*3], flashPosition [counter5*3+1], circleSizeDetermine2, circleSizeDetermine2)];
                                            [path fill];
                                        }
                                        else{
                                            
                                            arrayColorRangeR = lingColorListSim [mapLingNoHeld [counter3][counter4]*4];
                                            arrayColorRangeG = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+1];
                                            arrayColorRangeB = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+2];
                                            
                                            if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                                if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                                    if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                                    else arrayColorRangeR = 1.0;
                                                    
                                                    if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                                    else arrayColorRangeG = 1.0;
                                                    
                                                    if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                                    else arrayColorRangeB = 1.0;
                                                }
                                                else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                                    if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                                    else arrayColorRangeR = 0;
                                                    
                                                    if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                                    else arrayColorRangeG = 0;
                                                    
                                                    if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                                    else arrayColorRangeB = 0;
                                                }
                                            }
                                            
                                            [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                                            path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(flashPosition [counter5*3], flashPosition [counter5*3+1], circleSizeDetermine2, circleSizeDetermine2)];
                                            [path fill];
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            
            //----Redraw the least frequently appearing color circles on top of others----
            if (topColorNumber != 0){
                for (int counter3 = 0; counter3 < simDimension; counter3++){
                    for (int counter4 = 0; counter4 < simDimension; counter4++){
                        if (mapPositionHeld [counter3][counter4] != 0){
                            if (mapPositionHeld [counter3][counter4] < 1000 && mapPositionHeld [counter3][counter4] > -1000 && mapPositionHeld [counter3][counter4] != 0 && mapPositionHeld [counter3][counter4] != 500){
                                if (videoColorStatus == 0){
                                    if (mapPositionHeld [counter3][counter4] == -1) colorNumber = 3;
                                    else if (mapPositionHeld [counter3][counter4] == -500) colorNumber = 3;
                                    else if (mapPositionHeld [counter3][counter4] > 500) colorNumber = simColorDataHold [mapPositionHeld [counter3][counter4]-500-1];
                                    else if (mapPositionHeld [counter3][counter4] < 1000) colorNumber = simColorDataHold [mapPositionHeld [counter3][counter4]-1];
                                    
                                    if (colorNumber == 0) colorNumber = 3;
                                    
                                    if (colorNumber == topColorNumber){
                                        arrayColorRangeR = arrayColorRange2 [colorNumber*3];
                                        arrayColorRangeG = arrayColorRange2 [colorNumber*3+1];
                                        arrayColorRangeB = arrayColorRange2 [colorNumber*3+2];
                                        
                                        if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                            if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                                if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                                else arrayColorRangeR = 1.0;
                                                
                                                if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                                else arrayColorRangeG = 1.0;
                                                
                                                if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                                else arrayColorRangeB = 1.0;
                                            }
                                            else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                                if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                                else arrayColorRangeR = 0;
                                                
                                                if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                                else arrayColorRangeG = 0;
                                                
                                                if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                                else arrayColorRangeB = 0;
                                            }
                                        }
                                        
                                        [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                                        path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(counter4, counter3, circleSizeDetermine, circleSizeDetermine)];
                                        [path fill];
                                    }
                                }
                                else if (videoColorStatus == 2){
                                    if (lingColorListSim [mapLingNoHeld [counter3][counter4]*4+3] == 1){
                                        arrayColorRangeR = lingColorListSim [mapLingNoHeld [counter3][counter4]*4];
                                        arrayColorRangeG = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+1];
                                        arrayColorRangeB = lingColorListSim [mapLingNoHeld [counter3][counter4]*4+2];
                                        
                                        if (colorToneChangeOptionHold != 0 && colorToneChangeTimeHold <= imageSimNoCount){
                                            if (colorToneChangeOptionHold == 1 || colorToneChangeOptionHold == 2){
                                                if (arrayColorRangeR+addSub < 1.0) arrayColorRangeR = arrayColorRangeR+addSub;
                                                else arrayColorRangeR = 1.0;
                                                
                                                if (arrayColorRangeG+addSub < 1.0) arrayColorRangeG = arrayColorRangeG+addSub;
                                                else arrayColorRangeG = 1.0;
                                                
                                                if (arrayColorRangeB+addSub < 1.0) arrayColorRangeB = arrayColorRangeB+addSub;
                                                else arrayColorRangeB = 1.0;
                                            }
                                            else if (colorToneChangeOptionHold == 3 || colorToneChangeOptionHold == 4){
                                                if (arrayColorRangeR-addSub > 0) arrayColorRangeR = arrayColorRangeR-addSub;
                                                else arrayColorRangeR = 0;
                                                
                                                if (arrayColorRangeG-addSub > 0) arrayColorRangeG = arrayColorRangeG-addSub;
                                                else arrayColorRangeG = 0;
                                                
                                                if (arrayColorRangeB-addSub > 0) arrayColorRangeB = arrayColorRangeB-addSub;
                                                else arrayColorRangeB = 0;
                                            }
                                        }
                                        
                                        [[NSColor colorWithCalibratedRed:arrayColorRangeR green:arrayColorRangeG blue:arrayColorRangeB alpha:1] set];
                                        path = [NSBezierPath bezierPathWithOvalInRect: NSMakeRect(counter4, counter3, circleSizeDetermine, circleSizeDetermine)];
                                        [path fill];
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        
        for (int counter3 = 0; counter3 < simDimension; counter3++){
            for (int counter4 = 0; counter4 < simDimension; counter4++){
                if (mapPositionHeld [counter3][counter4] == -500 || (mapPositionHeld [counter3][counter4] < 1000 && mapPositionHeld [counter3][counter4] >= 500)){
                    mapPositionHeld [counter3][counter4] = 0;
                    mapCellNoHeld [counter3][counter4] = 0;
                    mapLingNoHeld [counter3][counter4] = 0;
                }
            }
        }
        
        delete [] flashPosition;
        
        double titleFont = 0;
        
        if (titleFontExport == 1) titleFont = 12;
        else if (titleFontExport == 2) titleFont = 18;
        else if (titleFontExport == 3) titleFont = 24;
        else if (titleFontExport == 4) titleFont = 30;
        else if (titleFontExport == 5) titleFont = 40;
        else if (titleFontExport == 6) titleFont = 50;
        else if (titleFontExport == 7) titleFont = 60;
        else if (titleFontExport == 8) titleFont = 80;
        else if (titleFontExport == 9) titleFont = 0;
        else if (titleFontExport == 10) titleFont = 6;
        else if (titleFontExport == 11) titleFont = 8;
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:titleFont] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor greenColor] forKey: NSForegroundColorAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSBackgroundColorAttributeName];
        
        string infoDisplayString = "Time: "+to_string(imageSimNoCount);
        string infoCountString = "Time: 0000";
        
        NSFont *font = [NSFont boldSystemFontOfSize:titleFont];
        
        NSString *timeNSstring2 = @(infoCountString.c_str());
        NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
        NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
        CGFloat size3 = [attrStrS2 size].height;
        
        if (titleFont != 0){
            attrStrA = [[NSAttributedString alloc] initWithString:@(infoDisplayString.c_str()) attributes:attributesA];
            pointA.x = 10;
            pointA.y = simDimension-size3-5;
            [attrStrA drawAtPoint:pointA];
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(displayImageSavePath.c_str()) atomically:YES];
        
        drawFlag = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToSimulationDisplay object:nil];
}

@end
