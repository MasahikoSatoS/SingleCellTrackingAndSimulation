//
//  LineageDataFluorescent.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/5/16.
//
//

#ifndef LineageDataFluorescent_H
#define LineageDataFluorescent_H
#import "Controller.h" 
#endif

@interface LineageDataFluorescent : NSObject <NSTableViewDataSource>{
    int tableCallLFCount; //Table operation
    int tableCurrentLFRowHold; //Table operation
    int rowIndexLFHold; //Table operation
    int tableViewLFCall; //Table operation
    
    IBOutlet NSTextField *rangeLowDisplay;
    IBOutlet NSTextField *rangeHighDisplay;
    IBOutlet NSTextField *rangeLowAreaDisplay;
    IBOutlet NSTextField *rangeHighAreaDisplay;
    
    IBOutlet NSTableView *tableViewLFList;
    
    NSTimer *LineageDataFluorescentTimer;
}

-(id)init;
-(void)dealloc;
-(void)display;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;
-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
