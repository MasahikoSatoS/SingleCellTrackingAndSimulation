//
//  EndTrimTable2.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-31.
//
//

#import "EndTrimTable2.h"

NSString *notificationToTrimTable2 = @"notificationExecuteTrimTable2";

@implementation EndTrimTable2

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTrimTable2 object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [endTrimTable2 setDataSource:self];
    [endTrimTable2 reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = mergeResultsHoldCount/6;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1;
        string displayData2;
        string displayData3;
        string displayData4;
        string displayData5;
        string displayData6;
        
        if (arrayMergeResultsHold [rowIndex*6] == "-1") displayData1 = "";
        else displayData1 = arrayMergeResultsHold [rowIndex*6];
        
        if (arrayMergeResultsHold [rowIndex*6+1] == "-1") displayData2 = "";
        else displayData2 = arrayMergeResultsHold [rowIndex*6+1];
        
        if (arrayMergeResultsHold [rowIndex*6+2] == "-1") displayData3 = "";
        else displayData3 = arrayMergeResultsHold [rowIndex*6+2];
        
        if (arrayMergeResultsHold [rowIndex*6+3] == "-1") displayData4 = "";
        else displayData4 = arrayMergeResultsHold [rowIndex*6+3];
        
        if (arrayMergeResultsHold [rowIndex*6+4] == "-1") displayData5 = "";
        else displayData5 = arrayMergeResultsHold [rowIndex*6+4];
        
        if (arrayMergeResultsHold [rowIndex*6+5] == "-1") displayData6 = "";
        else displayData6 = arrayMergeResultsHold [rowIndex*6+5];
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData4.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]){
            [attributes setObject:[NSColor blueColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData5.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL4"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL5"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    mergeOperationTableCount++;
    mergeOperationTableCurrentRow = rowIndex;
    
    if (mergeOperationTableCount == 2){
        if (upLoadingProgress == 0){
            mergeOperationTableCurrentRow = rowMergeOperationTable;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        if (upLoadingProgress == 0){
            mergeOperationTableCurrentRow = rowIndex;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Uploading In Progress"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    return YES;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTrimTable2 object:nil];
}

@end
