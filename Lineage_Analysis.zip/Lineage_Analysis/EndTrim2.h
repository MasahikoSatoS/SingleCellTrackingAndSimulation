//
//  EndTrim2.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-07-02.
//
//

#ifndef ENDTRIM2_H
#define ENDTRIM2_H
#import "Controller.h" 
#endif

@interface EndTrim2 : NSObject{
    int cellNumberProcessHold; //Cell number
    
    int *cellNumberDeleteHold2; //Cell number hold array
    int cellNumberDeleteHoldCount2;
    
    IBOutlet NSTextField *lineageCutValueDisplay;
    IBOutlet NSTextField *rangeValueADisplay1;
    IBOutlet NSTextField *rangeValueBDisplay1;
    IBOutlet NSTextField *rangeValueADisplay2;
    IBOutlet NSTextField *rangeValueBDisplay2;
    IBOutlet NSTextField *rangeValueCHDisplayA;
    IBOutlet NSTextField *rangeValueCHDisplayB;
}

-(int)secondarySubtract;
-(int)secondaryAddition;
-(int)primarySubtract;
-(int)primaryAddition;
-(void)fileDeleteUpDate;
-(void)lineageFluorescentDataTypeUpDate;

-(IBAction)lineageCut:(id)sender;

@end
