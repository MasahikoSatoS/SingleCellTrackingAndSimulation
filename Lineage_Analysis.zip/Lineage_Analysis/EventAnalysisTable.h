//
//  EventAnalysisTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#ifndef EVENTANALYSISTABLE_H
#define EVENTANALYSISTABLE_H
#import "Controller.h"
#endif

@interface EventAnalysisTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *eventAnalysisTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;

@end
