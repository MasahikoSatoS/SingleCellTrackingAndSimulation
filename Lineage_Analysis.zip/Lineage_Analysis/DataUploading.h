//
//  DataUploading.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/5/16.
//
//

#ifndef DATAUPLOADING_H
#define DATAUPLOADING_H
#import "Controller.h" 
#endif

@interface DataUploading : NSObject{
    int dataType; //Data type
    
    IBOutlet NSTextField *analysisSeriesDisplay;
    IBOutlet NSTextField *analysisIDDisplay;
    IBOutlet NSTextField *analysisResultsDisplay;
    IBOutlet NSTextField *analysisSourceDisplay;
    
    IBOutlet NSWindow *analysisLoad;
    IBOutlet NSBrowser *analysisLoadBrowser;
    
    NSWindowController *analysisLoadWindController;
    
    NSTimer *analysisLoadTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)directoryInfoUpDate;
-(void)fileDeleteUpDate;

-(IBAction)closeWindow:(id)sender;
-(IBAction)browserDoubleClick:(id)browser;
-(IBAction)deleteAnalysis:(id)sender;
-(IBAction)deleteAnalysisResults:(id)sender;
-(IBAction)loadAnalysis:(id)sender;
-(IBAction)dataSwitch:(id)sender;
-(IBAction)saveAnalysis:(id)sender;

@end
