//
//  SimulationProcess.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-11-04.
//

#ifndef SIMULATIONPROCESS_H
#define SIMULATIONPROCESS_H
#import "Controller.h"
#endif

@interface SimulationProcess : NSObject{
    IBOutlet NSTextField *growthTimeBDDisplay;
    IBOutlet NSTextField *growthTimeTDDisplay;
    IBOutlet NSTextField *growthTimeCFDisplay;
    IBOutlet NSTextField *growthBDDisplay;
    IBOutlet NSTextField *growthTDDisplay;
    IBOutlet NSTextField *growthBDCDDisplay;
    IBOutlet NSTextField *growthNOCDDisplay;
    IBOutlet NSTextField *growthBDCFDisplay;
    IBOutlet NSTextField *growthBDCFBDDisplay;
    IBOutlet NSTextField *growthBDCFTDDisplay;
    IBOutlet NSTextField *growthBDCFCDDisplay;
    IBOutlet NSTextField *growthTDCFDisplay;
    IBOutlet NSTextField *growthTDCFBDDisplay;
    IBOutlet NSTextField *growthTDCFTDDisplay;
    IBOutlet NSTextField *growthTDCFCDDisplay;
    IBOutlet NSTextField *growthTDBDDisplay;
    IBOutlet NSTextField *growthTDTDDisplay;
    IBOutlet NSTextField *growthTDCDDisplay;
    IBOutlet NSTextField *growthMulTDTDDisplay;
    IBOutlet NSTextField *growthSupTDBDDisplay;
    IBOutlet NSTextField *growthNoDivDisplay;
    IBOutlet NSTextField *growthRecoveryDisplay;
    
    IBOutlet NSTextField *growthPrgTimeBDDisplay;
    IBOutlet NSTextField *growthPrgTimeTDDisplay;
    IBOutlet NSTextField *growthPrgTimeCFDisplay;
    IBOutlet NSTextField *growthPrgBDDisplay;
    IBOutlet NSTextField *growthPrgTDDisplay;
    IBOutlet NSTextField *growthPrgBDCDDisplay;
    IBOutlet NSTextField *growthPrgNOCDDisplay;
    IBOutlet NSTextField *growthPrgBDCFDisplay;
    IBOutlet NSTextField *growthPrgBDCFBDDisplay;
    IBOutlet NSTextField *growthPrgBDCFTDDisplay;
    IBOutlet NSTextField *growthPrgBDCFCDDisplay;
    IBOutlet NSTextField *growthPrgTDCFDisplay;
    IBOutlet NSTextField *growthPrgTDCFBDDisplay;
    IBOutlet NSTextField *growthPrgTDCFTDDisplay;
    IBOutlet NSTextField *growthPrgTDCFCDDisplay;
    IBOutlet NSTextField *growthPrgTDBDDisplay;
    IBOutlet NSTextField *growthPrgTDTDDisplay;
    IBOutlet NSTextField *growthPrgTDCDDisplay;
    IBOutlet NSTextField *growthPrgMulTDTDDisplay;
    IBOutlet NSTextField *growthPrgSupTDBDDisplay;
    IBOutlet NSTextField *growthPrgNoDivDisplay;
    IBOutlet NSTextField *growthPrgRecoveryDisplay;
    
    IBOutlet NSTextField *growthMidTimeBDDisplay;
    IBOutlet NSTextField *growthMidTimeTDDisplay;
    IBOutlet NSTextField *growthMidTimeCFDisplay;
    IBOutlet NSTextField *growthMidBDDisplay;
    IBOutlet NSTextField *growthMidTDDisplay;
    IBOutlet NSTextField *growthMidBDCDDisplay;
    IBOutlet NSTextField *growthMidNOCDDisplay;
    IBOutlet NSTextField *growthMidBDCFDisplay;
    IBOutlet NSTextField *growthMidBDCFBDDisplay;
    IBOutlet NSTextField *growthMidBDCFTDDisplay;
    IBOutlet NSTextField *growthMidBDCFCDDisplay;
    IBOutlet NSTextField *growthMidTDCFDisplay;
    IBOutlet NSTextField *growthMidTDCFBDDisplay;
    IBOutlet NSTextField *growthMidTDCFTDDisplay;
    IBOutlet NSTextField *growthMidTDCFCDDisplay;
    IBOutlet NSTextField *growthMidTDBDDisplay;
    IBOutlet NSTextField *growthMidTDTDDisplay;
    IBOutlet NSTextField *growthMidTDCDDisplay;
    IBOutlet NSTextField *growthMidMulTDTDDisplay;
    IBOutlet NSTextField *growthMidSupTDBDDisplay;
    IBOutlet NSTextField *growthMidNoDivDisplay;
    IBOutlet NSTextField *growthMidRecoveryDisplay;
    
    IBOutlet NSTextField *growthAddTimeBDDisplay;
    IBOutlet NSTextField *growthAddTimeTDDisplay;
    IBOutlet NSTextField *growthAddTimeCFDisplay;
    IBOutlet NSTextField *growthAddBDDisplay;
    IBOutlet NSTextField *growthAddTDDisplay;
    IBOutlet NSTextField *growthAddBDCDDisplay;
    IBOutlet NSTextField *growthAddNOCDDisplay;
    IBOutlet NSTextField *growthAddBDCFDisplay;
    IBOutlet NSTextField *growthAddBDCFBDDisplay;
    IBOutlet NSTextField *growthAddBDCFTDDisplay;
    IBOutlet NSTextField *growthAddBDCFCDDisplay;
    IBOutlet NSTextField *growthAddTDCFDisplay;
    IBOutlet NSTextField *growthAddTDCFBDDisplay;
    IBOutlet NSTextField *growthAddTDCFTDDisplay;
    IBOutlet NSTextField *growthAddTDCFCDDisplay;
    IBOutlet NSTextField *growthAddTDBDDisplay;
    IBOutlet NSTextField *growthAddTDTDDisplay;
    IBOutlet NSTextField *growthAddTDCDDisplay;
    IBOutlet NSTextField *growthAddMulTDTDDisplay;
    IBOutlet NSTextField *growthAddSupTDBDDisplay;
    IBOutlet NSTextField *growthAddNoDivDisplay;
    IBOutlet NSTextField *growthAddRecoveryDisplay;
    
    IBOutlet NSTextField *growthTreatDisplay;
    IBOutlet NSTextField *growthPrgTreatDisplay;
    IBOutlet NSTextField *growthMidTreatDisplay;
    IBOutlet NSTextField *growthAddTreatDisplay;
    
    IBOutlet NSTextField *fluorescentBiasDisplay;
    IBOutlet NSTextField *fluorescentOptionDisplay;
    
    id dataSet;
}

-(IBAction)getListGrowthSet:(id)sender;
-(IBAction)getListGrowthProgSet:(id)sender;
-(IBAction)getListGrowthMidSet:(id)sender;
-(IBAction)getListGrowthAddSet:(id)sender;

@end
