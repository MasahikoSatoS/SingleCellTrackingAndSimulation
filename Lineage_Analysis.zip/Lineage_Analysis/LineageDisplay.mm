//
//  LineageDisplay.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/14/16.
//
//

#import "LineageDisplay.h"

NSString *notificationToLineageDisplay = @"notificationExecutLineageDisplay";

@implementation LineageDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToLineageDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    xPointDownLingDisplay = clickPoint.x;
    yPointDownLingDisplay = clickPoint.y;
    
    if (upLoadingProgress == 0){
        if ((xPointDownLingDisplay > 718 && xPointDownLingDisplay < 760 && yPointDownLingDisplay >573 && yPointDownLingDisplay < 587) || (xPointDownLingDisplay > 668 && xPointDownLingDisplay < 710 && yPointDownLingDisplay >573 && yPointDownLingDisplay < 587)){
            if (selectCurrentLineage >= 0){
                int displayCheck = 0;
                
                if (liveDisplayHold == 0){
                    displayCheck = 1;
                }
                else if (liveDisplayHold == 1){
                    if (arrayTableMain [selectCurrentLineage][5] != "nil" && atoi(arrayTableMain [selectCurrentLineage][5].c_str()) >= chNo1){
                        displayCheck = 1;
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Live Data/No Corresponding Channel Number Exists"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (liveDisplayHold == 2){
                    if (arrayTableMain [selectCurrentLineage][5] != "nil" && atoi(arrayTableMain [selectCurrentLineage][5].c_str()) >= chNo1){
                        int liveIfLastTimePoint = 0;
                        
                        for (int counter2 = 0; counter2 < arrayIFDataEntryHold [selectCurrentLineage]/22; counter2++){
                            if (arrayIFData [selectCurrentLineage][counter2*22+2] > liveIfLastTimePoint) liveIfLastTimePoint = arrayIFData [selectCurrentLineage][counter2*22+2];
                        }
                        
                        if (liveIfLastTimePoint == arrayTableDetail [selectCurrentLineage][3]){
                            if (colorOptionLingHold == 1){
                                if ((mainWindowMagOpen == 0 && colorOptionLingHold == 0) || (mainWindowMagOpen == 1 && colorOptionLingHold == 0) || (mainWindowMagOpen == 1 && colorOptionLingHold == 1)){
                                    displayCheck = 1;
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Set manual data using Main Winsow Magnification"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else displayCheck = 1;
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Last Time Point Must Have Live Data"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No Live Data/No Corresponding Channel Number Exists"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                else if (liveDisplayHold == 3 || liveDisplayHold == 4){
                    if (arrayTableMain [selectCurrentLineage][12] != "nil"){
                        if (ifOneAllHold != -1){
                            int channelNoCheck = 0;
                            
                            for (int counter1 = 0; counter1 < arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9; counter1++){
                                if (arrayIFTimeLineData [selectCurrentLineage][counter1*9] == ifOneAllHold && arrayIFTimeLineData [selectCurrentLineage][counter1*9+2] >= chNo1){
                                    channelNoCheck = 1;
                                }
                            }
                            
                            if (channelNoCheck == 1){
                                if (liveDisplayHold == 3) displayCheck = 1;
                                else{
                                    
                                    if ((mainWindowMagOpen == 0 && colorOptionLingHold == 0) || (mainWindowMagOpen == 1 && colorOptionLingHold == 0) || (mainWindowMagOpen == 1 && colorOptionLingHold == 1)){
                                        displayCheck = 1;
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Set Manual Data Using Main Window Magnification"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"No Corresponding Channel Number Exists"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"No IF Time Set"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"No IF Data Exists"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
                
                if (displayCheck == 1){
                    lingNo1 = -1;
                    lingNo2 = -1;
                    lingNo3 = -1;
                    lingNo4 = -1;
                    lingNo5 = -1;
                    lingNo6 = -1;
                    lingNo7 = -1;
                    lingNo8 = -1;
                    
                    lineageCurrentPosition = lineageCurrentPositionHold;
                    
                    int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
                    int displayCount = 0;
                    int lastCounterPosition = -1;
                    
                    for (int counter1 = lineageCurrentPosition; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                        if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                            lastCounterPosition = counter1;
                            
                            if (displayCount == 0) lingNo1 = counter1, displayCount++;
                            else if (displayCount == 1) lingNo2 = counter1, displayCount++;
                            else if (displayCount == 2) lingNo3 = counter1, displayCount++;
                            else if (displayCount == 3) lingNo4 = counter1, displayCount++;
                            else if (displayCount == 4) lingNo5 = counter1, displayCount++;
                            else if (displayCount == 5) lingNo6 = counter1, displayCount++;
                            else if (displayCount == 6) lingNo7 = counter1, displayCount++;
                            else if (displayCount == 7){
                                lingNo8 = counter1;
                                displayCount++;
                                break;
                            }
                        }
                    }
                    
                    if (lastCounterPosition != -1) lineageCurrentPosition = lastCounterPosition;
                    
                    //cout<<lingNo1<<" "<<lingNo2<<" "<<lingNo3<<" "<<lingNo4<<" "<<lingNo5<<" "<<lingNo6<<" "<<lingNo7<<" "<<lingNo8<<" LingNo"<<endl;
                    
                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                    [sound play];
                    
                    [self setNeedsDisplay:YES];
                }
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        
        if (exportFlag3 == 2){
            exportFlag3 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            if (exportTiming == 0) [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)keyDown:(NSEvent *)event{
    int keyCode = [event keyCode];
    int proceedFlag = 0;
    
    if (upLoadingProgress == 0){
        if (selectCurrentLineage >= 0){
            //----Lineage Reverse----
            if (keyCode == 123){
                
                //cout<<lingNo1<<" "<<lingNo2<<" "<<lingNo3<<" "<<lingNo4<<" "<<lingNo5<<" "<<lingNo6<<" "<<lingNo7<<" "<<lingNo8<<" LingnNoAAA"<<endl;
                
                int reductionCount = 0;
                
                if (lingNo8 != -1) reductionCount = 16;
                else{
                    
                    if (lingNo7 != -1) reductionCount = 15;
                    else if (lingNo6 != -1) reductionCount = 14;
                    else if (lingNo5 != -1) reductionCount = 13;
                    else if (lingNo4 != -1) reductionCount = 12;
                    else if (lingNo3 != -1) reductionCount = 11;
                    else if (lingNo2 != -1) reductionCount = 10;
                    else if (lingNo1 != -1) reductionCount = 9;
                }
                
                int findCount = 0;
                int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
                
                for (int counter1 = lineageCurrentPosition; counter1 >= 1; counter1--){
                    if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                        findCount++;
                        lineageCurrentPosition = counter1;
                        
                        if (findCount == reductionCount){
                            
                            break;
                        }
                    }
                }
                
                lingNo1 = -1;
                lingNo2 = -1;
                lingNo3 = -1;
                lingNo4 = -1;
                lingNo5 = -1;
                lingNo6 = -1;
                lingNo7 = -1;
                lingNo8 = -1;
                
                lineageCurrentPositionHold = lineageCurrentPosition;
                
                int displayCount = 0;
                int lastCounterPosition = -1;
                
                for (int counter1 = lineageCurrentPosition; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                    if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                        lastCounterPosition = counter1;
                        
                        if (displayCount == 0) lingNo1 = counter1, displayCount++;
                        else if (displayCount == 1) lingNo2 = counter1, displayCount++;
                        else if (displayCount == 2) lingNo3 = counter1, displayCount++;
                        else if (displayCount == 3) lingNo4 = counter1, displayCount++;
                        else if (displayCount == 4) lingNo5 = counter1, displayCount++;
                        else if (displayCount == 5) lingNo6 = counter1, displayCount++;
                        else if (displayCount == 6) lingNo7 = counter1, displayCount++;
                        else if (displayCount == 7){
                            lingNo8 = counter1;
                            displayCount++;
                            break;
                        }
                    }
                }
                
                if (lastCounterPosition != -1) lineageCurrentPosition = lastCounterPosition;
                
                //cout<<lingNo1<<" "<<lingNo2<<" "<<lingNo3<<" "<<lingNo4<<" "<<lingNo5<<" "<<lingNo6<<" "<<lingNo7<<" "<<lingNo8<<" LingNo"<<endl;
                
                proceedFlag = 1;
            }
            
            //----Lineage Forward----
            if (keyCode == 124){
                int newPositionFind = 0;
                int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
                
                for (int counter1 = lineageCurrentPosition+1; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                    if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                        newPositionFind = counter1;
                        break;
                    }
                }
                
                if (newPositionFind != 0){
                    lineageCurrentPosition = newPositionFind;
                    
                    lingNo1 = -1;
                    lingNo2 = -1;
                    lingNo3 = -1;
                    lingNo4 = -1;
                    lingNo5 = -1;
                    lingNo6 = -1;
                    lingNo7 = -1;
                    lingNo8 = -1;
                    
                    lineageCurrentPositionHold = lineageCurrentPosition;
                    
                    int displayCount = 0;
                    int lastCounterPosition = -1;
                    
                    for (int counter1 = lineageCurrentPosition; counter1 < lineageLinkHold [selectCurrentLineage]/lineageLinkListLengthLing; counter1++){
                        if (arrayLineageLink [selectCurrentLineage][counter1*lineageLinkListLengthLing] > 0){
                            lastCounterPosition = counter1;
                            
                            if (displayCount == 0) lingNo1 = counter1, displayCount++;
                            else if (displayCount == 1) lingNo2 = counter1, displayCount++;
                            else if (displayCount == 2) lingNo3 = counter1, displayCount++;
                            else if (displayCount == 3) lingNo4 = counter1, displayCount++;
                            else if (displayCount == 4) lingNo5 = counter1, displayCount++;
                            else if (displayCount == 5) lingNo6 = counter1, displayCount++;
                            else if (displayCount == 6) lingNo7 = counter1, displayCount++;
                            else if (displayCount == 7){
                                lingNo8 = counter1;
                                displayCount++;
                                break;
                            }
                        }
                    }
                    
                    if (lastCounterPosition != -1) lineageCurrentPosition = lastCounterPosition;
                    
                    //cout<<lingNo1<<" "<<lingNo2<<" "<<lingNo3<<" "<<lingNo4<<" "<<lingNo5<<" "<<lingNo6<<" "<<lingNo7<<" "<<lingNo8<<" LingNo"<<endl;
                    
                    proceedFlag = 1;
                }
            }
            
            if (proceedFlag == 1 && exportTiming == 0) [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

//----First Responder----
-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (exportFlag3 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767, 591)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(718, 573, 42, 14)];
        [path stroke];
        
        string reloadString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 720;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        string seriesLingDisplay;
        string cellLingDisplay;
        string treatLingDisplay;
        
        if (displayNameSeriesLing == "nil") seriesLingDisplay = "Analysis: "+seriesLing;
        else seriesLingDisplay = "Analysis: "+displayNameSeriesLing;
        
        if (displayNameTreatLing == "nil"){
            seriesLingDisplay = seriesLingDisplay+", Treat.: "+treatLing;
        }
        else seriesLingDisplay = seriesLingDisplay+", Treat.: "+displayNameTreatLing;
        
        if (displayNameCellLing != "nil") seriesLingDisplay = seriesLingDisplay+", Cell: "+displayNameCellLing;
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(seriesLingDisplay.c_str()) attributes:attributesA];
        pointA.x = 2;
        pointA.y = 575;
        [attrStrA drawAtPoint:pointA];
        
        int displayFlag = 0;
        int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
        int extractCount = 0;
        int lineageNoFind = 0;
        int lineageExtractLingCount = 0;
        int lineageExtractLingLimit = 0;
        int lineagePositionLing = 0;
        int numberOfCellEntry = 0;
        int numberOfEventCount = 0;
        int terminationFlag = 0;
        int lineageSelectNo = 0;
        int cellSelectPosition = 0;
        int horizontalListCount = 0;
        int eventListCount = 0;
        int largestTimePoint = 0;
        int findFlag = 0;
        int horizontalListCount2 = 0;
        int eventListCount2 = 0;
        int entryOrder = 0;
        int verticalListCount = 0;
        int cellNoLowPosition = 0;
        int cellNoHighPosition = 0;
        int matchFindFlag = 0;
        int xStart = 0;
        int yStart = 0;
        int horizontalTime = 0;
        int lineageFuseNo = 0;
        int lengthDivisionInt = 0;
        int numberOfDivision = 0;
        int roundNoGet = 0;
        int liveTimeListCount = 0;
        int rangeLiveAverageLow = 0;
        int rangeLiveAverageHigh = 0;
        int rangeLiveTotalLow = 0;
        int rangeLiveTotalHigh = 0;
        int lineageExtractIFCount = 0;
        int lineageExtractIFLimit = 0;
        int endType = 0;
        int rangeListCount = 0;
        int sift = 0;
        int rangeAverageLow = 0;
        int rangeAverageHigh = 0;
        int rangeTotalLow = 0;
        int rangeTotalHigh = 0;
        int fluorescentEntryCount = 0;
        int liveColorStart = 0;
        int liveColorEnd = 0;
        int liveValueGet = 0;
        int rangeNo = 0;
        int rangeNoHold = 0;
        int timeHold = 0;
        int timeHold2 = 0;
        int differenceInt = 0;
        int horizontalLineListCount = 0;
        int horizontalLineListValueCount = 0;
        int expandLineage = 0;
        int cellNoListTempCount = 0;
        int cellNoListCount = 0;
        int cellNoListLimit = 0;
        int cellNoOriginal = 0;
        int findMainLength = 0;
        int skipCount = 0;
        int skipEntryCount = 0;
        int divisionStatus = 0;
        int dataEntryCheck = 0;
        int endStatusCheck = 0;
        int endStatusCheck2 = 0;
        int colorCountTemp = 0;
        int checkStart = 0;
        int endStatusHoldCount = 0;
        int lineageDataLingSummaryCount = 0;
        int findBoth = 0;
        int extensionValueSource = 0;
        
        double cellSelect = 0;
        double parentCellNo = 0;
        double cellNoLow = 0;
        double cellNoHigh = 0;
        double expandCell = 0;
        double increment = 0;
        double horizontalIncrement = 0;
        double lengthDivision = 0;
        double lengthPix = 0;
        double rangeDivision = 0;
        double difference = 0;
        double difference2 = 0;
        double rangeDivisionAverage = 0;
        double rangeDivisionTotal = 0;
        double sumTotal = 0;
        double checkNoCheck = 0;
        double sumAverage = 0;
        double colorDataCount = 0;
        double cellNoEntry1 = 0;
        double cellNoEntry2 = 0;
        double cellNoSummary = 0;
        double lingNoSummary = 0;
        double extensionValue = 0;
        double parentInfo = 0;
        
        string cellNumberString;
        string ifName;
        string roundExtract;
        string liveName;
        string lineageNo;
        string timeInterval;
        string timeString;
        string fluorescentName;
        string extensionNoExtract;
        string extensionNoExtract2;
        string extensionNoExtractB;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint pointA2;
        
        CGFloat size2 = 0;
        
        for (int counter1 = 1; counter1 <= 8; counter1++){
            displayFlag = 0;
            lineagePositionLing = 0;
            
            if (counter1 == 1 && lingNo1 > 0){
                lineagePositionLing = lingNo1;
                displayFlag = 1;
                xStart = 10;
                yStart = 451;
            }
            else if (counter1 == 2 && lingNo2 > 0){
                lineagePositionLing = lingNo2;
                displayFlag = 1;
                xStart = 387;
                yStart = 451;
            }
            else if (counter1 == 3 && lingNo3 > 0){
                lineagePositionLing = lingNo3;
                displayFlag = 1;
                xStart = 10;
                yStart = 309;
            }
            else if (counter1 == 4 && lingNo4 > 0){
                lineagePositionLing = lingNo4;
                displayFlag = 1;
                xStart = 387;
                yStart = 309;
            }
            else if (counter1 == 5 && lingNo5 > 0){
                lineagePositionLing = lingNo5;
                displayFlag = 1;
                xStart = 10;
                yStart = 167;
            }
            else if (counter1 == 6 && lingNo6 > 0){
                lineagePositionLing = lingNo6;
                displayFlag = 1;
                xStart = 387;
                yStart = 167;
            }
            else if (counter1 == 7 && lingNo7 > 0){
                lineagePositionLing = lingNo7;
                displayFlag = 1;
                xStart = 10;
                yStart = 25;
            }
            else if (counter1 == 8 && lingNo8 > 0){
                lineagePositionLing = lingNo8;
                displayFlag = 1;
                xStart = 387;
                yStart = 25;
            }
            
            if (displayFlag == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart, yStart, 372, 117)];
                [path stroke];
                
                //----Lineage data read----
                extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkHold [selectCurrentLineage]+5];
                
                for (int counter3 = 0; counter3 < lineageLinkListLengthLing; counter3++){
                    if (arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter3] != 0){
                        lineageSelect [extractCount] = arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter3];
                        extractCount++;
                    }
                }
                
                double *arrayLineageDataLing = new double [5000];
                lineageExtractLingCount = 0;
                lineageExtractLingLimit = 5000;
                
                double *cellNoList = new double [5000];
                cellNoListCount = 0;
                cellNoListLimit = 5000;
                
                for (int counter2 = 0; counter2 < 5000; counter2++) cellNoList [counter2] = 0;
                
                for (int counter2 = 0; counter2 < extractCount; counter2++){
                    lineageNoFind = lineageSelect [counter2];
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [selectCurrentLineage]/9; counter3++){
                        if (arrayLineageData [selectCurrentLineage][counter3*9+6] == lineageNoFind){
                            if (lineageExtractLingCount+10 > lineageExtractLingLimit){
                                double *arrayUpDate = new double [lineageExtractLingCount+10];
                                
                                for (int counter4 = 0; counter4 < lineageExtractLingCount; counter4++) arrayUpDate [counter4] = arrayLineageDataLing [counter4];
                                
                                delete [] arrayLineageDataLing;
                                lineageExtractLingLimit = lineageExtractLingCount+500;
                                arrayLineageDataLing = new double [lineageExtractLingLimit];
                                
                                for (int counter4 = 0; counter4 < lineageExtractLingCount; counter4++) arrayLineageDataLing [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+1], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+2], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+3], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+4], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+5], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+6], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+7], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+8], lineageExtractLingCount++;
                            
                            if (arrayLineageData [selectCurrentLineage][counter3*9+3] == 1 || arrayLineageData [selectCurrentLineage][counter3*9+3] == 31 || arrayLineageData [selectCurrentLineage][counter3*9+3] == 41 || arrayLineageData [selectCurrentLineage][counter3*9+3] == 51){
                                if (cellNoListCount+10 > cellNoListLimit){
                                    double *arrayUpDate = new double [cellNoListCount+10];
                                    
                                    for (int counter4 = 0; counter4 < cellNoListCount; counter4++) arrayUpDate [counter4] = cellNoList [counter4];
                                    
                                    delete [] cellNoList;
                                    cellNoListLimit = cellNoListCount+500;
                                    cellNoList = new double [cellNoListLimit];
                                    
                                    for (int counter4 = 0; counter4 < cellNoListCount; counter4++) cellNoList [counter4] = arrayUpDate [counter4];
                                    delete [] arrayUpDate;
                                }
                                
                                cellNoList [cellNoListCount] = arrayLineageData [selectCurrentLineage][counter3*9+5], cellNoListCount++;
                                cellNoList [cellNoListCount] = arrayLineageData [selectCurrentLineage][counter3*9+4], cellNoListCount++;
                                cellNoList [cellNoListCount] = 0, cellNoListCount++;
                                cellNoList [cellNoListCount] = arrayLineageData [selectCurrentLineage][counter3*9+6], cellNoListCount++;
                            }
                        }
                    }
                }
                
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 299999999 && cellNoList [counter2*4] >= -299999999){
                        cellNoList [counter2*4+2] = cellNoList [counter2*4]*1000000;
                        cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                    }
                    else if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                        extensionNoExtractB = to_string(extensionValueSource)+"000";
                        extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                        
                        if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                        
                        extensionNoExtract2 = extensionNoExtract2+"000000";
                        extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                        
                        cellNoList [counter2*4+2] = extensionValue;
                        cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                    }
                    else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                        extensionNoExtractB = to_string(extensionValueSource)+"000";
                        
                        extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                        
                        if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                        
                        extensionNoExtract2 = extensionNoExtract2+"000000";
                        extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                        
                        cellNoList [counter2*4+2] = extensionValue;
                        cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource)+"000";
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                    else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource)+"000";
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                    else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 699999999 && cellNoList [counter2*4+1] >= 500000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                    else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -699999999 && cellNoList [counter2*4+1] <= -500000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < cellNoListCount/4; counterA++){
                //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<to_string(cellNoList [counterA*4+counterB]);
                //    cout<<" cellNoList "<<counterA<<endl;
                //}
                
                cellNoEntry1 = 0;
                cellNoSummary = 0;
                lingNoSummary = 0;
                
                for (int counter2 = 0; counter2 < lineageExtractLingCount/9; counter2++){
                    if (cellNoSummary != arrayLineageDataLing [counter2*9+5] || lingNoSummary != arrayLineageDataLing [counter2*9+6]){
                        cellNoSummary = arrayLineageDataLing [counter2*9+5];
                        lingNoSummary = arrayLineageDataLing [counter2*9+6];
                        
                        findBoth = 0;
                        cellNoEntry1 = 0;
                        cellNoEntry2 = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (arrayLineageDataLing [counter2*9+5] == cellNoList [counter3*4] && arrayLineageDataLing [counter2*9+6] == cellNoList [counter3*4+3]){
                                cellNoEntry1 = cellNoList [counter3*4+2];
                                findBoth++;
                            }
                            
                            if (arrayLineageDataLing [counter2*9+4] == cellNoList [counter3*4] && arrayLineageDataLing [counter2*9+6] == cellNoList [counter3*4+3]){
                                cellNoEntry2 = cellNoList [counter3*4+2];
                                findBoth++;
                            }
                            
                            if (findBoth == 2){
                                break;
                            }
                        }
                        
                        arrayLineageDataLing [counter2*9+5] = cellNoEntry1;
                        arrayLineageDataLing [counter2*9+4] = cellNoEntry2;
                    }
                    else arrayLineageDataLing [counter2*9+5] = cellNoEntry1;
                    
                    if (arrayLineageDataLing [counter2*9+3] == 91 || arrayLineageDataLing [counter2*9+3] == 92){
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (arrayLineageDataLing [counter2*9+4] == cellNoList [counter3*4]){
                                arrayLineageDataLing [counter2*9+4] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                double *arrayLineageDataLingSummary = new double [lineageExtractLingCount+50];
                lineageDataLingSummaryCount = 0;
                
                cellNoSummary = 0;
                lingNoSummary = 0;
                
                for (int counter2 = 0; counter2 < lineageExtractLingCount/9; counter2++){
                    if (arrayLineageDataLing [counter2*9+3] != 2){
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+1], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+2], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+3], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+4], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+5], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+6], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+7], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+8], lineageDataLingSummaryCount++;
                    }
                    
                    if (cellNoSummary != arrayLineageDataLing [counter2*9+5] || lingNoSummary != arrayLineageDataLing [counter2*9+6]){
                        cellNoSummary = arrayLineageDataLing [counter2*9+5];
                        lingNoSummary = arrayLineageDataLing [counter2*9+6];
                        
                        if (counter2 != 0 && arrayLineageDataLing [(counter2-1)*9+3] == 2){
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+1], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+2], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+3], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+4], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+5], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+6], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+7], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+8], lineageDataLingSummaryCount++;
                        }
                    }
                    
                    if (counter2 == lineageExtractLingCount/9-1){
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+1], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+2], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+3], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+4], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+5], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+6], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+7], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+8], lineageDataLingSummaryCount++;
                    }
                }
                
                //----Lineage no----
                lineageFuseNo = 0;
                
                for (int counter2 = 0; counter2 < lineageLinkListLengthLing; counter2++){
                    if (arrayLineageLinkListLGL [lineagePositionLing*lineageLinkListLengthLing+counter2] != 0){
                        lineageFuseNo++;
                    }
                }
                
                lineageNo = to_string(arrayLineageLinkListLGL [lineagePositionLing*lineageLinkListLengthLing]);
                
                for (int counter2 = 1; counter2 < lineageLinkListLengthLing; counter2++){
                    if (arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter2] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter2]);
                    }
                }
                
                //----Fluorescent data read----
                int *arrayIFDataLing = new int [5000];
                lineageExtractIFCount = 0;
                lineageExtractIFLimit = 5000;
                
                for (int counter2 = 0; counter2 < extractCount; counter2++){
                    lineageNoFind = lineageSelect [counter2];
                    
                    for (int counter3 = 0; counter3 < arrayIFDataEntryHold [selectCurrentLineage]/22; counter3++){
                        if (arrayIFData [selectCurrentLineage][counter3*22+1] == lineageNoFind){
                            if (lineageExtractIFCount+50 > lineageExtractIFLimit){
                                int *arrayUpDate = new int [lineageExtractIFCount+50];
                                
                                for (int counter4 = 0; counter4 < lineageExtractIFCount; counter4++) arrayUpDate [counter4] = arrayIFDataLing [counter4];
                                
                                delete [] arrayIFDataLing;
                                lineageExtractIFLimit = lineageExtractIFCount+5000;
                                arrayIFDataLing = new int [lineageExtractIFLimit];
                                
                                for (int counter4 = 0; counter4 < lineageExtractIFCount; counter4++) arrayIFDataLing [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+1], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+2], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+3], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+4], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+5], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+6], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+7], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+8], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+9], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+10], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+11], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+12], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+13], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+14], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+15], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+16], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+17], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+18], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+19], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+20], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+21], lineageExtractIFCount++;
                        }
                    }
                }
                
                //----Horizontal Scale----
                horizontalTime = arrayTableDetail [selectCurrentLineage][3];
                timeInterval = arrayLineageDataType [selectCurrentLineage][5];
                
                timeString = "";
                
                if (displayNameTreatLing != "nil") timeString = displayNameTreatLing+"-"+lineageNo;
                else timeString = "Lineage-"+lineageNo+" T. point (x"+timeInterval+" min)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:10];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = xStart+186-size2/(double)2;
                pointA.y = yStart-21;
                [attrStrA drawAtPoint:pointA];
                
                lengthDivision = horizontalTime/(double)5;
                lengthDivisionInt = 0;
                
                if (lengthDivision <= 25) lengthDivisionInt = 25;
                else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                else if (lengthDivision > 450 && lengthDivision <= 550) lengthDivisionInt = 500;
                else if (lengthDivision > 550 && lengthDivision <= 650) lengthDivisionInt = 600;
                else if (lengthDivision > 650 && lengthDivision <= 750) lengthDivisionInt = 700;
                else if (lengthDivision > 750 && lengthDivision <= 850) lengthDivisionInt = 800;
                else if (lengthDivision > 850 && lengthDivision <= 950) lengthDivisionInt = 900;
                else if (lengthDivision > 950 && lengthDivision <= 1050) lengthDivisionInt = 1000;
                else if (lengthDivision > 1050 && lengthDivision <= 1150) lengthDivisionInt = 1100;
                else if (lengthDivision > 1150 && lengthDivision <= 1250) lengthDivisionInt = 1200;
                else if (lengthDivision > 1250 && lengthDivision <= 1350) lengthDivisionInt = 1300;
                else if (lengthDivision > 1350 && lengthDivision <= 1450) lengthDivisionInt = 1400;
                else if (lengthDivision > 1450 && lengthDivision <= 1550) lengthDivisionInt = 1500;
                
                lengthPix = ((360-10)/(double)horizontalTime)*lengthDivisionInt;
                numberOfDivision = (int)((330-10)/(double)lengthPix)+1;
                
                sift = 0;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = xStart+lengthPix*counter2;
                    positionAA.y = yStart;
                    positionBB.x = xStart+lengthPix*counter2;
                    positionBB.y = yStart+5;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:9] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (xStart+lengthPix*counter2)-size2/(double)2-sift;
                    pointA2.y = yStart-12;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                //----Lineage display Horizontal set----
                numberOfCellEntry = 0;
                numberOfEventCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                    if (arrayLineageDataLingSummary [counter2*9+3] == 1 || arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                        numberOfCellEntry++;
                        numberOfEventCount++;
                    }
                    
                    if (arrayLineageDataLingSummary [counter2*9+3] == 32 || arrayLineageDataLingSummary [counter2*9+3] == 42 || arrayLineageDataLingSummary [counter2*9+3] == 52 || arrayLineageDataLingSummary [counter2*9+3] == 91 || arrayLineageDataLingSummary [counter2*9+3] == 6 || arrayLineageDataLingSummary [counter2*9+3] == 92 || arrayLineageDataLingSummary [counter2*9+3] == 8 || arrayLineageDataLingSummary [counter2*9+3] == 10 || arrayLineageDataLingSummary [counter2*9+3] == 11 || arrayLineageDataLingSummary [counter2*9+3] == 7){
                        numberOfEventCount++;
                    }
                }
                
                double *horizontalList = new double [numberOfCellEntry*7+50];
                horizontalListCount = 0;
                double *eventList = new double [numberOfEventCount*5+50];
                eventListCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                    if (arrayLineageDataLingSummary [counter2*9+3] == 1 || arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+5], horizontalListCount++;
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+6], horizontalListCount++;
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+8], horizontalListCount++;
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+2], horizontalListCount++;
                        
                        largestTimePoint = 0;
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                            if ((arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+3] == 91 || arrayLineageDataLingSummary [counter3*9+3] == 6 || arrayLineageDataLingSummary [counter3*9+3] == 92 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 10 || arrayLineageDataLingSummary [counter3*9+3] == 11 || arrayLineageDataLingSummary [counter3*9+3] == 7) && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+6] == arrayLineageDataLingSummary [counter2*9+6]){
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+5], eventListCount++;
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+6], eventListCount++;
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+2], eventListCount++;
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+3], eventListCount++;
                                eventList [eventListCount] = 0, eventListCount++;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                            if ((arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+3] == 91) && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+6] == arrayLineageDataLingSummary [counter2*9+6]){
                                horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter3*9+2], horizontalListCount++;
                                horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter3*9+3], horizontalListCount++;
                                findFlag = 1;
                                break;
                            }
                            else{
                                
                                if (arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+6] == arrayLineageDataLingSummary [counter2*9+6]){
                                    if (arrayLineageDataLingSummary [counter3*9+2] > largestTimePoint) largestTimePoint = (int)(arrayLineageDataLingSummary [counter3*9+2]);
                                }
                            }
                        }
                        
                        if (findFlag == 0){
                            horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                            horizontalList [horizontalListCount] = 2, horizontalListCount++;
                        }
                        
                        if (arrayLineageDataLingSummary [counter2*9+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                        else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < horizontalListCount/7; counterA++){
                //    cout<<horizontalList [counterA*7]<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" horizontalList"<<endl;
                //}
                
                //for (int counterA = 0; counterA < eventListCount/5; counterA++){
                //    cout<<eventList [counterA*5]<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
                //}
                
                double *horizontalList2 = new double [numberOfCellEntry*7+50];
                horizontalListCount2 = 0;
                double *eventList2 = new double [numberOfEventCount*6+50];
                eventListCount2 = 0;
                
                for (int counter2 = 0; counter2 < numberOfEventCount*6+50; counter2++) eventList2 [counter2] = 0;
                
                entryOrder = 0;
                
                do{
                    
                    terminationFlag = 1;
                    lineageSelectNo = 100000;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount/7; counter2++){
                        if (horizontalList [counter2*7+1] != -1){
                            lineageSelectNo = (int)(horizontalList [counter2*7+1]);
                            break;
                        }
                    }
                    
                    if (lineageSelectNo == 100000) terminationFlag = 0;
                    else{
                        
                        cellSelect = 999999999999999;
                        cellSelectPosition = 0;
                        
                        for (int counter2 = 0; counter2 < horizontalListCount/7; counter2++){
                            if (horizontalList [counter2*7] != -1 && horizontalList [counter2*7+1] == lineageSelectNo && horizontalList [counter2*7] < cellSelect){
                                cellSelect = horizontalList [counter2*7];
                                cellSelectPosition = counter2;
                            }
                        }
                        
                        if (cellSelect != 999999999999999){
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //----Cell no---
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //----Ling no----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //----Rev Cell no----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //----Time start----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //----Time end----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //----Event last----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //----Event I----
                            
                            for (int counter2 = 0; counter2 < eventListCount/5; counter2++){
                                if (eventList [counter2*5] == horizontalList [cellSelectPosition*7] && eventList [counter2*5+1] == horizontalList [cellSelectPosition*7+1]){
                                    eventList2 [eventListCount2] = eventList [counter2 *5], eventListCount2++; //----Cell no----
                                    eventList2 [eventListCount2] = eventList [counter2 *5+1], eventListCount2++; //----Ling no----
                                    eventList2 [eventListCount2] = eventList [counter2 *5+2], eventListCount2++; //----Time----
                                    eventList2 [eventListCount2] = eventList [counter2 *5+3], eventListCount2++; //----Event----
                                    eventList2 [eventListCount2] = entryOrder, eventListCount2++; //----Entry order----
                                }
                            }
                            
                            horizontalList [cellSelectPosition*7] = -1;
                            horizontalList [cellSelectPosition*7+1] = -1;
                            
                            entryOrder++;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                //----Lineage display Vertical set----
                double *verticalList = new double [numberOfEventCount*9+50];
                verticalListCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                    if (arrayLineageDataLingSummary [counter2*9+3] == 91){
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 92 && arrayLineageDataLingSummary [counter2*9+4] == arrayLineageDataLingSummary [counter3*9+5] && arrayLineageDataLingSummary [counter2*9+7] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]){
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 91, verticalListCount++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 92){
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 91 && arrayLineageDataLingSummary [counter2*9+4] == arrayLineageDataLingSummary [counter3*9+5] && arrayLineageDataLingSummary [counter2*9+7] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]){
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 91, verticalListCount++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 31){
                        parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 31 && arrayLineageDataLingSummary [counter2*9+6] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+4] == parentCellNo && arrayLineageDataLingSummary [counter3*9+5] != arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]){
                                    if (arrayLineageDataLingSummary [counter3*9+5] > arrayLineageDataLingSummary [counter2*9+5]){
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 31, verticalListCount++;
                                    }
                                    else{
                                        
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 31, verticalListCount++;
                                    }
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 41){
                        parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                        cellNoLow = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoHigh = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoLowPosition = counter2;
                        cellNoHighPosition = counter2;
                        
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 41 && arrayLineageDataLingSummary [counter2*9+6] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+4] == parentCellNo && arrayLineageDataLingSummary [counter3*9+5] != arrayLineageDataLingSummary [counter2*9+5]){
                                    if (arrayLineageDataLingSummary [counter3*9+5] > cellNoHigh){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoHighPosition = counter3;
                                    }
                                    
                                    if (arrayLineageDataLingSummary [counter3*9+5] < cellNoLow){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoLowPosition = counter3;
                                    }
                                }
                            }
                            
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+5], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+6], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+2], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+5], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+6], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+2], verticalListCount++;
                            verticalList [verticalListCount] = 0, verticalListCount++;
                            verticalList [verticalListCount] = 0, verticalListCount++;
                            verticalList [verticalListCount] = 41, verticalListCount++;
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 51){
                        parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                        cellNoLow = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoHigh = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoLowPosition = counter2;
                        cellNoHighPosition = counter2;
                        
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 51 && arrayLineageDataLingSummary [counter2*9+6] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+4] == parentCellNo && arrayLineageDataLingSummary [counter3*9+5] != arrayLineageDataLingSummary [counter2*9+5]){
                                    if (arrayLineageDataLingSummary [counter3*9+5] > cellNoHigh){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoHighPosition = counter3;
                                    }
                                    
                                    if (arrayLineageDataLingSummary [counter3*9+5] < cellNoLow){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoLowPosition = counter3;
                                    }
                                }
                            }
                            
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+5], verticalListCount++; //----Cell no 1----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+6], verticalListCount++; //----Ling no 1----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+2], verticalListCount++; //----Time 1----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+5], verticalListCount++; //----Cell no 2----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+6], verticalListCount++; //----Ling no 2----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+2], verticalListCount++; //----Time 2----
                            verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 1----
                            verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 2----
                            verticalList [verticalListCount] = 51, verticalListCount++; //----Event----
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< verticalList [counterA*9+counterB];
                //    cout<<" verticalList "<<counterA<<" "<<counter1<<endl;
                //}
                
                for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                    for (int counter3 = 0; counter3 < horizontalListCount2/7; counter3++){
                        if (horizontalList2 [counter3*7] == verticalList [counter2*9] && horizontalList2 [counter3*7+1] == verticalList [counter2*9+1]){
                            verticalList [counter2*9+6] = counter3;
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < horizontalListCount2/7; counter3++){
                        if (horizontalList2 [counter3*7] == verticalList [counter2*9+3] && horizontalList2 [counter3*7+1] == verticalList [counter2*9+4]){
                            verticalList [counter2*9+7] = counter3;
                            break;
                        }
                    }
                }
                
                increment = 117/(double)(numberOfCellEntry+1);
                horizontalIncrement = (330-10)/(double)horizontalTime;
                
                //----Lineage Display Vertical----
                [NSBezierPath setDefaultLineWidth:lingLineWidthHold];
                
                for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                    if (verticalList [counter2*9+8] == 91) [[NSColor orangeColor] set];
                    else if (verticalList [counter2*9+8] == 31) [[NSColor blackColor] set];
                    else if (verticalList [counter2*9+8] == 41) [[NSColor redColor] set];
                    else if (verticalList [counter2*9+8] == 51) [[NSColor redColor] set];
                    
                    positionAA.x = xStart+verticalList [counter2*9+2]*horizontalIncrement;
                    positionAA.y = yStart+increment+verticalList [counter2*9+6]*increment;
                    positionBB.x = xStart+verticalList [counter2*9+5]*horizontalIncrement;
                    positionBB.y = yStart+increment+verticalList [counter2*9+7]*increment;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                
                //----Live vertical line----
                [NSBezierPath setDefaultLineWidth:1];
                
                roundNoGet = 0;
                
                int *liveTimeList = new int [arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9+1];
                liveTimeListCount = 0;
                
                if (liveDisplayHold == 1 || ifOneAllHold != 0){
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9; counter2++){
                        if (arrayIFTimeLineData [selectCurrentLineage][counter2*9+1] == -1){
                            liveTimeList [liveTimeListCount] = arrayIFTimeLineData [selectCurrentLineage][counter2*9], liveTimeListCount++;
                            
                            if (blueLineDisplayHold == 0){
                                [[NSColor blueColor] set];
                                
                                if (arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement < 50){
                                    positionAA.x = xStart+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement;
                                    positionAA.y = yStart;
                                    positionBB.x = xStart+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement;
                                    positionBB.y = yStart+100;
                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                }
                                else{
                                    
                                    positionAA.x = xStart+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement;
                                    positionAA.y = yStart;
                                    positionBB.x = xStart+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement;
                                    positionBB.y = yStart+107;
                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                }
                            }
                        }
                        
                        if (arrayIFTimeLineData [selectCurrentLineage][counter2*9] == ifOneAllHold) roundNoGet = arrayIFTimeLineData [selectCurrentLineage][counter2*9+1];
                    }
                    
                    if ((liveDisplayHold == 1 || liveDisplayHold == 2)){
                        ifName = arrayTableMain [selectCurrentLineage][chNo1+5];
                        fluorescentName = "Live: "+ifName;
                        
                        [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(fluorescentName.c_str()) attributes:attributesA];
                        pointA.x = xStart+2;
                        pointA.y = yStart+103;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                findMainLength = arrayTableMainHold [selectCurrentLineage];
                
                double *horizontalLineList = new double [horizontalListCount2/7*3+50];
                double *horizontalLineListValue = new double [horizontalListCount2/7*2+50];
                
                rangeAverageLow = 0;
                rangeAverageHigh = 0;
                rangeTotalLow = 0;
                rangeTotalHigh = 0;
                
                if (liveDisplayHold == 3 || liveDisplayHold == 4){
                    ifName = "";
                    
                    for (int counter2 = 13; counter2 < findMainLength; counter2 = counter2+8){
                        if (atoi(arrayTableMain [selectCurrentLineage][counter2].c_str()) == roundNoGet){
                            ifName = arrayTableMain [selectCurrentLineage][counter2+chNo1+1];
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                        roundExtract = arrayLineageFluorescentDataType [counter2][1];
                        roundExtract = roundExtract.substr(1);
                        
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == selectCurrentLineage+1 && atoi(roundExtract.c_str()) == roundNoGet && arrayLineageFluorescentDataType [counter2][2] == ifName){
                            rangeTotalLow = atoi(arrayLineageFluorescentDataType [counter2][6].c_str());
                            rangeTotalHigh = atoi(arrayLineageFluorescentDataType [counter2][7].c_str());
                            rangeAverageLow = atoi(arrayLineageFluorescentDataType [counter2][4].c_str());
                            rangeAverageHigh = atoi(arrayLineageFluorescentDataType [counter2][5].c_str());
                            break;
                        }
                    }
                    
                    double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                    fluorescentEntryCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        if (horizontalList2 [counter2*7+3] <= ifOneAllHold && horizontalList2 [counter2*7+4] >= ifOneAllHold){
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                            fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    cout<<horizontalList2 [counterA*7]<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                    //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fluorescentEntryCount/5; counter2++){
                        cellNoOriginal = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (fluorescentEntry [counter2*5] == cellNoList [counter3*4+2]){
                                cellNoOriginal = (int)(cellNoList [counter3*4]);
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < lineageExtractIFCount/22; counter3++){
                            if (cellNoOriginal == arrayIFDataLing [counter3*22] && fluorescentEntry [counter2*5+1] == arrayIFDataLing [counter3*22+1] && ifOneAllHold == arrayIFDataLing [counter3*22+2]){
                                if (chNo1+6 == 7){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+5];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+5]*arrayIFDataLing [counter3*22+6];
                                }
                                else if (chNo1+6 == 8){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+8];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+8]*arrayIFDataLing [counter3*22+9];
                                }
                                else if (chNo1+6 == 9){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+11];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+11]*arrayIFDataLing [counter3*22+12];
                                }
                                else if (chNo1+6 == 10){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+14];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+14]*arrayIFDataLing [counter3*22+15];
                                }
                                else if (chNo1+6 == 11){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+17];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+17]*arrayIFDataLing [counter3*22+18];
                                }
                                else if (chNo1+6 == 12){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+20];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+20]*arrayIFDataLing [counter3*22+21];
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (averageTotalSetHold == 0){
                        rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                        
                        for (int counter2 = 0; counter2 < fluorescentEntryCount/5; counter2++){
                            if (fluorescentEntry [counter2*5+2] <= rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = xStart+355;
                            positionAA.y = yStart+increment+fluorescentEntry [counter2*5+4]*increment;
                            positionBB.x = xStart+365;
                            positionBB.y = yStart+increment+fluorescentEntry [counter2*5+4]*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                        
                        for (int counter2 = 0; counter2 <= fluorescentEntryCount/5; counter2++){
                            if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = xStart+355;
                            positionAA.y = yStart+increment+fluorescentEntry [counter2*5+4]*increment;
                            positionBB.x = xStart+365;
                            positionBB.y = yStart+increment+fluorescentEntry [counter2*5+4]*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    
                    fluorescentName = "IF: "+ifName;
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:11] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(fluorescentName.c_str()) attributes:attributesA];
                    pointA.x = xStart+2;
                    pointA.y = yStart+103;
                    [attrStrA drawAtPoint:pointA];
                    
                    if (liveDisplayHold == 4){
                        for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                            horizontalLineList [counter2] = 0;
                        }
                        
                        for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                            horizontalLineListValue [counter2] = 0;
                        }
                        
                        horizontalLineListCount = 0;
                        horizontalLineListValueCount = 0;
                        
                        for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                            horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                            horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                            horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                            
                            horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                            horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                        }
                        
                        //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                        //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                        //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                        //}
                        
                        //----Enter fluorescent value at the end point----
                        if (colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                        else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                        else horizontalLineListValue [counter2*2] = -100;
                                        
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //----Set dummy value at CD, OF FU lines----
                        if (siblingLingHold == 1 && colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3]  && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else if (colorOptionLingHold == 1){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3] && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            
                                            horizontalLineListValue [counter2*2] = -100;
                                            horizontalLineListValue [counter2*2+1] = 100;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                        //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                        //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractLingCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<to_string(arrayLineageDataLing [counterA*9+counterB]);
                        //    cout<<" arrayLineageDataLing "<<counterA<<endl;
                        //}
                        
                        expandCell = 0;
                        skipCount = 0;
                        
                        double *cellNoListTemp = new double [10];
                        
                        int *endStatusHold = new int [20];
                        
                        do{
                            
                            terminationFlag = 1;
                            expandLineage = 0;
                            skipEntryCount = skipCount;
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                    expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                    expandCell = horizontalLineList [counter2*3];
                                    break;
                                }
                                else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                            }
                            
                            if (expandLineage != 0){
                                parentCellNo = -1;
                                
                                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                    if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                        if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+5] == expandCell){
                                            parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                                            break;
                                        }
                                    }
                                }
                                
                                if (parentCellNo != -1){
                                    cellNoListTempCount = 0;
                                    endStatusHoldCount = 0;
                                    divisionStatus = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                        if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                            if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+4] == parentCellNo){
                                                if (arrayLineageDataLingSummary [counter2*9+3] == 31) divisionStatus = 2;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 41) divisionStatus = 3;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 51) divisionStatus = 4;
                                                
                                                cellNoListTemp [cellNoListTempCount] = arrayLineageDataLingSummary [counter2*9+5], cellNoListTempCount++;
                                                
                                                endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                                endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                                
                                                //----Check end status, enter 1 when end is CD, OF, FU----
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        endStatusHold [endStatusHoldCount-2] = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                checkStart = 0;
                                                checkNoCheck = 0;
                                                
                                                //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+5]  && arrayLineageDataLingSummary [counter3*9+3] != 91 && arrayLineageDataLingSummary [counter3*9+4] != 92){
                                                        checkStart = 1;
                                                        checkNoCheck = arrayLineageDataLingSummary [counter3*9+5];
                                                    }
                                                    
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                        checkStart = 0;
                                                    }
                                                    else if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                        
                                                        endStatusHold [endStatusHoldCount-1] = 0;
                                                        break;
                                                    }
                                                }
                                                
                                                if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                            }
                                        }
                                    }
                                    
                                    endStatusCheck = 0;
                                    endStatusCheck2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                        if (endStatusHold [counter2*2] == 1) endStatusCheck = 1;
                                        if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                    }
                                    
                                    sumTotal = 0;
                                    sumAverage = 0;
                                    colorDataCount = 0;
                                    colorCountTemp = 0;
                                    
                                    if (colorOptionLingHold == 1) sumAverage = -1;
                                    
                                    if (colorOptionLingHold == 0){
                                        if (siblingLingHold == 0){
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (siblingLingHold == 1){
                                            if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                endStatusCheck = 0;
                                                dataEntryCheck = 0;
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                    
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                            dataEntryCheck = 1;
                                                        }
                                                    }
                                                }
                                                
                                                if (endStatusCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumTotal = -2;
                                                                sumAverage = -2;
                                                                
                                                                horizontalLineListValue [counter3*2] = -1;
                                                                horizontalLineListValue [counter3*2+1] = -1;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                else if (dataEntryCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                        if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                    horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                    horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                    horizontalLineList [counter3*3+2] = -1;
                                                                    
                                                                    colorDataCount++;
                                                                    
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (colorOptionLingHold == 1){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        
                                                        //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<valueUK<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                        
                                                        if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else sumAverage = -100;
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = 0;
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = 0;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumAverage = -100;
                                                                
                                                                horizontalLineListValue [counter3*2] = -100;
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    if (endStatusHold [counter2*2] == 0){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                
                                                                if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else sumAverage = -100;
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                    //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                    //}
                                    
                                    if (colorDataCount == divisionStatus){
                                        skipCount = 0;
                                        
                                        if (colorOptionLingHold == 0){
                                            if (colorCountTemp == 0){
                                                sumTotal = sumTotal/(double)colorDataCount;
                                                sumAverage = (int)(sumAverage/(double)colorDataCount);
                                            }
                                            else{
                                                
                                                sumTotal = sumTotal/(double)colorCountTemp;
                                                sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                            if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentCellNo){
                                                horizontalLineListValue [counter2*2] = sumAverage;
                                                horizontalLineListValue [counter2*2+1] = sumTotal;
                                                horizontalLineList [counter2*3+2] = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else skipCount++;
                                }
                                else{
                                    
                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                            horizontalLineList [counter3*3+2] = -1;
                                        }
                                    }
                                }
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        delete [] cellNoListTemp;
                        delete [] endStatusHold;
                    }
                    
                    delete [] fluorescentEntry;
                }
                
                if (liveDisplayHold == 2){
                    int liveIfLastTimePoint = 0;
                    
                    for (int counter2 = 0; counter2 < lineageExtractIFCount/22; counter2++){
                        if (arrayIFDataLing [counter2*22+2] > liveIfLastTimePoint) liveIfLastTimePoint = arrayIFDataLing [counter2*22+2];
                    }
                    
                    double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                    fluorescentEntryCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        if (horizontalList2 [counter2*7+3] <= arrayTableDetail [selectCurrentLineage][3] && horizontalList2 [counter2*7+4] >= arrayTableDetail [selectCurrentLineage][3]){
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                            fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                    //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fluorescentEntryCount/5; counter2++){
                        cellNoOriginal = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (fluorescentEntry [counter2*5] == cellNoList [counter3*4+2]){
                                cellNoOriginal = (int)(cellNoList [counter3*4]);
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < lineageExtractIFCount/22; counter3++){
                            if (cellNoOriginal == arrayIFDataLing [counter3*22] && (int)(fluorescentEntry [counter2*5+1]) == arrayIFDataLing [counter3*22+1] && liveIfLastTimePoint == arrayIFDataLing [counter3*22+2]){
                                if (chNo1 == 1){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+5];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+5]*arrayIFDataLing [counter3*22+6];
                                }
                                else if (chNo1 == 2){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+8];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+8]*arrayIFDataLing [counter3*22+9];
                                }
                                else if (chNo1 == 3){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+11];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+11]*arrayIFDataLing [counter3*22+12];
                                }
                                else if (chNo1 == 4){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+14];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+14]*arrayIFDataLing [counter3*22+15];
                                }
                                else if (chNo1 == 5){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+17];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+17]*arrayIFDataLing [counter3*22+18];
                                }
                                else if (chNo1 == 6){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+20];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+20]*arrayIFDataLing [counter3*22+21];
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                    //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                        horizontalLineList [counter2] = 0;
                    }
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                        horizontalLineListValue [counter2] = 0;
                    }
                    
                    horizontalLineListCount = 0;
                    horizontalLineListValueCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                        
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                    //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    if (liveIfLastTimePoint == arrayTableDetail [selectCurrentLineage][3]){
                        if (colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                        else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                        else horizontalLineListValue [counter2*2] = -100;
                                        
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //----Set dummy value at CD, OF FU lines----
                        if (siblingLingHold == 1 && colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3]  && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else if (colorOptionLingHold == 1){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3]  && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            
                                            horizontalLineListValue [counter2*2] = -100;
                                            horizontalLineListValue [counter2*2+1] = 100;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                        //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                        //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractLingCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageDataLing [counterA*9+counterB];
                        //    cout<<" arrayLineageDataLing "<<counterA<<endl;
                        //}
                        
                        expandCell = 0;
                        skipCount = 0;
                        
                        double *cellNoListTemp = new double [10];
                        int *endStatusHold = new int [20];
                        
                        do{
                            
                            terminationFlag = 1;
                            expandLineage = 0;
                            skipEntryCount = skipCount;
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                    expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                    expandCell = horizontalLineList [counter2*3];
                                    break;
                                }
                                else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                            }
                            
                            if (expandLineage != 0){
                                parentCellNo = -1;
                                
                                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                    if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                        if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+5] == expandCell){
                                            parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                                            break;
                                        }
                                    }
                                }
                                
                                if (parentCellNo != -1){
                                    cellNoListTempCount = 0;
                                    endStatusHoldCount = 0;
                                    divisionStatus = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                        if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                            if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+4] == parentCellNo){
                                                if (arrayLineageDataLingSummary [counter2*9+3] == 31) divisionStatus = 2;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 41) divisionStatus = 3;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 51) divisionStatus = 4;
                                                
                                                cellNoListTemp [cellNoListTempCount] = arrayLineageDataLingSummary [counter2*9+5], cellNoListTempCount++;
                                                
                                                endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                                endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                                
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        endStatusHold [endStatusHoldCount-2] = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                checkStart = 0;
                                                checkNoCheck = 0;
                                                
                                                //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+5]  && arrayLineageDataLingSummary [counter3*9+3] != 91 && arrayLineageDataLingSummary [counter3*9+4] != 92){
                                                        checkStart = 1;
                                                        checkNoCheck = arrayLineageDataLingSummary [counter3*9+5];
                                                    }
                                                    
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                        
                                                        checkStart = 0;
                                                    }
                                                    else if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                        endStatusHold [endStatusHoldCount-1] = 0;
                                                        break;
                                                    }
                                                }
                                                
                                                if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                            }
                                        }
                                    }
                                    
                                    endStatusCheck = 0;
                                    endStatusCheck2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < endStatusHoldCount; counter2++){
                                        if (endStatusHold [counter2] == 1) endStatusCheck = 1;
                                        if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                    }
                                    
                                    sumTotal = 0;
                                    sumAverage = -1;
                                    colorDataCount = 0;
                                    colorCountTemp = 0;
                                    
                                    if (colorOptionLingHold == 1) sumAverage = -1;
                                    
                                    if (colorOptionLingHold == 0){
                                        if (siblingLingHold == 0){
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (siblingLingHold == 1){
                                            if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                endStatusCheck = 0;
                                                dataEntryCheck = 0;
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                    
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                            dataEntryCheck = 1;
                                                        }
                                                    }
                                                }
                                                
                                                if (endStatusCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumTotal = -2;
                                                                sumAverage = -2;
                                                                
                                                                horizontalLineListValue [counter3*2] = -1;
                                                                horizontalLineListValue [counter3*2+1] = -1;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                else if (dataEntryCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                        if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                    horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                    horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                    horizontalLineList [counter3*3+2] = -1;
                                                                    
                                                                    colorDataCount++;
                                                                    
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (colorOptionLingHold == 1){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        
                                                        //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                        
                                                        if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else sumAverage = -100;
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = 0;
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = 0;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumAverage = -100;
                                                                
                                                                horizontalLineListValue [counter3*2] = -100;
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    if (endStatusHold [counter2*2] == 0){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                
                                                                if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else sumAverage = -100;
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                    //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                    //}
                                    
                                    if (colorDataCount == divisionStatus){
                                        skipCount = 0;
                                        
                                        if (colorOptionLingHold == 0){
                                            if (colorCountTemp == 0){
                                                sumTotal = sumTotal/(double)colorDataCount;
                                                sumAverage = (int)(sumAverage/(double)colorDataCount);
                                            }
                                            else{
                                                
                                                sumTotal = sumTotal/(double)colorCountTemp;
                                                sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                            if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentCellNo){
                                                horizontalLineListValue [counter2*2] = sumAverage;
                                                horizontalLineListValue [counter2*2+1] = sumTotal;
                                                horizontalLineList [counter2*3+2] = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else skipCount++;
                                }
                                else{
                                    
                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                            horizontalLineList [counter3*3+2] = -1;
                                        }
                                    }
                                }
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        delete [] cellNoListTemp;
                        delete [] endStatusHold;
                    }
                    
                    delete [] fluorescentEntry;
                }
                
                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                //}
                
                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                //    cout<<" horizontalLineListValue "<<counterA<<" "<<counter1<<endl;
                //}
                
                //----Color data range get----
                rangeLiveAverageLow = 0;
                rangeLiveAverageHigh = 0;
                rangeLiveTotalLow = 0;
                rangeLiveTotalHigh = 0;
                
                if (liveDisplayHold == 1 || liveDisplayHold == 2){
                    liveName = "";
                    
                    if (chNo1 == 1) liveName = arrayTableMain [selectCurrentLineage][6];
                    else if (chNo1 == 2) liveName = arrayTableMain [selectCurrentLineage][7];
                    else if (chNo1 == 3) liveName = arrayTableMain [selectCurrentLineage][8];
                    else if (chNo1 == 4) liveName = arrayTableMain [selectCurrentLineage][9];
                    else if (chNo1 == 5) liveName = arrayTableMain [selectCurrentLineage][10];
                    else if (chNo1 == 6) liveName = arrayTableMain [selectCurrentLineage][11];
                    
                    for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == selectCurrentLineage+1 && arrayLineageFluorescentDataType [counter2][1] == "Live" && arrayLineageFluorescentDataType [counter2][2] == liveName){
                            rangeLiveTotalLow = atoi(arrayLineageFluorescentDataType [counter2][6].c_str());
                            rangeLiveTotalHigh = atoi(arrayLineageFluorescentDataType [counter2][7].c_str());
                            rangeLiveAverageLow = atoi(arrayLineageFluorescentDataType [counter2][4].c_str());
                            rangeLiveAverageHigh = atoi(arrayLineageFluorescentDataType [counter2][5].c_str());
                            break;
                        }
                    }
                }
                
                NSBezierPath *pathCircle;
                [NSBezierPath setDefaultLineWidth:lingLineWidthHold];
                
                rangeNoHold = 0;
                timeHold = 0;
                
                int *rangeList = new int [horizontalTime*3+10];
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    [[NSColor blackColor] set];
                    
                    cellNoOriginal = 0;
                    
                    for (int counter4 = 0; counter4 < cellNoListCount/4; counter4++){
                        if (horizontalList2 [counter2*7] == cellNoList [counter4*4+2]){
                            cellNoOriginal = (int)(cellNoList [counter4*4]);
                            break;
                            
                        }
                    }
                    
                    if (horizontalList2 [counter2*7+5] == 32 || horizontalList2 [counter2*7+3] == 42 || horizontalList2 [counter2*7+3] == 52) endType = 1;
                    else endType = 0;
                    
                    //cout<<counter2<<" "<<horizontalList2 [counter2*7]<<" "<<horizontalList2 [counter2*7+1]<<" TimeStartEnd"<<endl;
                    
                    //----Color data drawing----
                    if (liveDisplayHold == 0 || liveDisplayHold == 3){
                        positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                        positionAA.y = yStart+increment+counter2*increment;
                        
                        if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                        else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                        
                        positionBB.y = yStart+increment+counter2*increment;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                    else if (liveDisplayHold == 1){
                        liveColorStart = -1;
                        liveColorEnd = -1;
                        
                        for (int counter3 = 0; counter3 < liveTimeListCount; counter3++){
                            if (liveColorStart == -1 && liveTimeList [counter3] >= horizontalList2 [counter2*7+3]) liveColorStart = counter3;
                            if (liveTimeList [counter3] <= horizontalList2 [counter2*7+4]) liveColorEnd = counter3;
                        }
                        
                        if (liveColorStart != -1 && liveColorStart == liveColorEnd){
                            liveValueGet = 0;
                            
                            for (int counter3 = 0; counter3 < lineageExtractIFCount/22; counter3++){
                                if (cellNoOriginal == arrayIFDataLing [counter3*22] && horizontalList2 [counter2*7+1] == arrayIFDataLing [counter3*22+1] && liveTimeList [liveColorStart] == arrayIFDataLing [counter3*22+2]){
                                    if (chNo1 == 1){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+5];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+5]*arrayIFDataLing [counter3*22+6];
                                    }
                                    else if (chNo1 == 2){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+8];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+8]*arrayIFDataLing [counter3*22+9];
                                    }
                                    else if (chNo1 == 3){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+11];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+11]*arrayIFDataLing [counter3*22+12];
                                    }
                                    else if (chNo1 == 4){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+14];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+14]*arrayIFDataLing [counter3*22+15];
                                    }
                                    else if (chNo1 == 5){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+17];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+17]*arrayIFDataLing [counter3*22+18];
                                    }
                                    else if (chNo1 == 6){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+20];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+20]*arrayIFDataLing [counter3*22+21];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                
                                if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                                else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                                
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                
                                if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                                else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                                
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        } //----One live data/cell----
                        else if (liveColorStart != -1 && liveColorStart < liveColorEnd){ //----More than one live data/cell----
                            rangeListCount = 0;
                            
                            for (int counter3 = liveColorStart; counter3 <= liveColorEnd; counter3++){
                                liveValueGet = 0;
                                
                                for (int counter4 = 0; counter4 < lineageExtractIFCount/22; counter4++){
                                    if (cellNoOriginal == arrayIFDataLing [counter4*22] && horizontalList2 [counter2*7+1] == arrayIFDataLing [counter4*22+1] && liveTimeList [counter3] == arrayIFDataLing [counter4*22+2]){
                                        
                                        if (chNo1 == 1){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+5];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+5]*arrayIFDataLing [counter4*22+6];
                                        }
                                        else if (chNo1 == 2){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+8];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+8]*arrayIFDataLing [counter4*22+9];
                                        }
                                        else if (chNo1 == 3){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+11];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+11]*arrayIFDataLing [counter4*22+12];
                                        }
                                        else if (chNo1 == 4){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+14];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+14]*arrayIFDataLing [counter4*22+15];
                                        }
                                        else if (chNo1 == 5){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+17];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+17]*arrayIFDataLing [counter4*22+18];
                                        }
                                        else if (chNo1 == 6){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+20];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+20]*arrayIFDataLing [counter4*22+21];
                                        }
                                        
                                        break;
                                    }
                                }
                                
                                if (averageTotalSetHold == 0){
                                    rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                    
                                    if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                    else rangeNo = 23;
                                    
                                    if (liveValueGet == -1) rangeNo = 105/3+1;
                                }
                                else{
                                    
                                    rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                    
                                    if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                    else rangeNo = 23;
                                    
                                    if (liveValueGet == -1) rangeNo = 105/3+1;
                                }
                                
                                if (counter3 == liveColorStart){
                                    rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+3]), rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                    
                                    rangeNoHold = rangeNo;
                                    timeHold = liveTimeList [counter3];
                                }
                                else if (counter3 == liveColorEnd){
                                    difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter3]-timeHold);
                                    
                                    if (liveTimeList [counter3]-timeHold < 5){
                                        rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+3]), rangeListCount++;
                                        rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                        rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                    }
                                    else{
                                        
                                        difference2 = difference;
                                        timeHold2 = timeHold;
                                        
                                        for (int counter4 = timeHold+1; counter4 <= liveTimeList [counter3]; counter4++){
                                            if (counter4 == liveTimeList [counter3]){
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                            }
                                            else if (difference2 >= 1){
                                                differenceInt = (int)difference2;
                                                
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                                
                                                difference2 = difference;
                                                rangeNoHold = rangeNoHold+differenceInt;
                                                timeHold2 = counter4;
                                            }
                                            else difference2 = difference2+difference;
                                        }
                                    }
                                    
                                    rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                    
                                    if (endType == 1) rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+4])+1, rangeListCount++;
                                    else rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+4]), rangeListCount++;
                                    
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter3]-timeHold);
                                    
                                    if (liveTimeList [counter3]-timeHold < 5){
                                        rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+3]), rangeListCount++;
                                        rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                        rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                    }
                                    else{
                                        
                                        difference2 = difference;
                                        timeHold2 = timeHold;
                                        
                                        for (int counter4 = timeHold+1; counter4 <= liveTimeList [counter3]; counter4++){
                                            if (counter4 == liveTimeList [counter3]){
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                            }
                                            else if (difference2 >= 1){
                                                differenceInt = (int)difference2;
                                                
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                                
                                                difference2 = difference;
                                                rangeNoHold = rangeNoHold+differenceInt;
                                                timeHold2 = counter4;
                                                
                                            }
                                            else difference2 = difference2+difference;
                                        }
                                    }
                                    
                                    rangeNoHold = rangeNo;
                                    timeHold = liveTimeList [counter3];
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < rangeListCount/3; counter3++){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [rangeList [counter3*3+2]*3] green:arrayColorRange [rangeList [counter3*3+2]*3+1] blue:arrayColorRange [rangeList [counter3*3+2]*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+rangeList [counter3*3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                positionBB.x = xStart+rangeList [counter3*3+1]*horizontalIncrement;
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        else{
                            
                            positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                            positionAA.y = yStart+increment+counter2*increment;
                            
                            if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                            else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                            
                            positionBB.y = yStart+increment+counter2*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else if (liveDisplayHold == 2){
                        if (colorOptionLingHold == 0){
                            if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter2*2];
                            else liveValueGet = (int)horizontalLineListValue [counter2*2+1];
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                
                                if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                                else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                                
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                
                                if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                                else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                                
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        else{
                            
                            if (horizontalLineListValue [counter2*2] == -1 || horizontalLineListValue [counter2*2] == -100) rangeNo = 105;
                            else rangeNo = (int)(horizontalLineListValue [counter2*2]);
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                            
                            positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                            positionAA.y = yStart+increment+counter2*increment;
                            
                            if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                            else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                            
                            positionBB.y = yStart+increment+counter2*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else if (liveDisplayHold == 4){
                        if (colorOptionLingHold == 0){
                            if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter2*2];
                            else liveValueGet = (int)horizontalLineListValue [counter2*2+1];
                            
                            if (averageTotalFlag == 0){
                                rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                
                                if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                                else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                                
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else{
                                
                                rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                                positionAA.y = yStart+increment+counter2*increment;
                                
                                if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                                else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                                
                                positionBB.y = yStart+increment+counter2*increment;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        else{
                            
                            if (horizontalLineListValue [counter2*2] == -1 || horizontalLineListValue [counter2*2] == -100) rangeNo = 105;
                            else rangeNo = (int)(horizontalLineListValue [counter2*2]);
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                            
                            positionAA.x = xStart+horizontalList2 [counter2*7+3]*horizontalIncrement;
                            positionAA.y = yStart+increment+counter2*increment;
                            
                            if (endType == 1) positionBB.x = xStart+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement;
                            else positionBB.x = xStart+horizontalList2 [counter2*7+4]*horizontalIncrement;
                            
                            positionBB.y = yStart+increment+counter2*increment;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < eventListCount2/5; counter3++){
                        if (eventList2 [counter3*5+4] == counter2){
                            if (eventList2 [counter3*5+3] == 91 || eventList2 [counter3*5+3] == 92){
                                [[NSColor orangeColor] set];
                                pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(xStart+eventList2 [counter3*5+2]*horizontalIncrement-3, yStart+increment+counter2*increment-3, 6, 6)];
                                
                                [pathCircle fill];
                            }
                            else if (eventList2 [counter3*5+3] == 6){
                                [[NSColor cyanColor] set];
                                pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(xStart+eventList2 [counter3*5+2]*horizontalIncrement-3, yStart+increment+counter2*increment-3, 6, 6)];
                                [pathCircle fill];
                            }
                            else if (eventList2 [counter3*5+3] == 7){
                                [[NSColor magentaColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart+eventList2 [counter3*5+2]*horizontalIncrement-3, yStart+increment+counter2*increment-3, 6, 6)];
                                [path fill];
                            }
                            else if (eventList2 [counter3*5+3] == 8){
                                [[NSColor grayColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart+eventList2 [counter3*5+2]*horizontalIncrement-3, yStart+increment+counter2*increment-3, 6, 6)];
                                [path fill];
                            }
                            else if (eventList2 [counter3*5+3] == 10){
                                [[NSColor redColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart+eventList2 [counter3*5+2]*horizontalIncrement-3, yStart+increment+counter2*increment-3, 6, 6)];
                                [path stroke];
                            }
                            else if (eventList2 [counter3*5+3] == 11){
                                [[NSColor blueColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart+eventList2 [counter3*5+2]*horizontalIncrement-3, yStart+increment+counter2*increment-3, 6, 6)];
                                [path fill];
                            }
                        }
                    }
                }
                
                delete [] lineageSelect;
                delete [] arrayLineageDataLing;
                delete [] horizontalList;
                delete [] horizontalList2;
                delete [] eventList;
                delete [] eventList2;
                delete [] verticalList;
                delete [] liveTimeList;
                delete [] rangeList;
                delete [] arrayIFDataLing;
                delete [] horizontalLineList;
                delete [] horizontalLineListValue;
                delete [] cellNoList;
                delete [] arrayLineageDataLingSummary;
            }
        }
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:767*magFactor pixelsHigh:591*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:767*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767*magFactor, 591*magFactor)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1*magFactor];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        string seriesLingDisplay;
        string cellLingDisplay;
        string treatLingDisplay;
        
        if (displayNameSeriesLing == "nil") seriesLingDisplay = "Analysis: "+seriesLing;
        else seriesLingDisplay = "Analysis: "+displayNameSeriesLing;
        
        if (displayNameTreatLing == "nil"){
            seriesLingDisplay = seriesLingDisplay+", Treat.: "+treatLing;
        }
        else seriesLingDisplay = seriesLingDisplay+", Treat.: "+displayNameTreatLing;
        
        if (displayNameCellLing != "nil") seriesLingDisplay = seriesLingDisplay+", Cell: "+displayNameCellLing;
        
        [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(seriesLingDisplay.c_str()) attributes:attributesA];
        pointA.x = 2*magFactor;
        pointA.y = 575*magFactor;
        [attrStrA drawAtPoint:pointA];
        
        int displayFlag = 0;
        int lineageLinkListLengthLing = arrayLineageLink [selectCurrentLineage][0];
        int extractCount = 0;
        int lineageNoFind = 0;
        int lineageExtractLingCount = 0;
        int lineageExtractLingLimit = 0;
        int lineagePositionLing = 0;
        int numberOfCellEntry = 0;
        int numberOfEventCount = 0;
        int terminationFlag = 0;
        int lineageSelectNo = 0;
        int cellSelectPosition = 0;
        int horizontalListCount = 0;
        int eventListCount = 0;
        int largestTimePoint = 0;
        int findFlag = 0;
        int horizontalListCount2 = 0;
        int eventListCount2 = 0;
        int entryOrder = 0;
        int verticalListCount = 0;
        int cellNoLowPosition = 0;
        int cellNoHighPosition = 0;
        int matchFindFlag = 0;
        int xStart = 0;
        int yStart = 0;
        int horizontalTime = 0;
        int lineageFuseNo = 0;
        int lengthDivisionInt = 0;
        int numberOfDivision = 0;
        int roundNoGet = 0;
        int liveTimeListCount = 0;
        int rangeLiveAverageLow = 0;
        int rangeLiveAverageHigh = 0;
        int rangeLiveTotalLow = 0;
        int rangeLiveTotalHigh = 0;
        int lineageExtractIFCount = 0;
        int lineageExtractIFLimit = 0;
        int endType = 0;
        int rangeListCount = 0;
        int sift = 0;
        int rangeAverageLow = 0;
        int rangeAverageHigh = 0;
        int rangeTotalLow = 0;
        int rangeTotalHigh = 0;
        int fluorescentEntryCount = 0;
        int liveColorStart = 0;
        int liveColorEnd = 0;
        int liveValueGet = 0;
        int rangeNo = 0;
        int rangeNoHold = 0;
        int timeHold = 0;
        int timeHold2 = 0;
        int differenceInt = 0;
        int horizontalLineListCount = 0;
        int horizontalLineListValueCount = 0;
        int expandLineage = 0;
        int cellNoListTempCount = 0;
        int cellNoListCount = 0;
        int cellNoListLimit = 0;
        int cellNoOriginal = 0;
        int findMainLength = 0;
        int skipCount = 0;
        int skipEntryCount = 0;
        int divisionStatus = 0;
        int dataEntryCheck = 0;
        int endStatusCheck = 0;
        int endStatusCheck2 = 0;
        int colorCountTemp = 0;
        int checkStart = 0;
        int endStatusHoldCount = 0;
        int lineageDataLingSummaryCount = 0;
        int findBoth = 0;
        int extensionValueSource = 0;
        
        double cellSelect = 0;
        double parentCellNo = 0;
        double cellNoLow = 0;
        double cellNoHigh = 0;
        double expandCell = 0;
        double increment = 0;
        double horizontalIncrement = 0;
        double lengthDivision = 0;
        double lengthPix = 0;
        double rangeDivision = 0;
        double difference = 0;
        double difference2 = 0;
        double rangeDivisionAverage = 0;
        double rangeDivisionTotal = 0;
        double sumTotal = 0;
        double checkNoCheck = 0;
        double sumAverage = 0;
        double colorDataCount = 0;
        double cellNoEntry1 = 0;
        double cellNoEntry2 = 0;
        double cellNoSummary = 0;
        double lingNoSummary = 0;
        double extensionValue = 0;
        double parentInfo = 0;
        
        string cellNumberString;
        string ifName;
        string roundExtract;
        string liveName;
        string lineageNo;
        string timeInterval;
        string timeString;
        string fluorescentName;
        string extensionNoExtract;
        string extensionNoExtract2;
        string extensionNoExtractB;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint pointA2;
        
        CGFloat size2 = 0;
        
        for (int counter1 = 1; counter1 <= 8; counter1++){
            displayFlag = 0;
            lineagePositionLing = 0;
            
            if (counter1 == 1 && lingNo1 > 0){
                lineagePositionLing = lingNo1;
                displayFlag = 1;
                xStart = 10;
                yStart = 451;
            }
            else if (counter1 == 2 && lingNo2 > 0){
                lineagePositionLing = lingNo2;
                displayFlag = 1;
                xStart = 387;
                yStart = 451;
            }
            else if (counter1 == 3 && lingNo3 > 0){
                lineagePositionLing = lingNo3;
                displayFlag = 1;
                xStart = 10;
                yStart = 309;
            }
            else if (counter1 == 4 && lingNo4 > 0){
                lineagePositionLing = lingNo4;
                displayFlag = 1;
                xStart = 387;
                yStart = 309;
            }
            else if (counter1 == 5 && lingNo5 > 0){
                lineagePositionLing = lingNo5;
                displayFlag = 1;
                xStart = 10;
                yStart = 167;
            }
            else if (counter1 == 6 && lingNo6 > 0){
                lineagePositionLing = lingNo6;
                displayFlag = 1;
                xStart = 387;
                yStart = 167;
            }
            else if (counter1 == 7 && lingNo7 > 0){
                lineagePositionLing = lingNo7;
                displayFlag = 1;
                xStart = 10;
                yStart = 25;
            }
            else if (counter1 == 8 && lingNo8 > 0){
                lineagePositionLing = lingNo8;
                displayFlag = 1;
                xStart = 387;
                yStart = 25;
            }
            
            if (displayFlag == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1*magFactor];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor, yStart*magFactor, 372*magFactor, 117*magFactor)];
                [path stroke];
                
                //----Lineage data read----
                extractCount = 0;
                
                int *lineageSelect = new int [lineageLinkHold [selectCurrentLineage]+5];
                
                for (int counter3 = 0; counter3 < lineageLinkListLengthLing; counter3++){
                    if (arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter3] != 0){
                        lineageSelect [extractCount] = arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter3];
                        extractCount++;
                    }
                }
                
                double *arrayLineageDataLing = new double [5000];
                lineageExtractLingCount = 0;
                lineageExtractLingLimit = 5000;
                
                double *cellNoList = new double [5000];
                cellNoListCount = 0;
                cellNoListLimit = 5000;
                
                for (int counter2 = 0; counter2 < 5000; counter2++) cellNoList [counter2] = 0;
                
                for (int counter2 = 0; counter2 < extractCount; counter2++){
                    lineageNoFind = lineageSelect [counter2];
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [selectCurrentLineage]/9; counter3++){
                        if (arrayLineageData [selectCurrentLineage][counter3*9+6] == lineageNoFind){
                            if (lineageExtractLingCount+10 > lineageExtractLingLimit){
                                double *arrayUpDate = new double [lineageExtractLingCount+10];
                                
                                for (int counter4 = 0; counter4 < lineageExtractLingCount; counter4++) arrayUpDate [counter4] = arrayLineageDataLing [counter4];
                                
                                delete [] arrayLineageDataLing;
                                lineageExtractLingLimit = lineageExtractLingCount+500;
                                arrayLineageDataLing = new double [lineageExtractLingLimit];
                                
                                for (int counter4 = 0; counter4 < lineageExtractLingCount; counter4++) arrayLineageDataLing [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+1], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+2], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+3], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+4], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+5], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+6], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+7], lineageExtractLingCount++;
                            arrayLineageDataLing [lineageExtractLingCount] = arrayLineageData [selectCurrentLineage][counter3*9+8], lineageExtractLingCount++;
                            
                            if (arrayLineageData [selectCurrentLineage][counter3*9+3] == 1 || arrayLineageData [selectCurrentLineage][counter3*9+3] == 31 || arrayLineageData [selectCurrentLineage][counter3*9+3] == 41 || arrayLineageData [selectCurrentLineage][counter3*9+3] == 51){
                                if (cellNoListCount+10 > cellNoListLimit){
                                    double *arrayUpDate = new double [cellNoListCount+10];
                                    
                                    for (int counter4 = 0; counter4 < cellNoListCount; counter4++) arrayUpDate [counter4] = cellNoList [counter4];
                                    
                                    delete [] cellNoList;
                                    cellNoListLimit = cellNoListCount+500;
                                    cellNoList = new double [cellNoListLimit];
                                    
                                    for (int counter4 = 0; counter4 < cellNoListCount; counter4++) cellNoList [counter4] = arrayUpDate [counter4];
                                    delete [] arrayUpDate;
                                }
                                
                                cellNoList [cellNoListCount] = arrayLineageData [selectCurrentLineage][counter3*9+5], cellNoListCount++;
                                cellNoList [cellNoListCount] = arrayLineageData [selectCurrentLineage][counter3*9+4], cellNoListCount++;
                                cellNoList [cellNoListCount] = 0, cellNoListCount++;
                                cellNoList [cellNoListCount] = arrayLineageData [selectCurrentLineage][counter3*9+6], cellNoListCount++;
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 299999999 && cellNoList [counter2*4] >= -299999999){
                        cellNoList [counter2*4+2] = cellNoList [counter2*4]*1000000;
                        cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                    }
                    else if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                        extensionNoExtractB = to_string(extensionValueSource)+"000";
                        extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                        
                        if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                        
                        extensionNoExtract2 = extensionNoExtract2+"000000";
                        extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                        
                        cellNoList [counter2*4+2] = extensionValue;
                        cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                    }
                    else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] <= 299999999 && cellNoList [counter2*4+1] >= -299999999){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                        extensionNoExtractB = to_string(extensionValueSource)+"000";
                        
                        extensionNoExtract2 = to_string(cellNoList [counter2*4+1]);
                        
                        if ((int)extensionNoExtract2.find(".") != -1) extensionNoExtract2 = extensionNoExtract2.substr(0, extensionNoExtract2.find("."));
                        
                        extensionNoExtract2 = extensionNoExtract2+"000000";
                        extensionValue = atof(extensionNoExtract2.c_str())+atof(extensionNoExtractB.c_str());
                        
                        cellNoList [counter2*4+2] = extensionValue;
                        cellNoList [counter2*4+1] = cellNoList [counter2*4+1]*1000000;
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 499999999 && cellNoList [counter2*4] >= 300000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource)+"000";
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                    else if (cellNoList [counter2*4] >= -499999999 && cellNoList [counter2*4] <= -300000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource)+"000";
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 499999999 && cellNoList [counter2*4+1] >= 300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                    else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -499999999 && cellNoList [counter2*4+1] <= -300000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                for (int counter2 = 0; counter2 < cellNoListCount/4; counter2++){
                    if (cellNoList [counter2*4] <= 699999999 && cellNoList [counter2*4] >= 500000000 && cellNoList [counter2*4+1] <= 699999999 && cellNoList [counter2*4+1] >= 500000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(6, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] > 999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                    else if (cellNoList [counter2*4] >= -699999999 && cellNoList [counter2*4] <= -500000000 && cellNoList [counter2*4+1] >= -699999999 && cellNoList [counter2*4+1] <= -500000000){
                        extensionNoExtract = to_string(cellNoList [counter2*4]);
                        
                        if ((int)extensionNoExtract.find(".") != -1) extensionNoExtract = extensionNoExtract.substr(0, extensionNoExtract.find("."));
                        
                        extensionNoExtract = extensionNoExtract.substr(7, 3);
                        parentInfo = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter3*4] == cellNoList [counter2*4+1]){
                                parentInfo = cellNoList [counter3*4+1];
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (cellNoList [counter2*4+1] == cellNoList [counter3*4] && cellNoList [counter3*4+1] < -999999999 && cellNoList [counter2*4+3] == cellNoList [counter3*4+3]){
                                extensionValueSource = atoi(extensionNoExtract.c_str())-500;
                                extensionNoExtractB = to_string(extensionValueSource);
                                extensionValue = parentInfo+atof(extensionNoExtractB.c_str());
                                cellNoList [counter2*4+2] = extensionValue;
                                cellNoList [counter2*4+1] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                cellNoEntry1 = 0;
                cellNoSummary = 0;
                lingNoSummary = 0;
                
                for (int counter2 = 0; counter2 < lineageExtractLingCount/9; counter2++){
                    if (cellNoSummary != arrayLineageDataLing [counter2*9+5] || lingNoSummary != arrayLineageDataLing [counter2*9+6]){
                        cellNoSummary = arrayLineageDataLing [counter2*9+5];
                        lingNoSummary = arrayLineageDataLing [counter2*9+6];
                        
                        findBoth = 0;
                        cellNoEntry1 = 0;
                        cellNoEntry2 = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (arrayLineageDataLing [counter2*9+5] == cellNoList [counter3*4] && arrayLineageDataLing [counter2*9+6] == cellNoList [counter3*4+3]){
                                cellNoEntry1 = cellNoList [counter3*4+2];
                                findBoth++;
                            }
                            
                            if (arrayLineageDataLing [counter2*9+4] == cellNoList [counter3*4]  && arrayLineageDataLing [counter2*9+6] == cellNoList [counter3*4+3]){
                                cellNoEntry2 = cellNoList [counter3*4+2];
                                findBoth++;
                            }
                            
                            if (findBoth == 2){
                                break;
                            }
                        }
                        
                        arrayLineageDataLing [counter2*9+5] = cellNoEntry1;
                        arrayLineageDataLing [counter2*9+4] = cellNoEntry2;
                    }
                    else arrayLineageDataLing [counter2*9+5] = cellNoEntry1;
                    
                    if (arrayLineageDataLing [counter2*9+3] == 91 || arrayLineageDataLing [counter2*9+3] == 92){
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (arrayLineageDataLing [counter2*9+4] == cellNoList [counter3*4]){
                                arrayLineageDataLing [counter2*9+4] = cellNoList [counter3*4+2];
                                break;
                            }
                        }
                    }
                }
                
                double *arrayLineageDataLingSummary = new double [lineageExtractLingCount+50];
                lineageDataLingSummaryCount = 0;
                
                cellNoSummary = 0;
                lingNoSummary = 0;
                
                for (int counter2 = 0; counter2 < lineageExtractLingCount/9; counter2++){
                    if (arrayLineageDataLing [counter2*9+3] != 2){
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+1], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+2], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+3], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+4], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+5], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+6], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+7], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+8], lineageDataLingSummaryCount++;
                    }
                    
                    if (cellNoSummary != arrayLineageDataLing [counter2*9+5] || lingNoSummary != arrayLineageDataLing [counter2*9+6]){
                        cellNoSummary = arrayLineageDataLing [counter2*9+5];
                        lingNoSummary = arrayLineageDataLing [counter2*9+6];
                        
                        if (counter2 != 0 && arrayLineageDataLing [(counter2-1)*9+3] == 2){
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+1], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+2], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+3], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+4], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+5], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+6], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+7], lineageDataLingSummaryCount++;
                            arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [(counter2-1)*9+8], lineageDataLingSummaryCount++;
                        }
                    }
                    
                    if (counter2 == lineageExtractLingCount/9-1){
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+1], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+2], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+3], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+4], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+5], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+6], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+7], lineageDataLingSummaryCount++;
                        arrayLineageDataLingSummary [lineageDataLingSummaryCount] = arrayLineageDataLing [counter2*9+8], lineageDataLingSummaryCount++;
                    }
                }
                
                //----Lineage no----
                lineageFuseNo = 0;
                
                for (int counter2 = 0; counter2 < lineageLinkListLengthLing; counter2++){
                    if (arrayLineageLinkListLGL [lineagePositionLing*lineageLinkListLengthLing+counter2] != 0){
                        lineageFuseNo++;
                    }
                }
                
                lineageNo = to_string(arrayLineageLinkListLGL [lineagePositionLing*lineageLinkListLengthLing]);
                
                for (int counter2 = 1; counter2 < lineageLinkListLengthLing; counter2++){
                    if (arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter2] != 0){
                        lineageNo = lineageNo+", "+to_string(arrayLineageLink [selectCurrentLineage][lineagePositionLing*lineageLinkListLengthLing+counter2]);
                    }
                }
                
                //----Fluorescent data read----
                int *arrayIFDataLing = new int [5000];
                lineageExtractIFCount = 0;
                lineageExtractIFLimit = 5000;
                
                for (int counter2 = 0; counter2 < extractCount; counter2++){
                    lineageNoFind = lineageSelect [counter2];
                    
                    for (int counter3 = 0; counter3 < arrayIFDataEntryHold [selectCurrentLineage]/22; counter3++){
                        if (arrayIFData [selectCurrentLineage][counter3*22+1] == lineageNoFind){
                            if (lineageExtractIFCount+50 > lineageExtractIFLimit){
                                int *arrayUpDate = new int [lineageExtractIFCount+20];
                                
                                for (int counter4 = 0; counter4 < lineageExtractIFCount; counter4++) arrayUpDate [counter4] = arrayIFDataLing [counter4];
                                
                                delete [] arrayIFDataLing;
                                lineageExtractIFLimit = lineageExtractIFCount+5000;
                                arrayIFDataLing = new int [lineageExtractIFLimit];
                                
                                for (int counter4 = 0; counter4 < lineageExtractIFCount; counter4++) arrayIFDataLing [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+1], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+2], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+3], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+4], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+5], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+6], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+7], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+8], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+9], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+10], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+11], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+12], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+13], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+14], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+15], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+16], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+17], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+18], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+19], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+20], lineageExtractIFCount++;
                            arrayIFDataLing [lineageExtractIFCount] = arrayIFData [selectCurrentLineage][counter3*22+21], lineageExtractIFCount++;
                        }
                    }
                }
                
                //----Horizontal Scale----
                horizontalTime = arrayTableDetail [selectCurrentLineage][3];
                timeInterval = arrayLineageDataType [selectCurrentLineage][5];
                
                timeString = "";
                
                if (displayNameTreatLing != "nil") timeString = displayNameTreatLing+"-"+lineageNo;
                else timeString = "Lineage-"+lineageNo+" T. point (x"+timeInterval+" min)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:10*magFactor];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:10*magFactor] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = xStart*magFactor+186*magFactor-size2/(double)2;
                pointA.y = yStart*magFactor-21*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                lengthDivision = horizontalTime/(double)5;
                lengthDivisionInt = 0;
                
                if (lengthDivision <= 25) lengthDivisionInt = 25;
                else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                else if (lengthDivision > 450 && lengthDivision <= 550) lengthDivisionInt = 500;
                else if (lengthDivision > 550 && lengthDivision <= 650) lengthDivisionInt = 600;
                else if (lengthDivision > 650 && lengthDivision <= 750) lengthDivisionInt = 700;
                else if (lengthDivision > 750 && lengthDivision <= 850) lengthDivisionInt = 800;
                else if (lengthDivision > 850 && lengthDivision <= 950) lengthDivisionInt = 900;
                else if (lengthDivision > 950 && lengthDivision <= 1050) lengthDivisionInt = 1000;
                else if (lengthDivision > 1050 && lengthDivision <= 1150) lengthDivisionInt = 1100;
                else if (lengthDivision > 1150 && lengthDivision <= 1250) lengthDivisionInt = 1200;
                else if (lengthDivision > 1250 && lengthDivision <= 1350) lengthDivisionInt = 1300;
                else if (lengthDivision > 1350 && lengthDivision <= 1450) lengthDivisionInt = 1400;
                else if (lengthDivision > 1450 && lengthDivision <= 1550) lengthDivisionInt = 1500;
                
                lengthPix = ((360-10)/(double)horizontalTime)*lengthDivisionInt;
                numberOfDivision = (int)((330-10)/(double)lengthPix)+1;
                
                sift = 0;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = xStart*magFactor+lengthPix*counter2*magFactor;
                    positionAA.y = yStart*magFactor;
                    positionBB.x = xStart*magFactor+lengthPix*counter2*magFactor;
                    positionBB.y = yStart*magFactor+5*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:9*magFactor] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (xStart+lengthPix*counter2)*magFactor-size2/(double)2-sift*magFactor;
                    pointA2.y = yStart*magFactor-12*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                //----Lineage display Horizontal set----
                numberOfCellEntry = 0;
                numberOfEventCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                    if (arrayLineageDataLingSummary [counter2*9+3] == 1 || arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                        numberOfCellEntry++;
                        numberOfEventCount++;
                    }
                    
                    if (arrayLineageDataLingSummary [counter2*9+3] == 32 || arrayLineageDataLingSummary [counter2*9+3] == 42 || arrayLineageDataLingSummary [counter2*9+3] == 52 || arrayLineageDataLingSummary [counter2*9+3] == 91 || arrayLineageDataLingSummary [counter2*9+3] == 6 || arrayLineageDataLingSummary [counter2*9+3] == 92 || arrayLineageDataLingSummary [counter2*9+3] == 8 || arrayLineageDataLingSummary [counter2*9+3] == 10 || arrayLineageDataLingSummary [counter2*9+3] == 11 || arrayLineageDataLingSummary [counter2*9+3] == 7){
                        numberOfEventCount++;
                    }
                }
                
                double *horizontalList = new double [numberOfCellEntry*7+50];
                horizontalListCount = 0;
                double *eventList = new double [numberOfEventCount*5+50];
                eventListCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                    if (arrayLineageDataLingSummary [counter2*9+3] == 1 || arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+5], horizontalListCount++;
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+6], horizontalListCount++;
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+8], horizontalListCount++;
                        horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter2*9+2], horizontalListCount++;
                        
                        largestTimePoint = 0;
                        findFlag = 0;
                        
                        for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                            if ((arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+3] == 91 || arrayLineageDataLingSummary [counter3*9+3] == 6 || arrayLineageDataLingSummary [counter3*9+3] == 92 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 10 || arrayLineageDataLingSummary [counter3*9+3] == 11 || arrayLineageDataLingSummary [counter3*9+3] == 7) && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+6] == arrayLineageDataLingSummary [counter2*9+6]){
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+5], eventListCount++;
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+6], eventListCount++;
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+2], eventListCount++;
                                eventList [eventListCount] = arrayLineageDataLingSummary [counter3*9+3], eventListCount++;
                                eventList [eventListCount] = 0, eventListCount++;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                            if ((arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+3] == 91) && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+6] == arrayLineageDataLingSummary [counter2*9+6]){
                                horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter3*9+2], horizontalListCount++;
                                horizontalList [horizontalListCount] = arrayLineageDataLingSummary [counter3*9+3], horizontalListCount++;
                                findFlag = 1;
                                break;
                            }
                            else{
                                
                                if (arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+6] == arrayLineageDataLingSummary [counter2*9+6]){
                                    if (arrayLineageDataLingSummary [counter3*9+2] > largestTimePoint) largestTimePoint = (int)(arrayLineageDataLingSummary [counter3*9+2]);
                                }
                            }
                        }
                        
                        if (findFlag == 0){
                            horizontalList [horizontalListCount] = largestTimePoint, horizontalListCount++;
                            horizontalList [horizontalListCount] = 2, horizontalListCount++;
                        }
                        
                        if (arrayLineageDataLingSummary [counter2*9+3] == 1) horizontalList [horizontalListCount] = 1, horizontalListCount++;
                        else horizontalList [horizontalListCount] = 0, horizontalListCount++;
                    }
                }
                
                //for (int counterA = 0; counterA < horizontalListCount/7; counterA++){
                //    cout<<horizontalList [counterA*7]<<" "<<horizontalList [counterA*7+1]<<" "<<horizontalList [counterA*7+2]<<" "<<horizontalList [counterA*7+3]<<" "<<horizontalList [counterA*7+4]<<" horizontalList"<<endl;
                //}
                
                //for (int counterA = 0; counterA < eventListCount/5; counterA++){
                //    cout<<eventList [counterA*5]<<" "<<eventList [counterA*5+1]<<" "<< eventList [counterA*5+2]<<" "<<eventList [counterA*5+3]<<" "<<eventList [counterA*5+4]<<"   eventList"<<endl;
                //}
                
                double *horizontalList2 = new double [numberOfCellEntry*7+50];
                horizontalListCount2 = 0;
                double *eventList2 = new double [numberOfEventCount*6+50];
                eventListCount2 = 0;
                
                for (int counter2 = 0; counter2 < numberOfEventCount*6+50; counter2++) eventList2 [counter2] = 0;
                
                entryOrder = 0;
                
                do{
                    
                    terminationFlag = 1;
                    lineageSelectNo = 100000;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount/7; counter2++){
                        if (horizontalList [counter2*7+1] != -1){
                            lineageSelectNo = (int)(horizontalList [counter2*7+1]);
                            break;
                        }
                    }
                    
                    if (lineageSelectNo == 100000) terminationFlag = 0;
                    else{
                        
                        cellSelect = 999999999999999;
                        cellSelectPosition = 0;
                        
                        for (int counter2 = 0; counter2 < horizontalListCount/7; counter2++){
                            if (horizontalList [counter2*7] != -1 && horizontalList [counter2*7+1] == lineageSelectNo && horizontalList [counter2*7] < cellSelect){
                                cellSelect = horizontalList [counter2*7];
                                cellSelectPosition = counter2;
                            }
                        }
                        
                        if (cellSelect != 999999999999999){
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7], horizontalListCount2++; //----Cell no---
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+1], horizontalListCount2++; //----Ling no----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+2], horizontalListCount2++; //----Rev Cell no----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+3], horizontalListCount2++; //----Time start----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+4], horizontalListCount2++; //----Time end----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+5], horizontalListCount2++; //----Event last----
                            horizontalList2 [horizontalListCount2] = horizontalList [cellSelectPosition*7+6], horizontalListCount2++; //----Event I----
                            
                            for (int counter2 = 0; counter2 < eventListCount/5; counter2++){
                                if (eventList [counter2*5] == horizontalList [cellSelectPosition*7] && eventList [counter2*5+1] == horizontalList [cellSelectPosition*7+1]){
                                    eventList2 [eventListCount2] = eventList [counter2 *5], eventListCount2++; //----Cell no----
                                    eventList2 [eventListCount2] = eventList [counter2 *5+1], eventListCount2++; //----Ling no----
                                    eventList2 [eventListCount2] = eventList [counter2 *5+2], eventListCount2++; //----Time----
                                    eventList2 [eventListCount2] = eventList [counter2 *5+3], eventListCount2++; //----Event----
                                    eventList2 [eventListCount2] = entryOrder, eventListCount2++; //----Entry order----
                                }
                            }
                            
                            horizontalList [cellSelectPosition*7] = -1;
                            horizontalList [cellSelectPosition*7+1] = -1;
                            
                            entryOrder++;
                        }
                    }
                    
                } while (terminationFlag == 1);
                
                //----Lineage display Vertical set----
                double *verticalList = new double [numberOfEventCount*9+50];
                verticalListCount = 0;
                
                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                    if (arrayLineageDataLingSummary [counter2*9+3] == 91){
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 92 && arrayLineageDataLingSummary [counter2*9+4] == arrayLineageDataLingSummary [counter3*9+5] && arrayLineageDataLingSummary [counter2*9+7] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]){
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 91, verticalListCount++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 92){
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 91 && arrayLineageDataLingSummary [counter2*9+4] == arrayLineageDataLingSummary [counter3*9+5] && arrayLineageDataLingSummary [counter2*9+7] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]){
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                    verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 0, verticalListCount++;
                                    verticalList [verticalListCount] = 91, verticalListCount++;
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 31){
                        parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 31 && arrayLineageDataLingSummary [counter2*9+6] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+4] == parentCellNo && arrayLineageDataLingSummary [counter3*9+5] != arrayLineageDataLingSummary [counter2*9+5] && arrayLineageDataLingSummary [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]){
                                    if (arrayLineageDataLingSummary [counter3*9+5] > arrayLineageDataLingSummary [counter2*9+5]){
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 31, verticalListCount++;
                                    }
                                    else{
                                        
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter3*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+5], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+6], verticalListCount++;
                                        verticalList [verticalListCount] = arrayLineageDataLingSummary [counter2*9+2], verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 0, verticalListCount++;
                                        verticalList [verticalListCount] = 31, verticalListCount++;
                                    }
                                    
                                    break;
                                }
                            }
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 41){
                        parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                        cellNoLow = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoHigh = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoLowPosition = counter2;
                        cellNoHighPosition = counter2;
                        
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 41 && arrayLineageDataLingSummary [counter2*9+6] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+4] == parentCellNo && arrayLineageDataLingSummary [counter3*9+5] != arrayLineageDataLingSummary [counter2*9+5]){
                                    if (arrayLineageDataLingSummary [counter3*9+5] > cellNoHigh){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoHighPosition = counter3;
                                    }
                                    
                                    if (arrayLineageDataLingSummary [counter3*9+5] < cellNoLow){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoLowPosition = counter3;
                                    }
                                }
                            }
                            
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+5], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+6], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+2], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+5], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+6], verticalListCount++;
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+2], verticalListCount++;
                            verticalList [verticalListCount] = 0, verticalListCount++;
                            verticalList [verticalListCount] = 0, verticalListCount++;
                            verticalList [verticalListCount] = 41, verticalListCount++;
                        }
                    }
                    else if (arrayLineageDataLingSummary [counter2*9+3] == 51){
                        parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                        cellNoLow = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoHigh = arrayLineageDataLingSummary [counter2*9+5];
                        cellNoLowPosition = counter2;
                        cellNoHighPosition = counter2;
                        
                        matchFindFlag = 0;
                        
                        for (int counter3 = 0; counter3 < verticalListCount/9; counter3++){
                            if ((verticalList [counter3*9] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+1] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+2] == arrayLineageDataLingSummary [counter2*9+2]) || (verticalList [counter3*9+3] == arrayLineageDataLingSummary [counter2*9+5] && verticalList [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+6] && verticalList [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+2])){
                                matchFindFlag = 1;
                            }
                        }
                        
                        if (matchFindFlag == 0){
                            for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                if (arrayLineageDataLingSummary [counter3*9+3] == 51 && arrayLineageDataLingSummary [counter2*9+6] == arrayLineageDataLingSummary [counter3*9+6] && arrayLineageDataLingSummary [counter3*9+4] == parentCellNo && arrayLineageDataLingSummary [counter3*9+5] != arrayLineageDataLingSummary [counter2*9+5]){
                                    if (arrayLineageDataLingSummary [counter3*9+5] > cellNoHigh){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoHighPosition = counter3;
                                    }
                                    
                                    if (arrayLineageDataLingSummary [counter3*9+5] < cellNoLow){
                                        cellNoHigh = arrayLineageDataLingSummary [counter3*9+5];
                                        cellNoLowPosition = counter3;
                                    }
                                }
                            }
                            
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+5], verticalListCount++; //----Cell no 1----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+6], verticalListCount++; //----Ling no 1----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoLowPosition*9+2], verticalListCount++; //----Time 1----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+5], verticalListCount++; //----Cell no 2----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+6], verticalListCount++; //----Ling no 2----
                            verticalList [verticalListCount] = arrayLineageDataLingSummary [cellNoHighPosition*9+2], verticalListCount++; //----Time 2----
                            verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 1----
                            verticalList [verticalListCount] = 0, verticalListCount++; //----Cell order 2----
                            verticalList [verticalListCount] = 51, verticalListCount++; //----Event----
                        }
                    }
                }
                
                //for (int counterA = 0; counterA < verticalListCount/9; counterA++){
                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<< verticalList [counterA*9+counterB];
                //    cout<<" verticalList "<<counterA<<" "<<counter1<<endl;
                //}
                
                for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                    for (int counter3 = 0; counter3 < horizontalListCount2/7; counter3++){
                        if (horizontalList2 [counter3*7] == verticalList [counter2*9] && horizontalList2 [counter3*7+1] == verticalList [counter2*9+1]){
                            verticalList [counter2*9+6] = counter3;
                            break;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < horizontalListCount2/7; counter3++){
                        if (horizontalList2 [counter3*7] == verticalList [counter2*9+3] && horizontalList2 [counter3*7+1] == verticalList [counter2*9+4]){
                            verticalList [counter2*9+7] = counter3;
                            break;
                        }
                    }
                }
                
                increment = 117/(double)(numberOfCellEntry+1);
                horizontalIncrement = (330-10)/(double)horizontalTime;
                
                //----Lineage Display Vertical----
                [NSBezierPath setDefaultLineWidth:lingLineWidthHold*magFactor];
                
                for (int counter2 = 0; counter2 < verticalListCount/9; counter2++){
                    if (verticalList [counter2*9+8] == 91) [[NSColor orangeColor] set];
                    else if (verticalList [counter2*9+8] == 31) [[NSColor blackColor] set];
                    else if (verticalList [counter2*9+8] == 41) [[NSColor redColor] set];
                    else if (verticalList [counter2*9+8] == 51) [[NSColor redColor] set];
                    
                    positionAA.x = xStart*magFactor+verticalList [counter2*9+2]*horizontalIncrement*magFactor;
                    positionAA.y = yStart*magFactor+increment*magFactor+verticalList [counter2*9+6]*increment*magFactor;
                    positionBB.x = xStart*magFactor+verticalList [counter2*9+5]*horizontalIncrement*magFactor;
                    positionBB.y = yStart*magFactor+increment*magFactor+verticalList [counter2*9+7]*increment*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                }
                
                //----Live vertical line----
                [NSBezierPath setDefaultLineWidth:1*magFactor];
                
                roundNoGet = 0;
                
                int *liveTimeList = new int [arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9+1];
                liveTimeListCount = 0;
                
                if (liveDisplayHold == 1 || ifOneAllHold != 0){
                    for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [selectCurrentLineage]/9; counter2++){
                        if (arrayIFTimeLineData [selectCurrentLineage][counter2*9+1] == -1){
                            liveTimeList [liveTimeListCount] = arrayIFTimeLineData [selectCurrentLineage][counter2*9], liveTimeListCount++;
                            
                            if (blueLineDisplayHold == 0){
                                [[NSColor blueColor] set];
                                
                                if (arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement < 50){
                                    positionAA.x = xStart*magFactor+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement*magFactor;
                                    positionAA.y = yStart*magFactor;
                                    positionBB.x = xStart*magFactor+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement*magFactor;
                                    positionBB.y = yStart*magFactor+100*magFactor;
                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                }
                                else{
                                    
                                    positionAA.x = xStart*magFactor+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement*magFactor;
                                    positionAA.y = yStart*magFactor;
                                    positionBB.x = xStart*magFactor+arrayIFTimeLineData [selectCurrentLineage][counter2*9]*horizontalIncrement*magFactor;
                                    positionBB.y = yStart*magFactor+107*magFactor;
                                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                                }
                            }
                        }
                        
                        if (arrayIFTimeLineData [selectCurrentLineage][counter2*9] == ifOneAllHold) roundNoGet = arrayIFTimeLineData [selectCurrentLineage][counter2*9+1];
                    }
                    
                    if ((liveDisplayHold == 1 || liveDisplayHold == 2)){
                        ifName = arrayTableMain [selectCurrentLineage][chNo1+5];
                        fluorescentName = "Live: "+ifName;
                        
                        [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                        [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                        
                        attrStrA = [[NSAttributedString alloc] initWithString:@(fluorescentName.c_str()) attributes:attributesA];
                        pointA.x = xStart*magFactor+2*magFactor;
                        pointA.y = yStart*magFactor+103*magFactor;
                        [attrStrA drawAtPoint:pointA];
                    }
                }
                
                findMainLength = arrayTableMainHold [selectCurrentLineage];
                
                double *horizontalLineList = new double [horizontalListCount2/7*3+50];
                double *horizontalLineListValue = new double [horizontalListCount2/7*2+50];
                
                rangeAverageLow = 0;
                rangeAverageHigh = 0;
                rangeTotalLow = 0;
                rangeTotalHigh = 0;
                
                if (liveDisplayHold == 3 || liveDisplayHold == 4){
                    ifName = "";
                    
                    for (int counter2 = 13; counter2 < findMainLength; counter2 = counter2+8){
                        if (atoi(arrayTableMain [selectCurrentLineage][counter2].c_str()) == roundNoGet){
                            ifName = arrayTableMain [selectCurrentLineage][counter2+chNo1+1];
                            break;
                        }
                    }
                    
                    for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                        roundExtract = arrayLineageFluorescentDataType [counter2][1];
                        roundExtract = roundExtract.substr(1);
                        
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == selectCurrentLineage+1 && atoi(roundExtract.c_str()) == roundNoGet && arrayLineageFluorescentDataType [counter2][2] == ifName){
                            rangeTotalLow = atoi(arrayLineageFluorescentDataType [counter2][6].c_str());
                            rangeTotalHigh = atoi(arrayLineageFluorescentDataType [counter2][7].c_str());
                            rangeAverageLow = atoi(arrayLineageFluorescentDataType [counter2][4].c_str());
                            rangeAverageHigh = atoi(arrayLineageFluorescentDataType [counter2][5].c_str());
                            break;
                        }
                    }
                    
                    double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                    fluorescentEntryCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        if (horizontalList2 [counter2*7+3] <= ifOneAllHold && horizontalList2 [counter2*7+4] >= ifOneAllHold){
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                            fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    cout<<horizontalList2 [counterA*7]<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                    //    cout<<fluorescentEntry [counterA*5]<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fluorescentEntryCount/5; counter2++){
                        cellNoOriginal = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (fluorescentEntry [counter2*5] == cellNoList [counter3*4+2]){
                                cellNoOriginal = (int)(cellNoList [counter3*4]);
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < lineageExtractIFCount/22; counter3++){
                            if (cellNoOriginal == arrayIFDataLing [counter3*22] && fluorescentEntry [counter2*5+1] == arrayIFDataLing [counter3*22+1] && ifOneAllHold == arrayIFDataLing [counter3*22+2]){
                                if (chNo1+6 == 7){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+5];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+5]*arrayIFDataLing [counter3*22+6];
                                }
                                else if (chNo1+6 == 8){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+8];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+8]*arrayIFDataLing [counter3*22+9];
                                }
                                else if (chNo1+6 == 9){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+11];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+11]*arrayIFDataLing [counter3*22+12];
                                }
                                else if (chNo1+6 == 10){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+14];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+14]*arrayIFDataLing [counter3*22+15];
                                }
                                else if (chNo1+6 == 11){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+17];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+17]*arrayIFDataLing [counter3*22+18];
                                }
                                else if (chNo1+6 == 12){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+20];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+20]*arrayIFDataLing [counter3*22+21];
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    if (averageTotalSetHold == 0){
                        rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                        
                        for (int counter2 = 0; counter2 < fluorescentEntryCount/5; counter2++){
                            if (fluorescentEntry [counter2*5+2] <= rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                            else if (fluorescentEntry [counter2*5+2] < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = xStart*magFactor+355*magFactor;
                            positionAA.y = yStart*magFactor+increment*magFactor+fluorescentEntry [counter2*5+4]*increment*magFactor;
                            positionBB.x = xStart*magFactor+365*magFactor;
                            positionBB.y = yStart*magFactor+increment*magFactor+fluorescentEntry [counter2*5+4]*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else{
                        
                        rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                        
                        for (int counter2 = 0; counter2 <= fluorescentEntryCount/5; counter2++){
                            if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                            else if (fluorescentEntry [counter2*5+3] < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                            else rangeNo = 24;
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                            
                            positionAA.x = xStart*magFactor+355*magFactor;
                            positionAA.y = yStart*magFactor+increment*magFactor+fluorescentEntry [counter2*5+4]*increment*magFactor;
                            positionBB.x = xStart*magFactor+365*magFactor;
                            positionBB.y = yStart*magFactor+increment*magFactor+fluorescentEntry [counter2*5+4]*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    
                    fluorescentName = "IF: "+ifName;
                    
                    [attributesA setObject:[NSFont boldSystemFontOfSize:11*magFactor] forKey:NSFontAttributeName];
                    [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA = [[NSAttributedString alloc] initWithString:@(fluorescentName.c_str()) attributes:attributesA];
                    
                    pointA.x = xStart*magFactor+2*magFactor;
                    pointA.y = yStart*magFactor+103*magFactor;
                    
                    [attrStrA drawAtPoint:pointA];
                    
                    if (liveDisplayHold == 4){
                        for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                            horizontalLineList [counter2] = 0;
                        }
                        
                        for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                            horizontalLineListValue [counter2] = 0;
                        }
                        
                        horizontalLineListCount = 0;
                        horizontalLineListValueCount = 0;
                        
                        for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                            horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                            horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                            horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                            
                            horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                            horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                        }
                        
                        //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                        //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                        //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                        //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                        //}
                        
                        //----Enter fluorescent value at the end point----
                        if (colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                        else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                        else horizontalLineListValue [counter2*2] = -100;
                                        
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //----Set dummy value at CD, OF FU lines----
                        if (siblingLingHold == 1 && colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3]  && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else if (colorOptionLingHold == 1){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3] && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            
                                            horizontalLineListValue [counter2*2] = -100;
                                            horizontalLineListValue [counter2*2+1] = 100;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                        //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                        //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractLingCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<to_string(arrayLineageDataLingSummary [counterA*9+counterB]);
                        //    cout<<" arrayLineageDataLingSummary "<<counterA<<endl;
                        //}
                        
                        expandCell = 0;
                        skipCount = 0;
                        
                        double *cellNoListTemp = new double [10];
                        
                        int *endStatusHold = new int [20];
                        
                        do{
                            
                            terminationFlag = 1;
                            expandLineage = 0;
                            skipEntryCount = skipCount;
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                    expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                    expandCell = horizontalLineList [counter2*3];
                                    break;
                                }
                                else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                            }
                            
                            if (expandLineage != 0){
                                parentCellNo = -1;
                                
                                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                    if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                        if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+5] == expandCell){
                                            parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                                            break;
                                        }
                                    }
                                }
                                
                                if (parentCellNo != -1){
                                    cellNoListTempCount = 0;
                                    endStatusHoldCount = 0;
                                    divisionStatus = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                        if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                            if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+4] == parentCellNo){
                                                if (arrayLineageDataLingSummary [counter2*9+3] == 31) divisionStatus = 2;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 41) divisionStatus = 3;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 51) divisionStatus = 4;
                                                
                                                cellNoListTemp [cellNoListTempCount] = arrayLineageDataLingSummary [counter2*9+5], cellNoListTempCount++;
                                                
                                                endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                                endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                                
                                                //----Check end status, enter 1 when end is CD, OF, FU----
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        endStatusHold [endStatusHoldCount-2] = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                checkStart = 0;
                                                checkNoCheck = 0;
                                                
                                                //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+5]  && arrayLineageDataLingSummary [counter3*9+3] != 91 && arrayLineageDataLingSummary [counter3*9+4] != 92){
                                                        checkStart = 1;
                                                        checkNoCheck = arrayLineageDataLingSummary [counter3*9+5];
                                                    }
                                                    
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                        checkStart = 0;
                                                    }
                                                    else if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                        
                                                        endStatusHold [endStatusHoldCount-1] = 0;
                                                        break;
                                                    }
                                                }
                                                
                                                if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                            }
                                        }
                                    }
                                    
                                    endStatusCheck = 0;
                                    endStatusCheck2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                        if (endStatusHold [counter2*2] == 1) endStatusCheck = 1;
                                        if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                    }
                                    
                                    sumTotal = 0;
                                    sumAverage = 0;
                                    colorDataCount = 0;
                                    colorCountTemp = 0;
                                    
                                    if (colorOptionLingHold == 1) sumAverage = -1;
                                    
                                    if (colorOptionLingHold == 0){
                                        if (siblingLingHold == 0){
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (siblingLingHold == 1){
                                            if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                endStatusCheck = 0;
                                                dataEntryCheck = 0;
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                    
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                            dataEntryCheck = 1;
                                                        }
                                                    }
                                                }
                                                
                                                if (endStatusCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumTotal = -2;
                                                                sumAverage = -2;
                                                                
                                                                horizontalLineListValue [counter3*2] = -1;
                                                                horizontalLineListValue [counter3*2+1] = -1;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                else if (dataEntryCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                        if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                    horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                    horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                    horizontalLineList [counter3*3+2] = -1;
                                                                    
                                                                    colorDataCount++;
                                                                    
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (colorOptionLingHold == 1){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        
                                                        //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<valueUK<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                        
                                                        if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else sumAverage = -100;
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = 0;
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = 0;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumAverage = -100;
                                                                
                                                                horizontalLineListValue [counter3*2] = -100;
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    if (endStatusHold [counter2*2] == 0){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                
                                                                if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else sumAverage = -100;
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                    //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                    //}
                                    
                                    if (colorDataCount == divisionStatus){
                                        skipCount = 0;
                                        
                                        if (colorOptionLingHold == 0){
                                            if (colorCountTemp == 0){
                                                sumTotal = sumTotal/(double)colorDataCount;
                                                sumAverage = (int)(sumAverage/(double)colorDataCount);
                                            }
                                            else{
                                                
                                                sumTotal = sumTotal/(double)colorCountTemp;
                                                sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                            if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentCellNo){
                                                horizontalLineListValue [counter2*2] = sumAverage;
                                                horizontalLineListValue [counter2*2+1] = sumTotal;
                                                horizontalLineList [counter2*3+2] = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else skipCount++;
                                }
                                else{
                                    
                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                            horizontalLineList [counter3*3+2] = -1;
                                        }
                                    }
                                }
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        delete [] cellNoListTemp;
                        delete [] endStatusHold;
                    }
                    
                    delete [] fluorescentEntry;
                }
                
                if (liveDisplayHold == 2){
                    int liveIfLastTimePoint = 0;
                    
                    for (int counter2 = 0; counter2 < lineageExtractIFCount/22; counter2++){
                        if (arrayIFDataLing [counter2*22+2] > liveIfLastTimePoint) liveIfLastTimePoint = arrayIFDataLing [counter2*22+2];
                    }
                    
                    double *fluorescentEntry = new double [numberOfCellEntry*5+50];
                    fluorescentEntryCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        if (horizontalList2 [counter2*7+3] <= arrayTableDetail [selectCurrentLineage][3] && horizontalList2 [counter2*7+4] >= arrayTableDetail [selectCurrentLineage][3]){
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7], fluorescentEntryCount++; //----Cell no----
                            fluorescentEntry [fluorescentEntryCount] = horizontalList2 [counter2*7+1], fluorescentEntryCount++; //----Ling no----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----AV----
                            fluorescentEntry [fluorescentEntryCount] = 0, fluorescentEntryCount++; //----Total----
                            fluorescentEntry [fluorescentEntryCount] = counter2, fluorescentEntryCount++; //----Cell order----
                        }
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    cout<<to_string(horizontalList2 [counterA*7])<<" "<<horizontalList2 [counterA*7+1]<<" "<<horizontalList2 [counterA*7+2]<<" "<<horizontalList2 [counterA*7+3]<<" "<<horizontalList2 [counterA*7+4]<<" "<<horizontalList2 [counterA*7+5]<<" "<<horizontalList2 [counterA*7+6]<<"  horizontalList2"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                    //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < ifEntryCount/13; counterA++){
                    //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFData [tableCurrentRowHold][counterA*13+counterB];
                    //    cout<<" arrayIFData "<<counterA<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < fluorescentEntryCount/5; counter2++){
                        cellNoOriginal = 0;
                        
                        for (int counter3 = 0; counter3 < cellNoListCount/4; counter3++){
                            if (fluorescentEntry [counter2*5] == cellNoList [counter3*4+2]){
                                cellNoOriginal = (int)(cellNoList [counter3*4]);
                                break;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < lineageExtractIFCount/22; counter3++){
                            if (cellNoOriginal == arrayIFDataLing [counter3*22] && (int)(fluorescentEntry [counter2*5+1]) == arrayIFDataLing [counter3*22+1] && liveIfLastTimePoint == arrayIFDataLing [counter3*22+2]){
                                if (chNo1 == 1){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+5];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+5]*arrayIFDataLing [counter3*22+6];
                                }
                                else if (chNo1 == 2){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+8];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+8]*arrayIFDataLing [counter3*22+9];
                                }
                                else if (chNo1 == 3){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+11];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+11]*arrayIFDataLing [counter3*22+12];
                                }
                                else if (chNo1 == 4){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+14];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+14]*arrayIFDataLing [counter3*22+15];
                                }
                                else if (chNo1 == 5){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+17];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+17]*arrayIFDataLing [counter3*22+18];
                                }
                                else if (chNo1 == 6){
                                    fluorescentEntry [counter2*5+2] = arrayIFDataLing [counter3*22+20];
                                    fluorescentEntry [counter2*5+3] = arrayIFDataLing [counter3*22+20]*arrayIFDataLing [counter3*22+21];
                                }
                                
                                break;
                            }
                        }
                    }
                    
                    //for (int counterA = 0; counterA < fluorescentEntryCount/5; counterA++){
                    //    cout<<to_string(fluorescentEntry [counterA*5])<<" "<<fluorescentEntry [counterA*5+1]<<" "<< fluorescentEntry [counterA*5+2]<<" "<<fluorescentEntry [counterA*5+3]<<" "<<fluorescentEntry [counterA*5+4]<<"   fluorescentEntry"<<endl;
                    //}
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*3+50; counter2++){
                        horizontalLineList [counter2] = 0;
                    }
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7*2+50; counter2++){
                        horizontalLineListValue [counter2] = 0;
                    }
                    
                    horizontalLineListCount = 0;
                    horizontalLineListValueCount = 0;
                    
                    for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = horizontalList2 [counter2*7+1], horizontalLineListCount++;
                        horizontalLineList [horizontalLineListCount] = 0, horizontalLineListCount++;
                        
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                        horizontalLineListValue [horizontalLineListValueCount] = -1, horizontalLineListValueCount++;
                    }
                    
                    //for (int counterA = 0; counterA < horizontalListCount2/7; counterA++){
                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<< horizontalList2 [counterA*7+counterB];
                    //    cout<<" horizontalList2 "<<counterA<<" "<<counter1<<endl;
                    //}
                    
                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< to_string(horizontalLineList [counterA*3+counterB]);
                    //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                    //}
                    
                    if (liveIfLastTimePoint == arrayTableDetail [selectCurrentLineage][3]){
                        if (colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        horizontalLineListValue [counter2*2] = fluorescentEntry [counter3*5+2];
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        else{
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                for (int counter3 = 0; counter3 < fluorescentEntryCount/5; counter3++){
                                    if (horizontalLineList [counter2*3] == fluorescentEntry [counter3*5] && horizontalLineList [counter2*3+1] == fluorescentEntry [counter3*5+1]){
                                        horizontalLineList [counter2*3+2] = 1;
                                        
                                        if (fluorescentEntry [counter3*5+2] == 0) horizontalLineListValue [counter2*2] = lowXlow;
                                        else if (fluorescentEntry [counter3*5+2] == 100) horizontalLineListValue [counter2*2] = highXhigh;
                                        else horizontalLineListValue [counter2*2] = -100;
                                        
                                        horizontalLineListValue [counter2*2+1] = fluorescentEntry [counter3*5+3];
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        
                        //----Set dummy value at CD, OF FU lines----
                        if (siblingLingHold == 1 && colorOptionLingHold == 0){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3]  && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else if (colorOptionLingHold == 1){
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 0){
                                    for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                        if (arrayLineageDataLingSummary [counter3*9+5] == horizontalLineList [counter2*3]  && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                            horizontalLineList [counter2*3+2] = 1;
                                            
                                            horizontalLineListValue [counter2*2] = -100;
                                            horizontalLineListValue [counter2*2+1] = 100;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                        //    cout<<" horizontalLineList "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                        //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                        //    cout<<" horizontalLineListValue "<<counterA<<" "<<endl;
                        //}
                        
                        //for (int counterA = 0; counterA < lineageExtractLingCount/9; counterA++){
                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageDataLingSummary [counterA*9+counterB];
                        //    cout<<" arrayLineageDataLingSummary "<<counterA<<endl;
                        //}
                        
                        expandCell = 0;
                        skipCount = 0;
                        
                        double *cellNoListTemp = new double [10];
                        int *endStatusHold = new int [20];
                        
                        do{
                            
                            terminationFlag = 1;
                            expandLineage = 0;
                            skipEntryCount = skipCount;
                            
                            for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount == 0){
                                    expandLineage = (int)(horizontalLineList [counter2*3+1]);
                                    expandCell = horizontalLineList [counter2*3];
                                    break;
                                }
                                else if (horizontalLineList [counter2*3+2] == 1 && skipEntryCount >= 0) skipEntryCount--;
                            }
                            
                            if (expandLineage != 0){
                                parentCellNo = -1;
                                
                                for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                    if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                        if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+5] == expandCell){
                                            parentCellNo = arrayLineageDataLingSummary [counter2*9+4];
                                            break;
                                        }
                                    }
                                }
                                
                                if (parentCellNo != -1){
                                    cellNoListTempCount = 0;
                                    endStatusHoldCount = 0;
                                    divisionStatus = 0;
                                    
                                    for (int counter2 = 0; counter2 < lineageDataLingSummaryCount/9; counter2++){
                                        if (arrayLineageDataLingSummary [counter2*9+3] == 31 || arrayLineageDataLingSummary [counter2*9+3] == 41 || arrayLineageDataLingSummary [counter2*9+3] == 51){
                                            if (arrayLineageDataLingSummary [counter2*9+6] == expandLineage && arrayLineageDataLingSummary [counter2*9+4] == parentCellNo){
                                                if (arrayLineageDataLingSummary [counter2*9+3] == 31) divisionStatus = 2;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 41) divisionStatus = 3;
                                                else if (arrayLineageDataLingSummary [counter2*9+3] == 51) divisionStatus = 4;
                                                
                                                cellNoListTemp [cellNoListTempCount] = arrayLineageDataLingSummary [counter2*9+5], cellNoListTempCount++;
                                                
                                                endStatusHold [endStatusHoldCount] = 0, endStatusHoldCount++;
                                                endStatusHold [endStatusHoldCount] = -1, endStatusHoldCount++;
                                                
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == arrayLineageDataLingSummary [counter2*9+5] && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        endStatusHold [endStatusHoldCount-2] = 1;
                                                        break;
                                                    }
                                                }
                                                
                                                checkStart = 0;
                                                checkNoCheck = 0;
                                                
                                                //----Check progeny's end status, enter 1 when end is CD, OF, FU----
                                                for (int counter3 = 0; counter3 < lineageDataLingSummaryCount/9; counter3++){
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+4] == arrayLineageDataLingSummary [counter2*9+5]  && arrayLineageDataLingSummary [counter3*9+3] != 91 && arrayLineageDataLingSummary [counter3*9+4] != 92){
                                                        checkStart = 1;
                                                        checkNoCheck = arrayLineageDataLingSummary [counter3*9+5];
                                                    }
                                                    
                                                    if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 7 || arrayLineageDataLingSummary [counter3*9+3] == 8 || arrayLineageDataLingSummary [counter3*9+3] == 91)){
                                                        if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 1;
                                                        
                                                        checkStart = 0;
                                                    }
                                                    else if (arrayLineageDataLingSummary [counter3*9+6] == expandLineage && arrayLineageDataLingSummary [counter3*9+5] == checkNoCheck && checkStart == 1 && (arrayLineageDataLingSummary [counter3*9+3] == 32 || arrayLineageDataLingSummary [counter3*9+3] == 42 || arrayLineageDataLingSummary [counter3*9+3] == 52 || arrayLineageDataLingSummary [counter3*9+2] == arrayTableDetail [tableCurrentRowHold][3])){
                                                        endStatusHold [endStatusHoldCount-1] = 0;
                                                        break;
                                                    }
                                                }
                                                
                                                if (endStatusHold [endStatusHoldCount-1] == -1) endStatusHold [endStatusHoldCount-1] = 0;
                                            }
                                        }
                                    }
                                    
                                    endStatusCheck = 0;
                                    endStatusCheck2 = 0;
                                    
                                    for (int counter2 = 0; counter2 < endStatusHoldCount; counter2++){
                                        if (endStatusHold [counter2] == 1) endStatusCheck = 1;
                                        if (endStatusHold [counter2*2+1] == 1) endStatusCheck2 = 1;
                                    }
                                    
                                    sumTotal = 0;
                                    sumAverage = -1;
                                    colorDataCount = 0;
                                    colorCountTemp = 0;
                                    
                                    if (colorOptionLingHold == 1) sumAverage = -1;
                                    
                                    if (colorOptionLingHold == 0){
                                        if (siblingLingHold == 0){
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        else if (siblingLingHold == 1){
                                            if (endStatusCheck == 0 && endStatusCheck2 == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                            sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                            sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                            
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            colorDataCount++;
                                                        }
                                                    }
                                                }
                                            }
                                            else{
                                                
                                                endStatusCheck = 0;
                                                dataEntryCheck = 0;
                                                
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                    
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && endStatusHold [counter2*2+1] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                            dataEntryCheck = 1;
                                                        }
                                                    }
                                                }
                                                
                                                if (endStatusCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumTotal = -2;
                                                                sumAverage = -2;
                                                                
                                                                horizontalLineListValue [counter3*2] = -1;
                                                                horizontalLineListValue [counter3*2+1] = -1;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                else if (dataEntryCheck == 0){
                                                    for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                sumAverage = sumAverage+(int)horizontalLineListValue [counter3*2];
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                    
                                                    for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                        if (endStatusHold [counter2*2] == 1 || endStatusHold [counter2*2+1] == 1){
                                                            for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                                if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                    horizontalLineListValue [counter3*2] = (int)(sumAverage/(double)colorCountTemp);
                                                                    horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                    horizontalLineList [counter3*3+2] = -1;
                                                                    
                                                                    colorDataCount++;
                                                                    
                                                                    break;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    else if (colorOptionLingHold == 1){
                                        if (endStatusCheck == 0){
                                            for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                        sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                        
                                                        //cout<<highXhigh<<" "<<lowXlow<<" "<<lowXhigh<<" "<<sumAverage<<" "<<horizontalLineListValue [counter3*2]<<" "<<to_string(cellNoListTemp [counter2])<<" cellNoListTemp"<<endl;
                                                        
                                                        if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                        else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                        else sumAverage = -100;
                                                        
                                                        horizontalLineList [counter3*3+2] = -1;
                                                        colorDataCount++;
                                                    }
                                                }
                                            }
                                        }
                                        else{
                                            
                                            endStatusCheck = 0;
                                            dataEntryCheck = 0;
                                            
                                            for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                if (endStatusHold [counter2*2] == 0) endStatusCheck = 1;
                                                
                                                for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                    if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && endStatusHold [counter2*2] == 0 && horizontalLineListValue [counter3*2] == -1 && horizontalLineListValue [counter3*2+1] == -1){
                                                        dataEntryCheck = 1;
                                                    }
                                                }
                                            }
                                            
                                            if (endStatusCheck == 0){
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                            sumTotal = 0;
                                                            sumAverage = -100;
                                                            
                                                            horizontalLineListValue [counter3*2] = -100;
                                                            horizontalLineListValue [counter3*2+1] = 0;
                                                            horizontalLineList [counter3*3+2] = -1;
                                                            
                                                            colorDataCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                            }
                                            else if (dataEntryCheck == 0){
                                                for (int counter2 = 0; counter2 < endStatusHoldCount/2; counter2++){
                                                    if (endStatusHold [counter2*2] == 1){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2]){
                                                                sumAverage = -100;
                                                                
                                                                horizontalLineListValue [counter3*2] = -100;
                                                                horizontalLineListValue [counter3*2+1] = sumTotal/(double)colorCountTemp;
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                
                                                                colorDataCount++;
                                                                
                                                                break;
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                for (int counter2 = 0; counter2 < cellNoListTempCount; counter2++){
                                                    if (endStatusHold [counter2*2] == 0){
                                                        for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                                            if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == cellNoListTemp [counter2] && horizontalLineListValue [counter3*2] != -1 && horizontalLineListValue [counter3*2+1] != -1){
                                                                sumTotal = sumTotal+horizontalLineListValue [counter3*2+1];
                                                                
                                                                if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -1 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == lowXlow && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == highXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == valueUK && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == lowXhigh && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXlow && unknownPriorityHold == 1) sumAverage = lowXlow;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 0) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == highXhigh && unknownPriorityHold == 1) sumAverage = highXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 0) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == lowXhigh && unknownPriorityHold == 1) sumAverage = lowXhigh;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == valueUK && horizontalLineListValue [counter3*2] == -100) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXlow) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == highXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == lowXhigh) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == valueUK) sumAverage = valueUK;
                                                                else if (sumAverage == -100 && horizontalLineListValue [counter3*2] == -100) sumAverage = -100;
                                                                else sumAverage = -100;
                                                                
                                                                horizontalLineList [counter3*3+2] = -1;
                                                                colorCountTemp++;
                                                                colorDataCount++;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    
                                    //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                                    //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                                    //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                                    //}
                                    
                                    if (colorDataCount == divisionStatus){
                                        skipCount = 0;
                                        
                                        if (colorOptionLingHold == 0){
                                            if (colorCountTemp == 0){
                                                sumTotal = sumTotal/(double)colorDataCount;
                                                sumAverage = (int)(sumAverage/(double)colorDataCount);
                                            }
                                            else{
                                                
                                                sumTotal = sumTotal/(double)colorCountTemp;
                                                sumAverage = (int)(sumAverage/(double)colorCountTemp);
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < horizontalLineListCount/3; counter2++){
                                            if ((int)(horizontalLineList [counter2*3+1]) == expandLineage && horizontalLineList [counter2*3] == parentCellNo){
                                                horizontalLineListValue [counter2*2] = sumAverage;
                                                horizontalLineListValue [counter2*2+1] = sumTotal;
                                                horizontalLineList [counter2*3+2] = 1;
                                                break;
                                            }
                                        }
                                    }
                                    else skipCount++;
                                }
                                else{
                                    
                                    for (int counter3 = 0; counter3 < horizontalLineListCount/3; counter3++){
                                        if ((int)(horizontalLineList [counter3*3+1]) == expandLineage && horizontalLineList [counter3*3] == expandCell){
                                            horizontalLineList [counter3*3+2] = -1;
                                        }
                                    }
                                }
                            }
                            else terminationFlag = 0;
                            
                        } while (terminationFlag == 1);
                        
                        delete [] cellNoListTemp;
                        delete [] endStatusHold;
                    }
                    
                    delete [] fluorescentEntry;
                }
                
                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< horizontalLineList [counterA*3+counterB];
                //    cout<<" horizontalLineList "<<counterA<<" "<<counter1<<endl;
                //}
                
                //for (int counterA = 0; counterA < horizontalLineListCount/3; counterA++){
                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< horizontalLineListValue [counterA*2+counterB];
                //    cout<<" horizontalLineListValue "<<counterA<<" "<<counter1<<endl;
                //}
                
                //----Color data range get----
                rangeLiveAverageLow = 0;
                rangeLiveAverageHigh = 0;
                rangeLiveTotalLow = 0;
                rangeLiveTotalHigh = 0;
                
                if (liveDisplayHold == 1 || liveDisplayHold == 2){
                    liveName = "";
                    
                    if (chNo1 == 1) liveName = arrayTableMain [selectCurrentLineage][6];
                    else if (chNo1 == 2) liveName = arrayTableMain [selectCurrentLineage][7];
                    else if (chNo1 == 3) liveName = arrayTableMain [selectCurrentLineage][8];
                    else if (chNo1 == 4) liveName = arrayTableMain [selectCurrentLineage][6];
                    else if (chNo1 == 5) liveName = arrayTableMain [selectCurrentLineage][7];
                    else if (chNo1 == 6) liveName = arrayTableMain [selectCurrentLineage][8];
                    
                    for (int counter2 = 0; counter2 < lineageFluorescentDataTypeEntryCount; counter2++){
                        if (atoi(arrayLineageFluorescentDataType [counter2][0].c_str()) == selectCurrentLineage+1 && arrayLineageFluorescentDataType [counter2][1] == "Live" && arrayLineageFluorescentDataType [counter2][2] == liveName){
                            rangeLiveTotalLow = atoi(arrayLineageFluorescentDataType [counter2][6].c_str());
                            rangeLiveTotalHigh = atoi(arrayLineageFluorescentDataType [counter2][7].c_str());
                            rangeLiveAverageLow = atoi(arrayLineageFluorescentDataType [counter2][4].c_str());
                            rangeLiveAverageHigh = atoi(arrayLineageFluorescentDataType [counter2][5].c_str());
                            break;
                        }
                    }
                }
                
                NSBezierPath *pathCircle;
                [NSBezierPath setDefaultLineWidth:lingLineWidthHold*magFactor];
                
                rangeNoHold = 0;
                timeHold = 0;
                
                int *rangeList = new int [horizontalTime*3+10];
                
                for (int counter2 = 0; counter2 < horizontalListCount2/7; counter2++){
                    [[NSColor blackColor] set];
                    
                    cellNoOriginal = 0;
                    
                    for (int counter4 = 0; counter4 < cellNoListCount/4; counter4++){
                        if (horizontalList2 [counter2*7] == cellNoList [counter4*4+2]){
                            cellNoOriginal = (int)(cellNoList [counter4*4]);
                            break;
                            
                        }
                    }
                    
                    if (horizontalList2 [counter2*7+5] == 32 || horizontalList2 [counter2*7+3] == 42 || horizontalList2 [counter2*7+3] == 52) endType = 1;
                    else endType = 0;
                    
                    //cout<<counter2<<" "<<horizontalList2 [counter2*7]<<" "<<horizontalList2 [counter2*7+1]<<" TimeStartEnd"<<endl;
                    
                    //----Color data drawing----
                    if (liveDisplayHold == 0 || liveDisplayHold == 3){
                        positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                        positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                        
                        if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                        else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                        
                        positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    }
                    else if (liveDisplayHold == 1){
                        liveColorStart = -1;
                        liveColorEnd = -1;
                        
                        for (int counter3 = 0; counter3 < liveTimeListCount; counter3++){
                            if (liveColorStart == -1 && liveTimeList [counter3] >= horizontalList2 [counter2*7+3]) liveColorStart = counter3;
                            if (liveTimeList [counter3] <= horizontalList2 [counter2*7+4]) liveColorEnd = counter3;
                        }
                        
                        if (liveColorStart != -1 && liveColorStart == liveColorEnd){
                            liveValueGet = 0;
                            
                            for (int counter3 = 0; counter3 < lineageExtractIFCount/22; counter3++){
                                if (cellNoOriginal == arrayIFDataLing [counter3*22] && horizontalList2 [counter2*7+1] == arrayIFDataLing [counter3*22+1] && liveTimeList [liveColorStart] == arrayIFDataLing [counter3*22+2]){
                                    if (chNo1 == 1){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+5];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+5]*arrayIFDataLing [counter3*22+6];
                                    }
                                    else if (chNo1 == 2){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+8];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+8]*arrayIFDataLing [counter3*22+9];
                                    }
                                    else if (chNo1 == 3){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+11];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+11]*arrayIFDataLing [counter3*22+12];
                                    }
                                    else if (chNo1 == 4){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+14];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+14]*arrayIFDataLing [counter3*22+15];
                                    }
                                    else if (chNo1 == 5){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+17];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+17]*arrayIFDataLing [counter3*22+18];
                                    }
                                    else if (chNo1 == 6){
                                        if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter3*22+20];
                                        else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter3*22+20]*arrayIFDataLing [counter3*22+21];
                                    }
                                    
                                    break;
                                }
                            }
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                                else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                                
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                                else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                                
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        } //----One live data/cell----
                        else if (liveColorStart != -1 && liveColorStart < liveColorEnd){ //----More than one live data/cell----
                            rangeListCount = 0;
                            
                            for (int counter3 = liveColorStart; counter3 <= liveColorEnd; counter3++){
                                liveValueGet = 0;
                                
                                for (int counter4 = 0; counter4 < lineageExtractIFCount/22; counter4++){
                                    if (cellNoOriginal == arrayIFDataLing [counter4*22] && horizontalList2 [counter2*7+1] == arrayIFDataLing [counter4*22+1] && liveTimeList [counter3] == arrayIFDataLing [counter4*22+2]){
                                        
                                        if (chNo1 == 1){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+5];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+5]*arrayIFDataLing [counter4*22+6];
                                        }
                                        else if (chNo1 == 2){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+8];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+8]*arrayIFDataLing [counter4*22+9];
                                        }
                                        else if (chNo1 == 3){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+11];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+11]*arrayIFDataLing [counter4*22+12];
                                        }
                                        else if (chNo1 == 4){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+14];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+14]*arrayIFDataLing [counter4*22+15];
                                        }
                                        else if (chNo1 == 5){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+17];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+17]*arrayIFDataLing [counter4*22+18];
                                        }
                                        else if (chNo1 == 6){
                                            if (averageTotalSetHold == 0) liveValueGet = arrayIFDataLing [counter4*22+20];
                                            else if (averageTotalSetHold == 1) liveValueGet = arrayIFDataLing [counter4*22+20]*arrayIFDataLing [counter4*22+21];
                                        }
                                        
                                        break;
                                    }
                                }
                                
                                if (averageTotalSetHold == 0){
                                    rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                    
                                    if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                    else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                    else rangeNo = 23;
                                    
                                    if (liveValueGet == -1) rangeNo = 105/3+1;
                                }
                                else{
                                    
                                    rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                    
                                    if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                    else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                    else rangeNo = 23;
                                    
                                    if (liveValueGet == -1) rangeNo = 105/3+1;
                                }
                                
                                if (counter3 == liveColorStart){
                                    rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+3]), rangeListCount++;
                                    rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                    
                                    rangeNoHold = rangeNo;
                                    timeHold = liveTimeList [counter3];
                                }
                                else if (counter3 == liveColorEnd){
                                    difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter3]-timeHold);
                                    
                                    if (liveTimeList [counter3]-timeHold < 5){
                                        rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+3]), rangeListCount++;
                                        rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                        rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                    }
                                    else{
                                        
                                        difference2 = difference;
                                        timeHold2 = timeHold;
                                        
                                        for (int counter4 = timeHold+1; counter4 <= liveTimeList [counter3]; counter4++){
                                            if (counter4 == liveTimeList [counter3]){
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                            }
                                            else if (difference2 >= 1){
                                                differenceInt = (int)difference2;
                                                
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                                
                                                difference2 = difference;
                                                rangeNoHold = rangeNoHold+differenceInt;
                                                timeHold2 = counter4;
                                            }
                                            else difference2 = difference2+difference;
                                        }
                                    }
                                    
                                    rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                    
                                    if (endType == 1) rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+4])+1, rangeListCount++;
                                    else rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+4]), rangeListCount++;
                                    
                                    rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                }
                                else{
                                    
                                    difference = (rangeNo-rangeNoHold)/(double)(liveTimeList [counter3]-timeHold);
                                    
                                    if (liveTimeList [counter3]-timeHold < 5){
                                        rangeList [rangeListCount] = (int)(horizontalList2 [counter2*7+3]), rangeListCount++;
                                        rangeList [rangeListCount] = liveTimeList [counter3], rangeListCount++;
                                        rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                    }
                                    else{
                                        
                                        difference2 = difference;
                                        timeHold2 = timeHold;
                                        
                                        for (int counter4 = timeHold+1; counter4 <= liveTimeList [counter3]; counter4++){
                                            if (counter4 == liveTimeList [counter3]){
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNo, rangeListCount++;
                                            }
                                            else if (difference2 >= 1){
                                                differenceInt = (int)difference2;
                                                
                                                rangeList [rangeListCount] = timeHold2, rangeListCount++;
                                                rangeList [rangeListCount] = counter4, rangeListCount++;
                                                rangeList [rangeListCount] = rangeNoHold+differenceInt, rangeListCount++;
                                                
                                                difference2 = difference;
                                                rangeNoHold = rangeNoHold+differenceInt;
                                                timeHold2 = counter4;
                                                
                                            }
                                            else difference2 = difference2+difference;
                                        }
                                    }
                                    
                                    rangeNoHold = rangeNo;
                                    timeHold = liveTimeList [counter3];
                                }
                            }
                            
                            for (int counter3 = 0; counter3 < rangeListCount/3; counter3++){
                                [[NSColor colorWithCalibratedRed:arrayColorRange [rangeList [counter3*3+2]*3] green:arrayColorRange [rangeList [counter3*3+2]*3+1] blue:arrayColorRange [rangeList [counter3*3+2]*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+rangeList [counter3*3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                positionBB.x = xStart*magFactor+rangeList [counter3*3+1]*horizontalIncrement*magFactor;
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        else{
                            
                            positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else if (liveDisplayHold == 2){
                        if (colorOptionLingHold == 0){
                            if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter2*2];
                            else liveValueGet = (int)horizontalLineListValue [counter2*2+1];
                            
                            if (averageTotalFlag == 0){
                                rangeDivision = (rangeLiveAverageHigh-rangeLiveAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveAverageLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveAverageLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                                else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                                
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else{
                                
                                rangeDivision = (rangeLiveTotalHigh-rangeLiveTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeLiveTotalLow+rangeDivision) rangeNo = 1;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*2) rangeNo = 2;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*3) rangeNo = 3;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*4) rangeNo = 4;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*5) rangeNo = 5;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*6) rangeNo = 6;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*7) rangeNo = 7;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*8) rangeNo = 8;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*9) rangeNo = 9;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*10) rangeNo = 10;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*11) rangeNo = 11;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*12) rangeNo = 12;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*13) rangeNo = 13;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*14) rangeNo = 14;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*15) rangeNo = 15;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*16) rangeNo = 16;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*17) rangeNo = 17;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*18) rangeNo = 18;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*19) rangeNo = 19;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*20) rangeNo = 20;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*21) rangeNo = 21;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*22) rangeNo = 22;
                                else if (liveValueGet < rangeLiveTotalLow+rangeDivision*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                                else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                                
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        else{
                            
                            if (horizontalLineListValue [counter2*2] == -1 || horizontalLineListValue [counter2*2] == -100) rangeNo = 105;
                            else rangeNo = (int)(horizontalLineListValue [counter2*2]);
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                            
                            positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    else if (liveDisplayHold == 4){
                        if (colorOptionLingHold == 0){
                            if (averageTotalFlag == 0) liveValueGet = (int)horizontalLineListValue [counter2*2];
                            else liveValueGet = (int)horizontalLineListValue [counter2*2+1];
                            
                            if (averageTotalFlag == 0){
                                rangeDivisionAverage = (rangeAverageHigh-rangeAverageLow)/(double)25;
                                
                                if (liveValueGet <= rangeAverageLow+rangeDivisionAverage) rangeNo = 1;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*2) rangeNo = 2;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*3) rangeNo = 3;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*4) rangeNo = 4;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*5) rangeNo = 5;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*6) rangeNo = 6;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*7) rangeNo = 7;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*8) rangeNo = 8;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*9) rangeNo = 9;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*10) rangeNo = 10;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*11) rangeNo = 11;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*12) rangeNo = 12;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*13) rangeNo = 13;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*14) rangeNo = 14;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*15) rangeNo = 15;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*16) rangeNo = 16;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*17) rangeNo = 17;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*18) rangeNo = 18;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*19) rangeNo = 19;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*20) rangeNo = 20;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*21) rangeNo = 21;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*22) rangeNo = 22;
                                else if (liveValueGet < rangeAverageLow+rangeDivisionAverage*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                                else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                                
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                            else{
                                
                                rangeDivisionTotal = (rangeTotalHigh-rangeTotalLow)/(double)25;
                                
                                if (liveValueGet <= rangeTotalLow+rangeDivisionTotal) rangeNo = 1;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*2) rangeNo = 2;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*3) rangeNo = 3;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*4) rangeNo = 4;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*5) rangeNo = 5;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*6) rangeNo = 6;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*7) rangeNo = 7;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*8) rangeNo = 8;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*9) rangeNo = 9;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*10) rangeNo = 10;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*11) rangeNo = 11;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*12) rangeNo = 12;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*13) rangeNo = 13;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*14) rangeNo = 14;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*15) rangeNo = 15;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*16) rangeNo = 16;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*17) rangeNo = 17;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*18) rangeNo = 18;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*19) rangeNo = 19;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*20) rangeNo = 20;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*21) rangeNo = 21;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*22) rangeNo = 22;
                                else if (liveValueGet < rangeTotalLow+rangeDivisionTotal*23) rangeNo = 23;
                                else rangeNo = 24;
                                
                                if (liveValueGet == -1) rangeNo = 105/3+1;
                                
                                [[NSColor colorWithCalibratedRed:arrayColorRange [(rangeNo-1)*3] green:arrayColorRange [(rangeNo-1)*3+1] blue:arrayColorRange [(rangeNo-1)*3+2] alpha:1] set];
                                
                                positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                                positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                
                                if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                                else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                                
                                positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                                [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                            }
                        }
                        else{
                            
                            if (horizontalLineListValue [counter2*2] == -1 || horizontalLineListValue [counter2*2] == -100) rangeNo = 105;
                            else rangeNo = (int)(horizontalLineListValue [counter2*2]);
                            
                            [[NSColor colorWithCalibratedRed:arrayColorRange [rangeNo] green:arrayColorRange [rangeNo+1] blue:arrayColorRange [rangeNo+2] alpha:1] set];
                            
                            positionAA.x = xStart*magFactor+horizontalList2 [counter2*7+3]*horizontalIncrement*magFactor;
                            positionAA.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                            
                            if (endType == 1) positionBB.x = xStart*magFactor+(horizontalList2 [counter2*7+4]+1)*horizontalIncrement*magFactor;
                            else positionBB.x = xStart*magFactor+horizontalList2 [counter2*7+4]*horizontalIncrement*magFactor;
                            
                            positionBB.y = yStart*magFactor+increment*magFactor+counter2*increment*magFactor;
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < eventListCount2/5; counter3++){
                        if (eventList2 [counter3*5+4] == counter2){
                            if (eventList2 [counter3*5+3] == 91 || eventList2 [counter3*5+3] == 92){
                                [[NSColor orangeColor] set];
                                pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(xStart*magFactor+eventList2 [counter3*5+2]*horizontalIncrement*magFactor-3*magFactor, yStart*magFactor+increment*magFactor+counter2*increment*magFactor-3*magFactor, 6*magFactor, 6*magFactor)];
                                
                                [pathCircle fill];
                            }
                            else if (eventList2 [counter3*5+3] == 6){
                                [[NSColor cyanColor] set];
                                pathCircle = [NSBezierPath bezierPathWithOvalInRect:NSMakeRect(xStart*magFactor+eventList2 [counter3*5+2]*horizontalIncrement*magFactor-3*magFactor, yStart*magFactor+increment*magFactor+counter2*increment*magFactor-3*magFactor, 6*magFactor, 6*magFactor)];
                                [pathCircle fill];
                            }
                            else if (eventList2 [counter3*5+3] == 7){
                                [[NSColor magentaColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor+eventList2 [counter3*5+2]*horizontalIncrement*magFactor-3*magFactor, yStart*magFactor+increment*magFactor+counter2*increment*magFactor-3*magFactor, 6*magFactor, 6*magFactor)];
                                [path fill];
                            }
                            else if (eventList2 [counter3*5+3] == 8){
                                [[NSColor grayColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor+eventList2 [counter3*5+2]*horizontalIncrement*magFactor-3*magFactor, yStart*magFactor+increment*magFactor+counter2*increment*magFactor-3*magFactor, 6*magFactor, 6*magFactor)];
                                [path fill];
                            }
                            else if (eventList2 [counter3*5+3] == 10){
                                [[NSColor redColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor+eventList2 [counter3*5+2]*horizontalIncrement*magFactor-3*magFactor, yStart*magFactor+increment*magFactor+counter2*increment*magFactor-3*magFactor, 6*magFactor, 6*magFactor)];
                                [path stroke];
                            }
                            else if (eventList2 [counter3*5+3] == 11){
                                [[NSColor blueColor] set];
                                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor+eventList2 [counter3*5+2]*horizontalIncrement*magFactor-3*magFactor, yStart*magFactor+increment*magFactor+counter2*increment*magFactor-3*magFactor, 6*magFactor, 6*magFactor)];
                                [path fill];
                            }
                        }
                    }
                }
                
                delete [] lineageSelect;
                delete [] arrayLineageDataLing;
                delete [] horizontalList;
                delete [] horizontalList2;
                delete [] eventList;
                delete [] eventList2;
                delete [] verticalList;
                delete [] liveTimeList;
                delete [] rangeList;
                delete [] arrayIFDataLing;
                delete [] horizontalLineList;
                delete [] horizontalLineListValue;
                delete [] cellNoList;
                delete [] arrayLineageDataLingSummary;
            }
        }
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        if (exportTiming != 12) exportFlag3 = 2;
        else if (exportTiming == 12) exportTiming = 13;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToLineageDisplay object:nil];
}

@end
