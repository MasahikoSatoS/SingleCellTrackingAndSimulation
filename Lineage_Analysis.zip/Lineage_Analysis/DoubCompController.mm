//
//  DoubCompController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-01-30.
//
//

#import "DoubCompController.h"

NSString *notificationToDoubCompController = @"notificationExecuteDoubController";

@implementation DoubCompController

-(id)init{
    self = [super init];
    
    if (self != nil){
        geneDAStatusHold = 0;
        geneG1StatusHold = 0;
        geneG2StatusHold = 0;
        geneG3StatusHold = 0;
        timeDiffStatusHold = 0;
        lingGenerationStatusHold = 0;
        startValueHold = 0;
        rangeValuesHold = 100;
        groupValueHold = 5;
        noOfGenerationValueHold = 2;
        grandDDNoCutOff = 2;
        progenyDoubleHold = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDoubCompController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    mainWindowDoubController = [[NSWindowController alloc] initWithWindowNibName:@"DoubComp"];
    [mainWindowDoubController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable2 object:nil];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [mainWindowDoubWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [mainWindowDoubWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [rangeValueDisplay setDelegate:self];
    [groupValueDisplay setDelegate:self];
    [startValueDisplay setDelegate:self];
    [noOfGenerationValueDisplay setDelegate:self];
    
    [rangeValueDisplay setStringValue:@"100"];
    [groupValueDisplay setStringValue:@"5"];
    [startValueDisplay setStringValue:@"0"];
    [noOfGenerationValueDisplay setStringValue:@"2"];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == rangeValueDisplay){
            if ([rangeValueDisplay intValue] >= 10 && [rangeValueDisplay intValue] <= 10000){
                rangeValuesHold = [rangeValueDisplay intValue];
                
                progenyDoubleCompHoldCount = 0;
                
                int rangeStart = startValueHold;
                int rangeEnd = rangeValuesHold-1;
                int rangeIncrement = 0;
                
                for (int counter1 = 1; counter1 <= groupValueHold; counter1++){
                    arrayDoubleCompRangeHold [(counter1-1)*3] = counter1, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [(counter1-1)*3+2] = rangeStart+rangeEnd+rangeIncrement, progenyDoubleCompHoldCount++;
                    
                    rangeIncrement = rangeIncrement+rangeValuesHold;
                }
                
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = groupValueHold+1, progenyDoubleCompHoldCount++;
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = rangeStart+rangeEnd+rangeIncrement-rangeValuesHold+1, progenyDoubleCompHoldCount++;
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = 100000000, progenyDoubleCompHoldCount++;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable2 object:nil];
            }
        }
        
        if ([aNotification object] == groupValueDisplay){
            if ([groupValueDisplay intValue] >= 3 && [groupValueDisplay intValue] <= 100){
                groupValueHold = [groupValueDisplay intValue];
                
                progenyDoubleCompHoldCount = 0;
                
                int rangeStart = startValueHold;
                int rangeEnd = rangeValuesHold-1;
                int rangeIncrement = 0;
                
                for (int counter1 = 1; counter1 <= groupValueHold; counter1++){
                    arrayDoubleCompRangeHold [(counter1-1)*3] = counter1, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [(counter1-1)*3+2] = rangeStart+rangeEnd+rangeIncrement, progenyDoubleCompHoldCount++;
                    
                    rangeIncrement = rangeIncrement+rangeValuesHold;
                }
                
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = groupValueHold+1, progenyDoubleCompHoldCount++;
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = rangeStart+rangeEnd+rangeIncrement-rangeValuesHold+1, progenyDoubleCompHoldCount++;
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = 100000000, progenyDoubleCompHoldCount++;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable2 object:nil];
            }
        }
        
        if ([aNotification object] == startValueDisplay){
            if ([startValueDisplay intValue] >= -10000 && [startValueDisplay intValue] <= 10000){
                startValueHold = [startValueDisplay intValue];
                
                progenyDoubleCompHoldCount = 0;
                
                int rangeStart = startValueHold;
                int rangeEnd = rangeValuesHold-1;
                int rangeIncrement = 0;
                
                for (int counter1 = 1; counter1 <= groupValueHold; counter1++){
                    arrayDoubleCompRangeHold [(counter1-1)*3] = counter1, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [(counter1-1)*3+1] = rangeStart+rangeIncrement, progenyDoubleCompHoldCount++;
                    arrayDoubleCompRangeHold [(counter1-1)*3+2] = rangeStart+rangeEnd+rangeIncrement, progenyDoubleCompHoldCount++;
                    
                    rangeIncrement = rangeIncrement+rangeValuesHold;
                }
                
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = groupValueHold+1, progenyDoubleCompHoldCount++;
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = rangeStart+rangeEnd+rangeIncrement-rangeValuesHold+1, progenyDoubleCompHoldCount++;
                arrayDoubleCompRangeHold [progenyDoubleCompHoldCount] = 100000000, progenyDoubleCompHoldCount++;
                
                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable2 object:nil];
            }
        }
        
        if ([aNotification object] == noOfGenerationValueDisplay){
            if ([noOfGenerationValueDisplay intValue] >= 1 && [noOfGenerationValueDisplay intValue] <= 10){
                noOfGenerationValueHold = [noOfGenerationValueDisplay intValue];
            }
        }
    }
}

-(IBAction)createExcelFile:(id)sender{
    if (lineageDataEntryCount != 0){
        if (progenyDoubleCompHoldCount != 0){
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Doubling_Comparison";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Doubling_Comparison") != -1){
                        extractString = entry.substr(entry.find("DC")+2, entry.find(".txt")-entry.find("DC")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string path = resultSavePath2+"/Doubling_Comparison-DC"+to_string(maxEntryNo)+".txt";
            
            string progenyAnalysisString = "";
            
            ofstream oin;
            oin.open(path.c_str(), ios::out | ios::binary);
            
            int *arrayAscIIintData = new int [100], ascIIintDataCount = 0;
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            for (int counter1 = 0; counter1 < progenyDoubleCompResultsHoldCount/5; counter1++){
                ascIIstring = arrayProgenyDoubleCompResultsHold [counter1*5];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayProgenyDoubleCompResultsHold [counter1*5+1];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayProgenyDoubleCompResultsHold [counter1*5+2];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayProgenyDoubleCompResultsHold [counter1*5+3];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                ascIIstring = arrayProgenyDoubleCompResultsHold [counter1*5+4];
                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                
                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                
                oin.put(9);
                
                oin.put(13);
                oin.put(10);
            }
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            oin.close();
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Analysis Performed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)createExcelFile2:(id)sender{
    if (lineageDataEntryCount != 0){
        if (progenyDoubleCompHoldCount != 0){
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Doubling_Comparison";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Doubling_Comparison") != -1){
                        extractString = entry.substr(entry.find("DL")+2, entry.find(".txt")-entry.find("DL")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            string path = resultSavePath2+"/Doubling_Comparison-DL"+to_string(maxEntryNo)+".txt";
            
            ofstream oin;
            oin.open(path.c_str(), ios::out | ios::binary);
            
            int *arrayAscIIintData = new int [100];
            int ascIIintDataCount = 0;
            
            ascIIconversion = [[ASCIIconversion alloc] init];
            
            int lineageEntryNo = 0;
            unsigned long lineageEntrySize = 0;
            int totalNoOfCell = 0;
            int categoryLineageListCount = 0;
            int terminationFlag = 0;
            int pointCount = 0;
            int remainingFind = 0;
            int startingGeneration = 0;
            int cellNumberDeleteHoldCount = 0;
            int nextCellNo = 0;
            int generationNo = 0;
            int doublingTimeGet = 0;
            int lineageNoGet = 0;
            int percentEventIntCount = 0;
            int numberOfDifPoint = 0;
            int cellNoDuplicateFind = 0;
            int lingNoFind = 0;
            int categoryLineageListNormalizeCount2 = 0;
            int categoryLineageListCount3 = 0;
            int shortestDoublingValue = 0;
            int categoryLineageListCount2 = 0;
            int extraCount = 0;
            int categorySortListCount = 0;
            int categorySortListCount2 = 0;
            int maxGeneration = 0;
            int newGeneration = 0;
            
            double percentEventCount = 0;
            double differenceTotal = 0;
            
            string percentString;
            string displayData1;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                    //    cout<<"  arrayTableMain "<<counterA<<endl;
                    //}
                    
                    lineageEntrySize = arrayLineageDataEntryHold [counter2];
                    
                    lineageEntryNo = 0;
                    totalNoOfCell = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                            lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                        }
                        
                        if (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51){
                            totalNoOfCell++;
                        }
                    }
                    
                    int *categoryLineageList = new int [totalNoOfCell*5+10];
                    categoryLineageListCount = 0;
                    
                    for (int counter3 = 0; counter3 < totalNoOfCell*4+10; counter3++) categoryLineageList [counter3] = -1;
                    
                    pointCount = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+5] != 0 && (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51)){
                            pointCount = arrayLineageData [counter2][counter3*9+2];
                            
                            categoryLineageList [categoryLineageListCount] = arrayLineageData [counter2][counter3*9+6], categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = arrayLineageData [counter2][counter3*9+5], categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = arrayLineageData [counter2][counter3*9+4], categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = 0, categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = 0, categoryLineageListCount++;
                        }
                        else if (arrayLineageData [counter2][counter3*9+5] != 0 && (arrayLineageData [counter2][counter3*9+3] == 32 || arrayLineageData [counter2][counter3*9+3] == 42 || arrayLineageData [counter2][counter3*9+3] == 52)){
                            categoryLineageList [categoryLineageListCount-2] = arrayLineageData [counter2][counter3*9+2]-pointCount+1;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                        if (categoryLineageList [counter3*5+3] == 0){
                            categoryLineageList [counter3*5] = -1;
                            categoryLineageList [counter3*5+1] = -1;
                            categoryLineageList [counter3*5+2] = -1;
                            categoryLineageList [counter3*5+3] = -1;
                            categoryLineageList [counter3*5+4] = -1;
                        }
                        
                        if (categoryLineageList [counter3*5+3] != 0 && categoryLineageList [counter3*5+2] == 0){
                            categoryLineageList [counter3*5+4] = 1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < categoryLineageListCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< categoryLineageList [counterA*5+counterB];
                    //    cout<<"  categoryLineageList "<<counterA<<endl;
                    //}
                    
                    do{
                        
                        terminationFlag = 0;
                        remainingFind = 0;
                        
                        for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                            if (categoryLineageList [counter3*5+4] == 0){
                                remainingFind = 1;
                                break;
                            }
                        }
                        
                        if (remainingFind == 1){
                            for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                if (categoryLineageList [counter3*5+4] == 0){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList [counter3*5] == categoryLineageList [counter4*5] && categoryLineageList [counter3*5+2] == categoryLineageList [counter4*5+1]){
                                            categoryLineageList [counter3*5+4] = categoryLineageList [counter4*5+4]+1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else terminationFlag = 1;
                        
                    } while (terminationFlag == 0);
                    
                    //for (int counterA = 0; counterA < categoryLineageListCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< categoryLineageList [counterA*5+counterB];
                    //    cout<<"  categoryLineageList "<<counterA<<endl;
                    //}
                    
                    startingGeneration = 0;
                    
                    if (geneDAStatusHold == 1) startingGeneration = 1;
                    if (geneG1StatusHold == 1) startingGeneration = 2;
                    if (geneG2StatusHold == 1) startingGeneration = 3;
                    if (geneG3StatusHold == 1) startingGeneration = 4;
                    
                    if (progenyDoubleHold == 0){
                        if (lingGenerationStatusHold == 1){
                            int *categoryLineageList2 = new int [lineageEntryNo*15+10];
                            int *categoryLineageList3 = new int [lineageEntryNo*15+10];
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                categoryLineageList2 [counter3] = -1;
                                categoryLineageList3 [counter3] = 0;
                            }
                            
                            for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                if (categoryLineageList [counter3*5+4] == startingGeneration){
                                    int *cellNumberDeleteHold = new int [totalNoOfCell*4+50];
                                    cellNumberDeleteHoldCount = 0;
                                    
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList [counter4*5] == categoryLineageList [counter3*5] && categoryLineageList [counter4*5+2] == categoryLineageList [counter3*5+1]){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                        }
                                    }
                                    
                                    do {
                                        
                                        terminationFlag = 0;
                                        
                                        if (cellNumberDeleteHoldCount != 0){
                                            lineageNoGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-4];
                                            nextCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-3];
                                            doublingTimeGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-2];
                                            generationNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-2] = 0;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-3] = 0;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-4] = 0;
                                            cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-4;
                                            
                                            for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                                if (lineageNoGet == categoryLineageList [counter4*5] && categoryLineageList [counter4*5+2] == nextCellNo){
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                                }
                                            }
                                            
                                            if (categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] == -1) categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = 0;
                                            
                                            categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo]+doublingTimeGet-categoryLineageList [counter3*5+3];
                                            
                                            categoryLineageList3 [(categoryLineageList [counter3*5]-1)*15+generationNo]++;
                                        }
                                        else terminationFlag = 1;
                                        
                                    } while (terminationFlag == 0);
                                    
                                    delete [] cellNumberDeleteHold;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList2 [counterA*15+counterB];
                            //    cout<<"  categoryLineageList2 "<<counterA<<endl;
                            //}
                            
                            double *categoryLineageAverage = new double [lineageEntryNo*15+10];
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++) categoryLineageAverage [counter3] = 0.00001;
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                for (int counter4 = 0; counter4 <= 15; counter4++){
                                    if (categoryLineageList3 [counter3*15+counter4] != 0){
                                        categoryLineageAverage [counter3*15+counter4] = categoryLineageList2 [counter3*15+counter4]/(double)categoryLineageList3 [counter3*15+counter4];
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageAverage [counterA*15+counterB];
                            //    cout<<"  categoryLineageAverage "<<counterA<<endl;
                            //}
                            
                            ascIIstring = arrayTableMain [counter2][2];
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                            
                            oin.put(9);
                            
                            ascIIstring = arrayTableMain [counter2][3];
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                            
                            oin.put(9);
                            
                            ascIIstring = arrayTableMain [counter2][4];
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                            
                            oin.put(9);
                            
                            for (int counter3 = 0; counter3 < 11; counter3++){
                                ascIIstring = " ";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            ascIIstring = "Lineage No";
                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                            
                            for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                            
                            oin.put(9);
                            
                            for (int counter3 = 0; counter3 < 13; counter3++){
                                ascIIstring = "G"+to_string(counter3+1);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                extraCount = 0;
                                
                                for (int counter4 = 0; counter4 <= 15; counter4++){
                                    if (categoryLineageAverage [counter3*15+counter4] != 0.00001){
                                        extraCount++;
                                        break;
                                    }
                                }
                                
                                if (extraCount != 0){
                                    ascIIstring = to_string(counter3+1);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    for (int counter4 = 2; counter4 <= 15; counter4++){
                                        if (categoryLineageAverage [counter3*15+counter4] != 0.00001){
                                            ascIIstring = to_string(categoryLineageAverage [counter3*15+counter4]);
                                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                            
                                            for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                            
                                            oin.put(9);
                                        }
                                        else{
                                            
                                            ascIIstring = " ";
                                            ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                            
                                            for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                            
                                            oin.put(9);
                                        }
                                    }
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                            }
                            
                            oin.put(13);
                            oin.put(10);
                            
                            delete [] categoryLineageList2;
                            delete [] categoryLineageList3;
                            delete [] categoryLineageAverage;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                        }
                        else if (lingGenerationStatusHold == 0){
                            if (timeDiffStatusHold == 0){
                                int *categoryLineageList2 = new int [lineageEntryNo*15+10];
                                int *categoryLineageList3 = new int [lineageEntryNo*15+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                    categoryLineageList2 [counter3] = -1;
                                    categoryLineageList3 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == startingGeneration){
                                        int *cellNumberDeleteHold = new int [totalNoOfCell*4+50];
                                        cellNumberDeleteHoldCount = 0;
                                        
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5], cellNumberDeleteHoldCount++;
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5+1], cellNumberDeleteHoldCount++;
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5+3], cellNumberDeleteHoldCount++;
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5+4], cellNumberDeleteHoldCount++;
                                        
                                        do {
                                            
                                            terminationFlag = 0;
                                            
                                            if (cellNumberDeleteHoldCount != 0){
                                                lineageNoGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-4];
                                                nextCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-3];
                                                doublingTimeGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-2];
                                                generationNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-2] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-3] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-4] = 0;
                                                cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-4;
                                                
                                                for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                                    if (lineageNoGet == categoryLineageList [counter4*5] && categoryLineageList [counter4*5+2] == nextCellNo){
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                                    }
                                                }
                                                
                                                if (categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] == -1) categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = 0;
                                                
                                                categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo]+doublingTimeGet;
                                                
                                                categoryLineageList3 [(categoryLineageList [counter3*5]-1)*15+generationNo]++;
                                            }
                                            else terminationFlag = 1;
                                            
                                        } while (terminationFlag == 0);
                                        
                                        delete [] cellNumberDeleteHold;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList3 [counterA*15+counterB];
                                //    cout<<"  categoryLineageList3 "<<counterA<<endl;
                                //}
                                
                                double *categoryLineageAverage = new double [lineageEntryNo*15+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                    categoryLineageAverage [counter3] = 0.00001;
                                }
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                    for (int counter4 = 0; counter4 < 15; counter4++){
                                        if (categoryLineageList3 [counter3*15+counter4] != 0){
                                            categoryLineageAverage [counter3*15+counter4] = categoryLineageList2 [counter3*15+counter4]/(double)categoryLineageList3 [counter3*15+counter4];
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageAverage [counterA*15+counterB];
                                //    cout<<"  categoryLineageAverage "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount/5; counterA++){
                                //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< categoryLineageList [counterA*5+counterB];
                                //    cout<<"  categoryLineageList "<<counterA<<endl;
                                //}
                                
                                int *categorySortList = new int [totalNoOfCell*3+10];
                                categorySortListCount = 0;
                                
                                for (int counter3 = 0; counter3 < totalNoOfCell*3+10; counter3++) categorySortList [counter3] = 0;
                                
                                maxGeneration = 0;
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (maxGeneration < categoryLineageList [counter3*5+4]) maxGeneration = categoryLineageList [counter3*5+4];
                                }
                                
                                for (int counter3 = 1; counter3 <= maxGeneration; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList [counter4*5+4] == counter3){
                                            categorySortList [categorySortListCount] = categoryLineageList [counter4*5], categorySortListCount++;
                                            categorySortList [categorySortListCount] = categoryLineageList [counter4*5+3], categorySortListCount++;
                                            categorySortList [categorySortListCount] = categoryLineageList [counter4*5+4], categorySortListCount++;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categorySortListCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< categorySortList [counterA*3+counterB];
                                //    cout<<"  categorySortList "<<counterA<<endl;
                                //}
                                
                                ascIIstring = arrayTableMain [counter2][2];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = arrayTableMain [counter2][3];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = arrayTableMain [counter2][4];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < 11; counter3++){
                                    ascIIstring = " ";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Lineage No";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < 13; counter3++){
                                    ascIIstring = "G"+to_string(counter3+1);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                    extraCount = 0;
                                    
                                    for (int counter4 = 0; counter4 <= 15; counter4++){
                                        if (categoryLineageAverage [counter3*15+counter4] != 0.00001){
                                            extraCount++;
                                            break;
                                        }
                                    }
                                    
                                    if (extraCount != 0){
                                        ascIIstring = to_string(counter3+1);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                        
                                        for (int counter4 = 2; counter4 <= 15; counter4++){
                                            if (categoryLineageAverage [counter3*15+counter4] != 0.00001){
                                                ascIIstring = to_string(categoryLineageAverage [counter3*15+counter4]);
                                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                                
                                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                                
                                                oin.put(9);
                                            }
                                            else{
                                                
                                                ascIIstring = " ";
                                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                                
                                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                                
                                                oin.put(9);
                                            }
                                        }
                                        
                                        oin.put(13);
                                        oin.put(10);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Doubling time";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                //for (int counterA = 0; counterA < categorySortListCount/3; counterA++){
                                //    for (int counterB = 0; counterB < 3; counterB++) cout<<" "<< categorySortList [counterA*3+counterB];
                                //    cout<<"  categorySortListCount "<<counterA<<endl;
                                //}
                                
                                newGeneration = 0;
                                
                                for (int counter3 = 0; counter3 < categorySortListCount/3; counter3++){
                                    if (newGeneration != categorySortList[counter3*3+2]){
                                        newGeneration = categorySortList[counter3*3+2];
                                        
                                        oin.put(13);
                                        oin.put(10);
                                        
                                        ascIIstring = "Doubling time Generation "+to_string(newGeneration);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(13);
                                        oin.put(10);
                                        
                                        ascIIstring = to_string(categorySortList [counter3*3+1]);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                    else{
                                        
                                        ascIIstring = to_string(categorySortList[counter3*3+1]);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                delete [] categoryLineageList2;
                                delete [] categoryLineageList3;
                                delete [] categoryLineageAverage;
                                delete [] categorySortList;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else if (timeDiffStatusHold == 1){
                                int *categorySortList = new int [totalNoOfCell*3+10];
                                int *categorySortList2 = new int [totalNoOfCell*3+10];
                                categorySortListCount = 0;
                                categorySortListCount2 = 0;
                                
                                for (int counter3 = 0; counter3 < totalNoOfCell*3+10; counter3++){
                                    categorySortList [counter3] = 0;
                                    categorySortList2 [counter3] = 0;
                                }
                                
                                maxGeneration = 0;
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (maxGeneration < categoryLineageList [counter3*5+4]) maxGeneration = categoryLineageList [counter3*5+4];
                                }
                                
                                int *categoryLineageList2 = new int [lineageEntryNo*15+10];
                                int *categoryLineageList3 = new int [lineageEntryNo*15+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                    categoryLineageList2 [counter3] = -1;
                                    categoryLineageList3 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == startingGeneration){
                                        int *cellNumberDeleteHold = new int [totalNoOfCell*4+50];
                                        cellNumberDeleteHoldCount = 0;
                                        
                                        for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                            if (categoryLineageList [counter4*5] == categoryLineageList [counter3*5] && categoryLineageList [counter4*5+2] == categoryLineageList [counter3*5+1]){
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                            }
                                        }
                                        
                                        do {
                                            
                                            terminationFlag = 0;
                                            
                                            if (cellNumberDeleteHoldCount != 0){
                                                lineageNoGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-4];
                                                nextCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-3];
                                                doublingTimeGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-2];
                                                generationNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-2] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-3] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-4] = 0;
                                                cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-4;
                                                
                                                for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                                    if (lineageNoGet == categoryLineageList [counter4*5] && categoryLineageList [counter4*5+2] == nextCellNo){
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                                    }
                                                }
                                                
                                                if (categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] == -1) categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = 0;
                                                
                                                categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo]+doublingTimeGet-categoryLineageList [counter3*5+3];
                                                
                                                categorySortList [categorySortListCount] = doublingTimeGet-categoryLineageList [counter3*5+3], categorySortListCount++;
                                                categorySortList [categorySortListCount] = generationNo, categorySortListCount++;
                                                
                                                categoryLineageList3 [(categoryLineageList [counter3*5]-1)*15+generationNo]++;
                                            }
                                            else terminationFlag = 1;
                                            
                                        } while (terminationFlag == 0);
                                        
                                        delete [] cellNumberDeleteHold;
                                    }
                                }
                                
                                for (int counter3 = 1; counter3 <= maxGeneration; counter3++){
                                    for (int counter4 = 0; counter4 < categorySortListCount/2; counter4++){
                                        if (categorySortList [counter4*2+1] == counter3){
                                            categorySortList2 [categorySortListCount2] = categorySortList [counter4*2], categorySortListCount2++;
                                            categorySortList2 [categorySortListCount2] = categorySortList [counter4*2+1], categorySortListCount2++;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categorySortListCount2/2; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< categorySortList2 [counterA*2+counterB];
                                //    cout<<"  categorySortList2 "<<counterA<<endl;
                                //}
                                
                                delete [] categorySortList;
                                
                                double *categoryLineageAverage = new double [lineageEntryNo*15+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                    categoryLineageAverage [counter3] = 0.00001;
                                }
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                    for (int counter4 = 0; counter4 < 15; counter4++){
                                        if (categoryLineageList3 [counter3*15+counter4] != 0){
                                            categoryLineageAverage [counter3*15+counter4] = categoryLineageList2 [counter3*15+counter4]/(double)categoryLineageList3 [counter3*15+counter4];
                                        }
                                    }
                                }
                                
                                ascIIstring = arrayTableMain [counter2][2];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = arrayTableMain [counter2][3];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = arrayTableMain [counter2][4];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < 11; counter3++){
                                    ascIIstring = " ";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Lineage No";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                for (int counter3 = 0; counter3 < 13; counter3++){
                                    ascIIstring = "G"+to_string(counter3+1);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                    extraCount = 0;
                                    
                                    for (int counter4 = 0; counter4 <= 15; counter4++){
                                        if (categoryLineageAverage [counter3*15+counter4] != 0.00001){
                                            extraCount++;
                                            break;
                                        }
                                    }
                                    
                                    if (extraCount != 0){
                                        ascIIstring = to_string(counter3+1);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                        
                                        for (int counter4 = 2; counter4 <= 15; counter4++){
                                            if (categoryLineageAverage [counter3*15+counter4] != 0.00001){
                                                ascIIstring = to_string(categoryLineageAverage [counter3*15+counter4]);
                                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                                
                                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                                
                                                oin.put(9);
                                            }
                                            else{
                                                
                                                ascIIstring = " ";
                                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                                
                                                for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                                
                                                oin.put(9);
                                            }
                                        }
                                        
                                        oin.put(13);
                                        oin.put(10);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Doubling time difference";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                //for (int counterA = 0; counterA < categorySortListCount2/2; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< categorySortList [counterA*2+counterB];
                                //    cout<<"  categorySortList "<<counterA<<endl;
                                //}
                                
                                newGeneration = 0;
                                
                                for (int counter3 = 0; counter3 < categorySortListCount2/2; counter3++){
                                    if (newGeneration != categorySortList2 [counter3*2+1]){
                                        newGeneration = categorySortList2 [counter3*2+1];
                                        
                                        oin.put(13);
                                        oin.put(10);
                                        
                                        ascIIstring = "Doubling time Generation "+to_string(newGeneration);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(13);
                                        oin.put(10);
                                        
                                        ascIIstring = to_string(categorySortList2 [counter3*2]);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                    else{
                                        
                                        ascIIstring = to_string(categorySortList[counter3*2]);
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                        
                                        oin.put(9);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                delete [] categoryLineageList2;
                                delete [] categoryLineageList3;
                                delete [] categoryLineageAverage;
                                delete [] categorySortList;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                            else if (timeDiffStatusHold == 2 || timeDiffStatusHold == 3 || timeDiffStatusHold == 4 || timeDiffStatusHold == 5){
                                int numberOfDDG = 0;
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == 3) numberOfDDG++;
                                }
                                
                                int *categoryLineageList2 = new int [numberOfDDG*10+10];
                                categoryLineageListCount2 = 0;
                                
                                for (int counter3 = 0; counter3 < numberOfDDG*10+10; counter3++){
                                    categoryLineageList2 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == 3){
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5], categoryLineageListCount2++; //----Ling no----
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5+1], categoryLineageListCount2++; //----GDD----
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5+2], categoryLineageListCount2++; //----GDD parents----
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5+3], categoryLineageListCount2++; //----GDD Length----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----GD----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----GD partent----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----GD length----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----DA----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----DA Length----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----Total----
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList2 [counter3*10] == categoryLineageList [counter4*5] && categoryLineageList2 [counter3*10+2] == categoryLineageList [counter4*5+1]){
                                            categoryLineageList2 [counter3*10+4] = categoryLineageList [counter4*5+1];
                                            categoryLineageList2 [counter3*10+5] = categoryLineageList [counter4*5+2];
                                            categoryLineageList2 [counter3*10+6] = categoryLineageList [counter4*5+3];
                                            break;
                                        }
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList2 [counter3*10] == categoryLineageList [counter4*5] && categoryLineageList2 [counter3*10+5] == categoryLineageList [counter4*5+1]){
                                            categoryLineageList2 [counter3*10+7] = categoryLineageList [counter4*5+1];
                                            categoryLineageList2 [counter3*10+8] = categoryLineageList [counter4*5+3];
                                            break;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount2/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< categoryLineageList2 [counterA*10+counterB];
                                //    cout<<"  categoryLineageList2 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    if (timeDiffStatusHold == 2 || timeDiffStatusHold == 3){
                                        categoryLineageList2 [counter3*10+9] = categoryLineageList2 [counter3*10+3]+categoryLineageList2 [counter3*10+6]+categoryLineageList2 [counter3*10+8];
                                    }
                                    else if (timeDiffStatusHold == 4 || timeDiffStatusHold == 5){
                                        categoryLineageList2 [counter3*10+9] = categoryLineageList2 [counter3*10+6]+categoryLineageList2 [counter3*10+8];
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount2/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< categoryLineageList2 [counterA*10+counterB];
                                //    cout<<"  categoryLineageList2 "<<counterA<<endl;
                                //}
                                
                                double *categoryLineageListNormalize2 = new double [numberOfDDG+10];
                                categoryLineageListNormalizeCount2 = 0;
                                
                                for (int counter3 = 0; counter3 < numberOfDDG+10; counter3++) categoryLineageListNormalize2 [counter3] = 0;
                                
                                int *categoryLineageList3 = new int [lineageEntryNo*6+10];
                                categoryLineageListCount3 = 0;
                                
                                double *categoryLineageAverage = new double [lineageEntryNo*3+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*3+10; counter3++) categoryLineageAverage [counter3] = -1;
                                
                                int *categoryLineageShortest = new int [(lineageEntryNo+1)*2+10];
                                
                                for (int counter3 = 0; counter3 < (lineageEntryNo+1)*2+10; counter3++) categoryLineageShortest [counter3] = 0;
                                
                                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                                    shortestDoublingValue = 10000000;
                                    
                                    for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                        if (categoryLineageList2 [counter4*10] == counter3){
                                            if (shortestDoublingValue > categoryLineageList2 [counter4*10+9]) shortestDoublingValue = categoryLineageList2 [counter4*10+9];
                                        }
                                    }
                                    
                                    categoryLineageShortest [counter3*2] = counter3;
                                    categoryLineageShortest [counter3*2+1] = shortestDoublingValue;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    shortestDoublingValue = 1;
                                    
                                    for (int counter4 = 1; counter4 <= lineageEntryNo; counter4++){
                                        if (categoryLineageShortest [counter4*2] == categoryLineageList2 [counter3*10]){
                                            shortestDoublingValue = categoryLineageShortest [counter4*2+1];
                                        }
                                    }
                                    
                                    if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                        categoryLineageListNormalize2 [categoryLineageListNormalizeCount2] = categoryLineageList2 [counter3*10+9]/(double)shortestDoublingValue, categoryLineageListNormalizeCount2++;
                                    }
                                    else if (timeDiffStatusHold == 3 || timeDiffStatusHold == 5){
                                        categoryLineageListNormalize2 [categoryLineageListNormalizeCount2] = categoryLineageList2 [counter3*10+9]-shortestDoublingValue, categoryLineageListNormalizeCount2++;
                                    }
                                }
                                
                                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                        if (categoryLineageList2 [counter4*10] == counter3){
                                            cellNoDuplicateFind = 0;
                                            lingNoFind = 0;
                                            
                                            for (int counter5 = 0; counter5 < categoryLineageListCount3/2; counter5++){
                                                if (categoryLineageList3 [counter5*2] == counter3 && categoryLineageList2 [counter4*10+7] == categoryLineageList3 [counter5*2+1]){
                                                    cellNoDuplicateFind = 1;
                                                }
                                                
                                                if (categoryLineageList3 [counter5*2] == counter3){
                                                    lingNoFind = 1;
                                                }
                                            }
                                            
                                            if (lingNoFind == 0){
                                                categoryLineageList3 [categoryLineageListCount3] = categoryLineageList2 [counter4*10], categoryLineageListCount3++;
                                                categoryLineageList3 [categoryLineageListCount3] = 0, categoryLineageListCount3++;
                                            }
                                            
                                            if (cellNoDuplicateFind == 0){
                                                categoryLineageList3 [categoryLineageListCount3] = categoryLineageList2 [counter4*10], categoryLineageListCount3++;
                                                categoryLineageList3 [categoryLineageListCount3] = categoryLineageList2 [counter4*10+7], categoryLineageListCount3++;
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount3/2; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< categoryLineageList3 [counterA*2+counterB];
                                //    cout<<"  categoryLineageList3 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount3/2; counter3++){
                                    if (categoryLineageList3 [counter3*2+1] == 0){
                                        differenceTotal = 0;
                                        numberOfDifPoint = 0;
                                        
                                        for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                            if (categoryLineageList3 [counter3*2] == categoryLineageList2 [counter4*10]){
                                                differenceTotal = differenceTotal+categoryLineageListNormalize2 [counter4];
                                                numberOfDifPoint++;
                                            }
                                        }
                                        
                                        categoryLineageAverage [counter3] = differenceTotal/(double)numberOfDifPoint;
                                    }
                                    else if (categoryLineageList3 [counter3*2] != 0){
                                        differenceTotal = 0;
                                        numberOfDifPoint = 0;
                                        
                                        for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                            if (categoryLineageList3 [counter3*2] == categoryLineageList2 [counter4*10] && categoryLineageList3 [counter3*2+1] == categoryLineageList2 [counter4*10+7]){
                                                differenceTotal = differenceTotal+categoryLineageListNormalize2 [counter4];
                                                numberOfDifPoint++;
                                            }
                                        }
                                        
                                        if (numberOfDifPoint >= grandDDNoCutOff){
                                            categoryLineageAverage [counter3] = differenceTotal/(double)numberOfDifPoint;
                                        }
                                    }
                                }
                                
                                ascIIstring = arrayTableMain [counter2][2];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = arrayTableMain [counter2][3];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = arrayTableMain [counter2][4];
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                                
                                oin.put(9);
                                
                                ascIIstring = " ";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                ascIIstring = " ";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                ascIIstring = "Lineage No";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                ascIIstring = "All";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                ascIIstring = "Sib1";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                ascIIstring = "Sib2";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                ascIIstring = "Sib3";
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount3/2; counter3++){
                                    ascIIstring = to_string(categoryLineageList3 [counter3*2]);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                        percentEventIntCount = (int)((categoryLineageAverage [counter3]-1)*100000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                    }
                                    else if (timeDiffStatusHold == 3 || timeDiffStatusHold == 5){
                                        percentEventIntCount = (int)(categoryLineageAverage [counter3]*1000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                    }
                                    
                                    stringstream extension1;
                                    extension1 << percentEventCount;
                                    percentString = extension1.str();
                                    
                                    ascIIstring = percentString;
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(9);
                                    
                                    extraCount = 0;
                                    
                                    if (counter3+1 < categoryLineageListCount3/2 && categoryLineageList3 [(counter3+1)*2] == categoryLineageList3 [counter3*2]){
                                        if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+1]-1)*100000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        else{
                                            
                                            percentEventIntCount = (int)(categoryLineageAverage [counter3+1]*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        
                                        stringstream extension2;
                                        extension2 << percentEventCount;
                                        percentString = extension2.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                        
                                        extraCount++;
                                    }
                                    else{
                                        
                                        ascIIstring = " ";
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                    }
                                    
                                    if (counter3+2 < categoryLineageListCount3/2 && categoryLineageList3 [(counter3+2)*2] == categoryLineageList3 [counter3*2]){
                                        if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+2]-1)*100000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        else{
                                            
                                            percentEventIntCount = (int)(categoryLineageAverage [counter3+2]*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        
                                        stringstream extension2;
                                        extension2 << percentEventCount;
                                        percentString = extension2.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                        
                                        extraCount++;
                                    }
                                    else{
                                        
                                        ascIIstring = " ";
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                    }
                                    
                                    if (counter3+3 < categoryLineageListCount3/2 && categoryLineageList3 [(counter3+3)*2] == categoryLineageList3 [counter3*2]){
                                        if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+3]-1)*100000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        else{
                                            
                                            percentEventIntCount = (int)(categoryLineageAverage [counter3+3]*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        
                                        stringstream extension2;
                                        extension2 << percentEventCount;
                                        percentString = extension2.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                        
                                        extraCount++;
                                    }
                                    else{
                                        
                                        ascIIstring = " ";
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                    }
                                    
                                    counter3 = counter3+extraCount;
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                if (timeDiffStatusHold == 2 || timeDiffStatusHold == 3){
                                    ascIIstring = "DA+GD+GDD total";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                                else if (timeDiffStatusHold == 4 || timeDiffStatusHold == 5){
                                    ascIIstring = "GD+GDD total";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                for (int counter3 = 0; counter3 < categoryLineageListNormalizeCount2; counter3++){
                                    ascIIstring = to_string(categoryLineageList2 [counter3*10+9]);
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter5 = 0; counter5 < ascIIintDataCount; counter5++) oin.put((char)arrayAscIIintData [counter5]);
                                    
                                    oin.put(9);
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                    ascIIstring = "Ratio";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                    
                                    for (int counter3 = 0; counter3 < categoryLineageListNormalizeCount2; counter3++){
                                        stringstream extension2;
                                        extension2 << categoryLineageListNormalize2[counter3];
                                        percentString = extension2.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                    }
                                }
                                else if (timeDiffStatusHold == 3 || timeDiffStatusHold == 5){
                                    ascIIstring = "Difference";
                                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                    
                                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                    
                                    oin.put(13);
                                    oin.put(10);
                                    
                                    for (int counter3 = 0; counter3 < categoryLineageListNormalizeCount2; counter3++){
                                        stringstream extension2;
                                        extension2 << categoryLineageListNormalize2[counter3];
                                        percentString = extension2.str();
                                        
                                        ascIIstring = percentString;
                                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                        
                                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                        
                                        oin.put(9);
                                    }
                                }
                                
                                oin.put(13);
                                oin.put(10);
                                
                                oin.put(13);
                                oin.put(10);
                                
                                delete [] categoryLineageList2;
                                delete [] categoryLineageList3;
                                delete [] categoryLineageAverage;
                                delete [] categoryLineageListNormalize2;
                                delete [] categoryLineageShortest;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                            }
                        }
                    }
                    else{
                        
                        int **progenyCount = new int *[lineageEntryNo+10];
                        
                        for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++){
                            progenyCount [counter3] = new int [10];
                        }
                        
                        for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++){
                            for (int counter4 = 0; counter4 < 10; counter4++){
                                progenyCount [counter3][counter4] = 0;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                            if (categoryLineageList [counter3*5+4] > 0){
                                progenyCount [categoryLineageList [counter3*5]][categoryLineageList [counter3*5+4]]++;
                            }
                        }
                        
                        //for (int counterA = 1; counterA <=  lineageEntryNo; counterA++){
                        //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< progenyCount [counterA][counterB];
                        //    cout<<"  progenyCount "<<counterA<<endl;
                        //}
                        
                        ascIIstring = arrayTableMain [counter2][2];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayTableMain [counter2][3];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = arrayTableMain [counter2][4];
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
                        
                        oin.put(9);
                        
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        ascIIstring = " ";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        ascIIstring = "DA";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                            if (progenyCount [counter3][1] != 0){
                                ascIIstring = to_string(progenyCount [counter3][1]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        ascIIstring = "GD";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                            if (progenyCount [counter3][1] != 0){
                                ascIIstring = to_string(progenyCount [counter3][2]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        ascIIstring = "GGD";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                            if (progenyCount [counter3][3] != 0){
                                ascIIstring = to_string(progenyCount [counter3][3]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        ascIIstring = "GGGD";
                        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                        
                        for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                        
                        oin.put(9);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                            if (progenyCount [counter3][1] != 0){
                                ascIIstring = to_string(progenyCount [counter3][4]);
                                ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                                
                                for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                                
                                oin.put(9);
                            }
                        }
                        
                        oin.put(13);
                        oin.put(10);
                        
                        oin.put(13);
                        oin.put(10);
                        
                        for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++){
                            delete [] progenyCount [counter3];
                        }
                        
                        delete [] progenyCount;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                    
                    delete [] categoryLineageList;
                }
            }
            
            delete [] arrayAscIIintData;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            oin.close();
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Analysis Performed"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)analysisStart:(id)sender{
    if (lineageDataEntryCount != 0){
        if (geneDAStatusHold == 1 || geneG1StatusHold == 1 || geneG2StatusHold == 1 || geneG3StatusHold == 1){
            progenyDoubleCompResultsHoldCount = 0;
            
            int lineageEntryNo = 0;
            unsigned long lineageEntrySize = 0;
            int totalNoOfCell = 0;
            int categoryLineageListCount = 0;
            int terminationFlag = 0;
            int pointCount = 0;
            int remainingFind = 0;
            int startingGeneration = 0;
            int cellNumberDeleteHoldCount = 0;
            int nextCellNo = 0;
            int generationNo = 0;
            int doublingTimeGet = 0;
            int totalEventCount = 0;
            int lineageNoGet = 0;
            int percentEventIntCount = 0;
            int lastGeneration = 0;
            int actualLingNo = 0;
            int numberOfDifPoint = 0;
            int cellNoDuplicateFind = 0;
            int lingNoFind = 0;
            int categoryLineageListNormalizeCount2 = 0;
            int categoryLineageListCount3 = 0;
            int shortestDoublingValue = 0;
            int categoryLineageListCount2 = 0;
            int extraCount = 0;
            int dATotal = 0;
            int gDTotal = 0;
            int gGDTotal = 0;
            int gGGDTotal = 0;
            int lineageTotal = 0;
            
            double percentEventCount = 0;
            double totalDifférence = 0;
            double differenceTotal = 0;
            
            string percentString;
            string displayData1;
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    
                    //for (int counterA = 0; counterA < 1; counterA++){
                    //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< arrayTableMain [counter2][counterA+counterB];
                    //    cout<<"  arrayTableMain "<<counterA<<endl;
                    //}
                    
                    lineageEntrySize = arrayLineageDataEntryHold [counter2];
                    
                    lineageEntryNo = 0;
                    totalNoOfCell = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+6] > lineageEntryNo){
                            lineageEntryNo = arrayLineageData [counter2][counter3*9+6];
                        }
                        
                        if (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51){
                            totalNoOfCell++;
                        }
                    }
                    
                    int *categoryLineageList = new int [totalNoOfCell*5+10];
                    categoryLineageListCount = 0;
                    
                    for (int counter3 = 0; counter3 < totalNoOfCell*4+10; counter3++) categoryLineageList [counter3] = -1;
                    
                    pointCount = 0;
                    
                    for (unsigned long counter3 = 0; counter3 < lineageEntrySize/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+5] != 0 && (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51)){
                            pointCount = arrayLineageData [counter2][counter3*9+2];
                            
                            categoryLineageList [categoryLineageListCount] = arrayLineageData [counter2][counter3*9+6], categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = arrayLineageData [counter2][counter3*9+5], categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = arrayLineageData [counter2][counter3*9+4], categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = 0, categoryLineageListCount++;
                            categoryLineageList [categoryLineageListCount] = 0, categoryLineageListCount++;
                        }
                        else if (arrayLineageData [counter2][counter3*9+5] != 0 && (arrayLineageData [counter2][counter3*9+3] == 32 || arrayLineageData [counter2][counter3*9+3] == 42 || arrayLineageData [counter2][counter3*9+3] == 52)){
                            categoryLineageList [categoryLineageListCount-2] = arrayLineageData [counter2][counter3*9+2]-pointCount+1;
                        }
                    }
                    
                    for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                        if (categoryLineageList [counter3*5+3] == 0){
                            categoryLineageList [counter3*5] = -1;
                            categoryLineageList [counter3*5+1] = -1;
                            categoryLineageList [counter3*5+2] = -1;
                            categoryLineageList [counter3*5+3] = -1;
                            categoryLineageList [counter3*5+4] = -1;
                        }
                        
                        if (categoryLineageList [counter3*5+3] != 0 && categoryLineageList [counter3*5+2] == 0){
                            categoryLineageList [counter3*5+4] = 1;
                        }
                    }
                    
                    //for (int counterA = 0; counterA < categoryLineageListCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< categoryLineageList [counterA*5+counterB];
                    //    cout<<"  categoryLineageList "<<counterA<<endl;
                    //}
                    
                    do{
                        
                        terminationFlag = 0;
                        remainingFind = 0;
                        
                        for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                            if (categoryLineageList [counter3*5+4] == 0){
                                remainingFind = 1;
                                break;
                            }
                        }
                        
                        if (remainingFind == 1){
                            for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                if (categoryLineageList [counter3*5+4] == 0){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList [counter3*5] == categoryLineageList [counter4*5] && categoryLineageList [counter3*5+2] == categoryLineageList [counter4*5+1]){
                                            categoryLineageList [counter3*5+4] = categoryLineageList [counter4*5+4]+1;
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                        else terminationFlag = 1;
                        
                    } while (terminationFlag == 0);
                    
                    //for (int counterA = 0; counterA < categoryLineageListCount/5; counterA++){
                    //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<< categoryLineageList [counterA*5+counterB];
                    //    cout<<"  categoryLineageList "<<counterA<<endl;
                    //}
                    
                    startingGeneration = 0;
                    
                    if (geneDAStatusHold == 1) startingGeneration = 1;
                    if (geneG1StatusHold == 1) startingGeneration = 2;
                    if (geneG2StatusHold == 1) startingGeneration = 3;
                    if (geneG3StatusHold == 1) startingGeneration = 4;
                    
                    if (progenyDoubleHold == 0){
                        if (lingGenerationStatusHold == 1){
                            int *categoryLineageList2 = new int [lineageEntryNo*15+10];
                            int *categoryLineageList3 = new int [lineageEntryNo*15+10];
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                categoryLineageList2 [counter3] = -1;
                                categoryLineageList3 [counter3] = 0;
                            }
                            
                            for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                if (categoryLineageList [counter3*5+4] == startingGeneration){
                                    int *cellNumberDeleteHold = new int [totalNoOfCell*4+50];
                                    cellNumberDeleteHoldCount = 0;
                                    
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList [counter4*5] == categoryLineageList [counter3*5] && categoryLineageList [counter4*5+2] == categoryLineageList [counter3*5+1]){
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                        }
                                    }
                                    
                                    do {
                                        
                                        terminationFlag = 0;
                                        
                                        if (cellNumberDeleteHoldCount != 0){
                                            lineageNoGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-4];
                                            nextCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-3];
                                            doublingTimeGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-2];
                                            generationNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-2] = 0;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-3] = 0;
                                            cellNumberDeleteHold [cellNumberDeleteHoldCount-4] = 0;
                                            cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-4;
                                            
                                            for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                                if (lineageNoGet == categoryLineageList [counter4*5] && categoryLineageList [counter4*5+2] == nextCellNo){
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                    cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                                }
                                            }
                                            
                                            if (categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] == -1) categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = 0;
                                            
                                            categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo]+doublingTimeGet-categoryLineageList [counter3*5+3];
                                            
                                            categoryLineageList3 [(categoryLineageList [counter3*5]-1)*15+generationNo]++;
                                        }
                                        else terminationFlag = 1;
                                        
                                    } while (terminationFlag == 0);
                                    
                                    delete [] cellNumberDeleteHold;
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList2 [counterA*15+counterB];
                            //    cout<<"  categoryLineageList2 "<<counterA<<endl;
                            //}
                            
                            double *categoryLineageAverage = new double [lineageEntryNo*15+10];
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++) categoryLineageAverage [counter3] = -1;
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                for (int counter4 = 0; counter4 <= 15; counter4++){
                                    if (categoryLineageList3 [counter3*15+counter4] != 0){
                                        categoryLineageAverage [counter3*15+counter4] = categoryLineageList2 [counter3*15+counter4]/(double)categoryLineageList3 [counter3*15+counter4];
                                    }
                                }
                            }
                            
                            //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                            //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageAverage [counterA*15+counterB];
                            //    cout<<"  categoryLineageAverage "<<counterA<<endl;
                            //}
                            
                            int *categorySort = new int [progenyDoubleCompHoldCount+20];
                            
                            totalEventCount = 0;
                            
                            for (int counter3 = 0; counter3 < progenyDoubleCompHoldCount+20; counter3++) categorySort [counter3] = 0;
                            
                            for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                if (categoryLineageAverage [counter3*15+startingGeneration+noOfGenerationValueHold] != -1){
                                    for (int counter4 = 0; counter4 < progenyDoubleCompHoldCount/3; counter4++){
                                        if (categoryLineageAverage [counter3*15+startingGeneration+noOfGenerationValueHold] != -1 && categoryLineageAverage [counter3*15+startingGeneration+noOfGenerationValueHold] >= arrayDoubleCompRangeHold [counter4*3+1] && categoryLineageAverage [counter3*15+startingGeneration+noOfGenerationValueHold] <= arrayDoubleCompRangeHold [counter4*3+2]){
                                            categorySort [counter4]++;
                                            totalEventCount++;
                                            
                                            break;
                                        }
                                    }
                                }
                            }
                            
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][2], progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][3], progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][4], progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            
                            for (int counter3 = 0; counter3 < progenyDoubleCompHoldCount/3; counter3++){
                                if (progenyDoubleCompResultsHoldCount+10 > progenyDoubleCompResultsHoldLimit){
                                    string *arrayUpDate = new string [progenyDoubleCompResultsHoldCount+10];
                                    
                                    for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayProgenyDoubleCompResultsHold [counter4];
                                    
                                    delete [] arrayProgenyDoubleCompResultsHold;
                                    arrayProgenyDoubleCompResultsHold = new string [progenyDoubleCompResultsHoldLimit+350*3+500];
                                    progenyDoubleCompResultsHoldLimit = progenyDoubleCompResultsHoldLimit+350*3+500;
                                    
                                    for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayProgenyDoubleCompResultsHold [counter4] = arrayUpDate [counter4];
                                    delete [] arrayUpDate;
                                }
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                if (arrayDoubleCompRangeHold [counter3*3+2] == 100000000) arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = ">="+to_string(arrayDoubleCompRangeHold [counter3*3+1]), progenyDoubleCompResultsHoldCount++;
                                else arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(arrayDoubleCompRangeHold [counter3*3+1])+"-"+to_string(arrayDoubleCompRangeHold [counter3*3+2]), progenyDoubleCompResultsHoldCount++;
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(categorySort [counter3]), progenyDoubleCompResultsHoldCount++;
                                
                                if (totalEventCount != 0) percentEventCount = categorySort [counter3]/(double)totalEventCount;
                                else percentEventCount = 0;
                                
                                percentEventIntCount = (int)(percentEventCount*100000);
                                percentEventCount = percentEventIntCount/(double)1000;
                                
                                stringstream extension1;
                                extension1 << percentEventCount;
                                percentString = extension1.str();
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                            }
                            
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "Total", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(totalEventCount), progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "100", progenyDoubleCompResultsHoldCount++;
                            
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                            
                            delete [] categorySort;
                            
                            delete [] categoryLineageList2;
                            delete [] categoryLineageList3;
                            delete [] categoryLineageAverage;
                            
                            NSSound *sound = [NSSound soundNamed:@"Ping"];
                            [sound play];
                            
                            [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable object:self];
                        }
                        else if (lingGenerationStatusHold == 0){
                            if (timeDiffStatusHold == 0){
                                int *categoryLineageList2 = new int [lineageEntryNo*15+10];
                                int *categoryLineageList3 = new int [lineageEntryNo*15+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                    categoryLineageList2 [counter3] = -1;
                                    categoryLineageList3 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == startingGeneration){
                                        int *cellNumberDeleteHold = new int [totalNoOfCell*4+50];
                                        cellNumberDeleteHoldCount = 0;
                                        
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5], cellNumberDeleteHoldCount++;
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5+1], cellNumberDeleteHoldCount++;
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5+3], cellNumberDeleteHoldCount++;
                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter3*5+4], cellNumberDeleteHoldCount++;
                                        
                                        do {
                                            
                                            terminationFlag = 0;
                                            
                                            if (cellNumberDeleteHoldCount != 0){
                                                lineageNoGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-4];
                                                nextCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-3];
                                                doublingTimeGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-2];
                                                generationNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-2] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-3] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-4] = 0;
                                                cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-4;
                                                
                                                for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                                    if (lineageNoGet == categoryLineageList [counter4*5] && categoryLineageList [counter4*5+2] == nextCellNo){
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                                    }
                                                }
                                                
                                                if (categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] == -1) categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = 0;
                                                
                                                categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo]+doublingTimeGet;
                                                
                                                categoryLineageList3 [(categoryLineageList [counter3*5]-1)*15+generationNo]++;
                                            }
                                            else terminationFlag = 1;
                                            
                                        } while (terminationFlag == 0);
                                        
                                        delete [] cellNumberDeleteHold;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList2 [counterA*15+counterB];
                                //    cout<<"  categoryLineageList2A "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList3 [counterA*15+counterB];
                                //    cout<<"  categoryLineageList3 "<<counterA<<endl;
                                //}
                                
                                int *categoryLineageListTotal1 = new int [25];
                                int *categoryLineageListTotal2 = new int [25];
                                
                                for (int counter3 = 0; counter3 < 25; counter3++){
                                    categoryLineageListTotal1 [counter3] = 0;
                                    categoryLineageListTotal2 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                    for (int counter4 = 0; counter4 <= 15; counter4++){
                                        if (categoryLineageList2 [counter3*15+counter4] != -1){
                                            categoryLineageListTotal1 [counter4] = categoryLineageListTotal1 [counter4]+categoryLineageList2 [counter3*15+counter4];
                                            categoryLineageListTotal2 [counter4] = categoryLineageListTotal2 [counter4]+categoryLineageList3 [counter3*15+counter4];
                                        }
                                    }
                                }
                                
                                double *categoryLineageAverage = new double [25];
                                
                                for (int counter3 = 0; counter3 < 25; counter3++) categoryLineageAverage [counter3] = 0;
                                
                                lastGeneration = 0;
                                
                                for (int counter4 = 0; counter4 <= 15; counter4++){
                                    if (categoryLineageListTotal2 [counter4] != 0){
                                        categoryLineageAverage [counter4] = categoryLineageListTotal1 [counter4]/(double)categoryLineageListTotal2 [counter4];
                                        lastGeneration = counter4;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageAverage [counterA*15+counterB];
                                //    cout<<"  categoryLineageAverage "<<counterA<<endl;
                                //}
                                
                                delete [] categoryLineageListTotal1;
                                delete [] categoryLineageListTotal2;
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][2], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][3], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][4], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                for (int counter3 = 1; counter3 <= lastGeneration; counter3++){
                                    if (progenyDoubleCompResultsHoldCount+10 > progenyDoubleCompResultsHoldLimit){
                                        string *arrayUpDate = new string [progenyDoubleCompResultsHoldCount+10];
                                        
                                        for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayProgenyDoubleCompResultsHold [counter4];
                                        
                                        delete [] arrayProgenyDoubleCompResultsHold;
                                        arrayProgenyDoubleCompResultsHold = new string [progenyDoubleCompResultsHoldLimit+350*3+500];
                                        progenyDoubleCompResultsHoldLimit = progenyDoubleCompResultsHoldLimit+350*3+500;
                                        
                                        for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayProgenyDoubleCompResultsHold [counter4] = arrayUpDate [counter4];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    
                                    if (counter3 == 1) arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "DA", progenyDoubleCompResultsHoldCount++;
                                    else arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "G"+to_string(counter3), progenyDoubleCompResultsHoldCount++;
                                    
                                    percentEventIntCount = (int)(categoryLineageAverage [counter3]*1000);
                                    percentEventCount = percentEventIntCount/(double)1000;
                                    
                                    stringstream extension1;
                                    extension1 << percentEventCount;
                                    percentString = extension1.str();
                                    
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                }
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                delete [] categoryLineageList2;
                                delete [] categoryLineageList3;
                                delete [] categoryLineageAverage;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable object:self];
                            }
                            else if (timeDiffStatusHold == 1){
                                int *categoryLineageList2 = new int [lineageEntryNo*15+10];
                                int *categoryLineageList3 = new int [lineageEntryNo*15+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*15+10; counter3++){
                                    categoryLineageList2 [counter3] = -1;
                                    categoryLineageList3 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == startingGeneration){
                                        int *cellNumberDeleteHold = new int [totalNoOfCell*4+50];
                                        cellNumberDeleteHoldCount = 0;
                                        
                                        for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                            if (categoryLineageList [counter4*5] == categoryLineageList [counter3*5] && categoryLineageList [counter4*5+2] == categoryLineageList [counter3*5+1]){
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                            }
                                        }
                                        
                                        do {
                                            
                                            terminationFlag = 0;
                                            
                                            if (cellNumberDeleteHoldCount != 0){
                                                lineageNoGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-4];
                                                nextCellNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-3];
                                                doublingTimeGet = cellNumberDeleteHold [cellNumberDeleteHoldCount-2];
                                                generationNo = cellNumberDeleteHold [cellNumberDeleteHoldCount-1];
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-1] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-2] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-3] = 0;
                                                cellNumberDeleteHold [cellNumberDeleteHoldCount-4] = 0;
                                                cellNumberDeleteHoldCount = cellNumberDeleteHoldCount-4;
                                                
                                                for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                                    if (lineageNoGet == categoryLineageList [counter4*5] && categoryLineageList [counter4*5+2] == nextCellNo){
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+1], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+3], cellNumberDeleteHoldCount++;
                                                        cellNumberDeleteHold [cellNumberDeleteHoldCount] = categoryLineageList [counter4*5+4], cellNumberDeleteHoldCount++;
                                                    }
                                                }
                                                
                                                if (categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] == -1) categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = 0;
                                                
                                                categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo] = categoryLineageList2 [(categoryLineageList [counter3*5]-1)*15+generationNo]+doublingTimeGet-categoryLineageList [counter3*5+3];
                                                
                                                categoryLineageList3 [(categoryLineageList [counter3*5]-1)*15+generationNo]++;
                                            }
                                            else terminationFlag = 1;
                                            
                                        } while (terminationFlag == 0);
                                        
                                        delete [] cellNumberDeleteHold;
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList2 [counterA*15+counterB];
                                //    cout<<"  categoryLineageList2A "<<counterA<<endl;
                                //}
                                
                                //for (int counterA = 0; counterA < lineageEntryNo; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageList3 [counterA*15+counterB];
                                //    cout<<"  categoryLineageList3 "<<counterA<<endl;
                                //}
                                
                                int *categoryLineageListTotal1 = new int [25];
                                int *categoryLineageListTotal2 = new int [25];
                                
                                for (int counter3 = 0; counter3 < 25; counter3++){
                                    categoryLineageListTotal1 [counter3] = 0;
                                    categoryLineageListTotal2 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo; counter3++){
                                    for (int counter4 = 0; counter4 <= 15; counter4++){
                                        if (categoryLineageList2 [counter3*15+counter4] != -1){
                                            categoryLineageListTotal1 [counter4] = categoryLineageListTotal1 [counter4]+categoryLineageList2 [counter3*15+counter4];
                                            categoryLineageListTotal2 [counter4] = categoryLineageListTotal2 [counter4]+categoryLineageList3 [counter3*15+counter4];
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageListTotal2 [counterA*15+counterB];
                                //    cout<<"  categoryLineageListTotal2 "<<counterA<<endl;
                                //}
                                
                                double *categoryLineageAverage = new double [25];
                                
                                for (int counter3 = 0; counter3 < 25; counter3++) categoryLineageAverage [counter3] = 0;
                                
                                for (int counter4 = 0; counter4 <= 15; counter4++){
                                    if (categoryLineageListTotal2 [counter4] != 0){
                                        categoryLineageAverage [counter4] = categoryLineageListTotal1 [counter4]/(double)categoryLineageListTotal2 [counter4];
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < 15; counterB++) cout<<" "<< categoryLineageAverage [counterA*15+counterB];
                                //    cout<<"  categoryLineageAverage "<<counterA<<endl;
                                //}
                                
                                delete [] categoryLineageListTotal1;
                                delete [] categoryLineageListTotal2;
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][2], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][3], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][4], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                for (int counter3 = startingGeneration+1; counter3 <= startingGeneration+noOfGenerationValueHold; counter3++){
                                    if (progenyDoubleCompResultsHoldCount+10 > progenyDoubleCompResultsHoldLimit){
                                        string *arrayUpDate = new string [progenyDoubleCompResultsHoldCount+10];
                                        
                                        for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayProgenyDoubleCompResultsHold [counter4];
                                        
                                        delete [] arrayProgenyDoubleCompResultsHold;
                                        arrayProgenyDoubleCompResultsHold = new string [progenyDoubleCompResultsHoldLimit+350*3+500];
                                        progenyDoubleCompResultsHoldLimit = progenyDoubleCompResultsHoldLimit+350*3+500;
                                        
                                        for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayProgenyDoubleCompResultsHold [counter4] = arrayUpDate [counter4];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "G"+to_string(counter3), progenyDoubleCompResultsHoldCount++;
                                    
                                    percentEventIntCount = (int)(categoryLineageAverage [counter3]*1000);
                                    percentEventCount = percentEventIntCount/(double)1000;
                                    
                                    stringstream extension1;
                                    extension1 << percentEventCount;
                                    percentString = extension1.str();
                                    
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                }
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                delete [] categoryLineageList2;
                                delete [] categoryLineageList3;
                                delete [] categoryLineageAverage;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable object:self];
                            }
                            else if (timeDiffStatusHold == 2 || timeDiffStatusHold == 3 || timeDiffStatusHold == 4 || timeDiffStatusHold == 5){
                                int numberOfDDG = 0;
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == 3) numberOfDDG++;
                                }
                                
                                int *categoryLineageList2 = new int [numberOfDDG*10+10];
                                categoryLineageListCount2 = 0;
                                
                                for (int counter3 = 0; counter3 < numberOfDDG*10+10; counter3++){
                                    categoryLineageList2 [counter3] = 0;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                                    if (categoryLineageList [counter3*5+4] == 3){
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5], categoryLineageListCount2++; //----Ling no----
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5+1], categoryLineageListCount2++; //----GDD----
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5+2], categoryLineageListCount2++; //----GDD parents----
                                        categoryLineageList2 [categoryLineageListCount2] = categoryLineageList [counter3*5+3], categoryLineageListCount2++; //----GDD Length----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----GD----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----GD partent----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----GD length----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----DA----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----DA Length----
                                        categoryLineageList2 [categoryLineageListCount2] = 0, categoryLineageListCount2++; //----Total----
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList2 [counter3*10] == categoryLineageList [counter4*5] && categoryLineageList2 [counter3*10+2] == categoryLineageList [counter4*5+1]){
                                            categoryLineageList2 [counter3*10+4] = categoryLineageList [counter4*5+1];
                                            categoryLineageList2 [counter3*10+5] = categoryLineageList [counter4*5+2];
                                            categoryLineageList2 [counter3*10+6] = categoryLineageList [counter4*5+3];
                                            break;
                                        }
                                    }
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount/5; counter4++){
                                        if (categoryLineageList2 [counter3*10] == categoryLineageList [counter4*5] && categoryLineageList2 [counter3*10+5] == categoryLineageList [counter4*5+1]){
                                            categoryLineageList2 [counter3*10+7] = categoryLineageList [counter4*5+1];
                                            categoryLineageList2 [counter3*10+8] = categoryLineageList [counter4*5+3];
                                            break;
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount2/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< categoryLineageList2 [counterA*10+counterB];
                                //    cout<<"  categoryLineageList2 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    if (timeDiffStatusHold == 2 || timeDiffStatusHold == 3){
                                        categoryLineageList2 [counter3*10+9] = categoryLineageList2 [counter3*10+3]+categoryLineageList2 [counter3*10+6]+categoryLineageList2 [counter3*10+8];
                                    }
                                    else categoryLineageList2 [counter3*10+9] = categoryLineageList2 [counter3*10+6]+categoryLineageList2 [counter3*10+8];
                                }
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount2/10; counterA++){
                                //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< categoryLineageList2 [counterA*10+counterB];
                                //    cout<<"  categoryLineageList2 "<<counterA<<endl;
                                //}
                                
                                double *categoryLineageListNormalize2 = new double [numberOfDDG+10];
                                categoryLineageListNormalizeCount2 = 0;
                                
                                for (int counter3 = 0; counter3 < numberOfDDG+10; counter3++) categoryLineageListNormalize2 [counter3] = 0;
                                
                                int *categoryLineageList3 = new int [lineageEntryNo*6+10];
                                categoryLineageListCount3 = 0;
                                
                                double *categoryLineageAverage = new double [lineageEntryNo*3+10];
                                
                                for (int counter3 = 0; counter3 < lineageEntryNo*3+10; counter3++) categoryLineageAverage [counter3] = -1;
                                
                                int *categoryLineageShortest = new int [(lineageEntryNo+1)*2+10];
                                
                                for (int counter3 = 0; counter3 < (lineageEntryNo+1)*2+10; counter3++) categoryLineageShortest [counter3] = 0;
                                
                                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                                    shortestDoublingValue = 10000000;
                                    
                                    for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                        if (categoryLineageList2 [counter4*10] == counter3){
                                            if (shortestDoublingValue > categoryLineageList2 [counter4*10+9]) shortestDoublingValue = categoryLineageList2 [counter4*10+9];
                                        }
                                    }
                                    
                                    categoryLineageShortest [counter3*2] = counter3;
                                    categoryLineageShortest [counter3*2+1] = shortestDoublingValue;
                                }
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount2/10; counter3++){
                                    shortestDoublingValue = 1;
                                    
                                    for (int counter4 = 1; counter4 <= lineageEntryNo; counter4++){
                                        if (categoryLineageShortest [counter4*2] == categoryLineageList2 [counter3*10]){
                                            shortestDoublingValue = categoryLineageShortest [counter4*2+1];
                                        }
                                    }
                                    
                                    if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                        categoryLineageListNormalize2 [categoryLineageListNormalizeCount2] = categoryLineageList2 [counter3*10+9]/(double)shortestDoublingValue, categoryLineageListNormalizeCount2++;
                                    }
                                    else if (timeDiffStatusHold == 3 || timeDiffStatusHold == 5){
                                        categoryLineageListNormalize2 [categoryLineageListNormalizeCount2] = categoryLineageList2 [counter3*10+9]-shortestDoublingValue, categoryLineageListNormalizeCount2++;
                                    }
                                }
                                
                                for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                                    for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                        if (categoryLineageList2 [counter4*10] == counter3){
                                            cellNoDuplicateFind = 0;
                                            lingNoFind = 0;
                                            
                                            for (int counter5 = 0; counter5 < categoryLineageListCount3/2; counter5++){
                                                if (categoryLineageList3 [counter5*2] == counter3 && categoryLineageList2 [counter4*10+7] == categoryLineageList3 [counter5*2+1]){
                                                    cellNoDuplicateFind = 1;
                                                }
                                                
                                                if (categoryLineageList3 [counter5*2] == counter3){
                                                    lingNoFind = 1;
                                                }
                                            }
                                            
                                            if (lingNoFind == 0){
                                                categoryLineageList3 [categoryLineageListCount3] = categoryLineageList2 [counter4*10], categoryLineageListCount3++;
                                                categoryLineageList3 [categoryLineageListCount3] = 0, categoryLineageListCount3++;
                                            }
                                            
                                            if (cellNoDuplicateFind == 0){
                                                categoryLineageList3 [categoryLineageListCount3] = categoryLineageList2 [counter4*10], categoryLineageListCount3++;
                                                categoryLineageList3 [categoryLineageListCount3] = categoryLineageList2 [counter4*10+7], categoryLineageListCount3++;
                                            }
                                        }
                                    }
                                }
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount3/2; counterA++){
                                //    for (int counterB = 0; counterB < 2; counterB++) cout<<" "<< categoryLineageList3 [counterA*2+counterB];
                                //    cout<<"  categoryLineageList3 "<<counterA<<endl;
                                //}
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount3/2; counter3++){
                                    if (categoryLineageList3 [counter3*2+1] == 0){
                                        differenceTotal = 0;
                                        numberOfDifPoint = 0;
                                        
                                        for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                            if (categoryLineageList3 [counter3*2] == categoryLineageList2 [counter4*10]){
                                                differenceTotal = differenceTotal+categoryLineageListNormalize2 [counter4];
                                                numberOfDifPoint++;
                                            }
                                        }
                                        
                                        categoryLineageAverage [counter3] = differenceTotal/(double)numberOfDifPoint;
                                    }
                                    else if (categoryLineageList3 [counter3*2] != 0){
                                        differenceTotal = 0;
                                        numberOfDifPoint = 0;
                                        
                                        for (int counter4 = 0; counter4 < categoryLineageListCount2/10; counter4++){
                                            if (categoryLineageList3 [counter3*2] == categoryLineageList2 [counter4*10] && categoryLineageList3 [counter3*2+1] == categoryLineageList2 [counter4*10+7]){
                                                differenceTotal = differenceTotal+categoryLineageListNormalize2 [counter4];
                                                numberOfDifPoint++;
                                            }
                                        }
                                        
                                        if (numberOfDifPoint >= grandDDNoCutOff){
                                            categoryLineageAverage [counter3] = differenceTotal/(double)numberOfDifPoint;
                                        }
                                    }
                                }
                                
                                totalDifférence = 0;
                                actualLingNo = 0;
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount3/2; counter3++){
                                    if (categoryLineageList3 [counter3*2+1] == 0){
                                        totalDifférence = totalDifférence+categoryLineageAverage [counter3];
                                        actualLingNo++;
                                    }
                                }
                                
                                totalDifférence = totalDifférence/(double)actualLingNo;
                                
                                //for (int counterA = 0; counterA < categoryLineageListCount3/2; counterA++){
                                //    cout<<" "<< categoryLineageAverage [counterA]<<"  categoryLineageAverage "<<counterA<<endl;
                                //}
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][2], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][3], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][4], progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                for (int counter3 = 0; counter3 < categoryLineageListCount3/2; counter3++){
                                    if (progenyDoubleCompResultsHoldCount+10 > progenyDoubleCompResultsHoldLimit){
                                        string *arrayUpDate = new string [progenyDoubleCompResultsHoldCount+10];
                                        
                                        for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayProgenyDoubleCompResultsHold [counter4];
                                        
                                        delete [] arrayProgenyDoubleCompResultsHold;
                                        arrayProgenyDoubleCompResultsHold = new string [progenyDoubleCompResultsHoldLimit+350*3+500];
                                        progenyDoubleCompResultsHoldLimit = progenyDoubleCompResultsHoldLimit+350*3+500;
                                        
                                        for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayProgenyDoubleCompResultsHold [counter4] = arrayUpDate [counter4];
                                        delete [] arrayUpDate;
                                    }
                                    
                                    displayData1 = to_string(categoryLineageList3 [counter3*2]);
                                    
                                    if (displayData1.length() == 1) displayData1 = "L0000"+displayData1;
                                    else if (displayData1.length() == 2) displayData1 = "L000"+displayData1;
                                    else if (displayData1.length() == 3) displayData1 = "L00"+displayData1;
                                    else if (displayData1.length() == 4) displayData1 = "L0"+displayData1;
                                    else if (displayData1.length() == 5) displayData1 = "L"+displayData1;
                                    
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = displayData1, progenyDoubleCompResultsHoldCount++;
                                    
                                    if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                        percentEventIntCount = (int)((categoryLineageAverage [counter3]-1)*100000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                    }
                                    else{
                                        
                                        percentEventIntCount = (int)((categoryLineageAverage [counter3])*1000);
                                        percentEventCount = percentEventIntCount/(double)1000;
                                    }
                                    
                                    stringstream extension1;
                                    extension1 << percentEventCount;
                                    percentString = extension1.str();
                                    
                                    arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                    
                                    extraCount = 0;
                                    
                                    if (counter3+1 < categoryLineageListCount3/2 && categoryLineageList3 [(counter3+1)*2] == categoryLineageList3 [counter3*2]){
                                        if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+1]-1)*100000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        else{
                                            
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+1])*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        
                                        stringstream extension2;
                                        extension2 << percentEventCount;
                                        percentString = extension2.str();
                                        
                                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                        
                                        extraCount++;
                                    }
                                    else arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    
                                    if (counter3+2 < categoryLineageListCount3/2 && categoryLineageList3 [(counter3+2)*2] == categoryLineageList3 [counter3*2]){
                                        if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+2]-1)*100000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        else{
                                            
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+2])*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        
                                        stringstream extension2;
                                        extension2 << percentEventCount;
                                        percentString = extension2.str();
                                        
                                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                        
                                        extraCount++;
                                    }
                                    else arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    
                                    if (counter3+3 < categoryLineageListCount3/2 && categoryLineageList3 [(counter3+3)*2] == categoryLineageList3 [counter3*2]){
                                        if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+3]-1)*100000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        else{
                                            
                                            percentEventIntCount = (int)((categoryLineageAverage [counter3+3])*1000);
                                            percentEventCount = percentEventIntCount/(double)1000;
                                        }
                                        
                                        stringstream extension2;
                                        extension2 << percentEventCount;
                                        percentString = extension2.str();
                                        
                                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                        
                                        extraCount++;
                                    }
                                    else arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                    
                                    counter3 = counter3+extraCount;
                                }
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "Average", progenyDoubleCompResultsHoldCount++;
                                
                                if (timeDiffStatusHold == 2 || timeDiffStatusHold == 4){
                                    percentEventIntCount = (int)((totalDifférence-1)*100000);
                                    percentEventCount = percentEventIntCount/(double)1000;
                                }
                                else{
                                    
                                    percentEventIntCount = (int)(totalDifférence*1000);
                                    percentEventCount = percentEventIntCount/(double)1000;
                                }
                                
                                stringstream extension3;
                                extension3 << percentEventCount;
                                percentString = extension3.str();
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                                
                                delete [] categoryLineageList2;
                                delete [] categoryLineageList3;
                                delete [] categoryLineageAverage;
                                delete [] categoryLineageListNormalize2;
                                delete [] categoryLineageShortest;
                                
                                NSSound *sound = [NSSound soundNamed:@"Ping"];
                                [sound play];
                                
                                [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable object:self];
                            }
                        }
                    }
                    else{
                        
                        int **progenyCount = new int *[lineageEntryNo+10];
                        
                        for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++){
                            progenyCount [counter3] = new int [10];
                        }
                        
                        for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++){
                            for (int counter4 = 0; counter4 < 10; counter4++){
                                progenyCount [counter3][counter4] = 0;
                            }
                        }
                        
                        for (int counter3 = 0; counter3 < categoryLineageListCount/5; counter3++){
                            if (categoryLineageList [counter3*5+4] > 0){
                                progenyCount [categoryLineageList [counter3*5]][categoryLineageList [counter3*5+4]]++;
                            }
                        }
                        
                        //for (int counterA = 1; counterA <=  lineageEntryNo; counterA++){
                        //    for (int counterB = 0; counterB < 10; counterB++) cout<<" "<< progenyCount [counterA][counterB];
                        //    cout<<"  progenyCount "<<counterA<<endl;
                        //}
                        
                        dATotal = 0;
                        gDTotal = 0;
                        gGDTotal = 0;
                        gGGDTotal = 0;
                        lineageTotal = 0;
                        
                        for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                            if (progenyCount [counter3][1] != 0){
                                dATotal = dATotal+progenyCount [counter3][1];
                                gDTotal = gDTotal+progenyCount [counter3][2];
                                gGDTotal = gGDTotal+progenyCount [counter3][3];
                                gGGDTotal = gGGDTotal+progenyCount [counter3][4];
                                lineageTotal++;
                            }
                        }
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][2], progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][3], progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = arrayTableMain [counter2][4], progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "Lineage", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "DA", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "GD", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "GGD", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "GGGD", progenyDoubleCompResultsHoldCount++;
                        
                        for (int counter3 = 1; counter3 <= lineageEntryNo; counter3++){
                            if (progenyDoubleCompResultsHoldCount+10 > progenyDoubleCompResultsHoldLimit){
                                string *arrayUpDate = new string [progenyDoubleCompResultsHoldCount+10];
                                
                                for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayUpDate [counter4] = arrayProgenyDoubleCompResultsHold [counter4];
                                
                                delete [] arrayProgenyDoubleCompResultsHold;
                                arrayProgenyDoubleCompResultsHold = new string [progenyDoubleCompResultsHoldLimit+350*3+500];
                                progenyDoubleCompResultsHoldLimit = progenyDoubleCompResultsHoldLimit+350*3+500;
                                
                                for (int counter4 = 0; counter4 < progenyDoubleCompResultsHoldCount; counter4++) arrayProgenyDoubleCompResultsHold [counter4] = arrayUpDate [counter4];
                                delete [] arrayUpDate;
                            }
                            
                            if (progenyCount [counter3][1] != 0){
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(counter3), progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(progenyCount [counter3][1]), progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(progenyCount [counter3][2]), progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(progenyCount [counter3][3]), progenyDoubleCompResultsHoldCount++;
                                arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(progenyCount [counter3][4]), progenyDoubleCompResultsHoldCount++;
                            }
                        }
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "Average/Lineage", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = to_string(lineageTotal), progenyDoubleCompResultsHoldCount++;
                        
                        percentEventCount = dATotal/(double)lineageTotal;
                        percentEventIntCount = (int)(percentEventCount*100);
                        percentEventCount = percentEventIntCount/(double)100;
                        
                        stringstream extension1;
                        extension1 << percentEventCount;
                        percentString = extension1.str();
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                        
                        percentEventCount = gDTotal/(double)lineageTotal;
                        percentEventIntCount = (int)(percentEventCount*100);
                        percentEventCount = percentEventIntCount/(double)100;
                        
                        stringstream extension2;
                        extension2 << percentEventCount;
                        percentString = extension2.str();
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                        
                        percentEventCount = gGDTotal/(double)lineageTotal;
                        percentEventIntCount = (int)(percentEventCount*100);
                        percentEventCount = percentEventIntCount/(double)100;
                        
                        stringstream extension3;
                        extension3 << percentEventCount;
                        percentString = extension3.str();
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                        
                        percentEventCount = gGGDTotal/(double)lineageTotal;
                        percentEventIntCount = (int)(percentEventCount*100);
                        percentEventCount = percentEventIntCount/(double)100;
                        
                        stringstream extension4;
                        extension4 << percentEventCount;
                        percentString = extension4.str();
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = percentString, progenyDoubleCompResultsHoldCount++;
                        
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        arrayProgenyDoubleCompResultsHold [progenyDoubleCompResultsHoldCount] = "", progenyDoubleCompResultsHoldCount++;
                        
                        for (int counter3 = 0; counter3 < lineageEntryNo+10; counter3++){
                            delete [] progenyCount [counter3];
                        }
                        
                        delete [] progenyCount;
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                        
                        [[NSNotificationCenter defaultCenter] postNotificationName:notificationToDoubCompTable object:self];
                    }
                    
                    delete [] categoryLineageList;
                }
            }
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"No Start Generation Set"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)setDA:(id)sender{
    if (geneDAStatusHold == 0){
        geneDAStatusHold = 1;
        geneG1StatusHold = 0;
        geneG2StatusHold = 0;
        geneG3StatusHold = 0;
        
        [startDADisplay setStringValue:@"Yes"];
        [startDG1isplay setStringValue:@"No"];
        [startDG2isplay setStringValue:@"No"];
        [startDG3isplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setG1:(id)sender{
    if (geneG1StatusHold == 0){
        geneDAStatusHold = 0;
        geneG1StatusHold = 1;
        geneG2StatusHold = 0;
        geneG3StatusHold = 0;
        
        [startDADisplay setStringValue:@"No"];
        [startDG1isplay setStringValue:@"Yes"];
        [startDG2isplay setStringValue:@"No"];
        [startDG3isplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setG2:(id)sender{
    if (geneG2StatusHold == 0){
        geneDAStatusHold = 0;
        geneG1StatusHold = 0;
        geneG2StatusHold = 1;
        geneG3StatusHold = 0;
        
        [startDADisplay setStringValue:@"No"];
        [startDG1isplay setStringValue:@"No"];
        [startDG2isplay setStringValue:@"Yes"];
        [startDG3isplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setG3:(id)sender{
    if (geneG3StatusHold == 0){
        geneDAStatusHold = 0;
        geneG1StatusHold = 0;
        geneG2StatusHold = 0;
        geneG3StatusHold = 1;
        
        [startDADisplay setStringValue:@"No"];
        [startDG1isplay setStringValue:@"No"];
        [startDG2isplay setStringValue:@"No"];
        [startDG3isplay setStringValue:@"Yes"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)timeDiffSet:(id)sender{
    if (lingGenerationStatusHold == 0){
        if (timeDiffStatusHold == 0){
            timeDiffStatusHold = 1;
            [timeDiffDisplay setStringValue:@"Diff"];
        }
        else if (timeDiffStatusHold == 1){
            timeDiffStatusHold = 2;
            [timeDiffDisplay setStringValue:@"DA+1"];
        }
        else if (timeDiffStatusHold == 2){
            timeDiffStatusHold = 3;
            [timeDiffDisplay setStringValue:@"DA+2"];
        }
        else if (timeDiffStatusHold == 3){
            timeDiffStatusHold = 4;
            [timeDiffDisplay setStringValue:@"DA+3"];
        }
        else if (timeDiffStatusHold == 4){
            timeDiffStatusHold = 5;
            [timeDiffDisplay setStringValue:@"DA+4"];
        }
        else if (timeDiffStatusHold == 5){
            timeDiffStatusHold = 0;
            [timeDiffDisplay setStringValue:@"Time"];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Ling Mode"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)lingGenSet:(id)sender{
    if (lingGenerationStatusHold == 0){
        lingGenerationStatusHold = 1;
        [lingGenerationDisplay setStringValue:@"Ling"];
        
        timeDiffStatusHold = 1;
        [timeDiffDisplay setStringValue:@"Diff"];
    }
    else{
        
        lingGenerationStatusHold = 0;
        [lingGenerationDisplay setStringValue:@"Gen"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)proDobSet:(id)sender{
    if (progenyDoubleHold == 0){
        progenyDoubleHold = 1;
        [progenyDoubleDisplay setStringValue:@"Pro."];
    }
    else{
        
        progenyDoubleHold = 0;
        [progenyDoubleDisplay setStringValue:@"Dob."];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)setGDDCut:(id)sender{
    if (grandDDNoCutOff == 0){
        grandDDNoCutOff = 1;
        [grandDDNoCutOffDisplay setStringValue:@"1"];
    }
    else if (grandDDNoCutOff == 1){
        grandDDNoCutOff = 2;
        [grandDDNoCutOffDisplay setStringValue:@"2"];
    }
    else if (grandDDNoCutOff == 2){
        grandDDNoCutOff = 3;
        [grandDDNoCutOffDisplay setStringValue:@"3"];
    }
    else if (grandDDNoCutOff == 3){
        grandDDNoCutOff = 4;
        [grandDDNoCutOffDisplay setStringValue:@"4"];
    }
    else if (grandDDNoCutOff == 4){
        grandDDNoCutOff = 5;
        [grandDDNoCutOffDisplay setStringValue:@"5"];
    }
    else if (grandDDNoCutOff == 5){
        grandDDNoCutOff = 6;
        [grandDDNoCutOffDisplay setStringValue:@"6"];
    }
    else if (grandDDNoCutOff == 6){
        grandDDNoCutOff = 0;
        [grandDDNoCutOffDisplay setStringValue:@"No"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)reDisplayWindow{
    if (doubCompOperation == 3){
        [mainWindowDoubWindow makeKeyAndOrderFront:nil];
        doubCompOperation = 1;
        [doubControllerTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [mainWindowDoubWindow orderOut:nil];
    doubCompOperation = 2;
    doubControllerTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDoubCompController object:nil];
}

@end
