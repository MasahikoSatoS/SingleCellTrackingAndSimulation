//
//  CellDivisionAddition.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/15/16.
//
//

#ifndef CELLDIVISIONADDITION_H
#define CELLDIVISIONADDITION_H
#import "Controller.h" 
#endif

@interface CellDivisionAddition : NSObject{
    IBOutlet NSTextField *horizontalLow;
    IBOutlet NSTextField *horizontalHigh;
    IBOutlet NSTextField *verticalHigh;
    IBOutlet NSTextField *verticalDownHigh;
}

-(id)init;
-(void)dealloc;

@end
