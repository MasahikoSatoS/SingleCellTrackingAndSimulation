//
//  DoublingTimeDisplay.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/16/16.
//
//

#import "DoublingTimeDisplay.h"

NSString *notificationToDoublingTimeDisplay = @"notificationExecuteDoublingTimeDisplay";

@implementation DoublingTimeDisplay

-(id)initWithFrame:(NSRect)frame{
    self = [super initWithFrame:frame];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDoublingTimeDisplay object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [self setNeedsDisplay:YES];
}

-(void)mouseDown:(NSEvent *)event{
    NSPoint clickPoint = [self convertPoint:[event locationInWindow] fromView:nil];
    
    if (upLoadingProgress == 0){
        if (clickPoint.x > 718 && clickPoint.x < 760 && clickPoint.y >573 && clickPoint.y < 587){
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        
        if (clickPoint.x > 668 && clickPoint.x < 710 && clickPoint.y >573 && clickPoint.y < 587){
            exportFlag7 = 1;
            
            string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
            mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Doubling_Time";
            mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
            
            DIR *dir;
            struct dirent *dent;
            
            string entry;
            string extractString;
            int maxEntryNo = 0;
            
            dir = opendir(resultSavePath2.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Doubling_Time") != -1){
                        extractString = entry.substr(entry.find("DT")+2, entry.find(".tif")-entry.find("DT")-2);
                        
                        if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
                    }
                }
                
                closedir(dir);
            }
            
            maxEntryNo++;
            
            exportResultPath = resultSavePath2+"/Doubling_Time-DT"+to_string(maxEntryNo)+".tif";
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
        
        if (exportFlag7 == 2){
            exportFlag7 = 0;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
            
            [self setNeedsDisplay:YES];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(BOOL)acceptsFirstResponder{
    return YES;
}

-(void)drawRect:(NSRect)rect{
    if (exportFlag7 == 0){
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767, 591)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(718, 573, 42, 14)];
        [path stroke];
        
        string reloadString = "Reload";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 720;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        [[NSColor blueColor] set];
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(668, 573, 42, 14)];
        [path stroke];
        
        reloadString = "Export";
        
        attrStrA = [[NSAttributedString alloc] initWithString:@(reloadString.c_str()) attributes:attributesA];
        pointA.x = 670;
        pointA.y = 573;
        [attrStrA drawAtPoint:pointA];
        
        int entryNumberCount = 0;
        int maxEntry = 0;
        
        int *entryNumberTempHold = new int [40];
        int entryNumberTempHoldCount = 0;
        
        int rangeSt1 = 0;
        int rangeEd1 = 0;
        
        int rangeSt2 = 0;
        int rangeEd2 = 0;
        
        int rangeSt3 = 0;
        int rangeEd3 = 0;
        
        int rangeSt4 = 0;
        int rangeEd4 = 0;
        
        if (rangeDoubleSt1 > 0 && rangeDoubleEd1 > 0 && rangeDoubleSt1+10 < rangeDoubleEd1){
            rangeSt1 = rangeDoubleSt1;
            rangeEd1 = rangeDoubleEd1;
        }
        
        if (rangeDoubleSt2 > 0 && rangeDoubleEd2 > 0 && rangeDoubleSt2+10 < rangeDoubleEd2){
            rangeSt2 = rangeDoubleSt2;
            rangeEd2 = rangeDoubleEd2;
        }
        
        if (rangeDoubleSt3 > 0 && rangeDoubleEd3 > 0 && rangeDoubleSt3+10 < rangeDoubleEd3){
            rangeSt3 = rangeDoubleSt3;
            rangeEd3 = rangeDoubleEd3;
        }
        
        if (rangeDoubleSt4 > 0 && rangeDoubleEd4 > 0 && rangeDoubleSt4+10 < rangeDoubleEd4){
            rangeSt4 = rangeDoubleSt4;
            rangeEd4 = rangeDoubleEd4;
        }
        
        if (rangeSt1 == 0){
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 12){
                    entryNumberCount++;
                    entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    
                    maxEntry++;
                }
            }
        }
        else{
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 1){
                    if (rangeSt1 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    if (rangeSt2 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    if (rangeSt3 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    if (rangeSt4 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    maxEntry++;
                }
            }
        }
        
        int displayItem1 = 0;
        int displayItem2 = 0;
        int displayItem3 = 0;
        int displayItem4 = 0;
        int displayItem5 = 0;
        int displayItem6 = 0;
        int displayItem7 = 0;
        int displayItem8 = 0;
        int displayItem9 = 0;
        int displayItem10 = 0;
        int displayItem11 = 0;
        int displayItem12 = 0;
        
        if (rangeSt1 == 0){
            if (entryNumberCount == 1) displayItem1 = 1;
            else if (entryNumberCount == 2){
                displayItem1 = 2;
                displayItem2 = 2;
            }
            else if (entryNumberCount == 3){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
            }
            else if (entryNumberCount == 4){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 5){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 5;
                displayItem5 = 5;
            }
            else if (entryNumberCount == 6){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 6;
                displayItem5 = 6;
                displayItem6 = 6;
            }
            else if (entryNumberCount == 7){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 7;
                displayItem5 = 7;
                displayItem6 = 7;
                displayItem7 = 7;
            }
            else if (entryNumberCount == 8){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 8;
                displayItem4 = 8;
                displayItem5 = 8;
                displayItem6 = 8;
                displayItem7 = 8;
                displayItem8 = 8;
            }
            else if (entryNumberCount == 9){
                displayItem1 = 9;
                displayItem2 = 9;
                displayItem3 = 9;
                displayItem4 = 9;
                displayItem5 = 9;
                displayItem6 = 9;
                displayItem7 = 9;
                displayItem8 = 9;
                displayItem9 = 9;
            }
            else if (entryNumberCount == 10){
                displayItem1 = 10;
                displayItem2 = 10;
                displayItem3 = 10;
                displayItem4 = 10;
                displayItem5 = 10;
                displayItem6 = 10;
                displayItem7 = 10;
                displayItem8 = 10;
                displayItem9 = 10;
                displayItem10 = 10;
            }
            else if (entryNumberCount == 11){
                displayItem1 = 11;
                displayItem2 = 11;
                displayItem3 = 11;
                displayItem4 = 11;
                displayItem5 = 11;
                displayItem6 = 11;
                displayItem7 = 11;
                displayItem8 = 11;
                displayItem9 = 11;
                displayItem10 = 11;
                displayItem11 = 11;
            }
            else if (entryNumberCount == 12){
                displayItem1 = 12;
                displayItem2 = 12;
                displayItem3 = 12;
                displayItem4 = 12;
                displayItem5 = 12;
                displayItem6 = 12;
                displayItem7 = 12;
                displayItem8 = 12;
                displayItem9 = 12;
                displayItem10 = 12;
                displayItem11 = 12;
                displayItem12 = 12;
            }
        }
        else{
            
            if (rangeSt1 > 0 && rangeSt2 == 0){
                displayItem1 = 1;
            }
            else if (rangeSt2 > 0 && rangeSt3 == 0){
                displayItem1 = 2;
                displayItem2 = 2;
            }
            else if (rangeSt3 > 0 && rangeSt4 == 0){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
            }
            else if (rangeSt4 > 0){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
        }
        
        int displayFlag = 0;
        int xStart = 0;
        int yStart = 0;
        int lengthDivisionInt = 0;
        int numberOfDivision = 0;
        int lengthDivisionInt2 = 0;
        int numberOfDivision2 = 0;
        int lowestXPosition = 1000;
        int xDimension = 0;
        int yDimension = 0;
        int fontSize = 0;
        int horizontalLabelShift = 0;
        int horizontalNumberShift = 0;
        int verticalDisplayOn = 0;
        int endTime = 0;
        int averageDivTimeCount = 0;
        int rangeFlag = 0;
        int rangeStartProcess = 0;
        int rangeEndProcess = 0;
        
        double horizontalTime = 0;
        double lengthDivision = 0;
        double lengthPix = 0;
        double sift = 0;
        double lengthDivision2 = 0;
        double lengthPix2 = 0;
        double xPositionDr = 0;
        double yPositionDrStart = 0;
        double yPositionDrEnd = 0;
        double horizontalTimeHr = 0;
        double averageDivTime = 0;
        
        string treatNameGR;
        string timeString;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint pointA2;
        
        CGFloat size2 = 0;
        
        for (int counter1 = 0; counter1 < displayItem1; counter1++){
            displayFlag = 0;
            horizontalLabelShift = 25;
            horizontalNumberShift = 20;
            verticalDisplayOn = 0;
            
            if (counter1 == 0 && displayItem1 == 1){
                displayFlag = 1;
                xStart = 250;
                yStart = 200;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 40;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 0 && displayItem1 == 2){
                displayFlag = 1;
                xStart = 80;
                yStart = 200;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 40;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 1 && displayItem2 == 2){
                displayFlag = 1;
                xStart = 390;
                yStart = 200;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 40;
                
                if (rangeSt2 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt2;
                    rangeEndProcess = rangeEd2;
                }
            }
            else if (counter1 == 0 && displayItem1 == 3){
                displayFlag = 1;
                xStart = 80;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 1 && displayItem2 == 3){
                displayFlag = 1;
                xStart = 390;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 35;
                
                if (rangeSt2 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt2;
                    rangeEndProcess = rangeEd2;
                }
            }
            else if (counter1 == 2 && displayItem3 == 3){
                displayFlag = 1;
                xStart = 80;
                yStart = 70;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt3 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt3;
                    rangeEndProcess = rangeEd3;
                }
            }
            else if (counter1 == 0 && displayItem1 == 4){
                displayFlag = 1;
                xStart = 80;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 1 && displayItem2 == 4){
                displayFlag = 1;
                xStart = 390;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                
                if (rangeSt2 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt2;
                    rangeEndProcess = rangeEd2;
                }
            }
            else if (counter1 == 2 && displayItem3 == 4){
                displayFlag = 1;
                xStart = 80;
                yStart = 70;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt3 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt3;
                    rangeEndProcess = rangeEd3;
                }
            }
            else if (counter1 == 3 && displayItem4 == 4){
                displayFlag = 1;
                xStart = 390;
                yStart = 70;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                
                if (rangeSt4 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt4;
                    rangeEndProcess = rangeEd4;
                }
            }
            else if (counter1 == 0 && displayItem1 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 5){
                displayFlag = 1;
                xStart = 290;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 5){
                displayFlag = 1;
                xStart = 520;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 5){
                displayFlag = 1;
                xStart = 290;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 6){
                displayFlag = 1;
                xStart = 290;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 6){
                displayFlag = 1;
                xStart = 520;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 6){
                displayFlag = 1;
                xStart = 290;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 5 && displayItem6 == 6){
                displayFlag = 1;
                xStart = 520;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 7){
                displayFlag = 1;
                xStart = 290;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 2 && displayItem3 == 7){
                displayFlag = 1;
                xStart = 520;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 3 && displayItem4 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 7){
                displayFlag = 1;
                xStart = 290;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 5 && displayItem6 == 7){
                displayFlag = 1;
                xStart = 520;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 6 && displayItem7 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 0 && displayItem1 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 8){
                displayFlag = 1;
                xStart = 290;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 2 && displayItem3 == 8){
                displayFlag = 1;
                xStart = 520;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 3 && displayItem4 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 8){
                displayFlag = 1;
                xStart = 290;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 5 && displayItem6 == 8){
                displayFlag = 1;
                xStart = 520;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 6 && displayItem7 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 8){
                displayFlag = 1;
                xStart = 290;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 0 && displayItem1 == 9){
                displayFlag = 1;
                xStart = 60;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 9){
                displayFlag = 1;
                xStart = 290;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 2 && displayItem3 == 9){
                displayFlag = 1;
                xStart = 520;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 3 && displayItem4 == 9){
                displayFlag = 1;
                xStart = 60;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 9){
                displayFlag = 1;
                xStart = 290;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 5 && displayItem6 == 9){
                displayFlag = 1;
                xStart = 520;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 6 && displayItem7 == 9){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 9){
                displayFlag = 1;
                xStart = 290;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 8 && displayItem9 == 9){
                displayFlag = 1;
                xStart = 520;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 0 && displayItem1 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 10){
                displayFlag = 1;
                xStart = 290;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 10){
                displayFlag = 1;
                xStart = 520;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 10){
                displayFlag = 1;
                xStart = 290;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 10){
                displayFlag = 1;
                xStart = 520;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 10){
                displayFlag = 1;
                xStart = 290;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 8 && displayItem9 == 10){
                displayFlag = 1;
                xStart = 520;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 9 && displayItem10 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 0 && displayItem1 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 11){
                displayFlag = 1;
                xStart = 520;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 11){
                displayFlag = 1;
                xStart = 520;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 8 && displayItem9 == 11){
                displayFlag = 1;
                xStart = 520;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 9 && displayItem10 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 10 && displayItem11 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 0 && displayItem1 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 8 && displayItem9 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 9 && displayItem10 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 10 && displayItem11 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 11 && displayItem12 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            
            if (displayFlag == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart, yStart, xDimension, yDimension)];
                [path stroke];
                
                //----Horizontal Label----
                if (horizontalScaleHighDoublingTimeHold < horizontalScaleLowDoublingTimeHold+100) horizontalScaleHighDoublingTimeHold = horizontalScaleMaxDoublingTimeHold;
                
                horizontalTime = horizontalScaleHighDoublingTimeHold-horizontalScaleLowDoublingTimeHold;
                timeString = "Doubling Time (hr)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:fontSize];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = xStart+(xDimension/2)-size2/(double)2;
                pointA.y = yStart-horizontalLabelShift-2;
                [attrStrA drawAtPoint:pointA];
                
                horizontalTimeHr = horizontalTime/(double)60;
                
                //----Horizontal Scale----
                lengthDivision = horizontalTimeHr/(double)5;
                lengthDivisionInt = 0;
                
                if (lengthDivision <= 25) lengthDivisionInt = 25;
                else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
                else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
                else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
                else if (lengthDivision > 5000) lengthDivisionInt = 1000;
                
                lengthPix = ((xDimension-10)/(double)horizontalTimeHr)*lengthDivisionInt;
                numberOfDivision = (int)((xDimension-10)/(double)lengthPix)+1;
                
                sift = 0;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = xStart+lengthPix*counter2;
                    positionAA.y = yStart;
                    positionBB.x = xStart+lengthPix*counter2;
                    positionBB.y = yStart+5;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+(int)(horizontalScaleLowDoublingTimeHold/(double)60)).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (xStart+lengthPix*counter2)-size2/(double)2-sift;
                    pointA2.y = yStart-horizontalNumberShift;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                treatNameGR = arrayTableMain [entryNumberTempHold [counter1]][0]+": "+arrayTableMain [entryNumberTempHold [counter1]][4].substr(arrayTableMain [entryNumberTempHold [counter1]][4].find("-")+1);
                
                if ((int) treatNameGR.length() > 17){
                    treatNameGR = treatNameGR.substr(0, 16)+"..";
                }
                
                if (rangeFlag == 1){
                    treatNameGR = treatNameGR+", TP: "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess);
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA];
                pointA2.x = xStart+4;
                pointA2.y = yStart+yDimension-14;
                [attrStrA drawAtPoint:pointA2];
                
                //----Vertical Scale Upper----
                lengthDivision2 = verticalScaleHighDoublingHold/(double)5;
                lengthDivisionInt2 = 0;
                
                if (lengthDivision2 <= 10) lengthDivisionInt2 = 10;
                else if (lengthDivision2 > 10 && lengthDivision2 <= 25) lengthDivisionInt2 = 25;
                else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                
                lengthPix2 = (yDimension/(double)verticalScaleHighDoublingHold)*lengthDivisionInt2;
                numberOfDivision2 = (int)(yDimension/(double)lengthPix2)+1;
                lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    if (yStart+lengthPix2*counter2 <= yStart+yDimension){
                        positionAA.x = xStart;
                        positionAA.y = yStart+lengthPix2*counter2;
                        positionBB.x = xStart+5;
                        positionBB.y = yStart+lengthPix2*counter2;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (verticalDisplayOn == 1){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2).c_str());
                            
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart-size2-10;
                            pointA2.y = yStart+lengthPix2*counter2-5;
                            [attrStrA2 drawAtPoint:pointA2];
                            
                            if (lowestXPosition > xStart-size2-10) lowestXPosition = (int)(xStart-size2-10);
                        }
                    }
                }
                
                if (verticalDisplayOn == 1){
                    //----Vertical Label----
                    NSString *verticalNSstring = @"Number of Events";
                    
                    NSFont *font2 = [NSFont boldSystemFontOfSize:fontSize];
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    NSGraphicsContext *context = [NSGraphicsContext currentContext];
                    NSAffineTransform *transform = [NSAffineTransform transform];
                    [transform rotateByDegrees:+90];
                    
                    [context saveGraphicsState];
                    [transform concat];
                    
                    NSAttributedString *attrStrB;
                    NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                    NSString *titleStringB = @"Number of Events";
                    
                    [attributesB setObject:[NSFont boldSystemFontOfSize:fontSize] forKey:NSFontAttributeName];
                    [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                    
                    pointA.x = yStart+((yDimension/2)-size2/(double)2);
                    pointA.y = (lowestXPosition-5)*-1;
                    [attrStrB drawAtPoint:pointA];
                    
                    [context restoreGraphicsState];
                }
                
                [NSBezierPath setDefaultLineWidth:1.0];
                
                int *cellNumberHold = new int [horizontalScaleMaxDoublingTimeHold+50];
                
                for (int counter3 = 0; counter3 < horizontalScaleMaxDoublingTimeHold+50; counter3++){
                    cellNumberHold [counter3] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter3++){
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 31 || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 41 || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 51){
                        endTime = 0;
                        
                        if (rangeFlag == 0){
                            for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter4++){
                                if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6] && (arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 32 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 42 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 52)){
                                    endTime = arrayLineageData [entryNumberTempHold [counter1]][counter4*9+2];
                                }
                                else if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6]){
                                    break;
                                }
                            }
                        }
                        else{
                            
                            for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter4++){
                                if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6] && (arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 32 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 42 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 52) && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2] >= rangeStartProcess && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2] <= rangeEndProcess){
                                    endTime = arrayLineageData [entryNumberTempHold [counter1]][counter4*9+2];
                                }
                                else if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6]){
                                    break;
                                }
                            }
                        }
                        
                        if (endTime != 0){
                            cellNumberHold [(endTime-arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2])*atoi(arrayLineageDataType [entryNumberTempHold [counter1]][5].c_str())]++;
                        }
                    }
                }
                
                averageDivTime = 0;
                averageDivTimeCount = 0;
                
                for (int counter2 = 0; counter2 <= horizontalScaleMaxDoublingTimeHold; counter2++){
                    [[NSColor blueColor] set];
                    
                    if (counter2-horizontalScaleLowDoublingTimeHold > xStart && counter2-horizontalScaleLowDoublingTimeHold <= horizontalScaleMaxDoublingTimeHold){
                        xPositionDr = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDoublingTimeHold);
                        yPositionDrStart = yStart;
                        yPositionDrEnd = yStart+(yDimension/(double)verticalScaleHighDoublingHold)*(cellNumberHold[counter2]);
                        
                        if (xPositionDr > xStart && xPositionDr < xStart+xDimension){
                            positionAA.x = xPositionDr;
                            positionAA.y = yPositionDrStart;
                            positionBB.x = xPositionDr;
                            
                            if (yPositionDrEnd <= yStart+yDimension){
                                positionBB.y = yPositionDrEnd;
                            }
                            else positionBB.y = yStart+yDimension;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        
                        if (cellNumberHold[counter2] != 0){
                            averageDivTimeCount = averageDivTimeCount+cellNumberHold[counter2];
                            averageDivTime = averageDivTime+cellNumberHold[counter2]*counter2;
                        }
                    }
                }
                
                if (averageDivTimeCount != 0) averageDivTime = (averageDivTime/(double)averageDivTimeCount)/(double)60;
                else averageDivTime = 0;
                
                int averageDivTimeInt = (int)(averageDivTime*100);
                averageDivTime = averageDivTimeInt/(double)100;
                
                stringstream extension1;
                extension1 << averageDivTime;
                string averageDivTimeString = extension1.str();
                
                treatNameGR = "DT.: "+averageDivTimeString;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA];
                pointA2.x = xStart+xDimension-65;
                pointA2.y = yStart+yDimension-14;
                [attrStrA drawAtPoint:pointA2];
                
                delete [] cellNumberHold;
            }
        }
        
        delete [] entryNumberTempHold;
    }
    else{
        
        int magFactor = 4;
        
        NSBitmapImageRep *bitmapReps;
        bitmapReps = [[NSBitmapImageRep alloc] initWithBitmapDataPlanes:NULL pixelsWide:767*magFactor pixelsHigh:591*magFactor bitsPerSample:8 samplesPerPixel:3 hasAlpha:NO isPlanar:NO colorSpaceName:NSDeviceRGBColorSpace bytesPerRow:767*magFactor*4 bitsPerPixel:32];
        
        [NSGraphicsContext saveGraphicsState];
        [NSGraphicsContext setCurrentContext:[NSGraphicsContext graphicsContextWithBitmapImageRep:bitmapReps]];
        
        [[NSColor whiteColor] set];
        
        NSBezierPath *path;
        path = [NSBezierPath bezierPathWithRect: NSMakeRect(0, 0, 767*magFactor, 591*magFactor)];
        [path fill];
        
        //----Re-load----
        [NSBezierPath setDefaultLineWidth:1*magFactor];
        
        NSPoint pointA;
        NSAttributedString *attrStrA;
        NSMutableDictionary *attributesA = [NSMutableDictionary dictionary];
        
        int entryNumberCount = 0;
        int maxEntry = 0;
        
        int *entryNumberTempHold = new int [40];
        int entryNumberTempHoldCount = 0;
        
        int rangeSt1 = 0;
        int rangeEd1 = 0;
        
        int rangeSt2 = 0;
        int rangeEd2 = 0;
        
        int rangeSt3 = 0;
        int rangeEd3 = 0;
        
        int rangeSt4 = 0;
        int rangeEd4 = 0;
        
        if (rangeDoubleSt1 > 0 && rangeDoubleEd1 > 0 && rangeDoubleSt1+10 < rangeDoubleEd1){
            rangeSt1 = rangeDoubleSt1;
            rangeEd1 = rangeDoubleEd1;
        }
        
        if (rangeDoubleSt2 > 0 && rangeDoubleEd2 > 0 && rangeDoubleSt2+10 < rangeDoubleEd2){
            rangeSt2 = rangeDoubleSt2;
            rangeEd2 = rangeDoubleEd2;
        }
        
        if (rangeDoubleSt3 > 0 && rangeDoubleEd3 > 0 && rangeDoubleSt3+10 < rangeDoubleEd3){
            rangeSt3 = rangeDoubleSt3;
            rangeEd3 = rangeDoubleEd3;
        }
        
        if (rangeDoubleSt4 > 0 && rangeDoubleEd4 > 0 && rangeDoubleSt4+10 < rangeDoubleEd4){
            rangeSt4 = rangeDoubleSt4;
            rangeEd4 = rangeDoubleEd4;
        }
        
        if (rangeSt1 == 0){
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 12){
                    entryNumberCount++;
                    entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    
                    maxEntry++;
                }
            }
        }
        else{
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1 && maxEntry < 1){
                    if (rangeSt1 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    if (rangeSt2 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    if (rangeSt3 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    if (rangeSt4 != 0){
                        entryNumberCount++;
                        entryNumberTempHold [entryNumberTempHoldCount] = counter2, entryNumberTempHoldCount++;
                    }
                    
                    maxEntry++;
                }
            }
        }
        
        int displayItem1 = 0;
        int displayItem2 = 0;
        int displayItem3 = 0;
        int displayItem4 = 0;
        int displayItem5 = 0;
        int displayItem6 = 0;
        int displayItem7 = 0;
        int displayItem8 = 0;
        int displayItem9 = 0;
        int displayItem10 = 0;
        int displayItem11 = 0;
        int displayItem12 = 0;
        
        if (rangeSt1 == 0){
            if (entryNumberCount == 1) displayItem1 = 1;
            else if (entryNumberCount == 2){
                displayItem1 = 2;
                displayItem2 = 2;
            }
            else if (entryNumberCount == 3){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
            }
            else if (entryNumberCount == 4){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
            else if (entryNumberCount == 5){
                displayItem1 = 5;
                displayItem2 = 5;
                displayItem3 = 5;
                displayItem4 = 5;
                displayItem5 = 5;
            }
            else if (entryNumberCount == 6){
                displayItem1 = 6;
                displayItem2 = 6;
                displayItem3 = 6;
                displayItem4 = 6;
                displayItem5 = 6;
                displayItem6 = 6;
            }
            else if (entryNumberCount == 7){
                displayItem1 = 7;
                displayItem2 = 7;
                displayItem3 = 7;
                displayItem4 = 7;
                displayItem5 = 7;
                displayItem6 = 7;
                displayItem7 = 7;
            }
            else if (entryNumberCount == 8){
                displayItem1 = 8;
                displayItem2 = 8;
                displayItem3 = 8;
                displayItem4 = 8;
                displayItem5 = 8;
                displayItem6 = 8;
                displayItem7 = 8;
                displayItem8 = 8;
            }
            else if (entryNumberCount == 9){
                displayItem1 = 9;
                displayItem2 = 9;
                displayItem3 = 9;
                displayItem4 = 9;
                displayItem5 = 9;
                displayItem6 = 9;
                displayItem7 = 9;
                displayItem8 = 9;
                displayItem9 = 9;
            }
            else if (entryNumberCount == 10){
                displayItem1 = 10;
                displayItem2 = 10;
                displayItem3 = 10;
                displayItem4 = 10;
                displayItem5 = 10;
                displayItem6 = 10;
                displayItem7 = 10;
                displayItem8 = 10;
                displayItem9 = 10;
                displayItem10 = 10;
            }
            else if (entryNumberCount == 11){
                displayItem1 = 11;
                displayItem2 = 11;
                displayItem3 = 11;
                displayItem4 = 11;
                displayItem5 = 11;
                displayItem6 = 11;
                displayItem7 = 11;
                displayItem8 = 11;
                displayItem9 = 11;
                displayItem10 = 11;
                displayItem11 = 11;
            }
            else if (entryNumberCount == 12){
                displayItem1 = 12;
                displayItem2 = 12;
                displayItem3 = 12;
                displayItem4 = 12;
                displayItem5 = 12;
                displayItem6 = 12;
                displayItem7 = 12;
                displayItem8 = 12;
                displayItem9 = 12;
                displayItem10 = 12;
                displayItem11 = 12;
                displayItem12 = 12;
            }
        }
        else{
            
            if (rangeSt1 > 0 && rangeSt2 == 0){
                displayItem1 = 1;
            }
            else if (rangeSt2 > 0 && rangeSt3 == 0){
                displayItem1 = 2;
                displayItem2 = 2;
            }
            else if (rangeSt3 > 0 && rangeSt4 == 0){
                displayItem1 = 3;
                displayItem2 = 3;
                displayItem3 = 3;
            }
            else if (rangeSt4 > 0){
                displayItem1 = 4;
                displayItem2 = 4;
                displayItem3 = 4;
                displayItem4 = 4;
            }
        }
        
        int displayFlag = 0;
        int xStart = 0;
        int yStart = 0;
        int lengthDivisionInt = 0;
        int numberOfDivision = 0;
        int lengthDivisionInt2 = 0;
        int numberOfDivision2 = 0;
        int lowestXPosition = 1000;
        int xDimension = 0;
        int yDimension = 0;
        int fontSize = 0;
        int horizontalLabelShift = 0;
        int horizontalNumberShift = 0;
        int verticalDisplayOn = 0;
        int endTime = 0;
        int averageDivTimeCount = 0;
        int rangeFlag = 0;
        int rangeStartProcess = 0;
        int rangeEndProcess = 0;
        
        double horizontalTime = 0;
        double lengthDivision = 0;
        double lengthPix = 0;
        double sift = 0;
        double lengthDivision2 = 0;
        double lengthPix2 = 0;
        double xPositionDr = 0;
        double yPositionDrStart = 0;
        double yPositionDrEnd = 0;
        double horizontalTimeHr = 0;
        double averageDivTime = 0;
        
        string treatNameGR;
        string timeString;
        
        NSPoint positionAA;
        NSPoint positionBB;
        NSPoint pointA2;
        
        CGFloat size2 = 0;
        
        for (int counter1 = 0; counter1 < displayItem1; counter1++){
            displayFlag = 0;
            horizontalLabelShift = 25;
            horizontalNumberShift = 20;
            verticalDisplayOn = 0;
            
            if (counter1 == 0 && displayItem1 == 1){
                displayFlag = 1;
                xStart = 250;
                yStart = 200;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 40;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 0 && displayItem1 == 2){
                displayFlag = 1;
                xStart = 80;
                yStart = 200;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 40;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 1 && displayItem2 == 2){
                displayFlag = 1;
                xStart = 390;
                yStart = 200;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 40;
                
                if (rangeSt2 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt2;
                    rangeEndProcess = rangeEd2;
                }
            }
            else if (counter1 == 0 && displayItem1 == 3){
                displayFlag = 1;
                xStart = 80;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 1 && displayItem2 == 3){
                displayFlag = 1;
                xStart = 390;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 35;
                
                if (rangeSt2 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt2;
                    rangeEndProcess = rangeEd2;
                }
            }
            else if (counter1 == 2 && displayItem3 == 3){
                displayFlag = 1;
                xStart = 80;
                yStart = 70;
                xDimension = 300;
                yDimension = 200;
                fontSize = 12;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt3 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt3;
                    rangeEndProcess = rangeEd3;
                }
            }
            else if (counter1 == 0 && displayItem1 == 4){
                displayFlag = 1;
                xStart = 80;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt1 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt1;
                    rangeEndProcess = rangeEd1;
                }
            }
            else if (counter1 == 1 && displayItem2 == 4){
                displayFlag = 1;
                xStart = 390;
                yStart = 330;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                
                if (rangeSt2 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt2;
                    rangeEndProcess = rangeEd2;
                }
            }
            else if (counter1 == 2 && displayItem3 == 4){
                displayFlag = 1;
                xStart = 80;
                yStart = 70;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
                
                if (rangeSt3 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt3;
                    rangeEndProcess = rangeEd3;
                }
            }
            else if (counter1 == 3 && displayItem4 == 4){
                displayFlag = 1;
                xStart = 390;
                yStart = 70;
                xDimension = 300;
                yDimension = 200;
                fontSize = 11;
                horizontalLabelShift = 35;
                
                if (rangeSt4 > 0){
                    rangeFlag = 1;
                    rangeStartProcess = rangeSt4;
                    rangeEndProcess = rangeEd4;
                }
            }
            else if (counter1 == 0 && displayItem1 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 5){
                displayFlag = 1;
                xStart = 290;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 5){
                displayFlag = 1;
                xStart = 520;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 5){
                displayFlag = 1;
                xStart = 60;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 5){
                displayFlag = 1;
                xStart = 290;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 6){
                displayFlag = 1;
                xStart = 290;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 2 && displayItem3 == 6){
                displayFlag = 1;
                xStart = 520;
                yStart = 330;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 3 && displayItem4 == 6){
                displayFlag = 1;
                xStart = 60;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 6){
                displayFlag = 1;
                xStart = 290;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 5 && displayItem6 == 6){
                displayFlag = 1;
                xStart = 520;
                yStart = 110;
                xDimension = 220;
                yDimension = 160;
                fontSize = 11;
                horizontalLabelShift = 35;
            }
            else if (counter1 == 0 && displayItem1 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 7){
                displayFlag = 1;
                xStart = 290;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 2 && displayItem3 == 7){
                displayFlag = 1;
                xStart = 520;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 3 && displayItem4 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 7){
                displayFlag = 1;
                xStart = 290;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 5 && displayItem6 == 7){
                displayFlag = 1;
                xStart = 520;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 6 && displayItem7 == 7){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 0 && displayItem1 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 8){
                displayFlag = 1;
                xStart = 290;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 2 && displayItem3 == 8){
                displayFlag = 1;
                xStart = 520;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 3 && displayItem4 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 8){
                displayFlag = 1;
                xStart = 290;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 5 && displayItem6 == 8){
                displayFlag = 1;
                xStart = 520;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 6 && displayItem7 == 8){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 8){
                displayFlag = 1;
                xStart = 290;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 11;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 0 && displayItem1 == 9){
                displayFlag = 1;
                xStart = 60;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 9){
                displayFlag = 1;
                xStart = 290;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 2 && displayItem3 == 9){
                displayFlag = 1;
                xStart = 520;
                yStart = 410;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 3 && displayItem4 == 9){
                displayFlag = 1;
                xStart = 60;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 9){
                displayFlag = 1;
                xStart = 290;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 5 && displayItem6 == 9){
                displayFlag = 1;
                xStart = 520;
                yStart = 220;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 6 && displayItem7 == 9){
                displayFlag = 1;
                xStart = 60;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 9){
                displayFlag = 1;
                xStart = 290;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 8 && displayItem9 == 9){
                displayFlag = 1;
                xStart = 520;
                yStart = 40;
                xDimension = 220;
                yDimension = 140;
                fontSize = 10;
                horizontalLabelShift = 27;
                horizontalNumberShift = 15;
            }
            else if (counter1 == 0 && displayItem1 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 10){
                displayFlag = 1;
                xStart = 290;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 10){
                displayFlag = 1;
                xStart = 520;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 10){
                displayFlag = 1;
                xStart = 290;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 10){
                displayFlag = 1;
                xStart = 520;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 10){
                displayFlag = 1;
                xStart = 290;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 8 && displayItem9 == 10){
                displayFlag = 1;
                xStart = 520;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 9 && displayItem10 == 10){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 0 && displayItem1 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 11){
                displayFlag = 1;
                xStart = 520;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 11){
                displayFlag = 1;
                xStart = 520;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 8 && displayItem9 == 11){
                displayFlag = 1;
                xStart = 520;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 9 && displayItem10 == 11){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 10 && displayItem11 == 11){
                displayFlag = 1;
                xStart = 290;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 0 && displayItem1 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 1 && displayItem2 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 2 && displayItem3 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 451;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 3 && displayItem4 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 4 && displayItem5 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 5 && displayItem6 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 309;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 6 && displayItem7 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 7 && displayItem8 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 8 && displayItem9 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 167;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 9 && displayItem10 == 12){
                displayFlag = 1;
                xStart = 60;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
                verticalDisplayOn = 1;
            }
            else if (counter1 == 10 && displayItem11 == 12){
                displayFlag = 1;
                xStart = 290;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            else if (counter1 == 11 && displayItem12 == 12){
                displayFlag = 1;
                xStart = 520;
                yStart = 25;
                xDimension = 220;
                yDimension = 117;
                fontSize = 10;
                horizontalLabelShift = 20;
                horizontalNumberShift = 12;
            }
            
            if (displayFlag == 1){
                [[NSColor blackColor] set];
                [NSBezierPath setDefaultLineWidth:1.5*magFactor];
                
                path = [NSBezierPath bezierPathWithRect: NSMakeRect(xStart*magFactor, yStart*magFactor, xDimension*magFactor, yDimension*magFactor)];
                [path stroke];
                
                //----Horizontal Label----
                if (horizontalScaleHighDoublingTimeHold < horizontalScaleLowDoublingTimeHold+100) horizontalScaleHighDoublingTimeHold = horizontalScaleMaxDoublingTimeHold;
                
                horizontalTime = horizontalScaleHighDoublingTimeHold-horizontalScaleLowDoublingTimeHold;
                timeString = "Doubling Time (hr)";
                
                NSString *timeNSstring = @(timeString.c_str());
                
                NSFont *font = [NSFont boldSystemFontOfSize:fontSize*magFactor];
                NSDictionary *attributes = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                NSAttributedString *attrStrS = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributes];
                size2 = [attrStrS size].width;
                
                [attributesA setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                [attributesA setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                
                attrStrA = [[NSAttributedString alloc] initWithString:timeNSstring attributes:attributesA];
                pointA.x = xStart*magFactor+((xDimension*magFactor)/2)-size2/(double)2;
                pointA.y = yStart*magFactor-horizontalLabelShift*magFactor-2*magFactor;
                [attrStrA drawAtPoint:pointA];
                
                horizontalTimeHr = horizontalTime/(double)60;
                
                //----Horizontal Scale----
                lengthDivision = horizontalTimeHr/(double)5;
                lengthDivisionInt = 0;
                
                if (lengthDivision <= 25) lengthDivisionInt = 25;
                else if (lengthDivision > 25 && lengthDivision <= 50) lengthDivisionInt = 50;
                else if (lengthDivision > 50 && lengthDivision <= 100) lengthDivisionInt = 100;
                else if (lengthDivision > 100 && lengthDivision <= 150) lengthDivisionInt = 100;
                else if (lengthDivision > 150 && lengthDivision <= 200) lengthDivisionInt = 200;
                else if (lengthDivision > 200 && lengthDivision <= 250) lengthDivisionInt = 200;
                else if (lengthDivision > 250 && lengthDivision <= 300) lengthDivisionInt = 300;
                else if (lengthDivision > 300 && lengthDivision <= 350) lengthDivisionInt = 300;
                else if (lengthDivision > 350 && lengthDivision <= 400) lengthDivisionInt = 300;
                else if (lengthDivision > 400 && lengthDivision <= 450) lengthDivisionInt = 400;
                else if (lengthDivision > 450 && lengthDivision <= 500) lengthDivisionInt = 400;
                else if (lengthDivision > 500 && lengthDivision <= 1000) lengthDivisionInt = 500;
                else if (lengthDivision > 1000 && lengthDivision <= 5000) lengthDivisionInt = 1000;
                else if (lengthDivision > 5000) lengthDivisionInt = 1000;
                
                lengthPix = ((xDimension-10)/(double)horizontalTimeHr)*lengthDivisionInt;
                numberOfDivision = (int)((xDimension-10)/(double)lengthPix)+1;
                
                sift = 0;
                
                for (int counter2 = 0; counter2 < numberOfDivision; counter2++){
                    positionAA.x = xStart*magFactor+lengthPix*counter2*magFactor;
                    positionAA.y = yStart*magFactor;
                    positionBB.x = xStart*magFactor+lengthPix*counter2*magFactor;
                    positionBB.y = yStart*magFactor+5*magFactor;
                    [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                    
                    NSString *timeNSstring2 = @(to_string(counter2*lengthDivisionInt+(int)(horizontalScaleLowDoublingTimeHold/(double)60)).c_str());
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    if (counter2*lengthDivision == 0) sift = 0;
                    else if (counter2*lengthDivision < 1000) sift = 1;
                    
                    NSAttributedString *attrStrA2;
                    NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                    
                    [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    
                    attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring2 attributes:attributesA];
                    pointA2.x = (xStart*magFactor+lengthPix*counter2*magFactor)-size2/(double)2-sift*magFactor;
                    pointA2.y = yStart*magFactor-horizontalNumberShift*magFactor;
                    [attrStrA2 drawAtPoint:pointA2];
                }
                
                treatNameGR = arrayTableMain [entryNumberTempHold [counter1]][0]+": "+arrayTableMain [entryNumberTempHold [counter1]][4].substr(arrayTableMain [entryNumberTempHold [counter1]][4].find("-")+1);
                
                if ((int) treatNameGR.length() > 17){
                    treatNameGR = treatNameGR.substr(0, 16)+"..";
                }
                
                if (rangeFlag == 1){
                    treatNameGR = treatNameGR+", TP: "+to_string(rangeStartProcess)+"-"+to_string(rangeEndProcess);
                }
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA];
                pointA2.x = xStart*magFactor+4*magFactor;
                pointA2.y = yStart*magFactor+yDimension*magFactor-14*magFactor;
                [attrStrA drawAtPoint:pointA2];
                
                //----Vertical Scale Upper----
                lengthDivision2 = verticalScaleHighDoublingHold/(double)5;
                lengthDivisionInt2 = 0;
                
                if (lengthDivision2 <= 10) lengthDivisionInt2 = 10;
                else if (lengthDivision2 > 10 && lengthDivision2 <= 25) lengthDivisionInt2 = 25;
                else if (lengthDivision2 > 25 && lengthDivision2 <= 50) lengthDivisionInt2 = 50;
                else if (lengthDivision2 > 50 && lengthDivision2 <= 100) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 100 && lengthDivision2 <= 150) lengthDivisionInt2 = 100;
                else if (lengthDivision2 > 150 && lengthDivision2 <= 200) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 200 && lengthDivision2 <= 250) lengthDivisionInt2 = 200;
                else if (lengthDivision2 > 250 && lengthDivision2 <= 300) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 300 && lengthDivision2 <= 350) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 350 && lengthDivision2 <= 400) lengthDivisionInt2 = 300;
                else if (lengthDivision2 > 400 && lengthDivision2 <= 450) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 450 && lengthDivision2 <= 500) lengthDivisionInt2 = 400;
                else if (lengthDivision2 > 500 && lengthDivision2 <= 1000) lengthDivisionInt2 = 500;
                else if (lengthDivision2 > 1000 && lengthDivision2 <= 5000) lengthDivisionInt2 = 1000;
                else if (lengthDivision2 > 5000) lengthDivisionInt2 = 1000;
                
                lengthPix2 = (yDimension/(double)verticalScaleHighDoublingHold)*lengthDivisionInt2;
                numberOfDivision2 = (int)(yDimension/(double)lengthPix2)+1;
                lowestXPosition = 1000;
                
                for (int counter2 = 0; counter2 < numberOfDivision2; counter2++){
                    if (yStart+lengthPix2*counter2 <= yStart+yDimension){
                        positionAA.x = xStart*magFactor;
                        positionAA.y = yStart*magFactor+lengthPix2*counter2*magFactor;
                        positionBB.x = xStart*magFactor+5*magFactor;
                        positionBB.y = yStart*magFactor+lengthPix2*counter2*magFactor;
                        [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        
                        if (verticalDisplayOn == 1){
                            NSString *timeNSstring3 = @(to_string(counter2*lengthDivisionInt2).c_str());
                            
                            NSDictionary *attributes3 = [NSDictionary dictionaryWithObjectsAndKeys:font, NSFontAttributeName, nil];
                            NSAttributedString *attrStrS3 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributes3];
                            size2 = [attrStrS3 size].width;
                            
                            NSAttributedString *attrStrA2;
                            NSMutableDictionary *attributesA2 = [NSMutableDictionary dictionary];
                            
                            [attributesA2 setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                            [attributesA2 setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                            
                            attrStrA2 = [[NSAttributedString alloc] initWithString:timeNSstring3 attributes:attributesA];
                            pointA2.x = xStart*magFactor-size2-10*magFactor;
                            pointA2.y = yStart*magFactor+lengthPix2*counter2*magFactor-5*magFactor;
                            [attrStrA2 drawAtPoint:pointA2];
                            
                            if (lowestXPosition > xStart*magFactor-size2-10*magFactor) lowestXPosition = (int)(xStart*magFactor-size2-10*magFactor);
                        }
                    }
                }
                
                if (verticalDisplayOn == 1){
                    //----Vertical Label----
                    NSString *verticalNSstring = @"Number of Events";
                    
                    NSFont *font2 = [NSFont boldSystemFontOfSize:fontSize*magFactor];
                    NSDictionary *attributes2 = [NSDictionary dictionaryWithObjectsAndKeys:font2, NSFontAttributeName, nil];
                    NSAttributedString *attrStrS2 = [[NSAttributedString alloc] initWithString:verticalNSstring attributes:attributes2];
                    size2 = [attrStrS2 size].width;
                    
                    NSGraphicsContext *context = [NSGraphicsContext currentContext];
                    NSAffineTransform *transform = [NSAffineTransform transform];
                    [transform rotateByDegrees:+90];
                    
                    [context saveGraphicsState];
                    [transform concat];
                    
                    NSAttributedString *attrStrB;
                    NSMutableDictionary *attributesB = [NSMutableDictionary dictionary];
                    NSString *titleStringB = @"Number of Events";
                    
                    [attributesB setObject:[NSFont boldSystemFontOfSize:fontSize*magFactor] forKey:NSFontAttributeName];
                    [attributesB setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
                    attrStrB = [[NSAttributedString alloc] initWithString:titleStringB attributes:attributesB];
                    
                    pointA.x = yStart*magFactor+(((yDimension*magFactor)/2)-size2/(double)2);
                    pointA.y = (lowestXPosition-5)*-1;
                    [attrStrB drawAtPoint:pointA];
                    
                    [context restoreGraphicsState];
                }
                
                [NSBezierPath setDefaultLineWidth:1.0*magFactor];
                
                int *cellNumberHold = new int [horizontalScaleMaxDoublingTimeHold+50];
                
                for (int counter3 = 0; counter3 < horizontalScaleMaxDoublingTimeHold+50; counter3++){
                    cellNumberHold [counter3] = 0;
                }
                
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter3++){
                    if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 31 || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 41 || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+3] == 51){
                        endTime = 0;
                        
                        if (rangeFlag == 0){
                            for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter4++){
                                if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6] && (arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 32 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 42 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 52)){
                                    endTime = arrayLineageData [entryNumberTempHold [counter1]][counter4*9+2];
                                }
                                else if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6]){
                                    break;
                                }
                            }
                        }
                        else{
                            
                            for (unsigned long counter4 = counter3+1; counter4 < arrayLineageDataEntryHold [entryNumberTempHold [counter1]]/9; counter4++){
                                if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] == arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6] && (arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 32 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 42 || arrayLineageData [entryNumberTempHold [counter1]][counter4*9+3] == 52) && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2] >= rangeStartProcess && arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2] <= rangeEndProcess){
                                    endTime = arrayLineageData [entryNumberTempHold [counter1]][counter4*9+2];
                                }
                                else if (arrayLineageData [entryNumberTempHold [counter1]][counter3*9+5] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+5] || arrayLineageData [entryNumberTempHold [counter1]][counter3*9+6] != arrayLineageData [entryNumberTempHold [counter1]][counter4*9+6]){
                                    break;
                                }
                            }
                        }
                        
                        if (endTime != 0){
                            cellNumberHold [(endTime-arrayLineageData [entryNumberTempHold [counter1]][counter3*9+2])*atoi(arrayLineageDataType [entryNumberTempHold [counter1]][5].c_str())]++;
                        }
                    }
                }
                
                averageDivTime = 0;
                averageDivTimeCount = 0;
                
                for (int counter2 = 0; counter2 <= horizontalScaleMaxDoublingTimeHold; counter2++){
                    [[NSColor blueColor] set];
                    
                    if (counter2-horizontalScaleLowDoublingTimeHold > xStart && counter2-horizontalScaleLowDoublingTimeHold <= horizontalScaleMaxDoublingTimeHold){
                        xPositionDr = xStart+(xDimension/(double)horizontalTime)*(counter2-horizontalScaleLowDoublingTimeHold);
                        yPositionDrStart = yStart;
                        yPositionDrEnd = yStart+(yDimension/(double)verticalScaleHighDoublingHold)*(cellNumberHold[counter2]);
                        
                        if (xPositionDr*magFactor > xStart*magFactor && xPositionDr*magFactor < xStart*magFactor+xDimension*magFactor){
                            positionAA.x = xPositionDr*magFactor;
                            positionAA.y = yPositionDrStart*magFactor;
                            positionBB.x = xPositionDr*magFactor;
                            
                            if (yPositionDrEnd*magFactor <= yStart*magFactor+yDimension*magFactor){
                                positionBB.y = yPositionDrEnd*magFactor;
                            }
                            else positionBB.y = yStart*magFactor+yDimension*magFactor;
                            
                            [NSBezierPath strokeLineFromPoint:positionAA toPoint:positionBB];
                        }
                        
                        if (cellNumberHold[counter2] != 0){
                            averageDivTimeCount = averageDivTimeCount+cellNumberHold[counter2];
                            averageDivTime = averageDivTime+cellNumberHold[counter2]*counter2;
                        }
                    }
                }
                
                if (averageDivTimeCount != 0) averageDivTime = (averageDivTime/(double)averageDivTimeCount)/(double)60;
                else averageDivTime = 0;
                
                int averageDivTimeInt = (int)(averageDivTime*100);
                averageDivTime = averageDivTimeInt/(double)100;
                
                stringstream extension1;
                extension1 << averageDivTime;
                string averageDivTimeString = extension1.str();
                
                treatNameGR = "DT.: "+averageDivTimeString;
                
                attrStrA = [[NSAttributedString alloc] initWithString:@(treatNameGR.c_str()) attributes:attributesA];
                pointA2.x = xStart*magFactor+xDimension*magFactor-65*magFactor;
                pointA2.y = yStart*magFactor+yDimension*magFactor-14*magFactor;
                [attrStrA drawAtPoint:pointA2];
                
                delete [] cellNumberHold;
            }
        }
        
        delete [] entryNumberTempHold;
        
        [NSGraphicsContext restoreGraphicsState];
        
        NSData *imageExportData;
        imageExportData = [bitmapReps TIFFRepresentation];
        
        [imageExportData writeToFile:@(exportResultPath.c_str()) atomically:YES];
        
        exportFlag7 = 2;
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDoublingTimeDisplay object:nil];
}

@end
