//
//  CellGrowthController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/2/16.
//
//

#ifndef CELLGROWTHCONTROLLER_H
#define CELLGROWTHCONTROLLER_H
#import "Controller.h" 
#endif

@interface CellGrowthController : NSObject <NSTextFieldDelegate>{
    int pointConvert; //Point convert
    int minConvert;  //Min convert
    int everyConvert; //Every convert
    int lineagePointSet; //Lineage position set
    int lineagePointRangeSet; //Point range set
    double hrConvert; //HR convert
    
    IBOutlet NSTextField *verticalLow;
    IBOutlet NSTextField *verticalHigh;
    IBOutlet NSTextField *horizontalLow;
    IBOutlet NSTextField *horizontalHigh;
    IBOutlet NSTextField *overlayIndividual;
    IBOutlet NSTextField *usePrev;
    IBOutlet NSTextField *pointConvertDisplay;
    IBOutlet NSTextField *minConvertDisplay;
    IBOutlet NSTextField *hrConvertDisplay;
    IBOutlet NSTextField *everyConvertDisplay;
    IBOutlet NSTextField *lineagePointDisplay;
    IBOutlet NSTextField *lineagePointRangeDisplay;
    
    IBOutlet NSWindow *growthCurveWindow;
    
    NSWindowController *growthCurveWindowController;
    
    NSTimer *growthCurveTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFile2:(id)sender;
-(IBAction)overlayIndividualSet:(id)sender;
-(IBAction)useDisplaySet:(id)sender;
-(IBAction)closeWindow:(id)sender;

@end
