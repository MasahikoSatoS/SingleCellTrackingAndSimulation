//
//  DataUploading.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/5/16.
//
//

#import "DataUploading.h"

NSString *notificationToDataUploading = @"notificationExecuteDataUploading";

@implementation DataUploading

-(id)init{
    self = [super init];
    
    if (self != nil){
        dataType = 1;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToDataUploading object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    analysisLoadWindController = [[NSWindowController alloc] initWithWindowNibName:@"DataLoad"];
    [analysisLoadWindController showWindow:self];
    analysisImageNameSelect = "";
    analysisIDSelect = "";
    dataType = 1;
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [analysisLoad frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [analysisLoad setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [analysisLoadBrowser setTarget:self];
    [analysisLoadBrowser setDoubleAction:@selector(browserDoubleClick:)];
}

-(int)browser:(NSBrowser *)sender numberOfRowsInColumn:(int)column{
    directoryInfoCount = 0;
    
    string entry;
    
    DIR *dir;
    struct dirent *dent;
    
    if (column == 0){
        if (dataType == 1){
            dir = opendir(trackDataFolderPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Series") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_Series")), directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
        else if (dataType == 2){
            dir = opendir(analysisDataFolderPath.c_str());
            
            if (dir != NULL){
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_AnalysisResults") != -1){
                            if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                            arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_AnalysisResults")), directoryInfoCount++;
                        }
                    }
                }
                
                closedir(dir);
                
                //----Directory Sort----
                NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                
                for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                    [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                }
                
                [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                
                for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                    arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                }
            }
        }
    }
    
    if (column == 1){
        NSString *path;
        path = [sender path];
        
        if (dataType == 1){
            string analysisFolderPath = trackDataFolderPath+[path UTF8String]+"_Series";
            string analysisFolderPath2 = "";
            string analysisFolderPath3 = "";
            string analysisNameTemp = [path UTF8String];
            
            if (analysisNameTemp != ""){
                ifstream fin;
                
                int shortFormatFind = 0;
                
                analysisNameTemp = analysisNameTemp.substr(1);
                
                if ((int)analysisNameTemp.find("/") != -1) analysisNameTemp = analysisNameTemp.substr(0, analysisNameTemp.find("/"));
                
                analysisSeriesNameSelect = analysisNameTemp;
                analysisImageNameSelect = "";
                [analysisSeriesDisplay setStringValue:@(analysisSeriesNameSelect.c_str())];
                
                [analysisIDDisplay setStringValue:@"nil"];
                [analysisResultsDisplay setStringValue:@"nil"];
                
                dir = opendir(analysisFolderPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_TrackData") != -1){
                                analysisFolderPath3 = analysisFolderPath+"/"+entry+"/*ShortForm.dat";
                                shortFormatFind = 0;
                                
                                fin.open(analysisFolderPath3.c_str(), ios::in | ios::binary);
                                
                                if (fin.is_open()){
                                    shortFormatFind = 1;
                                    fin.close();
                                }
                                
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                
                                if (shortFormatFind == 0) arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_TrackData")), directoryInfoCount++;
                                else arrayDirectoryInfo [directoryInfoCount] = "*"+entry.substr(0, entry.find("_TrackData")), directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
        else if (dataType == 2){
            string analysisFolderPath = analysisDataFolderPath+[path UTF8String]+"_AnalysisResults";
            string analysisNameTemp = [path UTF8String];
            
            if (analysisNameTemp != ""){
                ifstream fin;
                
                analysisNameTemp = analysisNameTemp.substr(1);
                
                if ((int)analysisNameTemp.find("/") != -1) analysisNameTemp = analysisNameTemp.substr(0, analysisNameTemp.find("/"));
                
                analysisSeriesNameSelect = analysisNameTemp;
                analysisImageNameSelect = "";
                [analysisSeriesDisplay setStringValue:@(analysisSeriesNameSelect.c_str())];
                
                [analysisIDDisplay setStringValue:@"nil"];
                [analysisResultsDisplay setStringValue:@"nil"];
                
                dir = opendir(analysisFolderPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_IDResults") != -1){
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                
                                arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_IDResults")), directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
    }
    
    if (column == 2){
        NSString *path;
        path = [sender path];
        
        if (dataType == 2){
            string stringExtract1 = [path UTF8String];
            stringExtract1 = stringExtract1.substr(1);
            string stringExtract2 = "";
            string stringExtract3 = "";
            
            if ((int)stringExtract1.find("/") != -1){
                stringExtract2 = stringExtract1.substr(0, stringExtract1.find("/"));
                stringExtract3 = stringExtract1.substr(stringExtract1.find("/")+1);
            }
            
            string analysisFolderPath = analysisDataFolderPath+"/"+stringExtract2+"_AnalysisResults/"+stringExtract3+"_IDResults";
            string analysisFolderPath2 = "";
            string analysisFolderPath3 = "";
            string analysisNameTemp = [path UTF8String];
            
            if (stringExtract3 != ""){
                ifstream fin;
                
                analysisSeriesNameSelect = stringExtract2;
                analysisImageNameSelect = "";
                [analysisSeriesDisplay setStringValue:@(analysisSeriesNameSelect.c_str())];
                [analysisIDDisplay setStringValue:@"nil"];
                [analysisResultsDisplay setStringValue:@"nil"];
                
                dir = opendir(analysisFolderPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            if ((int)entry.find("_Results") != -1){
                                if (directoryInfoCount+2 > directoryInfoLimit) [self directoryInfoUpDate];
                                arrayDirectoryInfo [directoryInfoCount] = entry.substr(0, entry.find("_Results")), directoryInfoCount++;
                            }
                        }
                    }
                    
                    closedir(dir);
                    
                    //----Directory Sort----
                    NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
                    
                    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++){
                        [unsortedArray addObject:@(arrayDirectoryInfo [counter1].c_str())];
                    }
                    
                    [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
                    
                    for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                        arrayDirectoryInfo [counter1] = [unsortedArray [counter1] UTF8String];
                    }
                }
            }
        }
    }
    
    return directoryInfoCount;
}

-(void)browser:(NSBrowser *)sender willDisplayCell:(id)cell atRow:(int)row column:(int)column{
    if (column == 0){
        string folderName = arrayDirectoryInfo [row];
        [cell setStringValue: @(folderName.c_str())];
        [cell setLoaded:YES];
    }
    
    if (dataType == 1){
        if (column == 1){
            string folderName = arrayDirectoryInfo [row];
            [cell setStringValue: @(folderName.c_str())];
            [cell setLeaf:YES];
        }
    }
    else if (dataType == 2){
        if (column == 1){
            string folderName = arrayDirectoryInfo [row];
            [cell setStringValue: @(folderName.c_str())];
            [cell setLoaded:YES];
        }
        
        if (column == 2){
            string folderName = arrayDirectoryInfo [row];
            [cell setStringValue: @(folderName.c_str())];
            [cell setLeaf:YES];
        }
    }
}

-(IBAction)browserDoubleClick:(id)browser{
    NSString *nodePath = [browser path];
    string nodePathString = [nodePath UTF8String];
    
    if (nodePathString != ""){
        nodePathString = nodePathString.substr(1);
        
        if ((int)nodePathString.find("/") != -1){
            if (dataType == 1){
                string stringExtract = nodePathString.substr(nodePathString.find("/")+1);
                
                if ((int)stringExtract.find("/") != -1) stringExtract = stringExtract.substr(stringExtract.find("/")+1);
                
                analysisIDSelect = stringExtract;
                
                if ((int)analysisIDSelect.find("*") != -1){
                    analysisIDSelect = analysisIDSelect.substr(1);
                    [analysisIDDisplay setStringValue:@(analysisIDSelect.c_str())];
                }
                else{
                    
                    analysisIDSelect = "";
                    [analysisIDDisplay setStringValue:@"nil"];
                }
            }
            else if (dataType == 2){
                int idSelect = 0;
                
                string stringExtract = nodePathString.substr(nodePathString.find("/")+1);
                string stringExtract1;
                
                if ((int)stringExtract.find("/") != -1){
                    stringExtract1 = stringExtract.substr(0, stringExtract.find("/"));
                    stringExtract = stringExtract.substr(stringExtract.find("/")+1);
                    idSelect = 1;
                }
                
                analysisIDSelect = stringExtract;
                
                if (idSelect == 0){
                    [analysisIDDisplay setStringValue:@(analysisIDSelect.c_str())];
                }
                else{
                    
                    analysisImageNameSelect = stringExtract1;
                    [analysisSeriesDisplay setStringValue:@(analysisSeriesNameSelect.c_str())];
                    [analysisIDDisplay setStringValue:@(analysisImageNameSelect.c_str())];
                    [analysisResultsDisplay setStringValue:@(analysisIDSelect.c_str())];
                }
            }
        }
    }
}

-(IBAction)closeWindow:(id)sender{
    [analysisLoad orderOut:self];
    analysisLoadOperation = 2;
    analysisLoadTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (analysisLoadOperation == 3){
        [analysisLoad makeKeyAndOrderFront:self];
        analysisLoadOperation = 1;
        [analysisLoadTimer invalidate];
    }
}

-(IBAction)deleteAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        if (analysisIDSelect != ""){
            if (dataType == 1){
                string analysisIDPath = trackDataFolderPath+"/"+analysisSeriesNameSelect+"_Series";
                sourceAnalysisPath = trackDataFolderPath+"/"+analysisSeriesNameSelect+"_Series"+"/"+analysisIDSelect+"_TrackData";
                
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                DIR *dir3;
                struct dirent *dent3;
                DIR *dir4;
                struct dirent *dent4;
                
                //----Check whether source exist----
                int proceedingFlag = 0;
                int remainingNumberOfAnalysis = 0;
                string checkName = analysisIDSelect+"_TrackData";
                
                string entry;
                
                dir = opendir(analysisIDPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            remainingNumberOfAnalysis++;
                            
                            if (checkName == entry){
                                proceedingFlag = 1;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                else proceedingFlag = 0;
                
                if (proceedingFlag == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert addButtonWithTitle:@"Cancel"];
                    [alert setMessageText:@"Delete Analysis?"];
                    [alert setInformativeText:@"Deleted Analysis Cannot Be Restored"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    
                    if ([alert runModal] == NSAlertFirstButtonReturn){
                        analysisIDSelect = "";
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        string entry2;
                        string entry3;
                        string entry4;
                        string sourceAnalysisPath2;
                        string sourceAnalysisPath3;
                        string sourceAnalysisPath4;
                        string sourceAnalysisPath5;
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                    
                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                                
                                                dir3 = opendir(sourceAnalysisPath3.c_str());
                                                
                                                if (dir3 != NULL){
                                                    while ((dent3 = readdir(dir3))){
                                                        entry3 = dent3 -> d_name;
                                                        
                                                        if (entry3 != "." && entry3 != ".." && entry3 != ".DS_Store"){
                                                            sourceAnalysisPath4 = sourceAnalysisPath3+"/"+entry3;
                                                            
                                                            dir4 = opendir(sourceAnalysisPath4.c_str());
                                                            
                                                            if (dir4 != NULL){
                                                                while ((dent4 = readdir(dir4))){
                                                                    entry4 = dent4 -> d_name;
                                                                    
                                                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                                    arrayFileDelete [fileDeleteCount] = sourceAnalysisPath4+"/"+entry4, fileDeleteCount++;
                                                                }
                                                                
                                                                closedir(dir4);
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir(dir3);
                                                }
                                            }
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                            
                            closedir (dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                remove (arrayFileDelete [counter1].c_str());
                            }
                        }
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                    
                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                sourceAnalysisPath3 = sourceAnalysisPath2+"/"+entry2;
                                                
                                                dir3 = opendir(sourceAnalysisPath3.c_str());
                                                
                                                if (dir3 != NULL){
                                                    while ((dent3 = readdir(dir3))){
                                                        entry3 = dent3 -> d_name;
                                                        
                                                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                                        arrayFileDelete [fileDeleteCount] = sourceAnalysisPath3+"/"+entry3, fileDeleteCount++;
                                                    }
                                                    
                                                    closedir(dir3);
                                                }
                                            }
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                            
                            closedir (dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                remove (arrayFileDelete [counter1].c_str());
                                rmdir (arrayFileDelete [counter1].c_str());
                            }
                        }
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                    
                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                            arrayFileDelete [fileDeleteCount] = sourceAnalysisPath2+"/"+entry2, fileDeleteCount++;
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                            
                            closedir (dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                remove (arrayFileDelete [counter1].c_str());
                                rmdir (arrayFileDelete [counter1].c_str());
                            }
                        }
                        
                        fileDeleteCount = 0;
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+arrayFileDelete [counter1];
                                remove (sourceAnalysisPath2.c_str());
                                rmdir (sourceAnalysisPath2.c_str());
                            }
                            
                            rmdir (sourceAnalysisPath.c_str());
                        }
                        
                        if (remainingNumberOfAnalysis == 1){
                            fileDeleteCount = 0;
                            
                            dir = opendir(analysisIDPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                                
                                closedir(dir);
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+arrayFileDelete [counter1];
                                    remove (sourceAnalysisPath2.c_str());
                                }
                                
                                rmdir (analysisIDPath.c_str());
                            }
                        }
                        
                        [analysisLoadBrowser reloadColumn:1];
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else{
                    
                    [analysisIDDisplay setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"ID Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else if (dataType == 2){
                string analysisIDPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults";
                sourceAnalysisPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults"+"/"+analysisIDSelect+"_IDResults";
                
                DIR *dir;
                struct dirent *dent;
                DIR *dir2;
                struct dirent *dent2;
                
                //----Check whether source exist----
                int proceedingFlag = 0;
                int remainingNumberOfAnalysis = 0;
                string checkName = analysisIDSelect+"_IDResults";
                
                string entry;
                
                dir = opendir(analysisIDPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            remainingNumberOfAnalysis++;
                            
                            if (checkName == entry){
                                proceedingFlag = 1;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                else proceedingFlag = 0;
                
                if (proceedingFlag == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert addButtonWithTitle:@"Cancel"];
                    [alert setMessageText:@"Delete Analysis?"];
                    [alert setInformativeText:@"Deleted Analysis Cannot Be Restored"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    
                    if ([alert runModal] == NSAlertFirstButtonReturn){
                        analysisIDSelect = "";
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        string entry2;
                        string entry3;
                        string sourceAnalysisPath2;
                        string sourceAnalysisPath3;
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                    
                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                    
                                    if (dir2 != NULL){
                                        while ((dent2 = readdir(dir2))){
                                            entry2 = dent2 -> d_name;
                                            
                                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                            arrayFileDelete [fileDeleteCount] = sourceAnalysisPath2+"/"+entry2, fileDeleteCount++;
                                        }
                                        
                                        closedir(dir2);
                                    }
                                }
                            }
                            
                            closedir (dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                remove (arrayFileDelete [counter1].c_str());
                            }
                        }
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+arrayFileDelete [counter1];
                                remove (sourceAnalysisPath2.c_str());
                                rmdir (sourceAnalysisPath2.c_str());
                            }
                        }
                        
                        rmdir (sourceAnalysisPath.c_str());
                        
                        if (remainingNumberOfAnalysis == 1){
                            fileDeleteCount = 0;
                            
                            dir = opendir(analysisIDPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                                
                                closedir(dir);
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    sourceAnalysisPath2 = analysisIDPath+"/"+arrayFileDelete [counter1];
                                    remove (sourceAnalysisPath2.c_str());
                                }
                                
                                rmdir (analysisIDPath.c_str());
                            }
                        }
                        
                        [analysisLoadBrowser reloadColumn:1];
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else{
                    
                    [analysisIDDisplay setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"ID Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            [analysisIDDisplay setStringValue:@"nil"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteAnalysisResults:(id)sender{
    if (upLoadingProgress == 0){
        if (analysisIDSelect != "" && analysisImageNameSelect != ""){
            if (dataType == 2){
                string analysisSeriesPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults";
                string analysisIDPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults/"+analysisImageNameSelect+"_IDResults";
                sourceAnalysisPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults"+"/"+analysisImageNameSelect+"_IDResults/"+analysisIDSelect+"_Results";
                
                DIR *dir;
                struct dirent *dent;
                
                //----Check whether source exist----
                int proceedingFlag = 0;
                int remainingNumberOfAnalysis = 0;
                string checkName = analysisIDSelect+"_Results";
                
                string entry;
                
                dir = opendir(analysisIDPath.c_str());
                
                if (dir != NULL){
                    while ((dent = readdir(dir))){
                        entry = dent -> d_name;
                        
                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                            remainingNumberOfAnalysis++;
                            
                            if (checkName == entry){
                                proceedingFlag = 1;
                            }
                        }
                    }
                    
                    closedir(dir);
                }
                else proceedingFlag = 0;
                
                if (proceedingFlag == 1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert addButtonWithTitle:@"Cancel"];
                    [alert setMessageText:@"Delete Analysis?"];
                    [alert setInformativeText:@"Deleted Analysis Cannot Be Restored"];
                    
                    [alert setAlertStyle:NSAlertStyleWarning];
                    
                    if ([alert runModal] == NSAlertFirstButtonReturn){
                        analysisIDSelect = "";
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        string entry2;
                        string entry3;
                        string sourceAnalysisPath2;
                        string sourceAnalysisPath3;
                        
                        dir = opendir(sourceAnalysisPath.c_str());
                        
                        fileDeleteCount = 0;
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                
                                if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                            }
                            
                            closedir(dir);
                            
                            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+arrayFileDelete [counter1];
                                remove (sourceAnalysisPath2.c_str());
                            }
                        }
                        
                        rmdir (sourceAnalysisPath.c_str());
                        rmdir (sourceAnalysisPath.c_str());
                        
                        if (remainingNumberOfAnalysis == 1){
                            fileDeleteCount = 0;
                            
                            dir = opendir(analysisIDPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                                
                                closedir(dir);
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    sourceAnalysisPath2 = analysisIDPath+"/"+arrayFileDelete [counter1];
                                    remove (sourceAnalysisPath2.c_str());
                                }
                                
                                rmdir (analysisIDPath.c_str());
                            }
                        }
                        
                        remainingNumberOfAnalysis = 0;
                        
                        dir = opendir(analysisSeriesPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    remainingNumberOfAnalysis++;
                                }
                            }
                            
                            closedir(dir);
                        }
                        
                        if (remainingNumberOfAnalysis == 1){
                            fileDeleteCount = 0;
                            
                            dir = opendir(analysisSeriesPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                                    arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                                }
                                
                                closedir(dir);
                                
                                for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                                    sourceAnalysisPath2 = analysisSeriesPath+"/"+arrayFileDelete [counter1];
                                    remove (sourceAnalysisPath2.c_str());
                                }
                                
                                rmdir (analysisSeriesPath.c_str());
                            }
                        }
                        
                        [analysisLoadBrowser reloadColumn:1];
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                        [sound play];
                    }
                }
                else{
                    
                    [analysisIDDisplay setStringValue:@"nil"];
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"ID Error"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            [analysisIDDisplay setStringValue:@"nil"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"ID Error"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)loadAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        NSOpenPanel *openDlg = [NSOpenPanel openPanel];
        [openDlg setCanChooseFiles:NO];
        [openDlg setCanChooseDirectories:YES];
        
        if ([openDlg runModal] == NSModalResponseOK){
            NSArray *files = [openDlg URLs];
            NSString *fileName = [[files objectAtIndex:0] absoluteString];
            
            string directoryPathExtract = [fileName UTF8String];
            
            unsigned long findString1 = directoryPathExtract.find("/Users/");
            if ((int)findString1 == -1) findString1 = directoryPathExtract.find("/Volumes/");
            
            unsigned long directoryLength = directoryPathExtract.length();
            
            string extractedID = directoryPathExtract.substr(findString1, directoryLength-findString1-1);
            string directoryPath = directoryPathExtract.substr(findString1, directoryLength-findString1-1);
            
            int terminationFlag = 0;
            
            do{
                
                terminationFlag = 1;
                
                if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                else terminationFlag = 0;
                
            } while (terminationFlag == 1);
            
            directoryPath = directoryPath.substr (0, directoryPath.find (extractedID));
            
            if (extractedID != "" && ((int)extractedID.find("_TrackData") != -1 || (int)extractedID.find("_IDResults") != -1) && analysisSeriesNameSelect != ""){
                string destinationName = extractedID.substr (0, extractedID.find("_TrackData"));
                
                int errorFlag = 0;
                string newAnalysisID = "";
                
                if (dataType == 1) newAnalysisID = extractedID.substr (0, extractedID.find("_TrackData"));
                else newAnalysisID = extractedID.substr (0, extractedID.find("_IDResults"));
                
                if (newAnalysisID.length() < 4 || newAnalysisID.length() > 15) errorFlag = 1;
                if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
                if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
                
                string extractedID2;
                
                do{
                    
                    terminationFlag = 1;
                    
                    if ((int)extractedID.find("%20") != -1){
                        extractedID2 = destinationName.substr(0, findString1);
                        destinationName = destinationName.substr(findString1+3);
                        destinationName = extractedID2+" "+extractedID;
                    }
                    else terminationFlag = 0;
                    
                } while (terminationFlag == 1);
                
                if (errorFlag == 0){
                    if (dataType == 1){
                        string destinationAnalysisPath = trackDataFolderPath+"/"+analysisSeriesNameSelect+"_Series"+"/"+destinationName+"_TrackData";
                        sourceAnalysisPath = directoryPath+destinationName+"_TrackData";
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        //----Check whether same ID exist----
                        int proceedingFlag = 0;
                        string checkRefPath = trackDataFolderPath+"/"+analysisSeriesNameSelect+"_Series";
                        string checkName = destinationName+"_TrackData";
                        string entry;
                        
                        struct stat sizeOfFile;
                        
                        dir = opendir(checkRefPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (checkName == entry){
                                        proceedingFlag = 1;
                                        break;
                                    }
                                }
                            }
                            
                            closedir(dir);
                            
                            if (proceedingFlag == 1){
                                string additionString;
                                int proceedingFlag2 = 0;
                                
                                for (int counter1 = 0; counter1 < 24; counter1++){
                                    if (counter1 == 0) additionString = "A";
                                    else if (counter1 == 1) additionString = "B";
                                    else if (counter1 == 1) additionString = "C";
                                    else if (counter1 == 1) additionString = "D";
                                    else if (counter1 == 1) additionString = "E";
                                    else if (counter1 == 1) additionString = "F";
                                    else if (counter1 == 1) additionString = "G";
                                    else if (counter1 == 1) additionString = "H";
                                    else if (counter1 == 1) additionString = "I";
                                    else if (counter1 == 1) additionString = "J";
                                    else if (counter1 == 1) additionString = "K";
                                    else if (counter1 == 1) additionString = "L";
                                    else if (counter1 == 1) additionString = "M";
                                    else if (counter1 == 1) additionString = "N";
                                    else if (counter1 == 1) additionString = "O";
                                    else if (counter1 == 1) additionString = "Q";
                                    else if (counter1 == 1) additionString = "R";
                                    else if (counter1 == 1) additionString = "S";
                                    else if (counter1 == 1) additionString = "T";
                                    else if (counter1 == 1) additionString = "U";
                                    else if (counter1 == 1) additionString = "X";
                                    else if (counter1 == 1) additionString = "Y";
                                    else if (counter1 == 1) additionString = "Z";
                                    
                                    proceedingFlag2 = 0;
                                    
                                    dir = opendir(checkRefPath.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                if (destinationName+additionString+"_TrackData" == entry){
                                                    proceedingFlag2 = 1;
                                                    break;
                                                }
                                            }
                                        }
                                        
                                        closedir(dir);
                                    }
                                    
                                    if (proceedingFlag2 == 0){
                                        proceedingFlag = 0;
                                        destinationName = destinationName+additionString;
                                        destinationAnalysisPath = trackDataFolderPath+"/"+analysisSeriesNameSelect+"_Series"+"/"+destinationName+"_TrackData";
                                        
                                        break;
                                    }
                                }
                            }
                        }
                        else proceedingFlag = 1;
                        
                        if (proceedingFlag == 0){
                            string sizeCheckPath = "/";
                            
                            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                            unsigned long totalFileSize = 0;
                            
                            DIR *dir2;
                            struct dirent *dent2;
                            
                            dir = opendir(sourceAnalysisPath.c_str());
                            
                            if (dir != NULL){
                                string entry2;
                                string pathName2;
                                string pathName3;
                                
                                long sizeForCopy;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Connect") != -1){
                                        pathName2 = sourceAnalysisPath+"/"+entry;
                                        
                                        dir2 = opendir(pathName2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && ((int)entry2.find("_ConnectLineageRel") != -1 || (int)entry2.find("_ExtendAreaData") != -1 || (int)entry2.find("_LineageData") != -1)){
                                                    pathName3 = pathName2+"/"+entry2;
                                                    
                                                    if ( stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
                            
                            if (freeSize > refSize){
                                //----Create destination folder----
                                mkdir(destinationAnalysisPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                string entry2;
                                string destAnalysisPath2;
                                string sourceAnalysisPath2;
                                string copyFilePath;
                                string destinationFilePath;
                                
                                long sizeForCopy = 0;
                                
                                //----Copy start----
                                dir = opendir(sourceAnalysisPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            findString1 = entry.find("_Connect");
                                            
                                            //----Connect copy----
                                            if ((int)findString1 != -1){
                                                destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                                
                                                //----Create Connect folder----
                                                mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                
                                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                                
                                                if (dir2 != NULL){
                                                    while ((dent2 = readdir(dir2))){
                                                        entry2 = dent2 -> d_name;
                                                        
                                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store" && ((int)entry2.find("LineageData") != -1|| (int)entry2.find("ExtendAreaData") != -1 || (int)entry2.find("ConnectLineageRel") != -1)){
                                                            copyFilePath = sourceAnalysisPath2+"/"+entry2;
                                                            destinationFilePath = destAnalysisPath2+"/"+entry2;
                                                            
                                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                
                                                                char *buffer = new char[sizeForCopy];
                                                                infile.read (buffer, sizeForCopy);
                                                                outfile.write (buffer, sizeForCopy);
                                                                delete [] buffer;
                                                                
                                                                outfile.close();
                                                                infile.close();
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir (dir2);
                                                }
                                            }
                                            
                                            if ((int)entry.find("TrackingSetting.dat") != -1 || (int)entry.find("*LineageDataAddition.dat") != -1){
                                                copyFilePath = sourceAnalysisPath+"/"+entry;
                                                destinationFilePath = destinationAnalysisPath+"/"+entry;
                                                
                                                if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                    sizeForCopy = sizeOfFile.st_size;
                                                    
                                                    ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                    ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                    
                                                    char *buffer = new char[sizeForCopy];
                                                    infile.read (buffer, sizeForCopy);
                                                    outfile.write (buffer, sizeForCopy);
                                                    delete [] buffer;
                                                    
                                                    outfile.close();
                                                    infile.close();
                                                }
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    destinationAnalysisPath = destinationAnalysisPath+"/*ShortForm.dat";
                                    
                                    ofstream oin;
                                    oin.open(destinationAnalysisPath.c_str(), ios::out | ios::binary);
                                    
                                    oin<<"Short Form"<<endl;
                                    oin.close();
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Folder Missing"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Low Disk Space"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            [analysisLoadBrowser reloadColumn:1];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Analysis With Same ID Found"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else if (dataType == 2){
                        string destinationAnalysisPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults"+"/"+destinationName;
                        sourceAnalysisPath = directoryPath+destinationName;
                        
                        DIR *dir;
                        struct dirent *dent;
                        
                        //----Check whether same ID exist----
                        int proceedingFlag = 0;
                        string checkRefPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults";
                        string checkName = destinationName;
                        string entry;
                        
                        dir = opendir(checkRefPath.c_str());
                        
                        if (dir != NULL){
                            while ((dent = readdir(dir))){
                                entry = dent -> d_name;
                                
                                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                    if (checkName == entry){
                                        proceedingFlag = 1;
                                        break;
                                    }
                                }
                            }
                            
                            closedir(dir);
                        }
                        else proceedingFlag = 1;
                        
                        struct stat sizeOfFile;
                        
                        if (proceedingFlag == 0){
                            string sizeCheckPath = "/";
                            
                            NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                            unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                            unsigned long totalFileSize = 0;
                            
                            DIR *dir2;
                            struct dirent *dent2;
                            
                            dir = opendir(sourceAnalysisPath.c_str());
                            
                            if (dir != NULL){
                                string entry2;
                                string pathName2;
                                string pathName3;
                                
                                long sizeForCopy;
                                
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("_Results") != -1){
                                        pathName2 = sourceAnalysisPath+"/"+entry;
                                        
                                        dir2 = opendir(pathName2.c_str());
                                        
                                        if (dir2 != NULL){
                                            while ((dent2 = readdir(dir2))){
                                                entry2 = dent2 -> d_name;
                                                
                                                if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                    pathName3 = pathName2+"/"+entry2;
                                                    
                                                    if (stat(pathName3.c_str(), &sizeOfFile) == 0){
                                                        sizeForCopy = sizeOfFile.st_size;
                                                        
                                                        totalFileSize = totalFileSize+(unsigned long)sizeForCopy;
                                                    }
                                                }
                                            }
                                            
                                            closedir(dir2);
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            
                            unsigned long refSize = (unsigned long)totalFileSize+2097152000;
                            
                            if (freeSize > refSize){
                                //----Create destination folder----
                                mkdir(destinationAnalysisPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                
                                string entry2;
                                string destAnalysisPath2;
                                string sourceAnalysisPath2;
                                string copyFilePath;
                                string destinationFilePath;
                                
                                long sizeForCopy = 0;
                                
                                //----Copy start----
                                dir = opendir(sourceAnalysisPath.c_str());
                                
                                if (dir != NULL){
                                    while ((dent = readdir(dir))){
                                        entry = dent -> d_name;
                                        
                                        if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                            findString1 = entry.find("Results");
                                            
                                            //----Connect copy----
                                            if ((int)findString1 != -1){
                                                destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                                                sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                                
                                                //----Create Connect folder----
                                                mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                
                                                dir2 = opendir(sourceAnalysisPath2.c_str());
                                                
                                                if (dir2 != NULL){
                                                    while ((dent2 = readdir(dir2))){
                                                        entry2 = dent2 -> d_name;
                                                        
                                                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                            copyFilePath = sourceAnalysisPath2+"/"+entry2;
                                                            destinationFilePath = destAnalysisPath2+"/"+entry2;
                                                            
                                                            if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                sizeForCopy = sizeOfFile.st_size;
                                                                
                                                                ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                
                                                                char *buffer = new char[sizeForCopy];
                                                                infile.read (buffer, sizeForCopy);
                                                                outfile.write (buffer, sizeForCopy);
                                                                delete [] buffer;
                                                                
                                                                outfile.close();
                                                                infile.close();
                                                            }
                                                        }
                                                    }
                                                    
                                                    closedir (dir2);
                                                }
                                            }
                                        }
                                    }
                                    
                                    closedir(dir);
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Ping"];
                                    [sound play];
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Folder Missing"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"Low Disk Space"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                            
                            [analysisLoadBrowser reloadColumn:1];
                        }
                        else{
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Analysis With Same ID Found"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                }
                else{
                    
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Prohibited Channels Found"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
            else{
                
                if (extractedID == "" || (int)extractedID.find("_TrackData") == -1 || (int)extractedID.find("_IDResults") != -1){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"TrackData/ID Results Folder Missing"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
                else if (analysisImageNameSelect == ""){
                    NSAlert *alert = [[NSAlert alloc] init];
                    
                    [alert addButtonWithTitle:@"OK"];
                    [alert setMessageText:@"Set Analysis Name"];
                    [alert setAlertStyle:NSAlertStyleWarning];
                    [alert runModal];
                    
                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                    [sound play];
                }
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)saveAnalysis:(id)sender{
    if (upLoadingProgress == 0){
        if (lineageDataEntryCount != 0){
            if (dataType == 2){
                NSSavePanel *save = [NSSavePanel savePanel];
                
                long int result2 = [save runModal];
                
                if (result2 == NSModalResponseOK){
                    NSURL *files = [save URL];
                    NSString *selectedFile = files.path;
                    
                    string extractedID = [selectedFile UTF8String];
                    string directoryPath = [selectedFile UTF8String];
                    
                    int terminationFlag = 0;
                    
                    do{
                        
                        terminationFlag = 1;
                        
                        if ((int)extractedID.find("/") != -1) extractedID = extractedID.substr(extractedID.find("/")+1);
                        else terminationFlag = 0;
                        
                    } while (terminationFlag == 1);
                    
                    unsigned long findString1 = directoryPath.find (extractedID);
                    directoryPath = directoryPath.substr (0, findString1);
                    
                    if (extractedID != "" && analysisIDSelect != "" && analysisImageNameSelect == ""){
                        int errorFlag = 0;
                        string newAnalysisID = extractedID.substr (0, extractedID.find("_IDResults"));
                        
                        if (newAnalysisID.length() < 4 || newAnalysisID.length() > 15) errorFlag = 1;
                        if ((int)newAnalysisID.find(" ") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find(".") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("/") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find(",") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find(":") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("<") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find(">") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("'") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("[") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("]") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("=") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("+") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("{") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("}") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find(")") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("(") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("*") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("&") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("^") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("%") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("$") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("#") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("@") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("!") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("`") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("~") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("|") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("-") >= 0) errorFlag = 1;
                        if ((int)newAnalysisID.find("_") >= 0) errorFlag = 1;
                        
                        if (errorFlag == 0){
                            string destinationAnalysisPath = directoryPath+extractedID+"_IDResults";
                            sourceAnalysisPath = analysisDataFolderPath+"/"+analysisSeriesNameSelect+"_AnalysisResults"+"/"+analysisIDSelect+"_IDResults";
                            
                            DIR *dir;
                            struct dirent *dent;
                            
                            //----Check whether same ID exist----
                            int proceedingFlag = 0;
                            string checkName = extractedID+"_IDResults";
                            
                            string entry;
                            
                            dir = opendir(directoryPath.c_str());
                            
                            if (dir != NULL){
                                while ((dent = readdir(dir))){
                                    entry = dent -> d_name;
                                    
                                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                        if (checkName == entry){
                                            proceedingFlag = 1;
                                            break;
                                        }
                                    }
                                }
                                
                                closedir(dir);
                            }
                            else proceedingFlag = 1;
                            
                            struct stat sizeOfFile;
                            
                            //----If it exists, proceed----
                            if (proceedingFlag == 0){
                                DIR *dir2;
                                struct dirent *dent2;
                                
                                unsigned long folderSize = 0;
                                
                                NSArray *contents;
                                NSEnumerator *enumerator;
                                NSString *path;
                                contents = [[NSFileManager defaultManager] subpathsAtPath:@(sourceAnalysisPath.c_str())];
                                enumerator = [contents objectEnumerator];
                                
                                while (path = [enumerator nextObject]){
                                    NSDictionary *folderSizeFind = [[NSFileManager defaultManager] attributesOfItemAtPath:[@(sourceAnalysisPath.c_str()) stringByAppendingPathComponent:path] error:nil];
                                    folderSize +=[folderSizeFind fileSize];
                                }
                                
                                string stringExtract;
                                string sizeCheckPath = "";
                                
                                if ((int)destinationAnalysisPath.find("/Volumes") != -1){
                                    stringExtract = destinationAnalysisPath.substr(8);
                                    
                                    if ((int)stringExtract.find("/") != -1){
                                        stringExtract = stringExtract.substr(1);
                                        stringExtract = stringExtract.substr(0, stringExtract.find("/"));
                                        
                                        sizeCheckPath = "/Volumes/"+stringExtract+"/";
                                    }
                                }
                                else sizeCheckPath = "/";
                                
                                NSDictionary *dicVol = [[NSFileManager defaultManager] attributesOfFileSystemForPath: @(sizeCheckPath.c_str()) error:nil];
                                
                                unsigned long freeSize = [[dicVol objectForKey: NSFileSystemFreeSize] unsignedLongLongValue];
                                unsigned long refSize = (unsigned long)2097152000+folderSize;
                                
                                if (freeSize > refSize){
                                    //----Create destination folder----
                                    mkdir(destinationAnalysisPath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                    
                                    string entry2;
                                    string destAnalysisPath2;
                                    string sourceAnalysisPath2;
                                    string copyFilePath;
                                    string destinationFilePath;
                                    string destAnalysisPath3;
                                    string sourceAnalysisPath3;
                                    string entry3;
                                    string entry4;
                                    string destAnalysisPath4;
                                    string sourceAnalysisPath4;
                                    string getString;
                                    
                                    long sizeForCopy = 0;
                                    int tableMainTempCount = 0;
                                    int lineageDataTypeTempCount = 0;
                                    int lineageDataTypeTempLimit = 500;
                                    
                                    ifstream fin;
                                    ofstream oin;
                                    
                                    //----Copy start----
                                    dir = opendir(sourceAnalysisPath.c_str());
                                    
                                    if (dir != NULL){
                                        while ((dent = readdir(dir))){
                                            entry = dent -> d_name;
                                            
                                            if (entry != "." && entry != ".." && entry != ".DS_Store"){
                                                findString1 = entry.find("_Results");
                                                
                                                //----Connect copy----
                                                if ((int)findString1 != -1){
                                                    destAnalysisPath2 = destinationAnalysisPath+"/"+entry;
                                                    sourceAnalysisPath2 = sourceAnalysisPath+"/"+entry;
                                                    
                                                    //----Create Connect folder----
                                                    mkdir(destAnalysisPath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                                    
                                                    dir2 = opendir(sourceAnalysisPath2.c_str());
                                                    
                                                    if (dir2 != NULL){
                                                        while ((dent2 = readdir(dir2))){
                                                            entry2 = dent2 -> d_name;
                                                            
                                                            if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                                                                if ((int)entry2.find("*LineageDataAddition") != -1 || entry2 == "MainTable"){
                                                                    copyFilePath = sourceAnalysisPath2+"/"+"MainTable";
                                                                    
                                                                    sizeForCopy = 0;
                                                                    
                                                                    if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                        sizeForCopy = sizeOfFile.st_size;
                                                                    }
                                                                    
                                                                    string *arrayTableMainTemp = new string [sizeForCopy+50];
                                                                    tableMainTempCount = 0;
                                                                    
                                                                    fin.open(copyFilePath.c_str(), ios::in);
                                                                    
                                                                    if (fin.is_open()){
                                                                        do{
                                                                            
                                                                            terminationFlag = 1;
                                                                            
                                                                            getline(fin, getString);
                                                                            
                                                                            if (getString != "") arrayTableMainTemp [tableMainTempCount] = getString, tableMainTempCount++;
                                                                            else terminationFlag = 0;
                                                                            
                                                                        } while (terminationFlag == 1);
                                                                        
                                                                        fin.close();
                                                                    }
                                                                    
                                                                    arrayTableMainTemp [3] = newAnalysisID;
                                                                    
                                                                    destinationFilePath = destAnalysisPath2+"/"+"MainTable";
                                                                    
                                                                    oin.open(destinationFilePath.c_str(), ios::out | ios::binary);
                                                                    
                                                                    for (int counter1 = 0; counter1 < tableMainTempCount; counter1++){
                                                                        oin<<arrayTableMainTemp [counter1]<<endl;
                                                                    }
                                                                    
                                                                    oin.close();
                                                                    
                                                                    delete [] arrayTableMainTemp;
                                                                    
                                                                    string *arrayLineageDataTypeTemp = new string [500]; //----Hold Type Definition----
                                                                    lineageDataTypeTempCount = 0;
                                                                    lineageDataTypeTempLimit = 500;
                                                                    
                                                                    copyFilePath = sourceAnalysisPath2+"/*LineageDataAddition.dat";
                                                                    
                                                                    fin.open(copyFilePath.c_str(), ios::in);
                                                                    
                                                                    if (fin.is_open()){
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = newAnalysisID, lineageDataTypeTempCount++;
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                        getline(fin, getString);
                                                                        arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                        
                                                                        do{
                                                                            
                                                                            terminationFlag = 1;
                                                                            
                                                                            if (lineageDataTypeTempCount+9 > lineageDataTypeTempLimit){
                                                                                if (lineageDataTypeTempCount+10 > lineageDataTypeTempLimit){
                                                                                    string *arrayUpDate = new string [lineageDataTypeTempCount+10];
                                                                                    
                                                                                    for (int counter3 = 0; counter3 < lineageDataTypeTempCount; counter3++) arrayUpDate [counter3] = arrayLineageDataTypeTemp [counter3];
                                                                                    
                                                                                    delete [] arrayLineageDataTypeTemp;
                                                                                    lineageDataTypeTempLimit = lineageDataTypeTempCount+500;
                                                                                    arrayLineageDataTypeTemp = new string [lineageDataTypeTempLimit];
                                                                                    
                                                                                    for (int counter3 = 0; counter3 < lineageDataTypeTempCount; counter3++) arrayLineageDataTypeTemp [counter3] = arrayUpDate [counter3];
                                                                                    delete [] arrayUpDate;
                                                                                }
                                                                            }
                                                                            
                                                                            getline(fin, getString);
                                                                            
                                                                            if (getString == "") terminationFlag = 0;
                                                                            else{
                                                                                
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = to_string(lineageDataEntryCount);
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                                getline(fin, getString);
                                                                                arrayLineageDataTypeTemp [lineageDataTypeTempCount] = getString, lineageDataTypeTempCount++;
                                                                            }
                                                                            
                                                                        } while (terminationFlag == 1);
                                                                        
                                                                        fin.close();
                                                                    }
                                                                    
                                                                    destinationFilePath = destAnalysisPath2+"/*LineageDataAddition.dat";
                                                                    
                                                                    oin.open(destinationFilePath.c_str(), ios::out | ios::binary);
                                                                    
                                                                    for (int counter1 = 0; counter1 < lineageDataTypeTempCount; counter1++){
                                                                        oin<<arrayLineageDataTypeTemp [counter1]<<endl;
                                                                    }
                                                                    
                                                                    oin.close();
                                                                    
                                                                    delete [] arrayLineageDataTypeTemp;
                                                                }
                                                                else{
                                                                    
                                                                    copyFilePath = sourceAnalysisPath2+"/"+entry2;
                                                                    destinationFilePath = destAnalysisPath2+"/"+entry2;
                                                                    
                                                                    if (stat(copyFilePath.c_str(), &sizeOfFile) == 0){
                                                                        sizeForCopy = sizeOfFile.st_size;
                                                                        
                                                                        ifstream infile (copyFilePath.c_str(), ifstream::binary);
                                                                        ofstream outfile (destinationFilePath.c_str(), ofstream::binary);
                                                                        
                                                                        char *buffer = new char[sizeForCopy];
                                                                        infile.read (buffer, sizeForCopy);
                                                                        outfile.write (buffer, sizeForCopy);
                                                                        delete [] buffer;
                                                                        
                                                                        outfile.close();
                                                                        infile.close();
                                                                    }
                                                                }
                                                            }
                                                        }
                                                        
                                                        closedir (dir2);
                                                    }
                                                }
                                            }
                                        }
                                        
                                        closedir(dir);
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Ping"];
                                        [sound play];
                                        
                                        [analysisLoadBrowser reloadColumn:1];
                                    }
                                    else{
                                        
                                        NSAlert *alert = [[NSAlert alloc] init];
                                        
                                        [alert addButtonWithTitle:@"OK"];
                                        [alert setMessageText:@"Folder Missing"];
                                        [alert setAlertStyle:NSAlertStyleWarning];
                                        [alert runModal];
                                        
                                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                                        [sound play];
                                    }
                                    
                                    [analysisIDDisplay setStringValue:@"nil"];
                                }
                                else{
                                    
                                    [analysisIDDisplay setStringValue:@"nil"];
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Low Disk Space"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                            }
                            else{
                                
                                [analysisIDDisplay setStringValue:@"nil"];
                                
                                NSAlert *alert = [[NSAlert alloc] init];
                                
                                [alert addButtonWithTitle:@"OK"];
                                [alert setMessageText:@"ID Error"];
                                [alert setAlertStyle:NSAlertStyleWarning];
                                [alert runModal];
                                
                                NSSound *sound = [NSSound soundNamed:@"Hero"];
                                [sound play];
                            }
                        }
                        else{
                            
                            [analysisIDDisplay setStringValue:@"nil"];
                            
                            NSAlert *alert = [[NSAlert alloc] init];
                            
                            [alert addButtonWithTitle:@"OK"];
                            [alert setMessageText:@"Prohibited Channels Found"];
                            [alert setAlertStyle:NSAlertStyleWarning];
                            [alert runModal];
                            
                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                            [sound play];
                        }
                    }
                    else{
                        
                        [analysisIDDisplay setStringValue:@"nil"];
                        
                        NSAlert *alert = [[NSAlert alloc] init];
                        
                        [alert addButtonWithTitle:@"OK"];
                        [alert setMessageText:@"ID Error"];
                        [alert setAlertStyle:NSAlertStyleWarning];
                        [alert runModal];
                        
                        NSSound *sound = [NSSound soundNamed:@"Hero"];
                        [sound play];
                    }
                }
            }
            else{
                
                [analysisIDDisplay setStringValue:@"nil"];
                
                NSAlert *alert = [[NSAlert alloc] init];
                
                [alert addButtonWithTitle:@"OK"];
                [alert setMessageText:@"No Analysis Mode"];
                [alert setAlertStyle:NSAlertStyleWarning];
                [alert runModal];
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            [analysisIDDisplay setStringValue:@"nil"];
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"Lineage Data Missing"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Uploading In Progress"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)dataSwitch:(id)sender{
    if (lineageDataEntryCount != 0){
        if (dataType == 1){
            dataType = 2;
            
            analysisIDSelect = "";
            [analysisIDDisplay setStringValue:@"nil"];
            [analysisSourceDisplay setStringValue:@"Analysis"];
            
            [analysisLoadBrowser reloadColumn:0];
        }
        else{
            
            dataType = 1;
            
            analysisIDSelect = "";
            [analysisIDDisplay setStringValue:@"nil"];
            [analysisSourceDisplay setStringValue:@"Source"];
            
            [analysisLoadBrowser reloadColumn:0];
        }
        
        NSSound *sound = [NSSound soundNamed:@"Ping"];
        [sound play];
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"Lineage Data Missing"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(void)directoryInfoUpDate{
    string *arrayUpDate = new string [directoryInfoCount+10];
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayUpDate [counter1] = arrayDirectoryInfo [counter1];
    
    delete [] arrayDirectoryInfo;
    arrayDirectoryInfo = new string [directoryInfoLimit+500];
    directoryInfoLimit = directoryInfoLimit+500;
    
    for (int counter1 = 0; counter1 < directoryInfoCount; counter1++) arrayDirectoryInfo [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToDataUploading object:nil];
}

@end
