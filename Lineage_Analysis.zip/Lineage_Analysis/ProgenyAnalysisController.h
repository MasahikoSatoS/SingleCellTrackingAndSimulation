//
//  ProgenyAnalysisController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-22.
//
//

#ifndef PROGENYANALYSISCONTROLLER_H
#define PROGENYANALYSISCONTROLLER_H
#import "Controller.h" 
#endif

@interface ProgenyAnalysisController : NSObject <NSTextFieldDelegate>{
    int progenyAnalysisTimeEd1Hold; //Time end1
    int progenyAnalysisTimeEd2Hold; //Time end2
    int progenyAnalysisRangeHold; //Range
    int progenyAnalysisGroupHold; //Group
    int progenyAnalysisZeroInclude; //Zero include
    int sdCalculationHold; //SD calculation
    int percentMode; //Percent mode
    int normalizeHold; //Normalize
    int progenyOfMDInclude; //MD progeny include
    
    IBOutlet NSTextField *zeroIncludeDisplay;
    IBOutlet NSTextField *progenyAnalysisTimeEd1Display;
    IBOutlet NSTextField *progenyAnalysisTimeEd2Display;
    IBOutlet NSTextField *progenyAnalysisRangeDisplay;
    IBOutlet NSTextField *progenyAnalysisGroupDisplay;
    IBOutlet NSTextField *sdModeDisplay;
    IBOutlet NSTextField *percentModeDisplay;
    IBOutlet NSTextField *normalizeDisplay;
    IBOutlet NSTextField *progenyOfMDIncludeDisplay;
    
    IBOutlet NSWindow *progenyAnalysisProgenyWindow;
    
    NSWindowController *progenyAnalysisProgenyWindowController;
    
    NSTimer *progenyAnalysisProgenyTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)analysisSet;
-(void)lineageFluorescentDataTypeUpDate;

-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFile2:(id)sender;
-(IBAction)closeWindow:(id)sender;
-(IBAction)analysisStart:(id)sender;
-(IBAction)zeroStatusHold:(id)sender;
-(IBAction)sdCalculationHoldSet:(id)sender;
-(IBAction)percentModeSet:(id)sender;
-(IBAction)progenyOfMDIncludeSet:(id)sender;

@end
