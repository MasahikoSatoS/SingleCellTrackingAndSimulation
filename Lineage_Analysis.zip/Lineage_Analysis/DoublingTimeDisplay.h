//
//  DoublingTimeDisplay.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/16/16.
//
//

#ifndef DOUBLINGTIMEDISPLAY_H
#define DOUBLINGTIMEDISPLAY_H
#import "Controller.h" 
#endif

@interface DoublingTimeDisplay : NSView{
    IBOutlet NSWindow *doublingTimeListWindow;
}

-(void)dealloc;
-(BOOL)acceptsFirstResponder;
-(void)mouseDown:(NSEvent *)event;

@end
