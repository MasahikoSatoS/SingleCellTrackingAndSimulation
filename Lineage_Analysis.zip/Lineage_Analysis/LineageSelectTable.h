//
//  LineageSelectTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#ifndef LINEAGESELECTTABLE_H
#define LINEAGESELECTTABLE_H
#import "Controller.h" 
#endif

@interface LineageSelectTable : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *lineageSelectTable;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
