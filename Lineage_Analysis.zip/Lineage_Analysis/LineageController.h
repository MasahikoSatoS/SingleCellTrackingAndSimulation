//
//  LineageController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 11/9/16.
//
//

#ifndef LINEAGECONTROLLER_H
#define LINEAGECONTROLLER_H
#import "Controller.h" 
#endif

@interface LineageController : NSObject{
    int maxEntryNo; //Max entry no
    
    IBOutlet NSTextField *typeDisplayLing;
    IBOutlet NSTextField *seriesDisplayLing;
    IBOutlet NSTextField *analysisDisplayLing;
    IBOutlet NSTextField *treatDisplayLing;
    IBOutlet NSTextField *displayInfoInput;
    IBOutlet NSTextField *cellNameForDisplay;
    IBOutlet NSTextField *treatNameForDisplay;
    IBOutlet NSTextField *seriesNameForDisplay;
    IBOutlet NSTextField *ifRangeForDisplay;
    
    IBOutlet NSTextField *liveDisplayLing;
    IBOutlet NSTextField *channelDisplayLing;
    IBOutlet NSTextField *siblingDisplayLing;
    IBOutlet NSTextField *colorOptionDisplayLing;
    IBOutlet NSTextField *ifOneAllLing;
    IBOutlet NSTextField *averageTotalSetLing;
    IBOutlet NSTextField *blueLineSetDisplay;
    IBOutlet NSTextField *lineWidthSetDisplay;
    
    IBOutlet NSProgressIndicator *backSave;
    IBOutlet NSWindow *lineageWindow;
    
    NSWindowController *lineageWindowController;
    
    NSTimer *lineageTimer;
    NSTimer *lineageTimer2;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)liveDisplaySet:(id)sender;
-(IBAction)channelSet:(id)sender;
-(IBAction)siblingSet:(id)sender;
-(IBAction)ifOneAllSet:(id)sender;

-(IBAction)colorOptionSet:(id)sender;
-(IBAction)displayCellSet:(id)sender;
-(IBAction)displayTreatSet:(id)sender;
-(IBAction)displaySeriesSet:(id)sender;
-(IBAction)lingDataSave:(id)sender;

-(IBAction)averageTotalSet:(id)sender;
-(IBAction)blueLineDisplaySet:(id)sender;
-(IBAction)lineWidthSet:(id)sender;

-(IBAction)createPDF:(id)sender;
-(IBAction)createAllPDF:(id)sender;

@end
