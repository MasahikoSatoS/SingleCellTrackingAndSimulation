//
//  DoublingTimeAddition.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/16/16.
//
//

#ifndef DOUBLINGTIMEADDITION_H
#define DOUBLINGTIMEADDITION_H
#import "Controller.h" 
#endif

@interface DoublingTimeAddition : NSObject{
    IBOutlet NSTextField *verticalLow;
    IBOutlet NSTextField *verticalHigh;
    IBOutlet NSTextField *horizontalLow;
    IBOutlet NSTextField *horizontalHigh;
}

-(id)init;
-(void)dealloc;

@end
