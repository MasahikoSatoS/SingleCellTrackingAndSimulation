//
//  CellGrowthController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/2/16.
//
//

#import "CellGrowthController.h"

NSString *notificationToGrowthCurveController = @"notificationExecuteGrowthCurveController";

@implementation CellGrowthController

-(id)init{
    self = [super init];
    
    if (self != nil){
        everyConvert = 10;
        lineagePointSet = 1;
        lineagePointRangeSet = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToGrowthCurveController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    growthCurveWindowController = [[NSWindowController alloc] initWithWindowNibName:@"CellGrowth"];
    [growthCurveWindowController showWindow:self];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToGrowthCurveDisplay object:self];
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [growthCurveWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [growthCurveWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [verticalLow setDelegate:self];
    [verticalHigh setDelegate:self];
    [horizontalLow setDelegate:self];
    [horizontalHigh setDelegate:self];
    [pointConvertDisplay setDelegate:self];
    [minConvertDisplay setDelegate:self];
    [hrConvertDisplay setDelegate:self];
    [everyConvertDisplay setDelegate:self];
    [lineagePointDisplay setDelegate:self];
    [lineagePointRangeDisplay setDelegate:self];
    
    [verticalLow setIntegerValue:verticalScaleLowHold];
    [verticalHigh setIntegerValue:verticalScaleHighHold];
    [hrConvertDisplay setIntegerValue:horizontalScaleLowHold];
    [horizontalHigh setIntegerValue:horizontalScaleHighHold];
    [horizontalLow setIntegerValue:horizontalScaleLowHold];
    [pointConvertDisplay setIntegerValue:0];
    [minConvertDisplay setIntegerValue:0];
    [hrConvertDisplay setIntegerValue:0];
    [everyConvertDisplay setIntegerValue:10];
    [lineagePointDisplay setIntegerValue:lineagePointSet];
    [lineagePointRangeDisplay setIntegerValue:lineagePointRangeSet];
}

-(void)controlTextDidChange:(NSNotification *)aNotification{
    if ([[aNotification name] isEqualToString:@"NSControlTextDidChangeNotification"]){
        if ([aNotification object] == verticalLow){
            if ([verticalLow intValue] >= 0 && [verticalLow intValue] < verticalScaleHighHold){
                verticalScaleLowHold = [verticalLow intValue];
                [verticalLow setIntegerValue:verticalScaleLowHold];
            }
        }
        
        if ([aNotification object] == verticalHigh){
            if ([verticalHigh intValue] > 0 && [verticalHigh intValue] <= verticalScaleMaxHold){
                verticalScaleHighHold = [verticalHigh intValue];
                [verticalHigh setIntegerValue:verticalScaleHighHold];
            }
            else{
                
                verticalScaleHighHold = verticalScaleMaxHold;
                [verticalHigh setIntegerValue:verticalScaleHighHold];
            }
        }
        
        if ([aNotification object] == horizontalLow){
            if ([horizontalLow intValue] >= 0 && [horizontalLow intValue] < horizontalScaleHighHold){
                horizontalScaleLowHold = [horizontalLow intValue];
                [horizontalLow setIntegerValue:horizontalScaleLowHold];
            }
        }
        
        if ([aNotification object] == horizontalHigh){
            if ([horizontalHigh intValue] >= 0 && [horizontalHigh intValue] <= horizontalScaleMaxHold){
                horizontalScaleHighHold = [horizontalHigh intValue];
                [horizontalHigh setIntegerValue:horizontalScaleHighHold];
            }
            else{
                
                horizontalScaleHighHold = horizontalScaleMaxHold;
                [horizontalHigh setIntegerValue:horizontalScaleHighHold];
            }
        }
        
        if ([aNotification object] == everyConvertDisplay){
            if ([everyConvertDisplay intValue] > 0 && [everyConvertDisplay intValue] <= 100){
                everyConvert = [everyConvertDisplay intValue];
                [everyConvertDisplay setIntegerValue:everyConvert];
                
                minConvert = pointConvert*everyConvert;
                hrConvert = (pointConvert*everyConvert)/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [minConvertDisplay setIntegerValue:minConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [everyConvertDisplay setIntegerValue:everyConvert];
        }
        
        if ([aNotification object] == pointConvertDisplay){
            if ([pointConvertDisplay intValue] >= 0 && [pointConvertDisplay intValue] <= 10000){
                pointConvert = [pointConvertDisplay intValue];
                [pointConvertDisplay setIntegerValue:pointConvert];
                
                minConvert = pointConvert*everyConvert;
                hrConvert = (pointConvert*everyConvert)/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [minConvertDisplay setIntegerValue:minConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [pointConvertDisplay setIntegerValue:pointConvert];
        }
        
        if ([aNotification object] == minConvertDisplay){
            if ([minConvertDisplay intValue] >= 0 && [minConvertDisplay intValue] <= 100000){
                minConvert = [minConvertDisplay intValue];
                [minConvertDisplay setIntegerValue:minConvert];
                
                pointConvert = (int)(minConvert/(double)everyConvert);
                hrConvert = minConvert/(double)60;
                int hrConvertInt = (int)(hrConvert*100);
                hrConvert = hrConvertInt/(double)100;
                
                [pointConvertDisplay setIntegerValue:pointConvert];
                [hrConvertDisplay setDoubleValue:hrConvert];
            }
            else [minConvertDisplay setIntegerValue:minConvert];
        }
        
        if ([aNotification object] == hrConvertDisplay){
            if ([hrConvertDisplay intValue] >= 0 && [hrConvertDisplay intValue] <= 10000){
                hrConvert = [hrConvertDisplay intValue];
                [hrConvertDisplay setDoubleValue:hrConvert];
                
                pointConvert = (int)((hrConvert*60)/(double)everyConvert);
                minConvert = (int)(hrConvert*60);
                
                [pointConvertDisplay setIntegerValue:pointConvert];
                [minConvertDisplay setIntegerValue:minConvert];
            }
            else [hrConvertDisplay setDoubleValue:hrConvert];
        }
        
        if ([aNotification object] == lineagePointDisplay){
            if ([lineagePointDisplay intValue] > 0 && [lineagePointDisplay intValue] <= 10000){
                lineagePointSet = [lineagePointDisplay intValue];
                [lineagePointDisplay setIntegerValue:lineagePointSet];
            }
            else [lineagePointDisplay setIntegerValue:lineagePointSet];
        }
        
        if ([aNotification object] == lineagePointRangeDisplay){
            if ([lineagePointRangeDisplay intValue] >= 0 && [lineagePointRangeDisplay intValue] <= 10000){
                lineagePointRangeSet = [lineagePointRangeDisplay intValue];
                [lineagePointRangeDisplay setIntegerValue:lineagePointRangeSet];
            }
            else [lineagePointRangeDisplay setIntegerValue:lineagePointRangeSet];
        }
    }
}

-(IBAction)createExcelFile:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Growth_Curve";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Growth_Curve") != -1){
                extractString = entry.substr(entry.find("GC")+2, entry.find(".txt")-entry.find("GC")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Growth_Curve-GC"+to_string(maxEntryNo)+".txt";
    
    int **cellNumberHold = new int *[34];
    
    for (int counter2 = 0; counter2 < 34; counter2++){
        cellNumberHold [counter2] = new int [horizontalScaleMaxHold+50];
    }
    
    for (int counter2 = 0; counter2 < 34; counter2++){
        for (int counter3 = 0; counter3 < horizontalScaleMaxHold+50; counter3++){
            cellNumberHold [counter2][counter3] = -1;
        }
    }
    
    for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
        cellNumberHold [0][counter3] = counter3+1;
    }
    
    string *nameHold = new string [34];
    int *oldNewData = new int [34];
    
    for (int counter2 = 0; counter2 < 34; counter2++){
        nameHold [counter2] = "nil";
        oldNewData [counter2] = 0;
    }
    
    nameHold [0] = "Time min";
    
    int actualTime = 0;
    int timeEnd = 0;
    int initialValue = 0;
    int entryCount = 1;
    int checkTime = 0;
    int checkTime2 = 0;
    int checkLing = 0;
    int checkCell = 0;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            checkTime = 0;
            checkTime2 = 0;
            checkLing = 0;
            checkCell = 0;
            
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                if (arrayLineageData [counter2][counter3*9+3] == 32){
                    checkTime = arrayLineageData [counter2][counter3*9+2];
                    checkLing = arrayLineageData [counter2][counter3*9+6];
                    checkCell = arrayLineageData [counter2][counter3*9+5];
                    break;
                }
            }
            
            if (checkTime != 0){
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+3] == 31 && arrayLineageData [counter2][counter3*9+4] == checkCell && arrayLineageData [counter2][counter3*9+6] == checkLing){
                        checkTime2 = arrayLineageData [counter2][counter3*9+2];
                        break;
                    }
                }
                
                if (checkTime == checkTime2){
                    oldNewData [entryCount] = 1;
                }
            }
            
            entryCount++;
        }
    }
    
    entryCount = 1;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            timeEnd = arrayTableDetail [counter2][3];
            
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                actualTime = (arrayLineageData [counter2][counter3*9+2]-1)*atoi(arrayLineageDataType [counter2][5].c_str());
                
                if (arrayLineageData [counter2][counter3*9+2] <= timeEnd){
                    if (cellNumberHold [entryCount][actualTime] == -1){
                        cellNumberHold [entryCount][actualTime] = 1;
                    }
                    else{
                        
                        if (oldNewData [entryCount] == 0){
                            cellNumberHold [entryCount][actualTime]++;
                        }
                        else if (arrayLineageData [counter2][counter3*9+3] != 32 && arrayLineageData [counter2][counter3*9+3] != 42 && arrayLineageData [counter2][counter3*9+3] != 52){
                            cellNumberHold [entryCount][actualTime]++;
                        }
                    }
                }
            }
            
            if (normalizeStatusHold == 1){
                for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                    if (cellNumberHold [entryCount][counter3] != 0){
                        initialValue = cellNumberHold [entryCount][counter3];
                        break;
                    }
                }
                
                if (initialValue != 0 && initialValue >= 100){
                    for (int counter3 = 0; counter3 <= horizontalScaleMaxHold; counter3++){
                        if (cellNumberHold [entryCount][counter3] != -1){
                            cellNumberHold [entryCount][counter3] = (int)((cellNumberHold [entryCount][counter3]/(double)initialValue)*100);
                        }
                    }
                }
            }
            
            nameHold [entryCount] = arrayTableMain [counter2][3]+" "+arrayTableMain [counter2][4];
            
            entryCount++;
        }
    }
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100];
    int ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    for (int counter2 = 0; counter2 < entryCount; counter2++){
        //0D--13
        //***09***09***0D0A
        //***09***09
        
        ascIIstring = nameHold [counter2];
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
    }
    
    oin.put(13);
    oin.put(10);
    
    int entryCheck = 0;
    
    for (int counter1 = 0; counter1 <= horizontalScaleMaxHold; counter1++){
        entryCheck = 0;
        
        for (int counter2 = 1; counter2 < entryCount; counter2++){
            if (cellNumberHold [counter2][counter1] != -1) entryCheck = 1;
        }
        
        if (entryCheck == 1){
            for (int counter2 = 0; counter2 < entryCount; counter2++){
                if (cellNumberHold [counter2][counter1] != -1){
                    ascIIstring = to_string(cellNumberHold [counter2][counter1]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                }
                
                oin.put(9);
            }
            
            oin.put(13);
            oin.put(10);
        }
    }
    
    oin.close();
    
    for (int counter2 = 0; counter2 < 34; counter2++){
        delete [] cellNumberHold [counter2];
    }
    
    delete [] cellNumberHold;
    
    delete [] nameHold;
    delete [] arrayAscIIintData;
    delete [] oldNewData;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)createExcelFile2:(id)sender{
    string resultSavePath = "/Users/"+pathNameString+"/Desktop/CLIA_Results";
    mkdir(resultSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    string resultSavePath2 = "/Users/"+pathNameString+"/Desktop/CLIA_Results/Growth_Curve";
    mkdir(resultSavePath2.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
    
    DIR *dir;
    struct dirent *dent;
    
    string entry;
    string extractString;
    int maxEntryNo = 0;
    
    dir = opendir(resultSavePath2.c_str());
    
    if (dir != NULL){
        while ((dent = readdir(dir))){
            entry = dent -> d_name;
            
            if (entry != "." && entry != ".." && entry != ".DS_Store" && (int)entry.find("Growth_Curve") != -1){
                extractString = entry.substr(entry.find("GC")+2, entry.find(".txt")-entry.find("GC")-2);
                
                if (maxEntryNo < atoi(extractString.c_str())) maxEntryNo = atoi(extractString.c_str());
            }
        }
        
        closedir(dir);
    }
    
    maxEntryNo++;
    
    string path = resultSavePath2+"/Growth_CurveLing-GC"+to_string(maxEntryNo)+".txt";
    
    int lingEntryEx = 0;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            lingEntryEx++;
        }
    }
    
    int maxLingNoEx = 0;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                if (arrayLineageData [counter2][counter3*9+6] > maxLingNoEx){
                    maxLingNoEx = arrayLineageData [counter2][counter3*9+6];
                }
            }
        }
    }
    
    int **cellNumberHold = new int *[lingEntryEx+1];
    
    for (int counter2 = 0; counter2 < lingEntryEx+1; counter2++){
        cellNumberHold [counter2] = new int [maxLingNoEx+10];
    }
    
    for (int counter2 = 0; counter2 < lingEntryEx+1; counter2++){
        for (int counter3 = 0; counter3 < maxLingNoEx+10; counter3++){
            cellNumberHold [counter2][counter3] = -1;
        }
    }
    
    for (int counter3 = 1; counter3 <= maxLingNoEx; counter3++){
        cellNumberHold [0][counter3] = counter3;
    }
    
    string *nameHold = new string [lingEntryEx+1];
    int *lineageEntryNo = new int [lingEntryEx+1];
    int *oldNewData = new int [lingEntryEx+1];
    
    for (int counter2 = 0; counter2 < lingEntryEx+1; counter2++){
        nameHold [counter2] = "nil";
        lineageEntryNo [counter2] = 0;
        oldNewData [counter2] = 0;
    }
    
    nameHold [0] = "ID-Treat";
    
    int entryCount = 1;
    int lineageEntryLimit = 0;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            nameHold [entryCount] = arrayTableMain [counter2][3]+" "+arrayTableMain [counter2][4];
            
            lineageEntryLimit = 0;
            
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                if (arrayLineageData [counter2][counter3*9+6] > lineageEntryLimit){
                    lineageEntryLimit = arrayLineageData [counter2][counter3*9+6];
                }
            }
            
            lineageEntryNo [entryCount] = lineageEntryLimit;
            entryCount++;
        }
    }
    
    int checkTime = 0;
    int checkTime2 = 0;
    int checkLing = 0;
    int checkCell = 0;
    int adjustEntry = 0;
    
    entryCount = 1;
    
    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
        if (arraySelectedLing [counter2] == 1){
            checkTime = 0;
            checkTime2 = 0;
            checkLing = 0;
            checkCell = 0;
            
            for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                if (arrayLineageData [counter2][counter3*9+3] == 32){
                    checkTime = arrayLineageData [counter2][counter3*9+2];
                    checkLing = arrayLineageData [counter2][counter3*9+6];
                    checkCell = arrayLineageData [counter2][counter3*9+5];
                    break;
                }
            }
            
            if (checkTime != 0){
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+3] == 31 && arrayLineageData [counter2][counter3*9+4] == checkCell && arrayLineageData [counter2][counter3*9+6] == checkLing){
                        checkTime2 = arrayLineageData [counter2][counter3*9+2];
                        break;
                    }
                }
                
                if (checkTime == checkTime2){
                    oldNewData [entryCount] = 1;
                }
            }
            
            entryCount++;
        }
    }
    
    //for (int counterA = 0; counterA < lingEntryEx+1; counterA++){
    //    cout<<nameHold [counterA]<<" "<<lineageEntryNo [counterA]<<" entry"<<endl;
    //}
    
    entryCount = 1;
    
    if (lineagePointSet >= 1 && lineagePointRangeSet == 0){
        for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
            if (arraySelectedLing [counter2] == 1){
                for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                    if (arrayLineageData [counter2][counter3*9+2] == lineagePointSet){
                        if (cellNumberHold [entryCount][arrayLineageData [counter2][counter3*9+6]] == -1){
                            cellNumberHold [entryCount][arrayLineageData [counter2][counter3*9+6]] = 1;
                        }
                        else{
                            
                            if (oldNewData [entryCount] == 0){
                                cellNumberHold [entryCount][arrayLineageData [counter2][counter3*9+6]]++;
                            }
                            else if (arrayLineageData [counter2][counter3*9+3] != 32 && arrayLineageData [counter2][counter3*9+3] != 42 && arrayLineageData [counter2][counter3*9+3] != 52){
                                cellNumberHold [entryCount][arrayLineageData [counter2][counter3*9+6]]++;
                            }
                        }
                    }
                }
                
                entryCount++;
            }
        }
    }
    else{
        
        if (lineagePointSet >= 1 && lineagePointRangeSet >= lineagePointSet+50){
            int **cellNumberHold2 = new int *[lingEntryEx+1];
            int **cellNumberHold3 = new int *[lingEntryEx+1];
            
            for (int counter3 = 0; counter3 < lingEntryEx+1; counter3++){
                cellNumberHold2 [counter3] = new int [maxLingNoEx+10];
                cellNumberHold3 [counter3] = new int [maxLingNoEx+10];
            }
            
            for (int counter3 = 0; counter3 < lingEntryEx+1; counter3++){
                for (int counter4 = 0; counter4 < maxLingNoEx+10; counter4++){
                    cellNumberHold2 [counter3][counter4] = -1;
                    cellNumberHold3 [counter3][counter4] = -1;
                }
            }
            
            for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                if (arraySelectedLing [counter2] == 1){
                    for (unsigned long counter4 = 0; counter4 < arrayLineageDataEntryHold [counter2]/9; counter4++){
                        if (arrayLineageData [counter2][counter4*9+2] == lineagePointRangeSet){
                            if (cellNumberHold2 [entryCount][arrayLineageData [counter2][counter4*9+6]] == -1){
                                cellNumberHold2 [entryCount][arrayLineageData [counter2][counter4*9+6]] = 1;
                            }
                            else{
                                
                                if (oldNewData [entryCount] == 0){
                                    cellNumberHold2 [entryCount][arrayLineageData [counter2][counter4*9+6]]++;
                                }
                                else if (arrayLineageData [counter2][counter4*9+3] != 32 && arrayLineageData [counter2][counter4*9+3] != 42 && arrayLineageData [counter2][counter4*9+3] != 52){
                                    cellNumberHold2 [entryCount][arrayLineageData [counter2][counter4*9+6]]++;
                                }
                            }
                        }
                    }
                    
                    for (unsigned long counter3 = 0; counter3 < arrayLineageDataEntryHold [counter2]/9; counter3++){
                        if (arrayLineageData [counter2][counter3*9+2] >= lineagePointSet && arrayLineageData [counter2][counter3*9+2] <= lineagePointRangeSet && (arrayLineageData [counter2][counter3*9+3] == 31 || arrayLineageData [counter2][counter3*9+3] == 41 || arrayLineageData [counter2][counter3*9+3] == 51) && cellNumberHold2 [entryCount][arrayLineageData [counter2][counter3*9+6]] != -1){
                            if (cellNumberHold3 [entryCount][arrayLineageData [counter2][counter3*9+6]] == -1){
                                cellNumberHold3 [entryCount][arrayLineageData [counter2][counter3*9+6]] = 1;
                            }
                            else cellNumberHold3 [entryCount][arrayLineageData [counter2][counter3*9+6]]++;
                        }
                    }
                    
                    adjustEntry = 0;
                    
                    for (int counter3 = 1; counter3 <= maxLingNoEx; counter3++){
                        if (cellNumberHold3 [entryCount][counter3] != -1){
                            cellNumberHold [entryCount][adjustEntry] = cellNumberHold3 [entryCount][counter3];
                            adjustEntry++;
                        }
                    }
                    
                    entryCount++;
                }
            }
            
            for (int counter3 = 0; counter3 < lingEntryEx+1; counter3++){
                delete [] cellNumberHold2 [counter3];
                delete [] cellNumberHold3 [counter3];
            }
            
            delete [] cellNumberHold2;
            delete [] cellNumberHold3;
        }
        else{
            
            NSAlert *alert = [[NSAlert alloc] init];
            
            [alert addButtonWithTitle:@"OK"];
            [alert setMessageText:@"End Must Be > Point + 50"];
            [alert setAlertStyle:NSAlertStyleWarning];
            [alert runModal];
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    ofstream oin;
    oin.open(path.c_str(), ios::out | ios::binary);
    
    int *arrayAscIIintData = new int [100];
    int ascIIintDataCount = 0;
    
    ascIIconversion = [[ASCIIconversion alloc] init];
    
    for (int counter2 = 0; counter2 < lingEntryEx+1; counter2++){
        //0D--13
        //***09***09***0D0A
        //***09***09
        
        ascIIstring = nameHold [counter2];
        ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
        
        for (int counter3 = 0; counter3 < ascIIintDataCount; counter3++) oin.put((char)arrayAscIIintData [counter3]);
        
        oin.put(9);
        
        for (int counter3 = 1; counter3 <= maxLingNoEx; counter3++){
            if (lineageEntryNo [counter2] >= counter3){
                if (cellNumberHold [counter2][counter3] != -1){
                    ascIIstring = to_string(cellNumberHold [counter2][counter3]);
                    ascIIintDataCount = [ascIIconversion ascIICode:arrayAscIIintData];
                    
                    for (int counter4 = 0; counter4 < ascIIintDataCount; counter4++) oin.put((char)arrayAscIIintData [counter4]);
                    
                    oin.put(9);
                }
            }
        }
        
        oin.put(13);
        oin.put(10);
    }
    
    oin.close();
    
    for (int counter2 = 0; counter2 < lingEntryEx+1; counter2++){
        delete [] cellNumberHold [counter2];
    }
    
    delete [] cellNumberHold;
    
    delete [] nameHold;
    delete [] arrayAscIIintData;
    delete [] lineageEntryNo;
    delete [] oldNewData;
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)overlayIndividualSet:(id)sender{
    if (individualOverLayHold == 1){
        individualOverLayHold = 0;
        [overlayIndividual setStringValue:@"Overlay"];
    }
    else{
        
        individualOverLayHold = 1;
        [overlayIndividual setStringValue:@"Individual"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)useDisplaySet:(id)sender{
    if (normalizeStatusHold == 1){
        normalizeStatusHold = 0;
        [usePrev setStringValue:@"No"];
    }
    else{
        
        normalizeStatusHold = 1;
        [usePrev setStringValue:@"Yes"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)closeWindow:(id)sender{
    [growthCurveWindow orderOut:self];
    growthCurveWindowOperation = 2;
    growthCurveTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)reDisplayWindow{
    if (growthCurveWindowOperation == 3){
        [growthCurveWindow makeKeyAndOrderFront:self];
        growthCurveWindowOperation = 1;
        [growthCurveTimer invalidate];
    }
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToGrowthCurveController object:nil];
}

@end
