//
//  MainWindowMagnificationController.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-12-05.
//
//

#import "MainWindowMagnificationController.h"

NSString *notificationToMainWindowMagnificationController = @"notificationExecuteMainWindowMagnificationController";

@implementation MainWindowMagnificationController

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMainWindowMagnificationController object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    mainWindowMagController = [[NSWindowController alloc] initWithWindowNibName:@"MainWindowMag"];
    [mainWindowMagController showWindow:nil];
    
    [[NSNotificationCenter defaultCenter] postNotificationName:notificationToMainWindowMagnification object:nil];
}

-(void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [mainWindowMagWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [mainWindowMagWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [optondisplay setStringValue:@"Heat"];
    [drawingOptionDisplay setStringValue:@"None"];
    [unknownDisplay setStringValue:@"Zero"];
    
    if (mainWindowMagOpen == 1){
        [lowXlowDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [0] green:arrayColorRange [1] blue:arrayColorRange [2] alpha:1]];
        [lowXlowDisplay setStringValue:@"0/0"];
        
        [highXHighDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [0] green:arrayColorRange [1] blue:arrayColorRange [2] alpha:1]];
        [highXHighDisplay setStringValue:@"100/100"];
        
        [lowXHighDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [0] green:arrayColorRange [1] blue:arrayColorRange [2] alpha:1]];
        [lowXHighDisplay setStringValue:@"0/100"];
        
        [valueUKDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [0] green:arrayColorRange [1] blue:arrayColorRange [2] alpha:1]];
        [valueUKDisplay setStringValue:@"UD"];
    }
}

-(IBAction)stepperActionLowXLow:(id)sender{
    if ([stepperLowLow intValue] >= 0 && [stepperLowLow intValue] <= 105){
        lowXlow = [stepperLowLow intValue];
        [lowXlowDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [lowXlow] green:arrayColorRange [lowXlow+1] blue:arrayColorRange [lowXlow+2] alpha:1]];
        [lowXlowDisplay setStringValue:@"0/0"];
    }
}

-(IBAction)stepperActionLowXHigh:(id)sender{
    if ([stepperLowHigh intValue] >= 0 && [stepperLowHigh intValue] <= 105){
        lowXhigh = [stepperLowHigh intValue];
        [lowXHighDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [lowXhigh] green:arrayColorRange [lowXhigh+1] blue:arrayColorRange [lowXhigh+2] alpha:1]];
        [lowXHighDisplay setStringValue:@"0/100"];
    }
}

-(IBAction)stepperActionHighXHigh:(id)sender{
    if ([stepperHighHigh intValue] >= 0 && [stepperHighHigh intValue] <= 105){
        highXhigh = [stepperHighHigh intValue];
        [highXHighDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [highXhigh] green:arrayColorRange [highXhigh+1] blue:arrayColorRange [highXhigh+2] alpha:1]];
        [highXHighDisplay setStringValue:@"100/100"];
    }
}

-(IBAction)stepperActionValueUK:(id)sender{
    if ([stepperValueUK intValue] >= 0 && [stepperValueUK intValue] <= 105){
        valueUK = [stepperValueUK intValue];
        [valueUKDisplay setTextColor:[NSColor colorWithCalibratedRed:arrayColorRange [valueUK] green:arrayColorRange [valueUK+1] blue:arrayColorRange [valueUK+2] alpha:1]];
        [valueUKDisplay setStringValue:@"UD"];
    }
}

-(IBAction)optionLineageSelect:(id)sender{
    if (lineageDisplayOption == 0){
        lineageDisplayOption = 1;
        [optondisplay setStringValue:@"Manual"];
    }
    else{
        
        lineageDisplayOption = 0;
        [optondisplay setStringValue:@"Heat"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)optionDrawingSelect:(id)sender{
    if (drawingOptionHold == 0){
        drawingOptionHold = 1;
        [drawingOptionDisplay setStringValue:@"Live"];
    }
    else if (drawingOptionHold == 1){
        drawingOptionHold = 2;
        [drawingOptionDisplay setStringValue:@"Live Expand"];
    }
    else if (drawingOptionHold == 2){
        drawingOptionHold = 3;
        [drawingOptionDisplay setStringValue:@"IF"];
    }
    else if (drawingOptionHold == 3){
        drawingOptionHold = 4;
        [drawingOptionDisplay setStringValue:@"IF Expand"];
    }
    else if (drawingOptionHold == 4){
        drawingOptionHold = 0;
        [drawingOptionDisplay setStringValue:@"None"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)unknownSelect:(id)sender{
    if (unknownOptionHold == 0){
        unknownOptionHold = 1;
        [unknownDisplay setStringValue:@"Sibling (for heat)"];
    }
    else if (unknownOptionHold == 1){
        unknownOptionHold = 0;
        [unknownDisplay setStringValue:@"Zero"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(IBAction)priorityNDSelect:(id)sender{
    if (unknownPriorityHold == 0){
        unknownPriorityHold = 1;
        [priorityNDDisplay setStringValue:@"Line"];
    }
    else if (unknownPriorityHold == 1){
        unknownPriorityHold = 0;
        [priorityNDDisplay setStringValue:@"ND"];
    }
    
    NSSound *sound = [NSSound soundNamed:@"Ping"];
    [sound play];
}

-(void)reDisplayWindow{
    if (mainWindowMagOperation == 3){
        [mainWindowMagWindow makeKeyAndOrderFront:nil];
        mainWindowMagOperation = 1;
        [mainWindowMagTimer invalidate];
    }
}

-(IBAction)closeWindow:(id)sender{
    [mainWindowMagWindow orderOut:nil];
    mainWindowMagOperation = 2;
    mainWindowMagTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMainWindowMagnificationController object:nil];
}

@end
