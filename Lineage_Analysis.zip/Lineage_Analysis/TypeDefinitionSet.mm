//
//  TypeDefinitionSet.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 9/2/16.
//
//

#import "TypeDefinitionSet.h"

NSString *notificationToTypeDefinition = @"notificationExecuteTypeDefinition";

@implementation TypeDefinitionSet

-(id)init{
    self = [super init];
    
    if (self != nil){
        tableCallTDCount = 0;
        tableCurrentTDRowHold = 0;
        rowIndexTDHold = 0;
        tableViewTDCall = 0;
        
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToTypeDefinition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    typeDefinitionWindowController = [[NSWindowController alloc] initWithWindowNibName:@"TypeDefinitionSet"];
    [typeDefinitionWindowController showWindow:self];
    
    tableViewTDCall = 1;
}

- (void)awakeFromNib{
    NSRect screenRect = [[[NSScreen screens] objectAtIndex:0] visibleFrame];
    CGFloat yOrigin = screenRect.origin.y;
    CGFloat yLength = screenRect.size.height;
    
    NSRect windowSize = [typeDefinitionWindow frame];
    CGFloat windowHeight = windowSize.size.height;
    
    CGFloat displayX = 500;
    CGFloat displayY = yLength+yOrigin-20-windowHeight;
    
    if (windowHeight != 0) [typeDefinitionWindow setFrameOrigin:NSMakePoint(displayX, displayY)];
    
    [tableViewTDList setDataSource:self];
    
    typeDefTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
}

-(void)display{
    if (tableCallTDCount == 1){
        tableCallTDCount = 0;
        rowIndexTDHold = tableCurrentTDRowHold;
    }
    
    if (tableCallTDCount > 1) tableCallTDCount = 0;
    
    if (tableViewTDCall == 1){
        tableViewTDCall = 0;
        [tableViewTDList reloadData];
    }
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = typeDefinitionLimit/2;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    string displayData1;
    string displayData2;
    
    if (initialArraySet == 1){
        displayData1 = arrayTypeDefinitionHold2 [rowIndex*2];
        displayData2 = arrayTypeDefinitionHold2 [rowIndex*2+1];
        
        if (displayData1 == "nil") displayData1 = " ";
        if (displayData2 == "nil") displayData2 = " ";
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        [attributes setObject:[NSFont boldSystemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        [attributes setObject:[NSFont systemFontOfSize:10] forKey:NSFontAttributeName];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex{
    tableCallTDCount++;
    tableCurrentTDRowHold = rowIndex;
    
    if (tableCallTDCount == 2) tableCurrentTDRowHold = rowIndexTDHold;
    else if (tableCallTDCount == 1) tableCurrentTDRowHold = rowIndex;
    
    return YES;
}

-(void)tableView:(NSTableView *)aTableView setObjectValue:(id)anObject forTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSString *columnIdentifier = [aTableColumn identifier];
    NSString *objectInfo = anObject;
    
    string stringExtract;
    
    if ([columnIdentifier isEqualToString:@"COL1"] && typeDefinitionLimit/2 > rowIndex){
        string nameCheckString = [objectInfo UTF8String];
        
        if ((int)nameCheckString.length() == 2){
            int stringCheck = 0;
            stringExtract = nameCheckString.substr(0, 1);
            
            if (stringExtract != "A"|| stringExtract != "B"|| stringExtract != "C"|| stringExtract != "D"|| stringExtract != "E"|| stringExtract != "F"|| stringExtract != "G"|| stringExtract != "H"|| stringExtract != "I"|| stringExtract != "J"|| stringExtract != "K"|| stringExtract != "L"|| stringExtract != "M"|| stringExtract != "N"|| stringExtract != "O"|| stringExtract != "P"|| stringExtract != "Q"|| stringExtract != "R"|| stringExtract != "S"|| stringExtract != "T"|| stringExtract != "U"|| stringExtract != "V"|| stringExtract != "W"|| stringExtract != "X"|| stringExtract != "Y"|| stringExtract != "Z"){
                stringCheck++;
            }
            
            stringExtract = nameCheckString.substr(1);
            
            if (stringExtract != "A"|| stringExtract != "B"|| stringExtract != "C"|| stringExtract != "D"|| stringExtract != "E"|| stringExtract != "F"|| stringExtract != "G"|| stringExtract != "H"|| stringExtract != "I"|| stringExtract != "J"|| stringExtract != "K"|| stringExtract != "L"|| stringExtract != "M"|| stringExtract != "N"|| stringExtract != "O"|| stringExtract != "P"|| stringExtract != "Q"|| stringExtract != "R"|| stringExtract != "S"|| stringExtract != "T"|| stringExtract != "U"|| stringExtract != "V"|| stringExtract != "W"|| stringExtract != "X"|| stringExtract != "Y"|| stringExtract != "Z"){
                stringCheck++;
            }
            
            if (stringCheck == 2){
                arrayTypeDefinitionHold2 [rowIndex*2] = nameCheckString;
                
                if (typeDefinitionCount2 < rowIndex+1) typeDefinitionCount2 = (int)rowIndex+1;
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else if ([columnIdentifier isEqualToString:@"COL2"] && typeDefinitionLimit/2 > rowIndex){
        string nameCheckString = [objectInfo UTF8String];
        
        if ((int)nameCheckString.length() <= 50){
            arrayTypeDefinitionHold2 [rowIndex*2+1] = nameCheckString;
            
            if (typeDefinitionCount2 < rowIndex+1) typeDefinitionCount2 = (int)rowIndex+1;
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    
    tableViewTDCall = 1;
}

-(IBAction)saveEntry:(id)sender{
    if (typeDefinitionCount2 != 0){
        for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
            if (arrayTypeDefinitionHold2 [counter1*2] == "nil" || arrayTypeDefinitionHold2 [counter1*2+1] == "nil"){
                arrayTypeDefinitionHold2 [counter1*2] = "nil";
                arrayTypeDefinitionHold2 [counter1*2+1] = "nil";
            }
        }
        
        int entryCount = 0;
        
        for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
            if (arrayTypeDefinitionHold2 [counter1*2] != "nil"){
                arrayTypeDefinitionHold2 [entryCount*2] = arrayTypeDefinitionHold2 [counter1*2];
                arrayTypeDefinitionHold2 [entryCount*2+1] = arrayTypeDefinitionHold2 [counter1*2+1];
                
                entryCount++;
            }
        }
        
        if (entryCount != 0){
            for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
                if (arrayTypeDefinitionHold2 [counter1*2] != "nil" && arrayTypeDefinitionHold2 [counter1*2+1] != "nil" && (arrayTypeDefinitionHold [counter1*2] != arrayTypeDefinitionHold2 [counter1*2] || arrayTypeDefinitionHold [counter1*2+1] != arrayTypeDefinitionHold2 [counter1*2+1])){
                    arrayTypeDefinitionHold [counter1*2] = arrayTypeDefinitionHold2 [counter1*2];
                    arrayTypeDefinitionHold [counter1*2+1] = arrayTypeDefinitionHold2 [counter1*2+1];
                }
            }
            
            int typeDefinitionCountTemp = 0;
            entryCount = 0;
            
            for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
                if (arrayTypeDefinitionHold [counter1*2] != "nil"){
                    arrayTypeDefinitionHold [entryCount*2] = arrayTypeDefinitionHold [counter1*2], typeDefinitionCountTemp++;
                    arrayTypeDefinitionHold [entryCount*2+1] = arrayTypeDefinitionHold [counter1*2+1], typeDefinitionCountTemp++;
                    
                    entryCount++;
                }
            }
            
            for (int counter1 = entryCount; counter1 < typeDefinitionLimit/2; counter1++){
                arrayTypeDefinitionHold [counter1*2] = "nil";
                arrayTypeDefinitionHold [counter1*2+1] = "nil";
            }
            
            typeDefinitionCount = typeDefinitionCountTemp;
            
            string typeDefinitionPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/TypeDefinitionData";
            
            ofstream oin;
            
            oin.open(typeDefinitionPath.c_str(), ios::out);
            for (int counter1 = 0; counter1 < typeDefinitionCount; counter1++) oin<<arrayTypeDefinitionHold [counter1]<<endl;
            oin.close();
            
            for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
                arrayTypeDefinitionHold2 [counter1*2] = arrayTypeDefinitionHold [counter1*2];
                arrayTypeDefinitionHold2 [counter1*2+1] = arrayTypeDefinitionHold [counter1*2+1];
            }
            
            if (typeDefinitionCount+2 > typeDefinitionLimit){
                [self typeDefinitionHoldUpDate];
            }
            
            tableViewTDCall = 1;
            
            NSSound *sound = [NSSound soundNamed:@"Ping"];
            [sound play];
        }
        else{
            
            for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
                arrayTypeDefinitionHold2 [counter1*2] = arrayTypeDefinitionHold [counter1*2];
                arrayTypeDefinitionHold2 [counter1*2+1] = arrayTypeDefinitionHold [counter1*2+1];
            }
            
            tableViewTDCall = 1;
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entry"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)deleteEntry:(id)sender{
    if (typeDefinitionCount != 0){
        if (tableCurrentTDRowHold <= typeDefinitionLimit/2){
            int checkFlag = 0;
            
            if (arrayTypeDefinitionHold [tableCurrentTDRowHold*2] != "nil") checkFlag = 1;
            if (arrayTypeDefinitionHold [tableCurrentTDRowHold*2+1] != "nil") checkFlag = 1;
            if (arrayTypeDefinitionHold2 [tableCurrentTDRowHold*2] != "nil") checkFlag = 1;
            if (arrayTypeDefinitionHold2 [tableCurrentTDRowHold*2+1] != "nil") checkFlag = 1;
            
            if (checkFlag == 1){
                int entryCount = 0;
                
                for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
                    if (tableCurrentTDRowHold != counter1){
                        arrayTypeDefinitionHold [entryCount*2] = arrayTypeDefinitionHold [counter1*2];
                        arrayTypeDefinitionHold [entryCount*2+1] = arrayTypeDefinitionHold [counter1*2+1];
                        
                        arrayTypeDefinitionHold2 [entryCount*2] = arrayTypeDefinitionHold2 [counter1*2];
                        arrayTypeDefinitionHold2 [entryCount*2+1] = arrayTypeDefinitionHold2 [counter1*2+1];
                        
                        entryCount++;
                    }
                }
                
                typeDefinitionCount = entryCount;
                
                for (int counter1 = entryCount/2; counter1 < typeDefinitionLimit/2; counter1++){
                    arrayTypeDefinitionHold [counter1*2] = "nil";
                    arrayTypeDefinitionHold [counter1*2+1] = "nil";
                    arrayTypeDefinitionHold2 [counter1*2] = "nil";
                    arrayTypeDefinitionHold2 [counter1*2+1] = "nil";
                }
                
                string typeDefinitionPath = "/Users/"+pathNameString+"/Desktop/"+"CLIA_LiveCell/"+"11_System_Data/TypeDefinitionData";
                
                if (typeDefinitionCount != 0){
                    ofstream oin;
                    
                    oin.open(typeDefinitionPath.c_str(), ios::out);
                    for (int counter1 = 0; counter1 < typeDefinitionCount; counter1++) oin<<arrayTypeDefinitionHold [counter1]<<endl;
                    oin.close();
                }
                else remove (typeDefinitionPath.c_str());
                
                NSSound *sound = [NSSound soundNamed:@"Ping"];
                [sound play];
                
                tableViewTDCall = 1;
            }
            else{
                
                NSSound *sound = [NSSound soundNamed:@"Hero"];
                [sound play];
            }
        }
        else{
            
            NSSound *sound = [NSSound soundNamed:@"Hero"];
            [sound play];
        }
    }
    else{
        
        NSAlert *alert = [[NSAlert alloc] init];
        [alert addButtonWithTitle:@"OK"];
        [alert setMessageText:@"No Data Entry"];
        [alert setAlertStyle:NSAlertStyleWarning];
        [alert runModal];
        
        NSSound *sound = [NSSound soundNamed:@"Hero"];
        [sound play];
    }
}

-(IBAction)closeWindow:(id)sender{
    [typeDefinitionWindow orderOut:self];
    typeDefTimerAdjustOperation = 2;
    typeDefTimer = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(reDisplayWindow) userInfo:nil repeats:YES];
    [typeDefTimer2 invalidate];
}

-(void)reDisplayWindow{
    if (typeDefTimerAdjustOperation == 3){
        [typeDefinitionWindow makeKeyAndOrderFront:self];
        typeDefTimerAdjustOperation = 1;
        [typeDefTimer invalidate];
        typeDefTimer2 = [NSTimer scheduledTimerWithTimeInterval:0.2 target:self selector:@selector(display) userInfo:nil repeats:YES];
    }
}

-(void)typeDefinitionHoldUpDate{
    string *arrayUpDate = new string [typeDefinitionCount+10];
    
    for (int counter1 = 0; counter1 < typeDefinitionCount; counter1++) arrayUpDate [counter1] = arrayTypeDefinitionHold [counter1];
    
    delete [] arrayTypeDefinitionHold;
    delete [] arrayTypeDefinitionHold2;
    arrayTypeDefinitionHold = new string [typeDefinitionLimit+50];
    arrayTypeDefinitionHold2 = new string [typeDefinitionLimit+50];
    typeDefinitionLimit = typeDefinitionLimit+50;
    typeDefinitionLimit2 = typeDefinitionLimit2+50;
    
    for (int counter1 = 0; counter1 < typeDefinitionCount; counter1++) arrayTypeDefinitionHold2 [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
    
    for (int counter1 = 0; counter1 < typeDefinitionLimit/2; counter1++){
        arrayTypeDefinitionHold2 [counter1*2] = arrayTypeDefinitionHold [counter1*2];
        arrayTypeDefinitionHold2 [counter1*2+1] = arrayTypeDefinitionHold [counter1*2+1];
    }
}

-(void)dealloc{
    if (typeDefTimer) [typeDefTimer invalidate];
    if (typeDefTimer2) [typeDefTimer2 invalidate];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToTypeDefinition object:nil];
}

@end
