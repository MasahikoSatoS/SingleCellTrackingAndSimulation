//
//  CreateNewCellNo.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2021-08-17.
//


#ifndef CREATENEWCELLNO_H
#define CREATENEWCELLNO_H
#import "Controller.h"
#endif

@interface CreateNewCellNo : NSObject{
}

-(int)cellNumberAddition:(int)position;
-(int)cellNumberSubtraction:(int)position;
-(int)cellNumberAdditionSecond:(int)position;

@end
