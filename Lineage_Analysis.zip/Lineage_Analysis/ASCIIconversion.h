//
//  ASCIIconversion.h
//  XY_Map
//
//  Created by Masahiko Sato on 29/05/11, 28/05/13 revised.
//  Copyright 2011 Masahiko Sato. All rights reserved.
//

#ifndef ASCIICONVERSION_H
#define ASCIICONVERSION_H
#import "Controller.h"
#endif

@interface ASCIIconversion : NSObject{
}

-(int)ascIICode:(int*)arrayAscIIintData;
-(void)ascIIConversion2:(int)ascIIint;

@end
