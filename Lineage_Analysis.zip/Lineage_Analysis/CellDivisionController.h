//
//  CellDivisionController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/15/16.
//
//

#ifndef CELLDIVISIONCONTRROLER_H
#define CELLDIVISIONCONTRROLER_H
#import "Controller.h" 
#endif

@interface CellDivisionController : NSObject <NSTextFieldDelegate>{
    int pointConvert; //Point convert
    int minConvert; //Min convert
    int everyConvert; //Every convert
    double hrConvert; //HR convert
    
    IBOutlet NSTextField *verticalHigh;
    IBOutlet NSTextField *verticalDownHigh;
    IBOutlet NSTextField *horizontalLow;
    IBOutlet NSTextField *horizontalHigh;
    IBOutlet NSTextField *belowTypeDisplay;
    IBOutlet NSTextField *pointConvertDisplay;
    IBOutlet NSTextField *minConvertDisplay;
    IBOutlet NSTextField *hrConvertDisplay;
    IBOutlet NSTextField *everyConvertDisplay;
    
    IBOutlet NSWindow *cellDivisionWindow;
    
    NSWindowController *cellDivisionWindowController;
    
    NSTimer *cellDivisionTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)createExcelFile:(id)sender;
-(IBAction)belowTypeSelect:(id)sender;
-(IBAction)closeWindow:(id)sender;

@end
