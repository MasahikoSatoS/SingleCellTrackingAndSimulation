//
//  SimulationTable.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-10-29.
//

#ifndef SIMULATIONTABLE_H
#define SIMULATIONTABLE_H
#import "Controller.h" 
#endif

@interface SimulationTable : NSObject <NSTableViewDataSource>{
    int simOperationTableCount; //Table operation
    int rowSimOperationTable; //Table operation
    
    IBOutlet NSTableView *simulationTable;
    IBOutlet NSTextField *currentNameDisplay;
    IBOutlet NSTextField *currentTreatDisplay;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;


@end
