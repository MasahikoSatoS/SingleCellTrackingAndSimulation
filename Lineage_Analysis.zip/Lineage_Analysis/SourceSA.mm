//
//  SourceSA.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/21/16.
//
//

#import "SourceSA.h"

@implementation SourceSA

-(void)sourceMain{
    if (sourceStatusHold == 0){
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^(void){
            upLoadingProgress = 1;
            
            string imageDisplayPath = trackDataFolderPath+"/"+seriesName+"_Series"+"/"+analysisID+"_TrackData";
            string imageDisplayPath2;
            string imageDisplayPath3;
            string fluorescentNo1;
            string fluorescentNo2;
            string fluorescentNo3;
            string fluorescentNo4;
            string fluorescentNo5;
            string fluorescentNo6;
            string fluorescentName1;
            string fluorescentName2;
            string fluorescentName3;
            string fluorescentName4;
            string fluorescentName5;
            string fluorescentName6;
            string imagePositionString;
            string stringExtract2;
            string lineageAdditionalDataPath;
            string stringValue;
            string analysisDataSavePath;
            string analysisDataSavePath2;
            string extractTemp = "";
            string extractTemp2 = "";
            
            DIR *dir;
            struct dirent *dent;
            DIR *dir2;
            struct dirent *dent2;
            
            ifstream fin;
            
            int identicalDataFound = 0;
            int treatmentStatusCount = 0;
            int timeStart = 0;
            int timeEnd = 0;
            int expandLineFluorescentDataCount = 0;
            int connectLineageRelCount = 0;
            int ifDataTempCount = 0;
            int ifDataMainTempCount = 0;
            int ifDataMainTempLimit = 0;
            int ifFoundFlag = 0;
            int tableMainTempCount = 0;
            int timePointTemp = 0;
            int ifDataHoldCount = 0;
            int lineageDataCount = 0;
            int timeDICEnd = 0;
            int timeFIStart = 0;
            int timeFIEnd = 0;
            int noOfLing = 0;
            int noOfCellStart = 0;
            int noOfCellEnd = 0;
            int noOfTotalCells = 0;
            int noOfDD = 0;
            int noOfTD = 0;
            int noOfHD = 0;
            int noOfMI = 0;
            int noOfFU = 0;
            int noOfCD = 0;
            int ifEntryCount = 0;
            int stepCount = 0;
            int finData [25];
            int fluorescentDataEntryCount = 0;
            int channelNo1 = 0;
            int channelNo2 = 0;
            int channelNo3 = 0;
            int channelNo4 = 0;
            int channelNo5 = 0;
            int channelNo6 = 0;
            int roundCount = 0;
            int roundStart = 0;
            int roundEnd = 0;
            int firstTimeSet = 0;
            int largestEntry = 0;
            int terminationFlag = 0;
            int smallestTimePoint = 0;
            int reviseCellNo = 0;
            int newCellNo = 0;
            int maxLineageNo = 0;
            int ifDataLow = 0;
            int ifDataHigh = 0;
            int ifDataPerARLow = 0;
            int ifDataPerARHigh = 0;
            int ifStatusEntryCount = 0;
            int gravityCenterDataCount = 0;
            int areaDataTempCount = 0;
            int areaDataTempLimit = 0;
            int ifColor1 = 0;
            int ifColor2 = 0;
            int ifColor3 = 0;
            int ifColor4 = 0;
            int ifColor5 = 0;
            int ifColor6 = 0;
            int entryCount = 0;
            int identicalConnectFind = 0;
            int numberOfFusionEntry = 0;
            int remainingFlag = 0;
            int smallestEntry = 0;
            int smallestEntry2 = 0;
            int smallestEntryPosition = 0;
            int entryNo = 0;
            int lengthExpansionFlag = 0;
            int expansionNo = 0;
            int previousLengthHold = 0;
            int findFlag = 0;
            int matchFind = 0;
            int freeSpotFind = 0;
            int readingCount = 0;
            int lingNoTemp = 0;
            int lineageLinkListLengthTemp = 0;
            int smallestValue = 0;
            int cellNoAss = 0;
            int lingNoAss = 0;
            int fluorescentEntryCount = 0;
            
            long sizeForCopy = 0;
            unsigned long readPosition = 0;
            double foldTemp = 0;
            
            fileDeleteCount = 0;
            
            dir = opendir(imageDisplayPath.c_str());
            
            if (dir != NULL){
                string entry; //----Analysis ID----
                
                while ((dent = readdir(dir))){
                    entry = dent -> d_name;
                    
                    if (entry != "." && entry != ".." && entry != ".DS_Store"){
                        if ((int)entry.find("_Connect") != -1){
                            if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                            arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                        }
                    }
                }
                
                closedir(dir);
            }
            
            //----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
            
            string entry2; //----Treat name
            string getString;
            
            struct stat sizeOfFile;
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                imageDisplayPath2 = imageDisplayPath+"/"+arrayFileDelete [counter1];
                
                dir2 = opendir(imageDisplayPath2.c_str());
                
                if (dir2 != NULL){
                    while ((dent2 = readdir(dir2))){
                        entry2 = dent2 -> d_name;
                        
                        if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                            if ((int)entry2.find("LineageData") != -1){
                                identicalDataFound = 0;
                                
                                stringExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("_"));
                                
                                if (lineageDataEntryCount != 0){
                                    for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                                        if (arrayTableMain [counter2][2] == seriesName && arrayTableMain [counter2][3] == analysisID && arrayTableMain [counter2][4] == stringExtract2){
                                            identicalDataFound = 1;
                                            break;
                                        }
                                    }
                                }
                                
                                if (identicalDataFound == 0 && lineageDataEntryCount < 101){
                                    imageDisplayPath3 = imageDisplayPath+"/*TrackingSetting.dat";
                                    
                                    string *arrayIFDataHold = new string [450];
                                    string *arrayTreatmentStatus = new string [200];
                                    treatmentStatusCount = 0;
                                    
                                    for (int counter2 = 0; counter2 < 450; counter2++) arrayIFDataHold [counter2] = "nil";
                                    
                                    //for (int counterA = 0; counterA < 90/9; counterA++){
                                    //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
                                    //    cout<<" arrayIFDataHold "<<counterA<<endl;
                                    //}
                                    
                                    //----Saved condition read----
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        fluorescentNo1 = "";
                                        fluorescentNo2 = "";
                                        fluorescentNo3 = "";
                                        fluorescentNo4 = "";
                                        fluorescentNo5 = "";
                                        fluorescentNo6 = "";
                                        fluorescentName1 = "";
                                        fluorescentName2 = "";
                                        fluorescentName3 = "";
                                        fluorescentName4 = "";
                                        fluorescentName5 = "";
                                        fluorescentName6 = "";
                                        
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString);
                                        getline(fin, getString), fluorescentNo1 = getString;
                                        getline(fin, getString), fluorescentNo2 = getString;
                                        getline(fin, getString), fluorescentNo3 = getString;
                                        getline(fin, getString), fluorescentNo4 = getString;
                                        getline(fin, getString), fluorescentNo5 = getString;
                                        getline(fin, getString), fluorescentNo6 = getString;
                                        getline(fin, getString);
                                        
                                        if (getString == "nil") fluorescentName1 = "";
                                        else fluorescentName1 = getString;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString == "nil") fluorescentName2 = "";
                                        else fluorescentName2 = getString;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString == "nil") fluorescentName3 = "";
                                        else fluorescentName3 = getString;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString == "nil") fluorescentName4 = "";
                                        else fluorescentName4 = getString;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString == "nil") fluorescentName5 = "";
                                        else fluorescentName5 = getString;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString == "nil") fluorescentName6 = "";
                                        else fluorescentName6 = getString;
                                        
                                        for (int counter2 = 0; counter2 < 16; counter2++){
                                            getline(fin, getString);
                                            
                                            if (getString != "IFDATA"){
                                                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = "0", treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                                getline(fin, getString);
                                                arrayTreatmentStatus [treatmentStatusCount] = getString, treatmentStatusCount++;
                                            }
                                            else{
                                                
                                                break;
                                            }
                                        }
                                        
                                        ifDataHoldCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < 450; counter2 = counter2+15){
                                            getline(fin, getString);
                                            
                                            if (getString != "END"){
                                                if (getString != "") arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                else arrayIFDataHold [ifDataHoldCount] = "nil", ifDataHoldCount++;
                                                
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                                getline(fin, getString);
                                                arrayIFDataHold [ifDataHoldCount] = getString, ifDataHoldCount++;
                                            }
                                            else{
                                                
                                                break;
                                            }
                                        }
                                        
                                        fin.close();
                                        
                                        //for (int counterA = 0; counterA < treatmentStatusCount/9; counterA++){
                                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayTreatmentStatus [counterA*9+counterB];
                                        //    cout<<" arrayTreatmentStatus "<<counterA<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < ifDataHoldCount/9; counterA++){
                                        //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayIFDataHold [counterA*9+counterB];
                                        //    cout<<" arrayIFDataHold "<<counterA<<endl;
                                        //}
                                        
                                        imageDisplayPath3 = imageDisplayPath2+"/"+entry2;
                                        
                                        sizeForCopy = 0;
                                        
                                        if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                            sizeForCopy = sizeOfFile.st_size;
                                        }
                                        
                                        //----Lineage data----
                                        int *arrayLineageDataTemp = new int [sizeForCopy+50];
                                        lineageDataCount = 0;
                                        
                                        if (sizeForCopy != 0){
                                            fin.open(imageDisplayPath3.c_str(), ios::in | ios::binary);
                                            
                                            uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                            fin.read((char*)uploadTemp, sizeForCopy+50);
                                            fin.close();
                                            
                                            readPosition = 0;
                                            stepCount = 0;
                                            
                                            do{
                                                
                                                if (stepCount == 0){
                                                    finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                                    finData [1] = uploadTemp [readPosition], readPosition++;
                                                    finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                                    finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                                    finData [4] = uploadTemp [readPosition], readPosition++;
                                                    finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                                    finData [6] = uploadTemp [readPosition], readPosition++;
                                                    finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                                    finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                                    finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                                    finData [10] = uploadTemp [readPosition], readPosition++;
                                                    finData [11] = uploadTemp [readPosition], readPosition++;
                                                    finData [12] = uploadTemp [readPosition], readPosition++;
                                                    finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                                    finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                                    finData [15] = uploadTemp [readPosition], readPosition++;
                                                    finData [16] = uploadTemp [readPosition], readPosition++;
                                                    finData [17] = uploadTemp [readPosition], readPosition++;
                                                    finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                                    finData [19] = uploadTemp [readPosition], readPosition++;
                                                    finData [20] = uploadTemp [readPosition], readPosition++;
                                                    finData [21] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                                                    finData [22] = uploadTemp [readPosition], readPosition++;
                                                    finData [23] = uploadTemp [readPosition], readPosition++;
                                                    finData [24] = uploadTemp [readPosition], readPosition++; //--12 Ling no Fuse
                                                    
                                                    if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                                    else finData [2] = finData [1]*256+finData [2];
                                                    
                                                    if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                                    else finData [5] = finData [4]*256+finData [5];
                                                    
                                                    finData [7] = finData [6]*256+finData [7];
                                                    
                                                    if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                                    else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                                    
                                                    if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                                    else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                                    
                                                    finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                                    finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                                    
                                                    if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                    else{
                                                        
                                                        arrayLineageDataTemp [lineageDataCount] = finData [2], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [5], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [7], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [8], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [13], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [18], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [21], lineageDataCount++;
                                                        arrayLineageDataTemp [lineageDataCount] = finData [24], lineageDataCount++;
                                                    }
                                                }
                                                
                                            } while (stepCount != 3);
                                            
                                            delete [] uploadTemp;
                                            
                                            fin.close();
                                        }
                                        
                                        //for (int counterA = 0; counterA < lineageDataCount/8; counterA++){
                                        //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageDataTemp [counterA*8+counterB];
                                        //    cout<<" arrayLineageDataTemp "<<counterA<<endl;
                                        //}
                                        
                                        //----IF data and Area data----
                                        timeStart = 0;
                                        timeEnd = 0;
                                        timeDICEnd = 0;
                                        timeFIStart = 0;
                                        timeFIEnd = 0;
                                        
                                        extractTemp = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("_Connect"));
                                        
                                        for (int counter2 = 0; counter2 < treatmentStatusCount/9; counter2++){
                                            if (arrayTreatmentStatus [counter2*9] == extractTemp){
                                                timeStart = atoi(arrayTreatmentStatus [counter2*9+4].c_str());
                                                timeEnd = atoi(arrayTreatmentStatus [counter2*9+5].c_str());
                                                timeDICEnd = atoi(arrayTreatmentStatus [counter2*9+6].c_str());
                                                timeFIStart = atoi(arrayTreatmentStatus [counter2*9+7].c_str());
                                                timeFIEnd = atoi(arrayTreatmentStatus [counter2*9+8].c_str());
                                                break;
                                            }
                                        }
                                        
                                        //cout<<timeStart<<" "<<timeEnd<<" "<<timeDICEnd<<" "<<timeFIStart<<" "<<timeFIEnd<<" time"<<endl;
                                        
                                        if (timeEnd == timeDICEnd && timeDICEnd < timeFIEnd) timeEnd = timeFIEnd;
                                        
                                        int *arrayIFDataMainTemp = new int [1000];
                                        ifDataMainTempCount = 0;
                                        ifDataMainTempLimit = 1000;
                                        
                                        int *arrayAreaDataTemp = new int [lineageDataCount+500];
                                        areaDataTempCount = 0;
                                        areaDataTempLimit = lineageDataCount+500;
                                        
                                        progressTiming = 1;
                                        progressValue = timeEnd-timeStart+2;
                                        
                                        do usleep(10);
                                        while (progressTiming == 1);
                                        
                                        entryCount = 0;
                                        
                                        for (int counter3 = timeStart; counter3 <= timeEnd; counter3++){
                                            entryCount++;
                                            
                                            progressTiming = 3;
                                            progressValue = entryCount;
                                            
                                            usleep(1000);
                                            
                                            imagePositionString = to_string(counter3);
                                            
                                            if (imagePositionString.length() == 1) imagePositionString = "000"+imagePositionString;
                                            else if (imagePositionString.length() == 2) imagePositionString = "00"+imagePositionString;
                                            else if (imagePositionString.length() == 3) imagePositionString = "0"+imagePositionString;
                                            
                                            extractTemp = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("_Connect"));
                                            
                                            imageDisplayPath3 = imageDisplayPath2+"/"+imagePositionString+"_"+analysisID+"_"+extractTemp+"_ConnectLineageRel";
                                            
                                            sizeForCopy = 0;
                                            
                                            if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            int *connectLineageRelData = new int [sizeForCopy+50];
                                            connectLineageRelCount = 0;
                                            
                                            //----Master Data upLoad----
                                            if (sizeForCopy != 0){
                                                fin.open(imageDisplayPath3.c_str(), ios::in | ios::binary);
                                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                fin.close();
                                                
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Ling no
                                                        finData [3] = uploadTemp [readPosition], readPosition++;
                                                        finData [4] = uploadTemp [readPosition], readPosition++;
                                                        finData [5] = uploadTemp [readPosition], readPosition++; //--3 Connect no
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Image no
                                                        finData [8] = uploadTemp [readPosition], readPosition++; //--5 +-
                                                        finData [9] = uploadTemp [readPosition], readPosition++;
                                                        finData [10] = uploadTemp [readPosition], readPosition++;
                                                        finData [11] = uploadTemp [readPosition], readPosition++;
                                                        finData [12] = uploadTemp [readPosition], readPosition++; //--6 Cell no
                                                        finData [13] = uploadTemp [readPosition], readPosition++; //--7 Target
                                                        finData [14] = uploadTemp [readPosition], readPosition++; //--8 Res
                                                        
                                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                        finData [5] = finData [3]*65536+finData [4]*256+finData [5];
                                                        finData [7] = finData [6]*256+finData [7];
                                                        
                                                        if (finData [8] == 1) finData [12] = (finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12])*-1;
                                                        else finData [12] = finData [9]*16777216+finData [10]*65536+finData [11]*256+finData [12];
                                                        
                                                        if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            connectLineageRelData [connectLineageRelCount] = finData [2], connectLineageRelCount++;
                                                            connectLineageRelData [connectLineageRelCount] = finData [5], connectLineageRelCount++;
                                                            connectLineageRelData [connectLineageRelCount] = finData [7], connectLineageRelCount++;
                                                            connectLineageRelData [connectLineageRelCount] = finData [12], connectLineageRelCount++;
                                                            connectLineageRelData [connectLineageRelCount] = finData [13], connectLineageRelCount++;
                                                            connectLineageRelData [connectLineageRelCount] = finData [14], connectLineageRelCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                delete [] uploadTemp;
                                            }
                                            
                                            imageDisplayPath3 = imageDisplayPath2+"/"+imagePositionString+"_"+analysisID+"_"+extractTemp+"_ExtendAreaData";
                                            
                                            sizeForCopy = 0;
                                            
                                            if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                                sizeForCopy = sizeOfFile.st_size;
                                            }
                                            
                                            int *expandLineFluorescentData = new int [sizeForCopy+50];
                                            expandLineFluorescentDataCount = 0;
                                            
                                            fin.open(imageDisplayPath3.c_str(), ios::in | ios::binary);
                                            
                                            if (fin.is_open()){
                                                uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                                fin.read((char*)uploadTemp, sizeForCopy+50);
                                                fin.close();
                                                
                                                readPosition = 0;
                                                stepCount = 0;
                                                
                                                do{
                                                    
                                                    if (stepCount == 0){
                                                        finData [0] = uploadTemp [readPosition], readPosition++;
                                                        finData [1] = uploadTemp [readPosition], readPosition++;
                                                        finData [2] = uploadTemp [readPosition], readPosition++; //--1 Connect No
                                                        finData [3] = uploadTemp [readPosition], readPosition++; //--2 Channel No
                                                        finData [4] = uploadTemp [readPosition], readPosition++; //--3 Average Value
                                                        finData [5] = uploadTemp [readPosition], readPosition++;
                                                        finData [6] = uploadTemp [readPosition], readPosition++;
                                                        finData [7] = uploadTemp [readPosition], readPosition++; //--4 Total pix
                                                        
                                                        finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                        finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                        
                                                        if (finData [2] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 3;
                                                        else{
                                                            
                                                            expandLineFluorescentData [expandLineFluorescentDataCount] = finData [2], expandLineFluorescentDataCount++;
                                                            expandLineFluorescentData [expandLineFluorescentDataCount] = finData [3], expandLineFluorescentDataCount++;
                                                            expandLineFluorescentData [expandLineFluorescentDataCount] = finData [4], expandLineFluorescentDataCount++;
                                                            expandLineFluorescentData [expandLineFluorescentDataCount] = finData [7], expandLineFluorescentDataCount++;
                                                        }
                                                    }
                                                    
                                                } while (stepCount != 3);
                                                
                                                delete [] uploadTemp;
                                            }
                                            
                                            //for (int counterA = 0; counterA < expandLineFluorescentDataCount/4; counterA++){
                                            //    for (int counterB = 0; counterB < 4; counterB++) cout<<" "<<expandLineFluorescentData [counterA*4+counterB];
                                            //    cout<<" expandLineFluorescentData "<<counterA+1<<" "<<counter3<<endl;
                                            //}
                                            
                                            //for (int counterA = 0; counterA < connectLineageRelCount/6; counterA++){
                                            //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<connectLineageRelData [counterA*6+counterB];
                                            //    cout<<" ConnectLineageRel "<<counterA+1<<endl;
                                            //}
                                            
                                            if (expandLineFluorescentDataCount != 0){
                                                ifColor1 = 0;
                                                ifColor2 = 0;
                                                ifColor3 = 0;
                                                ifColor4 = 0;
                                                ifColor5 = 0;
                                                ifColor6 = 0;
                                                
                                                for (int counter4 = 0; counter4 < ifDataHoldCount/15; counter4++){
                                                    if (atoi(arrayIFDataHold [counter4*15+14].c_str()) != 0 && atoi(arrayIFDataHold [counter4*15+14].c_str()) <= counter3){
                                                        ifColor1 = atoi(arrayIFDataHold [counter4*15+7].c_str());
                                                        ifColor2 = atoi(arrayIFDataHold [counter4*15+8].c_str());
                                                        ifColor3 = atoi(arrayIFDataHold [counter4*15+9].c_str());
                                                        ifColor4 = atoi(arrayIFDataHold [counter4*15+10].c_str());
                                                        ifColor5 = atoi(arrayIFDataHold [counter4*15+11].c_str());
                                                        ifColor6 = atoi(arrayIFDataHold [counter4*15+12].c_str());
                                                    }
                                                }
                                                
                                                int *arrayIFDataTemp = new int [expandLineFluorescentDataCount*4+100];
                                                ifDataTempCount = 0;
                                                
                                                for (int counter4 = 0; counter4 < connectLineageRelCount/6; counter4++){
                                                    for (int counter5 = 0; counter5 < expandLineFluorescentDataCount/4; counter5++){
                                                        if (expandLineFluorescentData [counter5*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter5*4+1] <= 3 || (expandLineFluorescentData [counter5*4+1] > 3 && timeEnd > timeDICEnd))){
                                                            identicalConnectFind = 0;
                                                            
                                                            for (int counter6 = 0; counter6 < ifDataTempCount/22; counter6++){
                                                                if (arrayIFDataTemp [counter6*22] == connectLineageRelData [counter4*6+3] && arrayIFDataTemp [counter6*22+1] == connectLineageRelData [counter4*6]){
                                                                    identicalConnectFind = 1;
                                                                }
                                                            }
                                                            
                                                            if (identicalConnectFind == 0){
                                                                arrayIFDataTemp [ifDataTempCount] = connectLineageRelData [counter4*6+3], ifDataTempCount++;
                                                                arrayIFDataTemp [ifDataTempCount] = connectLineageRelData [counter4*6], ifDataTempCount++;
                                                                arrayIFDataTemp [ifDataTempCount] = counter3, ifDataTempCount++;
                                                                
                                                                if (expandLineFluorescentData [counter5*4+1] <= 3) arrayIFDataTemp [ifDataTempCount] = 1, ifDataTempCount++;
                                                                else arrayIFDataTemp [ifDataTempCount] = 2, ifDataTempCount++;
                                                                
                                                                for (int counter6 = 0; counter6 < expandLineFluorescentDataCount/4; counter6++){
                                                                    if (expandLineFluorescentData [counter6*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter6*4+1] == 1 || expandLineFluorescentData [counter6*4+1] == 7)){
                                                                        if (expandLineFluorescentData [counter6*4+1] == 1) arrayIFDataTemp [ifDataTempCount] = atoi(fluorescentNo1.c_str()), ifDataTempCount++;
                                                                        else arrayIFDataTemp [ifDataTempCount] = ifColor1, ifDataTempCount++;
                                                                        
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+2], ifDataTempCount++;
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+3], ifDataTempCount++;
                                                                        
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                ifFoundFlag = 0;
                                                                
                                                                for (int counter6 = 0; counter6 < expandLineFluorescentDataCount/4; counter6++){
                                                                    if (expandLineFluorescentData [counter6*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter6*4+1] == 2 || expandLineFluorescentData [counter6*4+1] == 8)){
                                                                        if (expandLineFluorescentData [counter6*4+1] == 2) arrayIFDataTemp [ifDataTempCount] = atoi(fluorescentNo2.c_str()), ifDataTempCount++;
                                                                        else arrayIFDataTemp [ifDataTempCount] = ifColor2, ifDataTempCount++;
                                                                        
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+2], ifDataTempCount++;
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+3], ifDataTempCount++;
                                                                        
                                                                        ifFoundFlag = 1;
                                                                        
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                if (ifFoundFlag == 0){
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                }
                                                                
                                                                ifFoundFlag = 0;
                                                                
                                                                for (int counter6 = 0; counter6 < expandLineFluorescentDataCount/4; counter6++){
                                                                    if (expandLineFluorescentData [counter6*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter6*4+1] == 3 || expandLineFluorescentData [counter6*4+1] == 9)){
                                                                        if (expandLineFluorescentData [counter6*4+1] == 3) arrayIFDataTemp [ifDataTempCount] = atoi(fluorescentNo3.c_str()), ifDataTempCount++;
                                                                        else arrayIFDataTemp [ifDataTempCount] = ifColor3, ifDataTempCount++;
                                                                        
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+2], ifDataTempCount++;
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+3], ifDataTempCount++;
                                                                        
                                                                        ifFoundFlag = 1;
                                                                        
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                if (ifFoundFlag == 0){
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                }
                                                                
                                                                ifFoundFlag = 0;
                                                                
                                                                for (int counter6 = 0; counter6 < expandLineFluorescentDataCount/4; counter6++){
                                                                    if (expandLineFluorescentData [counter6*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter6*4+1] == 4 || expandLineFluorescentData [counter6*4+1] == 10)){
                                                                        if (expandLineFluorescentData [counter6*4+1] == 4) arrayIFDataTemp [ifDataTempCount] = atoi(fluorescentNo4.c_str()), ifDataTempCount++;
                                                                        else arrayIFDataTemp [ifDataTempCount] = ifColor4, ifDataTempCount++;
                                                                        
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+2], ifDataTempCount++;
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+3], ifDataTempCount++;
                                                                        
                                                                        ifFoundFlag = 1;
                                                                        
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                if (ifFoundFlag == 0){
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                }
                                                                
                                                                ifFoundFlag = 0;
                                                                
                                                                for (int counter6 = 0; counter6 < expandLineFluorescentDataCount/4; counter6++){
                                                                    if (expandLineFluorescentData [counter6*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter6*4+1] == 5 || expandLineFluorescentData [counter6*4+1] == 11)){
                                                                        if (expandLineFluorescentData [counter6*4+1] == 5) arrayIFDataTemp [ifDataTempCount] = atoi(fluorescentNo5.c_str()), ifDataTempCount++;
                                                                        else arrayIFDataTemp [ifDataTempCount] = ifColor5, ifDataTempCount++;
                                                                        
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+2], ifDataTempCount++;
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+3], ifDataTempCount++;
                                                                        
                                                                        ifFoundFlag = 1;
                                                                        
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                if (ifFoundFlag == 0){
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                }
                                                                
                                                                ifFoundFlag = 0;
                                                                
                                                                for (int counter6 = 0; counter6 < expandLineFluorescentDataCount/4; counter6++){
                                                                    if (expandLineFluorescentData [counter6*4] == connectLineageRelData [counter4*6+1] && (expandLineFluorescentData [counter6*4+1] == 6 || expandLineFluorescentData [counter6*4+1] == 12)){
                                                                        if (expandLineFluorescentData [counter6*4+1] == 6) arrayIFDataTemp [ifDataTempCount] = atoi(fluorescentNo6.c_str()), ifDataTempCount++;
                                                                        else arrayIFDataTemp [ifDataTempCount] = ifColor6, ifDataTempCount++;
                                                                        
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+2], ifDataTempCount++;
                                                                        arrayIFDataTemp [ifDataTempCount] = expandLineFluorescentData [counter6*4+3], ifDataTempCount++;
                                                                        
                                                                        ifFoundFlag = 1;
                                                                        
                                                                        break;
                                                                    }
                                                                }
                                                                
                                                                if (ifFoundFlag == 0){
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                    arrayIFDataTemp [ifDataTempCount] = 0, ifDataTempCount++;
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                                
                                                //for (int counterA = 0; counterA < ifDataTempCount/13; counterA++){
                                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFDataTemp [counterA*13+counterB];
                                                //    cout<<" arrayIFDataTemp "<<counterA+1<<endl;
                                                //}
                                                
                                                if (ifDataMainTempCount+ifDataTempCount > ifDataMainTempLimit){
                                                    int *arrayUpDate = new int [ifDataMainTempCount+10];
                                                    
                                                    for (int counter4 = 0; counter4 < ifDataMainTempCount; counter4++) arrayUpDate [counter4] = arrayIFDataMainTemp [counter4];
                                                    
                                                    delete [] arrayIFDataMainTemp;
                                                    arrayIFDataMainTemp = new int [ifDataMainTempCount+ifDataTempCount+10000];
                                                    ifDataMainTempLimit = ifDataMainTempCount+ifDataTempCount+10000;
                                                    
                                                    for (int counter4 = 0; counter4 < ifDataMainTempCount; counter4++) arrayIFDataMainTemp [counter4] = arrayUpDate [counter4];
                                                    delete [] arrayUpDate;
                                                }
                                                
                                                for (int counter4 = 0; counter4 < ifDataTempCount/22; counter4++){
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+1], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+2], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+3], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+4], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+5], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+6], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+7], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+8], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+9], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+10], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+11], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+12], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+13], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+14], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+15], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+16], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+17], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+18], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+19], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+20], ifDataMainTempCount++;
                                                    arrayIFDataMainTemp [ifDataMainTempCount] = arrayIFDataTemp [counter4*22+21], ifDataMainTempCount++;
                                                }
                                                
                                                delete [] arrayIFDataTemp;
                                            }
                                            
                                            delete [] expandLineFluorescentData;
                                            
                                            if (counter3 <= timeDICEnd){
                                                imageDisplayPath3 = imageDisplayPath2+"/"+imagePositionString+"_"+analysisID+"_"+extractTemp+"_MasterDataRevise";
                                                
                                                sizeForCopy = 0;
                                                
                                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                                    sizeForCopy = sizeOfFile.st_size;
                                                }
                                                
                                                int *gravityCenterData = new int [sizeForCopy+50];
                                                gravityCenterDataCount = 0;
                                                
                                                fin.open(imageDisplayPath3.c_str(), ios::in | ios::binary);
                                                
                                                if (fin.is_open()){
                                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                                    fin.close();
                                                    
                                                    readPosition = 0;
                                                    stepCount = 0;
                                                    
                                                    do{
                                                        
                                                        if (stepCount == 0){
                                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                            
                                                            readPosition = readPosition+9;
                                                            
                                                            finData [1] = finData [0]*256+finData [1];
                                                            finData [3] = finData [2]*256+finData [3];
                                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                            
                                                            if (finData [1] == 0 && finData [3] == 0 && finData [7] == 0) stepCount = 1;
                                                        }
                                                        else if (stepCount == 1){
                                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                                            finData [2] = uploadTemp [readPosition], readPosition++; //--1
                                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                            finData [4] = uploadTemp [readPosition], readPosition++; //--3
                                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                            finData [8] = uploadTemp [readPosition], readPosition++;
                                                            finData [9] = uploadTemp [readPosition], readPosition++; //--5
                                                            finData [10] = uploadTemp [readPosition], readPosition++; //--6
                                                            
                                                            finData [2] = finData [0]*65536+finData [1]*256+finData [2];
                                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                                            finData [9] = finData [8]*256+finData [9];
                                                            
                                                            if (finData [2] == 0 && finData [7] == 0 && finData [9] == 0) stepCount = 2;
                                                        }
                                                        else if (stepCount == 2){
                                                            finData [0] = uploadTemp [readPosition], readPosition++;
                                                            finData [1] = uploadTemp [readPosition], readPosition++; //--1
                                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                                            finData [3] = uploadTemp [readPosition], readPosition++; //--2
                                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                                            finData [5] = uploadTemp [readPosition], readPosition++;
                                                            finData [6] = uploadTemp [readPosition], readPosition++; //--3
                                                            finData [7] = uploadTemp [readPosition], readPosition++; //--4
                                                            finData [8] = uploadTemp [readPosition], readPosition++;
                                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                                            finData [10] = uploadTemp [readPosition], readPosition++; //--5
                                                            finData [11] = uploadTemp [readPosition], readPosition++; //--6
                                                            
                                                            finData [1] = finData [0]*256+finData [1];
                                                            finData [3] = finData [2]*256+finData [3];
                                                            finData [6] = finData [4]*65536+finData [5]*256+finData [6];
                                                            finData [10] = finData [8]*65536+finData [9]*256+finData [10];
                                                            
                                                            if (finData [1] == 0 && finData [3] == 0) stepCount = 3;
                                                            else{
                                                                
                                                                gravityCenterData [gravityCenterDataCount] = finData [1], gravityCenterDataCount++;
                                                                gravityCenterData [gravityCenterDataCount] = finData [3], gravityCenterDataCount++;
                                                                gravityCenterData [gravityCenterDataCount] = finData [6], gravityCenterDataCount++;
                                                                gravityCenterData [gravityCenterDataCount] = finData [7], gravityCenterDataCount++;
                                                                gravityCenterData [gravityCenterDataCount] = finData [10], gravityCenterDataCount++;
                                                                gravityCenterData [gravityCenterDataCount] = finData [11], gravityCenterDataCount++;
                                                            }
                                                        }
                                                        
                                                    } while (stepCount != 3);
                                                    
                                                    delete [] uploadTemp;
                                                }
                                                
                                                for (int counter4 = 0; counter4 < gravityCenterDataCount/6; counter4++){
                                                    if (areaDataTempCount+10 > areaDataTempLimit){
                                                        int *arrayUpDate = new int [areaDataTempCount+10];
                                                        
                                                        for (int counter5 = 0; counter5 < areaDataTempCount; counter5++) arrayUpDate [counter5] = arrayAreaDataTemp [counter5];
                                                        
                                                        delete [] arrayAreaDataTemp;
                                                        areaDataTempLimit = areaDataTempCount+5000;
                                                        arrayAreaDataTemp = new int [areaDataTempLimit];
                                                        
                                                        for (int counter5 = 0; counter5 < areaDataTempCount; counter5++) arrayAreaDataTemp [counter5] = arrayUpDate [counter5];
                                                        delete [] arrayUpDate;
                                                    }
                                                    
                                                    for (int counter5 = 0; counter5 < connectLineageRelCount/6; counter5++){
                                                        if (gravityCenterData [counter4*6+4] == connectLineageRelData [counter5*6+1]){
                                                            arrayAreaDataTemp [areaDataTempCount] = connectLineageRelData [counter5*6], areaDataTempCount++;
                                                            arrayAreaDataTemp [areaDataTempCount] = connectLineageRelData [counter5*6+3], areaDataTempCount++;
                                                            arrayAreaDataTemp [areaDataTempCount] = gravityCenterData [counter4*6+2], areaDataTempCount++;
                                                            arrayAreaDataTemp [areaDataTempCount] = gravityCenterData [counter4*6+3], areaDataTempCount++;
                                                            arrayAreaDataTemp [areaDataTempCount] = connectLineageRelData [counter5*6+2], areaDataTempCount++;
                                                            break;
                                                        }
                                                    }
                                                }
                                                
                                                delete [] gravityCenterData;
                                                delete [] connectLineageRelData;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < areaDataTempCount/5; counterA++){
                                        //    for (int counterB = 0; counterB < 5; counterB++) cout<<" "<<arrayAreaDataTemp [counterA*5+counterB];
                                        //    cout<<" arrayAreaDataTemp "<<counterA+1<<endl;
                                        //}
                                        
                                        //for (int counterA = 0; counterA < ifDataMainTempCount/13; counterA++){
                                        //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFDataMainTemp [counterA*13+counterB];
                                        //    cout<<" arrayIFDataMainTemp "<<counterA+1<<endl;
                                        //}
                                        
                                        //----Main Table----
                                        tableMainTempCount = 0;
                                        
                                        string *arrayTableMainTemp = new string [ifDataHoldCount+20];
                                        
                                        arrayTableMainTemp [tableMainTempCount] = to_string(lineageDataEntryCount+1), tableMainTempCount++;
                                        arrayTableMainTemp [tableMainTempCount] = "SO", tableMainTempCount++;
                                        arrayTableMainTemp [tableMainTempCount] = seriesName, tableMainTempCount++;
                                        arrayTableMainTemp [tableMainTempCount] = analysisID, tableMainTempCount++;
                                        arrayTableMainTemp [tableMainTempCount] = extractTemp, tableMainTempCount++;
                                        
                                        fluorescentEntryCount = 0;
                                        
                                        arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentNo1 != "0"){
                                            arrayTableMainTemp [tableMainTempCount] = fluorescentName1, tableMainTempCount++;
                                            fluorescentEntryCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentNo2 != "0"){
                                            arrayTableMainTemp [tableMainTempCount] = fluorescentName2, tableMainTempCount++;
                                            fluorescentEntryCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentNo3 != "0"){
                                            arrayTableMainTemp [tableMainTempCount] = fluorescentName3, tableMainTempCount++;
                                            fluorescentEntryCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentNo4 != "0"){
                                            arrayTableMainTemp [tableMainTempCount] = fluorescentName4, tableMainTempCount++;
                                            fluorescentEntryCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentNo5 != "0"){
                                            arrayTableMainTemp [tableMainTempCount] = fluorescentName5, tableMainTempCount++;
                                            fluorescentEntryCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentNo6 != "0"){
                                            arrayTableMainTemp [tableMainTempCount] = fluorescentName6, tableMainTempCount++;
                                            fluorescentEntryCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (fluorescentEntryCount != 0) arrayTableMainTemp [tableMainTempCount-7] = to_string(fluorescentEntryCount);
                                        
                                        ifEntryCount = 0;
                                        
                                        for (int counter2 = 0; counter2 < ifDataHoldCount/15; counter2++){
                                            if (arrayIFDataHold [counter2*15] != "nil") ifEntryCount++;
                                        }
                                        
                                        if (ifDataHoldCount != 0 && timeEnd == timeFIEnd && timeFIEnd > timeDICEnd){
                                            arrayTableMainTemp [tableMainTempCount] = to_string(ifEntryCount), tableMainTempCount++;
                                        }
                                        else arrayTableMainTemp [tableMainTempCount] = "nil", tableMainTempCount++;
                                        
                                        if (ifDataHoldCount != 0 && timeEnd == timeFIEnd && timeFIEnd > timeDICEnd){
                                            for (int counter2 = 0; counter2 < ifEntryCount; counter2++){
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+13], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+1], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+2], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+3], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+4], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+5], tableMainTempCount++;
                                                arrayTableMainTemp [tableMainTempCount] = arrayIFDataHold [counter2*15+6], tableMainTempCount++;
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA < 1; counterA++){
                                        //    for (int counterB = 0; counterB < tableMainTempCount; counterB++) cout<<" "<<arrayTableMainTemp [counterA*tableMainTempCount+counterB];
                                        //    cout<<" arrayTableMain "<<counterA+1<<endl;
                                        //}
                                        
                                        //----IF Timeline data----
                                        int *arrayIFTimeLineDataTemp = new int [(timeEnd+10)*9];
                                        
                                        for (int counter2 = 0; counter2 <= timeEnd; counter2++){
                                            arrayIFTimeLineDataTemp [counter2*9] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+1] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+2] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+3] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+4] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+5] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+6] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+7] = 0;
                                            arrayIFTimeLineDataTemp [counter2*9+8] = 0;
                                        }
                                        
                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                            timePointTemp = arrayIFDataMainTemp [counter2*22+2];
                                            arrayIFTimeLineDataTemp [timePointTemp*9] = timePointTemp;
                                            
                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                arrayIFTimeLineDataTemp [timePointTemp*9+1] = -1;
                                                
                                                if (arrayIFDataMainTemp [counter2*22+4] != 0){
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+2]++;
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(fluorescentNo1.c_str());
                                                }
                                                else arrayIFTimeLineDataTemp [timePointTemp*9+3] = 0;
                                                
                                                if (arrayIFDataMainTemp [counter2*22+7] != 0){
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+2]++;
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(fluorescentNo2.c_str());
                                                }
                                                else arrayIFTimeLineDataTemp [timePointTemp*9+4] = 0;
                                                
                                                if (arrayIFDataMainTemp [counter2*22+10] != 0){
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+2]++;
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(fluorescentNo3.c_str());
                                                }
                                                else arrayIFTimeLineDataTemp [timePointTemp*9+5] = 0;
                                                
                                                if (arrayIFDataMainTemp [counter2*22+13] != 0){
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+2]++;
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(fluorescentNo4.c_str());
                                                }
                                                else arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                
                                                if (arrayIFDataMainTemp [counter2*22+16] != 0){
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+2]++;
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+7] = atoi(fluorescentNo5.c_str());
                                                }
                                                else arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                
                                                if (arrayIFDataMainTemp [counter2*22+19] != 0){
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+2]++;
                                                    arrayIFTimeLineDataTemp [timePointTemp*9+8] = atoi(fluorescentNo6.c_str());
                                                }
                                                else arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                            }
                                            else{
                                                
                                                for (int counter3 = 0; counter3 < ifEntryCount; counter3++){
                                                    if (atoi(arrayIFDataHold [counter3*15+14].c_str()) <= timePointTemp){
                                                        if (counter3 == ifEntryCount-1){
                                                            arrayIFTimeLineDataTemp [timePointTemp*9+1] = atoi(arrayIFDataHold [counter3*15].c_str());
                                                            arrayIFTimeLineDataTemp [timePointTemp*9+2] = atoi(arrayIFDataHold [counter3*15+13].c_str());
                                                            
                                                            if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 6){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(arrayIFDataHold [counter3*15+10].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = atoi(arrayIFDataHold [counter3*15+11].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = atoi(arrayIFDataHold [counter3*15+12].c_str());
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 5){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(arrayIFDataHold [counter3*15+10].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = atoi(arrayIFDataHold [counter3*15+11].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 4){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(arrayIFDataHold [counter3*15+10].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 3){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 2){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 1){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                        }
                                                        else if (atoi(arrayIFDataHold [(counter3+1)*15+14].c_str()) > timePointTemp){
                                                            arrayIFTimeLineDataTemp [timePointTemp*9+1] = atoi(arrayIFDataHold [counter3*15].c_str());
                                                            arrayIFTimeLineDataTemp [timePointTemp*9+2] = atoi(arrayIFDataHold [counter3*15+13].c_str());
                                                            
                                                            if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 6){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(arrayIFDataHold [counter3*15+10].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = atoi(arrayIFDataHold [counter3*15+11].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = atoi(arrayIFDataHold [counter3*15+12].c_str());
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 5){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(arrayIFDataHold [counter3*15+10].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = atoi(arrayIFDataHold [counter3*15+11].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 4){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = atoi(arrayIFDataHold [counter3*15+10].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 3){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = atoi(arrayIFDataHold [counter3*15+9].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 2){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = atoi(arrayIFDataHold [counter3*15+8].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                            else if (atoi(arrayIFDataHold [counter3*15+13].c_str()) == 1){
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+3] = atoi(arrayIFDataHold [counter3*15+7].c_str());
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+4] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+5] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+6] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+7] = 0;
                                                                arrayIFTimeLineDataTemp [timePointTemp*9+8] = 0;
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA <= timeEnd; counterA++){
                                        //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                                        //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                                        //}
                                        
                                        //----Detail Table----
                                        int *arrayTableDetailTemp = new int [20];
                                        
                                        noOfLing = 0;
                                        noOfCellStart = 0;
                                        noOfCellEnd = 0;
                                        noOfTotalCells = 0;
                                        noOfDD = 0;
                                        noOfTD = 0;
                                        noOfHD = 0;
                                        noOfMI = 0;
                                        noOfFU = 0;
                                        noOfCD = 0;
                                        
                                        maxLineageNo = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                            if (arrayLineageDataTemp [counter2*8+2] == timeStart && (arrayLineageDataTemp [counter2*8+5] == 0 || arrayLineageDataTemp [counter2*8+5] == -1)){
                                                noOfLing++;
                                            }
                                            
                                            if (maxLineageNo < arrayLineageDataTemp [counter2*8+6]) maxLineageNo = arrayLineageDataTemp [counter2*8+6]; //==
                                            
                                            if (arrayLineageDataTemp [counter2*8+2] == timeStart && arrayLineageDataTemp [counter2*8+5] == 0){
                                                noOfCellStart++;
                                            }
                                            
                                            if ((arrayLineageDataTemp [counter2*8+3] == 1 || arrayLineageDataTemp [counter2*8+3] == 31 || arrayLineageDataTemp [counter2*8+3] == 41 || arrayLineageDataTemp [counter2*8+3] == 51)){
                                                noOfTotalCells++;
                                            }
                                            
                                            if (arrayLineageDataTemp [counter2*8+2] == timeDICEnd) noOfCellEnd++;
                                            if (arrayLineageDataTemp [counter2*8+3] == 32) noOfDD++;
                                            if (arrayLineageDataTemp [counter2*8+3] == 42) noOfTD++;
                                            if (arrayLineageDataTemp [counter2*8+3] == 52) noOfHD++;
                                            if (arrayLineageDataTemp [counter2*8+3] == 6) noOfMI++;
                                            if (arrayLineageDataTemp [counter2*8+3] == 91) noOfFU++;
                                            if (arrayLineageDataTemp [counter2*8+3] == 7) noOfCD++;
                                        }
                                        
                                        arrayTableDetailTemp [0] = lineageDataEntryCount+1;
                                        arrayTableDetailTemp [1] = noOfLing;
                                        arrayTableDetailTemp [2] = timeStart;
                                        arrayTableDetailTemp [3] = timeDICEnd;
                                        
                                        if (timeDICEnd < timeFIStart) arrayTableDetailTemp [4] = timeFIStart;
                                        else arrayTableDetailTemp [4] = 0;
                                        
                                        if (timeDICEnd < timeFIEnd) arrayTableDetailTemp [5] = timeFIEnd;
                                        else arrayTableDetailTemp [5] = 0;
                                        
                                        arrayTableDetailTemp [6] = noOfCellStart;
                                        arrayTableDetailTemp [7] = noOfCellEnd;
                                        
                                        if (noOfCellStart != 0){
                                            foldTemp = noOfCellEnd/(double)noOfCellStart;
                                            foldTemp = foldTemp*10+1;
                                        }
                                        else foldTemp = 1;
                                        
                                        arrayTableDetailTemp [8] = (int)foldTemp;
                                        arrayTableDetailTemp [9] = noOfTotalCells;
                                        arrayTableDetailTemp [10] = noOfDD;
                                        arrayTableDetailTemp [11] = noOfTD;
                                        arrayTableDetailTemp [12] = noOfHD;
                                        arrayTableDetailTemp [13] = noOfDD+noOfTD+noOfHD;
                                        arrayTableDetailTemp [14] = noOfMI;
                                        arrayTableDetailTemp [15] = noOfFU;
                                        arrayTableDetailTemp [16] = noOfCD;
                                        
                                        //for (int counterA = 0; counterA < 1; counterA++){
                                        //    for (int counterB = 0; counterB < 17; counterB++) cout<<" "<<arrayTableDetailTemp [counterA*17+counterB];
                                        //    cout<<" arrayTableDetailTemp "<<counterA<<endl;
                                        //}
                                        
                                        fluorescentDataEntryCount = atoi(arrayTableMainTemp [5].c_str());
                                        
                                        if (fluorescentDataEntryCount == 0) fluorescentDataEntryCount = 1;
                                        
                                        for (int counter2 = 13; counter2 < tableMainTempCount; counter2 = counter2+8){
                                            fluorescentDataEntryCount = fluorescentDataEntryCount+atoi(arrayTableMainTemp [counter2+1].c_str());
                                        }
                                        
                                        //----Link Data----
                                        lineageLinkListLengthTemp = 4;
                                        int *arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                        int lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                        
                                        for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp+11; counter2++) arrayLineageLinkTemp [counter2] = 0;
                                        
                                        for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                            if (arrayLineageDataTemp [counter2*8+3] == 31 || arrayLineageDataTemp [counter2*8+3] == 41 || arrayLineageDataTemp [counter2*8+3] == 51 || arrayLineageDataTemp [counter2*8+3] == 1){
                                                lingNoTemp = arrayLineageDataTemp [counter2*8+6];
                                                arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                            }
                                        }
                                        
                                        for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                            lingNoTemp = arrayLineageDataTemp [counter2*8+6];
                                            
                                            if (arrayLineageDataTemp [counter2*8+7] != 0 && arrayLineageDataTemp [counter2*8+7] != lingNoTemp){
                                                matchFind = 0;
                                                freeSpotFind = 0;
                                                
                                                for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                    if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter3] == arrayLineageDataTemp [counter2*8+7]){
                                                        matchFind = 1;
                                                    }
                                                    
                                                    if (arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+counter3] == 0 && freeSpotFind == 0){
                                                        freeSpotFind = counter3;
                                                    }
                                                }
                                                
                                                if (matchFind == 0){
                                                    if (freeSpotFind == 0){
                                                        previousLengthHold = lineageLinkListLengthTemp;
                                                        int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                        
                                                        for (int counter3 = 0; counter3 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter3++) arrayUpDate [counter3] = arrayLineageLinkTemp [counter3];
                                                        
                                                        delete [] arrayLineageLinkTemp;
                                                        lineageLinkListLengthTemp = lineageLinkListLengthTemp+2;
                                                        arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+11];
                                                        lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+11;
                                                        
                                                        readingCount = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= maxLineageNo; counter3++){
                                                            for (int counter4 = 0; counter4 < previousLengthHold; counter4++){
                                                                arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+counter4] = arrayUpDate [readingCount], readingCount++;
                                                            }
                                                            
                                                            arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+previousLengthHold] = 0;
                                                            arrayLineageLinkTemp [counter3*lineageLinkListLengthTemp+previousLengthHold+1] = 0;
                                                        }
                                                        
                                                        delete [] arrayUpDate;
                                                        
                                                        freeSpotFind = previousLengthHold;
                                                    }
                                                    
                                                    arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp] = lingNoTemp;
                                                    arrayLineageLinkTemp [lingNoTemp*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageDataTemp [counter2*8+7];
                                                }
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA <= maxLingNo; counterA++){
                                        //    for (int counterB = 0; counterB < lineageLinkListLength; counterB++) cout<<" "<<arrayLineageLinkList [counterA*lineageLinkListLength+counterB];
                                        //    cout<<" arrayLineageLinkList "<<counterA<<endl;
                                        //}
                                        
                                        for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                            if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+1] != 0){
                                                freeSpotFind = -1;
                                                
                                                for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                    if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] == 0){
                                                        freeSpotFind = counter3;
                                                        break;
                                                    }
                                                }
                                                
                                                if (freeSpotFind == -1) freeSpotFind = 4;
                                                
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    
                                                    for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                        if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                            lengthExpansionFlag = 0;
                                                            
                                                            for (int counter4 = 1; counter4 <= maxLineageNo; counter4++){
                                                                if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3]){
                                                                    entryNo = 0;
                                                                    
                                                                    for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                                        findFlag = 0;
                                                                        
                                                                        for (int counter6 = 1; counter6 < lineageLinkListLengthTemp; counter6++){
                                                                            if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0 && (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter6] || arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == counter2)){
                                                                                findFlag = 1;
                                                                            }
                                                                            else if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0) findFlag = 1;
                                                                        }
                                                                        
                                                                        if (findFlag == 0) entryNo++;
                                                                    }
                                                                    
                                                                    if (entryNo != 0){
                                                                        if (freeSpotFind == lineageLinkListLengthTemp || freeSpotFind+entryNo > lineageLinkListLengthTemp){
                                                                            previousLengthHold = lineageLinkListLengthTemp;
                                                                            int *arrayUpDate = new int [lineageLinkListTempLimit+11];
                                                                            
                                                                            for (int counter5 = 0; counter5 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter5++) arrayUpDate [counter5] = arrayLineageLinkTemp [counter5];
                                                                            
                                                                            if ((freeSpotFind+entryNo)%2 != 0) expansionNo = freeSpotFind+entryNo+1;
                                                                            else expansionNo = freeSpotFind+entryNo;
                                                                            
                                                                            delete [] arrayLineageLinkTemp;
                                                                            lineageLinkListLengthTemp = expansionNo+2;
                                                                            arrayLineageLinkTemp = new int [(maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1];
                                                                            lineageLinkListTempLimit = (maxLineageNo+1)*lineageLinkListLengthTemp+lineageLinkListLengthTemp+1;
                                                                            
                                                                            expansionNo = lineageLinkListLengthTemp-previousLengthHold;
                                                                            
                                                                            readingCount = 0;
                                                                            
                                                                            for (int counter5 = 0; counter5 <= maxLineageNo; counter5++){
                                                                                for (int counter6 = 0; counter6 < previousLengthHold; counter6++){
                                                                                    arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+counter6] = arrayUpDate [readingCount], readingCount++;
                                                                                }
                                                                                
                                                                                for (int counter6 = 0; counter6 < expansionNo; counter6++){
                                                                                    arrayLineageLinkTemp [counter5*lineageLinkListLengthTemp+previousLengthHold+counter6] = 0;
                                                                                }
                                                                            }
                                                                            
                                                                            delete [] arrayUpDate;
                                                                            
                                                                            lengthExpansionFlag = 1;
                                                                            
                                                                            break;
                                                                        }
                                                                        else{
                                                                            
                                                                            for (int counter5 = 1; counter5 < lineageLinkListLengthTemp; counter5++){
                                                                                findFlag = 0;
                                                                                
                                                                                for (int counter6 = 1; counter6 < lineageLinkListLengthTemp; counter6++){
                                                                                    if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] != 0 && (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter6] || arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == counter2)){
                                                                                        findFlag = 1;
                                                                                    }
                                                                                    else if (arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5] == 0) findFlag = 1;
                                                                                }
                                                                                
                                                                                if (findFlag != 1){
                                                                                    arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+freeSpotFind] = arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp+counter5];
                                                                                    
                                                                                    freeSpotFind++;
                                                                                }
                                                                            }
                                                                            
                                                                            arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] = -1;
                                                                            break;
                                                                        }
                                                                    }
                                                                    else{
                                                                        
                                                                        arrayLineageLinkTemp [counter4*lineageLinkListLengthTemp] = -1;
                                                                    }
                                                                }
                                                            }
                                                            
                                                            if (lengthExpansionFlag == 1){
                                                                break;
                                                            }
                                                        }
                                                        
                                                        if (counter3 == lineageLinkListLengthTemp-1) terminationFlag = 0;
                                                    }
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                        }
                                        
                                        //for (int counterA = 0; counterA <= maxLineageNo; counterA++){
                                        //    for (int counterB = 0; counterB < lineageLinkListLengthTemp; counterB++) cout<<" "<<arrayLineageLinkTemp [counterA*lineageLinkListLengthTemp+counterB];
                                        //    cout<<" arrayLineageLinkTemp "<<counterA<<endl;
                                        //}
                                        
                                        int *numberOfEntryList = new int [lineageLinkListLengthTemp+1];
                                        int *numberOfEntryList2 = new int [lineageLinkListLengthTemp+1];
                                        
                                        for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                            if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp] > 0 && arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+1] != 0){
                                                numberOfFusionEntry = 0;
                                                
                                                for (int counter3 = 0; counter3 < lineageLinkListLengthTemp; counter3++){
                                                    if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                        numberOfFusionEntry++;
                                                    }
                                                }
                                                
                                                if (numberOfFusionEntry > 1){
                                                    for (int counter3 = 0; counter3 < lineageLinkListLengthTemp; counter3++){
                                                        if (arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] != 0){
                                                            numberOfEntryList [counter3] = arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3];
                                                        }
                                                        else numberOfEntryList [counter3] = 0;
                                                        
                                                        numberOfEntryList2 [counter3] = 0;
                                                    }
                                                    
                                                    smallestEntry2 = 1;
                                                    
                                                    do{
                                                        
                                                        terminationFlag = 1;
                                                        remainingFlag = 0;
                                                        smallestEntry = 100000;
                                                        smallestEntryPosition = 0;
                                                        
                                                        for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                            if (numberOfEntryList [counter3] != 0 && numberOfEntryList [counter3] < smallestEntry){
                                                                smallestEntry = numberOfEntryList [counter3];
                                                                smallestEntryPosition = counter3;
                                                                remainingFlag = 1;
                                                            }
                                                        }
                                                        
                                                        if (remainingFlag == 0) terminationFlag = 0;
                                                        else{
                                                            
                                                            numberOfEntryList2 [smallestEntry2] = numberOfEntryList [smallestEntryPosition], smallestEntry2++;
                                                            numberOfEntryList [smallestEntryPosition] = 0;
                                                        }
                                                        
                                                    } while (terminationFlag == 1);
                                                    
                                                    for (int counter3 = 1; counter3 < lineageLinkListLengthTemp; counter3++){
                                                        arrayLineageLinkTemp [counter2*lineageLinkListLengthTemp+counter3] = numberOfEntryList2 [counter3];
                                                    }
                                                }
                                            }
                                        }
                                        
                                        delete [] numberOfEntryList;
                                        delete [] numberOfEntryList2;
                                        
                                        //----Entry to Arrays----
                                        if (firstReadFlag == 0){
                                            firstReadFlag = 1;
                                            lineageDataEntryCount = 0;
                                            
                                            arrayLineageDataEntryHold = new unsigned long [101];
                                            arrayIFDataEntryHold = new int [101];
                                            arrayIFTimeLineDataEntryHold = new int [101];
                                            arrayTableMainHold = new int [101];
                                            arrayIfTimeStatusHold = new int [101];
                                            arrayAreaDataHold = new int [101];
                                            lineageLinkHold = new int [101];
                                            
                                            arrayLineageData = new int *[101];
                                            arrayIFData = new int *[101];
                                            arrayIFTimeLineData = new int *[101];
                                            arrayTableMain = new string *[101];
                                            arrayTableDetail = new int *[101];
                                            arrayLineageDataType = new string *[101];
                                            arrayLineageFluorescentDataType = new string *[101];
                                            arrayIfTimeStatus = new int *[101];
                                            arrayAreaData = new int *[101];
                                            arrayLineageLink = new int *[101];
                                            
                                            for (int counter2 = 0; counter2 < 101; counter2++){
                                                arrayLineageData [counter2] = new int [lineageDataCount+lineageDataCount/8+10];
                                                arrayIFData [counter2] = new int [ifDataMainTempCount+10];
                                                arrayIFTimeLineData [counter2] = new int [(timeEnd+1)*9+10];
                                                arrayTableMain [counter2] = new string [tableMainTempCount+10];
                                                arrayTableDetail [counter2] = new int [18];
                                                arrayLineageDataType [counter2] = new string [8];
                                                arrayLineageFluorescentDataType [counter2] = new string [9];
                                                arrayIfTimeStatus [counter2] = new int [(arrayTableDetailTemp [5]-arrayTableDetailTemp [4])*2+10];
                                                arrayAreaData [counter2] = new int [areaDataTempCount+10];
                                                arrayLineageLink [counter2] = new int [maxLineageNo*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                                            }
                                            
                                            arraySelectedLing = new int [101];
                                            
                                            for (int counter2 = 0; counter2 < 101; counter2++){
                                                arrayLineageDataEntryHold [counter2] = 0;
                                                arrayIFDataEntryHold [counter2] = 0;
                                                arrayIFTimeLineDataEntryHold [counter2] = 0;
                                                arrayTableMainHold [counter2] = 0;
                                                arraySelectedLing [counter2] = 0;
                                                arrayIfTimeStatusHold [counter2] = 0;
                                                arrayAreaDataHold [counter2] = 0;
                                                lineageLinkHold [counter2] = 0;
                                            }
                                            
                                            lineageFluorescentDataTypeEntryLimit = 101;
                                            lineageDataEntryCount++;
                                        }
                                        else if (lineageDataEntryCount < 101){
                                            delete [] arrayLineageData [lineageDataEntryCount];
                                            delete [] arrayIFData [lineageDataEntryCount];
                                            delete [] arrayIFTimeLineData [lineageDataEntryCount];
                                            delete [] arrayTableMain [lineageDataEntryCount];
                                            delete [] arrayIfTimeStatus [lineageDataEntryCount];
                                            delete [] arrayAreaData [lineageDataEntryCount];
                                            delete [] arrayLineageLink [lineageDataEntryCount];
                                            
                                            arrayLineageData [lineageDataEntryCount] = new int [lineageDataCount+lineageDataCount/8+10];
                                            arrayIFData [lineageDataEntryCount] = new int [ifDataMainTempCount+10];
                                            arrayIFTimeLineData [lineageDataEntryCount] = new int [(timeEnd+1)*9+10];
                                            arrayTableMain [lineageDataEntryCount] = new string [tableMainTempCount+10];
                                            arrayIfTimeStatus [lineageDataEntryCount] = new int [(arrayTableDetailTemp [5]-arrayTableDetailTemp [4])*2+10];
                                            arrayAreaData [lineageDataEntryCount] = new int [areaDataTempCount+10];
                                            arrayLineageLink [lineageDataEntryCount] = new int [maxLineageNo*lineageLinkListLengthTemp+lineageLinkListLengthTemp+10];
                                            
                                            lineageDataEntryCount++;
                                        }
                                        else{
                                            
                                            NSAlert *alert = [[NSAlert alloc] init];
                                            [alert addButtonWithTitle:@"OK"];
                                            [alert setMessageText:@"Entry Limit Exceeded: 100"];
                                            [alert setAlertStyle:NSAlertStyleWarning];
                                            [alert runModal];
                                            
                                            NSSound *sound = [NSSound soundNamed:@"Hero"];
                                            [sound play];
                                        }
                                        
                                        if (lineageDataEntryCount-1 < 101){
                                            int *cellEntryCount = new int [maxLineageNo+10];
                                            
                                            for (int counter2 = 0; counter2 < maxLineageNo+10; counter2++) cellEntryCount [counter2] = 0;
                                            
                                            for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                                if (arrayLineageDataTemp [counter2*8+3] == 1 || arrayLineageDataTemp [counter2*8+3] == 31 || arrayLineageDataTemp [counter2*8+3] == 41 || arrayLineageDataTemp [counter2*8+3] == 51){
                                                    cellEntryCount [arrayLineageDataTemp [counter2*8+6]]++;
                                                }
                                            }
                                            
                                            largestEntry = 0;
                                            
                                            for (int counter2 = 0; counter2 < maxLineageNo+10; counter2++){
                                                if (cellEntryCount [counter2] > largestEntry) largestEntry = cellEntryCount [counter2];
                                            }
                                            
                                            int **cellDataList = new int *[maxLineageNo+10];
                                            
                                            for (int counter2 = 0; counter2 < maxLineageNo+10; counter2++) cellDataList [counter2] = new int [largestEntry*3+30];
                                            
                                            for (int counter2 = 0; counter2 < maxLineageNo+10; counter2++) cellEntryCount [counter2] = 0;
                                            
                                            for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                                if (arrayLineageDataTemp [counter2*8+3] == 1 || arrayLineageDataTemp [counter2*8+3] == 31 || arrayLineageDataTemp [counter2*8+3] == 41 || arrayLineageDataTemp [counter2*8+3] == 51){
                                                    cellDataList [arrayLineageDataTemp [counter2*8+6]][cellEntryCount [arrayLineageDataTemp [counter2*8+6]]] = arrayLineageDataTemp [counter2*8+5], cellEntryCount [arrayLineageDataTemp [counter2*8+6]]++;
                                                    cellDataList [arrayLineageDataTemp [counter2*8+6]][cellEntryCount [arrayLineageDataTemp [counter2*8+6]]] = arrayLineageDataTemp [counter2*8+2], cellEntryCount [arrayLineageDataTemp [counter2*8+6]]++;
                                                    cellDataList [arrayLineageDataTemp [counter2*8+6]][cellEntryCount [arrayLineageDataTemp [counter2*8+6]]] = 0, cellEntryCount [arrayLineageDataTemp [counter2*8+6]]++;
                                                }
                                            }
                                            
                                            //for (int counterA = 0; counterA < maxLineageNo+10; counterA++){
                                            //    for (int counterB = 0; counterB < cellEntryCount [counterA]; counterB++) cout<<" "<<cellDataList [counterA][counterB];
                                            //    cout<<" cellDataList "<<counterA<<endl;
                                            //}
                                            
                                            for (int counter2 = 1; counter2 <= maxLineageNo; counter2++){
                                                reviseCellNo = 1;
                                                
                                                do{
                                                    
                                                    terminationFlag = 1;
                                                    smallestTimePoint = -1;
                                                    smallestValue = 100000;
                                                    
                                                    for (int counter3 = 0; counter3 < cellEntryCount [counter2]/3; counter3++){
                                                        if (smallestValue > cellDataList [counter2][counter3*3+1] && cellDataList [counter2][counter3*3+2] == 0){
                                                            smallestValue = cellDataList [counter2][counter3*3+1];
                                                            smallestTimePoint = counter3;
                                                        }
                                                    }
                                                    
                                                    if (smallestTimePoint != -1){
                                                        cellDataList [counter2][smallestTimePoint*3+2] = reviseCellNo;
                                                        reviseCellNo++;
                                                    }
                                                    else terminationFlag = 0;
                                                    
                                                } while (terminationFlag == 1);
                                            }
                                            
                                            //for (int counterA = 0; counterA < maxLineageNo+10; counterA++){
                                            //    for (int counterB = 0; counterB < cellEntryCount [counterA]; counterB++) cout<<" "<<cellDataList [counterA][counterB];
                                            //    cout<<" cellDataList  "<<counterA<<endl;
                                            //}
                                            
                                            for (int counter2 = 0; counter2 < lineageDataCount+lineageDataCount/8+10; counter2++){
                                                arrayLineageData [lineageDataEntryCount-1][counter2] = 0;
                                            }
                                            
                                            newCellNo = 0;
                                            cellNoAss = 0;
                                            lingNoAss = 0;
                                            
                                            for (int counter2 = 0; counter2 < lineageDataCount/8; counter2++){
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+1], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+2], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+3], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+4], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+5], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+6], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = arrayLineageDataTemp [counter2*8+7], arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                                
                                                if (arrayLineageDataTemp [counter2*8+5] != cellNoAss || lingNoAss != arrayLineageDataTemp [counter2*8+6]){
                                                    cellNoAss = arrayLineageDataTemp [counter2*8+5];
                                                    lingNoAss = arrayLineageDataTemp [counter2*8+6];
                                                    
                                                    for (int counter3 = 0; counter3 < cellEntryCount [arrayLineageDataTemp [counter2*8+6]]/3; counter3++){
                                                        if (cellDataList [arrayLineageDataTemp [counter2*8+6]][counter3*3] == arrayLineageDataTemp [counter2*8+5]){
                                                            newCellNo = cellDataList [arrayLineageDataTemp [counter2*8+6]][counter3*3+2];
                                                            break;
                                                        }
                                                    }
                                                }
                                                
                                                arrayLineageData [lineageDataEntryCount-1][arrayLineageDataEntryHold [lineageDataEntryCount-1]] = newCellNo, arrayLineageDataEntryHold [lineageDataEntryCount-1]++;
                                            }
                                            
                                            delete [] cellEntryCount;
                                            
                                            for (int counter2 = 0; counter2 < maxLineageNo+10; counter2++){
                                                delete [] cellDataList [counter2];
                                            }
                                            
                                            delete [] cellDataList;
                                            
                                            for (int counter2 = 0; counter2 < ifDataMainTempCount; counter2++){
                                                arrayIFData [lineageDataEntryCount-1][counter2] = arrayIFDataMainTemp [counter2];
                                            }
                                            
                                            arrayIFDataEntryHold [lineageDataEntryCount-1] = ifDataMainTempCount;
                                            
                                            for (int counter2 = 0; counter2 < timeEnd*9+9; counter2++){
                                                arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = 0;
                                            }
                                            
                                            for (int counter2 = 0; counter2 < timeEnd*9+9; counter2++){
                                                arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = arrayIFTimeLineDataTemp [counter2];
                                            }
                                            
                                            arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = timeEnd*9+9;
                                            
                                            for (int counter2 = 0; counter2 < tableMainTempCount; counter2++) arrayTableMain [lineageDataEntryCount-1][counter2] = arrayTableMainTemp [counter2];
                                            
                                            arrayTableMainHold [lineageDataEntryCount-1] = tableMainTempCount;
                                            
                                            for (int counter2 = 0; counter2 < 17; counter2++) arrayTableDetail [lineageDataEntryCount-1][counter2] = arrayTableDetailTemp [counter2];
                                            
                                            //**********arrayIFTimeStatus**********
                                            ifStatusEntryCount = 0;
                                            
                                            if (arrayTableDetailTemp [4] != 0){
                                                for (int counter2 = arrayTableDetailTemp [4]; counter2 <= arrayTableDetailTemp [5]; counter2++){
                                                    arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = counter2, ifStatusEntryCount++;
                                                    arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = 0, ifStatusEntryCount++;
                                                }
                                            }
                                            
                                            arrayIfTimeStatusHold [lineageDataEntryCount-1] = ifStatusEntryCount;
                                            
                                            //**********arrayAreaData**********
                                            for (int counter2 = 0; counter2 < areaDataTempCount; counter2++){
                                                arrayAreaData [lineageDataEntryCount-1][counter2] = arrayAreaDataTemp [counter2];
                                            }
                                            
                                            arrayAreaDataHold [lineageDataEntryCount-1] = areaDataTempCount;
                                            
                                            //**********arrayLinkData**********
                                            for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++){
                                                arrayLineageLink [lineageDataEntryCount-1][counter2] = arrayLineageLinkTemp [counter2];
                                            }
                                            
                                            arrayLineageLink [lineageDataEntryCount-1][0] = lineageLinkListLengthTemp;
                                            
                                            lineageLinkHold [lineageDataEntryCount-1] = (maxLineageNo+1)*lineageLinkListLengthTemp;
                                            
                                            //***********arrayLineageDataTypeHold********
                                            //*********arrayLineageFluorescentDataType*********
                                            lineageAdditionalDataPath = trackDataFolderPath+"/"+seriesName+"_Series/"+arrayFileDelete [counter1]+"/*LineageDataAddition-"+stringExtract2+".dat";
                                            
                                            fin.open(lineageAdditionalDataPath.c_str(), ios::in);
                                            
                                            if (fin.is_open()){
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][1] = getString;
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][2] = getString;
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][3] = getString;
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][4] = getString;
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][5] = getString;
                                                getline(fin, getString);
                                                arrayLineageDataType [lineageDataEntryCount-1][6] = getString;
                                                
                                                for (int counter2 = 0; counter2 < fluorescentDataEntryCount; counter2++){
                                                    if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                                    
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = getString;
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = getString;
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = getString;
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = getString;
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = getString;
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = getString;
                                                    getline(fin, getString);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = getString;
                                                    
                                                    lineageFluorescentDataTypeEntryCount++;
                                                }
                                                
                                                fin.close();
                                            }
                                            else{
                                                
                                                arrayLineageDataType [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                                arrayLineageDataType [lineageDataEntryCount-1][1] = "SO";
                                                arrayLineageDataType [lineageDataEntryCount-1][2] = seriesName;
                                                arrayLineageDataType [lineageDataEntryCount-1][3] = analysisID;
                                                arrayLineageDataType [lineageDataEntryCount-1][4] = extractTemp;
                                                arrayLineageDataType [lineageDataEntryCount-1][5] = "10";
                                                arrayLineageDataType [lineageDataEntryCount-1][6] = "nil";
                                                
                                                if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                                
                                                if (atoi(arrayTableMainTemp [5].c_str()) == 0){
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "nil";
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = "nil";
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = "nil";
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = "nil";
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = "nil";
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = "nil";
                                                    arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = "nil";
                                                    
                                                    lineageFluorescentDataTypeEntryCount++;
                                                }
                                                else{
                                                    
                                                    channelNo1 = 0;
                                                    channelNo2 = 0;
                                                    channelNo3 = 0;
                                                    channelNo4 = 0;
                                                    channelNo5 = 0;
                                                    channelNo6 = 0;
                                                    
                                                    for (int counter3 = 1; counter3 <= timeEnd; counter3++){
                                                        if (arrayIFTimeLineDataTemp [counter3*9+1] == -1){
                                                            channelNo1 = arrayIFTimeLineDataTemp [counter3*9+3];
                                                            channelNo2 = arrayIFTimeLineDataTemp [counter3*9+4];
                                                            channelNo3 = arrayIFTimeLineDataTemp [counter3*9+5];
                                                            channelNo4 = arrayIFTimeLineDataTemp [counter3*9+6];
                                                            channelNo5 = arrayIFTimeLineDataTemp [counter3*9+7];
                                                            channelNo6 = arrayIFTimeLineDataTemp [counter3*9+8];
                                                            break;
                                                        }
                                                    }
                                                    
                                                    if (lineageFluorescentDataTypeEntryCount+20 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                                    
                                                    if (atoi(arrayTableMainTemp [5].c_str()) >= 1){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "Live";
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [6];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo1);
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                                if (arrayIFDataMainTemp [counter2*22+5] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter2*22+5];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+5] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter2*22+5];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+6] != 0 && arrayIFDataMainTemp [counter2*22+5]*arrayIFDataMainTemp [counter2*22+6] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter2*22+5]*arrayIFDataMainTemp [counter2*22+6];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+6] != 0 && arrayIFDataMainTemp [counter2*22+5]*arrayIFDataMainTemp [counter2*22+6] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter2*22+5]*arrayIFDataMainTemp [counter2*22+6];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [5].c_str()) >= 2){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "Live";
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [7];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo2);
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                                if (arrayIFDataMainTemp [counter2*22+8] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter2*22+8];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+8] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter2*22+8];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+9] != 0 && arrayIFDataMainTemp [counter2*22+8]*arrayIFDataMainTemp [counter2*22+9] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter2*22+8]*arrayIFDataMainTemp [counter2*22+9];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+9] != 0 && arrayIFDataMainTemp [counter2*22+8]*arrayIFDataMainTemp [counter2*22+9] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter2*22+8]*arrayIFDataMainTemp [counter2*22+9];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [5].c_str()) >= 3){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "Live";
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [8];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo3);
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                                if (arrayIFDataMainTemp [counter2*22+11] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter2*22+11];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+11] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter2*22+11];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+12] != 0 && arrayIFDataMainTemp [counter2*22+11]*arrayIFDataMainTemp [counter2*22+12] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter2*22+11]*arrayIFDataMainTemp [counter2*22+12];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+12] != 0 && arrayIFDataMainTemp [counter2*22+11]*arrayIFDataMainTemp [counter2*22+12] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter2*22+11]*arrayIFDataMainTemp [counter2*22+12];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [5].c_str()) >= 4){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "Live";
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [9];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo4);
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                                if (arrayIFDataMainTemp [counter2*22+14] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter2*22+14];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+14] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter2*22+14];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+15] != 0 && arrayIFDataMainTemp [counter2*22+14]*arrayIFDataMainTemp [counter2*22+15] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter2*22+14]*arrayIFDataMainTemp [counter2*22+15];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+15] != 0 && arrayIFDataMainTemp [counter2*22+14]*arrayIFDataMainTemp [counter2*22+15] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter2*22+14]*arrayIFDataMainTemp [counter2*22+15];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [5].c_str()) >= 5){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "Live";
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [10];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo5);
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                                if (arrayIFDataMainTemp [counter2*22+17] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter2*22+17];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+17] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter2*22+17];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+18] != 0 && arrayIFDataMainTemp [counter2*22+17]*arrayIFDataMainTemp [counter2*22+18] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter2*22+17]*arrayIFDataMainTemp [counter2*22+18];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+18] != 0 && arrayIFDataMainTemp [counter2*22+17]*arrayIFDataMainTemp [counter2*22+18] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter2*22+17]*arrayIFDataMainTemp [counter2*22+18];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [5].c_str()) == 6){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "Live";
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [11];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo6);
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter2 = 0; counter2 < ifDataMainTempCount/22; counter2++){
                                                            if (arrayIFDataMainTemp [counter2*22+3] == 1){
                                                                if (arrayIFDataMainTemp [counter2*22+20] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter2*22+20];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+20] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter2*22+20];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+21] != 0 && arrayIFDataMainTemp [counter2*22+20]*arrayIFDataMainTemp [counter2*22+21] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter2*22+20]*arrayIFDataMainTemp [counter2*22+21];
                                                                
                                                                if (arrayIFDataMainTemp [counter2*22+21] != 0 && arrayIFDataMainTemp [counter2*22+20]*arrayIFDataMainTemp [counter2*22+21] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter2*22+20]*arrayIFDataMainTemp [counter2*22+21];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                }
                                                
                                                roundCount = 0;
                                                
                                                for (int counter2 = 13; counter2 < tableMainTempCount; counter2 = counter2+8){
                                                    roundCount++;
                                                    
                                                    channelNo1 = 0;
                                                    channelNo2 = 0;
                                                    channelNo3 = 0;
                                                    channelNo4 = 0;
                                                    channelNo5 = 0;
                                                    channelNo6 = 0;
                                                    roundStart = 0;
                                                    roundEnd = 0;
                                                    firstTimeSet = 0;
                                                    
                                                    for (int counter3 = 1; counter3 <= timeEnd; counter3++){
                                                        if (arrayIFTimeLineDataTemp [counter3*9+1] == roundCount){
                                                            channelNo1 = arrayIFTimeLineDataTemp [counter3*9+3];
                                                            channelNo2 = arrayIFTimeLineDataTemp [counter3*9+4];
                                                            channelNo3 = arrayIFTimeLineDataTemp [counter3*9+5];
                                                            channelNo4 = arrayIFTimeLineDataTemp [counter3*9+6];
                                                            channelNo5 = arrayIFTimeLineDataTemp [counter3*9+7];
                                                            channelNo6 = arrayIFTimeLineDataTemp [counter3*9+8];
                                                            
                                                            if (firstTimeSet == 0){
                                                                roundStart = counter3;
                                                                roundEnd = counter3;
                                                                firstTimeSet = 1;
                                                            }
                                                            else if (roundEnd < counter3) roundEnd = counter3;
                                                        }
                                                    }
                                                    
                                                    if (lineageFluorescentDataTypeEntryCount+20 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                                    
                                                    if (atoi(arrayTableMainTemp [counter2+1].c_str()) >= 1){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "R"+arrayTableMainTemp [counter2];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [counter2+2]; //=====
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo1); //=====
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= ifDataMainTempCount/22; counter3++){
                                                            if (arrayIFDataMainTemp [counter3*22+3] == 2 && arrayIFDataMainTemp [counter3*22+2] >= roundStart && arrayIFDataMainTemp [counter3*22+2] <= roundEnd){
                                                                if (arrayIFDataMainTemp [counter3*22+5] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter3*22+5];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+5] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter3*22+5];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+6] != 0 && arrayIFDataMainTemp [counter3*22+5]*arrayIFDataMainTemp [counter3*22+6] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter3*22+5]*arrayIFDataMainTemp [counter3*22+6];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+6] != 0 && arrayIFDataMainTemp [counter3*22+5]*arrayIFDataMainTemp [counter3*22+6] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter3*22+5]*arrayIFDataMainTemp [counter3*22+6];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [counter2+1].c_str()) >= 2){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "R"+arrayTableMainTemp [counter2];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [counter2+3]; //=====
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo2); //=====
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= ifDataMainTempCount/22; counter3++){
                                                            if (arrayIFDataMainTemp [counter3*22+3] == 2 && arrayIFDataMainTemp [counter3*22+2] >= roundStart && arrayIFDataMainTemp [counter3*22+2] <= roundEnd){
                                                                if (arrayIFDataMainTemp [counter3*22+8] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter3*22+8];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+8] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter3*22+8];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+9] != 0 && arrayIFDataMainTemp [counter3*22+8]*arrayIFDataMainTemp [counter3*22+9] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter3*22+8]*arrayIFDataMainTemp [counter3*22+9];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+9] != 0 && arrayIFDataMainTemp [counter3*22+8]*arrayIFDataMainTemp [counter3*22+9] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter3*22+8]*arrayIFDataMainTemp [counter3*22+9];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [counter2+1].c_str()) >= 3){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "R"+arrayTableMainTemp [counter2];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [counter2+4]; //=====
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo3); //=====
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= ifDataMainTempCount/22; counter3++){
                                                            if (arrayIFDataMainTemp [counter3*22+3] == 2 && arrayIFDataMainTemp [counter3*22+2] >= roundStart && arrayIFDataMainTemp [counter3*22+2] <= roundEnd){
                                                                if (arrayIFDataMainTemp [counter3*22+11] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter3*22+11];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+11] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter3*22+11];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+12] != 0 && arrayIFDataMainTemp [counter3*22+11]*arrayIFDataMainTemp [counter3*22+12] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter3*22+11]*arrayIFDataMainTemp [counter3*22+12];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+12] != 0 && arrayIFDataMainTemp [counter3*22+11]*arrayIFDataMainTemp [counter3*22+12] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter3*22+11]*arrayIFDataMainTemp [counter3*22+12];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [counter2+1].c_str()) >= 4){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "R"+arrayTableMainTemp [counter2];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [counter2+4]; //=====
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo4); //=====
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= ifDataMainTempCount/22; counter3++){
                                                            if (arrayIFDataMainTemp [counter3*22+3] == 2 && arrayIFDataMainTemp [counter3*22+2] >= roundStart && arrayIFDataMainTemp [counter3*22+2] <= roundEnd){
                                                                if (arrayIFDataMainTemp [counter3*22+14] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter3*22+14];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+14] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter3*22+14];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+15] != 0 && arrayIFDataMainTemp [counter3*22+14]*arrayIFDataMainTemp [counter3*22+15] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter3*22+14]*arrayIFDataMainTemp [counter3*22+15];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+15] != 0 && arrayIFDataMainTemp [counter3*22+14]*arrayIFDataMainTemp [counter3*22+15] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter3*22+14]*arrayIFDataMainTemp [counter3*22+15];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [counter2+1].c_str()) >= 5){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "R"+arrayTableMainTemp [counter2];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [counter2+4]; //=====
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo5); //=====
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= ifDataMainTempCount/22; counter3++){
                                                            if (arrayIFDataMainTemp [counter3*22+3] == 2 && arrayIFDataMainTemp [counter3*22+2] >= roundStart && arrayIFDataMainTemp [counter3*22+2] <= roundEnd){
                                                                if (arrayIFDataMainTemp [counter3*22+17] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter3*22+17];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+17] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter3*22+17];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+18] != 0 && arrayIFDataMainTemp [counter3*22+17]*arrayIFDataMainTemp [counter3*22+18] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter3*22+17]*arrayIFDataMainTemp [counter3*22+18];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+18] != 0 && arrayIFDataMainTemp [counter3*22+17]*arrayIFDataMainTemp [counter3*22+18] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter3*22+17]*arrayIFDataMainTemp [counter3*22+18];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                    
                                                    if (atoi(arrayTableMainTemp [counter2+1].c_str()) == 6){
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = "R"+arrayTableMainTemp [counter2];
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = arrayTableMainTemp [counter2+4]; //=====
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = to_string(channelNo6); //=====
                                                        
                                                        ifDataLow = 1000000;
                                                        ifDataHigh = 0;
                                                        ifDataPerARLow = 1000000;
                                                        ifDataPerARHigh = 0;
                                                        
                                                        for (int counter3 = 0; counter3 <= ifDataMainTempCount/22; counter3++){
                                                            if (arrayIFDataMainTemp [counter3*22+3] == 2 && arrayIFDataMainTemp [counter3*22+2] >= roundStart && arrayIFDataMainTemp [counter3*22+2] <= roundEnd){
                                                                if (arrayIFDataMainTemp [counter3*22+20] < ifDataLow) ifDataLow = arrayIFDataMainTemp [counter3*22+20];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+20] > ifDataHigh) ifDataHigh = arrayIFDataMainTemp [counter3*22+20];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+21] != 0 && arrayIFDataMainTemp [counter3*22+20]*arrayIFDataMainTemp [counter3*22+21] < ifDataPerARLow) ifDataPerARLow = arrayIFDataMainTemp [counter3*22+20]*arrayIFDataMainTemp [counter3*22+21];
                                                                
                                                                if (arrayIFDataMainTemp [counter3*22+21] != 0 && arrayIFDataMainTemp [counter3*22+20]*arrayIFDataMainTemp [counter3*22+21] > ifDataPerARHigh) ifDataPerARHigh = arrayIFDataMainTemp [counter3*22+20]*arrayIFDataMainTemp [counter3*22+21];
                                                            }
                                                        }
                                                        
                                                        if (ifDataLow == 1000000) ifDataLow = 0;
                                                        if (ifDataPerARLow == 1000000) ifDataPerARLow = 0;
                                                        
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = to_string(ifDataLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = to_string(ifDataHigh);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = to_string(ifDataPerARLow);
                                                        arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = to_string(ifDataPerARHigh);
                                                        lineageFluorescentDataTypeEntryCount++;
                                                    }
                                                }
                                                
                                                lineageAdditionalDataPath = trackDataFolderPath+"/"+seriesName+"_Series/"+analysisID+"_TrackData"+"/*LineageDataAddition-"+stringExtract2+".dat";
                                                
                                                //for (int counterA = 0; counterA < lineageDataEntryCount; counterA++){
                                                //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayLineageDataType [counterA][counterB];
                                                //    cout<<" arrayLineageDataType "<<counterA+1<<endl;
                                                //}
                                                
                                                //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                                //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                                //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                                //}
                                                
                                                ofstream oin;
                                                
                                                oin.open(lineageAdditionalDataPath.c_str(), ios::out | ios::binary);
                                                
                                                if (oin.is_open()){
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][0]<<endl;
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][1]<<endl;
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][2]<<endl;
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][3]<<endl;
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][4]<<endl;
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][5]<<endl;
                                                    oin<<arrayLineageDataType [lineageDataEntryCount-1][6]<<endl;
                                                    
                                                    for (int counter3 = 0; counter3 < lineageFluorescentDataTypeEntryCount; counter3++){
                                                        if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == lineageDataEntryCount){
                                                            oin<<arrayLineageFluorescentDataType [counter3][0]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][1]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][2]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][3]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][4]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][5]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][6]<<endl;
                                                            oin<<arrayLineageFluorescentDataType [counter3][7]<<endl;
                                                        }
                                                    }
                                                    
                                                    oin.close();
                                                }
                                            }
                                            
                                            analysisDataSavePath = analysisDataFolderPath+"/"+seriesName+"_AnalysisResults";
                                            mkdir(analysisDataSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            analysisDataSavePath = analysisDataSavePath+"/"+analysisID+"_IDResults";
                                            mkdir(analysisDataSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            analysisDataSavePath = analysisDataSavePath+"/"+"AN1-"+extractTemp+"_Results";
                                            mkdir(analysisDataSavePath.c_str(), S_IRWXU | S_IRWXG | S_IROTH | S_IXOTH);
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"LineageDataAnalysis";
                                            
                                            char *writingArray = new char [arrayLineageDataEntryHold [lineageDataEntryCount-1]/9*28+100];
                                            
                                            long indexCount = 0;
                                            int readBit [4];
                                            int dataTemp;
                                            
                                            for (unsigned long counter2 = 0; counter2 < arrayLineageDataEntryHold [lineageDataEntryCount-1]/9; counter2++){
                                                if (arrayLineageData [lineageDataEntryCount-1][counter2*9] < 0){
                                                    writingArray [indexCount] = 1, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9]*-1;
                                                }
                                                else{
                                                    
                                                    writingArray [indexCount] = 0, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9];
                                                }
                                                
                                                readBit [0] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [1] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                
                                                if (arrayLineageData [lineageDataEntryCount-1][counter2*9+1] < 0){
                                                    writingArray [indexCount] = 1, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+1]*-1;
                                                }
                                                else{
                                                    
                                                    writingArray [indexCount] = 0, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+1];
                                                }
                                                
                                                readBit [0] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [1] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                
                                                dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+2];
                                                readBit [0] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [1] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayLineageData [lineageDataEntryCount-1][counter2*9+3], indexCount++;
                                                
                                                if (arrayLineageData [lineageDataEntryCount-1][counter2*9+4] < 0){
                                                    writingArray [indexCount] = 1, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+4]*-1;
                                                }
                                                else{
                                                    
                                                    writingArray [indexCount] = 0, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+4];
                                                }
                                                
                                                readBit [0] = dataTemp/16777216;
                                                dataTemp = dataTemp%16777216;
                                                readBit [1] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [2] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [3] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                                
                                                if (arrayLineageData [lineageDataEntryCount-1][counter2*9+5] < 0){
                                                    writingArray [indexCount] = 1, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+5]*-1;
                                                }
                                                else{
                                                    
                                                    writingArray [indexCount] = 0, indexCount++;
                                                    dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+5];
                                                }
                                                
                                                readBit [0] = dataTemp/16777216;
                                                dataTemp = dataTemp%16777216;
                                                readBit [1] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [2] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [3] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                                
                                                dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+6];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+7];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayLineageData [lineageDataEntryCount-1][counter2*9+8];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            }
                                            
                                            for (int counter2 = 0; counter2 < 28; counter2++) writingArray [indexCount] = 0, indexCount++;
                                            
                                            ofstream outfile (analysisDataSavePath2.c_str(), ofstream::binary);
                                            outfile.write ((char*) writingArray, indexCount);
                                            outfile.close();
                                            
                                            delete [] writingArray;
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"LineageDataAnalysisEntry";
                                            
                                            ofstream oin;
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<<arrayLineageDataEntryHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"IFData";
                                            
                                            writingArray = new char [arrayIFDataEntryHold [lineageDataEntryCount-1]/22*60+60];
                                            
                                            indexCount = 0;
                                            
                                            for (int counter2 = 0; counter2 < arrayIFDataEntryHold [lineageDataEntryCount-1]/22; counter2++){
                                                if (arrayIFData [lineageDataEntryCount-1][counter2*22] < 0){
                                                    writingArray [indexCount] = 1, indexCount++;
                                                    dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22]*-1;
                                                }
                                                else{
                                                    
                                                    writingArray [indexCount] = 0, indexCount++;
                                                    dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22];
                                                }
                                                
                                                readBit [0] = dataTemp/16777216;
                                                dataTemp = dataTemp%16777216;
                                                readBit [1] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [2] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [3] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                writingArray [indexCount] = (char)readBit [3], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+1];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+2];
                                                readBit [0] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [1] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+3], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+4], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+5];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+6];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+7], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+8];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+9];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+10], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+11];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+12];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+13], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+14];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+15];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+16], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+17];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+18];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                writingArray [indexCount] = (char)arrayIFData [lineageDataEntryCount-1][counter2*22+19], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+20];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                                
                                                dataTemp = arrayIFData [lineageDataEntryCount-1][counter2*22+21];
                                                readBit [0] = dataTemp/65536;
                                                dataTemp = dataTemp%65536;
                                                readBit [1] = dataTemp/256;
                                                dataTemp = dataTemp%256;
                                                readBit [2] = dataTemp;
                                                
                                                writingArray [indexCount] = (char)readBit [0], indexCount++;
                                                writingArray [indexCount] = (char)readBit [1], indexCount++;
                                                writingArray [indexCount] = (char)readBit [2], indexCount++;
                                            }
                                            
                                            for (int counter2 = 0; counter2 < 33; counter2++) writingArray [indexCount] = 0, indexCount++;
                                            
                                            ofstream outfile2 (analysisDataSavePath2.c_str(), ofstream::binary);
                                            outfile2.write ((char*) writingArray, indexCount);
                                            outfile2.close();
                                            
                                            delete [] writingArray;
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"IFDataEntry";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<< arrayIFDataEntryHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"IFTimeLine";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            
                                            for (int counter2 = 0; counter2 < arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]; counter2++){
                                                oin<<arrayIFTimeLineData [lineageDataEntryCount-1][counter2]<<endl;
                                            }
                                            
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"IFTimeLineEntry";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<<arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"MainTable";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            
                                            for (int counter2 = 0; counter2 < arrayTableMainHold [lineageDataEntryCount-1]; counter2++){
                                                if (counter2 == 1) oin<<"AN"<<endl;
                                                else if (counter2 == 4) oin<<"AN1-"+extractTemp<<endl;
                                                else oin<<arrayTableMain [lineageDataEntryCount-1][counter2]<<endl;
                                            }
                                            
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"MainTableEntry";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<<arrayTableMainHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"DetailTable";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            
                                            for (int counter2 = 0; counter2 < 17; counter2++){
                                                oin<<arrayTableDetail [lineageDataEntryCount-1][counter2]<<endl;
                                            }
                                            
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"IFDataStatus";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            
                                            for (int counter2 = 0; counter2 < ifStatusEntryCount; counter2++){
                                                oin<<arrayIfTimeStatus [lineageDataEntryCount-1][counter2]<<endl;
                                            }
                                            
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"IFDataStatusEntry";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<<arrayIfTimeStatusHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"AreaData";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            
                                            for (int counter2 = 0; counter2 < areaDataTempCount; counter2++){
                                                oin<<arrayAreaData [lineageDataEntryCount-1][counter2]<<endl;
                                            }
                                            
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"AreaDataEntry";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<<arrayAreaDataHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"LinkData";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            
                                            for (int counter2 = 0; counter2 < (maxLineageNo+1)*lineageLinkListLengthTemp; counter2++){
                                                oin<<arrayLineageLink [lineageDataEntryCount-1][counter2]<<endl;
                                            }
                                            
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"LinkDataEntry";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out | ios::binary);
                                            oin<<lineageLinkHold [lineageDataEntryCount-1]<<endl;
                                            oin.close();
                                            
                                            analysisDataSavePath2 = analysisDataSavePath+"/"+"*LineageDataAddition.dat";
                                            
                                            oin.open(analysisDataSavePath2.c_str(), ios::out);
                                            oin<<arrayLineageDataType [lineageDataEntryCount-1][0]<<endl;
                                            oin<<"AN"<<endl;
                                            oin<<arrayLineageDataType [lineageDataEntryCount-1][2]<<endl;
                                            oin<<arrayLineageDataType [lineageDataEntryCount-1][3]<<endl;
                                            oin<<arrayLineageDataType [lineageDataEntryCount-1][4]<<endl;
                                            oin<<arrayLineageDataType [lineageDataEntryCount-1][5]<<endl;
                                            oin<<arrayLineageDataType [lineageDataEntryCount-1][6]<<endl;
                                            
                                            for (int counter3 = 0; counter3 < lineageFluorescentDataTypeEntryCount; counter3++){
                                                if (atoi(arrayLineageFluorescentDataType [counter3][0].c_str()) == lineageDataEntryCount){
                                                    oin<<arrayLineageFluorescentDataType [counter3][0]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][1]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][2]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][3]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][4]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][5]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][6]<<endl;
                                                    oin<<arrayLineageFluorescentDataType [counter3][7]<<endl;
                                                }
                                            }
                                            
                                            if (initialArraySet == 0) initialArraySet = 1;
                                        }
                                        
                                        delete [] arrayLineageDataTemp;
                                        delete [] arrayIFDataMainTemp;
                                        delete [] arrayTableMainTemp;
                                        delete [] arrayIFTimeLineDataTemp;
                                        delete [] arrayAreaDataTemp;
                                        delete [] arrayLineageLinkTemp;
                                        
                                        progressTiming = 5;
                                        
                                        do usleep(10);
                                        while (progressTiming == 5);
                                    }
                                    
                                    delete [] arrayIFDataHold;
                                    delete [] arrayTreatmentStatus;
                                }
                            }
                        }
                    }
                    
                    closedir(dir2);
                }
            }
            
            upLoadingFlag = 1;
            
            if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
            if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
            if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
            if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
            if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
            if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
            if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
            
            upLoadingProgress = 0;
        });
    }
    else if (sourceStatusHold == 1){
        string imageDisplayPath = analysisDataFolderPath+"/"+seriesName+"_AnalysisResults"+"/"+analysisID+"_IDResults";
        string imageDisplayPath2;
        string imageDisplayPath3;
        string stringExtract2;
        string lineageAdditionalDataPath;
        
        DIR *dir;
        struct dirent *dent;
        DIR *dir2;
        struct dirent *dent2;
        
        ifstream fin;
        
        int identicalDataFound = 0;
        int ifDataMainTempCount = 0;
        int tableMainTempCount = 0;
        int lineageDataCount = 0;
        int stepCount = 0;
        int finData [60];
        int terminationFlag = 0;
        int ifTimeLineDataTempCount = 0;
        int ifStatusEntryCount = 0;
        
        long sizeForCopy = 0;
        long sizeForCopy2 = 0;
        long sizeForCopy3 = 0;
        unsigned long readPosition = 0;
        
        fileDeleteCount = 0;
        
        dir = opendir(imageDisplayPath.c_str());
        
        if (dir != NULL){
            string entry; //----Analysis ID----
            
            while ((dent = readdir(dir))){
                entry = dent -> d_name;
                
                if (entry != "." && entry != ".." && entry != ".DS_Store"){
                    if ((int)entry.find("_Results") != -1){
                        if (fileDeleteCount+5 > fileDeleteLimit) [self fileDeleteUpDate];
                        arrayFileDelete [fileDeleteCount] = entry, fileDeleteCount++;
                    }
                }
            }
            
            closedir(dir);
            
            //----Directory Sort----
            NSMutableArray *unsortedArray = [[NSMutableArray alloc] init];
            
            for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
                [unsortedArray addObject:@(arrayFileDelete [counter1].c_str())];
            }
            
            [unsortedArray sortUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
            
            for (NSUInteger counter1 = 0; counter1 < [unsortedArray count]; counter1++){
                arrayFileDelete [counter1] = [unsortedArray [counter1] UTF8String];
            }
        }
        
        string entry2; //----Treat name
        string getString;
        
        struct stat sizeOfFile;
        
        for (int counter1 = 0; counter1 < fileDeleteCount; counter1++){
            imageDisplayPath2 = imageDisplayPath+"/"+arrayFileDelete [counter1];
            
            dir2 = opendir(imageDisplayPath2.c_str());
            
            if (dir2 != NULL){
                while ((dent2 = readdir(dir2))){
                    entry2 = dent2 -> d_name;
                    
                    if (entry2 != "." && entry2 != ".." && entry2 != ".DS_Store"){
                        if ((int)entry2.find("DetailTable") != -1){
                            identicalDataFound = 0;
                            
                            stringExtract2 = arrayFileDelete [counter1].substr(0, arrayFileDelete [counter1].find("_"));
                            
                            if (lineageDataEntryCount != 0){
                                for (int counter2 = 0; counter2 < lineageDataEntryCount; counter2++){
                                    if (arrayTableMain [counter2][2] == seriesName && arrayTableMain [counter2][3] == analysisID && arrayTableMain [counter2][4] == stringExtract2){
                                        identicalDataFound = 1;
                                        break;
                                    }
                                }
                            }
                            
                            if (identicalDataFound == 0 && lineageDataEntryCount < 101){
                                imageDisplayPath3 = imageDisplayPath2+"/"+"LineageDataAnalysis";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for Lineage data----
                                int *arrayLineageDataTemp = new int [sizeForCopy+50];
                                lineageDataCount = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(imageDisplayPath3.c_str(), ios::in | ios::binary);
                                    
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                            finData [1] = uploadTemp [readPosition], readPosition++;
                                            finData [2] = uploadTemp [readPosition], readPosition++; //--2 X Position
                                            finData [3] = uploadTemp [readPosition], readPosition++; //--3 +-
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--4 Y Position
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++; //--5 Time point
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--6 Event type
                                            finData [9] = uploadTemp [readPosition], readPosition++; //--7 +-
                                            finData [10] = uploadTemp [readPosition], readPosition++;
                                            finData [11] = uploadTemp [readPosition], readPosition++;
                                            finData [12] = uploadTemp [readPosition], readPosition++;
                                            finData [13] = uploadTemp [readPosition], readPosition++; //--8 Next cell/fuse no
                                            finData [14] = uploadTemp [readPosition], readPosition++; //--9 +-
                                            finData [15] = uploadTemp [readPosition], readPosition++;
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--10 Cell no
                                            finData [19] = uploadTemp [readPosition], readPosition++;
                                            finData [20] = uploadTemp [readPosition], readPosition++;
                                            finData [21] = uploadTemp [readPosition], readPosition++; //--11 Ling no
                                            finData [22] = uploadTemp [readPosition], readPosition++;
                                            finData [23] = uploadTemp [readPosition], readPosition++;
                                            finData [24] = uploadTemp [readPosition], readPosition++; //--12 Ling no Fuse
                                            finData [25] = uploadTemp [readPosition], readPosition++;
                                            finData [26] = uploadTemp [readPosition], readPosition++;
                                            finData [27] = uploadTemp [readPosition], readPosition++; //--12 Ling no Fuse
                                            
                                            if (finData [0] == 1) finData [2] = (finData [1]*256+finData [2])*-1;
                                            else finData [2] = finData [1]*256+finData [2];
                                            
                                            if (finData [3] == 1) finData [5] = (finData [4]*256+finData [5])*-1;
                                            else finData [5] = finData [4]*256+finData [5];
                                            
                                            finData [7] = finData [6]*256+finData [7];
                                            
                                            if (finData [9] == 1) finData [13] = (finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13])*-1;
                                            else finData [13] = finData [10]*16777216+finData [11]*65536+finData [12]*256+finData [13];
                                            
                                            if (finData [14] == 1) finData [18] = (finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18])*-1;
                                            else finData [18] = finData [15]*16777216+finData [16]*65536+finData [17]*256+finData [18];
                                            
                                            finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                            finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                            finData [27] = finData [25]*65536+finData [26]*256+finData [27];
                                            
                                            if (finData [2] == 0 && finData [5] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayLineageDataTemp [lineageDataCount] = finData [2], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [5], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [7], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [8], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [13], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [18], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [21], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [24], lineageDataCount++;
                                                arrayLineageDataTemp [lineageDataCount] = finData [27], lineageDataCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < lineageDataCount/9; counterA++){
                                //    for (int counterB = 0; counterB < 9; counterB++) cout<<" "<<arrayLineageDataTemp [counterA*9+counterB];
                                //    cout<<" arrayLineageDataTemp "<<counterA<<endl;
                                //}
                                
                                imageDisplayPath3 = imageDisplayPath2+"/"+"IFData";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for IFData----
                                int *arrayIFDataMainTemp = new int [sizeForCopy+50];
                                ifDataMainTempCount = 0;
                                
                                if (sizeForCopy != 0){
                                    fin.open(imageDisplayPath3.c_str(), ios::in | ios::binary);
                                    
                                    uint8_t *uploadTemp = new uint8_t [sizeForCopy+50];
                                    fin.read((char*)uploadTemp, sizeForCopy+50);
                                    fin.close();
                                    
                                    readPosition = 0;
                                    stepCount = 0;
                                    
                                    do{
                                        
                                        if (stepCount == 0){
                                            finData [0] = uploadTemp [readPosition], readPosition++; //--1 +-
                                            finData [1] = uploadTemp [readPosition], readPosition++; //--2 Cell no
                                            finData [2] = uploadTemp [readPosition], readPosition++;
                                            finData [3] = uploadTemp [readPosition], readPosition++;
                                            finData [4] = uploadTemp [readPosition], readPosition++;
                                            finData [5] = uploadTemp [readPosition], readPosition++; //--4 Ling no
                                            finData [6] = uploadTemp [readPosition], readPosition++;
                                            finData [7] = uploadTemp [readPosition], readPosition++;
                                            finData [8] = uploadTemp [readPosition], readPosition++; //--7 TP
                                            finData [9] = uploadTemp [readPosition], readPosition++;
                                            finData [10] = uploadTemp [readPosition], readPosition++; //--9 Live/IF
                                            finData [11] = uploadTemp [readPosition], readPosition++; //--10 Ch1 no
                                            finData [12] = uploadTemp [readPosition], readPosition++; //--11 Ch1 value
                                            finData [13] = uploadTemp [readPosition], readPosition++;
                                            finData [14] = uploadTemp [readPosition], readPosition++;
                                            finData [15] = uploadTemp [readPosition], readPosition++; //--14 Ch1 area
                                            finData [16] = uploadTemp [readPosition], readPosition++;
                                            finData [17] = uploadTemp [readPosition], readPosition++;
                                            finData [18] = uploadTemp [readPosition], readPosition++; //--17 Ch2 no
                                            finData [19] = uploadTemp [readPosition], readPosition++; //--18 Ch2 value
                                            finData [20] = uploadTemp [readPosition], readPosition++;
                                            finData [21] = uploadTemp [readPosition], readPosition++;
                                            finData [22] = uploadTemp [readPosition], readPosition++; //--21 Ch2 area
                                            finData [23] = uploadTemp [readPosition], readPosition++;
                                            finData [24] = uploadTemp [readPosition], readPosition++;
                                            finData [25] = uploadTemp [readPosition], readPosition++; //--24 Ch3 no
                                            finData [26] = uploadTemp [readPosition], readPosition++; //--25 Ch3 value
                                            finData [27] = uploadTemp [readPosition], readPosition++;
                                            finData [28] = uploadTemp [readPosition], readPosition++;
                                            finData [29] = uploadTemp [readPosition], readPosition++; //--28 Ch3 area
                                            finData [30] = uploadTemp [readPosition], readPosition++;
                                            finData [31] = uploadTemp [readPosition], readPosition++;
                                            
                                            finData [32] = uploadTemp [readPosition], readPosition++; //--31 Ch4 no
                                            finData [33] = uploadTemp [readPosition], readPosition++; //--32 Ch4 value
                                            finData [34] = uploadTemp [readPosition], readPosition++;
                                            finData [35] = uploadTemp [readPosition], readPosition++;
                                            finData [36] = uploadTemp [readPosition], readPosition++; //--36 Ch4 area
                                            finData [37] = uploadTemp [readPosition], readPosition++;
                                            finData [38] = uploadTemp [readPosition], readPosition++;
                                            finData [39] = uploadTemp [readPosition], readPosition++; //--40 Ch5 no
                                            finData [40] = uploadTemp [readPosition], readPosition++; //--41 Ch5 value
                                            finData [41] = uploadTemp [readPosition], readPosition++;
                                            finData [42] = uploadTemp [readPosition], readPosition++;
                                            finData [43] = uploadTemp [readPosition], readPosition++; //--45 Ch5 area
                                            finData [44] = uploadTemp [readPosition], readPosition++;
                                            finData [45] = uploadTemp [readPosition], readPosition++;
                                            finData [46] = uploadTemp [readPosition], readPosition++; //--48 Ch6 no
                                            finData [47] = uploadTemp [readPosition], readPosition++; //--49 Ch6 value
                                            finData [48] = uploadTemp [readPosition], readPosition++;
                                            finData [49] = uploadTemp [readPosition], readPosition++;
                                            finData [50] = uploadTemp [readPosition], readPosition++; //--53 Ch6 area
                                            finData [51] = uploadTemp [readPosition], readPosition++;
                                            finData [52] = uploadTemp [readPosition], readPosition++;
                                            
                                            if (finData [0] == 1) finData [4] = (finData [1]*16777216+finData [2]*65536+finData [3]*256+finData [4])*-1;
                                            else finData [4] = finData [1]*16777216+finData [2]*65536+finData [3]*256+finData [4];
                                            
                                            finData [7] = finData [5]*65536+finData [6]*256+finData [7];
                                            finData [9] = finData [8]*256+finData [9];
                                            finData [14] = finData [12]*65536+finData [13]*256+finData [14];
                                            finData [17] = finData [15]*65536+finData [16]*256+finData [17];
                                            finData [21] = finData [19]*65536+finData [20]*256+finData [21];
                                            finData [24] = finData [22]*65536+finData [23]*256+finData [24];
                                            finData [28] = finData [26]*65536+finData [27]*256+finData [28];
                                            finData [31] = finData [29]*65536+finData [30]*256+finData [31];
                                            
                                            finData [35] = finData [33]*65536+finData [34]*256+finData [35];
                                            finData [38] = finData [36]*65536+finData [37]*256+finData [38];
                                            finData [42] = finData [40]*65536+finData [41]*256+finData [42];
                                            finData [45] = finData [43]*65536+finData [44]*256+finData [45];
                                            finData [49] = finData [47]*65536+finData [48]*256+finData [49];
                                            finData [52] = finData [50]*65536+finData [51]*256+finData [52];
                                            
                                            if (finData [7] == 0 && finData [9] == 0) stepCount = 3;
                                            else{
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [4], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [7], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [9], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [10], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [11], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [14], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [17], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [18], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [21], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [24], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [25], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [28], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [31], ifDataMainTempCount++;
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [32], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [35], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [38], ifDataMainTempCount++;
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [39], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [42], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [45], ifDataMainTempCount++;
                                                
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [46], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [49], ifDataMainTempCount++;
                                                arrayIFDataMainTemp [ifDataMainTempCount] = finData [52], ifDataMainTempCount++;
                                            }
                                        }
                                        
                                    } while (stepCount != 3);
                                    
                                    delete [] uploadTemp;
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < ifDataMainTempCount/13; counterA++){
                                //    for (int counterB = 0; counterB < 13; counterB++) cout<<" "<<arrayIFDataMainTemp [counterA*13+counterB];
                                //    cout<<" arrayIFDataMainTemp "<<counterA+1<<endl;
                                //}
                                
                                imageDisplayPath3 = imageDisplayPath2+"/"+"IFTimeLine";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for IFTimeLine----
                                int *arrayIFTimeLineDataTemp = new int [sizeForCopy+50];
                                ifTimeLineDataTempCount = 0;
                                
                                fin.open(imageDisplayPath3.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") arrayIFTimeLineDataTemp [ifTimeLineDataTempCount] = atoi(getString.c_str()), ifTimeLineDataTempCount++;
                                        else terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                //for (int counterA = 0; counterA < ifTimeLineDataTempCount/6; counterA++){
                                //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineDataTemp [counterA*6+counterB];
                                //    cout<<" arrayIFTimeLineDataTemp "<<counterA<<endl;
                                //}
                                
                                //----Array for Main Table----
                                imageDisplayPath3 = imageDisplayPath2+"/"+"MainTable";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                string *arrayTableMainTemp = new string [sizeForCopy+50];
                                tableMainTempCount = 0;
                                
                                fin.open(imageDisplayPath3.c_str(), ios::in);
                                
                                if (fin.is_open()){
                                    do{
                                        
                                        terminationFlag = 1;
                                        
                                        getline(fin, getString);
                                        
                                        if (getString != "") arrayTableMainTemp [tableMainTempCount] = getString, tableMainTempCount++;
                                        else terminationFlag = 0;
                                        
                                    } while (terminationFlag == 1);
                                    
                                    fin.close();
                                }
                                
                                //----Array for IF Time status----
                                imageDisplayPath3 = imageDisplayPath2+"/"+"IFDataStatus";
                                
                                sizeForCopy = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy = sizeOfFile.st_size;
                                }
                                
                                //----Array for Area status----
                                imageDisplayPath3 = imageDisplayPath2+"/"+"AreaData";
                                
                                sizeForCopy2 = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy2 = sizeOfFile.st_size;
                                }
                                
                                //for (int counterA = 0; counterA < 1; counterA++){
                                //    for (int counterB = 0; counterB < tableMainTempCount; counterB++) cout<<" "<<arrayTableMainTemp [counterA+counterB];
                                //    cout<<" arrayTableMain "<<counterA<<endl;
                                //}
                                
                                //----Array for Link Table----
                                imageDisplayPath3 = imageDisplayPath2+"/"+"LinkData";
                                
                                sizeForCopy3 = 0;
                                
                                if (stat(imageDisplayPath3.c_str(), &sizeOfFile) == 0){
                                    sizeForCopy3 = sizeOfFile.st_size;
                                }
                                
                                if (firstReadFlag == 0){
                                    firstReadFlag = 1;
                                    lineageDataEntryCount = 0;
                                    lineageFluorescentDataTypeEntryCount = 0;
                                    
                                    arrayLineageDataEntryHold = new unsigned long [101];
                                    arrayIFDataEntryHold = new int [101];
                                    arrayIFTimeLineDataEntryHold = new int [101];
                                    arrayTableMainHold = new int [101];
                                    arrayIfTimeStatusHold = new int [101];
                                    arrayAreaDataHold = new int [101];
                                    lineageLinkHold = new int [101];
                                    
                                    arrayLineageData = new int *[101];
                                    arrayIFData = new int *[101];
                                    arrayIFTimeLineData = new int *[101];
                                    arrayTableMain = new string *[101];
                                    arrayTableDetail = new int *[101];
                                    arrayLineageDataType = new string *[101];
                                    arrayLineageFluorescentDataType = new string *[101];
                                    arrayIfTimeStatus = new int *[101];
                                    arrayAreaData = new int *[101];
                                    arrayLineageLink = new int *[101];
                                    
                                    for (int counter2 = 0; counter2 < 101; counter2++){
                                        arrayLineageData [counter2] = new int [lineageDataCount+10]; //==
                                        arrayIFData [counter2] = new int [ifDataMainTempCount+10];
                                        arrayIFTimeLineData [counter2] = new int [ifTimeLineDataTempCount+10];
                                        arrayTableMain [counter2] = new string [tableMainTempCount+10];
                                        arrayTableDetail [counter2] = new int [18];
                                        arrayLineageDataType [counter2] = new string [8];
                                        arrayLineageFluorescentDataType [counter2] = new string [9];
                                        arrayIfTimeStatus [counter2] = new int [sizeForCopy+50];
                                        arrayAreaData [counter2] = new int [sizeForCopy2+50];
                                        arrayLineageLink [counter2] = new int [sizeForCopy3+50];
                                    }
                                    
                                    arraySelectedLing = new int [101];
                                    
                                    for (int counter2 = 0; counter2 < 101; counter2++){
                                        arrayLineageDataEntryHold [counter2] = 0;
                                        arrayIFDataEntryHold [counter2] = 0;
                                        arrayIFTimeLineDataEntryHold [counter2] = 0;
                                        arrayTableMainHold [counter2] = 0;
                                        arraySelectedLing [counter2] = 0;
                                        arrayIfTimeStatusHold [counter2] = 0;
                                        arrayAreaDataHold [counter2] = 0;
                                        lineageLinkHold [counter2] = 0;
                                    }
                                    
                                    lineageFluorescentDataTypeEntryLimit = 101;
                                    
                                    lineageDataEntryCount++;
                                }
                                else if (lineageDataEntryCount < 101){
                                    delete [] arrayLineageData [lineageDataEntryCount];
                                    delete [] arrayIFData [lineageDataEntryCount];
                                    delete [] arrayIFTimeLineData [lineageDataEntryCount];
                                    delete [] arrayTableMain [lineageDataEntryCount];
                                    delete [] arrayIfTimeStatus [lineageDataEntryCount];
                                    delete [] arrayAreaData [lineageDataEntryCount];
                                    delete [] arrayLineageLink [lineageDataEntryCount];
                                    
                                    arrayLineageData [lineageDataEntryCount] = new int [lineageDataCount+10]; //==
                                    arrayIFData [lineageDataEntryCount] = new int [ifDataMainTempCount+10];
                                    arrayIFTimeLineData [lineageDataEntryCount] = new int [ifTimeLineDataTempCount+10];
                                    arrayTableMain [lineageDataEntryCount] = new string [tableMainTempCount+10];
                                    arrayIfTimeStatus [lineageDataEntryCount] = new int [sizeForCopy+50];
                                    arrayAreaData [lineageDataEntryCount] = new int [sizeForCopy2+50];
                                    arrayLineageLink [lineageDataEntryCount] = new int [sizeForCopy3+50];
                                    
                                    lineageDataEntryCount++;
                                }
                                else{
                                    
                                    NSAlert *alert = [[NSAlert alloc] init];
                                    [alert addButtonWithTitle:@"OK"];
                                    [alert setMessageText:@"Entry Limit Exceeded: 100"];
                                    [alert setAlertStyle:NSAlertStyleWarning];
                                    [alert runModal];
                                    
                                    NSSound *sound = [NSSound soundNamed:@"Hero"];
                                    [sound play];
                                }
                                
                                if (lineageDataEntryCount-1 < 101){
                                    for (int counter2 = 0; counter2 < lineageDataCount; counter2++){
                                        arrayLineageData [lineageDataEntryCount-1][counter2] = arrayLineageDataTemp [counter2];
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"LineageDataAnalysisEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayLineageDataEntryHold [lineageDataEntryCount-1] = (unsigned long)(atoi(getString.c_str()));
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < ifDataMainTempCount; counter2++){
                                        arrayIFData [lineageDataEntryCount-1][counter2] = arrayIFDataMainTemp [counter2]; //=====
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"IFDataEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayIFDataEntryHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < ifTimeLineDataTempCount; counter2++){
                                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = 0;
                                    }
                                    
                                    for (int counter2 = 0; counter2 < ifTimeLineDataTempCount; counter2++){
                                        arrayIFTimeLineData [lineageDataEntryCount-1][counter2] = arrayIFTimeLineDataTemp [counter2];
                                    }
                                    
                                    //for (int counterA = 0; counterA < ifTimeLineDataTempCount/6; counterA++){
                                    //    for (int counterB = 0; counterB < 6; counterB++) cout<<" "<<arrayIFTimeLineData [lineageDataEntryCount-1][counterA*6+counterB];
                                    //    cout<<" arrayIFTimeLineData "<<counterA<<endl;
                                    //}
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"IFTimeLineEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayIFTimeLineDataEntryHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    for (int counter2 = 0; counter2 < tableMainTempCount; counter2++){
                                        arrayTableMain [lineageDataEntryCount-1][counter2] = arrayTableMainTemp [counter2];
                                    }
                                    
                                    arrayTableMain [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                    
                                    //for (int counterA = 0; counterA < 1; counterA++){
                                    //    for (int counterB = 0; counterB < tableMainTempCount; counterB++) cout<<" "<< arrayTableMain [lineageDataEntryCount-1][counterA+counterB];
                                    //    cout<<"  arrayTableMain "<<counterA<<endl;
                                    //}
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"MainTableEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayTableMainHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"DetailTable";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][0] = lineageDataEntryCount;
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][1] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][2] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][3] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][4] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][5] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][6] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][7] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][8] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][9] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][10] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][11] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][12] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][13] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][14] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][15] = atoi(getString.c_str());
                                        getline(fin, getString);
                                        arrayTableDetail [lineageDataEntryCount-1][16] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/*LineageDataAddition.dat";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][0] = to_string(lineageDataEntryCount);
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][1] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][2] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][3] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][4] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][5] = getString;
                                        getline(fin, getString);
                                        arrayLineageDataType [lineageDataEntryCount-1][6] = getString;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            if (lineageFluorescentDataTypeEntryCount+9 > lineageFluorescentDataTypeEntryLimit) [self lineageFluorescentDataTypeUpDate];
                                            
                                            getline(fin, getString);
                                            
                                            if (getString == "") terminationFlag = 0;
                                            else{
                                                
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][0] = to_string(lineageDataEntryCount);
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][1] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][2] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][3] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][4] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][5] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][6] = getString;
                                                getline(fin, getString);
                                                arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][7] = getString;
                                                
                                                lineageFluorescentDataTypeEntryCount++;
                                            }
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"IFDataStatus";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        ifStatusEntryCount = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            getline(fin, getString);
                                            
                                            if (getString != "") arrayIfTimeStatus [lineageDataEntryCount-1][ifStatusEntryCount] = atoi(getString.c_str()), ifStatusEntryCount++;
                                            else terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"IFDataStatusEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayIfTimeStatusHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"AreaData";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        ifStatusEntryCount = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            getline(fin, getString);
                                            
                                            if (getString != "") arrayAreaData [lineageDataEntryCount-1][ifStatusEntryCount] = atoi(getString.c_str()), ifStatusEntryCount++;
                                            else terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"AreaDataEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        arrayAreaDataHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"LinkData";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        ifStatusEntryCount = 0;
                                        
                                        do{
                                            
                                            terminationFlag = 1;
                                            
                                            getline(fin, getString);
                                            
                                            if (getString != "") arrayLineageLink [lineageDataEntryCount-1][ifStatusEntryCount] = atoi(getString.c_str()), ifStatusEntryCount++;
                                            else terminationFlag = 0;
                                            
                                        } while (terminationFlag == 1);
                                        
                                        fin.close();
                                    }
                                    
                                    imageDisplayPath3 = imageDisplayPath2+"/"+"LinkDataEntry";
                                    
                                    fin.open(imageDisplayPath3.c_str(), ios::in);
                                    
                                    if (fin.is_open()){
                                        getline(fin, getString);
                                        
                                        lineageLinkHold [lineageDataEntryCount-1] = atoi(getString.c_str());
                                        
                                        fin.close();
                                    }
                                    
                                    //for (int counterA = 0; counterA < lineageDataEntryCount; counterA++){
                                    //    for (int counterB = 0; counterB < 7; counterB++) cout<<" "<<arrayLineageDataType [counterA][counterB];
                                    //    cout<<" arrayLineageDataType "<<counterA+1<<endl;
                                    //}
                                    
                                    //for (int counterA = 0; counterA < lineageFluorescentDataTypeEntryCount; counterA++){
                                    //    for (int counterB = 0; counterB < 8; counterB++) cout<<" "<<arrayLineageFluorescentDataType [counterA][counterB];
                                    //    cout<<" arrayLineageFluorescentDataType "<<counterA+1<<endl;
                                    //}
                                }
                                
                                if (initialArraySet == 0) initialArraySet = 1;
                                
                                delete [] arrayLineageDataTemp;
                                delete [] arrayIFDataMainTemp;
                                delete [] arrayTableMainTemp;
                                delete [] arrayIFTimeLineDataTemp;
                            }
                        }
                    }
                }
                
                closedir(dir2);
            }
        }
        
        upLoadingFlag = 1;
        
        if (lineageOpen == 1 && lineageWindowOperation != 2) lineageListCall = 1;
        if (growthCurveOpen == 1 && growthCurveWindowOperation != 2) growthCurveCall = 1;
        if (cellDivisionOpen == 1 && cellDivisionWindowOperation != 2) cellDivisionCall = 1; //========ADD POINT
        if (doublingTimeOpen == 1 && doublingTimeWindowOperation != 2) doublingTimeCall = 1;
        if (trimOpen == 1 && trimWindowOperation != 2) trimCall = 1;
        if (lineageSelectOpen == 1 && lineageSelectWindowOperation != 2) lineageSelectCall = 1;
        if (simulationOpen == 1 && simulationOperation != 2) simulationCall = 1;
    }
}

-(void)lineageFluorescentDataTypeUpDate{
    string **arrayLineageFluorescentDataTypeTemp = new string *[lineageFluorescentDataTypeEntryLimit];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        arrayLineageFluorescentDataTypeTemp [counter1] = new string [9];
    }
    
    int lineageFluorescentDataTypeEntryLimitTemp = lineageFluorescentDataTypeEntryLimit;
    int lineageFluorescentEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataTypeTemp [lineageFluorescentEntryCount][counter2] = arrayLineageFluorescentDataType [counter1][counter2];
        }
        
        lineageFluorescentEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit; counter1++){
        delete [] arrayLineageFluorescentDataType [counter1];
    }
    
    delete [] arrayLineageFluorescentDataType;
    
    arrayLineageFluorescentDataType = new string *[lineageFluorescentDataTypeEntryLimit+320];
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimit+320; counter1++){
        arrayLineageFluorescentDataType [counter1] = new string [9];
    }
    
    lineageFluorescentDataTypeEntryLimit = lineageFluorescentDataTypeEntryLimit+320;
    lineageFluorescentDataTypeEntryCount = 0;
    
    for (int counter1 = 0; counter1 < lineageFluorescentEntryCount; counter1++){
        for (int counter2 = 0; counter2 < 8; counter2++){
            arrayLineageFluorescentDataType [lineageFluorescentDataTypeEntryCount][counter2] = arrayLineageFluorescentDataTypeTemp [counter1][counter2];
        }
        
        lineageFluorescentDataTypeEntryCount++;
    }
    
    for (int counter1 = 0; counter1 < lineageFluorescentDataTypeEntryLimitTemp; counter1++){
        delete [] arrayLineageFluorescentDataTypeTemp [counter1];
    }
    
    delete [] arrayLineageFluorescentDataTypeTemp;
}

-(void)fileDeleteUpDate{
    string *arrayUpDate = new string [fileDeleteCount+10];
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayUpDate [counter1] = arrayFileDelete [counter1];
    
    delete [] arrayFileDelete;
    arrayFileDelete = new string [fileDeleteLimit+500];
    fileDeleteLimit = fileDeleteLimit+500;
    
    for (int counter1 = 0; counter1 < fileDeleteCount; counter1++) arrayFileDelete [counter1] = arrayUpDate [counter1];
    delete [] arrayUpDate;
}

@end
