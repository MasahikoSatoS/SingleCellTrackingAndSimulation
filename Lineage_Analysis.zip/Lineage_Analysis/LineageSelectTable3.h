//
//  LineageSelectTable3.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#ifndef LINEAGESELECTTABLE3_H
#define LINEAGESELECTTABLE3_H
#import "Controller.h" 
#endif

@interface LineageSelectTable3 : NSObject <NSTableViewDataSource>{
    IBOutlet NSTableView *lineageSelectTable3;
}

-(id)init;
-(void)dealloc;

-(int)numberOfRowsInTableView:(NSTableView *)aTableView;
-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex;
-(BOOL)tableView:(NSTableView *)aTableView shouldSelectRow:(int)rowIndex;

@end
