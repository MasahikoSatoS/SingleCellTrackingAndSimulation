//
//  LineageSelectController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#ifndef LINEAGESELECTCONTROLLER_H
#define LINEAGESELECTCONTROLLER_H
#import "Controller.h"
#endif

@interface LineageSelectController : NSObject{
    IBOutlet NSTextField *fusionMoveDisplay;
    IBOutlet NSTextField *noOfPickDisplay;
    
    IBOutlet NSWindow *lineageSelectWindow;
    
    NSWindowController *lineageSelectWindowController;
    
    NSTimer *lineageSelectTimer;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)lineageFluorescentDataTypeUpDate;

-(IBAction)closeWindow:(id)sender;
-(IBAction)createNonSelected:(id)sender;
-(IBAction)createSelected:(id)sender;
-(IBAction)fusionMove:(id)sender;
-(IBAction)resetSelect:(id)sender;
-(IBAction)randomSelect:(id)sender;

@end
