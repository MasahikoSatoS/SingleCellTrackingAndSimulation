//
//  EventAnalysisController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-06-08.
//
//

#ifndef EVENTANALYSISCONTROLLER_H
#define EVENTANALYSISCONTROLLER_H
#import "Controller.h" 
#endif

@interface EventAnalysisController : NSObject <NSTextFieldDelegate>{
    int rangeSt1; //Range start
    int rangeSt2; //Range start
    int rangeSt3; //Range start
    int rangeSt4; //Range start
    
    int rangeEd1; //Range end
    int rangeEd2; //Range end
    int rangeEd3; //Range end
    int rangeEd4; //Range end
    
    int normalizeHold; //Normalize
    int normalizationStatusHold; //Normalize status
    int sdSetStatusHold; //SD status
    int firstEventStatusHold; //First event
    int followingEventStatusHold; //Following event
    int firstEventStatusHold2; //First event
    int followingEventStatusHold2; //Following event
    int firstEventStatusHold3; //First event
    int followingEventStatusHold3; //Following event
    int firstEventStatusHold4; //First event
    int followingEventStatusHold4; //Following event
    
    int singleDDStatusHold; //Single DD
    int singleTDStatusHold; //Single TD
    int singleHDStatusHold; //Single HD
    int singleOFStatusHold; //Single OF
    int singleCDStatusHold; //Single CD
    int singleIPStatusHold; //Single IP
    int singleMIStatusHold; //Single MI
    int singleCFStatusHold; //Single CF
    int singleDVStatusHold; //Single DV
    int singleCellStatusHold; //Single cell status
    int singleDFStatusHold; //Single DF
    int singleDSStatusHold; //Single DS
    int singleDGStatusHold; //Single DG
    int singleTGStatusHold; //Single TG
    
    int followingEventDivision; //Following event div
    int divisionAfter; //Division after
    int stopBeforeMI; //Stop before MI
    int noDataLingInclude; //No data ling include
    
    IBOutlet NSTextField *rangeEventStDisplay1;
    IBOutlet NSTextField *rangeEventStDisplay2;
    IBOutlet NSTextField *rangeEventStDisplay3;
    IBOutlet NSTextField *rangeEventStDisplay4;
    IBOutlet NSTextField *rangeEventEdDisplay1;
    IBOutlet NSTextField *rangeEventEdDisplay2;
    IBOutlet NSTextField *rangeEventEdDisplay3;
    IBOutlet NSTextField *rangeEventEdDisplay4;
    IBOutlet NSTextField *normalizeDisplay;
    IBOutlet NSTextField *sdStatusDisplay;
    
    IBOutlet NSTextField *eventSingleDDDisplay;
    IBOutlet NSTextField *eventSingleTDDisplay;
    IBOutlet NSTextField *eventSingleHDDisplay;
    IBOutlet NSTextField *eventSingleOFDisplay;
    IBOutlet NSTextField *eventSingleCDDisplay;
    IBOutlet NSTextField *eventSingleCFDisplay;
    IBOutlet NSTextField *eventSingleIPDisplay;
    IBOutlet NSTextField *eventSingleMIDisplay;
    IBOutlet NSTextField *eventSingleDVDisplay;
    IBOutlet NSTextField *eventSingleDFDisplay;
    IBOutlet NSTextField *eventSingleDSDisplay;
    IBOutlet NSTextField *eventSingleDGDisplay;
    IBOutlet NSTextField *eventSingleTGDisplay;
    IBOutlet NSTextField *eventSingleCellDisplay;
    
    IBOutlet NSTextField *eventFirstDisplay;
    IBOutlet NSTextField *eventFollowingDisplay;
    IBOutlet NSTextField *eventFirstDisplay2;
    IBOutlet NSTextField *eventFollowingDisplay2;
    IBOutlet NSTextField *eventFirstDisplay3;
    IBOutlet NSTextField *eventFollowingDisplay3;
    IBOutlet NSTextField *eventFirstDisplay4;
    IBOutlet NSTextField *eventFollowingDisplay4;
    
    IBOutlet NSTextField *plusDivDisplay;
    IBOutlet NSTextField *stopBFMIDisplay;
    IBOutlet NSTextField *noDataLingDisplay;
    
    IBOutlet NSTextField *normalizeCellNoDisplay;
    IBOutlet NSTextField *normalizeLingDisplay;
    IBOutlet NSTextField *normalizeCellDisplay;
    
    IBOutlet NSWindow *eventAnalysisWindow;
    
    NSWindowController *eventAnalysisWindowController;
    
    NSTimer *eventAnalysisTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;
-(void)analysisSet;

-(IBAction)closeWindow:(id)sender;
-(IBAction)sdStatusSet:(id)sender;
-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFile2:(id)sender;
-(IBAction)createExcelFile3:(id)sender;
-(IBAction)analysisStart:(id)sender;

-(IBAction)setSingleDD:(id)sender;
-(IBAction)setSingleTD:(id)sender;
-(IBAction)setSingleHD:(id)sender;
-(IBAction)setSingleOF:(id)sender;
-(IBAction)setSingleCD:(id)sender;
-(IBAction)setSingleIP:(id)sender;
-(IBAction)setSingleMI:(id)sender;
-(IBAction)setSingleCF:(id)sender;
-(IBAction)setSingleDV:(id)sender;
-(IBAction)setSingleDF:(id)sender;
-(IBAction)setSingleDS:(id)sender;
-(IBAction)setSingleGD:(id)sender;
-(IBAction)setSingleTG:(id)sender;
-(IBAction)selectAll:(id)sender;
-(IBAction)noLingDataIncSet:(id)sender;

-(IBAction)setFirstDD:(id)sender;
-(IBAction)setFirstTD:(id)sender;
-(IBAction)setFirstHD:(id)sender;
-(IBAction)setFirstIP:(id)sender;
-(IBAction)setFirstMI:(id)sender;
-(IBAction)setFirstCF:(id)sender;

-(IBAction)setFirstDDSeq:(id)sender;
-(IBAction)plusDivSet:(id)sender;
-(IBAction)stopBFMISet:(id)sender;

-(IBAction)setFollowingDD:(id)sender;
-(IBAction)setFollowingTD:(id)sender;
-(IBAction)setFollowingHD:(id)sender;
-(IBAction)setFollowingOF:(id)sender;
-(IBAction)setFollowingCD:(id)sender;
-(IBAction)setFollowingIP:(id)sender;
-(IBAction)setFollowingMI:(id)sender;
-(IBAction)setFollowingCF:(id)sender;
-(IBAction)setFollowingDV:(id)sender;
-(IBAction)clearSequential:(id)sender;

-(IBAction)normalizationNumber:(id)sender;
-(IBAction)normalizationLing:(id)sender;
-(IBAction)normalizationCell:(id)sender;

@end
