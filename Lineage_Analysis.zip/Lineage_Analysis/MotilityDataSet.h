//
//  MotilityDataSet.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#ifndef MOTILITYDATASET_H
#define MOTILITYDATASET_H
#import "Controller.h"
#endif

@interface MotilityDataSet : NSObject{
    IBOutlet NSTextField *displayScaleDisplay;
    IBOutlet NSTextField *displayMaxDisplay;
    IBOutlet NSTextField *verticalStartDisplay;
    IBOutlet NSTextField *horizontalStartDisplay;
    IBOutlet NSTextField *treatmentMotilityDisplay;
    IBOutlet NSTextField *lineageMotilityDisplay;
    IBOutlet NSTextField *cellMotilityDisplay;
    IBOutlet NSTextField *verticalRangeDisplay;
    IBOutlet NSTextField *horizontalRangeDisplay;
}

-(id)init;
-(void)dealloc;

@end
