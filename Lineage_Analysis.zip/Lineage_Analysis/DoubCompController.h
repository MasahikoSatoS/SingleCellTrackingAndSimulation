//
//  DoubCompController.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-01-30.
//
//

#ifndef DOUBCOMPCONTROLLER_H
#define DOUBCOMPCONTROLLER_H
#import "Controller.h" 
#endif

@interface DoubCompController : NSObject<NSTextFieldDelegate>{
    int geneDAStatusHold; //Set DA
    int geneG1StatusHold; //Set G1
    int geneG2StatusHold; //Set G2
    int geneG3StatusHold; //Set G3
    
    int timeDiffStatusHold; //Time difference
    int lingGenerationStatusHold; //Lineage generation
    int startValueHold; //Start value
    int rangeValuesHold; //Range
    int groupValueHold; //Group value
    int noOfGenerationValueHold; //No of generation value
    int grandDDNoCutOff; //Grand DD cut off
    int progenyDoubleHold; //Progeny double
    
    IBOutlet NSTextField *startDADisplay;
    IBOutlet NSTextField *startDG1isplay;
    IBOutlet NSTextField *startDG2isplay;
    IBOutlet NSTextField *startDG3isplay;
    IBOutlet NSTextField *timeDiffDisplay;
    IBOutlet NSTextField *lingGenerationDisplay;
    IBOutlet NSTextField *rangeValueDisplay;
    IBOutlet NSTextField *groupValueDisplay;
    IBOutlet NSTextField *startValueDisplay;
    IBOutlet NSTextField *noOfGenerationValueDisplay;
    IBOutlet NSTextField *grandDDNoCutOffDisplay;
    IBOutlet NSTextField *progenyDoubleDisplay;
    
    IBOutlet NSWindow *mainWindowDoubWindow;
    
    NSWindowController *mainWindowDoubController;
    
    NSTimer *doubControllerTimer;
    
    id ascIIconversion;
}

-(id)init;
-(void)dealloc;
-(void)reDisplayWindow;

-(IBAction)closeWindow:(id)sender;

-(IBAction)createExcelFile:(id)sender;
-(IBAction)createExcelFile2:(id)sender;
-(IBAction)analysisStart:(id)sender;

-(IBAction)setDA:(id)sender;
-(IBAction)setG1:(id)sender;
-(IBAction)setG2:(id)sender;
-(IBAction)setG3:(id)sender;
-(IBAction)setGDDCut:(id)sender;
-(IBAction)timeDiffSet:(id)sender;
-(IBAction)lingGenSet:(id)sender;
-(IBAction)proDobSet:(id)sender;

@end
