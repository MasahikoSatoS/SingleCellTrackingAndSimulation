//
//  CellDivisionAddition.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 12/15/16.
//
//

#import "CellDivisionAddition.h"

NSString *notificationToCellDivisionAddition = @"notificationExecuteCellDivisionAddition";

@implementation CellDivisionAddition

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToCellDivisionAddition object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [verticalHigh setIntegerValue:verticalScaleHighUpDivisionHold];
    [verticalDownHigh setIntegerValue:verticalScaleHighDownDivisionHold];
    [horizontalLow setIntegerValue:horizontalScaleLowDivisionHold];
    [horizontalHigh setIntegerValue:horizontalScaleHighDivisionHold];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToCellDivisionAddition object:nil];
}

@end
