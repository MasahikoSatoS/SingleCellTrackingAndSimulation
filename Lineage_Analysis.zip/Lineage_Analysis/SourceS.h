//
//  SourceS.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 10/21/16.
//
//

#ifndef SOURCES_H
#define SOURCES_H
#import "Controller.h"
#endif

@interface SourceS : NSObject{
}

-(void)sourceMain;
-(void)lineageFluorescentDataTypeUpDate;
-(void)fileDeleteUpDate;

@end
