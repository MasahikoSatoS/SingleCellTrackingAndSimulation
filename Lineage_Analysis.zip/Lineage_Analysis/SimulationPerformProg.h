//
//  SimulationPerformProg.h
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2020-12-08.
//

#ifndef SIMULATIONPERFORMPROG_H
#define SIMULATIONPERFORMPROG_H
#import "Controller.h"
#endif

@interface SimulationPerformProg : NSObject{
    int *expandFirstDVList; //First DV
    int expandFirstDVListCount;
    int *expandDoubLingDoubBD; //Expand doubling BD
    int expandDoubLingDoubBDCount;
    int *expandDoubLingDoubTD; //Expand doubling TD
    int expandDoubLingDoubTDCount;
    int *expandDoubLingDoubCF; //Expand CF
    int expandDoubLingDoubCFCount;
    
    int *expandBDCD; //Expand BDCD
    int expandBDCDCount;
    int *expandBDCF; //Expand BDCF
    int expandBDCFCount;
    int *expandNonCD; //Expand nonCD
    int expandNonCDCount;
    int *expandBDCFCD; //Expand BDCFCD
    int expandBDCFCDCount;
    
    int *expandTDCF; //Expand TDCF
    int expandTDCFCount;
    int *expandTDCFCD; //Expand TDCFCD
    int expandTDCFCDCount;
    int *expandTDCD; //Expand TDCD
    int expandTDCDCount;
    
    int *firstEventList; //First event
    int *secondEventBDList; //Second event BD
    int *secondEventBDCFList; //Second event BDCF
    int *secondEventTDList; //Second event TD
    int *secondEventTDCFList; //Second event TDCF
    
    int randBDRangeA; //Rand BD
    int randBDRangeB; //Rand BD
    int randCDRangeA; //Rand CD
    int randCDRangeB; //Rand CD
    
    int durationStart; //Duration start
    int durationEnd; //Duration end
    int baseMidHold; //Base mid
    int timeProgCount; //Time prog
    
    id createNewCellNo;
}

-(void)progPerform:(int)growthCycleMid :(int)growthCycleProgEnd :(int)growthCycleProgEnd2;

-(void)expandFirstDVListSet;
-(void)expandDoubLingDoubBDSet;
-(void)expandDoubLingDoubTDSet;
-(void)expandDoubLingDoubCFSet;
-(void)expandBDCDSet;
-(void)expandBDCFSet;
-(void)expandNonCDSet;
-(void)expandBDCFCDSet;
-(void)expandTDCFSet;
-(void)expandTDCFCDSet;
-(void)expandTDCDSet;
-(void)firstEventListSet;
-(void)secondEventBDListSet;
-(void)secondEventBDCFListSet;
-(void)secondEventTDListSet;
-(void)secondEventTDCFListSet;
-(void)randBDRangeSet;

@end
