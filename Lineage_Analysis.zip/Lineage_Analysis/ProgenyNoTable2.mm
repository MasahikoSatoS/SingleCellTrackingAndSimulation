//
//  ProgenyNoTable2.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2017-05-10.
//
//

#import "ProgenyNoTable2.h"

@implementation ProgenyNoTable2

NSString *notificationToProgenyNoTable2 = @"notificationExecuteProgenyNoTable2";

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToProgenyNoTable2 object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [categoryProgenyTable2 setDataSource:self];
    [categoryProgenyTable2 reloadData];
}

-(int)numberOfRowsInTableView:(NSTableView *)aTableView{
    int tableViewContent = categoryRangeHoldCount/3;
    return tableViewContent;
}

-(id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex{
    NSAttributedString *attrStr;
    
    if (initialArraySet == 1){
        string displayData1 = to_string(arrayCategoryRangeHold [rowIndex*3]);
        string displayData2 = "";
        
        if (arrayCategoryRangeHold [rowIndex*3+2] == 100000000) displayData2 = ">= "+to_string(arrayCategoryRangeHold [rowIndex*3+1]);
        else displayData2 = to_string(arrayCategoryRangeHold [rowIndex*3+1]);
        
        string displayData3 = "";
        
        if (arrayCategoryRangeHold [rowIndex*3+2] == 100000000) displayData3 = "";
        else displayData3 = to_string(arrayCategoryRangeHold [rowIndex*3+2]);
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData1.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData2.c_str()) attributes:attributes];
        }
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]){
            [attributes setObject:[NSColor blackColor] forKey: NSForegroundColorAttributeName];
            attrStr = [[NSAttributedString alloc] initWithString:@(displayData3.c_str()) attributes:attributes];
        }
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    else{
        
        NSMutableDictionary *attributes = [NSMutableDictionary dictionary];
        
        if ([[aTableColumn identifier] isEqualToString:@"COL1"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL2"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else if ([[aTableColumn identifier] isEqualToString:@"COL3"]) attrStr = [[NSAttributedString alloc] initWithString:@" "];
        else attrStr = [[NSAttributedString alloc] initWithString:@"" attributes:attributes];
    }
    
    return attrStr;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToProgenyNoTable2 object:nil];
}

@end
