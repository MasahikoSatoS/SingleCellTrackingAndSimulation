//
//  MotilityDataSet.m
//  Lineage_Analysis
//
//  Created by Masahiko Sato on 2018-03-06.
//
//

#import "MotilityDataSet.h"

NSString *notificationToMotilityDataSet = @"notificationExecuteMotilityDataSet";

@implementation MotilityDataSet

-(id)init{
    self = [super init];
    
    if (self != nil){
        NSNotificationCenter *center = [NSNotificationCenter defaultCenter];
        [center addObserver:self selector:@selector(defaultsChanged:) name:notificationToMotilityDataSet object:nil];
    }
    
    return self;
}

-(void)defaultsChanged:(NSNotification *) notification{
    [displayScaleDisplay setIntegerValue:motilityDisplayScaleMaxHold];
    [displayMaxDisplay setIntegerValue:motilityDisplayScaleMaxHold];
    [verticalStartDisplay setIntegerValue:motilityVerticalStartHold];
    [horizontalStartDisplay setIntegerValue:motilityHorizontalStartHold];
    [treatmentMotilityDisplay setStringValue:@(motilityTreatmentHold.c_str())];
    [lineageMotilityDisplay setStringValue:@(motilityLineageHold.c_str())];
    
    if (motilityCellNoHold == -1) [cellMotilityDisplay setStringValue:@"nil"];
    else [cellMotilityDisplay setIntegerValue:motilityCellNoHold];
    
    [verticalRangeDisplay setStringValue:@(motilityRangeVertical.c_str())];
    [horizontalRangeDisplay setStringValue:@(motilityRangeHorizontal.c_str())];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self name:notificationToMotilityDataSet object:nil];
}

@end
